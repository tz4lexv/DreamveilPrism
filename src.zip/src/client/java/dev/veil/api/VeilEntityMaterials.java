package dev.veil.api;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

public final class VeilEntityMaterials {
    private record Entry(String type, String layer, VeilCreatorScene.Material material) {}

    public interface Registration extends AutoCloseable {
        @Override
        void close();
    }

    private static final ConcurrentHashMap<String, Entry> ENTRIES = new ConcurrentHashMap<>();

    private VeilEntityMaterials() {}

    public static synchronized Registration register(
            String entityType, String layer, VeilCreatorScene.Material material) {
        Objects.requireNonNull(material);
        if (entityType == null
                || !entityType.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")
                || layer == null
                || layer.isBlank()
                || material.id() < 6)
            throw new IllegalArgumentException(
                    "Entity material requires namespaced type, layer and non-reserved material ID");
        String key = entityType + "|" + layer;
        for (var value : ENTRIES.values())
            if (value.material().id() == material.id() && !value.material().equals(material))
                throw new IllegalArgumentException(
                        "Conflicting entity material ID " + material.id());
        Entry entry = new Entry(entityType, layer, material);
        if (ENTRIES.putIfAbsent(key, entry) != null)
            throw new IllegalStateException("Entity material mapping already registered: " + key);
        var closed = new java.util.concurrent.atomic.AtomicBoolean();
        return () -> {
            if (closed.compareAndSet(false, true)) ENTRIES.remove(key, entry);
        };
    }

    public static int resolve(String entityType, String layer, int fallback) {
        if (ENTRIES.isEmpty()) return fallback;
        Entry entry = ENTRIES.get(entityType + "|" + layer);
        if (entry == null) entry = ENTRIES.get(entityType + "|*");
        return entry == null ? fallback : entry.material().id();
    }

    public static List<VeilCreatorScene.Material> materials() {
        return ENTRIES.values().stream().map(Entry::material).distinct().toList();
    }
}
