package dev.veil.revive.client.graphics.minecraft;

import static org.lwjgl.vulkan.VK10.VK_SUCCESS;

public final class VulkanResult {
    private VulkanResult() {}

    public static void check(int result, String operation) {
        if (result != VK_SUCCESS)
            throw new IllegalStateException(operation + " failed with VkResult " + result);
    }
}
