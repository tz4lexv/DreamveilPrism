package dev.veil.revive.mixin;

import com.mojang.blaze3d.textures.GpuSampler;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChunkSectionsToRender.class)
public abstract class ChunkSectionsFullTelemetryMixin {
    @Unique private VeilFullFrameTelemetry.CpuZone veil$zone;

    @Inject(method = "renderGroup", at = @At("HEAD"), require = 0)
    private void veil$renderGroupStart(
            ChunkSectionLayerGroup group, GpuSampler sampler, CallbackInfo ci) {
        this.veil$zone =
                group == ChunkSectionLayerGroup.TRANSLUCENT
                        ? VeilFullFrameTelemetry.CpuZone.TERRAIN_TRANSLUCENT_SUBMIT
                        : VeilFullFrameTelemetry.CpuZone.TERRAIN_OPAQUE_SUBMIT;
        VeilFullFrameTelemetry.beginCpu(this.veil$zone);
    }

    @Inject(method = "renderGroup", at = @At("RETURN"), require = 0)
    private void veil$renderGroupEnd(
            ChunkSectionLayerGroup group, GpuSampler sampler, CallbackInfo ci) {
        if (this.veil$zone != null) VeilFullFrameTelemetry.endCpu(this.veil$zone);
        this.veil$zone = null;
    }
}
