package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.vertex.MeshData;

import dev.veil.revive.client.*;

import net.minecraft.client.renderer.chunk.*;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.function.BiConsumer;

@Mixin(CompiledSectionMesh.class)
public abstract class CompiledSectionMetadataMixin
        implements VeilMeshExtras, VeilTransparencyExtras {
    @Unique private VeilMeshMetadata veil$metadata;

    @Unique
    private final VeilTransparencyState veil$transparencyState =
            VeilTransparencyOrder.requested() ? new VeilTransparencyState() : null;

    @Override
    public VeilTransparencyState veil$transparencyState() {
        return veil$transparencyState;
    }

    @Override
    public VeilTransparencyOrder veil$transparencyOrder() {
        return veil$transparencyState == null ? null : veil$transparencyState.get();
    }

    @Override
    public void veil$transparencyOrder(VeilTransparencyOrder order) {
        if (veil$transparencyState != null) veil$transparencyState.set(order);
    }

    @WrapOperation(
            method = "<init>",
            at =
                    @At(
                            value = "INVOKE",
                            target = "Ljava/util/Map;forEach(Ljava/util/function/BiConsumer;)V"),
            require = 1)
    private void veil$capture(
            Map<ChunkSectionLayer, MeshData> layers,
            BiConsumer<ChunkSectionLayer, MeshData> consumer,
            Operation<Void> original,
            TranslucencyPointOfView view,
            SectionCompiler.Results results) {
        veil$metadata = new VeilMeshMetadata(results);
        try {
            VeilIndexedTerrain.optimize(results, veil$metadata);
            veil$metadata.accountUploads(results);
            original.call(layers, consumer);
        } catch (RuntimeException | Error failure) {
            try {
                veil$metadata.close((SectionMesh) (Object) this);
            } catch (RuntimeException | Error cleanup) {
                failure.addSuppressed(cleanup);
            }
            throw failure;
        }
    }

    @Override
    public VeilMeshMetadata veil$metadata() {
        return veil$metadata;
    }

    @Inject(method = "close", at = @At("HEAD"), require = 1)
    private void veil$retire(CallbackInfo ci) {
        if (veil$transparencyState != null) veil$transparencyState.close();
        if (veil$metadata != null) veil$metadata.close((SectionMesh) (Object) this);
    }
}
