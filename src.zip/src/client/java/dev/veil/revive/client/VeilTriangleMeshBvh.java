package dev.veil.revive.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

final class VeilTriangleMeshBvh {
    static final int MAX_TRIANGLES = 16_384;

    record Bounds(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        Bounds union(Bounds other) {
            return new Bounds(
                    Math.min(minX, other.minX),
                    Math.min(minY, other.minY),
                    Math.min(minZ, other.minZ),
                    Math.max(maxX, other.maxX),
                    Math.max(maxY, other.maxY),
                    Math.max(maxZ, other.maxZ));
        }

        double centroid(int axis) {
            return switch (axis) {
                case 0 -> (minX + maxX) * 0.5;
                case 1 -> (minY + maxY) * 0.5;
                default -> (minZ + maxZ) * 0.5;
            };
        }
    }

    record Node(Bounds bounds, int left, int right, int primitive) {
        boolean leaf() {
            return primitive >= 0;
        }
    }

    record Topology(
            int[] primitiveOrder,
            int[] left,
            int[] right,
            int[] primitive,
            int root,
            int maxDepth) {}

    record Build(Topology topology, List<Node> nodes) {}

    private VeilTriangleMeshBvh() {}

    static Build build(List<Bounds> source) {
        if (source.size() > MAX_TRIANGLES)
            throw new IllegalArgumentException("Creator meshes exceed triangle budget");
        if (source.isEmpty())
            return new Build(
                    new Topology(new int[0], new int[0], new int[0], new int[0], -1, 0), List.of());
        ArrayList<Integer> order = new ArrayList<>(source.size());
        for (int index = 0; index < source.size(); index++) order.add(index);
        ArrayList<MutableNode> nodes = new ArrayList<>(source.size() * 2 - 1);
        int[] depth = {0};
        int root = buildRange(source, order, nodes, 0, order.size(), 1, depth);
        int[] primitiveOrder = order.stream().mapToInt(Integer::intValue).toArray();
        int[] left = new int[nodes.size()],
                right = new int[nodes.size()],
                primitive = new int[nodes.size()];
        for (int index = 0; index < nodes.size(); index++) {
            MutableNode node = nodes.get(index);
            left[index] = node.left;
            right[index] = node.right;
            primitive[index] = node.primitive;
        }
        Topology topology = new Topology(primitiveOrder, left, right, primitive, root, depth[0]);
        return new Build(topology, refit(topology, source));
    }

    static List<Node> refit(Topology topology, List<Bounds> source) {
        if (source.size() != topology.primitiveOrder.length)
            throw new IllegalArgumentException("BVH topology size changed");
        if (topology.root < 0) return List.of();
        Node[] nodes = new Node[topology.left.length];
        refitNode(topology.root, topology, source, nodes);
        return List.of(nodes);
    }

    private static Bounds refitNode(
            int index, Topology topology, List<Bounds> source, Node[] output) {
        int primitive = topology.primitive[index];
        Bounds bounds;
        if (primitive >= 0) {
            bounds = source.get(topology.primitiveOrder[primitive]);
        } else {
            bounds =
                    refitNode(topology.left[index], topology, source, output)
                            .union(refitNode(topology.right[index], topology, source, output));
        }
        output[index] =
                new Node(
                        bounds,
                        topology.left[index],
                        topology.right[index],
                        primitive < 0 ? -1 : topology.primitiveOrder[primitive]);
        return bounds;
    }

    private static int buildRange(
            List<Bounds> source,
            ArrayList<Integer> order,
            ArrayList<MutableNode> nodes,
            int from,
            int to,
            int level,
            int[] maxDepth) {
        maxDepth[0] = Math.max(maxDepth[0], level);
        int nodeIndex = nodes.size();
        nodes.add(new MutableNode());
        if (to - from == 1) {
            nodes.get(nodeIndex).primitive = from;
            return nodeIndex;
        }
        Bounds centroidBounds = source.get(order.get(from));
        float minX = (float) centroidBounds.centroid(0), maxX = minX;
        float minY = (float) centroidBounds.centroid(1), maxY = minY;
        float minZ = (float) centroidBounds.centroid(2), maxZ = minZ;
        for (int index = from + 1; index < to; index++) {
            Bounds value = source.get(order.get(index));
            float x = (float) value.centroid(0),
                    y = (float) value.centroid(1),
                    z = (float) value.centroid(2);
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            minZ = Math.min(minZ, z);
            maxZ = Math.max(maxZ, z);
        }
        int axis =
                maxX - minX >= maxY - minY && maxX - minX >= maxZ - minZ
                        ? 0
                        : maxY - minY >= maxZ - minZ ? 1 : 2;
        order.subList(from, to)
                .sort(Comparator.comparingDouble(value -> source.get(value).centroid(axis)));
        int middle = (from + to) >>> 1;
        MutableNode node = nodes.get(nodeIndex);
        node.left = buildRange(source, order, nodes, from, middle, level + 1, maxDepth);
        node.right = buildRange(source, order, nodes, middle, to, level + 1, maxDepth);
        node.primitive = -1;
        return nodeIndex;
    }

    private static final class MutableNode {
        int left = -1, right = -1, primitive = -1;
    }
}
