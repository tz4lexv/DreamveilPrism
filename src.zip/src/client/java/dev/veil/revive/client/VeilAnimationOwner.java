package dev.veil.revive.client;

import net.minecraft.client.renderer.texture.SpriteContents;
import net.minecraft.resources.Identifier;

public interface VeilAnimationOwner {
    void veil$setOwner(Identifier name, SpriteContents contents);
}
