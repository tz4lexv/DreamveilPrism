package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.sugar.Local;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilRebuildBudget;
import dev.veil.revive.client.VeilRebuildCoalescer;
import dev.veil.revive.client.VeilVideoConfig;
import dev.veil.revive.core.UploadWaitPolicy;

import net.minecraft.client.renderer.SectionBufferBuilderPack;
import net.minecraft.client.renderer.chunk.CompiledSectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.concurrent.locks.LockSupport;

@Mixin(
        targets =
                "net.minecraft.client.renderer.chunk.SectionRenderDispatcher$RenderSection$CompileTask")
public abstract class CompileTaskCoalescingMixin {
    @Unique private long veil$compileStartNs;
    @Unique private int veil$uploadWaitSpins;
    @Unique private long veil$uploadParkedNs;

    @Inject(method = "doTask", at = @At("HEAD"), require = 0)
    private void veil$measureCompileStart(
            SectionBufferBuilderPack buffers,
            CallbackInfoReturnable<
                            SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult>
                    cir) {
        veil$uploadWaitSpins = 0;
        veil$uploadParkedNs = 0L;
        if (ReviveRuntime.optimizationsEnabled() && VeilVideoConfig.on("renderer.rebuildBudget")) {
            veil$compileStartNs = System.nanoTime();
        }
    }

    @Inject(method = "doTask", at = @At("RETURN"), require = 0)
    private void veil$measureCompileEnd(
            SectionBufferBuilderPack buffers,
            CallbackInfoReturnable<
                            SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult>
                    cir) {
        long start = veil$compileStartNs;
        veil$compileStartNs = 0L;
        if (start != 0L)
            VeilRebuildBudget.recordCompileDuration(
                    Math.max(1L, System.nanoTime() - start - veil$uploadParkedNs));
    }

    @Redirect(
            method = "doTask",
            at = @At(value = "INVOKE", target = "Ljava/lang/Thread;onSpinWait()V"),
            require = 0)
    private void veil$adaptiveUploadBackoff() {
        if (veil$uploadWaitSpins < Integer.MAX_VALUE) veil$uploadWaitSpins++;
        long delay = UploadWaitPolicy.parkNanos(veil$uploadWaitSpins);
        if (!ReviveRuntime.optimizationsEnabled()
                || !VeilVideoConfig.on("renderer.rebuildBudget")
                || delay == 0L) {
            Thread.onSpinWait();
            return;
        }
        if (Thread.currentThread().isInterrupted()) {
            VeilRebuildCoalescer.recordUploadBackoffYield();
            Thread.yield();
            return;
        }
        long start = System.nanoTime();
        LockSupport.parkNanos(delay);
        long elapsed = System.nanoTime() - start;
        veil$uploadParkedNs += elapsed;
        VeilRebuildCoalescer.recordUploadBackoffPark(elapsed);
    }

    @Inject(
            method = "doTask",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/renderer/chunk/SectionRenderDispatcher$RenderSection;setSectionMesh(Lnet/minecraft/client/renderer/chunk/SectionMesh;)Lnet/minecraft/client/renderer/chunk/SectionMesh;"),
            cancellable = true,
            require = 1)
    private void veil$dropObsoleteEmptyResult(
            SectionBufferBuilderPack buffers,
            CallbackInfoReturnable<
                            SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult>
                    cir,
            @Local CompiledSectionMesh mesh) {
        if (ReviveRuntime.optimizationsEnabled()
                && VeilVideoConfig.on("renderer.rebuildCoalescing")
                && ((SectionTaskAccessor) (Object) this).veil$isCancelled().get()) {
            mesh.close();
            cir.setReturnValue(
                    SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult.CANCELLED);
        }
    }
}
