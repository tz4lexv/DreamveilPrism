package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import java.util.function.BiConsumer;

public record VeilSectionUniformUploader(
        int index,
        SectionMesh mesh,
        ChunkSectionLayer layer,
        SectionRenderDispatcher.RenderSection section)
        implements BiConsumer<GpuBufferSlice[], RenderPass.UniformUploader>,
                dev.veil.revive.client.terrain.capture.TerrainPlanSource.UniformOwner {
    public VeilSectionUniformUploader(int index, SectionMesh mesh, ChunkSectionLayer layer) {
        this(index, mesh, layer, null);
    }

    @Override
    public void accept(GpuBufferSlice[] sections, RenderPass.UniformUploader uploader) {
        uploader.upload("ChunkSection", sections[index]);
    }
}
