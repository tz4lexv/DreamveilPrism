package dev.veil.revive.client;

public interface VeilMeshExtras {
    VeilMeshMetadata veil$metadata();
}
