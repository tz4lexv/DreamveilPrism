package dev.veil.revive.client.graphics.minecraft;

import com.mojang.blaze3d.vulkan.Destroyable;
import com.mojang.blaze3d.vulkan.VulkanCommandEncoder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

final class DeferredDestructionAudit {
    private static final String REPORT = System.getProperty("veil.deferredDestructionReport");
    private static long queued, completed, failed, rejected, pending;
    private static boolean reportWarningEmitted;
    private static volatile Snapshot latest;
    private static Snapshot flushed;
    private static final ScheduledExecutorService WRITER = startWriter();

    private DeferredDestructionAudit() {}

    static void enqueue(VulkanCommandEncoder encoder, Destroyable destruction) {
        if (REPORT == null) {
            encoder.queueForDestroy(destruction);
            return;
        }
        queued++;
        pending++;
        AtomicBoolean callbackStarted = new AtomicBoolean();
        try {
            encoder.queueForDestroy(
                    () -> {
                        callbackStarted.set(true);
                        try {
                            destruction.destroy();
                            completed++;
                        } catch (RuntimeException | Error problem) {
                            failed++;
                            throw problem;
                        } finally {
                            pending--;
                            checkpoint();
                        }
                    });
        } catch (RuntimeException | Error problem) {
            // A synchronous queue is also legal in unit tests: if its callback
            // already ran and threw, that is a destruction failure, not a rejection.
            if (!callbackStarted.get()) {
                rejected++;
                pending--;
            }
            checkpoint();
            throw problem;
        }
        checkpoint();
    }

    private static void checkpoint() {
        latest = new Snapshot(queued, completed, failed, rejected, pending);
    }

    private static ScheduledExecutorService startWriter() {
        if (REPORT == null) return null;
        try {
            var writer =
                    Executors.newSingleThreadScheduledExecutor(
                            task -> {
                                var thread = new Thread(task, "Veil retirement audit writer");
                                thread.setDaemon(true);
                                return thread;
                            });
            try {
                Runtime.getRuntime()
                        .addShutdownHook(
                                new Thread(
                                        () -> {
                                            writer.shutdown();
                                            flush();
                                        },
                                        "Veil retirement audit shutdown"));
                writer.scheduleWithFixedDelay(
                        DeferredDestructionAudit::flush, 250L, 250L, TimeUnit.MILLISECONDS);
                return writer;
            } catch (RuntimeException problem) {
                writer.shutdown();
                throw problem;
            }
        } catch (RuntimeException problem) {
            warn(problem);
            return null;
        }
    }

    static synchronized void flush() {
        Snapshot snapshot = latest;
        if (REPORT == null || snapshot == null || snapshot.equals(flushed)) return;
        try {
            Files.writeString(Path.of(REPORT), snapshot.json());
            flushed = snapshot;
        } catch (IOException | RuntimeException problem) {
            warn(problem);
        }
    }

    private static void warn(Exception problem) {
        if (!reportWarningEmitted) {
            reportWarningEmitted = true;
            System.err.println("Veil GPU retirement audit unavailable: " + problem);
        }
    }

    private record Snapshot(long queued, long completed, long failed, long rejected, long pending) {
        String json() {
            return "{\"queued\":"
                    + queued
                    + ",\"completed\":"
                    + completed
                    + ",\"failed\":"
                    + failed
                    + ",\"rejected\":"
                    + rejected
                    + ",\"pending\":"
                    + pending
                    + "}\n";
        }
    }
}
