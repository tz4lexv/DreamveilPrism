package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.vkCmdCopyBuffer;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.api.VeilCreatorScene;

import net.minecraft.client.Minecraft;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkBufferCopy;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

final class VeilShadowLightHost {
    static final String HOST_ID = "minecraft:shadow_lights";
    static final int MAX_LIGHTS = 16;
    static final int CAPACITY = 48 + MAX_LIGHTS * 64;
    private static final int MAGIC = 0x56534c31;

    private static GpuBuffer buffer;
    private static int dataHash;
    private static boolean uploaded;
    private static long frames, uploads;
    private static int candidateCount, selectedCount;

    private VeilShadowLightHost() {}

    static void prepare() {
        RenderSystem.assertOnRenderThread();
        Minecraft client = Minecraft.getInstance();
        if (client.level == null
                || client.gameRenderer == null
                || client.gameRenderer.mainCamera() == null) return;
        var camera = client.gameRenderer.mainCamera().position();
        List<VeilCreatorScene.Light> candidates = VeilCreatorSceneHost.lightsSnapshot();
        List<VeilCreatorScene.Light> selected =
                select(candidates, camera.x, camera.y, camera.z, MAX_LIGHTS);
        candidateCount = candidates.size();
        selectedCount = selected.size();
        byte[] data = encode(selected, floor256(camera.x), floor256(camera.y), floor256(camera.z));
        int nextHash = Arrays.hashCode(data);
        if (buffer == null)
            buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil budgeted shadow lights",
                                    VeilHzb.STORAGE_USAGE | GpuBuffer.USAGE_COPY_DST,
                                    CAPACITY);
        if (!uploaded || nextHash != dataHash) {
            upload(data);
            dataHash = nextHash;
            uploaded = true;
            uploads++;
        }
        frames++;
    }

    static List<VeilCreatorScene.Light> select(
            List<VeilCreatorScene.Light> source,
            double cameraX,
            double cameraY,
            double cameraZ,
            int limit) {
        if (limit <= 0 || source.isEmpty()) return List.of();
        ArrayList<Scored> scored = new ArrayList<>(source.size());
        for (VeilCreatorScene.Light light : source) {
            double luminance =
                    Math.max(0.0, light.r() * 0.2126 + light.g() * 0.7152 + light.b() * 0.0722);
            double score;
            if (light.type() == VeilCreatorScene.LIGHT_DIRECTIONAL) {
                score = 1.0e12 + luminance * Math.max(0.0, light.intensity()) * 1.0e6;
            } else {
                double dx = light.x() - cameraX, dy = light.y() - cameraY, dz = light.z() - cameraZ;
                double distanceSquared = dx * dx + dy * dy + dz * dz;
                double range = Math.max(0.0, light.range());
                if (range <= 0.0 || distanceSquared > range * range) continue;
                double window = 1.0 - Math.min(1.0, distanceSquared / (range * range));
                score =
                        luminance
                                * Math.max(0.0, light.intensity())
                                * window
                                * window
                                / Math.max(distanceSquared, 0.25);
            }
            if (score > 0.0 && Double.isFinite(score)) scored.add(new Scored(light, score));
        }
        scored.sort(
                Comparator.comparingDouble(Scored::score)
                        .reversed()
                        .thenComparingLong(value -> value.light().id()));
        ArrayList<VeilCreatorScene.Light> result = new ArrayList<>(Math.min(limit, scored.size()));
        for (int index = 0; index < scored.size() && index < limit; index++)
            result.add(scored.get(index).light());
        return List.copyOf(result);
    }

    static GpuBuffer buffer() {
        if (buffer == null) throw new IllegalStateException(HOST_ID + " is not prepared");
        return buffer;
    }

    private static byte[] encode(
            List<VeilCreatorScene.Light> lights, int originX, int originY, int originZ) {
        ByteBuffer out =
                ByteBuffer.wrap(new byte[48 + lights.size() * 64]).order(ByteOrder.LITTLE_ENDIAN);
        out.putInt(0, MAGIC).putInt(4, 1).putInt(8, lights.size()).putInt(12, MAX_LIGHTS);
        out.putFloat(16, originX).putFloat(20, originY).putFloat(24, originZ).putFloat(28, 0.0f);
        out.putInt(32, candidateCount).putInt(36, 0).putInt(40, 0).putInt(44, 0);
        int offset = 48;
        for (VeilCreatorScene.Light light : lights) {
            out.putFloat(offset, light.x() - originX)
                    .putFloat(offset + 4, light.y() - originY)
                    .putFloat(offset + 8, light.z() - originZ)
                    .putFloat(offset + 12, light.range());
            out.putFloat(offset + 16, light.r())
                    .putFloat(offset + 20, light.g())
                    .putFloat(offset + 24, light.b())
                    .putFloat(offset + 28, light.intensity());
            out.putFloat(offset + 32, light.directionX())
                    .putFloat(offset + 36, light.directionY())
                    .putFloat(offset + 40, light.directionZ())
                    .putInt(offset + 44, light.type());
            out.putFloat(offset + 48, light.innerCos())
                    .putFloat(offset + 52, light.outerCos())
                    .putInt(offset + 56, light.flags())
                    .putInt(offset + 60, (int) light.id());
            offset += 64;
        }
        return out.array();
    }

    private static void upload(byte[] data) {
        GpuBuffer staging =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil shadow light staging",
                                GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                                data.length);
        try {
            try (var mapping = staging.map(false, true)) {
                mapping.data().put(data);
            }
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var copy = VkBufferCopy.calloc(1, stack);
                copy.get(0).srcOffset(0).dstOffset(0).size(data.length);
                vkCmdCopyBuffer(
                        VeilVulkanRuntime.requireCurrent().commandBuffer(),
                        ((VulkanGpuBuffer) staging).vkBuffer(),
                        ((VulkanGpuBuffer) buffer).vkBuffer(),
                        copy);
            }
        } finally {
            staging.close();
        }
    }

    static String telemetry() {
        return "shadow_light_frames="
                + frames
                + "\nshadow_light_uploads_total="
                + uploads
                + "\nshadow_light_candidates="
                + candidateCount
                + "\nshadow_lights_selected="
                + selectedCount;
    }

    static void close() {
        if (buffer != null) {
            buffer.close();
            buffer = null;
        }
        dataHash = 0;
        uploaded = false;
        candidateCount = selectedCount = 0;
    }

    private static int floor256(double value) {
        return Math.floorDiv((int) Math.floor(value), 256) * 256;
    }

    private record Scored(VeilCreatorScene.Light light, double score) {}
}
