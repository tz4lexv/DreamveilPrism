package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.terrain.PairedTerrainMesh;

import java.util.IdentityHashMap;

final class VeilPairedTerrainGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.verifyProgressivePairs")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final IdentityHashMap<Object, Boolean> SEEN = new IdentityHashMap<>();
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static PairedTerrainMesh.Result expected;
    private static Object expectedIdentity;
    private static long verifiedVertices;
    private static final long[] layouts = new long[3], indexWidths = new long[2];
    private static final boolean REQUIRE_FLOAT20 =
            "false".equalsIgnoreCase(System.getProperty("veil.regularPackedPrefer16"));
    private static boolean offsetVerified;

    static boolean enabled() {
        return ENABLED;
    }

    static void capture(
            Object identity,
            PairedTerrainMesh.Result data,
            GpuBuffer vertices,
            long vertexOffset,
            GpuBuffer indices,
            long indexOffset) {
        capture(identity, data, vertices, vertexOffset, indices, indexOffset, false);
    }

    static boolean verify(
            Object identity,
            PairedTerrainMesh.Result data,
            GpuBuffer vertices,
            long vertexOffset,
            GpuBuffer indices,
            long indexOffset) {
        if (!ENABLED) throw new IllegalStateException("Paired lifecycle requires GPU verification");
        capture(identity, data, vertices, vertexOffset, indices, indexOffset, true);
        return Boolean.TRUE.equals(SEEN.get(identity));
    }

    private static void capture(
            Object identity,
            PairedTerrainMesh.Result data,
            GpuBuffer vertices,
            long vertexOffset,
            GpuBuffer indices,
            long indexOffset,
            boolean force) {
        if (!ENABLED
                || fence != null
                || SEEN.containsKey(identity)
                || !force
                        && verifiedVertices >= 100000
                        && offsetVerified
                        && (!REQUIRE_FLOAT20 || layouts[1] >= 100000)) return;
        if (!force
                && REQUIRE_FLOAT20
                && data.vertices().layout()
                        != dev.veil.revive.core.terrain.RegularTerrainVertices.Layout.FLOAT_UV20)
            return;
        SEEN.put(identity, Boolean.FALSE);
        expected = data;
        expectedIdentity = identity;
        readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil paired upload parity",
                                GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                                data.byteSize());
        var encoder = RenderSystem.getDevice().createCommandEncoder();
        encoder.copyToBuffer(
                vertices.slice(vertexOffset, data.vertices().vertices().length),
                readback.slice(0, data.vertices().vertices().length));
        encoder.copyToBuffer(
                indices.slice(indexOffset, data.indices().length),
                readback.slice(data.vertices().vertices().length, data.indices().length));
        offsetVerified |= vertexOffset != 0 && indexOffset != 0;
        fence = encoder.createFence();
    }

    static void tick() {
        if (!ENABLED || fence == null || !fence.awaitCompletion(0)) return;
        try (var mapped = readback.map(true, false)) {
            var bytes = mapped.data();
            byte[] vertices = expected.vertices().vertices(), indices = expected.indices();
            for (int i = 0; i < vertices.length; i++)
                if (bytes.get(i) != vertices[i])
                    throw new IllegalStateException("Paired GPU vertex bytes differ");
            for (int i = 0; i < indices.length; i++)
                if (bytes.get(vertices.length + i) != indices[i])
                    throw new IllegalStateException("Paired GPU index bytes differ");
        }
        verifiedVertices += expected.originalVertices();
        SEEN.put(expectedIdentity, Boolean.TRUE);
        layouts[expected.vertices().layout().ordinal()] += expected.originalVertices();
        indexWidths[expected.indexBytes() == 2 ? 0 : 1] += expected.originalVertices();
        fence.close();
        readback.close();
        fence = null;
        readback = null;
        expected = null;
        expectedIdentity = null;
    }

    static void requireComplete() {
        if (!ENABLED) return;
        tick();
        if (verifiedVertices < 100000
                || !offsetVerified
                || fence != null
                || REQUIRE_FLOAT20 && layouts[1] < 100000)
            throw new IllegalStateException("Paired GPU buffer parity incomplete");
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil paired GPU uploads: PASS (native_vertices={} nonzero_vertex_and_index_offsets=true)",
                verifiedVertices);
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil paired GPU formats: grid16={} float_uv20={} wide_position20={} indices16={} indices32={}",
                layouts[0],
                layouts[1],
                layouts[2],
                indexWidths[0],
                indexWidths[1]);
    }

    static void close() {
        if (fence != null) fence.close();
        if (readback != null) readback.close();
        fence = null;
        readback = null;
        expected = null;
        expectedIdentity = null;
        SEEN.clear();
    }
}
