package dev.veil.revive.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class VeilRayAccelerationCache implements AutoCloseable {
    private Map<VeilRaySectionCache.Key, VeilRayQueryScene> sections = new HashMap<>();
    private long rebuilds, reuses, topBuilds;

    VeilRayQueryScene prepare(
            VeilVulkanRuntime runtime, List<VeilRaySectionCache.Part> parts, long sceneBytes) {
        var next = new HashMap<VeilRaySectionCache.Key, VeilRayQueryScene>();
        var created = new ArrayList<VeilRayQueryScene>();
        var instances = new ArrayList<VeilRayQueryScene.Instance>();
        VeilRayQueryScene top = null;
        long bytes = sceneBytes;
        int rebuilt = 0, reused = 0;
        try {
            for (var part : parts) {
                var bottom = next.get(part.key());
                if (bottom == null) bottom = sections.get(part.key());
                if (bottom == null) {
                    bottom = new VeilRayQueryScene(runtime, part.bytes(), "Veil ray section", true);
                    created.add(bottom);
                    bottom.build();
                    rebuilt++;
                } else reused++;
                if (next.putIfAbsent(part.key(), bottom) == null)
                    bytes = Math.addExact(bytes, bottom.bytes());
                if (bytes > VeilShaderLimits.current().packBytes())
                    throw new IllegalArgumentException(
                            "Section acceleration cache exceeds shader memory budget");
                instances.add(
                        new VeilRayQueryScene.Instance(
                                bottom.bottomAddress(),
                                part.triangleOffset(),
                                part.x(),
                                part.y(),
                                part.z()));
            }
            top = new VeilRayQueryScene(runtime, instances, "Veil world sections");
            if (bytes > VeilShaderLimits.current().packBytes() - top.bytes())
                throw new IllegalArgumentException("World TLAS exceeds shader memory budget");
            top.build();
            for (var entry : sections.entrySet())
                if (!next.containsKey(entry.getKey())) entry.getValue().close();
            sections = next;
            rebuilds += rebuilt;
            reuses += reused;
            topBuilds++;
            return top;
        } catch (RuntimeException | Error failure) {
            if (top != null) top.close();
            created.forEach(VeilRayQueryScene::close);
            throw failure;
        }
    }

    String telemetry() {
        return "ray_world_blas_rebuilds_total="
                + rebuilds
                + "\nray_world_blas_reuses_total="
                + reuses
                + "\nray_world_tlas_builds_total="
                + topBuilds;
    }

    public void close() {
        sections.values().forEach(VeilRayQueryScene::close);
        sections.clear();
    }
}
