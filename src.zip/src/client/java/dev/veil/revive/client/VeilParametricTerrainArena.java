package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.terrain.ParametricTerrainQuads;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.LongAdder;

final class VeilParametricTerrainArena {
    private static final boolean REQUESTED = Boolean.getBoolean("veil.parametricTerrain");
    private static final boolean VERIFY =
            Boolean.getBoolean("veil.verifyParametricTerrain")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final int LIMIT = 4 << 20;
    private static final ParametricTerrainQuads.Layout[] LAYOUTS =
            ParametricTerrainQuads.Layout.values();
    private static final LongAdder CPU_VERTICES = new LongAdder();
    private static final List<VeilManagedGpuArena<Entry>> ARENAS =
            new ArrayList<>(Arrays.asList(null, null, null, null));
    private static final IdentityHashMap<SectionMesh, EnumMap<ChunkSectionLayer, Entry>> OWNERS =
            new IdentityHashMap<>();
    private static final IdentityHashMap<SectionMesh, EnumMap<ChunkSectionLayer, Failure>>
            FAILURES = new IdentityHashMap<>();
    private static final IdentityHashMap<GpuBuffer, Integer> FORMATS = new IdentityHashMap<>();
    private static final ConcurrentLinkedQueue<SectionMesh> RETIRED = new ConcurrentLinkedQueue<>();
    private static final IdentityHashMap<
                    SectionRenderDispatcher.RenderSection, EnumMap<ChunkSectionLayer, Reservation>>
            REPLACEMENTS = new IdentityHashMap<>();
    private static final ArrayDeque<Reservation> EXPIRATIONS = new ArrayDeque<>();
    private static VeilPersistentStagingBuffer staging;
    private static ByteBuffer scratch;
    private static volatile boolean disabled;
    private static long revision, uploaded, resolved, commands, savedBytes, expired, rejected;
    private static long nextExpiry;
    private static long reused, expiredReservations;
    private static long sliceReuses, sliceCreations;
    private static int heapBytes;

    private static final class Entry {
        final int slot, quads;
        final SectionRenderDispatcher.RenderSection section;
        final long origin;
        long lastSeen;
        boolean reused;
        Slice cachedSlice;

        Entry(int slot, int quads, long now, SectionRenderDispatcher.RenderSection section) {
            this.slot = slot;
            this.quads = quads;
            this.section = section;
            origin = section == null ? 0 : section.getRenderOrigin().asLong();
            lastSeen = now;
        }
    }

    private record Reservation(
            SectionRenderDispatcher.RenderSection section,
            ChunkSectionLayer layer,
            Entry entry,
            long expires) {}

    private record Failure(ParametricTerrainQuads.Result data, long capacityRevision) {}

    record Slice(GpuBuffer buffer, int baseVertex, int indexCount) {}

    private VeilParametricTerrainArena() {}

    static boolean requested() {
        return REQUESTED;
    }

    static int temporaryBytesPerVertex() {
        return 2 + (VERIFY ? 28 : 0) + (VeilParametricTerrainGpuProbe.enabled() ? 28 : 0);
    }

    static boolean enabled() {
        return REQUESTED && !disabled && VeilProgressiveMeshing.pairsEnabled();
    }

    static void disable() {
        disabled = true;
    }

    static void verifyCpu(byte[] source, ParametricTerrainQuads.Result data) {
        VeilParametricTerrainGpuProbe.captureSource(source, data);
        if (!VERIFY || CPU_VERTICES.sum() >= 100000) return;
        var decoded = ParametricTerrainQuads.decode(data);
        if (decoded.remaining() != source.length)
            throw new IllegalStateException("Parametric native size mismatch");
        for (int b = 0; b < source.length; b++)
            if (source[b] != decoded.get(b))
                throw new IllegalStateException("Parametric native attribute mismatch byte=" + b);
        CPU_VERTICES.add(data.quadCount() * 4L);
    }

    static void update(
            Map<ChunkSectionLayer, ? extends Map<?, List<RenderPass.Draw<GpuBufferSlice[]>>>>
                    groups) {
        drainRetired();
        if (!enabled()) return;
        long now = System.nanoTime();
        expireReservations(now);
        int budget = LIMIT;
        boolean staged = false;
        for (var layer : groups.entrySet()) {
            if (layer.getKey() == ChunkSectionLayer.TRANSLUCENT) continue;
            for (var draws : layer.getValue().values())
                for (var draw : draws) {
                    if (!(draw.uniformUploaderConsumer()
                            instanceof VeilSectionUniformUploader uploader)) continue;
                    var owner = OWNERS.get(uploader.mesh());
                    if (owner != null && owner.containsKey(layer.getKey())) {
                        owner.get(layer.getKey()).lastSeen = now;
                        continue;
                    }
                    if (!(uploader.mesh() instanceof VeilMeshExtras extras)
                            || extras.veil$metadata() == null
                            || extras.veil$metadata().closed()) continue;
                    var data = extras.veil$metadata().parametricTerrain(layer.getKey());
                    if (data == null || data.descriptors().length > budget) continue;
                    int slot = data.layout().ordinal();
                    if (staging == null) {
                        staging = new VeilPersistentStagingBuffer("Veil parametric uploads", LIMIT);
                        try (var stack = org.lwjgl.system.MemoryStack.stackPush()) {
                            var properties =
                                    org.lwjgl.vulkan.VkPhysicalDeviceProperties.calloc(stack);
                            var format = org.lwjgl.vulkan.VkFormatProperties.calloc(stack);
                            org.lwjgl.vulkan.VK10.vkGetPhysicalDeviceFormatProperties(
                                    VeilVulkanRuntime.requireCurrent()
                                            .vkDevice()
                                            .getPhysicalDevice(),
                                    org.lwjgl.vulkan.VK10.VK_FORMAT_R32_SINT,
                                    format);
                            if ((format.bufferFeatures()
                                            & org.lwjgl
                                                    .vulkan
                                                    .VK10
                                                    .VK_FORMAT_FEATURE_UNIFORM_TEXEL_BUFFER_BIT)
                                    == 0) {
                                disable();
                                staging.close();
                                staging = null;
                                ReviveMod.LOGGER.warn(
                                        "Veil parametric terrain unavailable: R32_SINT texel buffers unsupported");
                                return;
                            }
                            org.lwjgl.vulkan.VK10.vkGetPhysicalDeviceProperties(
                                    VeilVulkanRuntime.requireCurrent()
                                            .vkDevice()
                                            .getPhysicalDevice(),
                                    properties);
                            heapBytes =
                                    (int)
                                            Math.min(
                                                    LIMIT,
                                                    Integer.toUnsignedLong(
                                                                    properties
                                                                            .limits()
                                                                            .maxTexelBufferElements())
                                                            * 4L);
                        }
                    }
                    if (ARENAS.get(slot) == null)
                        ARENAS.set(
                                slot,
                                new VeilManagedGpuArena<>(
                                        "Veil parametric descriptors " + slot,
                                        GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER,
                                        heapBytes,
                                        data.layout().stride(),
                                        staging,
                                        2));
                    var arena = ARENAS.get(slot);
                    var reservation = reservation(uploader.section(), layer.getKey());
                    var failures = FAILURES.get(uploader.mesh());
                    var failure = failures == null ? null : failures.get(layer.getKey());
                    if (reservation == null
                            && failure != null
                            && failure.data == data
                            && failure.capacityRevision == arena.capacityRevision()) continue;
                    if (failures != null) failures.remove(layer.getKey());
                    budget -= data.descriptors().length;
                    var entry = new Entry(slot, data.quadCount(), now, uploader.section());
                    if (reservation != null) {
                        var previous = reservation.entry;
                        var allocation = ARENAS.get(previous.slot).getAllocation(previous);
                        if (previous.slot == slot
                                && previous.origin == entry.origin
                                && allocation != null
                                && allocation.size() >= data.descriptors().length) {
                            var admission =
                                    arena.tryRestageAllocation(
                                            previous,
                                            data.descriptors().length,
                                            () -> prepare(data.descriptors()));
                            if (admission == VeilManagedGpuArena.Admission.STAGING) continue;
                            if (admission == VeilManagedGpuArena.Admission.ADDED) {
                                consumeReservation(reservation);
                                arena.rekeyAllocation(previous, entry);
                                entry.reused = true;
                                OWNERS.computeIfAbsent(
                                                uploader.mesh(),
                                                ignored -> new EnumMap<>(ChunkSectionLayer.class))
                                        .put(layer.getKey(), entry);
                                staged = true;
                                reused++;
                                uploaded++;
                                savedBytes += data.quadCount() * 112L - data.descriptors().length;
                                continue;
                            }
                        }
                        consumeReservation(reservation);
                        release(previous);
                    }
                    var admission =
                            arena.tryAddAllocation(
                                    entry,
                                    ignored -> revision++,
                                    data.descriptors().length,
                                    () -> prepare(data.descriptors()));
                    if (admission == VeilManagedGpuArena.Admission.CAPACITY) {
                        FAILURES.computeIfAbsent(
                                        uploader.mesh(),
                                        ignored -> new EnumMap<>(ChunkSectionLayer.class))
                                .put(layer.getKey(), new Failure(data, arena.capacityRevision()));
                        rejected++;
                        continue;
                    }
                    if (admission != VeilManagedGpuArena.Admission.ADDED) continue;
                    OWNERS.computeIfAbsent(
                                    uploader.mesh(),
                                    ignored -> new EnumMap<>(ChunkSectionLayer.class))
                            .put(layer.getKey(), entry);
                    staged = true;
                    uploaded++;
                    savedBytes += data.quadCount() * 112L - data.descriptors().length;
                }
        }
        if (staged)
            try (var uploader =
                    staging.startUploading(RenderSystem.getDevice().createCommandEncoder())) {
                for (var arena : ARENAS)
                    if (arena != null)
                        arena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
            }
        if (now >= nextExpiry) {
            nextExpiry = now + 1_000_000_000L;
            var owners = OWNERS.values().iterator();
            while (owners.hasNext()) {
                var layers = owners.next();
                var entries = layers.values().iterator();
                while (entries.hasNext()) {
                    var entry = entries.next();
                    if (now - entry.lastSeen < 2_000_000_000L) continue;
                    release(entry);
                    entries.remove();
                    expired++;
                }
                if (layers.isEmpty()) owners.remove();
            }
        }
        for (var arena : ARENAS) if (arena != null) arena.maintain();
    }

    private static ByteBuffer prepare(byte[] bytes) {
        if (scratch == null || scratch.capacity() < bytes.length) {
            if (scratch != null) MemoryUtil.memFree(scratch);
            scratch = MemoryUtil.memAlloc(Math.max(4096, bytes.length));
        }
        return scratch.clear().put(bytes).flip();
    }

    private static void release(Entry entry) {
        ARENAS.get(entry.slot).removeAllocation(entry);
        revision++;
    }

    private static Reservation reservation(
            SectionRenderDispatcher.RenderSection section, ChunkSectionLayer layer) {
        var layers = REPLACEMENTS.get(section);
        return layers == null ? null : layers.get(layer);
    }

    private static void consumeReservation(Reservation reservation) {
        var layers = REPLACEMENTS.get(reservation.section);
        if (layers == null || layers.get(reservation.layer) != reservation) return;
        layers.remove(reservation.layer);
        if (layers.isEmpty()) REPLACEMENTS.remove(reservation.section);
    }

    private static void expireReservations(long now) {
        for (int n = 0;
                n < 64 && !EXPIRATIONS.isEmpty() && EXPIRATIONS.peekFirst().expires <= now;
                n++) {
            var reservation = EXPIRATIONS.removeFirst();
            if (reservation(reservation.section, reservation.layer) != reservation) continue;
            consumeReservation(reservation);
            release(reservation.entry);
            expiredReservations++;
        }
    }

    private static void drainRetired() {
        SectionMesh retired;
        while ((retired = RETIRED.poll()) != null) {
            FAILURES.remove(retired);
            var removed = OWNERS.remove(retired);
            if (removed == null) continue;
            for (var layer : removed.entrySet()) {
                var entry = layer.getValue();
                if (entry.section == null || ARENAS.get(entry.slot).getAllocation(entry) == null) {
                    release(entry);
                    continue;
                }
                var reservation =
                        new Reservation(
                                entry.section,
                                layer.getKey(),
                                entry,
                                System.nanoTime() + 1_000_000_000L);
                var layers =
                        REPLACEMENTS.computeIfAbsent(
                                entry.section, ignored -> new EnumMap<>(ChunkSectionLayer.class));
                var previous = layers.put(layer.getKey(), reservation);
                if (previous != null && previous.entry != entry) release(previous.entry);
                EXPIRATIONS.addLast(reservation);
            }
            revision++;
        }
    }

    static boolean hasOwner(SectionMesh mesh) {
        return OWNERS.containsKey(mesh);
    }

    static long reusedAllocations() {
        return reused;
    }

    static boolean reusedAllocation(SectionMesh mesh, ChunkSectionLayer layer) {
        var owner = OWNERS.get(mesh);
        var entry = owner == null ? null : owner.get(layer);
        return entry != null && entry.reused;
    }

    static boolean verifyGpuDescriptors(SectionMesh mesh, ChunkSectionLayer layer) {
        var owner = OWNERS.get(mesh);
        var entry = owner == null ? null : owner.get(layer);
        if (entry == null || !(mesh instanceof VeilMeshExtras extras)) return false;
        var data = extras.veil$metadata().parametricTerrain(layer);
        var arena = ARENAS.get(entry.slot);
        var allocation = arena.getAllocation(entry);
        return data != null
                && allocation != null
                && VeilParametricDescriptorProbe.verify(
                        entry,
                        data.descriptors(),
                        arena.getGpuBuffer(allocation),
                        allocation.offset());
    }

    static void retire(SectionMesh mesh) {
        RETIRED.add(mesh);
    }

    static Slice get(SectionMesh mesh, ChunkSectionLayer layer) {
        Slice slice = peek(mesh, layer);
        if (slice != null) resolved++;
        return slice;
    }

    static Slice peek(SectionMesh mesh, ChunkSectionLayer layer) {
        if (!enabled()
                || !(mesh instanceof VeilMeshExtras extras)
                || extras.veil$metadata() == null
                || extras.veil$metadata().closed()
                || extras.veil$metadata().parametricTerrain(layer) == null) return null;
        var owner = OWNERS.get(mesh);
        var entry = owner == null ? null : owner.get(layer);
        if (entry == null) return null;
        var arena = ARENAS.get(entry.slot);
        var allocation = arena.getAllocation(entry);
        if (allocation == null) return null;
        var buffer = arena.getGpuBuffer(allocation);
        FORMATS.put(buffer, entry.slot);
        int baseVertex = Math.toIntExact(allocation.offset() / LAYOUTS[entry.slot].stride() * 4);
        var cached = entry.cachedSlice;
        if (cached != null && cached.buffer() == buffer && cached.baseVertex() == baseVertex) {
            sliceReuses++;
            return cached;
        }
        sliceCreations++;
        return entry.cachedSlice = new Slice(buffer, baseVertex, entry.quads * 6);
    }

    static int formatSlot(GpuBuffer buffer) {
        return REQUESTED ? FORMATS.getOrDefault(buffer, -1) : -1;
    }

    static long revision() {
        return revision;
    }

    static void recordSubmission(GpuBuffer buffer, int count) {
        if (REQUESTED && FORMATS.containsKey(buffer)) commands += count;
    }

    static void requireComplete() {
        if (!REQUESTED) return;
        if (!enabled()
                || uploaded == 0
                || resolved == 0
                || commands == 0
                || VERIFY && CPU_VERTICES.sum() < 100000)
            throw new IllegalStateException(
                    "Parametric terrain route incomplete: uploaded="
                            + uploaded
                            + " resolved="
                            + resolved
                            + " commands="
                            + commands
                            + " cpu_vertices="
                            + CPU_VERTICES.sum());
        ReviveMod.LOGGER.info(
                "Veil parametric terrain route: PASS (uploaded={} resolved={} gpu_commands={} cpu_vertices={} saved_descriptor_bytes={} expired={} capacity_rejections={} reused={} expired_reservations={} slice_reuses={} slice_creations={})",
                uploaded,
                resolved,
                commands,
                CPU_VERTICES.sum(),
                savedBytes,
                expired,
                rejected,
                reused,
                expiredReservations,
                sliceReuses,
                sliceCreations);
    }

    static void close() {
        VeilParametricTerrainGpuProbe.close();
        VeilParametricDescriptorProbe.close();
        for (int i = 0; i < ARENAS.size(); i++) {
            if (ARENAS.get(i) != null) ARENAS.get(i).close();
            ARENAS.set(i, null);
        }
        if (staging != null) {
            staging.close();
            staging = null;
        }
        if (scratch != null) {
            MemoryUtil.memFree(scratch);
            scratch = null;
        }
        OWNERS.clear();
        FAILURES.clear();
        FORMATS.clear();
        RETIRED.clear();
        REPLACEMENTS.clear();
        EXPIRATIONS.clear();
        nextExpiry = 0;
        heapBytes = 0;
        revision++;
    }
}
