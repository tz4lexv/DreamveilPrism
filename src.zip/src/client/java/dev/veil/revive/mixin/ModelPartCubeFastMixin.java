package dev.veil.revive.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.veil.revive.client.VeilEntityCubeRenderer;
import dev.veil.revive.client.VeilEntityModelFastPath;
import dev.veil.revive.client.VeilModelCuboid;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.core.Direction;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;

@Mixin(ModelPart.Cube.class)
public abstract class ModelPartCubeFastMixin {
    @Mutable @Shadow @Final public float minX;

    @Shadow @Final public ModelPart.Polygon[] polygons;

    @Unique private VeilModelCuboid veil$cuboid;

    @Redirect(
            method = "<init>",
            at =
                    @At(
                            value = "FIELD",
                            opcode = Opcodes.PUTFIELD,
                            target = "Lnet/minecraft/client/model/geom/ModelPart$Cube;minX:F",
                            ordinal = 0),
            require = 0)
    private void veil$captureCube(
            ModelPart.Cube instance,
            float value,
            int xTexOffs,
            int yTexOffs,
            float minX,
            float minY,
            float minZ,
            float width,
            float height,
            float depth,
            float growX,
            float growY,
            float growZ,
            boolean mirror,
            float xTexSize,
            float yTexSize,
            Set<Direction> visibleFaces) {
        this.veil$cuboid =
                new VeilModelCuboid(
                        xTexOffs,
                        yTexOffs,
                        minX,
                        minY,
                        minZ,
                        width,
                        height,
                        depth,
                        growX,
                        growY,
                        growZ,
                        mirror,
                        xTexSize,
                        yTexSize,
                        visibleFaces);
        this.minX = value;
    }

    @Inject(method = "compile", at = @At("HEAD"), cancellable = true, require = 0)
    private void veil$fastCompile(
            PoseStack.Pose pose,
            VertexConsumer consumer,
            int light,
            int overlay,
            int color,
            CallbackInfo ci) {
        dev.veil.revive.client.VeilEntityMeshCapture.captureCube(pose, this.polygons);
        if (!VeilEntityModelFastPath.cubeEnabled()) return;
        if (this.veil$cuboid == null) {
            VeilEntityModelFastPath.recordCubeFallback();
            return;
        }

        if (((Object) this).getClass() != ModelPart.Cube.class) {
            VeilEntityModelFastPath.recordCubeFallback();
            return;
        }

        if (this.veil$cuboid.visibleFaceCount() < 3) {
            VeilEntityModelFastPath.recordCubeFallback();
            return;
        }

        VeilEntityCubeRenderer.render(pose, consumer, this.veil$cuboid, light, overlay, color);
        ci.cancel();
    }
}
