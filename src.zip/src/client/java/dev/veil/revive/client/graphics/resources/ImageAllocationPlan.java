package dev.veil.revive.client.graphics.resources;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilResourceUsage;

import java.util.Set;

public record ImageAllocationPlan(
        String name,
        VeilFormat format,
        int width,
        int height,
        int depth,
        int layers,
        int mipLevels,
        int samples,
        boolean nativeImage,
        boolean image3d,
        boolean cubemap,
        boolean image2dArray,
        boolean sampled,
        boolean storageImage,
        boolean renderTarget,
        boolean depthTarget,
        Set<VeilResourceUsage> usages,
        SamplerParameters sampler,
        boolean cubeArray,
        boolean image1d,
        boolean image1dArray) {
    public ImageAllocationPlan(
            String name,
            VeilFormat format,
            int width,
            int height,
            int depth,
            int layers,
            int mipLevels,
            int samples,
            boolean nativeImage,
            boolean image3d,
            boolean cubemap,
            boolean image2dArray,
            boolean sampled,
            boolean storageImage,
            boolean renderTarget,
            boolean depthTarget,
            Set<VeilResourceUsage> usages,
            SamplerParameters sampler,
            boolean cubeArray) {
        this(
                name,
                format,
                width,
                height,
                depth,
                layers,
                mipLevels,
                samples,
                nativeImage,
                image3d,
                cubemap,
                image2dArray,
                sampled,
                storageImage,
                renderTarget,
                depthTarget,
                usages,
                sampler,
                cubeArray,
                false,
                false);
    }

    public ImageAllocationPlan(
            String name,
            VeilFormat format,
            int width,
            int height,
            int depth,
            int layers,
            int mipLevels,
            int samples,
            boolean nativeImage,
            boolean image3d,
            boolean cubemap,
            boolean image2dArray,
            boolean sampled,
            boolean storageImage,
            boolean renderTarget,
            boolean depthTarget,
            Set<VeilResourceUsage> usages,
            SamplerParameters sampler) {
        this(
                name,
                format,
                width,
                height,
                depth,
                layers,
                mipLevels,
                samples,
                nativeImage,
                image3d,
                cubemap,
                image2dArray,
                sampled,
                storageImage,
                renderTarget,
                depthTarget,
                usages,
                sampler,
                false);
    }

    public ImageAllocationPlan {
        usages = Set.copyOf(usages);
        if (cubeArray && !cubemap)
            throw new IllegalArgumentException(
                    "Cubemap array must use cube-compatible image: " + name);
        if (image1dArray && !image1d || image1d && (image3d || cubemap || image2dArray))
            throw new IllegalArgumentException("Incompatible image dimensions: " + name);
    }

    public void validateExtent(
            int resolvedWidth, int resolvedHeight, int resolvedDepth, int resolvedLayers) {
        if (resolvedWidth < 1 || resolvedHeight < 1 || resolvedDepth < 1 || resolvedLayers < 1)
            throw new IllegalArgumentException("Image extent/layers must be positive: " + name);
        if (image3d && resolvedLayers != 1 || !image3d && resolvedDepth != 1)
            throw new IllegalArgumentException("Image dimensions do not match its type: " + name);
        if (image1d
                && (resolvedHeight != 1 || samples != 1 || !image1dArray && resolvedLayers != 1))
            throw new IllegalArgumentException(
                    "1D images require height/depth one, one sample and compatible layers: "
                            + name);
        if (cubemap
                && (image3d
                        || resolvedWidth != resolvedHeight
                        || (cubeArray
                                ? resolvedLayers < 6 || resolvedLayers % 6 != 0
                                : resolvedLayers != 6)
                        || samples != 1))
            throw new IllegalArgumentException(
                    "Cubemap requires square 2D faces, at least six layers and one sample: "
                            + name);
    }
}
