package dev.veil.revive.client;

import com.mojang.blaze3d.systems.GpuQueryPool;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.mixin.VulkanQueryPoolInvoker;

import java.util.Arrays;
import java.util.Locale;
import java.util.OptionalLong;

final class VeilShaderPassProfiler implements AutoCloseable {
    interface Queries extends AutoCloseable {
        default void prepare(int first, int count) {}

        default void afterCompletion(Runnable callback) {
            callback.run();
        }

        void write(int index);

        OptionalLong[] read(int first, int count);

        default OptionalLong[] invocations(int first, int count) {
            return null;
        }

        @Override
        void close();
    }

    private static final int SLOTS = 4;
    private final int count;
    private final double period;
    private final int validBits;
    private final boolean[] pending = new boolean[SLOTS];
    private final boolean[] complete = new boolean[SLOTS];
    private final long[] slotEpoch = new long[SLOTS];
    private long epoch;
    private final double[] totals;
    private final double[] minimum;
    private final double[] maximum;
    private final long[] samples;
    private final double[][] invocationTotals;
    private boolean invocationAvailable;
    private Queries queries;
    private int current = -1;
    private int next;
    private long skipped;
    private String unavailable = "";

    VeilShaderPassProfiler(int count, double period, int validBits) {
        this.count = count;
        this.period = period;
        this.validBits = validBits;
        totals = new double[count];
        minimum = new double[count];
        maximum = new double[count];
        samples = new long[count];
        invocationTotals = new double[count][3];
        Arrays.fill(minimum, Double.POSITIVE_INFINITY);
        if (count < 1 || !Double.isFinite(period) || period <= 0 || validBits < 1 || validBits > 64)
            unavailable = "timestamp capability unavailable";
    }

    VeilShaderPassProfiler(int count, double period, int validBits, Queries queries) {
        this(count, period, validBits);
        this.queries = queries;
    }

    void beginFrame(boolean enabled) {
        current = -1;
        if (!unavailable.isEmpty()) return;
        if (queries != null) for (int slot = 0; slot < SLOTS; slot++) poll(slot);
        if (!enabled) return;
        if (queries == null) {
            var invocations =
                    new VeilShaderInvocationQueries(
                            VeilVulkanRuntime.requireCurrent(), SLOTS * count);
            GpuQueryPool pool;
            try {
                pool = RenderSystem.getDevice().createTimestampQueryPool(SLOTS * count * 2);
            } catch (RuntimeException failure) {
                invocations.close();
                throw failure;
            }
            queries =
                    new Queries() {
                        public void prepare(int first, int length) {
                            org.lwjgl.vulkan.VK10.vkCmdResetQueryPool(
                                    VeilVulkanRuntime.requireCurrent().commandBuffer(),
                                    ((VulkanQueryPoolInvoker) pool).veil$queryPool(),
                                    first,
                                    length);
                            invocations.reset(first / 2, length / 2);
                        }

                        public void afterCompletion(Runnable callback) {
                            VeilVulkanRuntime.requireCurrent().deferDestroy(callback::run);
                        }

                        private void timestamp(int index) {
                            org.lwjgl.vulkan.KHRSynchronization2.vkCmdWriteTimestamp2KHR(
                                    VeilVulkanRuntime.requireCurrent().commandBuffer(),
                                    org.lwjgl.vulkan.VK13.VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                                    ((VulkanQueryPoolInvoker) pool).veil$queryPool(),
                                    index);
                        }

                        public void write(int index) {
                            if ((index & 1) == 0) {
                                timestamp(index);
                                invocations.begin(index / 2);
                            } else {
                                invocations.end(index / 2);
                                timestamp(index);
                            }
                        }

                        public OptionalLong[] read(int first, int length) {
                            return pool.getValues(first, length);
                        }

                        public OptionalLong[] invocations(int first, int length) {
                            return invocations.read(first, length);
                        }

                        public void close() {
                            pool.close();
                            invocations.close();
                        }
                    };
        }
        int slot = next++ & (SLOTS - 1);
        if (pending[slot]) {
            skipped++;
            return;
        }
        complete[slot] = false;
        slotEpoch[slot] = epoch;
        current = slot;
        queries.prepare(slot * count * 2, count * 2);
    }

    void begin(int pass) {
        if (current < 0) return;
        queries.write((current * count + pass) * 2);
        pending[current] = true;
    }

    void end(int pass) {
        if (current < 0) return;
        queries.write((current * count + pass) * 2 + 1);
        if (pass == count - 1) {
            int slot = current;
            Queries submittedQueries = queries;
            queries.afterCompletion(
                    () -> {
                        if (queries == submittedQueries) complete[slot] = true;
                    });
        }
    }

    void poll() {
        if (queries != null) for (int slot = 0; slot < SLOTS; slot++) poll(slot);
    }

    private void poll(int slot) {
        if (!pending[slot] || !complete[slot]) return;
        var values = queries.read(slot * count * 2, count * 2);
        for (var value : values) if (value.isEmpty()) return;
        var invocations = queries.invocations(slot * count, count);
        if (invocations != null) for (var value : invocations) if (value.isEmpty()) return;
        if (slotEpoch[slot] != epoch) {
            pending[slot] = false;
            return;
        }
        for (int pass = 0; pass < count; pass++) {
            double ms =
                    elapsed(
                            values[pass * 2].getAsLong(),
                            values[pass * 2 + 1].getAsLong(),
                            validBits,
                            period);
            if (!Double.isFinite(ms) || ms < 0) continue;
            totals[pass] += ms;
            minimum[pass] = Math.min(minimum[pass], ms);
            maximum[pass] = Math.max(maximum[pass], ms);
            samples[pass]++;
            if (invocations != null) {
                invocationAvailable = true;
                for (int counter = 0; counter < 3; counter++)
                    invocationTotals[pass][counter] += invocations[pass * 3 + counter].getAsLong();
            }
        }
        pending[slot] = false;
    }

    static double elapsed(long start, long end, int bits, double period) {
        long delta = end - start;
        if (bits < 64) delta &= (1L << bits) - 1;
        if (delta < 0) return Double.NaN;
        return delta * period / 1_000_000.0;
    }

    long samples(int pass) {
        return samples[pass];
    }

    void reset() {
        epoch++;
        Arrays.fill(totals, 0);
        Arrays.fill(maximum, 0);
        Arrays.fill(minimum, Double.POSITIVE_INFINITY);
        Arrays.fill(samples, 0);
        for (var counters : invocationTotals) Arrays.fill(counters, 0);
        invocationAvailable = false;
        skipped = 0;
    }

    long skipped() {
        return skipped;
    }

    double average(int pass) {
        return samples[pass] == 0 ? Double.NaN : totals[pass] / samples[pass];
    }

    String report(int pass) {
        if (!unavailable.isEmpty()) return "GPU ms: UNAVAILABLE (" + unavailable + ")";
        if (samples[pass] == 0)
            return "GPU ms: UNAVAILABLE (no completed samples; enable /veil shaders profile on)";
        String timing =
                String.format(
                        Locale.ROOT,
                        "GPU ms: avg=%.5f min=%.5f max=%.5f samples=%d skipped_frames=%d",
                        average(pass),
                        minimum[pass],
                        maximum[pass],
                        samples[pass],
                        skipped);
        return timing
                + (invocationAvailable
                        ? String.format(
                                Locale.ROOT,
                                "\nGPU invocations avg: vertex=%.1f fragment=%.1f compute=%.1f",
                                invocationTotals[pass][0] / samples[pass],
                                invocationTotals[pass][1] / samples[pass],
                                invocationTotals[pass][2] / samples[pass])
                        : "\nGPU invocations: UNAVAILABLE (pipelineStatisticsQuery not enabled)");
    }

    @Override
    public void close() {
        if (queries != null) {
            queries.close();
            queries = null;
        }
        current = -1;
        Arrays.fill(pending, false);
    }
}
