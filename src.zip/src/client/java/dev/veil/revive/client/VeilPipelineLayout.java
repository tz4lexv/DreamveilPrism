package dev.veil.revive.client;

import dev.veil.revive.client.graphics.pipelines.NativePipelineLayout;

import java.util.List;
import java.util.Objects;

final class VeilPipelineLayout implements AutoCloseable {
    public record DescriptorBinding(
            int binding, int descriptorType, int descriptorCount, int stageFlags) {
        public DescriptorBinding {
            if (binding < 0) throw new IllegalArgumentException("binding < 0");
            if (descriptorCount <= 0) throw new IllegalArgumentException("descriptorCount <= 0");
        }
    }

    public record PushConstantRange(int stageFlags, int offset, int size) {
        public PushConstantRange {
            if (offset < 0 || size <= 0 || (offset & 3) != 0 || (size & 3) != 0) {
                throw new IllegalArgumentException(
                        "Push constant offset/size must be positive 4-byte aligned values");
            }
        }
    }

    private final NativePipelineLayout resource;

    private VeilPipelineLayout(NativePipelineLayout resource) {
        this.resource = resource;
    }

    public static VeilPipelineLayout createPushDescriptorSet0(
            VeilVulkanRuntime runtime,
            List<DescriptorBinding> descriptorBindings,
            List<PushConstantRange> pushConstants) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        Objects.requireNonNull(runtime, "runtime");
        descriptorBindings = List.copyOf(descriptorBindings);
        VeilRayCapabilities.validateDescriptors(runtime, descriptorBindings);
        pushConstants = List.copyOf(pushConstants);
        var descriptors =
                descriptorBindings.stream()
                        .map(
                                binding ->
                                        new NativePipelineLayout.DescriptorBinding(
                                                binding.binding(),
                                                binding.descriptorType(),
                                                binding.descriptorCount(),
                                                binding.stageFlags()))
                        .toList();
        return new VeilPipelineLayout(
                NativePipelineLayout.createPushDescriptorSet0(
                        runtime, descriptors, nativePushes(pushConstants)));
    }

    public static VeilPipelineLayout createFromReflection(
            VeilVulkanRuntime runtime, VeilShaderInterface shaderInterface) {
        Objects.requireNonNull(runtime, "runtime");
        Objects.requireNonNull(shaderInterface, "shaderInterface");

        var descriptors = new java.util.ArrayList<DescriptorBinding>();
        for (var descriptor : shaderInterface.descriptors()) {
            if (descriptor.set() != 0) {
                throw new IllegalArgumentException(
                        "Veil push-descriptor creator backend supports reflected set 0 only; got set="
                                + descriptor.set()
                                + " binding="
                                + descriptor.binding());
            }
            if (descriptor.runtimeArray()) {
                throw new IllegalArgumentException(
                        "Runtime descriptor array reached layout creation without an ABI5 manifest bound: set="
                                + descriptor.set()
                                + " binding="
                                + descriptor.binding());
            }
            descriptors.add(
                    new DescriptorBinding(
                            descriptor.binding(),
                            descriptor.descriptorType(),
                            descriptor.descriptorCount(),
                            descriptor.stageFlags()));
        }

        var pushes = new java.util.ArrayList<PushConstantRange>();
        for (var push : shaderInterface.pushConstants()) {
            pushes.add(new PushConstantRange(push.stageFlags(), push.offset(), push.size()));
        }

        return descriptors.isEmpty()
                ? createNoDescriptors(runtime, pushes)
                : createPushDescriptorSet0(runtime, descriptors, pushes);
    }

    public static VeilPipelineLayout createNoDescriptors(
            VeilVulkanRuntime runtime, List<PushConstantRange> pushConstants) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        Objects.requireNonNull(runtime, "runtime");
        return new VeilPipelineLayout(
                NativePipelineLayout.createNoDescriptors(
                        runtime, nativePushes(List.copyOf(pushConstants))));
    }

    private static List<NativePipelineLayout.PushConstantRange> nativePushes(
            List<PushConstantRange> pushes) {
        return pushes.stream()
                .map(
                        push ->
                                new NativePipelineLayout.PushConstantRange(
                                        push.stageFlags(), push.offset(), push.size()))
                .toList();
    }

    public long handle() {
        return resource.handle();
    }

    public long descriptorSetLayout() {
        return resource.descriptorSetLayout();
    }

    void destroyNow() {
        resource.destroyNow();
    }

    @Override
    public void close() {
        resource.close();
    }
}
