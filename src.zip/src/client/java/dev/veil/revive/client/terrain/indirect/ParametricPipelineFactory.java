package dev.veil.revive.client.terrain.indirect;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.shaders.UniformType;

import dev.veil.revive.core.terrain.ParametricTerrainQuads;

import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.resources.Identifier;

import java.util.EnumMap;
import java.util.Optional;

public final class ParametricPipelineFactory {
    private ParametricPipelineFactory() {}

    public record Tables(
            EnumMap<ChunkSectionLayer, RenderPipeline[][]> pipelines, RenderPipeline[] depth) {}

    private static RenderPipeline.Builder builder(int slot, boolean direct) {
        var layout = ParametricTerrainQuads.Layout.values()[slot];
        var uniforms =
                BindGroupLayout.builder()
                        .withUniform("VeilFrame", UniformType.UNIFORM_BUFFER)
                        .withUniform(
                                "VeilSections", UniformType.TEXEL_BUFFER, GpuFormat.RGBA32_SINT)
                        .withUniform("VeilQuadWords", UniformType.TEXEL_BUFFER, GpuFormat.R32_SINT);
        if (direct)
            uniforms.withUniform("VeilDrawCommands", UniformType.TEXEL_BUFFER, GpuFormat.R32_SINT);
        var result =
                RenderPipeline.builder()
                        .withBindGroupLayout(BindGroupLayouts.GLOBALS)
                        .withBindGroupLayout(BindGroupLayouts.FOG)
                        .withBindGroupLayout(BindGroupLayouts.SAMPLER0_SAMPLER2)
                        .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                        .withBindGroupLayout(uniforms.build())
                        .withPrimitiveTopology(PrimitiveTopology.QUADS)
                        .withDepthStencilState(DepthStencilState.DEFAULT)
                        .withShaderDefine("VEIL_QUAD_WORDS", layout.stride() / 4)
                        .withVertexShader(id("core/terrain_parametric" + (direct ? "_multi" : "")));
        if (layout.flatColor()) result.withShaderDefine("VEIL_QUAD_FLAT");
        if (layout.halfUv()) result.withShaderDefine("VEIL_QUAD_HALF");
        return result;
    }

    public static Tables create() {
        var pipelines = new EnumMap<ChunkSectionLayer, RenderPipeline[][]>(ChunkSectionLayer.class);
        var depth = new RenderPipeline[4];
        for (var layer : ChunkSectionLayer.values()) {
            if (layer == ChunkSectionLayer.TRANSLUCENT) continue;
            var variants = new RenderPipeline[4][2];
            for (int slot = 0; slot < 4; slot++)
                for (int direct = 0; direct < 2; direct++) {
                    var builder =
                            builder(slot, direct != 0)
                                    .withLocation(
                                            id(
                                                    "pipeline/parametric_"
                                                            + layer.label()
                                                            + "_"
                                                            + slot
                                                            + "_"
                                                            + direct))
                                    .withFragmentShader(id("core/terrain_indirect"))
                                    .withColorTargetState(
                                            layer.pipeline().getColorTargetStates()[0]);
                    if (layer == ChunkSectionLayer.CUTOUT)
                        builder.withShaderDefine("ALPHA_CUTOUT", 0.5f);
                    variants[slot][direct] = builder.build();
                }
            pipelines.put(layer, variants);
        }
        for (int slot = 0; slot < 4; slot++)
            depth[slot] =
                    builder(slot, false)
                            .withLocation(id("pipeline/parametric_depth_" + slot))
                            .withFragmentShader(id("core/depth_only"))
                            .withColorTargetState(
                                    new ColorTargetState(
                                            Optional.empty(),
                                            GpuFormat.RGBA8_UNORM,
                                            ColorTargetState.WRITE_NONE))
                            .build();
        return new Tables(pipelines, depth);
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }
}
