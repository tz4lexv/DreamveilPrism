package dev.veil.revive.client.graphics.minecraft;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.Destroyable;
import com.mojang.blaze3d.vulkan.VulkanDevice;
import com.mojang.blaze3d.vulkan.VulkanQueue;

import dev.veil.revive.mixin.GpuDeviceAccessor;
import dev.veil.revive.mixin.VulkanEncoderAccessor;

import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDevice;

import java.util.Objects;

public class MinecraftVulkanContext {
    private final VulkanDevice device;

    protected MinecraftVulkanContext(VulkanDevice device) {
        this.device = Objects.requireNonNull(device, "device");
    }

    public enum BackendKind {
        PENDING,

        VULKAN,

        OTHER
    }

    public static VulkanDevice currentDeviceOrNull() {
        var gpuDevice = RenderSystem.tryGetDevice();
        if (gpuDevice == null) return null;
        var backend = ((GpuDeviceAccessor) gpuDevice).veil$backend();
        return backend instanceof VulkanDevice vulkan ? vulkan : null;
    }

    public static BackendKind backendKind() {
        var gpuDevice = RenderSystem.tryGetDevice();
        if (gpuDevice == null) return BackendKind.PENDING;
        return ((GpuDeviceAccessor) gpuDevice).veil$backend() instanceof VulkanDevice
                ? BackendKind.VULKAN
                : BackendKind.OTHER;
    }

    public static boolean isCurrentBackend() {
        return backendKind() == BackendKind.VULKAN;
    }

    public static VulkanDevice requireDevice() {
        var gpuDevice = RenderSystem.tryGetDevice();
        if (gpuDevice == null) {
            throw new IllegalStateException(
                    "Veil Vulkan shader runtime requested before Minecraft initialized its graphics device");
        }
        var backend = ((GpuDeviceAccessor) gpuDevice).veil$backend();
        if (!(backend instanceof VulkanDevice vulkan)) {
            throw new IllegalStateException(
                    "Veil Vulkan shader runtime requires Minecraft's Vulkan backend; active backend="
                            + gpuDevice.getDeviceInfo().backendName());
        }
        return vulkan;
    }

    public VulkanDevice device() {
        return device;
    }

    public VkDevice vkDevice() {
        return device.vkDevice();
    }

    public VulkanQueue graphicsQueue() {
        return device.graphicsQueue();
    }

    public VulkanQueue computeQueue() {
        return device.computeQueue();
    }

    public VulkanQueue transferQueue() {
        return device.transferQueue();
    }

    public long vma() {
        return device.vma();
    }

    public VkCommandBuffer commandBuffer() {
        RenderSystem.assertOnRenderThread();
        return ((VulkanEncoderAccessor) device.createCommandEncoder()).veil$commandBuffer();
    }

    public void deferDestroy(Destroyable destruction) {
        RenderSystem.assertOnRenderThread();
        DeferredDestructionAudit.enqueue(device.createCommandEncoder(), destruction);
    }
}
