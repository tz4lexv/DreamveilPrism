package dev.veil.revive.client.shaderpack.runtime;

import static org.lwjgl.vulkan.VK13.vkCmdDispatch;
import static org.lwjgl.vulkan.VK13.vkCmdDispatchIndirect;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.revive.client.VeilShaderPack;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkCommandBuffer;

import java.util.function.Function;

public final class ComputePassExecutor<P> {
    private final Function<P, VeilShaderPack.Pass> definitions;
    private final Function<String, GpuBuffer> buffers;
    private final GraphicsPassExecutor.Binder<P> binder;

    public ComputePassExecutor(
            Function<P, VeilShaderPack.Pass> definitions,
            Function<String, GpuBuffer> buffers,
            GraphicsPassExecutor.Binder<P> binder) {
        this.definitions = definitions;
        this.buffers = buffers;
        this.binder = binder;
    }

    public void execute(P pass, VkCommandBuffer cmd, int width, int height, int[] groups) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            binder.bind(pass, cmd, stack, width, height);
            var dispatch = definitions.apply(pass).dispatch();
            if (dispatch.indirect()) {
                GpuBuffer arguments = buffers.apply(dispatch.indirectResource());
                if (arguments == null)
                    throw new IllegalStateException(
                            "Indirect dispatch buffer unavailable: " + dispatch.indirectResource());
                vkCmdDispatchIndirect(
                        cmd, ((VulkanGpuBuffer) arguments).vkBuffer(), dispatch.indirectOffset());
            } else {
                vkCmdDispatch(cmd, groups[0], groups[1], groups[2]);
            }
        }
    }
}
