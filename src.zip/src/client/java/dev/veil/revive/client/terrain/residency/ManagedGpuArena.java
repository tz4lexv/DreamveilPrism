package dev.veil.revive.client.terrain.residency;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.StagingBuffer;

import dev.veil.revive.client.VeilGpuAllocationJfrProbe;
import dev.veil.revive.core.IncrementalDefragPlanner;
import dev.veil.revive.core.MultiArenaAllocator;
import dev.veil.revive.core.WallClockCadence;
import dev.veil.revive.core.terrain.AttributeUploadPlan;

import org.lwjgl.system.MemoryStack;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.function.Consumer;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

public class ManagedGpuArena<T> implements AutoCloseable {
    private static final boolean BOUNDED_DEFRAG = Boolean.getBoolean("veil.boundedArenaDefrag");
    private static final boolean REUSE_EMPTY_PLANS =
            Boolean.getBoolean("veil.reuseEmptyDefragPlans");
    private final String name;
    private final int usage, heapBytes, alignment, unit;
    private final StagingBuffer staging;
    private final Consumer<RelocationStage> relocationCheckpoint;
    private final LongSupplier maintenanceBudget;
    private final MultiArenaAllocator allocator;
    private final IncrementalDefragPlanner planner = new IncrementalDefragPlanner();
    private final IdentityHashMap<T, Entry<T>> entries = new IdentityHashMap<>();
    private UploadQueue<T> pendingUploads = new UploadQueue<>();
    private UploadQueue<T> uploadScratch = new UploadQueue<>();
    private final HashMap<Long, T> ownerKeys = BOUNDED_DEFRAG ? new HashMap<>() : null;
    private final MultiArenaAllocator.DefragCursor defragCursor =
            new MultiArenaAllocator.DefragCursor();
    private long inspectedAllocations, defragPasses;
    private final ArrayList<GpuBuffer> heaps = new ArrayList<>();
    private final WallClockCadence cadence = new WallClockCadence();
    private GpuBuffer scratch;
    private long movedBytes, moves, capacityRevision;
    private long fullPlans, emptyPlanSkips, emptyPlanBudget;
    private boolean emptyPlanValid;

    protected ManagedGpuArena(
            String name,
            int usage,
            int heapBytes,
            int alignment,
            StagingBuffer staging,
            LongSupplier maintenanceBudget) {
        this(name, usage, heapBytes, alignment, staging, 8, maintenanceBudget);
    }

    protected ManagedGpuArena(
            String name,
            int usage,
            int heapBytes,
            int alignment,
            StagingBuffer staging,
            int maxArenas,
            LongSupplier maintenanceBudget) {
        this(name, usage, heapBytes, alignment, staging, maxArenas, null, maintenanceBudget);
    }

    public enum RelocationStage {
        BEFORE_SCRATCH,
        BEFORE_ENCODER,
        BEFORE_SOURCE_COPY,
        BEFORE_DESTINATION_COPY
    }

    protected ManagedGpuArena(
            String name,
            int usage,
            int heapBytes,
            int alignment,
            StagingBuffer staging,
            int maxArenas,
            Consumer<RelocationStage> relocationCheckpoint,
            LongSupplier maintenanceBudget) {
        this.relocationCheckpoint = relocationCheckpoint;
        this.maintenanceBudget = java.util.Objects.requireNonNull(maintenanceBudget);
        this.name = name;
        this.usage = usage | GpuBuffer.USAGE_COPY_SRC | GpuBuffer.USAGE_COPY_DST;
        this.heapBytes = heapBytes;
        this.unit = (alignment & (alignment - 1)) == 0 ? 1 : alignment;
        this.alignment = unit == 1 ? alignment : 1;
        this.staging = staging;
        allocator = new MultiArenaAllocator(heapBytes / unit, maxArenas);
    }

    public boolean addAllocation(T key, Consumer<T> callback, ByteBuffer data) {
        return tryAddAllocation(key, callback, data.remaining(), () -> data) == Admission.ADDED;
    }

    public enum Admission {
        ADDED,
        CAPACITY,
        STAGING
    }

    public Admission tryAddAllocation(
            T key, Consumer<T> callback, int bytes, Supplier<ByteBuffer> producer) {
        if (bytes <= 0) throw new IllegalArgumentException("bytes <= 0");
        if (entries.containsKey(key)) throw new IllegalStateException("duplicate arena owner");
        var allocation = allocator.allocate((bytes + (long) unit - 1) / unit, alignment);
        if (allocation == null) return Admission.CAPACITY;
        if (REUSE_EMPTY_PLANS) emptyPlanValid = false;
        StagingBuffer.BufferHandle handle = null;
        boolean admitted = false;
        try {
            var data = producer.get();
            if (data.remaining() != bytes)
                throw new IllegalArgumentException("arena producer size changed");
            handle = staging.tryAppend(data);
            if (handle == null) return Admission.STAGING;
            if (entries.containsKey(key)) throw new IllegalStateException("duplicate arena owner");
            while (heaps.size() <= allocation.arenaIndex())
                heaps.add(RenderSystem.getDevice().createBuffer(() -> name, usage, heapBytes));
            var entry = new Entry<T>(key, allocation, callback, handle);
            entries.put(key, entry);
            pendingUploads.add(entry);
            admitted = true;
            if (REUSE_EMPTY_PLANS) emptyPlanValid = false;
            if (ownerKeys != null) ownerKeys.put(allocation.id(), key);
            VeilGpuAllocationJfrProbe.allocated(
                    this,
                    entry,
                    "VEIL_MANAGED",
                    bytes,
                    allocation.size() * unit,
                    allocation.offset() * unit,
                    alignment * unit,
                    allocation.arenaIndex(),
                    heapBytes);
            return Admission.ADDED;
        } finally {
            if (!admitted) {
                if (handle != null) handle.close();
                if (allocator.free(allocation) && REUSE_EMPTY_PLANS) emptyPlanValid = false;
            }
        }
    }

    public long capacityRevision() {
        return capacityRevision;
    }

    public void rekeyAllocation(T previous, T replacement) {
        if (entries.containsKey(replacement))
            throw new IllegalStateException("duplicate arena owner");
        var entry = entries.remove(previous);
        if (entry == null) throw new IllegalStateException("missing arena owner");
        entries.put(replacement, entry);
        entry.key = replacement;
        if (ownerKeys != null) ownerKeys.put(entry.allocation.id(), replacement);
    }

    public Admission tryRestageAllocation(T key, int bytes, Supplier<ByteBuffer> producer) {
        if (bytes <= 0) throw new IllegalArgumentException("bytes <= 0");
        var entry = entries.get(key);
        if (entry == null || bytes > entry.allocation.size() * unit) return Admission.CAPACITY;
        if (entry.busy()) return Admission.STAGING;
        var data = producer.get();
        if (data.remaining() != bytes)
            throw new IllegalArgumentException("arena producer size changed");
        if (entries.get(key) != entry) return Admission.CAPACITY;
        if (entry.busy()) return Admission.STAGING;
        var handle = staging.tryAppend(data);
        if (handle == null) return Admission.STAGING;
        if (entries.get(key) != entry || entry.busy()) {
            handle.close();
            return entries.get(key) != entry ? Admission.CAPACITY : Admission.STAGING;
        }
        entry.pending = handle;
        pendingUploads.add(entry);
        return Admission.ADDED;
    }

    public Admission tryRestageAttributes(T key, AttributeUploadPlan plan) {
        var entry = entries.get(key);
        if (entry == null
                || plan.bufferBytes() > entry.allocation.size() * unit
                || plan.payloadBytes() > 4 << 20
                || plan.rangeCount() > 32) return Admission.CAPACITY;
        if (entry.busy()) return Admission.STAGING;
        if (plan.rangeCount() == 0) return Admission.ADDED;
        int largestRange = 0;
        for (int range = 0; range < plan.rangeCount(); range++)
            largestRange = Math.max(largestRange, plan.size(range));
        var stack = MemoryStack.stackGet();
        if (largestRange <= 4096 && largestRange <= stack.getPointer()) {
            try (var frame = stack.push()) {
                return stageAttributes(entry, plan, frame.malloc(1, largestRange));
            }
        }
        var payload = org.lwjgl.system.MemoryUtil.memAlloc(largestRange);
        try {
            return stageAttributes(entry, plan, payload);
        } finally {
            org.lwjgl.system.MemoryUtil.memFree(payload);
        }
    }

    private Admission stageAttributes(
            Entry<T> entry, AttributeUploadPlan plan, ByteBuffer payload) {
        var patches = new ArrayList<Patch>(plan.rangeCount());
        boolean admitted = false;
        try {
            for (int range = 0; range < plan.rangeCount(); range++) {
                payload.clear().limit(plan.size(range));
                payload.put(plan.payload(range)).flip();
                var handle = staging.tryAppend(payload);
                if (handle == null) return Admission.STAGING;
                boolean retained = false;
                try {
                    patches.add(new Patch(handle, plan.offset(range)));
                    retained = true;
                } finally {
                    if (!retained) handle.close();
                }
            }
            if (entries.get(entry.key) != entry) return Admission.CAPACITY;
            if (entry.busy()) return Admission.STAGING;
            entry.patches = patches;
            pendingUploads.add(entry);
            admitted = true;
            return Admission.ADDED;
        } finally {
            if (!admitted) {
                for (var patch : patches) patch.handle.close();
            }
        }
    }

    private void release(MultiArenaAllocator.Allocation allocation) {
        if (allocator.free(allocation)) {
            if (REUSE_EMPTY_PLANS) emptyPlanValid = false;
            capacityRevision++;
        }
    }

    public boolean uploadStagedAllocations(
            com.mojang.blaze3d.systems.GpuDevice device, StagingBuffer.Uploader uploader) {
        if (pendingUploads.first == null) return false;
        UploadQueue<T> draining = pendingUploads;
        pendingUploads = uploadScratch == null ? new UploadQueue<>() : uploadScratch;
        uploadScratch = null;
        boolean changed = false;
        try {
            while (draining.first != null) {
                Entry<T> entry = draining.first;
                var destination = getGpuBuffer(entry.allocation);
                long offset = entry.allocation.offset() * unit;
                if (entry.pending != null) uploader.copyTo(entry.pending, destination, offset);
                if (entry.patches != null)
                    for (var patch : entry.patches)
                        uploader.copyTo(patch.handle, destination, offset + patch.offset);
                entry.releasePending();
                if (entry.callback != null) entry.callback.accept(entry.key);
                changed = true;
            }
            return changed;
        } finally {
            if (draining.first != null) {
                if (pendingUploads.first == null) {
                    UploadQueue<T> empty = pendingUploads;
                    pendingUploads = draining;
                    draining = empty;
                } else {
                    pendingUploads.prepend(draining);
                }
            }
            if (uploadScratch == null) uploadScratch = draining;
        }
    }

    public MultiArenaAllocator.Allocation getAllocation(T key) {
        Entry<T> entry = entries.get(key);
        if (entry == null || entry.busy()) return null;
        var a = entry.allocation;
        if (unit == 1) return a;
        return new MultiArenaAllocator.Allocation(
                a.id(),
                a.arenaIndex(),
                a.offset() * unit,
                a.size() * unit,
                unit == 1 ? a.alignment() : 4);
    }

    public GpuBuffer getGpuBuffer(MultiArenaAllocator.Allocation allocation) {
        return heaps.get(allocation.arenaIndex());
    }

    public void removeAllocation(T key) {
        Entry<T> entry = entries.remove(key);
        if (entry != null) {
            if (ownerKeys != null) ownerKeys.remove(entry.allocation.id());
            if (entry.queue != null) entry.queue.remove(entry);
            entry.releasePending();
            release(entry.allocation);
            VeilGpuAllocationJfrProbe.freed(this, entry);
        }
    }

    public void maintain() {
        if (!cadence.due(System.nanoTime(), 200_000_000L) || entries.isEmpty()) return;
        long budget = Math.max(16L << 10, Math.min(256L << 10, maintenanceBudget.getAsLong() / 2));
        if (reuseEmptyPlan(budget / unit)) return;
        for (Entry<T> entry : entries.values()) if (entry.busy()) return;
        defragment(budget);
    }

    private boolean reuseEmptyPlan(long allocationBudget) {
        if (REUSE_EMPTY_PLANS
                && !BOUNDED_DEFRAG
                && emptyPlanValid
                && emptyPlanBudget == allocationBudget) {
            emptyPlanSkips++;
            return true;
        }
        return false;
    }

    public void defragment(long budget) {
        long allocationBudget = budget / unit;
        if (reuseEmptyPlan(allocationBudget)) return;
        int performed = 0;
        java.util.List<IncrementalDefragPlanner.Move> planned;
        if (BOUNDED_DEFRAG) {
            var pass = allocator.planDefrag(defragCursor, budget / unit, 2, 256);
            planned = pass.moves();
            inspectedAllocations += pass.inspected();
            defragPasses++;
        } else {
            fullPlans++;
            planned = planner.plan(allocator.liveAllocations(), allocationBudget);
            if (REUSE_EMPTY_PLANS) {
                emptyPlanValid = planned.isEmpty();
                emptyPlanBudget = allocationBudget;
            }
        }
        for (var move : planned) {
            if (performed >= 2) break;
            Entry<T> owner = null;
            T key = null;
            if (ownerKeys != null) {
                key = ownerKeys.get(move.allocationId());
                owner = entries.get(key);
            } else {
                for (var record : entries.entrySet()) {
                    if (record.getValue().allocation.id() == move.allocationId()) {
                        owner = record.getValue();
                        key = record.getKey();
                        break;
                    }
                }
            }
            if (owner == null || owner.busy()) break;
            long bytes = move.bytes() * unit;
            var buffer = getGpuBuffer(owner.allocation);
            MultiArenaAllocator.Allocation relocated;
            try {
                relocated =
                        allocator.relocate(
                                move,
                                () -> {
                                    checkpoint(RelocationStage.BEFORE_SCRATCH);
                                    if (scratch == null || scratch.size() < bytes) {
                                        var replacement =
                                                RenderSystem.getDevice()
                                                        .createBuffer(
                                                                () -> name + " relocation scratch",
                                                                GpuBuffer.USAGE_COPY_SRC
                                                                        | GpuBuffer.USAGE_COPY_DST,
                                                                bytes);
                                        var previous = scratch;
                                        scratch = replacement;
                                        if (previous != null) previous.close();
                                    }
                                    checkpoint(RelocationStage.BEFORE_ENCODER);
                                    var encoder = RenderSystem.getDevice().createCommandEncoder();
                                    checkpoint(RelocationStage.BEFORE_SOURCE_COPY);
                                    encoder.copyToBuffer(
                                            buffer.slice(move.fromOffset() * unit, bytes),
                                            scratch.slice(0, bytes));
                                    checkpoint(RelocationStage.BEFORE_DESTINATION_COPY);
                                    encoder.copyToBuffer(
                                            scratch.slice(0, bytes),
                                            buffer.slice(move.toOffset() * unit, bytes));
                                });
            } catch (RuntimeException | Error failure) {
                defragCursor.reset();
                throw failure;
            }
            if (relocated == null) throw new IllegalStateException("invalid live GPU relocation");
            owner.allocation = relocated;
            if (REUSE_EMPTY_PLANS) emptyPlanValid = false;
            VeilGpuAllocationJfrProbe.moved(
                    this, owner, relocated.offset() * unit, relocated.arenaIndex());
            capacityRevision++;
            if (owner.callback != null) owner.callback.accept(key);
            movedBytes += bytes;
            moves++;
            performed++;
        }
    }

    private void checkpoint(RelocationStage stage) {
        if (relocationCheckpoint != null) relocationCheckpoint.accept(stage);
    }

    public String telemetry() {
        return "arena_defrag_moves_total="
                + moves
                + "\narena_defrag_bytes_total="
                + movedBytes
                + "\narena_defrag_passes_total="
                + defragPasses
                + "\narena_defrag_inspected_total="
                + inspectedAllocations
                + "\narena_defrag_bounded="
                + BOUNDED_DEFRAG
                + "\narena_defrag_full_plans_total="
                + fullPlans
                + "\narena_defrag_empty_plan_skips_total="
                + emptyPlanSkips
                + "\narena_defrag_reuse_empty="
                + REUSE_EMPTY_PLANS
                + "\n";
    }

    @Override
    public void close() {
        if (REUSE_EMPTY_PLANS) emptyPlanValid = false;
        for (Entry<T> entry : entries.values()) entry.releasePending();
        entries.clear();
        VeilGpuAllocationJfrProbe.closed(this);
        if (ownerKeys != null) ownerKeys.clear();
        for (GpuBuffer heap : heaps) heap.close();
        heaps.clear();
        if (scratch != null) scratch.close();
        scratch = null;
    }

    private record Patch(StagingBuffer.BufferHandle handle, long offset) {}

    private static final class UploadQueue<T> {
        Entry<T> first, last;

        void add(Entry<T> entry) {
            if (entry.queue != null) throw new IllegalStateException("upload already queued");
            entry.queue = this;
            entry.previous = last;
            if (last == null) first = entry;
            else last.next = entry;
            last = entry;
        }

        void remove(Entry<T> entry) {
            if (entry.previous == null) first = entry.next;
            else entry.previous.next = entry.next;
            if (entry.next == null) last = entry.previous;
            else entry.next.previous = entry.previous;
            entry.queue = null;
            entry.previous = entry.next = null;
        }

        void prepend(UploadQueue<T> earlier) {
            for (Entry<T> entry = earlier.first; entry != null; entry = entry.next)
                entry.queue = this;
            earlier.last.next = first;
            if (first == null) last = earlier.last;
            else first.previous = earlier.last;
            first = earlier.first;
            earlier.first = earlier.last = null;
        }
    }

    private static final class Entry<T> {
        T key;
        UploadQueue<T> queue;
        Entry<T> previous, next;
        MultiArenaAllocator.Allocation allocation;
        final Consumer<T> callback;
        StagingBuffer.BufferHandle pending;
        ArrayList<Patch> patches;

        boolean busy() {
            return pending != null || patches != null;
        }

        void releasePending() {
            if (pending != null) pending.close();
            pending = null;
            if (patches != null) for (var patch : patches) patch.handle.close();
            patches = null;
            if (queue != null) queue.remove(this);
        }

        Entry(
                T key,
                MultiArenaAllocator.Allocation allocation,
                Consumer<T> callback,
                StagingBuffer.BufferHandle pending) {
            this.key = key;
            this.allocation = allocation;
            this.callback = callback;
            this.pending = pending;
        }
    }
}
