package dev.veil.revive.client.shaderpack.runtime;

import dev.veil.revive.client.VeilHostResourceRegistry;
import dev.veil.revive.client.VeilShaderPack;

public record CreatorSceneRequirements(
        boolean lights, boolean instances, boolean materials, boolean geometry) {
    public boolean capturesEntities() {
        return instances || geometry;
    }

    public static CreatorSceneRequirements from(VeilShaderPack pack) {
        boolean lights = false, instances = false, materials = false, geometry = false;
        for (var resource : pack.resources().values()) {
            String host = resource.hostId();
            if (host == null) continue;
            switch (host) {
                case VeilHostResourceRegistry.CREATOR_LIGHTS,
                        VeilHostResourceRegistry.SHADOW_LIGHTS ->
                        lights = true;
                case VeilHostResourceRegistry.CREATOR_INSTANCES -> instances = true;
                case VeilHostResourceRegistry.CREATOR_MATERIALS -> materials = true;
                case VeilHostResourceRegistry.CREATOR_GEOMETRY -> geometry = true;
                default -> {}
            }
        }
        return new CreatorSceneRequirements(lights, instances, materials, geometry);
    }
}
