package dev.veil.revive.client;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

public final class VeilServerAiCounters {
    private static final Metric SERVER_TICK = new Metric();
    private static final Metric LEVEL_TICK = new Metric();
    private static final Metric ENTITY_TICK = new Metric();
    private static final Metric VILLAGER_ENTITY_TICK = new Metric();
    private static final Metric MOB_AI = new Metric();
    private static final Metric VILLAGER_MOB_AI = new Metric();
    private static final Metric VILLAGER_CUSTOM_AI = new Metric();
    private static final Metric BRAIN = new Metric();
    private static final Metric VILLAGER_BRAIN = new Metric();
    private static final Metric SENSOR = new Metric();
    private static final Metric VILLAGER_SENSOR = new Metric();
    private static final Metric NAVIGATION = new Metric();
    private static final Metric VILLAGER_NAVIGATION = new Metric();
    private static final Metric PATH_CREATE = new Metric();
    private static final Metric VILLAGER_PATH_CREATE = new Metric();

    private VeilServerAiCounters() {}

    public static void serverTick(long ns) {
        SERVER_TICK.add(ns);
    }

    public static void levelTick(long ns) {
        LEVEL_TICK.add(ns);
    }

    public static void entityTick(long ns, boolean villager) {
        ENTITY_TICK.add(ns);
        if (villager) VILLAGER_ENTITY_TICK.add(ns);
    }

    public static void mobAi(long ns, boolean villager) {
        MOB_AI.add(ns);
        if (villager) VILLAGER_MOB_AI.add(ns);
    }

    public static void villagerCustomAi(long ns) {
        VILLAGER_CUSTOM_AI.add(ns);
    }

    public static void brain(long ns, boolean villager) {
        BRAIN.add(ns);
        if (villager) VILLAGER_BRAIN.add(ns);
    }

    public static void sensor(long ns, boolean villager) {
        SENSOR.add(ns);
        if (villager) VILLAGER_SENSOR.add(ns);
    }

    public static void navigation(long ns, boolean villager) {
        NAVIGATION.add(ns);
        if (villager) VILLAGER_NAVIGATION.add(ns);
    }

    public static void pathCreate(long ns, boolean villager) {
        PATH_CREATE.add(ns);
        if (villager) VILLAGER_PATH_CREATE.add(ns);
    }

    public static void reset() {
        SERVER_TICK.reset();
        LEVEL_TICK.reset();
        ENTITY_TICK.reset();
        VILLAGER_ENTITY_TICK.reset();
        MOB_AI.reset();
        VILLAGER_MOB_AI.reset();
        VILLAGER_CUSTOM_AI.reset();
        BRAIN.reset();
        VILLAGER_BRAIN.reset();
        SENSOR.reset();
        VILLAGER_SENSOR.reset();
        NAVIGATION.reset();
        VILLAGER_NAVIGATION.reset();
        PATH_CREATE.reset();
        VILLAGER_PATH_CREATE.reset();
    }

    public static Snapshot snapshot() {
        return new Snapshot(
                SERVER_TICK.snapshot(),
                LEVEL_TICK.snapshot(),
                ENTITY_TICK.snapshot(),
                VILLAGER_ENTITY_TICK.snapshot(),
                MOB_AI.snapshot(),
                VILLAGER_MOB_AI.snapshot(),
                VILLAGER_CUSTOM_AI.snapshot(),
                BRAIN.snapshot(),
                VILLAGER_BRAIN.snapshot(),
                SENSOR.snapshot(),
                VILLAGER_SENSOR.snapshot(),
                NAVIGATION.snapshot(),
                VILLAGER_NAVIGATION.snapshot(),
                PATH_CREATE.snapshot(),
                VILLAGER_PATH_CREATE.snapshot());
    }

    public record MetricSnapshot(long calls, long ns, long maxNs) {
        public MetricSnapshot minus(MetricSnapshot before) {
            return new MetricSnapshot(calls - before.calls, ns - before.ns, maxNs);
        }

        public MetricSnapshot plus(MetricSnapshot other) {
            return new MetricSnapshot(
                    calls + other.calls, ns + other.ns, Math.max(maxNs, other.maxNs));
        }

        public double totalMs() {
            return ns / 1_000_000.0;
        }

        public double averageMs() {
            return calls == 0L ? 0.0 : totalMs() / calls;
        }

        public double averageUs() {
            return calls == 0L ? 0.0 : (ns / 1_000.0) / calls;
        }

        public double maxMs() {
            return maxNs / 1_000_000.0;
        }
    }

    public record Snapshot(
            MetricSnapshot serverTick,
            MetricSnapshot levelTick,
            MetricSnapshot entityTick,
            MetricSnapshot villagerEntityTick,
            MetricSnapshot mobAi,
            MetricSnapshot villagerMobAi,
            MetricSnapshot villagerCustomAi,
            MetricSnapshot brain,
            MetricSnapshot villagerBrain,
            MetricSnapshot sensor,
            MetricSnapshot villagerSensor,
            MetricSnapshot navigation,
            MetricSnapshot villagerNavigation,
            MetricSnapshot pathCreate,
            MetricSnapshot villagerPathCreate) {

        public Snapshot minus(Snapshot before) {
            return new Snapshot(
                    serverTick.minus(before.serverTick),
                    levelTick.minus(before.levelTick),
                    entityTick.minus(before.entityTick),
                    villagerEntityTick.minus(before.villagerEntityTick),
                    mobAi.minus(before.mobAi),
                    villagerMobAi.minus(before.villagerMobAi),
                    villagerCustomAi.minus(before.villagerCustomAi),
                    brain.minus(before.brain),
                    villagerBrain.minus(before.villagerBrain),
                    sensor.minus(before.sensor),
                    villagerSensor.minus(before.villagerSensor),
                    navigation.minus(before.navigation),
                    villagerNavigation.minus(before.villagerNavigation),
                    pathCreate.minus(before.pathCreate),
                    villagerPathCreate.minus(before.villagerPathCreate));
        }

        public Snapshot plus(Snapshot other) {
            return new Snapshot(
                    serverTick.plus(other.serverTick),
                    levelTick.plus(other.levelTick),
                    entityTick.plus(other.entityTick),
                    villagerEntityTick.plus(other.villagerEntityTick),
                    mobAi.plus(other.mobAi),
                    villagerMobAi.plus(other.villagerMobAi),
                    villagerCustomAi.plus(other.villagerCustomAi),
                    brain.plus(other.brain),
                    villagerBrain.plus(other.villagerBrain),
                    sensor.plus(other.sensor),
                    villagerSensor.plus(other.villagerSensor),
                    navigation.plus(other.navigation),
                    villagerNavigation.plus(other.villagerNavigation),
                    pathCreate.plus(other.pathCreate),
                    villagerPathCreate.plus(other.villagerPathCreate));
        }
    }

    private static final class Metric {
        private final LongAdder calls = new LongAdder();
        private final LongAdder ns = new LongAdder();
        private final AtomicLong maxNs = new AtomicLong();

        void add(long elapsedNs) {
            if (elapsedNs <= 0L) return;
            calls.increment();
            ns.add(elapsedNs);
            long current = maxNs.get();
            while (elapsedNs > current && !maxNs.compareAndSet(current, elapsedNs))
                current = maxNs.get();
        }

        void reset() {
            calls.reset();
            ns.reset();
            maxNs.set(0L);
        }

        MetricSnapshot snapshot() {
            return new MetricSnapshot(calls.sum(), ns.sum(), maxNs.get());
        }
    }
}
