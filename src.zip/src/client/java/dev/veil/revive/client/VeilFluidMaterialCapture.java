package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.veil.revive.client.scene.materials.FluidMaterialCapture;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.world.level.material.FluidState;

public final class VeilFluidMaterialCapture {
    private VeilFluidMaterialCapture() {}

    public static void beginSectionCompile() {
        FluidMaterialCapture.beginSectionCompile();
    }

    public static VeilMaterialRange[] endSectionCompile(SectionCompiler.Results results) {
        return FluidMaterialCapture.endSectionCompile(results);
    }

    public static void beginFluid(FluidState state) {
        FluidMaterialCapture.beginFluid(state);
    }

    static void beginMaterial(int materialId) {
        FluidMaterialCapture.beginMaterial(materialId);
    }

    public static VertexConsumer wrapBuilder(ChunkSectionLayer layer, VertexConsumer consumer) {
        return FluidMaterialCapture.wrapBuilder(layer, consumer);
    }

    public static void endFluid() {
        FluidMaterialCapture.endFluid();
    }

    public static long resolvedGroups() {
        return FluidMaterialCapture.resolvedGroups();
    }

    public static long unresolvedGroups() {
        return FluidMaterialCapture.unresolvedGroups();
    }
}
