package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

public final class VeilWorldHistoryGpuProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.modularWorldHistoryProbe");
    private static Object world, device;
    private static VeilShaderPackRuntime generation;
    private static int phase = -1, ordinal, verified;
    private static long resetSerial, started;
    private static boolean failed;
    private static final boolean CONTRACTS = Boolean.getBoolean("veil.graphicsContractsProbe");
    private static int verifiedContracts;

    private VeilWorldHistoryGpuProbe() {}

    public static boolean enabled() {
        return ENABLED;
    }

    public static boolean verified(Object currentWorld) {
        return !ENABLED
                || (!failed
                        && world == currentWorld
                        && verified == 7
                        && PbrMipGpuProbe.verified(currentWorld)
                        && (!CONTRACTS || verifiedContracts == 15));
    }

    static void checkTimeout(boolean executionFailed) {
        if (!ENABLED || failed || PbrReloadGpuProbe.started()) return;
        long now = System.nanoTime();
        if (started == 0) started = now;
        if (executionFailed || now - started > 180_000_000_000L) fail("runtime/readback timeout");
    }

    static void before(VeilShaderPackRuntime active, Object currentWorld, boolean cut) {
        if (!ENABLED || failed || PbrReloadGpuProbe.started()) return;
        Object currentDevice =
                dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext
                        .currentDeviceOrNull();
        if (generation == null) {
            generation = active;
            device = currentDevice;
        }
        if (generation != active || device == null || device != currentDevice)
            throw new IllegalStateException("World history changed runtime/device");
        if (world != currentWorld) {
            world = currentWorld;
            phase++;
            ordinal = 0;
            verified = 0;
            verifiedContracts = 0;
            resetSerial++;
            if (!cut) throw new IllegalStateException("New world did not invalidate history");
        } else if (cut) {
            ordinal = 0;
            verified = 0;
            verifiedContracts = 0;
            resetSerial++;
        } else ordinal++;
        if (ordinal <= 2 && active.historyValid() != (ordinal == 2))
            throw new IllegalStateException("World history warmup exposed stale frames");
    }

    static void after(VeilShaderPackRuntime active) {
        if (!ENABLED || failed || ordinal > 2 || PbrReloadGpuProbe.started()) return;
        if (CONTRACTS && ordinal == 0) verifyContracts(active);
        int frame = ordinal, capturedPhase = phase;
        long serial = resetSerial;
        int red = frame == 2 ? 0 : 255, green = frame == 2 ? 255 : 0;
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil world history readback",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                4);
        try {
            active.readOutput(
                    "output",
                    readback,
                    () -> {
                        try (var mapped = readback.map(true, false)) {
                            var bytes = mapped.data();
                            if (Byte.toUnsignedInt(bytes.get(0)) != red
                                    || Byte.toUnsignedInt(bytes.get(1)) != green
                                    || Byte.toUnsignedInt(bytes.get(2)) != 0
                                    || Byte.toUnsignedInt(bytes.get(3)) != 255)
                                throw new IllegalStateException("Unexpected world history pixel");
                            if (serial == resetSerial) {
                                verified |= 1 << frame;
                                ReviveMod.LOGGER.info(
                                        "Veil world history readback: phase={} offset={} rgba={},{},0,255 same_runtime=true same_device=true",
                                        capturedPhase,
                                        frame,
                                        red,
                                        green);
                                if (verified == 7)
                                    ReviveMod.LOGGER.info(
                                            "Veil world history phase: PASS phase={}",
                                            capturedPhase);
                            }
                        } catch (RuntimeException problem) {
                            fail(problem.getMessage());
                        } finally {
                            readback.close();
                        }
                    });
        } catch (RuntimeException | Error problem) {
            readback.close();
            throw problem;
        }
    }

    private static void fail(String reason) {
        failed = true;
        ReviveMod.LOGGER.error("Veil world history GPU: FAIL ({})", reason);
        Minecraft.getInstance().stop();
    }

    private static void verifyContracts(VeilShaderPackRuntime active) {
        var dimension =
                dev.veil.revive.client.scene.environment.DimensionMetadata.of(
                        Minecraft.getInstance().level.dimension().identifier().toString());
        var publicFeatures = dev.veil.api.VeilGraphicsCapabilities.rasterFeatures();
        var expectedFeatures = java.util.EnumSet.noneOf(dev.veil.api.graphics.RasterFeature.class);
        for (var feature :
                dev.veil.revive.client.graphics.minecraft.EnabledRasterFeatures.Feature.values())
            if (dev.veil.revive.client.graphics.minecraft.EnabledRasterFeatures
                    .enabledOnCurrentDevice(feature))
                expectedFeatures.add(dev.veil.api.graphics.RasterFeature.valueOf(feature.name()));
        if (!publicFeatures.equals(expectedFeatures))
            throw new IllegalStateException("Public raster capabilities differ from live device");
        ReviveMod.LOGGER.info("Veil public raster capabilities: PASS features={}", publicFeatures);
        String[] outputs = {"dimensionProof", "pbrEmptyProof", "pbrOverflowProof", "pbrValidProof"};
        long serial = resetSerial;
        int capturedPhase = phase;
        for (int index = 0; index < outputs.length; index++) {
            String output = outputs[index];
            int bit = 1 << index;
            int red = index == 0 ? dimension.kind() : 0;
            int green = index == 0 ? dimension.identifierHash() & 255 : 255;
            int blue = index == 0 ? dimension.identifierHash() >>> 8 & 255 : 0;
            var readback =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil graphics contract readback",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    4);
            try {
                active.readOutput(
                        output,
                        readback,
                        () -> {
                            try (var mapped = readback.map(true, false)) {
                                var bytes = mapped.data();
                                if (Byte.toUnsignedInt(bytes.get(0)) != red
                                        || Byte.toUnsignedInt(bytes.get(1)) != green
                                        || Byte.toUnsignedInt(bytes.get(2)) != blue
                                        || Byte.toUnsignedInt(bytes.get(3)) != 255)
                                    throw new IllegalStateException(
                                            "Unexpected graphics contract pixel: " + output);
                                if (serial == resetSerial) {
                                    verifiedContracts |= bit;
                                    ReviveMod.LOGGER.info(
                                            "Veil graphics contract readback: PASS phase={} output={} rgba={},{},{},255",
                                            capturedPhase,
                                            output,
                                            red,
                                            green,
                                            blue);
                                }
                            } catch (RuntimeException problem) {
                                fail(problem.getMessage());
                            } finally {
                                readback.close();
                            }
                        });
            } catch (RuntimeException | Error problem) {
                readback.close();
                throw problem;
            }
        }
    }
}
