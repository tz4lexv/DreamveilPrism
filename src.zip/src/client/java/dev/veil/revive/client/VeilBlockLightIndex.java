package dev.veil.revive.client;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.function.LongPredicate;

final class VeilBlockLightIndex<T> {
    private final LinkedHashMap<Long, T> active = new LinkedHashMap<>();
    private final LinkedHashMap<Long, T> scanning = new LinkedHashMap<>();

    void changed(long position, T light) {
        update(active, position, light);
        update(scanning, position, light);
    }

    void observed(long position, T light) {
        update(scanning, position, light);
    }

    void beginScan(LongPredicate retained) {
        active.keySet().removeIf(position -> !retained.test(position));
        scanning.clear();
    }

    void completeScan() {
        active.clear();
        active.putAll(scanning);
        scanning.clear();
    }

    List<T> snapshot() {
        return List.copyOf(active.values());
    }

    void clear() {
        active.clear();
        scanning.clear();
    }

    private static <T> void update(LinkedHashMap<Long, T> values, long position, T light) {
        if (light == null) values.remove(position);
        else values.put(position, light);
    }
}
