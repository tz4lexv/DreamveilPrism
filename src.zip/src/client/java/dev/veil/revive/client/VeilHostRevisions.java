package dev.veil.revive.client;

import java.util.concurrent.atomic.AtomicLong;

public final class VeilHostRevisions {
    private static final AtomicLong VISIBILITY = new AtomicLong(1L);
    private static final AtomicLong MESH = new AtomicLong(1L);
    private static final AtomicLong ORIGIN = new AtomicLong(1L);
    private static final AtomicLong GLOBAL = new AtomicLong(1L);

    private VeilHostRevisions() {}

    public static void visibilityChanged() {
        VISIBILITY.incrementAndGet();
    }

    public static void meshChanged() {
        MESH.incrementAndGet();
        VeilSectionChanges.changed(null);
    }

    public static void meshChanged(
            net.minecraft.client.renderer.chunk.SectionRenderDispatcher.RenderSection section) {
        MESH.incrementAndGet();
        VeilSectionChanges.changed(section);
    }

    public static void sectionRelocated() {
        ORIGIN.incrementAndGet();
        VeilSectionChanges.changed(null);
    }

    public static void sectionRelocated(
            net.minecraft.client.renderer.chunk.SectionRenderDispatcher.RenderSection section) {
        ORIGIN.incrementAndGet();
        VeilSectionChanges.changed(section);
    }

    public static void invalidateAll() {
        VeilSectionChanges.changed(null);
        GLOBAL.incrementAndGet();
        VISIBILITY.incrementAndGet();
        MESH.incrementAndGet();
        ORIGIN.incrementAndGet();
    }

    public static long visibility() {
        return VISIBILITY.get();
    }

    public static long mesh() {
        return MESH.get();
    }

    public static long origin() {
        return ORIGIN.get();
    }

    public static long global() {
        return GLOBAL.get();
    }
}
