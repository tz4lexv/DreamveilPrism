package dev.veil.revive.client;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

import org.lwjgl.glfw.GLFW;

public final class VeilControls {
    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("veil", "diagnostics"));

    private static final KeyMapping BYPASS =
            new KeyMapping(
                    "key.veil.bypass", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F8, CATEGORY);

    private static final KeyMapping BENCHMARK =
            new KeyMapping(
                    "key.veil.benchmark", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F9, CATEGORY);

    private static final KeyMapping DETAILS =
            new KeyMapping(
                    "key.veil.details", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F10, CATEGORY);

    private VeilControls() {}

    public static java.util.List<KeyMapping> mappings() {
        return java.util.List.of(BYPASS, BENCHMARK, DETAILS);
    }

    public static KeyMapping.Category category() {
        return CATEGORY;
    }

    public static void handleTick(net.minecraft.client.Minecraft client) {
        while (BYPASS.consumeClick()) VeilDiagnostics.toggleBypass(client);
        while (BENCHMARK.consumeClick()) {
            if (VeilDiagnostics.benchmarkActive()) VeilDiagnostics.cancelBenchmark(client);
            else VeilDiagnostics.startBenchmark(client);
        }
        while (DETAILS.consumeClick()) VeilDiagnostics.toggleDetailedOverlay(client);
    }
}
