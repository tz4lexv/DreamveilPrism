package dev.veil.revive.client.diagnostics;

import com.mojang.blaze3d.buffers.GpuBuffer;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.BitSet;

public final class TerrainAttributeReadback {
    private TerrainAttributeReadback() {}

    public static void verify(
            ByteBuffer original,
            GpuBuffer[] readbacks,
            int width,
            int height,
            int mode,
            String context) {
        ByteBuffer source = original.slice().order(original.order());
        if (source.remaining() % 28 != 0)
            throw new IllegalArgumentException("Invalid canonical attributes");
        int count = source.remaining() / 28, pixels = width * height;
        BitSet seen = new BitSet(count);
        String positionContext = context + " position", uvContext = context + " UV/light";
        try (var a = readbacks[0].map(true, false);
                var b = readbacks[1].map(true, false);
                var c = readbacks[2].map(true, false)) {
            ByteBuffer positions = a.data().order(ByteOrder.LITTLE_ENDIAN);
            ByteBuffer uvLight = b.data().order(ByteOrder.LITTLE_ENDIAN), colors = c.data();
            int floatOffset = mode * pixels * 16, colorOffset = mode * pixels * 4;
            for (int pixel = 0; pixel < pixels; pixel++) {
                int at = floatOffset + pixel * 16;
                float marker = positions.getFloat(at + 12);
                if (marker == 0) continue;
                int vertex = (int) marker - 1;
                if (vertex < 0 || vertex >= count || marker != vertex + 1f || seen.get(vertex))
                    throw new IllegalStateException(
                            context + " invalid marker=" + marker + " pixel=" + pixel);
                seen.set(vertex);
                int src = vertex * 28;
                for (int axis = 0; axis < 3; axis++)
                    exact(
                            source.getFloat(src + axis * 4),
                            positions.getFloat(at + axis * 4),
                            vertex,
                            positionContext);
                for (int channel = 0; channel < 4; channel++) {
                    if (source.get(src + 12 + channel)
                            != colors.get(colorOffset + pixel * 4 + channel))
                        throw new IllegalStateException(
                                context + " color mismatch vertex=" + vertex);
                    float expected =
                            channel < 2
                                    ? source.getFloat(src + 16 + channel * 4)
                                    : source.getShort(src + 24 + (channel - 2) * 2);
                    exact(expected, uvLight.getFloat(at + channel * 4), vertex, uvContext);
                }
            }
        }
        if (seen.cardinality() != count)
            throw new IllegalStateException(
                    context + " coverage=" + seen.cardinality() + "/" + count);
    }

    private static void exact(float expected, float actual, int vertex, String context) {
        if (Float.floatToRawIntBits(expected) != Float.floatToRawIntBits(actual))
            throw new IllegalStateException(
                    context + " vertex=" + vertex + " expected=" + expected + " actual=" + actual);
    }
}
