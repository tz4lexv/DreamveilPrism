package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

final class VeilResidentRetirementProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.residentRetirementProbe");
    private static boolean injected, fallbackDetected, recovered;

    private VeilResidentRetirementProbe() {}

    static boolean shouldInject(int commands) {
        return ENABLED && !injected && commands >= 64;
    }

    static void injected() {
        injected = true;
        ReviveMod.LOGGER.info(
                "Veil resident retirement probe: injected obsolete active packet node");
    }

    static void fallbackDetected() {
        if (ENABLED && injected) fallbackDetected = true;
    }

    static void recovered() {
        if (!ENABLED || !fallbackDetected || recovered) return;
        recovered = true;
        ReviveMod.LOGGER.info(
                "Veil resident retirement probe: PASS (obsolete active packet triggered native fallback and resident registry recovered)");
    }

    static void requireComplete() {
        if (ENABLED && (!injected || !fallbackDetected || !recovered))
            throw new IllegalStateException("Resident retirement fallback probe incomplete");
    }
}
