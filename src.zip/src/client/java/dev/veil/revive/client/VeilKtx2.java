package dev.veil.revive.client;

final class VeilKtx2 {
    private VeilKtx2() {}

    static byte[] decode(VeilShaderPack.Resource resource, byte[] file) {
        return dev.veil.revive.client.shaderpack.preparation.Ktx2Decoder.decode(
                resource, file, VeilVulkanFormats.vk(resource.format()));
    }
}
