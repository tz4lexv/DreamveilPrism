package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

import java.util.EnumMap;

final class VeilRegularTerrainPipelines {
    private static final EnumMap<ChunkSectionLayer, RenderPipeline[][]> PIPELINES =
            new EnumMap<>(ChunkSectionLayer.class);
    private static final RenderPipeline[] DEPTH = new RenderPipeline[3];
    private static Object validatedDevice;
    private static boolean validatedDirect;

    private VeilRegularTerrainPipelines() {}

    static VertexFormat format(int stride) {
        return dev.veil.revive.client.terrain.indirect.RegularPipelineFactory.format(stride);
    }

    static VertexFormat formatForSlot(int slot) {
        return dev.veil.revive.client.terrain.indirect.RegularPipelineFactory.formatForSlot(slot);
    }

    static void initialize() {
        if (!PIPELINES.isEmpty()) return;
        var tables = dev.veil.revive.client.terrain.indirect.RegularPipelineFactory.create();
        PIPELINES.putAll(tables.pipelines());
        System.arraycopy(tables.depth(), 0, DEPTH, 0, DEPTH.length);
    }

    static void validate(boolean directAvailable) {
        if (!VeilRegularPackedTerrain.enabled()
                || (validatedDevice == RenderSystem.getDevice()
                        && (!directAvailable || validatedDirect))) return;
        initialize();
        boolean valid = true;
        for (var variants : PIPELINES.values())
            for (var formats : variants)
                for (int d = 0; d < 2; d++)
                    if (d == 0 || directAvailable)
                        valid &= RenderSystem.getDevice().precompilePipeline(formats[d]).isValid();
        for (var pipeline : DEPTH)
            valid &= RenderSystem.getDevice().precompilePipeline(pipeline).isValid();
        if (!valid) {
            VeilRegularPackedTerrain.disable();
            dev.veil.revive.ReviveMod.LOGGER.warn(
                    "Regular compact terrain pipelines unavailable; retaining canonical terrain");
        }
        validatedDevice = RenderSystem.getDevice();
        validatedDirect = directAvailable;
    }

    static RenderPipeline select(
            GpuBuffer vertices, ChunkSectionLayer layer, boolean direct, RenderPipeline fallback) {
        int parametric = VeilParametricTerrainArena.formatSlot(vertices);
        if (parametric >= 0)
            return VeilParametricTerrainPipelines.select(parametric, layer, direct);
        int slot = VeilRegularPackedTerrain.formatSlot(vertices);
        return slot < 0 ? fallback : PIPELINES.get(layer)[slot][direct ? 1 : 0];
    }

    static RenderPipeline depth(GpuBuffer vertices, RenderPipeline fallback) {
        int parametric = VeilParametricTerrainArena.formatSlot(vertices);
        if (parametric >= 0) return VeilParametricTerrainPipelines.depth(parametric);
        int slot = VeilRegularPackedTerrain.formatSlot(vertices);
        return slot < 0 ? fallback : DEPTH[slot];
    }
}
