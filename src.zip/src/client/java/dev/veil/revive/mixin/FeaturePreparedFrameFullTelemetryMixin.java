package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.renderer.feature.FeatureRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(FeatureRenderDispatcher.PreparedFrame.class)
public abstract class FeaturePreparedFrameFullTelemetryMixin {
    @Unique private VeilFullFrameTelemetry.CpuZone veil$featureZone;

    @Inject(method = "executeSolid", at = @At("HEAD"), require = 0)
    private void veil$solidStart(CallbackInfo ci) {
        veil$begin(VeilFullFrameTelemetry.CpuZone.FEATURE_SOLID);
    }

    @Inject(method = "executeSolid", at = @At("RETURN"), require = 0)
    private void veil$solidEnd(CallbackInfo ci) {
        veil$end();
    }

    @Inject(
            method = {"executeTranslucent", "executeTranslucentAfterTerrain"},
            at = @At("HEAD"),
            require = 0)
    private void veil$translucentStart(CallbackInfo ci) {
        veil$begin(VeilFullFrameTelemetry.CpuZone.FEATURE_TRANSLUCENT);
    }

    @Inject(
            method = {"executeTranslucent", "executeTranslucentAfterTerrain"},
            at = @At("RETURN"),
            require = 0)
    private void veil$translucentEnd(CallbackInfo ci) {
        veil$end();
    }

    @Inject(
            method = {"executeOutline", "executeAlwaysOnTop"},
            at = @At("HEAD"),
            require = 0)
    private void veil$otherStart(CallbackInfo ci) {
        veil$begin(VeilFullFrameTelemetry.CpuZone.FEATURE_OTHER);
    }

    @Inject(
            method = {"executeOutline", "executeAlwaysOnTop"},
            at = @At("RETURN"),
            require = 0)
    private void veil$otherEnd(CallbackInfo ci) {
        veil$end();
    }

    @Unique
    private void veil$begin(VeilFullFrameTelemetry.CpuZone zone) {
        this.veil$featureZone = zone;
        VeilFullFrameTelemetry.beginCpu(zone);
    }

    @Unique
    private void veil$end() {
        if (this.veil$featureZone != null) VeilFullFrameTelemetry.endCpu(this.veil$featureZone);
        this.veil$featureZone = null;
    }
}
