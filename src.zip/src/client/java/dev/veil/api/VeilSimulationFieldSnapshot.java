package dev.veil.api;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;

/**
 * A format-neutral CPU checkpoint for a tightly packed 1D/2D/3D creator-defined field. It is not a
 * Vulkan image and does not perform asynchronous GPU readback or upload.
 */
public final class VeilSimulationFieldSnapshot {
    private static final int MAGIC = 0x56534631; // VSF1
    private static final int VERSION = 1;
    private static final int HEADER_BYTES = Integer.BYTES * 9;

    public enum ScalarType {
        UINT8(1, 1),
        UINT16(2, 2),
        FLOAT16(3, 2),
        UINT32(4, 4),
        FLOAT32(5, 4);

        private final int wireId;
        private final int bytes;

        ScalarType(int wireId, int bytes) {
            this.wireId = wireId;
            this.bytes = bytes;
        }

        public int bytes() {
            return bytes;
        }

        public int wireId() {
            return wireId;
        }

        static ScalarType fromWireId(int wireId) throws IOException {
            for (ScalarType type : values()) {
                if (type.wireId == wireId) return type;
            }
            throw new IOException("Unknown field scalar type: " + wireId);
        }
    }

    private final int width;
    private final int height;
    private final int depth;
    private final int components;
    private final ScalarType type;
    private final byte[] pixels;

    public VeilSimulationFieldSnapshot(
            int width, int height, int depth, int components, ScalarType type, byte[] pixels) {
        this.type = Objects.requireNonNull(type, "type");
        Objects.requireNonNull(pixels, "pixels");
        if (width < 1 || height < 1 || depth < 1 || components < 1 || components > 4)
            throw new IllegalArgumentException(
                    "Field extent/components must be positive (1-4 components)");
        long expected;
        try {
            expected =
                    Math.multiplyExact(
                            Math.multiplyExact(Math.multiplyExact((long) width, height), depth),
                            (long) components * type.bytes());
        } catch (ArithmeticException overflow) {
            throw new IllegalArgumentException(
                    "Field dimensions overflow addressable storage", overflow);
        }
        if (expected > Integer.MAX_VALUE || expected != pixels.length)
            throw new IllegalArgumentException("Field dimensions do not match tightly packed data");
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.components = components;
        this.pixels = pixels.clone();
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    public int depth() {
        return depth;
    }

    public int components() {
        return components;
    }

    public ScalarType type() {
        return type;
    }

    public byte[] pixels() {
        return pixels.clone();
    }

    /** Read-only bytes in little-endian component order; safe to pass to staging preparation. */
    public ByteBuffer data() {
        return ByteBuffer.wrap(pixels).asReadOnlyBuffer().order(ByteOrder.LITTLE_ENDIAN);
    }

    /** Portable CPU field encoding. No Vulkan resource is read or created here. */
    public byte[] encode() {
        ByteBuffer encoded =
                ByteBuffer.allocate(HEADER_BYTES + pixels.length).order(ByteOrder.LITTLE_ENDIAN);
        encoded.putInt(MAGIC).putInt(VERSION).putInt(width).putInt(height).putInt(depth);
        encoded.putInt(components).putInt(type.wireId()).putInt(pixels.length).putInt(0);
        encoded.put(pixels);
        return encoded.array();
    }

    /** Validates the entire payload before constructing a field; never accepts trailing bytes. */
    public static VeilSimulationFieldSnapshot decode(byte[] bytes) throws IOException {
        Objects.requireNonNull(bytes, "bytes");
        if (bytes.length < HEADER_BYTES) throw new IOException("Truncated field metadata");
        ByteBuffer data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        int magic = data.getInt();
        int version = data.getInt();
        int width = data.getInt();
        int height = data.getInt();
        int depth = data.getInt();
        int components = data.getInt();
        int typeId = data.getInt();
        int dataBytes = data.getInt();
        int reserved = data.getInt();
        if (magic != MAGIC
                || version != VERSION
                || reserved != 0
                || dataBytes < 0
                || dataBytes != bytes.length - HEADER_BYTES)
            throw new IOException("Unsupported or malformed field metadata");
        try {
            return new VeilSimulationFieldSnapshot(
                    width,
                    height,
                    depth,
                    components,
                    ScalarType.fromWireId(typeId),
                    Arrays.copyOfRange(bytes, HEADER_BYTES, bytes.length));
        } catch (IllegalArgumentException invalid) {
            throw new IOException("Invalid simulation field dimensions", invalid);
        }
    }

    /** Persist metadata alongside field values; the store supplies checksum and isolation. */
    public void save(VeilSimulationStateStore store, String worldId, String packId, String stateId)
            throws IOException {
        Objects.requireNonNull(store, "store");
        if ((long) pixels.length + HEADER_BYTES > store.maxSnapshotBytes())
            throw new IllegalArgumentException("Field exceeds the configured snapshot budget");
        store.save(worldId, packId, stateId, encode());
    }

    /** A malformed payload is rejected, never partially restored. */
    public static Optional<VeilSimulationFieldSnapshot> load(
            VeilSimulationStateStore store, String worldId, String packId, String stateId)
            throws IOException {
        Objects.requireNonNull(store, "store");
        var loaded = store.load(worldId, packId, stateId);
        if (loaded.isEmpty()) return Optional.empty();
        return Optional.of(decode(loaded.get()));
    }
}
