package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;

import net.minecraft.client.Minecraft;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftFrameLatencyMixin {
    @Inject(method = "runTick(Z)V", at = @At("HEAD"), require = 1)
    private void veil$beforeClientFrame(boolean tick, CallbackInfo ci) {
        ReviveRuntime.onClientFrameStart();
    }

    @Inject(method = "runTick(Z)V", at = @At("RETURN"), require = 1)
    private void veil$afterClientFrame(boolean tick, CallbackInfo ci) {
        ReviveRuntime.onClientFrameEnd();
    }
}
