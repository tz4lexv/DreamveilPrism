package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderPassDescriptor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.terrain.RegularTerrainVertices;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.resources.Identifier;

import org.joml.Vector4f;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.BitSet;
import java.util.Optional;

final class VeilRegularPackedGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.regularPackedGpuProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final int NATIVE_COUNT = 100_000,
            COUNT = NATIVE_COUNT + 32,
            WIDTH = 512,
            HEIGHT = 256;
    private static final int SLOT = Integer.getInteger("veil.regularPackedGpuSlot", 2);
    private static byte[] original, packed;
    private static volatile int captured;
    private static boolean started, complete;
    private static final GpuTexture[] targets = new GpuTexture[3];
    private static final GpuTextureView[] views = new GpuTextureView[3];
    private static final GpuBuffer[] readbacks = new GpuBuffer[3];
    private static GpuBuffer vertices, vertexReadback;
    private static GpuFence fence;

    private VeilRegularPackedGpuProbe() {}

    static void capture(ByteBuffer source, RegularTerrainVertices.Result result) {
        if (!ENABLED || captured >= NATIVE_COUNT || result.layout().ordinal() != SLOT) return;
        captureNative(source, result);
    }

    private static synchronized void captureNative(
            ByteBuffer source, RegularTerrainVertices.Result result) {
        int count = Math.min(result.vertexCount(), NATIVE_COUNT - captured);
        if (count == 0) return;
        if (original == null) {
            original = new byte[COUNT * 28];
            packed = new byte[COUNT * result.stride()];
        }
        source.get(source.position(), original, captured * 28, count * 28);
        System.arraycopy(
                result.vertices(), 0, packed, captured * result.stride(), count * result.stride());
        captured += count;
    }

    static void tick() {
        if (!ENABLED || complete || captured < NATIVE_COUNT) return;
        if (!started) {
            started = true;
            try {
                appendBoundaries();
                start();
            } catch (RuntimeException | Error failure) {
                close();
                throw failure;
            }
        } else if (fence.awaitCompletion(0)) {
            try {
                verifyReadback();
                complete = true;
                ReviveMod.LOGGER.info(
                        "Veil regular packed GPU attributes: PASS (100000 native vertices + 32 boundary vertices, slot={}, shared terrain decoder, position/UV/tint/AO/signed-light, nonzero binding offset)",
                        SLOT);
            } finally {
                close();
            }
        }
    }

    private static void start() {
        RegularTerrainVertices.verify(
                ByteBuffer.wrap(original).order(ByteOrder.LITTLE_ENDIAN),
                new RegularTerrainVertices.Result(
                        packed, RegularTerrainVertices.Layout.values()[SLOT], COUNT));
        var device = RenderSystem.getDevice();
        var builder =
                RenderPipeline.builder()
                        .withLocation(id("pipeline/terrain_attributes_probe_" + SLOT))
                        .withVertexShader(
                                id(
                                        SLOT == 2
                                                ? "core/terrain_attributes_wide_probe"
                                                : "core/terrain_attributes_probe"))
                        .withFragmentShader(id("core/terrain_attributes_probe"))
                        .withPrimitiveTopology(PrimitiveTopology.POINTS)
                        .withCull(false)
                        .withDepthStencilState(Optional.empty())
                        .withVertexBinding(0, VeilRegularTerrainPipelines.formatForSlot(SLOT));
        var descriptor =
                RenderPassDescriptor.create(() -> "Veil terrain attribute readback")
                        .withRenderArea(new RenderPass.RenderArea(0, 0, WIDTH, HEIGHT));
        for (int i = 0; i < 3; i++) {
            var format = i == 2 ? GpuFormat.RGBA8_UNORM : GpuFormat.RGBA32_FLOAT;
            builder.withColorTargetState(
                    i, new ColorTargetState(Optional.empty(), format, ColorTargetState.WRITE_ALL));
            targets[i] =
                    device.createTexture(
                            "Veil terrain attribute " + i,
                            GpuTexture.USAGE_RENDER_ATTACHMENT | GpuTexture.USAGE_COPY_SRC,
                            format,
                            WIDTH,
                            HEIGHT,
                            1,
                            1);
            views[i] = device.createTextureView(targets[i]);
            descriptor.withColorAttachment(views[i], Optional.of(new Vector4f(0, 0, 0, 0)));
            readbacks[i] =
                    device.createBuffer(
                            () -> "Veil terrain attribute readback",
                            GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                            (long) WIDTH * HEIGHT * format.blockSize());
        }
        var pipeline = builder.build();
        if (!device.precompilePipeline(pipeline).isValid())
            throw new IllegalStateException("Terrain attribute probe shader unavailable");
        var payload = ByteBuffer.allocateDirect(packed.length + 64);
        payload.position(64).put(packed).flip();
        vertices =
                device.createBuffer(
                        () -> "Veil terrain attribute vertices",
                        GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_COPY_SRC,
                        payload);
        vertexReadback =
                device.createBuffer(
                        () -> "Veil attribute vertex bytes",
                        GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                        packed.length);
        var encoder = device.createCommandEncoder();
        encoder.copyToBuffer(vertices.slice(64, packed.length), vertexReadback.slice());
        try (var pass = encoder.createRenderPass(descriptor)) {
            pass.setPipeline(pipeline);
            pass.setVertexBuffer(0, vertices.slice(64, packed.length));
            pass.draw(COUNT, 1, 0, 0);
        }
        for (int i = 0; i < 3; i++)
            encoder.copyTextureToBuffer(targets[i], readbacks[i], 0, () -> {}, 0);
        fence = encoder.createFence();
    }

    private static void appendBoundaries() {
        var bytes = ByteBuffer.wrap(original).order(ByteOrder.LITTLE_ENDIAN);
        bytes.position(NATIVE_COUNT * 28);
        float[] positions =
                SLOT == 2
                        ? new float[] {-8, -0.25f, 1f / 64, 16.25f, 23.999f}
                        : new float[] {0, 1f / 32, 15.96875f, 16};
        float[] halfUvs = {-2, -0.5f, 0, 0.25f, 1, 2, 65504};
        short[] lights = {Short.MIN_VALUE, -1, 0, 1, 255, Short.MAX_VALUE};
        for (int i = 0; i < COUNT - NATIVE_COUNT; i++) {
            for (int axis = 0; axis < 3; axis++)
                bytes.putFloat(positions[(i + axis) % positions.length]);
            bytes.putInt(i * 0x9e3779b9);
            bytes.putFloat(SLOT == 1 ? (i + 0.37f) / 31 : halfUvs[i % halfUvs.length]);
            bytes.putFloat(SLOT == 1 ? -i / 19f : halfUvs[(i + 2) % halfUvs.length]);
            bytes.putShort(lights[i % lights.length]);
            bytes.putShort(lights[(i + 3) % lights.length]);
        }
        var boundary =
                ByteBuffer.wrap(original, NATIVE_COUNT * 28, 32 * 28)
                        .slice()
                        .order(ByteOrder.LITTLE_ENDIAN);
        var result =
                SLOT == 2
                        ? RegularTerrainVertices.encodeWide(boundary, 32)
                        : RegularTerrainVertices.encode(boundary, 32, SLOT == 0);
        if (result == null || result.layout().ordinal() != SLOT)
            throw new IllegalStateException("GPU boundary layout mismatch");
        System.arraycopy(
                result.vertices(),
                0,
                packed,
                NATIVE_COUNT * result.stride(),
                result.vertices().length);
    }

    private static void verifyReadback() {
        try (var mapping = vertexReadback.map(true, false)) {
            for (int i = 0; i < packed.length; i++)
                if (mapping.data().get(i) != packed[i])
                    throw new IllegalStateException("GPU vertex upload mismatch byte=" + i);
        }
        var source = ByteBuffer.wrap(original).order(ByteOrder.LITTLE_ENDIAN);
        var seen = new BitSet(COUNT);
        try (var positionMap = readbacks[0].map(true, false);
                var uvLightMap = readbacks[1].map(true, false);
                var colorMap = readbacks[2].map(true, false)) {
            var positions = positionMap.data().order(ByteOrder.LITTLE_ENDIAN);
            var uvLight = uvLightMap.data().order(ByteOrder.LITTLE_ENDIAN);
            var colors = colorMap.data();
            for (int pixel = 0; pixel < WIDTH * HEIGHT; pixel++) {
                float marker = positions.getFloat(pixel * 16 + 12);
                if (marker == 0) continue;
                int vertex = (int) marker - 1;
                if (marker != vertex + 1f || vertex < 0 || vertex >= COUNT || seen.get(vertex))
                    throw new IllegalStateException(
                            "Invalid or duplicate GPU vertex marker " + marker);
                seen.set(vertex);
                int src = vertex * 28;
                for (int axis = 0; axis < 3; axis++) {
                    float expected = source.getFloat(src + axis * 4),
                            actual = positions.getFloat(pixel * 16 + axis * 4);
                    if (!Float.isFinite(actual)
                            || (SLOT == 2
                                    ? Math.abs(expected - actual)
                                            > RegularTerrainVertices.WIDE_POSITION_ERROR
                                    : Float.floatToRawIntBits(expected)
                                            != Float.floatToRawIntBits(actual)))
                        throw new IllegalStateException(
                                "GPU position mismatch vertex="
                                        + vertex
                                        + " axis="
                                        + axis
                                        + " expected="
                                        + expected
                                        + " actual="
                                        + actual
                                        + " sourceXYZ="
                                        + source.getFloat(src)
                                        + ","
                                        + source.getFloat(src + 4)
                                        + ","
                                        + source.getFloat(src + 8)
                                        + " decodedXYZ="
                                        + positions.getFloat(pixel * 16)
                                        + ","
                                        + positions.getFloat(pixel * 16 + 4)
                                        + ","
                                        + positions.getFloat(pixel * 16 + 8));
                }
                for (int channel = 0; channel < 4; channel++) {
                    if (colors.get(pixel * 4 + channel) != source.get(src + 12 + channel))
                        throw new IllegalStateException(
                                "GPU tint/AO mismatch vertex=" + vertex + " channel=" + channel);
                    float expected =
                            channel < 2
                                    ? source.getFloat(src + 16 + channel * 4)
                                    : source.getShort(src + 24 + (channel - 2) * 2);
                    float actual = uvLight.getFloat(pixel * 16 + channel * 4);
                    if (Float.floatToRawIntBits(expected) != Float.floatToRawIntBits(actual))
                        throw new IllegalStateException(
                                "GPU UV/light mismatch vertex="
                                        + vertex
                                        + " channel="
                                        + channel
                                        + " expected="
                                        + expected
                                        + " actual="
                                        + actual);
                }
            }
        }
        if (seen.cardinality() != COUNT)
            throw new IllegalStateException(
                    "GPU vertex coverage incomplete: " + seen.cardinality());
    }

    static void requireComplete() {
        if (ENABLED && !complete)
            throw new IllegalStateException(
                    "Compact GPU attributes probe incomplete, captured=" + captured);
    }

    private static void close() {
        if (fence != null) fence.close();
        if (vertices != null) vertices.close();
        if (vertexReadback != null) vertexReadback.close();
        for (int i = 0; i < 3; i++) {
            if (readbacks[i] != null) readbacks[i].close();
            if (views[i] != null) views[i].close();
            if (targets[i] != null) targets[i].close();
        }
        original = packed = null;
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }
}
