package dev.veil.revive.client.shaderpack.preparation;

import static dev.veil.revive.client.shaderpack.preparation.BindingValidator.*;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.api.VeilDraw;
import dev.veil.api.VeilResourceUsage;
import dev.veil.api.VeilVertexLayout;
import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderPack.Geometry;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.Resource;
import dev.veil.revive.client.VeilShaderPack.Source;
import dev.veil.revive.client.graphics.resources.VertexBufferRangeRules;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

public final class DrawPlanValidator {
    private final Map<String, Resource> resources;

    public DrawPlanValidator(Map<String, Resource> resources) {
        this.resources = resources;
    }

    public void validate(
            Pass pass,
            Map<String, VeilRenderGraph.Access> uses,
            List<VeilRenderGraph.Use> graphUses) {
        if (pass.geometry() != Geometry.CUSTOM) return;
        var layoutBindings = new LinkedHashMap<Integer, VeilVertexLayout.Binding>();
        pass.vertexLayout()
                .bindings()
                .forEach(binding -> layoutBindings.put(binding.binding(), binding));
        for (VeilDraw draw : pass.draws()) {
            var bound = new LinkedHashSet<Integer>();
            for (VeilDraw.VertexBuffer binding : draw.vertexBuffers()) {
                VeilVertexLayout.Binding layout = layoutBindings.get(binding.binding());
                if (layout == null)
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": draw references absent vertex binding="
                                    + binding.binding());
                Resource resource =
                        requireBuffer(pass, binding.resource(), VeilResourceUsage.VERTEX, "vertex");
                if (!bound.add(binding.binding()))
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": duplicate vertex binding="
                                    + binding.binding());
                int alignment =
                        pass.vertexLayout().attributes().stream()
                                .filter(attribute -> attribute.binding() == binding.binding())
                                .mapToInt(
                                        attribute ->
                                                attribute.format().bytesPerTexel()
                                                        / attribute.format().channels())
                                .max()
                                .orElse(1);
                if (binding.offset() % alignment != 0) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": vertex buffer offset is not attribute-aligned: "
                                    + binding.resource());
                }
                validateVertexRange(pass, draw, binding, layout, resource);
                addDrawUse(
                        pass, uses, graphUses, resource.name(), VeilRenderGraph.Access.VERTEX_READ);
            }
            for (VeilVertexLayout.Binding layout : layoutBindings.values()) {
                boolean used =
                        pass.vertexLayout().attributes().stream()
                                .anyMatch(attribute -> attribute.binding() == layout.binding());
                if (used && !bound.contains(layout.binding())) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": draw is missing vertex buffer binding="
                                    + layout.binding());
                }
            }
            if (draw.indexed()) {
                VeilDraw.IndexBuffer binding = draw.indexBuffer();
                Resource resource =
                        requireBuffer(pass, binding.resource(), VeilResourceUsage.INDEX, "index");
                if (resource.source() == Source.OWNED) {
                    if (binding.offset() > resource.bytes())
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + ": index offset exceeds "
                                        + resource.name());
                    if (!draw.indirect() && draw.elementCount() != 0 && draw.instanceCount() != 0) {
                        long end =
                                Math.addExact(
                                        binding.offset(),
                                        Math.multiplyExact(
                                                Math.addExact(
                                                        draw.firstElement(), draw.elementCount()),
                                                binding.bytes()));
                        if (end > resource.bytes())
                            throw new IllegalArgumentException(
                                    "Pass "
                                            + pass.name()
                                            + ": indexed draw exceeds "
                                            + resource.name());
                    }
                }
                addDrawUse(
                        pass, uses, graphUses, resource.name(), VeilRenderGraph.Access.INDEX_READ);
            }
            if (draw.indirect()) {
                Resource resource =
                        requireBuffer(
                                pass,
                                draw.indirectBuffer(),
                                VeilResourceUsage.INDIRECT,
                                "indirect");
                long bytes =
                        draw.drawCount() == 0
                                ? 0
                                : Math.addExact(
                                        draw.commandBytes(),
                                        Math.multiplyExact(
                                                (long) draw.drawCount() - 1, draw.stride()));
                if (resource.source() == Source.OWNED
                        && Math.addExact(draw.indirectOffset(), bytes) > resource.bytes()) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": indirect command range exceeds "
                                    + resource.name());
                }
                addDrawUse(
                        pass,
                        uses,
                        graphUses,
                        resource.name(),
                        VeilRenderGraph.Access.INDIRECT_READ);
            }
        }
    }

    private Resource requireBuffer(Pass pass, String name, VeilResourceUsage usage, String role) {
        return dev.veil.revive.client.shaderpack.preparation.ResourceRequirements.buffer(
                resources, pass, name, usage, role);
    }

    private void validateVertexRange(
            Pass pass,
            VeilDraw draw,
            VeilDraw.VertexBuffer binding,
            VeilVertexLayout.Binding layout,
            Resource resource) {
        if (resource.source() != Source.OWNED) return;
        if (binding.offset() > resource.bytes())
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": vertex offset exceeds " + resource.name());
        if (draw.indirect()
                || draw.indexed() && layout.inputRate() == VeilVertexLayout.InputRate.VERTEX)
            return;
        long first =
                layout.inputRate() == VeilVertexLayout.InputRate.INSTANCE
                        ? draw.firstInstance()
                        : draw.firstElement();
        long count =
                layout.inputRate() == VeilVertexLayout.InputRate.INSTANCE
                        ? draw.instanceCount()
                        : draw.elementCount();
        if (count == 0 || draw.instanceCount() == 0) return;
        int attributeSpan =
                pass.vertexLayout().attributes().stream()
                        .filter(attribute -> attribute.binding() == binding.binding())
                        .mapToInt(
                                attribute ->
                                        attribute.offset() + attribute.format().bytesPerTexel())
                        .max()
                        .orElse(0);
        try {
            VertexBufferRangeRules.validate(
                    binding.offset(),
                    first,
                    count,
                    layout.stride(),
                    attributeSpan,
                    resource.bytes());
        } catch (IllegalArgumentException invalid) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + ": draw range exceeds vertex buffer "
                            + resource.name()
                            + " (binding="
                            + binding.binding()
                            + ")",
                    invalid);
        }
    }

    private static void addDrawUse(
            Pass pass,
            Map<String, VeilRenderGraph.Access> uses,
            List<VeilRenderGraph.Use> graphUses,
            String resource,
            VeilRenderGraph.Access access) {
        VeilRenderGraph.Access previous = uses.putIfAbsent(resource, access);
        if (previous == null) graphUses.add(VeilRenderGraph.Use.whole(resource, access));
        else if (previous != access)
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + ": buffer has incompatible descriptor/draw roles: "
                            + resource);
    }
}
