package dev.veil.revive.client;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;

import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.color.block.BlockTintSource;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class VeilModelTintCache {
    private final BlockColors colors;
    private final DynamicTints dynamic;
    private final List<BlockTintSource> sources = new ArrayList<>();
    private final IntArrayList dynamicValues = new IntArrayList();
    private int[] values = new int[8];
    private boolean[] known = new boolean[8];
    private boolean ready;

    public VeilModelTintCache(BlockColors colors, DynamicTints dynamic) {
        this.colors = colors;
        this.dynamic = dynamic;
    }

    public int color(BlockAndTintGetter world, BlockState state, BlockPos position, int index) {
        if (index < 0) throw new IndexOutOfBoundsException("Negative model tint index");
        if (!ready) {
            sources.addAll(colors.getTintSources(state));
            if (sources.isEmpty()) dynamic.collect(state, world, position, dynamicValues);
            int count = sources.size();
            if (count > values.length) {
                values = new int[count];
                known = new boolean[count];
            } else Arrays.fill(known, 0, count, false);
            ready = true;
        }
        if (sources.isEmpty())
            return index < dynamicValues.size() ? dynamicValues.getInt(index) : -1;
        if (index >= sources.size()) return -1;
        if (!known[index]) {
            var source = sources.get(index);
            values[index] = source == null ? -1 : source.colorInWorld(state, world, position);
            known[index] = true;
        }
        return values[index];
    }

    public void clear() {
        sources.clear();
        dynamicValues.clear();
        ready = false;
    }

    @FunctionalInterface
    public interface DynamicTints {
        void collect(BlockState state, BlockAndTintGetter world, BlockPos position, IntList values);
    }
}
