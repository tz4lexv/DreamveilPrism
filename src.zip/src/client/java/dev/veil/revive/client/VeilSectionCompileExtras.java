package dev.veil.revive.client;

import net.minecraft.client.renderer.texture.TextureAtlasSprite;

public interface VeilSectionCompileExtras {
    int veil$reusedModels();

    void veil$setReusedModels(int models);

    TextureAtlasSprite[] veil$animatedSprites();

    void veil$setAnimatedSprites(TextureAtlasSprite[] sprites);

    VeilMaterialRange[] veil$materialRanges();

    void veil$setMaterialRanges(VeilMaterialRange[] ranges);

    VeilFluidGeometry[] veil$fluidGeometry();

    void veil$setFluidGeometry(VeilFluidGeometry[] geometry);

    void veil$setOriginalQuads(VeilOriginalQuadCapture.Snapshot snapshot);

    VeilOriginalQuadCapture.Snapshot veil$takeOriginalQuads();

    VeilOriginalQuadCapture.Snapshot veil$originalQuads();

    boolean veil$lightOnlyUpdate();

    void veil$setLightOnlyUpdate(boolean lightOnly);
}
