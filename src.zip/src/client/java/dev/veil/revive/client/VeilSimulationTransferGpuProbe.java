package dev.veil.revive.client;

import dev.veil.api.VeilSimulationFieldSnapshot;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.util.Arrays;

/** Opt-in native regression for the dedicated simulation-transfer fixture. */
final class VeilSimulationTransferGpuProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.simulationTransferGpuProbe");
    private static boolean requested;
    private static boolean completed;
    private static long started;

    private VeilSimulationTransferGpuProbe() {}

    static void tick(VeilShaderPackRuntime active) {
        if (!ENABLED || requested) return;
        if (!System.getProperty("veil.shaderPack", "").equals("veil-simulation-transfers-v121"))
            throw new IllegalStateException("Simulation probe requires its dedicated fixture");
        var states = active.transferImageStates("field");
        require(
                states.stream()
                        .anyMatch(
                                state ->
                                        state.subresource().baseMip() == 0
                                                && state.subresource().levelCount() == 1
                                                && state.state().layout()
                                                        == VeilRenderGraph.Layout.SHADER_READ_ONLY),
                "sampled mip0 layout");
        require(
                states.stream()
                        .anyMatch(
                                state ->
                                        state.subresource().baseMip() == 1
                                                && state.subresource().levelCount() == 2
                                                && state.state().layout()
                                                        == VeilRenderGraph.Layout
                                                                .TRANSFER_DESTINATION),
                "uncopied mip layouts");
        requested = true;
        started = System.nanoTime();
        active.readSimulationField(
                "field",
                original -> {
                    try {
                        require(
                                original.width() == 4
                                        && original.height() == 4
                                        && original.depth() == 1
                                        && original.components() == 4
                                        && original.type()
                                                == VeilSimulationFieldSnapshot.ScalarType.UINT8,
                                "field shape/format");
                        require(
                                Arrays.equals(original.pixels(), new byte[64]),
                                "zero initialization");
                        byte[] pattern = new byte[64];
                        for (int i = 0; i < pattern.length; i += 4) {
                            pattern[i] = 32;
                            pattern[i + 1] = 64;
                            pattern[i + 2] = (byte) 128;
                            pattern[i + 3] = (byte) 255;
                        }
                        var changed =
                                new VeilSimulationFieldSnapshot(
                                        4, 4, 1, 4, original.type(), pattern);
                        active.restoreSimulationField("field", changed);
                        active.readSimulationField(
                                "field",
                                captured -> {
                                    try {
                                        require(
                                                Arrays.equals(captured.pixels(), pattern),
                                                "restored bytes");
                                        active.restoreSimulationField("field", original);
                                        active.readSimulationField(
                                                "field",
                                                restored -> {
                                                    try {
                                                        require(
                                                                Arrays.equals(
                                                                        restored.pixels(),
                                                                        original.pixels()),
                                                                "original bytes restored");
                                                        ReviveMod.LOGGER.info(
                                                                "Veil simulation transfer GPU: PASS (three exact 64-byte captures, two uploads, mip0 sampled/mips1-2 transfer-destination)");
                                                        completed = true;
                                                        Minecraft.getInstance().stop();
                                                    } catch (RuntimeException problem) {
                                                        fail(problem);
                                                    }
                                                });
                                    } catch (RuntimeException problem) {
                                        fail(problem);
                                    }
                                });
                    } catch (RuntimeException problem) {
                        fail(problem);
                    }
                });
    }

    static void checkTimeout(boolean executionFailed) {
        if (!ENABLED || completed) return;
        if (started == 0) started = System.nanoTime();
        if (executionFailed || System.nanoTime() - started > 60_000_000_000L)
            fail(new IllegalStateException("Simulation GPU runtime/readback timeout"));
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException("Simulation GPU mismatch: " + message);
    }

    private static void fail(RuntimeException problem) {
        if (completed) return;
        completed = true;
        ReviveMod.LOGGER.error("Veil simulation transfer GPU: FAIL", problem);
        Minecraft.getInstance().stop();
    }
}
