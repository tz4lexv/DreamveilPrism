package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;

import java.util.ArrayList;
import java.util.Collections;

final class VeilSlangCullProbe {
    private static GpuBuffer actual, reference, readback, actualCount, referenceCount;
    private static GpuBuffer inactiveSections;
    private static boolean testingInactive;
    private static GpuFence fence;
    private static VeilHzbCompute slang, glsl;
    private static int completed, bytes, commands, expectedModes = 5;
    private static long compared;

    static void compare(
            VeilVulkanRuntime runtime,
            VeilIndirectTerrain.PreparedBatch batch,
            GpuBufferSlice sections,
            GpuBufferSlice hzb,
            int width,
            int height,
            int mipCount,
            int[] offsets) {
        if (!VeilSlangHzbProbe.enabled() || completed >= expectedModes || fence != null) return;
        var device = RenderSystem.getDevice();
        int variantModes = VeilHzbCompute.supportsWave(runtime) ? 10 : 5;
        expectedModes = variantModes * 2;
        testingInactive = completed >= variantModes;
        if (testingInactive) {
            var data =
                    java.nio.ByteBuffer.allocateDirect(Math.toIntExact(sections.length()))
                            .order(java.nio.ByteOrder.nativeOrder());
            for (int entry = 0; entry + 16 <= data.capacity(); entry += 16) {
                float visibility =
                        switch ((entry / 16) % 3) {
                            case 0 -> 0.0f;
                            case 1 -> -0.0f;
                            default -> -0.5f;
                        };
                data.putFloat(entry + 12, visibility);
            }
            inactiveSections =
                    device.createBuffer(
                            () -> "Veil inactive section culling proof",
                            VeilHzb.STORAGE_USAGE,
                            data);
            sections = inactiveSections.slice();
        }
        commands = batch.batch().sectionIndices().length;
        bytes = commands * 20;
        int usage = VeilHzb.STORAGE_USAGE | GpuBuffer.USAGE_COPY_SRC;
        actual = device.createBuffer(() -> "Veil Slang culling parity", usage, bytes);
        reference = device.createBuffer(() -> "Veil GLSL culling parity", usage, bytes);
        actualCount = device.createBuffer(() -> "Veil Slang culling counters", usage, 16);
        referenceCount = device.createBuffer(() -> "Veil GLSL culling counters", usage, 16);
        readback =
                device.createBuffer(
                        () -> "Veil culling parity readback",
                        GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                        2L * bytes + 32);
        slang =
                new VeilHzbCompute(
                        runtime, true, variantModes == 10 && completed % variantModes >= 5);
        glsl = new VeilHzbCompute(runtime, false);
        slang.dispatchProbe(
                batch,
                sections,
                hzb,
                actual.slice(),
                actualCount.slice(),
                completed % 5,
                width,
                height,
                mipCount,
                offsets);
        glsl.dispatchProbe(
                batch,
                sections,
                hzb,
                reference.slice(),
                referenceCount.slice(),
                completed % 5,
                width,
                height,
                mipCount,
                offsets);
        var encoder = device.createCommandEncoder();
        encoder.copyToBuffer(actual.slice(), readback.slice(0, bytes));
        encoder.copyToBuffer(reference.slice(), readback.slice(bytes, bytes));
        encoder.copyToBuffer(actualCount.slice(), readback.slice(2L * bytes, 16));
        encoder.copyToBuffer(referenceCount.slice(), readback.slice(2L * bytes + 16, 16));
        fence = encoder.createFence();
    }

    static void poll() {
        if (fence == null || !fence.awaitCompletion(0)) return;
        try (var mapped = readback.map(true, false)) {
            var data = mapped.data();
            int count = data.getInt(bytes * 2);
            if (count < 0 || count > commands)
                throw new IllegalStateException("Invalid Slang visible count");
            if (testingInactive && count != 0)
                throw new IllegalStateException(
                        "Inactive sections emitted GPU commands mode=" + completed);
            for (int offset = 0; offset < 16; offset += 4) {
                if (data.getInt(bytes * 2 + offset) != data.getInt(bytes * 2 + 16 + offset))
                    throw new IllegalStateException(
                            "Slang culling counter mismatch mode="
                                    + completed
                                    + " counter="
                                    + offset / 4);
            }
            var a = new ArrayList<String>();
            var b = new ArrayList<String>();
            for (int command = 0; command < count; command++) {
                var ca = new StringBuilder();
                var cb = new StringBuilder();
                for (int word = 0; word < 5; word++) {
                    ca.append(data.getInt(command * 20 + word * 4)).append(',');
                    cb.append(data.getInt(bytes + command * 20 + word * 4)).append(',');
                }
                a.add(ca.toString());
                b.add(cb.toString());
            }
            Collections.sort(a);
            Collections.sort(b);
            if (!a.equals(b))
                throw new IllegalStateException("Slang culling command mismatch mode=" + completed);
            compared += commands;
            ReviveMod.LOGGER.info(
                    "Veil Slang culling parity: mode={} input={} visible={} inactive={} commands and counters equal",
                    completed,
                    commands,
                    count,
                    testingInactive);
            if (++completed == expectedModes)
                ReviveMod.LOGGER.info(
                        "Veil Slang culling GPU probe: PASS ({} input commands, all 5 modes, available scalar/wave variants, active/inactive sections, compacted command sets and counters equal against GLSL)",
                        compared);
        } finally {
            fence.close();
            fence = null;
            actual.close();
            reference.close();
            actualCount.close();
            referenceCount.close();
            readback.close();
            if (inactiveSections != null) {
                inactiveSections.close();
                inactiveSections = null;
            }
            slang.close();
            glsl.close();
        }
    }

    static void requireComplete() {
        if (VeilSlangHzbProbe.enabled() && completed != expectedModes)
            throw new IllegalStateException("Slang culling probe incomplete: " + completed);
    }
}
