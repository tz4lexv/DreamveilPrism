package dev.veil.api.graphics;

import java.util.Set;

public interface GraphicsCapabilitySource {
    boolean accelerationStructures();

    boolean rayQuery();

    boolean rayPipeline();

    Set<String> hostResources();

    default boolean shaderInt64() {
        return false;
    }

    default boolean shaderBufferInt64Atomics() {
        return false;
    }

    default boolean shaderSharedInt64Atomics() {
        return false;
    }

    default Set<String> enabledDeviceFeatures() {
        return Set.of();
    }

    default Set<RasterFeature> rasterFeatures() {
        return Set.of();
    }
}
