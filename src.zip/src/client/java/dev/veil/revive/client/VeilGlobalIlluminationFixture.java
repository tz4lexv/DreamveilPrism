package dev.veil.revive.client;

import dev.veil.api.VeilCreatorScene;
import dev.veil.revive.ReviveMod;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;

final class VeilGlobalIlluminationFixture {
    private static VeilCreatorScene.Registration fixtureLight;

    private VeilGlobalIlluminationFixture() {}

    /** A persistent Minecraft block construction; no synthetic ray-scene geometry. */
    static double prepareCornell(ServerLevel level, int centerX, int centerZ) {
        final int floor = 160;
        var cursor = new BlockPos.MutableBlockPos();
        // Clear only the dedicated room footprint, including the previous fixture contents.
        for (int x = centerX - 8; x <= centerX + 8; x++)
            for (int z = centerZ - 8; z <= centerZ + 8; z++)
                for (int y = floor; y <= floor + 9; y++) {
                    var block = Blocks.AIR;
                    if (y == floor || y == floor + 9 || z == centerZ - 8)
                        block = Blocks.CONCRETE.white();
                    if (x == centerX - 8) block = Blocks.CONCRETE.red();
                    if (x == centerX + 8) block = Blocks.CONCRETE.green();
                    // Front wall has a five-block entrance; the ceiling still encloses the room.
                    if (z == centerZ + 8 && (Math.abs(x - centerX) > 2 || y > floor + 4))
                        block = Blocks.CONCRETE.white();
                    level.setBlock(cursor.set(x, y, z), block.defaultBlockState(), 3);
                }
        for (int x = centerX - 2; x <= centerX + 2; x++)
            for (int z = centerZ - 3; z <= centerZ; z++)
                level.setBlock(
                        cursor.set(x, floor + 9, z), Blocks.SEA_LANTERN.defaultBlockState(), 3);
        fill(
                level,
                centerX - 4,
                floor + 1,
                centerZ - 3,
                centerX - 2,
                floor + 3,
                centerZ - 1,
                Blocks.CONCRETE.white());
        fill(
                level,
                centerX + 2,
                floor + 1,
                centerZ - 5,
                centerX + 4,
                floor + 5,
                centerZ - 3,
                Blocks.CONCRETE.white());
        // Material comparison plinths, with white receivers below the colored filters.
        fill(
                level,
                centerX - 7,
                floor + 1,
                centerZ + 1,
                centerX - 5,
                floor + 1,
                centerZ + 3,
                Blocks.CONCRETE.white());
        fill(
                level,
                centerX - 7,
                floor + 4,
                centerZ + 1,
                centerX - 5,
                floor + 4,
                centerZ + 3,
                Blocks.STAINED_GLASS.blue());
        fill(
                level,
                centerX + 5,
                floor + 1,
                centerZ + 1,
                centerX + 7,
                floor + 1,
                centerZ + 3,
                Blocks.CONCRETE.white());
        fill(
                level,
                centerX + 5,
                floor + 4,
                centerZ + 1,
                centerX + 7,
                floor + 4,
                centerZ + 3,
                Blocks.STAINED_GLASS.red());
        fill(
                level,
                centerX - 6,
                floor + 1,
                centerZ - 6,
                centerX - 5,
                floor + 2,
                centerZ - 5,
                Blocks.IRON_BLOCK);
        fill(
                level,
                centerX + 5,
                floor + 1,
                centerZ - 1,
                centerX + 6,
                floor + 2,
                centerZ,
                Blocks.GOLD_BLOCK);
        if (fixtureLight != null) fixtureLight.close();
        fixtureLight =
                VeilCreatorScene.registerLight(
                        new VeilCreatorScene.Light(
                                0x564749434f4c4f52L,
                                VeilCreatorScene.LIGHT_POINT,
                                centerX + .5f,
                                floor + 8.5f,
                                centerZ - 1.5f,
                                32f,
                                1f,
                                1f,
                                1f,
                                100f,
                                0f,
                                -1f,
                                0f,
                                1f,
                                -1f,
                                0));
        // Persist a human-readable location beside the world's logs.
        try {
            java.nio.file.Files.writeString(
                    java.nio.file.Path.of("logs", "cornell-block-room.txt"),
                    "Actual Minecraft blocks in the dedicated benchmark save.\n"
                            + "Bounds: "
                            + (centerX - 8)
                            + " 160 "
                            + (centerZ - 8)
                            + " to "
                            + (centerX + 8)
                            + " 169 "
                            + (centerZ + 8)
                            + "\n"
                            + "Entrance: "
                            + (centerX + .5)
                            + " 161 "
                            + (centerZ + 8.5)
                            + "\n"
                            + "Red/green walls, white receivers, ceiling sea lanterns, white boxes, blue/red glass, iron/gold blocks.\n"
                            + "Metal blocks require a pack's PBR maps and reflection integrator to appear reflective.\n");
        } catch (java.io.IOException failure) {
            throw new IllegalStateException(failure);
        }
        ReviveMod.LOGGER.info(
                "Veil Cornell block construction: BUILT bounds=({},160,{})..({},169,{})",
                centerX - 8,
                centerZ - 8,
                centerX + 8,
                centerZ + 8);
        return floor + 1.0;
    }

    private static void fill(
            ServerLevel level,
            int x0,
            int y0,
            int z0,
            int x1,
            int y1,
            int z1,
            net.minecraft.world.level.block.Block block) {
        var cursor = new BlockPos.MutableBlockPos();
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                for (int z = z0; z <= z1; z++)
                    level.setBlock(cursor.set(x, y, z), block.defaultBlockState(), 3);
    }

    static double prepare(ServerLevel level, int centerX, int centerZ) {
        boolean closed = Boolean.getBoolean("veil.giClosedRoom");
        String colorCase = System.getProperty("veil.giColorCase", "default");
        boolean controlled = !colorCase.equals("default");
        if (fixtureLight != null) {
            fixtureLight.close();
            fixtureLight = null;
        }
        boolean coloredWalls = colorCase.equals("colored") || colorCase.equals("swapped");
        int floor = 160;
        if (floor + 9 >= level.getMaxY())
            throw new IllegalStateException("GI room exceeds world bounds");
        level.getGameRules()
                .set(
                        net.minecraft.world.level.gamerules.GameRules.SPAWN_MOBS,
                        false,
                        level.getServer());
        var entities = new java.util.ArrayList<net.minecraft.world.entity.Entity>();
        level.getAllEntities().forEach(entities::add);
        for (var entity : entities)
            if (!(entity instanceof net.minecraft.world.entity.player.Player)) entity.discard();
        var cursor = new BlockPos.MutableBlockPos();
        for (int x = centerX - 8; x <= centerX + 8; x++)
            for (int z = centerZ - 8; z <= centerZ + 8; z++)
                for (int y = floor; y <= floor + 9; y++) {
                    boolean wall =
                            x == centerX - 8
                                    || x == centerX + 8
                                    || z == centerZ - 8
                                    || z == centerZ + 8;
                    var block =
                            y == floor || wall || (closed && y == floor + 9)
                                    ? Blocks.CONCRETE.white()
                                    : Blocks.AIR;
                    if (wall && y > floor && y < floor + 9 && (!controlled || coloredWalls)) {
                        if (x == centerX - 8)
                            block =
                                    colorCase.equals("swapped")
                                            ? Blocks.CONCRETE.green()
                                            : Blocks.CONCRETE.red();
                        else if (x == centerX + 8)
                            block =
                                    colorCase.equals("swapped")
                                            ? Blocks.CONCRETE.red()
                                            : Blocks.CONCRETE.green();
                    }
                    level.setBlock(cursor.set(x, y, z), block.defaultBlockState(), 3);
                }
        if (controlled) {
            if (!java.util.Set.of(
                            "neutral",
                            "colored",
                            "swapped",
                            "glassred",
                            "glassgreen",
                            "glassclear",
                            "opaque")
                    .contains(colorCase))
                throw new IllegalArgumentException("Unknown GI color fixture: " + colorCase);
            fixtureLight =
                    VeilCreatorScene.registerLight(
                            new VeilCreatorScene.Light(
                                    0x564749434f4c4f52L,
                                    VeilCreatorScene.LIGHT_POINT,
                                    centerX + 0.5f,
                                    floor + 8.5f,
                                    centerZ + 0.5f,
                                    32.0f,
                                    1.0f,
                                    1.0f,
                                    1.0f,
                                    100.0f,
                                    0.0f,
                                    -1.0f,
                                    0.0f,
                                    1.0f,
                                    -1.0f,
                                    0));
            for (int x = centerX - 2; x <= centerX + 2; x++)
                for (int z = centerZ - 2; z <= centerZ + 2; z++) {
                    if (colorCase.startsWith("glass") || colorCase.equals("opaque")) {
                        var filter =
                                switch (colorCase) {
                                    case "glassred" -> Blocks.STAINED_GLASS.red();
                                    case "glassgreen" -> Blocks.STAINED_GLASS.green();
                                    case "glassclear" -> Blocks.GLASS;
                                    default -> Blocks.CONCRETE.white();
                                };
                        level.setBlock(cursor.set(x, floor + 7, z), filter.defaultBlockState(), 3);
                    }
                }
            ReviveMod.LOGGER.info(
                    "Veil GI color fixture: case={} controlled white receiver, white point light in air",
                    colorCase);
        }
        ReviveMod.LOGGER.info(
                "Veil GI fixture: room={} floor={} radius=8 height=9 red/green walls, mobs removed",
                closed ? "CLOSED" : "OPEN",
                floor);
        return floor + 2.0;
    }
}
