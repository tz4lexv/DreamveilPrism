package dev.veil.revive.client.raytracing;

import static org.lwjgl.vulkan.KHRAccelerationStructure.*;
import static org.lwjgl.vulkan.KHRRayQuery.*;
import static org.lwjgl.vulkan.KHRRayTracingPipeline.*;
import static org.lwjgl.vulkan.VK11.*;

import com.mojang.blaze3d.vulkan.VulkanBackend;
import com.mojang.blaze3d.vulkan.VulkanPhysicalDevice;
import com.mojang.blaze3d.vulkan.init.VulkanFeature;
import com.mojang.blaze3d.vulkan.init.VulkanPNextStruct;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;

import java.util.Collection;
import java.util.Set;

public final class RayDeviceCapabilities {
    private static volatile boolean accelerationSupported, querySupported, pipelineSupported;

    private RayDeviceCapabilities() {}

    public static void request(
            VulkanPhysicalDevice physical,
            Collection<String> extensions,
            Set<VulkanFeature> features) {
        accelerationSupported = querySupported = pipelineSupported = false;
        if (!physical.hasDeviceExtension(VK_KHR_ACCELERATION_STRUCTURE_EXTENSION_NAME)
                || !physical.hasDeviceExtension("VK_KHR_deferred_host_operations")) return;
        boolean queryExtension = physical.hasDeviceExtension(VK_KHR_RAY_QUERY_EXTENSION_NAME);
        boolean pipelineExtension =
                physical.hasDeviceExtension(VK_KHR_RAY_TRACING_PIPELINE_EXTENSION_NAME);
        if (!queryExtension && !pipelineExtension) return;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var ray = VkPhysicalDeviceRayQueryFeaturesKHR.calloc(stack).sType$Default();
            var pipeline =
                    VkPhysicalDeviceRayTracingPipelineFeaturesKHR.calloc(stack).sType$Default();
            long optionalFeatures = 0;
            if (queryExtension) {
                ray.pNext(optionalFeatures);
                optionalFeatures = ray.address();
            }
            if (pipelineExtension) {
                pipeline.pNext(optionalFeatures);
                optionalFeatures = pipeline.address();
            }
            var acceleration =
                    VkPhysicalDeviceAccelerationStructureFeaturesKHR.calloc(stack)
                            .sType$Default()
                            .pNext(optionalFeatures);
            var core =
                    VkPhysicalDeviceVulkan12Features.calloc(stack)
                            .sType$Default()
                            .pNext(acceleration.address());
            var all = VkPhysicalDeviceFeatures2.calloc(stack).sType$Default().pNext(core.address());
            vkGetPhysicalDeviceFeatures2(physical.vkPhysicalDevice(), all);
            accelerationSupported =
                    acceleration.accelerationStructure() && core.bufferDeviceAddress();
            querySupported = accelerationSupported && queryExtension && ray.rayQuery();
            pipelineSupported =
                    accelerationSupported && pipelineExtension && pipeline.rayTracingPipeline();
            if (!querySupported && !pipelineSupported) return;
            extensions.add(VK_KHR_ACCELERATION_STRUCTURE_EXTENSION_NAME);
            extensions.add("VK_KHR_deferred_host_operations");
            features.add(
                    new VulkanFeature(
                            VulkanBackend.VK12_FEATURES_STRUCT,
                            "bufferDeviceAddress",
                            VkPhysicalDeviceVulkan12Features.BUFFERDEVICEADDRESS));
            features.add(
                    new VulkanFeature(
                            new VulkanPNextStruct(
                                    VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ACCELERATION_STRUCTURE_FEATURES_KHR,
                                    VkPhysicalDeviceAccelerationStructureFeaturesKHR.SIZEOF),
                            "accelerationStructure",
                            VkPhysicalDeviceAccelerationStructureFeaturesKHR
                                    .ACCELERATIONSTRUCTURE));
            if (querySupported) {
                extensions.add(VK_KHR_RAY_QUERY_EXTENSION_NAME);
                features.add(
                        new VulkanFeature(
                                new VulkanPNextStruct(
                                        VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_RAY_QUERY_FEATURES_KHR,
                                        VkPhysicalDeviceRayQueryFeaturesKHR.SIZEOF),
                                "rayQuery",
                                VkPhysicalDeviceRayQueryFeaturesKHR.RAYQUERY));
            }
            if (pipelineSupported) {
                extensions.add(VK_KHR_RAY_TRACING_PIPELINE_EXTENSION_NAME);
                features.add(
                        new VulkanFeature(
                                new VulkanPNextStruct(
                                        VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_RAY_TRACING_PIPELINE_FEATURES_KHR,
                                        VkPhysicalDeviceRayTracingPipelineFeaturesKHR.SIZEOF),
                                "rayTracingPipeline",
                                VkPhysicalDeviceRayTracingPipelineFeaturesKHR.RAYTRACINGPIPELINE));
            }
        }
    }

    public static boolean rayQuery() {
        return accelerationStructures() && enabled("rayQuery");
    }

    public static boolean accelerationStructures() {
        return enabled("accelerationStructure") && enabled("bufferDeviceAddress");
    }

    public static boolean rayPipeline() {
        return accelerationStructures() && enabled("rayTracingPipeline");
    }

    private static boolean enabled(String feature) {
        return dev.veil.revive.client.graphics.minecraft.EnabledDeviceFeatures
                .enabledOnCurrentDevice(feature);
    }

    public static String report() {
        return "ray_tracing: portableBvh=true portableBvhBuilder=BINNED_SAH accelerationSupported="
                + accelerationSupported
                + " accelerationEnabled="
                + accelerationStructures()
                + " rayQuerySupported="
                + querySupported
                + " rayQueryEnabled="
                + rayQuery()
                + " rayPipelineSupported="
                + pipelineSupported
                + " rayPipelineEnabled="
                + rayPipeline()
                + " rayPipelineImplemented=true sbt=true";
    }
}
