package dev.veil.revive.client.graphics.pipelines;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.revive.client.graphics.minecraft.DeferredGpuRetirement;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.client.graphics.minecraft.VulkanResult;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.VkShaderModuleCreateInfo;

import java.nio.ByteBuffer;
import java.util.function.LongConsumer;

public final class NativeShaderModule implements AutoCloseable {
    private final MinecraftVulkanContext runtime;
    private final String sourceName;
    private final DeferredGpuRetirement closeRequested = new DeferredGpuRetirement();
    private long handle;

    private NativeShaderModule(MinecraftVulkanContext runtime, String sourceName, long handle) {
        this.runtime = runtime;
        this.sourceName = sourceName;
        this.handle = handle;
    }

    public static NativeShaderModule create(
            MinecraftVulkanContext runtime,
            byte[] code,
            String sourceName,
            LongConsumer debugName) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        ByteBuffer nativeCode = MemoryUtil.memAlloc(code.length);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            nativeCode.put(code).flip();
            var out = stack.mallocLong(1);
            int result =
                    vkCreateShaderModule(
                            runtime.vkDevice(),
                            VkShaderModuleCreateInfo.calloc(stack)
                                    .sType$Default()
                                    .pCode(nativeCode),
                            null,
                            out);
            VulkanResult.check(result, "vkCreateShaderModule(" + sourceName + ")");
            debugName.accept(out.get(0));
            return new NativeShaderModule(runtime, sourceName, out.get(0));
        } finally {
            MemoryUtil.memFree(nativeCode);
        }
    }

    public long handle() {
        if (closeRequested.closeRequested() || handle == VK_NULL_HANDLE)
            throw new IllegalStateException("Shader module is closed: " + sourceName);
        return handle;
    }

    public void destroyNow() {
        closeRequested.markDestroyed();
        long old = handle;
        handle = VK_NULL_HANDLE;
        if (old != VK_NULL_HANDLE) vkDestroyShaderModule(runtime.vkDevice(), old, null);
    }

    @Override
    public void close() {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        closeRequested.defer(action -> runtime.deferDestroy(action::run), this::destroyNow);
    }
}
