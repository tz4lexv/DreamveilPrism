package dev.veil.revive.client.graphics.rendergraph;

import static dev.veil.revive.client.VeilShaderGraphPlan.*;

import static org.lwjgl.vulkan.VK13.*;

import dev.veil.revive.client.VeilHostResourceRegistry;
import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderGraphPlan.Frame;
import dev.veil.revive.client.VeilShaderPack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class FrameCyclePlan {
    private final VeilShaderPack pack;
    private final List<Frame> frames;
    private final int cycle;
    private final Map<String, List<VeilRenderGraph.ImageState>> initialImages;

    public FrameCyclePlan(VeilShaderPack.Prepared prepared) {
        pack = prepared.pack();
        int resolvedCycle = 1;
        for (var resource : pack.resources().values())
            resolvedCycle = lcm(resolvedCycle, resource.historyCount());
        cycle = resolvedCycle;

        var tracker = new VeilRenderGraph.Tracker();
        var names = new java.util.LinkedHashSet<String>();
        var imageTransferWrite = VeilRenderGraph.State.of(VeilRenderGraph.Access.TRANSFER_WRITE);
        var bufferTransferWrite =
                VeilRenderGraph.State.of(VeilRenderGraph.Access.BUFFER_TRANSFER_WRITE);
        var bufferUndefined =
                new VeilRenderGraph.State(
                        VK_PIPELINE_STAGE_2_TOP_OF_PIPE_BIT, 0, false, VeilRenderGraph.Layout.NONE);
        for (var resource : pack.resources().values()) {
            for (int index = 0; index < resource.historyCount(); index++) {
                String key = physical(resource.name(), index);
                names.add(key);
                VeilRenderGraph.Subresource subresource = fullImageOrWhole(resource);
                if (resource.hostImport()) {
                    tracker.initialize(
                            key,
                            subresource,
                            VeilHostResourceRegistry.definition(resource.hostId()).initialState(),
                            resource.kind());
                } else if (resource.kind() == VeilRenderGraph.Kind.BUFFER) {
                    tracker.initialize(
                            key,
                            subresource,
                            resource.initialContent() == VeilShaderPack.InitialContent.UNDEFINED
                                    ? bufferUndefined
                                    : bufferTransferWrite);
                } else if (resource.initializedAsset()) {
                    tracker.initialize(
                            key, subresource, resource.sampled() ? sampledState() : storageState());
                } else if (resource.initialContent() == VeilShaderPack.InitialContent.ZERO) {
                    tracker.initialize(key, subresource, imageTransferWrite);
                } else {
                    tracker.initialize(key, subresource, undefinedState());
                }
            }
        }
        if (pack.present() != null) names.add(SCENE_COLOR);

        var initialSnapshots = new LinkedHashMap<String, List<VeilRenderGraph.ImageState>>();
        for (String name : names) {
            var snapshot = tracker.imageStates(name);
            if (!snapshot.isEmpty()) initialSnapshots.put(name, List.copyOf(snapshot));
        }
        initialImages = Map.copyOf(initialSnapshots);

        var plans = new ArrayList<Frame>();
        for (int frame = 0; frame < cycle * 2; frame++) {
            int frameOrdinal = frame;
            for (var resource : pack.resources().values()) {
                if (!resource.hostImport()) continue;
                tracker.initialize(
                        physical(resource.name(), frame),
                        fullImageOrWhole(resource),
                        VeilHostResourceRegistry.definition(resource.hostId()).initialState(),
                        resource.kind());
            }
            if (pack.present() != null) {
                tracker.initialize(
                        SCENE_COLOR,
                        VeilRenderGraph.Subresource.image(0, 1, 0, 1),
                        VeilHostResourceRegistry.definition(VeilHostResourceRegistry.SCENE_COLOR)
                                .initialState());
            }

            var barriers = new ArrayList<List<VeilRenderGraph.Barrier>>();
            for (var pass : prepared.graph()) {
                var physicalUses = new ArrayList<VeilRenderGraph.Use>();
                for (VeilRenderGraph.Use use : pass.uses()) {
                    physicalUses.add(
                            new VeilRenderGraph.Use(
                                    physical(use.resource(), frame),
                                    use.access(),
                                    use.subresource()));
                }
                var physicalResources = new LinkedHashMap<String, VeilRenderGraph.Access>();
                pass.resources()
                        .forEach(
                                (key, access) ->
                                        physicalResources.put(physical(key, frameOrdinal), access));
                barriers.add(
                        tracker.before(
                                new VeilRenderGraph.Pass(
                                        pass.name(), physicalResources, physicalUses, Set.of())));
            }

            List<VeilRenderGraph.Barrier> present;
            if (pack.present() == null) {
                present = List.of();
            } else {
                VeilShaderPack.Resource output = pack.resources().get(pack.present());
                var presentUses =
                        List.of(
                                new VeilRenderGraph.Use(
                                        physical(pack.present(), frame),
                                        VeilRenderGraph.Access.FRAGMENT_SAMPLE,
                                        fullImageSubresource(output)),
                                new VeilRenderGraph.Use(
                                        SCENE_COLOR,
                                        VeilRenderGraph.Access.COLOR_READ_WRITE,
                                        VeilRenderGraph.Subresource.image(0, 1, 0, 1)));
                present =
                        tracker.before(
                                new VeilRenderGraph.Pass(
                                        "@present",
                                        Map.of(
                                                physical(pack.present(), frame),
                                                VeilRenderGraph.Access.FRAGMENT_SAMPLE,
                                                SCENE_COLOR,
                                                VeilRenderGraph.Access.COLOR_READ_WRITE),
                                        presentUses,
                                        Set.of()));
            }

            var states = new LinkedHashMap<String, VeilRenderGraph.State>();
            for (String name : names) {
                var state = tracker.current(name);
                if (state != null) states.put(name, state);
            }

            var release = new ArrayList<VeilRenderGraph.Barrier>();
            var released = new java.util.LinkedHashSet<String>();
            for (var resource : pack.resources().values()) {
                if (!resource.hostImport()) continue;
                String physical = physical(resource.name(), frame);
                var hostDefinition = VeilHostResourceRegistry.definition(resource.hostId());
                VeilRenderGraph.State initial = hostDefinition.initialState();
                VeilRenderGraph.State target = hostDefinition.releaseState();
                if (resource.kind() == VeilRenderGraph.Kind.IMAGE) {
                    release.addAll(tracker.release(physical, initial, target));
                    released.add(physical);
                } else {
                    release.addAll(tracker.release(physical, initial, target));
                    released.add(physical);
                }
            }
            if (pack.present() != null && !released.contains(SCENE_COLOR)) {
                VeilRenderGraph.State current = tracker.current(SCENE_COLOR);
                var sceneColorDefinition =
                        VeilHostResourceRegistry.definition(VeilHostResourceRegistry.SCENE_COLOR);
                VeilRenderGraph.State initial = sceneColorDefinition.initialState();
                VeilRenderGraph.State target = sceneColorDefinition.releaseState();
                release.addAll(tracker.release(SCENE_COLOR, initial, target));
            }
            var imageStates = new LinkedHashMap<String, List<VeilRenderGraph.ImageState>>();
            for (String name : names) {
                var snapshot = tracker.imageStates(name);
                if (!snapshot.isEmpty()) imageStates.put(name, snapshot);
            }
            plans.add(
                    new Frame(
                            List.copyOf(barriers),
                            present,
                            Map.copyOf(states),
                            List.copyOf(release),
                            imageStates));
        }
        frames = List.copyOf(plans);
    }

    public Frame frame(long ordinal) {
        if (ordinal < 0) throw new IllegalArgumentException("Negative graph frame");
        return frames.get(ordinal < cycle ? (int) ordinal : cycle + (int) (ordinal % cycle));
    }

    /** States after declared initialization, before any graph pass consumes the images. */
    public Map<String, List<VeilRenderGraph.ImageState>> initialImageStates() {
        return initialImages;
    }

    public String physical(String logical, long ordinal) {
        int marker = logical.lastIndexOf("#history:");
        int historyOffset = 0;
        String name = logical;
        if (marker >= 0) {
            name = logical.substring(0, marker);
            try {
                historyOffset = Integer.parseInt(logical.substring(marker + 9));
            } catch (NumberFormatException failure) {
                throw new IllegalArgumentException(
                        "Invalid graph history resource " + logical, failure);
            }
        } else if (logical.endsWith("#previous")) {
            name = logical.substring(0, logical.length() - 9);
            historyOffset = 1;
        }
        var resource = pack.resources().get(name);
        if (resource == null)
            throw new IllegalArgumentException("Unknown graph resource " + logical);
        if (resource.hostImport()) return VeilHostResourceRegistry.physical(resource.hostId());
        if (!resource.history()) {
            if (historyOffset != 0)
                throw new IllegalArgumentException("Resource has no history " + logical);
            return name;
        }
        if (historyOffset < 0 || historyOffset >= resource.historyCount()) {
            throw new IllegalArgumentException(
                    "History offset exceeds resource history " + logical);
        }
        return name + "#" + Math.floorMod(ordinal - historyOffset, resource.historyCount());
    }

    private static int lcm(int left, int right) {
        return Math.multiplyExact(left / gcd(left, right), right);
    }

    private static int gcd(int left, int right) {
        while (right != 0) {
            int next = left % right;
            left = right;
            right = next;
        }
        return left;
    }

    private static VeilRenderGraph.Subresource fullImageOrWhole(VeilShaderPack.Resource resource) {
        if (resource.kind() == VeilRenderGraph.Kind.BUFFER)
            return resource.hostImport()
                    ? VeilRenderGraph.Subresource.WHOLE
                    : VeilRenderGraph.Subresource.buffer(0, resource.bytes());
        return fullImageSubresource(resource);
    }

    private static VeilRenderGraph.Subresource fullImageSubresource(
            VeilShaderPack.Resource resource) {
        int mips = resource.hostImport() ? 1 : Math.max(1, resource.mipLevels());
        int layers =
                resource.hostImport()
                        ? 1
                        : resource.cubemap() || resource.image1dArray() || resource.image2dArray()
                                ? resource.layers()
                                : 1;
        return VeilRenderGraph.Subresource.image(0, mips, 0, layers);
    }
}
