package dev.veil.revive.client.graphics.minecraft;

import com.mojang.blaze3d.pipeline.RenderPipeline;

import dev.veil.api.VeilScenePass;

import net.minecraft.resources.Identifier;

import java.util.concurrent.atomic.AtomicLong;

public final class SceneRasterPipeline extends RenderPipeline {
    private static final AtomicLong NEXT_ID = new AtomicLong();
    private final RenderPipeline original;
    private final VeilScenePass.Raster raster;

    SceneRasterPipeline(RenderPipeline original, VeilScenePass.Raster raster) {
        super(
                Identifier.fromNamespaceAndPath(
                        "veil", "scene_raster/" + NEXT_ID.incrementAndGet()),
                original.getVertexShader(),
                original.getFragmentShader(),
                original.getShaderDefines(),
                original.getBindGroupLayouts(),
                original.getColorTargetStates().clone(),
                original.getDepthStencilState(),
                original.getPolygonMode(),
                original.isCull(),
                original.getVertexFormatBindings().clone(),
                original.getPrimitiveTopology(),
                original.getSortKey());
        this.original = original;
        this.raster = raster;
    }

    public RenderPipeline original() {
        return original;
    }

    public VeilScenePass.Raster raster() {
        return raster;
    }
}
