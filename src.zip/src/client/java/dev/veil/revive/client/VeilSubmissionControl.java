package dev.veil.revive.client;

import java.util.Locale;

public final class VeilSubmissionControl {
    public enum Mode {
        AUTO,
        DIRECT_DRAWS,
        DIRECT_MDI,
        DIRECT_MULTIDRAW,
        FRUSTUM_MDI;

        public String telemetryName() {
            return name().toLowerCase(Locale.ROOT);
        }
    }

    private static volatile Mode benchmarkOverride;

    private VeilSubmissionControl() {}

    public static Mode effectiveMode() {
        Mode override = benchmarkOverride;
        if (dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment()
                && Boolean.getBoolean("veil.directMultiProbe")) return Mode.DIRECT_MULTIDRAW;
        if (override != null) return override;
        String configured = VeilVideoConfig.value("renderer.submissionMode", "AUTO");
        try {
            return Mode.valueOf(configured.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            return Mode.AUTO;
        }
    }

    static void setBenchmarkOverride(Mode mode) {
        benchmarkOverride = mode;
    }

    static void clearBenchmarkOverride() {
        benchmarkOverride = null;
    }

    static boolean benchmarkOverrideActive() {
        return benchmarkOverride != null;
    }
}
