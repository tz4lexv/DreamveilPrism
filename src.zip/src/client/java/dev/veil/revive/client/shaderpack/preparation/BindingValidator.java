package dev.veil.revive.client.shaderpack.preparation;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilResourceUsage;
import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderInterface;
import dev.veil.revive.client.VeilShaderPack.Binding;
import dev.veil.revive.client.VeilShaderPack.BindingAccess;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.Resource;

import java.util.LinkedHashMap;

public final class BindingValidator {
    private BindingValidator() {}

    public static VeilShaderInterface pipelineInterface(
            Pass pass, VeilShaderInterface shaderInterface) {
        var counts = new LinkedHashMap<Integer, Integer>();
        for (var descriptor : shaderInterface.descriptors()) {
            if (!descriptor.runtimeArray()) continue;
            Binding binding = pass.bindings().get(descriptor.binding());
            if (binding == null)
                throw new IllegalArgumentException(
                        "Missing runtime descriptor binding " + descriptor.binding());
            counts.put(descriptor.binding(), binding.resources().size());
        }
        VeilShaderInterface resolved =
                counts.isEmpty()
                        ? shaderInterface
                        : shaderInterface.resolveRuntimeDescriptorArrays(counts);
        int descriptors =
                resolved.descriptors().stream()
                        .filter(value -> value.set() == 0)
                        .mapToInt(VeilShaderInterface.Descriptor::descriptorCount)
                        .sum();
        if (descriptors > 32) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + " requires "
                            + descriptors
                            + " push descriptors; the portable creator limit is 32");
        }
        return resolved;
    }

    public static VeilRenderGraph.Access validateDescriptorResource(
            Pass pass,
            VeilShaderInterface.Descriptor descriptor,
            Binding binding,
            Resource resource,
            java.util.function.ToLongFunction<String> hostBytes,
            java.util.function.Predicate<String> generalSampler) {
        if (resource.kind() == VeilRenderGraph.Kind.BUFFER) {
            if (dev.veil.revive.client.VeilSurfaceTransforms.HOST_ID.equals(resource.hostId())
                    && (binding.access() != BindingAccess.READ
                            || binding.offset() != 0
                            || binding.range() != 0))
                throw new IllegalArgumentException(
                        "Surface transforms require a complete read-only binding");
            boolean rayScene = resource.raySceneAsset() || resource.worldRayScene();
            if (rayScene && binding.access() != BindingAccess.READ)
                throw new IllegalArgumentException(
                        "Ray scene assets are read-only: " + resource.name());
            if (descriptor.descriptorType()
                    == org.lwjgl.vulkan.KHRAccelerationStructure
                            .VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR) {
                if (!rayScene
                        || binding.offset() != 0
                        || binding.range() != 0
                        || binding.previous()
                        || binding.resources().size() != 1
                        || descriptor.runtimeArray()
                        || descriptor.descriptorCount() != 1) {
                    throw new IllegalArgumentException(
                            "Ray query binding requires one .veilrt.json asset or minecraft:ray_world host resource");
                }
                return pass.compute()
                        ? VeilRenderGraph.Access.COMPUTE_READ
                        : pass.raytrace()
                                ? VeilRenderGraph.Access.RAY_READ
                                : VeilRenderGraph.Access.FRAGMENT_READ;
            }
            boolean uniform = descriptor.descriptorType() == VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
            if (descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_STORAGE_BUFFER && !uniform) {
                throw new IllegalArgumentException(
                        "Pass "
                                + pass.name()
                                + " binding="
                                + descriptor.binding()
                                + " resource="
                                + resource.name()
                                + " requires a storage or uniform buffer descriptor");
            }
            if (uniform
                    && (!resource.usages().contains(VeilResourceUsage.UNIFORM)
                            || binding.access() != BindingAccess.READ)) {
                throw new IllegalArgumentException(
                        "Uniform buffer descriptors require read-only uniform usage: "
                                + resource.name());
            }
            if (!uniform && !resource.usages().contains(VeilResourceUsage.STORAGE)) {
                throw new IllegalArgumentException(
                        "Storage buffer descriptor requires storage usage: " + resource.name());
            }
            long availableBytes =
                    resource.hostImport()
                            ? hostBytes.applyAsLong(resource.hostId())
                            : resource.bytes();
            availableBytes = binding.resolvedBufferRange(availableBytes);
            if (availableBytes < descriptor.minimumBufferSize()) {
                throw new IllegalArgumentException(
                        "Pass "
                                + pass.name()
                                + " binding="
                                + descriptor.binding()
                                + ": buffer too small; required="
                                + descriptor.minimumBufferSize()
                                + " actual="
                                + availableBytes);
            }
            if (!uniform) validateAccessQualifier(pass, descriptor, binding);
            boolean otherGraphicsStages =
                    !pass.compute()
                            && !pass.raytrace()
                            && (descriptor.stageFlags() & ~VK_SHADER_STAGE_FRAGMENT_BIT) != 0;
            if (uniform)
                return pass.compute()
                        ? VeilRenderGraph.Access.COMPUTE_UNIFORM_READ
                        : pass.raytrace()
                                ? VeilRenderGraph.Access.RAY_UNIFORM_READ
                                : otherGraphicsStages
                                        ? VeilRenderGraph.Access.GRAPHICS_UNIFORM_READ
                                        : VeilRenderGraph.Access.FRAGMENT_UNIFORM_READ;
            if (otherGraphicsStages)
                return switch (binding.access()) {
                    case READ -> VeilRenderGraph.Access.GRAPHICS_BUFFER_READ;
                    case WRITE -> VeilRenderGraph.Access.GRAPHICS_BUFFER_WRITE;
                    case READ_WRITE -> VeilRenderGraph.Access.GRAPHICS_BUFFER_READ_WRITE;
                };
            return pass.compute()
                    ? switch (binding.access()) {
                        case READ -> VeilRenderGraph.Access.COMPUTE_READ;
                        case WRITE -> VeilRenderGraph.Access.COMPUTE_WRITE;
                        case READ_WRITE -> VeilRenderGraph.Access.COMPUTE_READ_WRITE;
                    }
                    : pass.raytrace()
                            ? switch (binding.access()) {
                                case READ -> VeilRenderGraph.Access.RAY_READ;
                                case WRITE -> VeilRenderGraph.Access.RAY_WRITE;
                                case READ_WRITE -> VeilRenderGraph.Access.RAY_READ_WRITE;
                            }
                            : switch (binding.access()) {
                                case READ -> VeilRenderGraph.Access.FRAGMENT_READ;
                                case WRITE -> VeilRenderGraph.Access.FRAGMENT_WRITE;
                                case READ_WRITE -> VeilRenderGraph.Access.FRAGMENT_READ_WRITE;
                            };
        }
        if (descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                && descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_STORAGE_IMAGE) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + " binding="
                            + descriptor.binding()
                            + " resource="
                            + resource.name()
                            + " expected sampled/storage image descriptor, actualType="
                            + descriptor.descriptorType());
        }
        int dimension =
                resource.image1d()
                        ? org.lwjgl.util.spvc.Spv.SpvDim1D
                        : resource.image3d()
                                ? org.lwjgl.util.spvc.Spv.SpvDim3D
                                : resource.cubemap()
                                        ? org.lwjgl.util.spvc.Spv.SpvDimCube
                                        : org.lwjgl.util.spvc.Spv.SpvDim2D;
        int storageFormat =
                descriptor.descriptorType() == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE
                        ? storageImageFormat(resource.format())
                        : org.lwjgl.util.spvc.Spv.SpvImageFormatUnknown;
        var expectedImage =
                new VeilShaderInterface.ImageType(
                        dimension,
                        resource.image1dArray() || resource.image2dArray() || resource.cubeArray(),
                        false,
                        descriptor.descriptorType() == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                                && resource.sampler().compare() != null,
                        imageBaseType(resource),
                        storageFormat);
        if (!expectedImage.equals(descriptor.imageType())) {
            String scalar =
                    switch (imageBaseType(resource)) {
                        case org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_UINT32 -> "unsigned-integer";
                        case org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_INT32 -> "signed-integer";
                        default -> "floating-point";
                    };
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + " binding="
                            + descriptor.binding()
                            + ": resource "
                            + resource.name()
                            + " requires a "
                            + scalar
                            + " "
                            + (resource.image1d()
                                    ? resource.image1dArray()
                                            ? "sampler1DArray/image1DArray descriptor"
                                            : "sampler1D/image1D descriptor"
                                    : resource.image3d()
                                            ? "sampler3D/image3D descriptor"
                                            : resource.cubemap()
                                                    ? resource.cubeArray()
                                                            ? "samplerCubeArray/imageCubeArray descriptor"
                                                            : "samplerCube/imageCube descriptor"
                                                    : resource.image2dArray()
                                                            ? "sampler2DArray/image2DArray descriptor"
                                                            : "sampler2D/image2D descriptor"));
        }
        if (descriptor.descriptorType() == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER) {
            if (binding.access() != BindingAccess.READ)
                throw new IllegalArgumentException(
                        "Sampled image bindings are read-only: " + resource.name());
            if (generalSampler.test(resource.hostId())) {
                return pass.compute()
                        ? VeilRenderGraph.Access.COMPUTE_SAMPLE_GENERAL
                        : pass.raytrace()
                                ? VeilRenderGraph.Access.RAY_SAMPLE_GENERAL
                                : VeilRenderGraph.Access.FRAGMENT_SAMPLE_GENERAL;
            }
            return pass.compute()
                    ? VeilRenderGraph.Access.COMPUTE_SAMPLE
                    : pass.raytrace()
                            ? VeilRenderGraph.Access.RAY_SAMPLE
                            : VeilRenderGraph.Access.FRAGMENT_SAMPLE;
        }
        if (!resource.storageImage()) {
            throw new IllegalArgumentException(
                    "Storage image descriptor requires a Veil storageImage2d/storageImage2dArray/storageImage3d resource: "
                            + resource.name());
        }
        validateAccessQualifier(pass, descriptor, binding);
        return pass.compute()
                ? switch (binding.access()) {
                    case READ -> VeilRenderGraph.Access.COMPUTE_IMAGE_READ;
                    case WRITE -> VeilRenderGraph.Access.COMPUTE_IMAGE_WRITE;
                    case READ_WRITE -> VeilRenderGraph.Access.COMPUTE_IMAGE_READ_WRITE;
                }
                : pass.raytrace()
                        ? switch (binding.access()) {
                            case READ -> VeilRenderGraph.Access.RAY_IMAGE_READ;
                            case WRITE -> VeilRenderGraph.Access.RAY_IMAGE_WRITE;
                            case READ_WRITE -> VeilRenderGraph.Access.RAY_IMAGE_READ_WRITE;
                        }
                        : switch (binding.access()) {
                            case READ -> VeilRenderGraph.Access.FRAGMENT_IMAGE_READ;
                            case WRITE -> VeilRenderGraph.Access.FRAGMENT_IMAGE_WRITE;
                            case READ_WRITE -> VeilRenderGraph.Access.FRAGMENT_IMAGE_READ_WRITE;
                        };
    }

    public static VeilRenderGraph.Subresource graphSubresource(
            VeilShaderInterface.Descriptor descriptor, Binding binding, Resource resource) {
        if (resource.kind() == VeilRenderGraph.Kind.BUFFER)
            return resource.hostImport()
                            || descriptor.descriptorType()
                                    == org.lwjgl.vulkan.KHRAccelerationStructure
                                            .VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR
                            || binding.offset() == 0
                                    && binding.writes()
                                    && binding.resolvedBufferRange(resource.bytes())
                                            == resource.bytes()
                    ? VeilRenderGraph.Subresource.WHOLE
                    : VeilRenderGraph.Subresource.buffer(
                            binding.offset(), binding.resolvedBufferRange(resource.bytes()));
        int mipBase;
        int mipCount;
        if (!resource.nativeImage()) {
            mipBase = 0;
            mipCount = 1;
        } else {
            boolean storageDescriptor =
                    descriptor.descriptorType() == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
            int selected = binding.selectedMip(storageDescriptor);
            if (selected >= 0) {
                mipBase = selected;
                mipCount = 1;
            } else {
                mipBase = 0;
                mipCount = resource.mipLevels();
            }
        }
        int availableLayers =
                resource.image1dArray() || resource.image2dArray() || resource.cubemap()
                        ? resource.layers()
                        : 1;
        int layerBase = binding.baseLayer();
        int layerCount =
                binding.layerCount() == 0 ? availableLayers - layerBase : binding.layerCount();
        return VeilRenderGraph.Subresource.image(mipBase, mipCount, layerBase, layerCount);
    }

    private static VeilRenderGraph.Subresource fullImageSubresource(Resource resource) {
        int levels = Math.max(1, resource.mipLevels());
        int layers =
                resource.image1dArray() || resource.image2dArray() || resource.cubemap()
                        ? resource.layers()
                        : 1;
        return VeilRenderGraph.Subresource.image(0, levels, 0, layers);
    }

    public static void validateAttachmentSubresource(Resource resource, int mip, int layer) {
        int mipLevels = resource.hostImport() ? 1 : resource.mipLevels();
        int layers =
                resource.hostImport()
                        ? 1
                        : resource.image1dArray() || resource.image2dArray() || resource.cubemap()
                                ? resource.layers()
                                : 1;
        if (mip < 0 || mip >= mipLevels || layer < 0 || layer >= layers) {
            throw new IllegalArgumentException("Attachment subresource exceeds " + resource.name());
        }
        if (resource.image3d())
            throw new IllegalArgumentException(
                    "3D images cannot be graphics attachments: " + resource.name());
    }

    public static void validateSubresource(
            Pass pass,
            VeilShaderInterface.Descriptor descriptor,
            Binding binding,
            Resource resource) {
        if (resource.kind() != VeilRenderGraph.Kind.IMAGE) {
            if (binding.mip() >= 0 || binding.baseLayer() != 0 || binding.layerCount() != 0) {
                throw new IllegalArgumentException(
                        "Buffer binding cannot select image subresources: " + resource.name());
            }
            return;
        }
        if (binding.offset() != 0 || binding.range() != 0)
            throw new IllegalArgumentException(
                    "Image binding cannot select buffer offsets/ranges: " + resource.name());
        if ((binding.mip() >= 0 || binding.baseLayer() != 0 || binding.layerCount() != 0)
                && !resource.nativeImage()) {
            throw new IllegalArgumentException(
                    "Explicit mip/layer views require a Veil-owned texture/storage image: "
                            + resource.name());
        }
        boolean storageDescriptor = descriptor.descriptorType() == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
        int mip = binding.selectedMip(storageDescriptor);
        if (mip >= resource.mipLevels()) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + " binding="
                            + descriptor.binding()
                            + ": mip "
                            + mip
                            + " exceeds resource "
                            + resource.name()
                            + " mipLevels="
                            + resource.mipLevels());
        }
        if (resource.cubemap()
                && !resource.cubeArray()
                && (binding.baseLayer() != 0 || binding.layerCount() != 0)) {
            throw new IllegalArgumentException(
                    "Cubemap descriptors must bind all six faces: " + resource.name());
        }
        if (!resource.image1dArray()
                && !resource.image2dArray()
                && !resource.cubemap()
                && (binding.baseLayer() != 0 || binding.layerCount() > 1)) {
            throw new IllegalArgumentException(
                    "Layer subresource selection requires image2DArray: " + resource.name());
        }
        int availableLayers =
                resource.image1dArray() || resource.image2dArray() || resource.cubemap()
                        ? resource.layers()
                        : 1;
        int count =
                binding.layerCount() == 0
                        ? availableLayers - binding.baseLayer()
                        : binding.layerCount();
        if (binding.baseLayer() >= availableLayers
                || count < 1
                || (long) binding.baseLayer() + count > availableLayers) {
            throw new IllegalArgumentException("Invalid array layer range for " + resource.name());
        }
        if (resource.cubeArray() && count % 6 != 0)
            throw new IllegalArgumentException(
                    "Cubemap array views require a multiple of six layers: " + resource.name());
    }

    public static boolean subresourcesOverlap(Binding a, Binding b, Resource resource) {
        if (resource.kind() == VeilRenderGraph.Kind.BUFFER) {
            if (resource.hostImport()) return true;
            return VeilRenderGraph.Subresource.buffer(
                            a.offset(), a.resolvedBufferRange(resource.bytes()))
                    .overlaps(
                            VeilRenderGraph.Subresource.buffer(
                                    b.offset(), b.resolvedBufferRange(resource.bytes())));
        }
        int mipA = a.selectedMip(true), mipB = b.selectedMip(true);
        if (mipA != mipB) return false;
        int layers =
                resource.image1dArray() || resource.image2dArray() || resource.cubemap()
                        ? resource.layers()
                        : 1;
        int aCount = a.layerCount() == 0 ? layers - a.baseLayer() : a.layerCount();
        int bCount = b.layerCount() == 0 ? layers - b.baseLayer() : b.layerCount();
        return a.baseLayer() < b.baseLayer() + bCount && b.baseLayer() < a.baseLayer() + aCount;
    }

    private static void validateAccessQualifier(
            Pass pass, VeilShaderInterface.Descriptor descriptor, Binding binding) {
        boolean valid =
                switch (binding.access()) {
                    case READ -> descriptor.readable() && !descriptor.writable();
                    case WRITE -> !descriptor.readable() && descriptor.writable();
                    case READ_WRITE -> descriptor.readable() && descriptor.writable();
                };
        if (!valid) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + " binding="
                            + descriptor.binding()
                            + ": shader access qualifiers do not match manifest access="
                            + binding.access().name().toLowerCase());
        }
    }

    private static int imageBaseType(Resource resource) {
        if (resource.format() == null) return org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_FP32;
        return switch (resource.format().numericType()) {
            case UINT, STENCIL -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_UINT32;
            case SINT -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_INT32;
            default -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_FP32;
        };
    }

    private static int storageImageFormat(VeilFormat format) {
        return switch (format.name()) {
            case "R8_UNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR8;
            case "RG8_UNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg8;
            case "RGBA8_UNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba8;
            case "R8_SNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR8Snorm;
            case "RG8_SNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg8Snorm;
            case "RGBA8_SNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba8Snorm;
            case "R16_UNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR16;
            case "RG16_UNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg16;
            case "RGBA16_UNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba16;
            case "R16_SNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR16Snorm;
            case "RG16_SNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg16Snorm;
            case "RGBA16_SNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba16Snorm;
            case "R8_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR8i;
            case "RG8_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg8i;
            case "RGBA8_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba8i;
            case "R16_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR16i;
            case "RG16_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg16i;
            case "RGBA16_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba16i;
            case "R32_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR32i;
            case "RG32_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg32i;
            case "RGBA32_SINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba32i;
            case "R8_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR8ui;
            case "RG8_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg8ui;
            case "RGBA8_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba8ui;
            case "R16_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR16ui;
            case "RG16_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg16ui;
            case "RGBA16_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba16ui;
            case "R32_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR32ui;
            case "RG32_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg32ui;
            case "RGBA32_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba32ui;
            case "R16_FLOAT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR16f;
            case "RG16_FLOAT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg16f;
            case "RGBA16_FLOAT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba16f;
            case "R32_FLOAT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR32f;
            case "RG32_FLOAT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRg32f;
            case "RGBA32_FLOAT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgba32f;
            case "RGB10A2_UNORM" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgb10A2;
            case "RGB10A2_UINT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatRgb10a2ui;
            case "RG11B10_FLOAT" -> org.lwjgl.util.spvc.Spv.SpvImageFormatR11fG11fB10f;

            default ->
                    throw new IllegalArgumentException(
                            "GpuFormat cannot be represented as a typed SPIR-V storage image: "
                                    + format);
        };
    }
}
