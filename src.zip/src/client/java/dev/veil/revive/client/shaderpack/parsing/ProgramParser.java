package dev.veil.revive.client.shaderpack.parsing;

import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.asset;
import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.fields;
import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.object;
import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.resourceName;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import dev.veil.revive.client.VeilShaderId;
import dev.veil.revive.client.VeilShaderStage;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ProgramParser {
    private ProgramParser() {}

    public static Map<VeilShaderId, Map<VeilShaderStage, VeilShaderId>> parsePrograms(
            JsonObject root, String namespace) {
        var programs = new LinkedHashMap<VeilShaderId, Map<VeilShaderStage, VeilShaderId>>();
        for (var entry : object(root, "programs").entrySet()) {
            var stages = new EnumMap<VeilShaderStage, VeilShaderId>(VeilShaderStage.class);
            for (var stage : entry.getValue().getAsJsonObject().entrySet()) {
                VeilShaderStage kind = stage(stage.getKey());
                JsonElement declaration = stage.getValue();
                if (declaration.isJsonObject()) {
                    fields(declaration.getAsJsonObject(), "source", "entry");
                    if (root.get("abi").getAsInt() < 18)
                        throw new IllegalArgumentException(
                                "Shader entry point objects require ABI 18");
                }
                String path =
                        declaration.isJsonObject()
                                ? declaration.getAsJsonObject().get("source").getAsString()
                                : declaration.getAsString();
                String extension =
                        switch (kind) {
                            case VERTEX -> ".vert";
                            case TESS_CONTROL -> ".tesc";
                            case TESS_EVALUATION -> ".tese";
                            case GEOMETRY -> ".geom";
                            case FRAGMENT -> ".frag";
                            case COMPUTE -> ".comp";
                            case RAYGEN -> ".rgen";
                            case MISS -> ".rmiss";
                            case CLOSEST_HIT -> ".rchit";
                            case ANY_HIT -> ".rahit";
                            case INTERSECTION -> ".rint";
                            case CALLABLE -> ".rcall";
                        };
                if (!path.endsWith(extension)
                        && !path.endsWith(".spv")
                        && !path.endsWith(".slang")) {
                    throw new IllegalArgumentException(
                            "Shader " + path + " requires " + extension + " or .spv or .slang");
                }
                stages.put(kind, asset(namespace, path));
            }
            programs.put(asset(namespace, resourceName(entry.getKey())), stages);
        }
        return programs;
    }

    public static Map<VeilShaderId, Map<VeilShaderStage, String>> parseEntryPoints(
            JsonObject root, String namespace) {
        var result = new LinkedHashMap<VeilShaderId, Map<VeilShaderStage, String>>();
        for (var program : object(root, "programs").entrySet()) {
            var entries = new EnumMap<VeilShaderStage, String>(VeilShaderStage.class);
            for (var item : program.getValue().getAsJsonObject().entrySet()) {
                if (!item.getValue().isJsonObject()) continue;
                var value = item.getValue().getAsJsonObject();
                String source = value.get("source").getAsString();
                String entry = value.has("entry") ? value.get("entry").getAsString() : "main";
                if (!entry.matches("[A-Za-z_][A-Za-z0-9_]*"))
                    throw new IllegalArgumentException("Invalid shader entry point " + entry);
                if (!entry.equals("main") && !source.endsWith(".slang") && !source.endsWith(".spv"))
                    throw new IllegalArgumentException(
                            "Named entry points require Slang or SPIR-V");
                entries.put(stage(item.getKey()), entry);
            }
            if (!entries.isEmpty())
                result.put(asset(namespace, resourceName(program.getKey())), entries);
        }
        return result;
    }

    public static VeilShaderStage stage(String name) {
        return switch (name) {
            case "vertex" -> VeilShaderStage.VERTEX;
            case "tessControl" -> VeilShaderStage.TESS_CONTROL;
            case "tessEvaluation" -> VeilShaderStage.TESS_EVALUATION;
            case "geometry" -> VeilShaderStage.GEOMETRY;
            case "fragment" -> VeilShaderStage.FRAGMENT;
            case "compute" -> VeilShaderStage.COMPUTE;
            case "raygen" -> VeilShaderStage.RAYGEN;
            case "miss" -> VeilShaderStage.MISS;
            case "closestHit" -> VeilShaderStage.CLOSEST_HIT;
            case "anyHit" -> VeilShaderStage.ANY_HIT;
            case "intersection" -> VeilShaderStage.INTERSECTION;
            case "callable" -> VeilShaderStage.CALLABLE;
            default -> throw new IllegalArgumentException("Unsupported shader stage: " + name);
        };
    }
}
