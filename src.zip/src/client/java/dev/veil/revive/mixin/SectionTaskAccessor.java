package dev.veil.revive.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.concurrent.atomic.AtomicBoolean;

@Mixin(
        targets =
                "net.minecraft.client.renderer.chunk.SectionRenderDispatcher$RenderSection$SectionTask")
public interface SectionTaskAccessor {
    @Invoker("getRenderOrigin")
    net.minecraft.core.BlockPos veil$getRenderOrigin();

    @Accessor("isCancelled")
    AtomicBoolean veil$isCancelled();

    @Accessor("isRecompile")
    boolean veil$isRecompile();
}
