package dev.veil.revive.client;

import static org.lwjgl.util.spvc.Spv.*;
import static org.lwjgl.util.spvc.Spvc.*;
import static org.lwjgl.vulkan.KHRAccelerationStructure.VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR;
import static org.lwjgl.vulkan.VK10.*;

import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.spvc.SpvcReflectedResource;
import org.lwjgl.util.spvc.SpvcSpecializationConstant;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

public final class VeilSpirvReflection {
    private VeilSpirvReflection() {}

    public static VeilShaderInterface reflect(VeilSpirvBinary binary) {
        if (binary == null) throw new NullPointerException("binary");
        try (MemoryStack stack = MemoryStack.stackPush()) {
            PointerBuffer contextOut = stack.mallocPointer(1);
            check(SPVC_SUCCESS, spvc_context_create(contextOut), 0L, "spvc_context_create");
            long context = contextOut.get(0);
            try {
                byte[] code = binary.unsafeCode();
                if ((code.length & 3) != 0 || code.length == 0) {
                    throw new IllegalArgumentException(
                            "Invalid SPIR-V byte length "
                                    + code.length
                                    + " for "
                                    + binary.sourceName());
                }
                PointerBuffer irOut = stack.mallocPointer(1);
                ByteBuffer nativeBytes =
                        MemoryUtil.memAlloc(code.length).order(ByteOrder.nativeOrder());
                try {
                    nativeBytes.put(code).flip();
                    IntBuffer words = nativeBytes.asIntBuffer();
                    check(
                            SPVC_SUCCESS,
                            spvc_context_parse_spirv(context, words, words.remaining(), irOut),
                            context,
                            "spvc_context_parse_spirv(" + binary.sourceName() + ")");
                } finally {
                    MemoryUtil.memFree(nativeBytes);
                }

                PointerBuffer compilerOut = stack.mallocPointer(1);
                check(
                        SPVC_SUCCESS,
                        spvc_context_create_compiler(
                                context,
                                SPVC_BACKEND_NONE,
                                irOut.get(0),
                                SPVC_CAPTURE_MODE_TAKE_OWNERSHIP,
                                compilerOut),
                        context,
                        "spvc_context_create_compiler(" + binary.sourceName() + ")");
                long compiler = compilerOut.get(0);
                int executionModel =
                        switch (binary.stage()) {
                            case VERTEX -> SpvExecutionModelVertex;
                            case TESS_CONTROL -> SpvExecutionModelTessellationControl;
                            case TESS_EVALUATION -> SpvExecutionModelTessellationEvaluation;
                            case GEOMETRY -> SpvExecutionModelGeometry;
                            case FRAGMENT -> SpvExecutionModelFragment;
                            case COMPUTE -> SpvExecutionModelGLCompute;
                            case RAYGEN -> SpvExecutionModelRayGenerationKHR;
                            case MISS -> SpvExecutionModelMissKHR;
                            case CLOSEST_HIT -> SpvExecutionModelClosestHitKHR;
                            case ANY_HIT -> SpvExecutionModelAnyHitKHR;
                            case INTERSECTION -> SpvExecutionModelIntersectionKHR;
                            case CALLABLE -> SpvExecutionModelCallableKHR;
                        };
                check(
                        SPVC_SUCCESS,
                        spvc_compiler_set_entry_point(
                                compiler, binary.entryPoint(), executionModel),
                        context,
                        "spvc_compiler_set_entry_point("
                                + binary.sourceName()
                                + ", "
                                + binary.entryPoint()
                                + ", "
                                + binary.stage()
                                + ")");

                PointerBuffer activeOut = stack.mallocPointer(1);
                check(
                        SPVC_SUCCESS,
                        spvc_compiler_get_active_interface_variables(compiler, activeOut),
                        context,
                        "spvc_compiler_get_active_interface_variables");
                PointerBuffer resourcesOut = stack.mallocPointer(1);
                check(
                        SPVC_SUCCESS,
                        spvc_compiler_create_shader_resources_for_active_variables(
                                compiler, resourcesOut, activeOut.get(0)),
                        context,
                        "spvc_compiler_create_shader_resources(" + binary.sourceName() + ")");
                long resources = resourcesOut.get(0);
                int stageFlags = binary.stage().vkStageFlags();

                List<VeilShaderInterface.Descriptor> descriptors = new ArrayList<>();
                reflectDescriptors(
                        stack,
                        context,
                        compiler,
                        resources,
                        SPVC_RESOURCE_TYPE_UNIFORM_BUFFER,
                        VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
                        stageFlags,
                        descriptors);
                reflectDescriptors(
                        stack,
                        context,
                        compiler,
                        resources,
                        SPVC_RESOURCE_TYPE_STORAGE_BUFFER,
                        VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,
                        stageFlags,
                        descriptors);
                reflectDescriptors(
                        stack,
                        context,
                        compiler,
                        resources,
                        SPVC_RESOURCE_TYPE_SAMPLED_IMAGE,
                        VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
                        stageFlags,
                        descriptors);
                reflectDescriptors(
                        stack,
                        context,
                        compiler,
                        resources,
                        SPVC_RESOURCE_TYPE_SEPARATE_IMAGE,
                        VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE,
                        stageFlags,
                        descriptors);
                reflectDescriptors(
                        stack,
                        context,
                        compiler,
                        resources,
                        SPVC_RESOURCE_TYPE_SEPARATE_SAMPLERS,
                        VK_DESCRIPTOR_TYPE_SAMPLER,
                        stageFlags,
                        descriptors);
                reflectDescriptors(
                        stack,
                        context,
                        compiler,
                        resources,
                        SPVC_RESOURCE_TYPE_STORAGE_IMAGE,
                        VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,
                        stageFlags,
                        descriptors);
                reflectDescriptors(
                        stack,
                        context,
                        compiler,
                        resources,
                        SPVC_RESOURCE_TYPE_SUBPASS_INPUT,
                        VK_DESCRIPTOR_TYPE_INPUT_ATTACHMENT,
                        stageFlags,
                        descriptors);
                reflectDescriptors(
                        stack,
                        context,
                        compiler,
                        resources,
                        SPVC_RESOURCE_TYPE_ACCELERATION_STRUCTURE,
                        VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR,
                        stageFlags,
                        descriptors);

                rejectNonVulkanResourceKind(
                        stack,
                        context,
                        resources,
                        SPVC_RESOURCE_TYPE_ATOMIC_COUNTER,
                        "atomic counters");
                rejectNonVulkanResourceKind(
                        stack,
                        context,
                        resources,
                        SPVC_RESOURCE_TYPE_GL_PLAIN_UNIFORM,
                        "GL plain uniforms");

                List<VeilShaderInterface.PushConstant> pushConstants =
                        reflectPushConstants(stack, context, compiler, resources, stageFlags);
                List<VeilShaderInterface.StageIo> inputs =
                        reflectStageIo(
                                stack,
                                context,
                                compiler,
                                resources,
                                SPVC_RESOURCE_TYPE_STAGE_INPUT,
                                stageFlags);
                List<VeilShaderInterface.StageIo> outputs =
                        reflectStageIo(
                                stack,
                                context,
                                compiler,
                                resources,
                                SPVC_RESOURCE_TYPE_STAGE_OUTPUT,
                                stageFlags);
                List<VeilShaderInterface.SpecializationConstant> specs =
                        reflectSpecializationConstants(stack, context, compiler, stageFlags);

                return new VeilShaderInterface(descriptors, pushConstants, inputs, outputs, specs);
            } finally {
                spvc_context_destroy(context);
            }
        }
    }

    private static void reflectDescriptors(
            MemoryStack stack,
            long context,
            long compiler,
            long resources,
            int resourceType,
            int descriptorType,
            int stageFlags,
            List<VeilShaderInterface.Descriptor> out) {
        SpvcReflectedResource.Buffer reflected = resources(stack, context, resources, resourceType);
        if (reflected == null) return;
        for (SpvcReflectedResource resource : reflected) {
            if (!spvc_compiler_has_decoration(compiler, resource.id(), SpvDecorationDescriptorSet)
                    || !spvc_compiler_has_decoration(
                            compiler, resource.id(), SpvDecorationBinding)) {
                throw new IllegalStateException(
                        "Native Vulkan shader resource '"
                                + safeName(resource)
                                + "' is missing explicit descriptor set/binding decorations");
            }
            int set =
                    spvc_compiler_get_decoration(
                            compiler, resource.id(), SpvDecorationDescriptorSet);
            int binding =
                    spvc_compiler_get_decoration(compiler, resource.id(), SpvDecorationBinding);
            long type = spvc_compiler_get_type_handle(compiler, resource.type_id());
            ArrayInfo array = descriptorArrayInfo(type);
            int actualDescriptorType = descriptorType;
            if (descriptorType == VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE
                    || descriptorType == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                    || descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE) {
                if (spvc_type_get_image_dimension(type) == SpvDimBuffer) {
                    actualDescriptorType =
                            descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE
                                    ? VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER
                                    : VK_DESCRIPTOR_TYPE_UNIFORM_TEXEL_BUFFER;
                }
            }
            long minimumSize = 0;
            VeilShaderInterface.ImageType imageType = null;
            if (actualDescriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
                    || actualDescriptorType == VK_DESCRIPTOR_TYPE_STORAGE_BUFFER) {
                PointerBuffer size = stack.mallocPointer(1);
                check(
                        SPVC_SUCCESS,
                        spvc_compiler_get_declared_struct_size(
                                compiler,
                                spvc_compiler_get_type_handle(compiler, resource.base_type_id()),
                                size),
                        context,
                        "descriptor block size");
                minimumSize = size.get(0);
            } else if (descriptorType == VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE
                    || descriptorType == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                    || descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE) {
                long sampled =
                        spvc_compiler_get_type_handle(
                                compiler, spvc_type_get_image_sampled_type(type));
                imageType =
                        new VeilShaderInterface.ImageType(
                                spvc_type_get_image_dimension(type),
                                spvc_type_get_image_arrayed(type),
                                spvc_type_get_image_multisampled(type),
                                spvc_type_get_image_is_depth(type),
                                spvc_type_get_basetype(sampled),
                                spvc_type_get_image_storage_format(type));
            }
            out.add(
                    new VeilShaderInterface.Descriptor(
                            set,
                            binding,
                            actualDescriptorType,
                            array.count,
                            array.runtime,
                            stageFlags,
                            safeName(resource),
                            !hasAccessDecoration(compiler, resource, SpvDecorationNonReadable),
                            (actualDescriptorType == VK_DESCRIPTOR_TYPE_STORAGE_BUFFER
                                            || actualDescriptorType
                                                    == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE
                                            || actualDescriptorType
                                                    == VK_DESCRIPTOR_TYPE_STORAGE_TEXEL_BUFFER)
                                    && !hasAccessDecoration(
                                            compiler, resource, SpvDecorationNonWritable),
                            minimumSize,
                            imageType));
        }
    }

    private static boolean hasAccessDecoration(
            long compiler, SpvcReflectedResource resource, int decoration) {
        if (spvc_compiler_has_decoration(compiler, resource.id(), decoration)
                || spvc_compiler_has_decoration(compiler, resource.base_type_id(), decoration))
            return true;
        long type = spvc_compiler_get_type_handle(compiler, resource.base_type_id());
        int count = spvc_type_get_num_member_types(type);
        if (count == 0) return false;
        for (int member = 0; member < count; member++) {
            if (!spvc_compiler_has_member_decoration(
                    compiler, resource.base_type_id(), member, decoration)) return false;
        }
        return true;
    }

    private static void rejectNonVulkanResourceKind(
            MemoryStack stack, long context, long resources, int resourceType, String label) {
        SpvcReflectedResource.Buffer reflected = resources(stack, context, resources, resourceType);
        if (reflected != null && reflected.remaining() > 0) {
            throw new IllegalStateException(
                    "Veil native Vulkan shader ABI does not accept " + label);
        }
    }

    private static List<VeilShaderInterface.PushConstant> reflectPushConstants(
            MemoryStack stack, long context, long compiler, long resources, int stageFlags) {
        List<VeilShaderInterface.PushConstant> out = new ArrayList<>();
        SpvcReflectedResource.Buffer reflected =
                resources(stack, context, resources, SPVC_RESOURCE_TYPE_PUSH_CONSTANT);
        if (reflected == null) return out;
        for (SpvcReflectedResource resource : reflected) {
            long type = spvc_compiler_get_type_handle(compiler, resource.base_type_id());
            PointerBuffer sizeOut = stack.mallocPointer(1);
            check(
                    SPVC_SUCCESS,
                    spvc_compiler_get_declared_struct_size(compiler, type, sizeOut),
                    context,
                    "spvc_compiler_get_declared_struct_size(push constant)");
            long reflectedSize = sizeOut.get(0);
            if (reflectedSize <= 0 || reflectedSize > Integer.MAX_VALUE - 3) {
                throw new IllegalStateException(
                        "Invalid reflected push constant size " + reflectedSize);
            }
            int size = align4((int) reflectedSize);
            var members = new ArrayList<VeilShaderInterface.BlockMember>();
            for (int member = 0; member < spvc_type_get_num_member_types(type); member++) {
                long memberType =
                        spvc_compiler_get_type_handle(
                                compiler, spvc_type_get_member_type(type, member));
                members.add(
                        new VeilShaderInterface.BlockMember(
                                spvc_compiler_get_member_decoration(
                                        compiler,
                                        resource.base_type_id(),
                                        member,
                                        SpvDecorationOffset),
                                spvc_type_get_basetype(memberType),
                                spvc_type_get_bit_width(memberType),
                                spvc_type_get_vector_size(memberType),
                                spvc_type_get_columns(memberType),
                                fixedArrayElementCount(memberType)));
            }
            out.add(
                    new VeilShaderInterface.PushConstant(
                            0, size, stageFlags, safeName(resource), members));
        }
        return out;
    }

    private static List<VeilShaderInterface.StageIo> reflectStageIo(
            MemoryStack stack,
            long context,
            long compiler,
            long resources,
            int resourceType,
            int stageFlags) {
        List<VeilShaderInterface.StageIo> out = new ArrayList<>();
        SpvcReflectedResource.Buffer reflected = resources(stack, context, resources, resourceType);
        if (reflected == null) return out;
        for (SpvcReflectedResource resource : reflected) {
            if (spvc_compiler_has_decoration(compiler, resource.id(), SpvDecorationBuiltIn))
                continue;
            if (!spvc_compiler_has_decoration(compiler, resource.id(), SpvDecorationLocation)) {
                throw new IllegalArgumentException(
                        "Stage interface blocks with member locations are not supported: "
                                + safeName(resource));
            }
            if (spvc_compiler_has_decoration(compiler, resource.id(), SpvDecorationIndex)
                    && spvc_compiler_get_decoration(compiler, resource.id(), SpvDecorationIndex)
                            != 0) {
                throw new IllegalArgumentException(
                        "Dual-source fragment outputs are not supported: " + safeName(resource));
            }
            int location =
                    spvc_compiler_get_decoration(compiler, resource.id(), SpvDecorationLocation);
            int component =
                    spvc_compiler_has_decoration(compiler, resource.id(), SpvDecorationComponent)
                            ? spvc_compiler_get_decoration(
                                    compiler, resource.id(), SpvDecorationComponent)
                            : 0;
            long type = spvc_compiler_get_type_handle(compiler, resource.type_id());
            if (spvc_type_get_basetype(type) == SPVC_BASETYPE_STRUCT
                    || spvc_type_get_num_array_dimensions(type) > 1) {
                throw new IllegalArgumentException(
                        "Structured or multidimensional stage interfaces are not supported: "
                                + safeName(resource));
            }
            int arrayElements = fixedArrayElementCount(type);
            out.add(
                    new VeilShaderInterface.StageIo(
                            location,
                            component,
                            spvc_type_get_basetype(type),
                            spvc_type_get_bit_width(type),
                            Math.max(1, spvc_type_get_vector_size(type)),
                            Math.max(1, spvc_type_get_columns(type)),
                            arrayElements,
                            stageFlags,
                            safeName(resource)));
        }
        return out;
    }

    private static List<VeilShaderInterface.SpecializationConstant> reflectSpecializationConstants(
            MemoryStack stack, long context, long compiler, int stageFlags) {
        PointerBuffer listOut = stack.mallocPointer(1);
        PointerBuffer countOut = stack.mallocPointer(1);
        check(
                SPVC_SUCCESS,
                spvc_compiler_get_specialization_constants(compiler, listOut, countOut),
                context,
                "spvc_compiler_get_specialization_constants");
        int count = Math.toIntExact(countOut.get(0));
        if (count == 0) return List.of();
        var nativeList = SpvcSpecializationConstant.create(listOut.get(0), count);
        List<VeilShaderInterface.SpecializationConstant> out = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            var constant = nativeList.get(i);
            String name = spvc_compiler_get_name(compiler, constant.id());
            long constantHandle = spvc_compiler_get_constant_handle(compiler, constant.id());
            long type =
                    spvc_compiler_get_type_handle(compiler, spvc_constant_get_type(constantHandle));
            if (spvc_type_get_vector_size(type) != 1
                    || spvc_type_get_columns(type) != 1
                    || spvc_type_get_num_array_dimensions(type) != 0) {
                throw new IllegalArgumentException(
                        "Only scalar specialization constants are supported: ID="
                                + constant.constant_id());
            }
            out.add(
                    new VeilShaderInterface.SpecializationConstant(
                            constant.id(),
                            constant.constant_id(),
                            stageFlags,
                            name == null ? "" : name,
                            spvc_type_get_basetype(type),
                            spvc_type_get_bit_width(type)));
        }
        return out;
    }

    private static SpvcReflectedResource.Buffer resources(
            MemoryStack stack, long context, long resources, int resourceType) {
        PointerBuffer listOut = stack.mallocPointer(1);
        PointerBuffer countOut = stack.mallocPointer(1);
        check(
                SPVC_SUCCESS,
                spvc_resources_get_resource_list_for_type(
                        resources, resourceType, listOut, countOut),
                context,
                "spvc_resources_get_resource_list_for_type(" + resourceType + ")");
        int count = Math.toIntExact(countOut.get(0));
        if (count == 0) return null;
        return SpvcReflectedResource.create(listOut.get(0), count);
    }

    private static ArrayInfo descriptorArrayInfo(long type) {
        int dimensions = spvc_type_get_num_array_dimensions(type);
        if (dimensions == 0) return new ArrayInfo(1, false);
        long count = 1;
        boolean runtime = false;
        for (int dimension = 0; dimension < dimensions; dimension++) {
            if (!spvc_type_array_dimension_is_literal(type, dimension)) {
                throw new IllegalArgumentException(
                        "Specialization-sized interface or descriptor arrays are not supported");
            }
            int extent = spvc_type_get_array_dimension(type, dimension);
            if (extent <= 0) {
                runtime = true;
                continue;
            }
            count = Math.multiplyExact(count, extent);
            if (count > Integer.MAX_VALUE)
                throw new IllegalStateException("Descriptor array is too large");
        }
        return new ArrayInfo((int) Math.max(1, count), runtime);
    }

    private static int fixedArrayElementCount(long type) {
        ArrayInfo info = descriptorArrayInfo(type);
        if (info.runtime)
            throw new IllegalArgumentException("Runtime-sized stage interfaces are not supported");
        return info.count;
    }

    private static String safeName(SpvcReflectedResource resource) {
        String name = resource.nameString();
        return name == null ? "" : name;
    }

    private static int align4(int value) {
        return (value + 3) & ~3;
    }

    private static void check(int success, int result, long context, String operation) {
        if (result == success) return;
        String details = context == 0L ? null : spvc_context_get_last_error_string(context);
        throw new IllegalStateException(
                operation
                        + " failed: spvc_result="
                        + result
                        + (details == null || details.isBlank() ? "" : " (" + details + ")"));
    }

    private record ArrayInfo(int count, boolean runtime) {}
}
