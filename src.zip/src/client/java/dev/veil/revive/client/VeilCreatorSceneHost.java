package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.vkCmdCopyBuffer;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.api.VeilCreatorScene;
import dev.veil.revive.client.shaderpack.runtime.CreatorSceneRequirements;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.AABB;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkBufferCopy;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;

final class VeilCreatorSceneHost {
    static final String LIGHTS_ID = "minecraft:creator_lights";
    static final String INSTANCES_ID = "minecraft:creator_instances";
    static final String MATERIALS_ID = "minecraft:creator_materials";
    static final String GEOMETRY_ID = "minecraft:creator_geometry";
    static final int LIGHTS_CAPACITY = 128 * 1024;
    static final int INSTANCES_CAPACITY = 512 * 1024;
    static final int MATERIALS_CAPACITY = 64 * 1024;
    static final int GEOMETRY_CAPACITY = 1024 * 1024;
    private static final int LIGHT_HEADER = 48;
    private static final int LIGHT_STRIDE = 64;
    private static final int INSTANCE_HEADER = 48;
    private static final int INSTANCE_STRIDE = 80;
    private static final int MATERIAL_HEADER = 16;
    private static final int MATERIAL_STRIDE = 80;
    private static final int GEOMETRY_HEADER = 64;
    private static final int GEOMETRY_PRIMITIVE_STRIDE = 80;
    private static final int GEOMETRY_NODE_STRIDE = 32;
    private static final int LIGHT_SCAN_RADIUS = 24;
    private static final int LIGHT_SCAN_DIAMETER = LIGHT_SCAN_RADIUS * 2 + 1;
    private static final int LIGHT_SCAN_VOLUME =
            LIGHT_SCAN_DIAMETER * LIGHT_SCAN_DIAMETER * LIGHT_SCAN_DIAMETER;
    private static final int LIGHT_SCAN_BUDGET = 2048;
    private static GpuBuffer lights;
    private static GpuBuffer instances;
    private static GpuBuffer materials;
    private static GpuBuffer geometry;
    private static int originX;
    private static int originY;
    private static int originZ;
    private static int scanCenterX = Integer.MIN_VALUE;
    private static int scanCenterY;
    private static int scanCenterZ;
    private static int scanCursor;
    private static final VeilBlockLightIndex<VeilCreatorScene.Light> blockLightIndex =
            new VeilBlockLightIndex<>();
    private static ClientLevel lightWorld;
    private static long immediateLightUpdates;
    private static List<VeilCreatorScene.Light> publishedLights = List.of();
    private static long frames;
    private static long uploads;
    private static int lightCount;
    private static int instanceCount;
    private static int materialCount;
    private static int geometryPrimitiveCount;
    private static int geometryNodeCount;
    private static int geometryEntityCount;
    private static int geometryMaxDepth;
    private static int lightHash;
    private static int instanceHash;
    private static int materialHash;
    private static int geometryHash;
    private static boolean lightUploaded;
    private static boolean lightRequested;
    private static boolean instanceUploaded;
    private static boolean materialUploaded;
    private static boolean geometryUploaded;

    private VeilCreatorSceneHost() {}

    static void prepare(float sunAngle, boolean includeGeometry) {
        prepare(sunAngle, new CreatorSceneRequirements(true, true, true, includeGeometry));
    }

    static void prepare(float sunAngle, CreatorSceneRequirements requirements) {
        RenderSystem.assertOnRenderThread();
        Minecraft client = Minecraft.getInstance();
        if (client.level == null
                || client.gameRenderer == null
                || client.gameRenderer.mainCamera() == null) return;
        var camera = client.gameRenderer.mainCamera().position();
        if (lightWorld != client.level) {
            blockLightIndex.clear();
            scanCenterX = Integer.MIN_VALUE;
            scanCursor = 0;
            lightWorld = client.level;
        }
        originX = floor256(camera.x);
        originY = floor256(camera.y);
        originZ = floor256(camera.z);
        ensureBuffers(requirements);
        if (requirements.lights() && !lightRequested) lightUploaded = false;
        lightRequested = requirements.lights();
        if (requirements.lights()) {
            scanLights(
                    client,
                    (int) Math.floor(camera.x),
                    (int) Math.floor(camera.y),
                    (int) Math.floor(camera.z));
        }
        byte[] lightBytes =
                requirements.lights() ? encodeLights(sunAngle, camera.x, camera.y, camera.z) : null;
        CapturedInstances captured =
                requirements.capturesEntities()
                        ? captureInstances(client, requirements.geometry())
                        : null;
        byte[] instanceBytes =
                requirements.instances() ? encodeInstances(captured.instances()) : null;
        byte[] geometryBytes =
                requirements.geometry()
                        ? encodeGeometry(captured.geometry(), captured.entityCount())
                        : null;
        byte[] materialBytes = requirements.materials() ? encodeMaterials() : null;
        int nextLightHash = Arrays.hashCode(lightBytes);
        if (lightBytes != null
                && (!lightUploaded || frames % 2 == 0 && nextLightHash != lightHash)) {
            upload(lights, lightBytes, "Veil creator lights upload");
            lightHash = nextLightHash;
            lightUploaded = true;
            uploads++;
        }
        int nextInstanceHash = Arrays.hashCode(instanceBytes);
        if (instanceBytes != null && (!instanceUploaded || nextInstanceHash != instanceHash)) {
            upload(instances, instanceBytes, "Veil creator instances upload");
            instanceHash = nextInstanceHash;
            instanceUploaded = true;
            uploads++;
        }
        int nextMaterialHash = Arrays.hashCode(materialBytes);
        if (materialBytes != null && (!materialUploaded || nextMaterialHash != materialHash)) {
            upload(materials, materialBytes, "Veil creator materials upload");
            materialHash = nextMaterialHash;
            materialUploaded = true;
            uploads++;
        }
        if (requirements.geometry()) {
            int nextGeometryHash = Arrays.hashCode(geometryBytes);
            if (!geometryUploaded || nextGeometryHash != geometryHash) {
                upload(geometry, geometryBytes, "Veil creator dynamic geometry upload");
                geometryHash = nextGeometryHash;
                geometryUploaded = true;
                uploads++;
            }
        }
        frames++;
    }

    static GpuBuffer lights() {
        return require(lights, LIGHTS_ID);
    }

    static GpuBuffer instances() {
        return require(instances, INSTANCES_ID);
    }

    static GpuBuffer materials() {
        return require(materials, MATERIALS_ID);
    }

    static GpuBuffer geometry() {
        return require(geometry, GEOMETRY_ID);
    }

    private static byte[] encodeLights(
            float sunAngle, double cameraX, double cameraY, double cameraZ) {
        int capacity = (LIGHTS_CAPACITY - LIGHT_HEADER) / LIGHT_STRIDE;
        ArrayList<VeilCreatorScene.Light> values = new ArrayList<>();
        addCelestialLights(values, sunAngle);
        values.addAll(VeilCreatorScene.lights());
        List<VeilCreatorScene.Light> blockLights = blockLightIndex.snapshot();
        blockLights.stream()
                .sorted(
                        Comparator.comparingDouble(
                                light ->
                                        distanceSquared(
                                                light.x(), light.y(), light.z(), cameraX, cameraY,
                                                cameraZ)))
                .limit(Math.max(0, capacity - values.size()))
                .forEach(values::add);
        if (values.size() > capacity) values.subList(capacity, values.size()).clear();
        publishedLights = List.copyOf(values);
        ByteBuffer out = bytes(LIGHT_HEADER + values.size() * LIGHT_STRIDE);
        header(out, 0x564c5431, 1, values.size(), capacity);
        origin(out, 16);
        out.putFloat(28, 0.0f);
        out.putFloat(32, 0.0f).putFloat(36, blockLights.size());
        int offset = LIGHT_HEADER;
        for (VeilCreatorScene.Light light : values) {
            out.putFloat(offset, light.x() - originX)
                    .putFloat(offset + 4, light.y() - originY)
                    .putFloat(offset + 8, light.z() - originZ)
                    .putFloat(offset + 12, light.range());
            out.putFloat(offset + 16, light.r())
                    .putFloat(offset + 20, light.g())
                    .putFloat(offset + 24, light.b())
                    .putFloat(offset + 28, light.intensity());
            out.putFloat(offset + 32, light.directionX())
                    .putFloat(offset + 36, light.directionY())
                    .putFloat(offset + 40, light.directionZ())
                    .putInt(offset + 44, light.type());
            out.putFloat(offset + 48, light.innerCos())
                    .putFloat(offset + 52, light.outerCos())
                    .putInt(offset + 56, light.flags())
                    .putInt(offset + 60, (int) light.id());
            offset += LIGHT_STRIDE;
        }
        lightCount = values.size();
        return out.array();
    }

    static void addCelestialLights(List<VeilCreatorScene.Light> values, float sunAngle) {
        var towardSun = dev.veil.revive.client.scene.inputs.SceneCameraMath.towardSun(sunAngle);
        float sx = towardSun.x;
        float sy = towardSun.y;
        float sunVisibility = smoothstep(-0.08f, 0.12f, sy);
        float moonVisibility = smoothstep(-0.08f, 0.12f, -sy);
        values.add(
                new VeilCreatorScene.Light(
                        -1L,
                        VeilCreatorScene.LIGHT_DIRECTIONAL,
                        0,
                        0,
                        0,
                        0,
                        1.0f,
                        0.93f,
                        0.78f,
                        4.5f * sunVisibility,
                        sx,
                        sy,
                        0.0f,
                        1.0f,
                        1.0f,
                        1));
        values.add(
                new VeilCreatorScene.Light(
                        -2L,
                        VeilCreatorScene.LIGHT_DIRECTIONAL,
                        0,
                        0,
                        0,
                        0,
                        0.38f,
                        0.48f,
                        0.72f,
                        0.42f * moonVisibility,
                        -sx,
                        -sy,
                        0.0f,
                        1.0f,
                        1.0f,
                        2));
    }

    private static byte[] encodeInstances(List<VeilCreatorScene.Instance> source) {
        int capacity = (INSTANCES_CAPACITY - INSTANCE_HEADER) / INSTANCE_STRIDE;
        ArrayList<VeilCreatorScene.Instance> values =
                new ArrayList<>(source.subList(0, Math.min(capacity, source.size())));
        ByteBuffer out = bytes(INSTANCE_HEADER + values.size() * INSTANCE_STRIDE);
        header(out, 0x56445931, 1, values.size(), capacity);
        origin(out, 16);
        out.putFloat(28, 0.0f);
        int offset = INSTANCE_HEADER;
        for (VeilCreatorScene.Instance instance : values) {
            writeInstance(out, offset, instance);
            offset += INSTANCE_STRIDE;
        }
        instanceCount = values.size();
        return out.array();
    }

    private static CapturedInstances captureInstances(Minecraft client, boolean includeGeometry) {
        ArrayList<VeilCreatorScene.Instance> instances = new ArrayList<>();
        ArrayList<VeilCreatorScene.Instance> geometry = new ArrayList<>();
        int entities = 0;
        for (var entity : client.level.entitiesForRendering()) {
            if (entity.isRemoved()
                    || entity.isSpectator()
                    || instances.size() >= VeilDynamicGeometry.MAX_PRIMITIVES) continue;
            AABB box = entity.getBoundingBox();
            int flags = entity == client.player ? VeilCreatorScene.INSTANCE_LOCAL_PLAYER : 0;
            if (entity instanceof LivingEntity) flags |= VeilCreatorScene.INSTANCE_LIVING;
            if (entity instanceof ItemEntity) flags |= VeilCreatorScene.INSTANCE_ITEM;
            if (entity.isInWater()) flags |= VeilCreatorScene.INSTANCE_IN_WATER;
            flags |= BuiltInRegistries.ENTITY_TYPE.getId(entity.getType()) << 8;
            int material =
                    dev.veil.api.VeilEntityMaterials.resolve(
                            BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).toString(),
                            "*",
                            entity instanceof LivingEntity ? 4 : 5);
            VeilCreatorScene.Instance instance =
                    new VeilCreatorScene.Instance(
                            entity.getId(),
                            VeilCreatorScene.INSTANCE_AABB,
                            material,
                            flags,
                            (float) entity.getX(),
                            (float) entity.getY(),
                            (float) entity.getZ(),
                            (float) entity.xOld,
                            (float) entity.yOld,
                            (float) entity.zOld,
                            (float) box.minX,
                            (float) box.minY,
                            (float) box.minZ,
                            (float) box.maxX,
                            (float) box.maxY,
                            (float) box.maxZ,
                            entity.getYRot(),
                            entity.getXRot());
            instances.add(instance);
            if (includeGeometry)
                appendEntityGeometry(
                        geometry,
                        instance,
                        entity instanceof LivingEntity,
                        entity instanceof ItemEntity);
            entities++;
        }
        for (VeilCreatorScene.Instance instance : VeilCreatorScene.instances()) {
            if (instances.size() < VeilDynamicGeometry.MAX_PRIMITIVES) instances.add(instance);
            if (includeGeometry && geometry.size() < VeilDynamicGeometry.MAX_PRIMITIVES)
                geometry.add(instance);
        }
        return new CapturedInstances(instances, geometry, entities);
    }

    private static void appendEntityGeometry(
            ArrayList<VeilCreatorScene.Instance> output,
            VeilCreatorScene.Instance source,
            boolean living,
            boolean item) {
        if (output.size() >= VeilDynamicGeometry.MAX_PRIMITIVES) return;
        if (item) {
            output.add(
                    part(
                            source,
                            0,
                            VeilCreatorScene.INSTANCE_SPHERE,
                            source.minX(),
                            source.minY(),
                            source.minZ(),
                            source.maxX(),
                            source.maxY(),
                            source.maxZ()));
            return;
        }
        if (!living) {
            output.add(source);
            return;
        }
        float width = source.maxX() - source.minX();
        float height = source.maxY() - source.minY();
        float depth = source.maxZ() - source.minZ();
        float cx = (source.minX() + source.maxX()) * 0.5f;
        float cz = (source.minZ() + source.maxZ()) * 0.5f;
        float bottom = source.minY();
        float humanoid = height >= Math.max(width, depth) * 1.35f ? 1.0f : 0.0f;
        if (humanoid > 0.5f) {
            float headBottom = bottom + height * 0.72f;
            float torsoBottom = bottom + height * 0.35f;
            float halfTorso = width * 0.34f;
            addPart(
                    output,
                    part(
                            source,
                            0,
                            VeilCreatorScene.INSTANCE_AABB,
                            cx - width * 0.28f,
                            headBottom,
                            cz - depth * 0.36f,
                            cx + width * 0.28f,
                            source.maxY(),
                            cz + depth * 0.36f));
            addPart(
                    output,
                    part(
                            source,
                            1,
                            VeilCreatorScene.INSTANCE_AABB,
                            cx - halfTorso,
                            torsoBottom,
                            cz - depth * 0.28f,
                            cx + halfTorso,
                            headBottom,
                            cz + depth * 0.28f));
            float limbRadius = Math.max(0.035f, width * 0.11f);
            addPart(
                    output,
                    part(
                            source,
                            2,
                            VeilCreatorScene.INSTANCE_CAPSULE,
                            cx - width * 0.19f - limbRadius,
                            bottom,
                            cz - limbRadius,
                            cx - width * 0.19f + limbRadius,
                            torsoBottom + height * 0.04f,
                            cz + limbRadius));
            addPart(
                    output,
                    part(
                            source,
                            3,
                            VeilCreatorScene.INSTANCE_CAPSULE,
                            cx + width * 0.19f - limbRadius,
                            bottom,
                            cz - limbRadius,
                            cx + width * 0.19f + limbRadius,
                            torsoBottom + height * 0.04f,
                            cz + limbRadius));
            addPart(
                    output,
                    part(
                            source,
                            4,
                            VeilCreatorScene.INSTANCE_CAPSULE,
                            source.minX(),
                            torsoBottom,
                            cz - limbRadius,
                            cx - halfTorso + limbRadius,
                            headBottom - height * 0.04f,
                            cz + limbRadius));
            addPart(
                    output,
                    part(
                            source,
                            5,
                            VeilCreatorScene.INSTANCE_CAPSULE,
                            cx + halfTorso - limbRadius,
                            torsoBottom,
                            cz - limbRadius,
                            source.maxX(),
                            headBottom - height * 0.04f,
                            cz + limbRadius));
        } else {
            float legTop = bottom + height * 0.48f;
            float bodyBottom = bottom + height * 0.36f;
            addPart(
                    output,
                    part(
                            source,
                            0,
                            VeilCreatorScene.INSTANCE_AABB,
                            source.minX(),
                            bodyBottom,
                            source.minZ(),
                            source.maxX(),
                            source.maxY(),
                            source.maxZ()));
            float radius = Math.max(0.035f, Math.min(width, depth) * 0.11f);
            float[] xs = {source.minX() + width * 0.22f, source.maxX() - width * 0.22f};
            float[] zs = {source.minZ() + depth * 0.22f, source.maxZ() - depth * 0.22f};
            int part = 1;
            for (float x : xs)
                for (float z : zs) {
                    addPart(
                            output,
                            part(
                                    source,
                                    part++,
                                    VeilCreatorScene.INSTANCE_CAPSULE,
                                    x - radius,
                                    bottom,
                                    z - radius,
                                    x + radius,
                                    legTop,
                                    z + radius));
                }
        }
    }

    private static void addPart(
            ArrayList<VeilCreatorScene.Instance> output, VeilCreatorScene.Instance part) {
        if (output.size() < VeilDynamicGeometry.MAX_PRIMITIVES) output.add(part);
    }

    private static VeilCreatorScene.Instance part(
            VeilCreatorScene.Instance source,
            int part,
            int type,
            float minX,
            float minY,
            float minZ,
            float maxX,
            float maxY,
            float maxZ) {
        long id = source.id() * 8L + part;
        return new VeilCreatorScene.Instance(
                id,
                type,
                source.material(),
                source.flags(),
                source.x(),
                source.y(),
                source.z(),
                source.previousX(),
                source.previousY(),
                source.previousZ(),
                minX,
                minY,
                minZ,
                maxX,
                maxY,
                maxZ,
                source.yaw(),
                source.pitch());
    }

    private static byte[] encodeGeometry(List<VeilCreatorScene.Instance> source, int entities) {
        VeilDynamicGeometry.Build build = VeilDynamicGeometry.build(source);
        int primitiveOffsetWords = GEOMETRY_HEADER / 16;
        int nodeOffsetWords =
                primitiveOffsetWords + build.primitives().size() * (GEOMETRY_PRIMITIVE_STRIDE / 16);
        int size =
                GEOMETRY_HEADER
                        + build.primitives().size() * GEOMETRY_PRIMITIVE_STRIDE
                        + build.nodes().size() * GEOMETRY_NODE_STRIDE;
        if (size > GEOMETRY_CAPACITY)
            throw new IllegalStateException("Dynamic geometry exceeds its host buffer");
        ByteBuffer out = bytes(size);
        header(out, 0x56474531, 1, build.primitives().size(), build.nodes().size());
        origin(out, 16);
        out.putInt(28, build.root());
        out.putInt(32, primitiveOffsetWords)
                .putInt(36, nodeOffsetWords)
                .putInt(40, entities)
                .putInt(44, build.maxDepth());
        int offset = GEOMETRY_HEADER;
        for (VeilCreatorScene.Instance primitive : build.primitives()) {
            writeInstance(out, offset, primitive);
            offset += GEOMETRY_PRIMITIVE_STRIDE;
        }
        for (VeilDynamicGeometry.Node node : build.nodes()) {
            int left = node.leaf() ? node.primitive() | 0x80000000 : node.left();
            int right = node.leaf() ? -1 : node.right();
            out.putFloat(offset, node.minX() - originX)
                    .putFloat(offset + 4, node.minY() - originY)
                    .putFloat(offset + 8, node.minZ() - originZ)
                    .putInt(offset + 12, left);
            out.putFloat(offset + 16, node.maxX() - originX)
                    .putFloat(offset + 20, node.maxY() - originY)
                    .putFloat(offset + 24, node.maxZ() - originZ)
                    .putInt(offset + 28, right);
            offset += GEOMETRY_NODE_STRIDE;
        }
        geometryPrimitiveCount = build.primitives().size();
        geometryNodeCount = build.nodes().size();
        geometryEntityCount = entities;
        geometryMaxDepth = build.maxDepth();
        return out.array();
    }

    private static void writeInstance(
            ByteBuffer out, int offset, VeilCreatorScene.Instance instance) {
        out.putFloat(offset, instance.x() - originX)
                .putFloat(offset + 4, instance.y() - originY)
                .putFloat(offset + 8, instance.z() - originZ)
                .putInt(offset + 12, instance.type());
        out.putFloat(offset + 16, instance.previousX() - originX)
                .putFloat(offset + 20, instance.previousY() - originY)
                .putFloat(offset + 24, instance.previousZ() - originZ)
                .putInt(offset + 28, (int) instance.id());
        out.putFloat(offset + 32, instance.minX() - originX)
                .putFloat(offset + 36, instance.minY() - originY)
                .putFloat(offset + 40, instance.minZ() - originZ)
                .putInt(offset + 44, instance.material());
        out.putFloat(offset + 48, instance.maxX() - originX)
                .putFloat(offset + 52, instance.maxY() - originY)
                .putFloat(offset + 56, instance.maxZ() - originZ)
                .putInt(offset + 60, instance.flags());
        out.putFloat(offset + 64, instance.yaw())
                .putFloat(offset + 68, instance.pitch())
                .putInt(offset + 72, 0)
                .putInt(offset + 76, (int) (instance.id() >>> 32));
    }

    private record CapturedInstances(
            List<VeilCreatorScene.Instance> instances,
            List<VeilCreatorScene.Instance> geometry,
            int entityCount) {}

    private static byte[] encodeMaterials() {
        int capacity = (MATERIALS_CAPACITY - MATERIAL_HEADER) / MATERIAL_STRIDE;
        LinkedHashMap<Integer, VeilCreatorScene.Material> values = new LinkedHashMap<>();
        put(values, material(0, 1, 1, 1, 1, 0, 0, 0, 0.85f, 0, 1.5f, 0, 1, 0, 0, 0, 0, 0));
        put(
                values,
                material(
                        1, 0.18f, 0.38f, 0.52f, 0.34f, 0, 0, 0, 0.05f, 0, 1.333f, 1, 1, 0.08f,
                        0.025f, 0.01f, 0, 1));
        put(
                values,
                material(
                        2, 0.75f, 0.18f, 0.025f, 1, 5.5f, 1.15f, 0.08f, 0.45f, 0, 1.45f, 0, 1, 0, 0,
                        0, 0, 2));
        put(
                values,
                material(
                        3, 0.65f, 0.72f, 0.78f, 0.5f, 0, 0, 0, 0.12f, 0, 1.4f, 0.72f, 1, 0.03f,
                        0.03f, 0.03f, 0, 1));
        put(
                values,
                material(
                        4, 0.72f, 0.72f, 0.72f, 1, 0, 0, 0, 0.72f, 0, 1.45f, 0, 1, 0, 0, 0, 0.08f,
                        0));
        put(
                values,
                material(
                        5, 0.82f, 0.82f, 0.82f, 1, 0, 0, 0, 0.55f, 0.02f, 1.5f, 0, 1, 0, 0, 0, 0,
                        0));
        for (VeilCreatorScene.Material material : VeilCreatorScene.materials())
            put(values, material);
        for (var material : dev.veil.api.VeilEntityMaterials.materials()) {
            var existing = values.get(material.id());
            if (existing != null && !existing.equals(material))
                throw new IllegalArgumentException(
                        "Conflicting entity PBR material ID " + material.id());
            put(values, material);
        }
        ArrayList<VeilCreatorScene.Material> ordered = new ArrayList<>(values.values());
        ordered.sort(Comparator.comparingInt(VeilCreatorScene.Material::id));
        if (ordered.size() > capacity) ordered.subList(capacity, ordered.size()).clear();
        ByteBuffer out = bytes(MATERIAL_HEADER + ordered.size() * MATERIAL_STRIDE);
        header(out, 0x56504d31, 1, ordered.size(), capacity);
        int offset = MATERIAL_HEADER;
        for (VeilCreatorScene.Material material : ordered) {
            out.putFloat(offset, material.baseR())
                    .putFloat(offset + 4, material.baseG())
                    .putFloat(offset + 8, material.baseB())
                    .putFloat(offset + 12, material.alpha());
            out.putFloat(offset + 16, material.emissionR())
                    .putFloat(offset + 20, material.emissionG())
                    .putFloat(offset + 24, material.emissionB())
                    .putFloat(offset + 28, material.roughness());
            out.putFloat(offset + 32, material.metallic())
                    .putFloat(offset + 36, material.ior())
                    .putFloat(offset + 40, material.transmission())
                    .putFloat(offset + 44, material.occlusion());
            out.putFloat(offset + 48, material.absorptionR())
                    .putFloat(offset + 52, material.absorptionG())
                    .putFloat(offset + 56, material.absorptionB())
                    .putFloat(offset + 60, material.subsurface());
            out.putInt(offset + 64, material.id()).putInt(offset + 68, material.flags());
            offset += MATERIAL_STRIDE;
        }
        materialCount = ordered.size();
        return out.array();
    }

    private static void scanLights(Minecraft client, int x, int y, int z) {
        int cellX = Math.floorDiv(x, 8) * 8;
        int cellY = Math.floorDiv(y, 8) * 8;
        int cellZ = Math.floorDiv(z, 8) * 8;
        if (cellX != scanCenterX || cellY != scanCenterY || cellZ != scanCenterZ) {
            scanCenterX = cellX;
            scanCenterY = cellY;
            scanCenterZ = cellZ;
            scanCursor = 0;
            blockLightIndex.beginScan(position -> inLightScan(BlockPos.of(position)));
        }
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int end = Math.min(LIGHT_SCAN_VOLUME, scanCursor + LIGHT_SCAN_BUDGET);
        for (; scanCursor < end; scanCursor++) {
            int localX = scanCursor % LIGHT_SCAN_DIAMETER;
            int yz = scanCursor / LIGHT_SCAN_DIAMETER;
            int localZ = yz % LIGHT_SCAN_DIAMETER;
            int localY = yz / LIGHT_SCAN_DIAMETER;
            pos.set(
                    scanCenterX + localX - LIGHT_SCAN_RADIUS,
                    scanCenterY + localY - LIGHT_SCAN_RADIUS,
                    scanCenterZ + localZ - LIGHT_SCAN_RADIUS);
            var state = client.level.getBlockState(pos);
            blockLightIndex.observed(pos.asLong(), blockLight(pos, state.getLightEmission()));
        }
        if (scanCursor == LIGHT_SCAN_VOLUME) {
            blockLightIndex.completeScan();
            scanCursor = 0;
        }
    }

    static void blockLightChanged(ClientLevel level, BlockPos pos) {
        if (lights == null || level != lightWorld || !inLightScan(pos)) return;
        RenderSystem.assertOnRenderThread();
        blockLightIndex.changed(
                pos.asLong(), blockLight(pos, level.getBlockState(pos).getLightEmission()));
        immediateLightUpdates++;
        if (Boolean.getBoolean("veil.verifyImmediateBlockLights"))
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil immediate block light update: position={} emission={} scan_cursor={} indexed={} frame={}",
                    pos,
                    level.getBlockState(pos).getLightEmission(),
                    scanCursor,
                    blockLightIndex.snapshot().stream()
                            .anyMatch(light -> light.id() == pos.asLong()),
                    frames);
    }

    private static boolean inLightScan(BlockPos pos) {
        return Math.abs((long) pos.getX() - scanCenterX) <= LIGHT_SCAN_RADIUS
                && Math.abs((long) pos.getY() - scanCenterY) <= LIGHT_SCAN_RADIUS
                && Math.abs((long) pos.getZ() - scanCenterZ) <= LIGHT_SCAN_RADIUS;
    }

    private static VeilCreatorScene.Light blockLight(BlockPos pos, int emission) {
        if (emission <= 0) return null;
        float intensity = emission / 15.0f;
        return new VeilCreatorScene.Light(
                pos.asLong(),
                VeilCreatorScene.LIGHT_POINT,
                pos.getX() + 0.5f,
                pos.getY() + 0.5f,
                pos.getZ() + 0.5f,
                2.0f + emission * 0.9f,
                1.0f,
                0.58f + intensity * 0.18f,
                0.24f,
                2.0f + intensity * 5.0f,
                0,
                -1,
                0,
                1,
                -1,
                4);
    }

    private static void upload(GpuBuffer destination, byte[] data, String label) {
        GpuBuffer staging =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> label,
                                GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                                data.length);
        try {
            try (var mapping = staging.map(false, true)) {
                mapping.data().put(data);
            }
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var copy = VkBufferCopy.calloc(1, stack);
                copy.get(0).srcOffset(0).dstOffset(0).size(data.length);
                vkCmdCopyBuffer(
                        VeilVulkanRuntime.requireCurrent().commandBuffer(),
                        ((VulkanGpuBuffer) staging).vkBuffer(),
                        ((VulkanGpuBuffer) destination).vkBuffer(),
                        copy);
            }
        } finally {
            staging.close();
        }
    }

    private static void ensureBuffers(CreatorSceneRequirements requirements) {
        if (requirements.lights() && lights == null)
            lights = storage("Veil creator light data", LIGHTS_CAPACITY);
        if (requirements.instances() && instances == null)
            instances = storage("Veil creator instance data", INSTANCES_CAPACITY);
        if (requirements.materials() && materials == null)
            materials = storage("Veil creator material data", MATERIALS_CAPACITY);
        if (requirements.geometry() && geometry == null)
            geometry = storage("Veil creator dynamic geometry", GEOMETRY_CAPACITY);
    }

    private static GpuBuffer storage(String label, int capacity) {
        return RenderSystem.getDevice()
                .createBuffer(
                        () -> label, VeilHzb.STORAGE_USAGE | GpuBuffer.USAGE_COPY_DST, capacity);
    }

    static String telemetry() {
        return "creator_scene_frames="
                + frames
                + "\ncreator_scene_uploads_total="
                + uploads
                + "\ncreator_lights="
                + lightCount
                + "\ncreator_immediate_light_updates="
                + immediateLightUpdates
                + "\ncreator_instances="
                + instanceCount
                + "\ncreator_materials="
                + materialCount
                + "\ncreator_geometry_entities="
                + geometryEntityCount
                + "\ncreator_geometry_primitives="
                + geometryPrimitiveCount
                + "\ncreator_geometry_nodes="
                + geometryNodeCount
                + "\ncreator_geometry_max_depth="
                + geometryMaxDepth
                + "\ncreator_light_scan_progress="
                + scanCursor
                + "/"
                + LIGHT_SCAN_VOLUME;
    }

    static List<VeilCreatorScene.Light> lightsSnapshot() {
        return publishedLights;
    }

    static void close() {
        if (lights != null) {
            lights.close();
            lights = null;
        }
        if (instances != null) {
            instances.close();
            instances = null;
        }
        if (materials != null) {
            materials.close();
            materials = null;
        }
        if (geometry != null) {
            geometry.close();
            geometry = null;
        }
        blockLightIndex.clear();
        lightWorld = null;
        immediateLightUpdates = 0;
        publishedLights = List.of();
        scanCenterX = Integer.MIN_VALUE;
        scanCursor = 0;
        materialHash = geometryHash = 0;
        lightHash = instanceHash = 0;
        lightUploaded = instanceUploaded = materialUploaded = geometryUploaded = false;
        lightRequested = false;
    }

    private static GpuBuffer require(GpuBuffer value, String id) {
        if (value == null) throw new IllegalStateException(id + " is not prepared");
        return value;
    }

    private static void header(ByteBuffer out, int magic, int version, int count, int capacity) {
        out.putInt(0, magic).putInt(4, version).putInt(8, count).putInt(12, capacity);
    }

    private static void origin(ByteBuffer out, int offset) {
        out.putFloat(offset, originX).putFloat(offset + 4, originY).putFloat(offset + 8, originZ);
    }

    private static ByteBuffer bytes(int size) {
        return ByteBuffer.wrap(new byte[size]).order(ByteOrder.LITTLE_ENDIAN);
    }

    private static int floor256(double value) {
        return Math.floorDiv((int) Math.floor(value), 256) * 256;
    }

    private static double distanceSquared(
            float x, float y, float z, double cx, double cy, double cz) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        return dx * dx + dy * dy + dz * dz;
    }

    private static float smoothstep(float low, float high, float value) {
        float t = Math.max(0.0f, Math.min(1.0f, (value - low) / (high - low)));
        return t * t * (3.0f - 2.0f * t);
    }

    private static VeilCreatorScene.Material material(
            int id,
            float br,
            float bg,
            float bb,
            float alpha,
            float er,
            float eg,
            float eb,
            float roughness,
            float metallic,
            float ior,
            float transmission,
            float occlusion,
            float ar,
            float ag,
            float ab,
            float subsurface,
            int flags) {
        return new VeilCreatorScene.Material(
                id,
                br,
                bg,
                bb,
                alpha,
                er,
                eg,
                eb,
                roughness,
                metallic,
                ior,
                transmission,
                occlusion,
                ar,
                ag,
                ab,
                subsurface,
                flags);
    }

    private static void put(
            LinkedHashMap<Integer, VeilCreatorScene.Material> values,
            VeilCreatorScene.Material material) {
        values.put(material.id(), material);
    }
}
