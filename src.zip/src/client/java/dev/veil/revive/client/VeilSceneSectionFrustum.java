package dev.veil.revive.client;

import org.joml.Matrix4fc;

final class VeilSceneSectionFrustum {
    private final dev.veil.revive.client.scene.geometry.SceneSectionFrustum frustum;

    VeilSceneSectionFrustum(Matrix4fc matrix, double x, double y, double z) {
        frustum = new dev.veil.revive.client.scene.geometry.SceneSectionFrustum(matrix, x, y, z);
    }

    boolean intersects(int x, int y, int z) {
        return frustum.intersects(x, y, z);
    }
}
