package dev.veil.revive.client.terrain.indirect;

import dev.veil.revive.client.terrain.capture.TerrainPlanSource;
import dev.veil.revive.core.terrain.IndirectBatchPayload;

import java.nio.ByteBuffer;
import java.util.List;

public final class TerrainBatchEncoder {
    private TerrainBatchEncoder() {}

    public interface Draw {
        int sectionIndex();

        int indexCount();

        int firstIndex();

        int baseVertex();

        float[] bounds();
    }

    public static void encode(
            TerrainBatchStorage batch,
            ByteBuffer target,
            List<? extends Draw> source,
            int start,
            long[] order,
            TerrainPlanSource.Origins origins) {
        IndirectBatchPayload.initializeRegions(target, batch.regionBoundsOffset, batch.regionCount);
        for (int i = 0; i < batch.sectionIndices.length; i++) {
            int sourceOffset = order == null ? i : (int) (order[i] & 0xFFFL);
            Draw draw = source.get(start + sourceOffset);
            int section = draw.sectionIndex();
            batch.sectionIndices[i] = section;
            float[] box = draw.bounds();
            IndirectBatchPayload.writeBounds(target, batch.boundsOffset + i * 32, box);
            int regionBase = batch.regionBoundsOffset + (i >> batch.regionShift) * 32;
            if (IndirectBatchPayload.prepareRegion(target, regionBase, box)) {
                IndirectBatchPayload.includeRegion(
                        target,
                        regionBase,
                        box,
                        origins.x(section),
                        origins.y(section),
                        origins.z(section));
            }
            int count = draw.indexCount();
            int first = draw.firstIndex();
            int base = draw.baseVertex();
            batch.indexCounts[i] = count;
            batch.firstIndices[i] = first;
            batch.baseVertices[i] = base;
            batch.directCommands.put(i * 3, first).put(i * 3 + 1, count).put(i * 3 + 2, base);
            IndirectBatchPayload.writeCommand(
                    target, batch.commandsOffset + i * 20, count, first, base, section);
        }
        target.position(0).limit(batch.allocationSize);
    }
}
