package dev.veil.revive.client;

import org.joml.Vector3f;

import java.nio.ByteBuffer;

final class VeilCreatorGraphicsProbe {
    private VeilCreatorGraphicsProbe() {}

    static java.util.Map<String, String> overrides() {
        return Boolean.getBoolean("veil.shaderProbe")
                        && System.getProperty("veil.shaderPack", "").equals("creatorgraphics")
                ? java.util.Map.of(
                        "cameraYaw", "0.0", "fogDensity", "0.08", "shadowStrength", "1.0")
                : java.util.Map.of();
    }

    static void verify(ByteBuffer pixels, int width, int height, float yaw) {
        if (width != 64 || height != 32)
            throw new IllegalStateException("Creator test extent changed");
        int shadowPixels = 0, fogPixels = 0;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                var expected = pixel(x, y, width, height, yaw, 0.08f, 1);
                var noShadow = pixel(x, y, width, height, yaw, 0.08f, 0);
                var noFog = pixel(x, y, width, height, yaw, 0, 1);
                if (expected.distanceSquared(noShadow) > 0.0001f) shadowPixels++;
                if (expected.distanceSquared(noFog) > 0.0001f) fogPixels++;
                for (int channel = 0; channel < 4; channel++) {
                    int actual = Byte.toUnsignedInt(pixels.get((y * width + x) * 4 + channel));
                    int wanted = channel == 3 ? 255 : Math.round(expected.get(channel) * 255);
                    if (Math.abs(actual - wanted) > 2) {
                        throw new IllegalStateException(
                                "Creator pixel mismatch at "
                                        + x
                                        + ","
                                        + y
                                        + " channel="
                                        + channel
                                        + " expected="
                                        + wanted
                                        + " actual="
                                        + actual);
                    }
                }
            }
        }
        if (shadowPixels < 10 || fogPixels < 100)
            throw new IllegalStateException("Creator scene does not exercise fog and shadows");
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil creator graphics readback: cameraYaw={}, {} shadow-sensitive pixels, {} fog-sensitive pixels",
                yaw,
                shadowPixels,
                fogPixels);
        var image =
                new java.awt.image.BufferedImage(
                        width, height, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++) {
                int offset = (y * width + x) * 4;
                image.setRGB(
                        x,
                        y,
                        0xff000000
                                | Byte.toUnsignedInt(pixels.get(offset)) << 16
                                | Byte.toUnsignedInt(pixels.get(offset + 1)) << 8
                                | Byte.toUnsignedInt(pixels.get(offset + 2)));
            }
        try {
            var destination = java.nio.file.Path.of("logs", "veil-creatorgraphics-" + yaw + ".png");
            java.nio.file.Files.createDirectories(destination.getParent());
            if (!javax.imageio.ImageIO.write(image, "png", destination.toFile()))
                throw new java.io.IOException("PNG encoder unavailable");
        } catch (java.io.IOException failure) {
            throw new IllegalStateException("Cannot save creator GPU readback", failure);
        }
    }

    private static Vector3f pixel(
            int x, int y, int width, int height, float yaw, float density, float strength) {
        var eye = new Vector3f(5 * (float) Math.sin(yaw), 2.5f, 5 * (float) Math.cos(yaw));
        var forward = new Vector3f(0, 1, 0).sub(eye).normalize();
        var right = new Vector3f(forward).cross(0, 1, 0).normalize();
        var up = new Vector3f(right).cross(forward).normalize();
        float tangent = (float) Math.tan(Math.toRadians(55) * 0.5);
        float sx = ((x + 0.5f) / width * 2 - 1) * tangent * 2;
        float sy = (1 - (y + 0.5f) / height * 2) * tangent;
        var ray =
                new Vector3f(forward)
                        .add(new Vector3f(right).mul(sx))
                        .add(new Vector3f(up).mul(sy))
                        .normalize();
        var light = new Vector3f(-0.4f, 0.8f, 0.3f).normalize();
        float distance = sphere(eye, ray);
        float ground = ray.y < -0.0001f ? -eye.y / ray.y : 1000;
        boolean plane = ground < distance;
        distance = Math.min(Math.min(distance, ground), 20);
        var point = new Vector3f(ray).mul(distance).add(eye);
        var normal = plane ? new Vector3f(0, 1, 0) : new Vector3f(point).sub(0, 1, 0).normalize();
        var color = new Vector3f(0.15f, 0.3f, 0.5f);
        if (distance < 20) {
            color = plane ? new Vector3f(0.45f, 0.5f, 0.4f) : new Vector3f(0.7f, 0.22f, 0.12f);
            float visible =
                    visibility(
                            new Vector3f(point).add(new Vector3f(normal).mul(0.002f)),
                            light,
                            strength);
            color.mul(0.15f + Math.max(normal.dot(light), 0) * visible);
        }
        float stepLength = distance / 32;
        float stepTransmittance = (float) Math.exp(-density * stepLength);
        float transmittance = 1;
        var scatter = new Vector3f();
        for (int step = 0; step < 32; step++) {
            var sample = new Vector3f(ray).mul((step + 0.5f) * stepLength).add(eye);
            float visible = visibility(sample, light, strength);
            var source =
                    new Vector3f(0.16f, 0.2f, 0.27f)
                            .add(new Vector3f(0.5f, 0.42f, 0.3f).mul(visible));
            scatter.add(source.mul(transmittance * (1 - stepTransmittance)));
            transmittance *= stepTransmittance;
        }
        return color.mul(transmittance).add(scatter).max(new Vector3f()).min(new Vector3f(1));
    }

    private static float visibility(Vector3f point, Vector3f light, float strength) {
        return sphere(new Vector3f(light).mul(0.002f).add(point), light) < 1000 ? 1 - strength : 1;
    }

    private static float sphere(Vector3f origin, Vector3f direction) {
        var offset = new Vector3f(origin).sub(0, 1, 0);
        float b = offset.dot(direction);
        float discriminant = b * b - offset.lengthSquared() + 1;
        if (discriminant < 0) return 1000;
        float root = (float) Math.sqrt(discriminant);
        float near = -b - root, far = -b + root;
        return near > 0.001f ? near : far > 0.001f ? far : 1000;
    }
}
