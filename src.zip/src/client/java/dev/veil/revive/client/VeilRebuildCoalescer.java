package dev.veil.revive.client;

import java.util.concurrent.atomic.LongAdder;

public final class VeilRebuildCoalescer {
    private static final LongAdder CANCELLED = new LongAdder();
    private static final LongAdder STALE_POLLS_SKIPPED = new LongAdder();
    private static final LongAdder BUDGET_DEFERRED = new LongAdder();
    private static final LongAdder FIRST_LOAD_UNBLOCKED = new LongAdder();
    private static final LongAdder UPLOAD_BACKOFF_YIELDS = new LongAdder();
    private static final LongAdder UPLOAD_BACKOFF_PARKS = new LongAdder();
    private static final LongAdder UPLOAD_BACKOFF_PARKED_NS = new LongAdder();

    private VeilRebuildCoalescer() {}

    public static void recordCancelled() {
        CANCELLED.increment();
    }

    public static void recordStalePollSkipped() {
        STALE_POLLS_SKIPPED.increment();
    }

    public static void recordBudgetDeferred() {
        BUDGET_DEFERRED.increment();
    }

    public static void recordFirstLoadUnblocked() {
        FIRST_LOAD_UNBLOCKED.increment();
    }

    public static void recordUploadBackoffYield() {
        UPLOAD_BACKOFF_YIELDS.increment();
    }

    public static void recordUploadBackoffPark(long nanos) {
        UPLOAD_BACKOFF_PARKS.increment();
        UPLOAD_BACKOFF_PARKED_NS.add(nanos);
    }

    public static long cancelled() {
        return CANCELLED.sum();
    }

    public static long stalePollsSkipped() {
        return STALE_POLLS_SKIPPED.sum();
    }

    public static long uploadBackoffParkedNsTotal() {
        return UPLOAD_BACKOFF_PARKED_NS.sum();
    }

    public static String telemetry() {
        return "chunk_rebuilds_coalesced_total="
                + CANCELLED.sum()
                + "\nchunk_rebuild_stale_polls_skipped_total="
                + STALE_POLLS_SKIPPED.sum()
                + "\nchunk_rebuild_budget_deferred_total="
                + BUDGET_DEFERRED.sum()
                + "\nchunk_first_load_unblocked_total="
                + FIRST_LOAD_UNBLOCKED.sum()
                + "\nchunk_rebuild_upload_backoff_yields_total="
                + UPLOAD_BACKOFF_YIELDS.sum()
                + "\nchunk_rebuild_upload_backoff_parks_total="
                + UPLOAD_BACKOFF_PARKS.sum()
                + "\nchunk_rebuild_upload_backoff_parked_ns_total="
                + UPLOAD_BACKOFF_PARKED_NS.sum()
                + "\n";
    }
}
