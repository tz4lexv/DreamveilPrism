package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.PoseStack;

import dev.veil.api.VeilCreatorMeshes;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.UVPair;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.world.entity.Entity;

import org.joml.Matrix4f;
import org.joml.Vector3fc;

import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;

public final class VeilEntityMeshCapture {
    private static final long ENTITY_PREFIX = 0x5645000000000000L;
    private static final long ITEM_MESH_ID = 0x56454954454d0001L;
    private static final int MAX_FRAME_VERTICES = 48_000;
    private static final int MAX_FRAME_TRIANGLES = 12_000;
    private static final int MAX_MISSED_PREPARES = 4;

    private record EntitySurface(int id, int material) {}

    private static final IdentityHashMap<Object, EntitySurface> STATE_ENTITIES =
            new IdentityHashMap<>();
    private static final HashMap<Long, Capture> CAPTURES = new HashMap<>();
    private static Capture current;
    private static boolean active;
    private static int cameraOriginX, cameraOriginY, cameraOriginZ;
    private static double cameraRemainderX, cameraRemainderY, cameraRemainderZ;
    private static int frameVertices, frameTriangles;
    private static long frames,
            publishedMeshes,
            capturedVertices,
            capturedTriangles,
            skippedTriangles;

    private VeilEntityMeshCapture() {}

    public static void beginFrame() {
        boolean requested = VeilShaderService.wantsAutomaticEntityMeshes();
        current = null;
        frameVertices = frameTriangles = 0;
        if (!requested) {
            if (active) closeAll();
            active = false;
            STATE_ENTITIES.clear();
            return;
        }
        active = true;
        var camera = Minecraft.getInstance().gameRenderer.mainCamera().position();
        cameraOriginX = floor256(camera.x);
        cameraOriginY = floor256(camera.y);
        cameraOriginZ = floor256(camera.z);
        cameraRemainderX = camera.x - cameraOriginX;
        cameraRemainderY = camera.y - cameraOriginY;
        cameraRemainderZ = camera.z - cameraOriginZ;
        CAPTURES.values().forEach(Capture::beginFrame);
        frames++;
    }

    public static void associate(EntityRenderState state, Entity entity) {

        if (VeilShaderService.wantsAutomaticEntityMeshes() && state != null && entity != null)
            STATE_ENTITIES.put(
                    state,
                    new EntitySurface(
                            entity.getId(),
                            dev.veil.api.VeilEntityMaterials.resolve(
                                    net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE
                                            .getKey(entity.getType())
                                            .toString(),
                                    "*",
                                    entity instanceof net.minecraft.world.entity.LivingEntity
                                            ? 4
                                            : 5)));
    }

    public static void beginModel(Object state) {
        if (!active) return;
        EntitySurface entity = STATE_ENTITIES.get(state);
        current =
                entity == null
                        ? null
                        : capture(
                                ENTITY_PREFIX | Integer.toUnsignedLong(entity.id()),
                                entity.material(),
                                1);
    }

    public static void endModel() {
        current = null;
    }

    public static void captureCube(PoseStack.Pose pose, ModelPart.Polygon[] polygons) {
        Capture target = current;
        if (!active || target == null || pose == null || polygons == null) return;
        Matrix4f matrix = pose.pose();
        for (ModelPart.Polygon polygon : polygons) {
            ModelPart.Vertex[] vertices = polygon.vertices();
            if (vertices.length < 3 || !reserve(vertices.length, vertices.length - 2)) {
                skippedTriangles += Math.max(1, vertices.length - 2);
                continue;
            }
            int base = target.vertexCount();
            for (ModelPart.Vertex vertex : vertices) {
                target.add(
                        transformX(matrix, vertex.worldX(), vertex.worldY(), vertex.worldZ()),
                        transformY(matrix, vertex.worldX(), vertex.worldY(), vertex.worldZ()),
                        transformZ(matrix, vertex.worldX(), vertex.worldY(), vertex.worldZ()),
                        vertex.u(),
                        vertex.v());
            }
            for (int index = 1; index + 1 < vertices.length; index++)
                target.triangle(base, base + index, base + index + 1);
        }
    }

    public static void captureItem(PoseStack.Pose pose, List<BakedQuad> quads) {
        if (!active || pose == null || quads == null || quads.isEmpty()) return;
        Capture target = capture(ITEM_MESH_ID, 5, 2);
        Matrix4f matrix = pose.pose();
        for (BakedQuad quad : quads) {
            if (!reserve(4, 2)) {
                skippedTriangles += 2;
                continue;
            }
            int base = target.vertexCount();
            for (int index = 0; index < 4; index++) {
                Vector3fc vertex = quad.position(index);
                target.add(
                        transformX(matrix, vertex.x(), vertex.y(), vertex.z()),
                        transformY(matrix, vertex.x(), vertex.y(), vertex.z()),
                        transformZ(matrix, vertex.x(), vertex.y(), vertex.z()),
                        UVPair.unpackU(quad.packedUV(index)),
                        UVPair.unpackV(quad.packedUV(index)));
            }
            target.triangle(base, base + 1, base + 2);
            target.triangle(base, base + 2, base + 3);
        }
    }

    public static void publishFrame() {
        if (!active) return;
        current = null;
        Iterator<Capture> iterator = CAPTURES.values().iterator();
        while (iterator.hasNext()) {
            Capture capture = iterator.next();
            if (!capture.touched || capture.vertexCount() == 0 || capture.triangleCount() == 0) {

                if (++capture.missedPrepares > MAX_MISSED_PREPARES) {
                    capture.close();
                    iterator.remove();
                }
                continue;
            }
            capture.missedPrepares = 0;
            capture.publish();
            publishedMeshes++;
        }
        capturedVertices += frameVertices;
        capturedTriangles += frameTriangles;
        active = false;
        STATE_ENTITIES.clear();
    }

    public static String telemetry() {
        return "entity_mesh_capture_frames="
                + frames
                + "\nentity_mesh_capture_live_meshes="
                + CAPTURES.size()
                + "\nentity_mesh_capture_vertices_total="
                + capturedVertices
                + "\nentity_mesh_capture_triangles_total="
                + capturedTriangles
                + "\nentity_mesh_capture_publishes_total="
                + publishedMeshes
                + "\nentity_mesh_capture_skipped_triangles_total="
                + skippedTriangles;
    }

    public static void close() {
        closeAll();
        active = false;
        current = null;
        STATE_ENTITIES.clear();
    }

    private static Capture capture(long id, int material, int flags) {
        Capture value = CAPTURES.computeIfAbsent(id, key -> new Capture(key, material, flags));
        value.material = material;
        value.touched = true;
        return value;
    }

    private static boolean reserve(int vertices, int triangles) {
        if (frameVertices + vertices > MAX_FRAME_VERTICES
                || frameTriangles + triangles > MAX_FRAME_TRIANGLES) return false;
        frameVertices += vertices;
        frameTriangles += triangles;
        return true;
    }

    private static float transformX(Matrix4f m, float x, float y, float z) {
        return (float)
                (cameraOriginX
                        + cameraRemainderX
                        + m.m00() * x
                        + m.m10() * y
                        + m.m20() * z
                        + m.m30());
    }

    private static float transformY(Matrix4f m, float x, float y, float z) {
        return (float)
                (cameraOriginY
                        + cameraRemainderY
                        + m.m01() * x
                        + m.m11() * y
                        + m.m21() * z
                        + m.m31());
    }

    private static float transformZ(Matrix4f m, float x, float y, float z) {
        return (float)
                (cameraOriginZ
                        + cameraRemainderZ
                        + m.m02() * x
                        + m.m12() * y
                        + m.m22() * z
                        + m.m32());
    }

    private static void closeAll() {
        CAPTURES.values().forEach(Capture::close);
        CAPTURES.clear();
    }

    private static int floor256(double value) {
        return Math.floorDiv((int) Math.floor(value), 256) * 256;
    }

    private static final class Capture {
        private final long id;
        private int material;
        private final int flags;
        private float[] positions = new float[384];
        private float[] textureCoordinates = new float[256];
        private int[] indices = new int[384];
        private int positionSize, indexSize, hash;
        private float[] previous;
        private int[] previousIndices;
        private long lastFrame;
        private boolean motionPending;
        private VeilCreatorMeshes.Registration registration;
        private boolean touched;
        private int missedPrepares;

        private Capture(long id, int material, int flags) {
            this.id = id;
            this.material = material;
            this.flags = flags;
        }

        private void beginFrame() {
            positionSize = indexSize = 0;
            touched = false;
        }

        private int vertexCount() {
            return positionSize / 3;
        }

        private int triangleCount() {
            return indexSize / 3;
        }

        private void add(float x, float y, float z, float u, float v) {
            int uv = vertexCount() * 2;
            if (uv + 2 > textureCoordinates.length)
                textureCoordinates =
                        Arrays.copyOf(textureCoordinates, textureCoordinates.length * 2);
            textureCoordinates[uv] = u;
            textureCoordinates[uv + 1] = v;
            if (positionSize + 3 > positions.length)
                positions = Arrays.copyOf(positions, positions.length * 2);
            positions[positionSize++] = x;
            positions[positionSize++] = y;
            positions[positionSize++] = z;
        }

        private void triangle(int a, int b, int c) {
            if (indexSize + 3 > indices.length)
                indices = Arrays.copyOf(indices, indices.length * 2);
            indices[indexSize++] = a;
            indices[indexSize++] = b;
            indices[indexSize++] = c;
        }

        private void publish() {
            float[] currentPositions = Arrays.copyOf(positions, positionSize);
            int[] currentIndices = Arrays.copyOf(indices, indexSize);
            float[] currentUv = Arrays.copyOf(textureCoordinates, vertexCount() * 2);
            int nextHash =
                    31 * (31 * Arrays.hashCode(currentPositions) + Arrays.hashCode(currentIndices))
                            + Arrays.hashCode(currentUv);
            nextHash = 31 * nextHash + material;
            if (registration != null
                    && nextHash == hash
                    && !motionPending
                    && lastFrame == frames - 1) {
                lastFrame = frames;
                return;
            }
            float[] previousPositions =
                    previous != null
                                    && previous.length == currentPositions.length
                                    && lastFrame == frames - 1
                                    && Arrays.equals(previousIndices, currentIndices)
                            ? previous
                            : currentPositions;
            VeilCreatorMeshes.Mesh mesh =
                    new VeilCreatorMeshes.Mesh(
                            id,
                            material,
                            flags,
                            currentPositions,
                            previousPositions,
                            currentIndices,
                            currentUv);
            if (registration == null) registration = VeilCreatorMeshes.register(mesh);
            else registration.update(mesh);
            motionPending = !Arrays.equals(previousPositions, currentPositions);
            previous = currentPositions;
            previousIndices = currentIndices;
            lastFrame = frames;
            hash = nextHash;
        }

        private void close() {
            if (registration != null) registration.close();
            registration = null;
            previous = null;
        }
    }
}
