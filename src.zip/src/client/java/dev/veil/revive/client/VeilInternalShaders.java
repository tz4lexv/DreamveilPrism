package dev.veil.revive.client;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

final class VeilInternalShaders {
    private VeilInternalShaders() {}

    static VeilSpirvBinary hzbPyramid(boolean slang) throws IOException {
        return load("hzb_build", slang);
    }

    static VeilSpirvBinary hzbCull(boolean slang) throws IOException {
        return hzbCull(slang, false);
    }

    static VeilSpirvBinary hzbCull(boolean slang, boolean wave) throws IOException {
        return load(wave && slang ? "hzb_cull_wave" : "hzb_cull", slang);
    }

    private static VeilSpirvBinary load(String name, boolean slang) throws IOException {
        String resource =
                "/assets/veil/shaders/" + (slang ? "slang/" + name + ".spv" : name + ".comp");
        byte[] bytes;
        try (var stream = VeilInternalShaders.class.getResourceAsStream(resource)) {
            if (stream == null) throw new IOException("Missing internal shader: " + resource);
            bytes = stream.readAllBytes();
        }
        if (!slang)
            return VeilSpirvCompiler.compile(
                    resource, new String(bytes, StandardCharsets.UTF_8), VeilShaderStage.COMPUTE);
        try {
            String digest =
                    HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
            return new VeilSpirvBinary(bytes, VeilShaderStage.COMPUTE, resource, "main", digest);
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }
}
