package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilMinecraftTerrainBridge;

import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SectionRenderDispatcher.RenderSection.class)
public abstract class RenderSectionMeshUpdateMixin {
    @Shadow @Final private SectionRenderDispatcher this$0;

    @Inject(method = "resortTransparency", at = @At("HEAD"), cancellable = true, require = 1)
    private void veil$spatialTrigger(CallbackInfo ci) {
        if (!dev.veil.revive.client.VeilTransparencyOrder.spatialRequested()
                || !dev.veil.revive.client.VeilTransparencyOrder.enabled()) return;
        var self = (SectionRenderDispatcher.RenderSection) (Object) this;
        if (!(self.getSectionMesh()
                        instanceof net.minecraft.client.renderer.chunk.CompiledSectionMesh mesh)
                || mesh.getTransparencyState() == null) return;
        var state = ((dev.veil.revive.client.VeilTransparencyExtras) mesh).veil$transparencyState();
        var order = state == null ? null : state.idleOrder();
        if (order == null) return;
        var camera = ((SectionRenderDispatcherInvoker) this$0).veil$cameraPosition().get();
        if (camera == null) return;
        var origin = net.minecraft.core.SectionPos.of(self.getSectionNode());
        float x = (float) (camera.x - origin.minBlockX()),
                y = (float) (camera.y - origin.minBlockY()),
                z = (float) (camera.z - origin.minBlockZ());
        var points = mesh.getTransparencyState().centroids();
        if (!order.insideRegion(points, x, y, z)) return;
        order.recordPrequeue(points, x, y, z);
        ci.cancel();
    }

    @Inject(method = "setSectionNode(J)V", at = @At("HEAD"), require = 1)
    private void veil$sectionRelocated(long newSectionNode, CallbackInfo ci) {
        SectionRenderDispatcher.RenderSection self =
                (SectionRenderDispatcher.RenderSection) (Object) this;
        if (self.getSectionNode() != newSectionNode) {
            if (ReviveRuntime.enabled())
                dev.veil.revive.client.VeilSectionResidencyGuard.markRelocated(self);
            dev.veil.revive.client.VeilHostRevisions.sectionRelocated(self);
        }
    }

    @Inject(method = "reset()V", at = @At("HEAD"), require = 1)
    private void veil$sectionReset(CallbackInfo ci) {
        if (!ReviveRuntime.enabled()) return;
        SectionRenderDispatcher.RenderSection self =
                (SectionRenderDispatcher.RenderSection) (Object) this;
        dev.veil.revive.client.VeilOriginalAttributeWork.retired(
                self.getSectionNode(), self.getSectionMesh());
        dev.veil.revive.client.VeilFluidGeometryHost.release(self.getSectionMesh());
        dev.veil.revive.client.VeilHostRevisions.meshChanged(self);
    }

    @Inject(
            method = {"reset()V", "setSectionNode(J)V"},
            at = @At("RETURN"),
            require = 1)
    private void veil$sectionMutationFinished(CallbackInfo ci) {
        if (ReviveRuntime.enabled())
            dev.veil.revive.client.VeilSectionChanges.changed(
                    (SectionRenderDispatcher.RenderSection) (Object) this);
    }

    @Inject(
            method =
                    "setSectionMesh(Lnet/minecraft/client/renderer/chunk/SectionMesh;)Lnet/minecraft/client/renderer/chunk/SectionMesh;",
            at = @At("RETURN"),
            require = 1)
    private void revive$meshInstalled(
            SectionMesh newMesh, CallbackInfoReturnable<SectionMesh> cir) {
        if (!ReviveRuntime.enabled()) return;
        SectionRenderDispatcher.RenderSection self =
                (SectionRenderDispatcher.RenderSection) (Object) this;
        SectionMesh oldMesh = cir.getReturnValue();
        if (oldMesh != null && oldMesh != newMesh)
            dev.veil.revive.client.VeilFluidGeometryHost.release(oldMesh);
        dev.veil.revive.client.VeilOriginalAttributeWork.installed(self, newMesh);
        VeilMinecraftTerrainBridge.onSectionMeshUpdated(self.getSectionNode());
        dev.veil.revive.client.VeilSectionResidencyGuard.markMeshInstalled(self);
        if (newMesh instanceof dev.veil.revive.client.VeilMeshExtras extras
                && extras.veil$metadata() != null) {
            extras.veil$metadata().attachProgressive(self, newMesh);
            dev.veil.revive.client.VeilRebuildBudget.recordInstalledMesh(
                    self.getSectionNode(), extras.veil$metadata().uploadBytes());
        }
        dev.veil.revive.client.VeilHostRevisions.meshChanged(self);
    }
}
