package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.renderer.extract.LevelExtractor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelExtractor.class)
public abstract class LevelExtractorFullTelemetryMixin {
    @Inject(method = "extract", at = @At("HEAD"), require = 0)
    private void veil$extractStart(CallbackInfo ci) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.WORLD_EXTRACT);
    }

    @Inject(method = "extract", at = @At("RETURN"), require = 0)
    private void veil$extractEnd(CallbackInfo ci) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.WORLD_EXTRACT);
    }

    @Inject(method = "extractVisibleBlockEntities", at = @At("HEAD"), require = 0)
    private void veil$blockEntityExtractStart(CallbackInfo ci) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.BLOCK_ENTITY_EXTRACT);
    }

    @Inject(method = "extractVisibleBlockEntities", at = @At("RETURN"), require = 0)
    private void veil$blockEntityExtractEnd(CallbackInfo ci) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.BLOCK_ENTITY_EXTRACT);
    }
}
