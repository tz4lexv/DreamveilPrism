package dev.veil.revive.client;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;

public final class VeilSectionDirtyState {
    private static final LongOpenHashSet DIRTY = new LongOpenHashSet();
    private static final LongOpenHashSet REFRESHED_AFTER_GLOBAL_INVALIDATION =
            new LongOpenHashSet();
    private static boolean globalInvalidation;

    private VeilSectionDirtyState() {}

    public static synchronized void markDirty(long sectionNode) {
        DIRTY.add(sectionNode);
        REFRESHED_AFTER_GLOBAL_INVALIDATION.remove(sectionNode);
    }

    public static synchronized void meshUpdated(long sectionNode) {
        DIRTY.remove(sectionNode);
        if (globalInvalidation) {
            REFRESHED_AFTER_GLOBAL_INVALIDATION.add(sectionNode);
        }
    }

    public static synchronized boolean isUnsafe(long sectionNode) {
        if (DIRTY.contains(sectionNode)) return true;
        return globalInvalidation && !REFRESHED_AFTER_GLOBAL_INVALIDATION.contains(sectionNode);
    }

    public static synchronized void invalidateAll() {
        DIRTY.clear();
        REFRESHED_AFTER_GLOBAL_INVALIDATION.clear();
        globalInvalidation = true;
    }

    public static synchronized void clearAll() {
        DIRTY.clear();
        REFRESHED_AFTER_GLOBAL_INVALIDATION.clear();
        globalInvalidation = false;
    }
}
