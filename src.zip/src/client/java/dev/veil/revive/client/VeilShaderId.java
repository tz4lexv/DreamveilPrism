package dev.veil.revive.client;

import java.util.ArrayDeque;
import java.util.Objects;

public record VeilShaderId(String namespace, String path) implements Comparable<VeilShaderId> {
    public VeilShaderId {
        Objects.requireNonNull(namespace, "namespace");
        Objects.requireNonNull(path, "path");
        if (!namespace.matches("[a-z0-9_.-]+")
                || path.isEmpty()
                || path.startsWith("/")
                || !path.matches("[a-zA-Z0-9_./-]+")) {
            throw new IllegalArgumentException("Invalid shader ID: " + namespace + ":" + path);
        }
        for (String part : path.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) {
                throw new IllegalArgumentException("Noncanonical shader path: " + path);
            }
        }
    }

    public static VeilShaderId parse(String value) {
        int separator = value.indexOf(':');
        if (separator <= 0)
            throw new IllegalArgumentException("Shader ID requires namespace:path: " + value);
        return new VeilShaderId(value.substring(0, separator), value.substring(separator + 1));
    }

    public VeilShaderId relative(String name) {
        if (name.indexOf(':') >= 0) return parse(name);
        if (name.startsWith("/") || name.indexOf('\\') >= 0) {
            throw new IllegalArgumentException("Invalid include path: " + name);
        }
        var parts = new ArrayDeque<String>();
        int slash = path.lastIndexOf('/');
        String joined = (slash < 0 ? "" : path.substring(0, slash + 1)) + name;
        for (String part : joined.split("/", -1)) {
            if (part.equals("..")) {
                if (parts.isEmpty())
                    throw new IllegalArgumentException("Include escapes asset root: " + name);
                parts.removeLast();
            } else if (!part.equals(".") && !part.isEmpty()) {
                parts.addLast(part);
            }
        }
        return new VeilShaderId(namespace, String.join("/", parts));
    }

    @Override
    public String toString() {
        return namespace + ":" + path;
    }

    @Override
    public int compareTo(VeilShaderId other) {
        return toString().compareTo(other.toString());
    }
}
