package dev.veil.api;

import java.util.HashSet;
import java.util.List;

public record VeilDraw(
        Kind kind,
        List<VertexBuffer> vertexBuffers,
        IndexBuffer indexBuffer,
        long elementCount,
        long instanceCount,
        long firstElement,
        int vertexOffset,
        long firstInstance,
        String indirectBuffer,
        long indirectOffset,
        int drawCount,
        int stride) {
    public static final int DRAW_INDIRECT_BYTES = 16;
    public static final int DRAW_INDEXED_INDIRECT_BYTES = 20;

    public enum Kind {
        DRAW,
        DRAW_INDEXED,
        DRAW_INDIRECT,
        DRAW_INDEXED_INDIRECT
    }

    public enum IndexType {
        UINT16,
        UINT32
    }

    public record VertexBuffer(int binding, String resource, long offset) {
        public VertexBuffer {
            if (binding < 0 || resource == null || resource.isBlank() || offset < 0) {
                throw new IllegalArgumentException("Invalid vertex buffer binding");
            }
        }
    }

    public record IndexBuffer(String resource, long offset, IndexType type) {
        public IndexBuffer {
            if (resource == null || resource.isBlank() || offset < 0 || type == null) {
                throw new IllegalArgumentException("Invalid index buffer binding");
            }
            int alignment = type == IndexType.UINT16 ? 2 : 4;
            if (offset % alignment != 0)
                throw new IllegalArgumentException(
                        "Index buffer offset is not aligned for " + type);
        }

        public int bytes() {
            return type == IndexType.UINT16 ? 2 : 4;
        }
    }

    public VeilDraw {
        if (kind == null) throw new IllegalArgumentException("Draw kind is missing");
        vertexBuffers =
                vertexBuffers.stream()
                        .sorted(java.util.Comparator.comparingInt(VertexBuffer::binding))
                        .toList();
        var bindings = new HashSet<Integer>();
        for (VertexBuffer buffer : vertexBuffers) {
            if (!bindings.add(buffer.binding()))
                throw new IllegalArgumentException(
                        "Duplicate draw vertex binding: " + buffer.binding());
        }
        boolean indexed = kind == Kind.DRAW_INDEXED || kind == Kind.DRAW_INDEXED_INDIRECT;
        boolean indirect = kind == Kind.DRAW_INDIRECT || kind == Kind.DRAW_INDEXED_INDIRECT;
        if (indexed != (indexBuffer != null))
            throw new IllegalArgumentException("Indexed draw requires exactly one index buffer");
        if (elementCount < 0
                || elementCount > 0xffff_ffffL
                || instanceCount < 0
                || instanceCount > 0xffff_ffffL
                || firstElement < 0
                || firstElement > 0xffff_ffffL
                || firstInstance < 0
                || firstInstance > 0xffff_ffffL) {
            throw new IllegalArgumentException("Draw unsigned fields exceed uint32 range");
        }
        if (indirect) {
            if (indirectBuffer == null
                    || indirectBuffer.isBlank()
                    || indirectOffset < 0
                    || (indirectOffset & 3L) != 0
                    || drawCount < 0
                    || stride < 0
                    || (stride & 3) != 0) {
                throw new IllegalArgumentException("Invalid indirect draw parameters");
            }
            int bytes = indexed ? DRAW_INDEXED_INDIRECT_BYTES : DRAW_INDIRECT_BYTES;
            if (drawCount > 1 && stride < bytes)
                throw new IllegalArgumentException(
                        "Indirect draw stride is smaller than its binary command");
            if (elementCount != 0
                    || instanceCount != 0
                    || firstElement != 0
                    || vertexOffset != 0
                    || firstInstance != 0) {
                throw new IllegalArgumentException(
                        "Indirect draws cannot declare direct draw fields");
            }
        } else if (indirectBuffer != null || indirectOffset != 0 || drawCount != 0 || stride != 0) {
            throw new IllegalArgumentException("Direct draws cannot declare indirect parameters");
        }
    }

    public boolean indexed() {
        return kind == Kind.DRAW_INDEXED || kind == Kind.DRAW_INDEXED_INDIRECT;
    }

    public boolean indirect() {
        return kind == Kind.DRAW_INDIRECT || kind == Kind.DRAW_INDEXED_INDIRECT;
    }

    public int commandBytes() {
        return indexed() ? DRAW_INDEXED_INDIRECT_BYTES : DRAW_INDIRECT_BYTES;
    }
}
