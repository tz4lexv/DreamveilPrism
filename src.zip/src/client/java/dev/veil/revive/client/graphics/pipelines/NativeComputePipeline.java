package dev.veil.revive.client.graphics.pipelines;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.revive.client.graphics.minecraft.DeferredGpuRetirement;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.client.graphics.minecraft.VulkanResult;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkComputePipelineCreateInfo;
import org.lwjgl.vulkan.VkSpecializationInfo;

import java.util.function.LongSupplier;

public final class NativeComputePipeline implements AutoCloseable {
    private final MinecraftVulkanContext runtime;
    private final LongSupplier layout;
    private final Runnable releaseDependencies;
    private final DeferredGpuRetirement closeRequested = new DeferredGpuRetirement();
    private long pipeline;

    private NativeComputePipeline(
            MinecraftVulkanContext runtime,
            LongSupplier layout,
            Runnable releaseDependencies,
            long pipeline) {
        this.runtime = runtime;
        this.layout = layout;
        this.releaseDependencies = releaseDependencies;
        this.pipeline = pipeline;
    }

    public static NativeComputePipeline create(
            MinecraftVulkanContext runtime,
            long module,
            LongSupplier layout,
            String entryPoint,
            VkSpecializationInfo specialization,
            LongSupplier pipelineCache,
            String operation,
            Runnable releaseDependencies) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        long pipeline = VK_NULL_HANDLE;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var info =
                    VkComputePipelineCreateInfo.calloc(1, stack)
                            .sType$Default()
                            .layout(layout.getAsLong());
            info.stage()
                    .sType$Default()
                    .stage(VK_SHADER_STAGE_COMPUTE_BIT)
                    .module(module)
                    .pName(stack.UTF8(entryPoint))
                    .pSpecializationInfo(specialization);
            var out = stack.callocLong(1);
            int result =
                    vkCreateComputePipelines(
                            runtime.vkDevice(), pipelineCache.getAsLong(), info, null, out);
            pipeline = out.get(0);
            VulkanResult.check(result, operation);
            return new NativeComputePipeline(runtime, layout, releaseDependencies, pipeline);
        } catch (RuntimeException failure) {
            if (pipeline != VK_NULL_HANDLE) vkDestroyPipeline(runtime.vkDevice(), pipeline, null);
            throw failure;
        }
    }

    public long handle() {
        if (closeRequested.closeRequested() || pipeline == VK_NULL_HANDLE)
            throw new IllegalStateException("Compute pipeline is closed");
        return pipeline;
    }

    public long layout() {
        if (closeRequested.closeRequested())
            throw new IllegalStateException("Compute pipeline is closed");
        return layout.getAsLong();
    }

    public void destroyNow() {
        closeRequested.markDestroyed();
        long old = pipeline;
        pipeline = VK_NULL_HANDLE;
        if (old != VK_NULL_HANDLE) vkDestroyPipeline(runtime.vkDevice(), old, null);
        releaseDependencies.run();
    }

    @Override
    public void close() {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        closeRequested.defer(action -> runtime.deferDestroy(action::run), this::destroyNow);
    }
}
