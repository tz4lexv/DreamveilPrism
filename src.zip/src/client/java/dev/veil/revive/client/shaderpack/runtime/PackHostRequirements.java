package dev.veil.revive.client.shaderpack.runtime;

import dev.veil.api.VeilScenePass;
import dev.veil.revive.client.VeilHostResourceRegistry;
import dev.veil.revive.client.VeilShaderPack;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;

public record PackHostRequirements(
        boolean opaqueSceneInputs,
        boolean materialInputs,
        boolean environment,
        boolean nativeLighting,
        boolean worldRayScene,
        boolean incrementalWorldRayScene,
        boolean creatorSceneData,
        boolean creatorGeometry,
        boolean creatorMeshData,
        boolean shadowLightData,
        boolean fluidGeometryWater,
        boolean fluidGeometryLava,
        int pbrAtlasMask,
        Map<VeilScenePass.Category, Integer> sceneCategoryCounts) {
    public PackHostRequirements {
        sceneCategoryCounts = Map.copyOf(sceneCategoryCounts);
    }

    public static PackHostRequirements from(VeilShaderPack pack) {
        var hosts = new HashSet<String>();
        boolean rayScene = false;
        for (var resource : pack.resources().values()) {
            if (resource.hostId() != null) hosts.add(resource.hostId());
            rayScene |= resource.worldRayScene();
        }
        var categories = new EnumMap<VeilScenePass.Category, Integer>(VeilScenePass.Category.class);
        boolean water = false;
        boolean lava = false;
        for (var pass : pack.passes()) {
            water |= !pass.compute() && pass.geometry().water();
            lava |= pass.geometry() == VeilShaderPack.Geometry.FLUID_LAVA;
            if (pass.scenePass()) {
                for (var category : pass.scene().categories()) {
                    categories.merge(category, 1, Integer::sum);
                }
            }
        }
        return new PackHostRequirements(
                hosts.contains(VeilHostResourceRegistry.SCENE_OPAQUE_COLOR)
                        || hosts.contains(VeilHostResourceRegistry.SCENE_OPAQUE_DEPTH),
                hosts.contains(VeilHostResourceRegistry.SCENE_MATERIAL_ID)
                        || hosts.contains(VeilHostResourceRegistry.SCENE_MATERIAL_DEPTH),
                hosts.contains(VeilHostResourceRegistry.ENVIRONMENT),
                hosts.contains(VeilHostResourceRegistry.NATIVE_LIGHTING),
                rayScene,
                pack.abiVersion() >= 17 && rayScene,
                hosts.contains(VeilHostResourceRegistry.CREATOR_LIGHTS)
                        || hosts.contains(VeilHostResourceRegistry.SHADOW_LIGHTS)
                        || hosts.contains(VeilHostResourceRegistry.CREATOR_INSTANCES)
                        || hosts.contains(VeilHostResourceRegistry.CREATOR_MATERIALS)
                        || hosts.contains(VeilHostResourceRegistry.CREATOR_GEOMETRY),
                hosts.contains(VeilHostResourceRegistry.CREATOR_GEOMETRY),
                hosts.contains(VeilHostResourceRegistry.CREATOR_MESHES),
                hosts.contains(VeilHostResourceRegistry.SHADOW_LIGHTS),
                pack.replacesVanilla().water() && water,
                pack.replacesVanilla().lava() && lava,
                (hosts.contains(VeilHostResourceRegistry.BLOCK_NORMAL_ATLAS) ? 1 : 0)
                        | (hosts.contains(VeilHostResourceRegistry.BLOCK_SPECULAR_ATLAS) ? 2 : 0),
                categories);
    }

    public boolean requestsSceneCategory(VeilScenePass.Category category) {
        return sceneCategoryCounts.getOrDefault(category, 0) > 0;
    }

    public boolean repeatsSceneCategory(VeilScenePass.Category category) {
        return sceneCategoryCounts.getOrDefault(category, 0) > 1;
    }
}
