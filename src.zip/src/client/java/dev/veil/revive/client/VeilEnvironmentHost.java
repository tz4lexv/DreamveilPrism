package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;

import dev.veil.revive.client.scene.environment.EnvironmentInputs;

final class VeilEnvironmentHost {
    static final int CAPACITY = EnvironmentInputs.CAPACITY;

    private VeilEnvironmentHost() {}

    static void prepare() {
        EnvironmentInputs.prepare(VeilHzb.STORAGE_USAGE);
    }

    static float rain() {
        return EnvironmentInputs.rain();
    }

    static GpuBuffer buffer() {
        return EnvironmentInputs.buffer();
    }

    static void close() {
        EnvironmentInputs.close();
    }
}
