package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderPassDescriptor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.terrain.ParametricTerrainQuads;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.resources.Identifier;

import org.joml.Vector4f;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Optional;

final class VeilParametricQuadsGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.parametricQuadsGpuProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final int WIDTH = 512, HEIGHT = 256, PREFIX_QUADS = 3, FIRST_INDEX = 8;
    private static final GpuTexture[] targets = new GpuTexture[3];
    private static final GpuTextureView[] views = new GpuTextureView[3];
    private static final GpuBuffer[] readbacks = new GpuBuffer[3];
    private static GpuBuffer words, indices;
    private static GpuFence fence;
    private static ByteBuffer original;
    private static int currentCase, count;

    private VeilParametricQuadsGpuProbe() {}

    static void tick() {
        if (!ENABLED || currentCase == 8) return;
        if (fence == null) {
            try {
                start();
            } catch (RuntimeException | Error failure) {
                close();
                throw failure;
            }
        } else if (fence.awaitCompletion(0)) {
            try {
                verifyReadback();
                ReviveMod.LOGGER.info(
                        "Veil parametric GPU case: PASS (layout={} indices={} vertices={} nonzero_base_vertex=12 first_index=8 shared_quad_indices=true no_vertex_attributes=true)",
                        ParametricTerrainQuads.Layout.values()[currentCase / 2],
                        (currentCase & 1) == 0 ? "SHORT" : "INT",
                        count);
                currentCase++;
                if (currentCase == 8)
                    ReviveMod.LOGGER.info(
                            "Veil parametric GPU decoder: PASS (four layouts, SHORT/INT, reconstructed position/UV/color/light, synthetic fixtures)");
            } finally {
                close();
            }
        }
    }

    private static void start() {
        var layout = ParametricTerrainQuads.Layout.values()[currentCase / 2];
        boolean wideIndex = (currentCase & 1) != 0;
        count = wideIndex ? 65540 : 4096;
        original = fixture(layout, count);
        var packed = ParametricTerrainQuads.encode(original, count);
        if (packed == null || packed.layout() != layout)
            throw new IllegalStateException("Parametric GPU fixture layout mismatch");
        var device = RenderSystem.getDevice();
        var builder =
                RenderPipeline.builder()
                        .withLocation(id("pipeline/parametric_probe_" + currentCase))
                        .withVertexShader(id("core/terrain_parametric_probe"))
                        .withFragmentShader(id("core/terrain_attributes_probe"))
                        .withPrimitiveTopology(PrimitiveTopology.POINTS)
                        .withCull(false)
                        .withDepthStencilState(Optional.empty())
                        .withShaderDefine("VEIL_QUAD_WORDS", layout.stride() / 4)
                        .withBindGroupLayout(
                                BindGroupLayout.builder()
                                        .withUniform(
                                                "VeilQuadWords",
                                                UniformType.TEXEL_BUFFER,
                                                GpuFormat.R32_SINT)
                                        .build());
        if (layout.flatColor()) builder.withShaderDefine("VEIL_QUAD_FLAT");
        if (layout.halfUv()) builder.withShaderDefine("VEIL_QUAD_HALF");
        var descriptor =
                RenderPassDescriptor.create(() -> "Veil parametric attributes")
                        .withRenderArea(new RenderPass.RenderArea(0, 0, WIDTH, HEIGHT));
        for (int i = 0; i < 3; i++) {
            var format = i == 2 ? GpuFormat.RGBA8_UNORM : GpuFormat.RGBA32_FLOAT;
            builder.withColorTargetState(
                    i, new ColorTargetState(Optional.empty(), format, ColorTargetState.WRITE_ALL));
            targets[i] =
                    device.createTexture(
                            "Veil parametric attribute " + i,
                            GpuTexture.USAGE_RENDER_ATTACHMENT | GpuTexture.USAGE_COPY_SRC,
                            format,
                            WIDTH,
                            HEIGHT,
                            1,
                            1);
            views[i] = device.createTextureView(targets[i]);
            descriptor.withColorAttachment(views[i], Optional.of(new Vector4f(0, 0, 0, 0)));
            readbacks[i] =
                    device.createBuffer(
                            () -> "Veil parametric readback",
                            GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                            (long) WIDTH * HEIGHT * format.blockSize());
        }
        var pipeline = builder.build();
        if (!device.precompilePipeline(pipeline).isValid())
            throw new IllegalStateException("Parametric decoder pipeline unavailable");
        ByteBuffer payload =
                ByteBuffer.allocateDirect(
                        packed.descriptors().length + PREFIX_QUADS * layout.stride());
        payload.position(PREFIX_QUADS * layout.stride()).put(packed.descriptors()).flip();
        words =
                device.createBuffer(
                        () -> "Veil parametric words",
                        GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER,
                        payload);
        int indexCount = count / 4 * 6;
        ByteBuffer indexBytes =
                ByteBuffer.allocateDirect((indexCount + FIRST_INDEX) * (wideIndex ? 4 : 2))
                        .order(ByteOrder.LITTLE_ENDIAN);
        indexBytes.position(FIRST_INDEX * (wideIndex ? 4 : 2));
        int[] corners = {0, 1, 2, 2, 3, 0};
        for (int q = 0; q < count / 4; q++)
            for (int corner : corners) {
                int vertex = q * 4 + corner;
                if (wideIndex) indexBytes.putInt(vertex);
                else indexBytes.putShort((short) vertex);
            }
        indexBytes.flip();
        indices =
                device.createBuffer(
                        () -> "Veil parametric shared indices", GpuBuffer.USAGE_INDEX, indexBytes);
        var encoder = device.createCommandEncoder();
        try (var pass = encoder.createRenderPass(descriptor)) {
            pass.setPipeline(pipeline);
            pass.setUniform("VeilQuadWords", words);
            pass.setIndexBuffer(indices, wideIndex ? IndexType.INT : IndexType.SHORT);
            pass.drawIndexed(indexCount, 1, FIRST_INDEX, PREFIX_QUADS * 4, 0);
        }
        for (int i = 0; i < 3; i++)
            encoder.copyTextureToBuffer(targets[i], readbacks[i], 0, () -> {}, 0);
        fence = encoder.createFence();
    }

    private static ByteBuffer fixture(ParametricTerrainQuads.Layout layout, int count) {
        ByteBuffer buffer = ByteBuffer.allocate(count * 28).order(ByteOrder.LITTLE_ENDIAN);
        int[][] orders = {
            {0, 1, 2, 3},
            {1, 2, 3, 0},
            {2, 3, 0, 1},
            {3, 0, 1, 2},
            {0, 3, 2, 1},
            {1, 0, 3, 2},
            {2, 1, 0, 3},
            {3, 2, 1, 0}
        };
        int[][] xy = {{0, 0}, {0, 1}, {1, 1}, {1, 0}};
        for (int q = 0; q < count / 4; q++)
            for (int c = 0; c < 4; c++) {
                int axis = q % 3, geom = orders[q % 8][c], uv = orders[(q / 8) % 8][c];
                float[] position = new float[3];
                position[axis] = (q % 513) / 32f;
                position[(axis + 1) % 3] = xy[geom][0] == 0 ? 0 : 16;
                position[(axis + 2) % 3] = xy[geom][1] == 0 ? 1f / 32 : 15.96875f;
                for (float value : position) buffer.putFloat(value);
                buffer.putInt(q * 0x9e3779b9 ^ (layout.flatColor() ? 0 : c * 0x03050709));
                buffer.putFloat(xy[uv][0] == 0 ? (layout.halfUv() ? -0.5f : 0.1f) : 1);
                buffer.putFloat(xy[uv][1] == 0 ? 0.25f : (layout.halfUv() ? 1.5f : 0.9f));
                buffer.putInt(((q + c) % 16 << 4) | ((q * 3 + c) % 16 << 20));
            }
        return buffer.flip();
    }

    private static void verifyReadback() {
        VeilTerrainAttributeReadback.verify(
                original, readbacks, WIDTH, HEIGHT, 0, "Synthetic parametric");
    }

    static void requireComplete() {
        if (ENABLED && currentCase != 8)
            throw new IllegalStateException(
                    "Parametric GPU probe incomplete: " + currentCase + "/8");
    }

    private static void close() {
        if (fence != null) {
            fence.close();
            fence = null;
        }
        if (words != null) {
            words.close();
            words = null;
        }
        if (indices != null) {
            indices.close();
            indices = null;
        }
        for (int i = 0; i < 3; i++) {
            if (readbacks[i] != null) {
                readbacks[i].close();
                readbacks[i] = null;
            }
            if (views[i] != null) {
                views[i].close();
                views[i] = null;
            }
            if (targets[i] != null) {
                targets[i].close();
                targets[i] = null;
            }
        }
        original = null;
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }
}
