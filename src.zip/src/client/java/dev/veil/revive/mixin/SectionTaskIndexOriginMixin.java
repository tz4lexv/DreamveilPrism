package dev.veil.revive.mixin;

import dev.veil.revive.client.terrain.QueuedSectionTaskOrigin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(
        targets =
                "net.minecraft.client.renderer.chunk.SectionRenderDispatcher$RenderSection$SectionTask")
public abstract class SectionTaskIndexOriginMixin implements QueuedSectionTaskOrigin {
    @Unique private long veil$queueIndexKey;

    @Override
    public void veil$setQueueIndexKey(long key) {
        veil$queueIndexKey = key;
    }

    @Override
    public long veil$getQueueIndexKey() {
        return veil$queueIndexKey;
    }
}
