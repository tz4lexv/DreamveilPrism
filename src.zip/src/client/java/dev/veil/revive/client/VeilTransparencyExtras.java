package dev.veil.revive.client;

public interface VeilTransparencyExtras {
    VeilTransparencyState veil$transparencyState();

    VeilTransparencyOrder veil$transparencyOrder();

    void veil$transparencyOrder(VeilTransparencyOrder order);
}
