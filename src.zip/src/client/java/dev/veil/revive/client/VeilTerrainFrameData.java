package dev.veil.revive.client;

import dev.veil.revive.core.terrain.TerrainSectionColumns;

import net.minecraft.client.renderer.DynamicUniforms;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;

import java.util.BitSet;

public final class VeilTerrainFrameData
        implements dev.veil.revive.client.terrain.capture.TerrainPlanSource.Origins {
    private final TerrainSectionColumns columns;
    private final Matrix4f modelView = new Matrix4f();
    private int atlasWidth, atlasHeight;
    private long fallbackMaterializations;

    public VeilTerrainFrameData() {
        this(Boolean.getBoolean("veil.sparseSectionUploads"));
    }

    VeilTerrainFrameData(boolean sparse) {
        columns = new TerrainSectionColumns(sparse);
    }

    void begin(Matrix4fc sourceModelView, int atlasWidth, int atlasHeight, int count) {
        modelView.set(sourceModelView);
        this.atlasWidth = atlasWidth;
        this.atlasHeight = atlasHeight;
        columns.begin(count);
    }

    void set(int index, int x, int y, int z, float visibility, boolean changed) {
        columns.set(index, x, y, z, visibility, changed);
    }

    DynamicUniforms.ChunkSectionInfo[] materializeFallbackInfos(
            VeilSharedSectionUniforms uniforms) {
        fallbackMaterializations++;
        uniforms.begin(modelView);
        for (int i = 0; i < columns.count(); i++) {
            uniforms.add(
                    columns.x(i),
                    columns.y(i),
                    columns.z(i),
                    columns.visibility(i),
                    atlasWidth,
                    atlasHeight);
        }
        return uniforms.finish();
    }

    Matrix4fc modelView() {
        return modelView;
    }

    int atlasWidth() {
        return atlasWidth;
    }

    int atlasHeight() {
        return atlasHeight;
    }

    @Override
    public int count() {
        return columns.count();
    }

    int dirtyFirst() {
        return columns.dirtyFirst();
    }

    int dirtyLast() {
        return columns.dirtyLast();
    }

    boolean hasDirtyEntries() {
        return columns.hasDirtyEntries();
    }

    BitSet dirtyEntries() {
        return columns.dirtyEntries();
    }

    @Override
    public int x(int index) {
        return columns.x(index);
    }

    @Override
    public int y(int index) {
        return columns.y(index);
    }

    @Override
    public int z(int index) {
        return columns.z(index);
    }

    float visibility(int index) {
        return columns.visibility(index);
    }

    long primitiveUpdates() {
        return columns.primitiveUpdates();
    }

    long fallbackMaterializations() {
        return fallbackMaterializations;
    }
}
