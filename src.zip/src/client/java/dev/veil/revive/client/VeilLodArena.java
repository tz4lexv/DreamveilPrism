package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;

import dev.veil.revive.core.AutoLodProfitabilityPolicy;
import dev.veil.revive.core.DirectionalQuadBuckets;
import dev.veil.revive.core.PlanarTerrainLod;
import dev.veil.revive.core.TerrainUploadBudget;
import dev.veil.revive.core.VoxelClipmapPlanner;
import dev.veil.revive.core.WallClockCadence;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.*;

import org.lwjgl.system.MemoryUtil;

import java.util.*;

public final class VeilLodArena {
    private static final long MAX_BYTES = 32L << 20;
    private static StagingBuffer staging;
    private static VeilManagedGpuArena<SectionMesh> arena;
    private static final IdentityHashMap<SectionMesh, Entry> entries = new IdentityHashMap<>();
    private static final IdentityHashMap<SectionMesh, Slice> residentSelections =
            new IdentityHashMap<>();
    private static final boolean RESIDENT_COMMANDS =
            Boolean.getBoolean("veil.residentTerrainCommands");
    private static long residentSelectionReuses, residentSelectionRetirements;
    private static final boolean VERIFY_RESIDENT_SELECTIONS =
            dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.verifyStablePackets");
    private static long verifiedResidentSelections;
    private static IdentityHashMap<SectionMesh, Slice> selected = new IdentityHashMap<>(),
            next = new IdentityHashMap<>();
    private static final IdentityHashMap<SectionMesh, Boolean> eligible = new IdentityHashMap<>();
    private static final IdentityHashMap<SectionMesh, CompactReject> compactRejectedAtlas =
            new IdentityHashMap<>();
    private static final ArrayList<Candidate> UPLOAD_CANDIDATES = new ArrayList<>();
    private static final ArrayDeque<Candidate> CANDIDATE_POOL = new ArrayDeque<>();
    private static final ArrayList<Entry> SELECTED_ENTRIES = new ArrayList<>();
    private static final ArrayList<Slice> SELECTED_SLICES = new ArrayList<>();
    private static final boolean VERIFY_SELECTION_CHECKS =
            Boolean.getBoolean("veil.verifyLodChecks");
    private static int verifiedSelectionChecks;
    private static final int MAX_POOLED_CANDIDATES = 4096;
    private static long candidateReuses, sliceReuses, directionalQuadsOmitted;
    private static int directionalQuadsOmittedCurrent;
    private static int voxelCellSectionsCurrent;
    private static final VoxelClipmapPlanner CLIPMAP = new VoxelClipmapPlanner();
    private static final TerrainUploadBudget UPLOAD_BUDGET = new TerrainUploadBudget();
    private static final Comparator<Candidate> UPLOAD_ORDER =
            Comparator.comparingDouble(Candidate::uploadValue)
                    .reversed()
                    .thenComparing(Comparator.comparingDouble(Candidate::distanceSq).reversed());
    private static final int MAX_UPLOAD_RESERVE_BYTES = 4 << 20;
    private static long uploadDeadlineDeferrals;
    private static java.nio.ByteBuffer uploadScratch;
    private static long revision, residentBytes, uploadedBytes, selectedQuadsSaved;
    private static long submittedDraws;
    private static int eligibleSections, selectedQuadsSavedCurrent, selectedProtectedQuadsCurrent;
    private static long selectedBytesSavedCurrent,
            selectedOriginalBytesCurrent,
            selectedOptimizedBytesCurrent;
    private static long selectedMergedInputQuadsCurrent, selectedAffineGradientQuadsCurrent;
    private static long selectedSubBlockQuadsCurrent, selectedDuplicateQuadsCurrent;

    private static boolean autoStandaloneProfitable;
    private static long autoStandaloneEvaluations, autoStandaloneAccepted, autoStandaloneRejected;
    private static long autoStandaloneEnables, autoStandaloneDisables;

    private static final long SELECTION_REFRESH_NS = 100_000_000L;
    private static final long RESIDENCY_RETENTION_NS = 2_000_000_000L;
    private static final double CAMERA_FORCE_DISTANCE_SQ = 16.0;
    private static final WallClockCadence SELECTION_CADENCE = new WallClockCadence();
    private static boolean selectionStampValid;
    private static long lastVisibilityRevision = Long.MIN_VALUE;
    private static long lastMeshRevision = Long.MIN_VALUE;
    private static long lastOriginRevision = Long.MIN_VALUE;
    private static long lastGlobalRevision = Long.MIN_VALUE;
    private static long lastAtlasKey = Long.MIN_VALUE;
    private static int lastConfiguredDistance = Integer.MIN_VALUE;
    private static double lastCameraX, lastCameraY, lastCameraZ;
    private static long selectionUpdateRuns,
            selectionFastSkips,
            selectionRevisionForces,
            selectionCameraForces,
            selectionCadenceRefreshes;
    private static long selectionUpdateNanos;

    static SelectionCounters selectionCounters() {
        return new SelectionCounters(
                selectionUpdateRuns,
                selectionFastSkips,
                selectionRevisionForces,
                selectionUpdateNanos);
    }

    record SelectionCounters(long runs, long skips, long revisionForces, long updateNanos) {}

    private VeilLodArena() {}

    public record Slice(
            GpuBuffer buffer,
            int baseVertex,
            int indexCount,
            DirectionalQuadBuckets.Layout buckets,
            int faceMask,
            boolean voxelCells) {}

    private static final class Entry {
        final PlanarTerrainLod.Result mesh;
        final DirectionalQuadBuckets.Layout buckets;
        int gpuStride = PlanarTerrainLod.GPU_STRIDE;
        int gpuBytes;
        int sectionIndex;
        long lastSeenNanos;

        Entry(
                PlanarTerrainLod.Result mesh,
                DirectionalQuadBuckets.Layout buckets,
                int sectionIndex,
                long nowNanos) {
            this.mesh = mesh;
            this.gpuBytes = mesh.optimizedBytes();
            this.buckets = buckets;
            this.sectionIndex = sectionIndex;
            lastSeenNanos = nowNanos;
        }
    }

    private static final class CompactReject {
        final long atlasKey;
        long lastSeenNanos;

        CompactReject(long atlasKey, long nowNanos) {
            this.atlasKey = atlasKey;
            this.lastSeenNanos = nowNanos;
        }
    }

    public static void update(ChunkSectionsToRender terrain, VeilTerrainFrameData infos) {
        if (!VeilVideoConfig.on("renderer.lod")) {
            if (!selected.isEmpty() || arena != null || !entries.isEmpty()) close();
            return;
        }
        if (!RenderSystem.getDevice().getDeviceInfo().backendName().equalsIgnoreCase("Vulkan"))
            return;

        final long nowNanos = System.nanoTime();
        var camera = Minecraft.getInstance().gameRenderer.mainCamera().position();
        int configuredBudget = VeilVideoConfig.number("lod.uploadKiB", 512, 64, 2048) << 10;
        int configuredDistance = VeilVideoConfig.number("lod.distance", 48, 0, 512);
        long atlasKey = ((long) infos.atlasWidth() << 32) ^ (infos.atlasHeight() & 0xffffffffL);
        if (selectionStampValid && lastAtlasKey != atlasKey) close();

        long visibilityRevision = VeilHostRevisions.visibility();
        long meshRevision = VeilHostRevisions.mesh();
        long originRevision = VeilHostRevisions.origin();
        long globalRevision = VeilHostRevisions.global();
        boolean revisionChanged =
                !selectionStampValid
                        || visibilityRevision != lastVisibilityRevision
                        || meshRevision != lastMeshRevision
                        || originRevision != lastOriginRevision
                        || globalRevision != lastGlobalRevision
                        || atlasKey != lastAtlasKey
                        || configuredDistance != lastConfiguredDistance;
        double cameraDx = camera.x - lastCameraX;
        double cameraDy = camera.y - lastCameraY;
        double cameraDz = camera.z - lastCameraZ;
        boolean cameraMoved =
                !selectionStampValid
                        || cameraDx * cameraDx + cameraDy * cameraDy + cameraDz * cameraDz
                                >= CAMERA_FORCE_DISTANCE_SQ;
        boolean cadenceDue = !selectionStampValid || SELECTION_CADENCE.ready(nowNanos);

        if (selectionStampValid
                && !revisionChanged
                && !cameraMoved
                && !cadenceDue
                && !directionMaskChanged(infos, camera)) {
            selectionFastSkips++;

            if (!selected.isEmpty()) selectedQuadsSaved += selectedQuadsSavedCurrent;
            return;
        }

        if (selectionStampValid) {
            if (revisionChanged) selectionRevisionForces++;
            else if (cameraMoved) selectionCameraForces++;
            else if (cadenceDue) selectionCadenceRefreshes++;
        }
        long selectionStartNs =
                (VeilDiagnostics.benchmarkActive()
                                || ReviveRuntime.config().profilerEnabled()
                                || VeilCameraSweepProbe.enabled())
                        ? System.nanoTime()
                        : 0L;
        selectionUpdateRuns++;

        resetSelection();
        collectCandidates(terrain, infos, camera, configuredDistance, atlasKey, nowNanos);
        retireResidentMeshes(nowNanos);
        boolean staged = stageCandidates(infos, configuredBudget, atlasKey, nowNanos);
        retireRejectedMeshes(nowNanos);
        uploadStagedMeshes(staged);
        if (arena != null) arena.maintain();
        VeilPackedTerrain.maintain();
        publishSelection(infos, camera);

        selectionStampValid = true;
        SELECTION_CADENCE.scheduleFrom(nowNanos, SELECTION_REFRESH_NS);
        lastVisibilityRevision = visibilityRevision;
        lastMeshRevision = meshRevision;
        lastOriginRevision = originRevision;
        lastGlobalRevision = globalRevision;
        lastAtlasKey = atlasKey;
        lastConfiguredDistance = configuredDistance;
        lastCameraX = camera.x;
        lastCameraY = camera.y;
        lastCameraZ = camera.z;
        if (selectionStartNs != 0L) selectionUpdateNanos += System.nanoTime() - selectionStartNs;
    }

    private static void resetSelection() {
        selectionStampValid = false;
        next.clear();
        eligible.clear();
        eligibleSections = 0;
        selectedQuadsSavedCurrent = 0;
        selectedBytesSavedCurrent = 0L;
        selectedOriginalBytesCurrent = 0L;
        selectedOptimizedBytesCurrent = 0L;
        selectedProtectedQuadsCurrent = 0;
        selectedMergedInputQuadsCurrent = 0L;
        selectedAffineGradientQuadsCurrent = 0L;
        selectedSubBlockQuadsCurrent = 0L;
        selectedDuplicateQuadsCurrent = 0L;
        directionalQuadsOmittedCurrent = 0;
        voxelCellSectionsCurrent = 0;

        recycleCandidates();
    }

    private static boolean directionMaskChanged(
            VeilTerrainFrameData infos, net.minecraft.world.phys.Vec3 camera) {
        boolean changed = cachedDirectionMaskChanged(infos, camera);
        if (VERIFY_SELECTION_CHECKS && verifiedSelectionChecks < 20000) {
            if (changed != legacyDirectionMaskChanged(infos, camera))
                throw new IllegalStateException("Cached LOD selection check differs from live map");
            if (verifiedSelectionChecks == 999)
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil LOD selection verification PASS: 1000 cached checks match live map; verification continues");
            if (++verifiedSelectionChecks == 20000)
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil LOD selection verification PASS: 20000 cached checks match live map");
        }
        return changed;
    }

    private static boolean cachedDirectionMaskChanged(
            VeilTerrainFrameData infos, net.minecraft.world.phys.Vec3 camera) {
        java.util.List<VoxelClipmapPlanner.Ring> rings = null;
        for (int i = 0; i < SELECTED_ENTRIES.size(); i++) {
            Entry entry = SELECTED_ENTRIES.get(i);
            if (entry.buckets == null || !entry.buckets.active()) continue;
            Slice slice = SELECTED_SLICES.get(i);
            if (slice.faceMask() != visibleMask(entry, infos, camera)) return true;
            if (entry.buckets.cells() != null) {
                if (rings == null) rings = clipmapRings(camera);
                if (slice.voxelCells() != useVoxelCells(entry, infos, rings)) return true;
            }
        }
        return false;
    }

    private static boolean legacyDirectionMaskChanged(
            VeilTerrainFrameData infos, net.minecraft.world.phys.Vec3 camera) {
        java.util.List<VoxelClipmapPlanner.Ring> rings = null;
        for (var selectedEntry : selected.entrySet()) {
            Entry entry = entries.get(selectedEntry.getKey());
            if (entry == null || entry.buckets == null || !entry.buckets.active()) continue;
            if (selectedEntry.getValue().faceMask() != visibleMask(entry, infos, camera))
                return true;
            if (entry.buckets.cells() != null) {
                if (rings == null) rings = clipmapRings(camera);
                if (selectedEntry.getValue().voxelCells() != useVoxelCells(entry, infos, rings))
                    return true;
            }
        }
        return false;
    }

    private static java.util.List<VoxelClipmapPlanner.Ring> clipmapRings(
            net.minecraft.world.phys.Vec3 camera) {
        return CLIPMAP.plan(
                (int) Math.floor(camera.x / 16.0), (int) Math.floor(camera.z / 16.0), 3, 12);
    }

    private static boolean useVoxelCells(
            Entry entry,
            VeilTerrainFrameData infos,
            java.util.List<VoxelClipmapPlanner.Ring> rings) {
        if (!VeilVideoConfig.flag("renderer.voxelCellCulling", true)
                || !VeilVideoConfig.on("renderer.hzb")
                || entry.buckets == null
                || entry.buckets.cells() == null) return false;
        int index = entry.sectionIndex;
        if (index < 0 || index >= infos.count()) return false;
        return CLIPMAP.levelAt(rings, infos.x(index) >> 4, infos.z(index) >> 4) > 0;
    }

    private static int visibleMask(
            Entry entry, VeilTerrainFrameData infos, net.minecraft.world.phys.Vec3 camera) {
        if (!VeilVideoConfig.flag("renderer.directionalBuckets", true)
                || !VeilIndirectTerrain.lodPipelineCulls()) return 63;
        int index = entry.sectionIndex;
        if (index < 0 || index >= infos.count()) return 63;
        return entry.buckets.visibleMask(
                camera.x - infos.x(index),
                camera.y - infos.y(index),
                camera.z - infos.z(index),
                5.0);
    }

    private static void collectCandidates(
            ChunkSectionsToRender terrain,
            VeilTerrainFrameData infos,
            net.minecraft.world.phys.Vec3 camera,
            int configuredDistance,
            long atlasKey,
            long nowNanos) {
        for (var group : terrain.drawGroupsPerLayer().get(ChunkSectionLayer.SOLID).values())
            for (var draw : group) {
                if (!(draw.uniformUploaderConsumer()
                        instanceof VeilSectionUniformUploader uploader)) continue;
                if (!(uploader.mesh() instanceof VeilMeshExtras extras)
                        || extras.veil$metadata() == null) continue;
                var lod = extras.veil$metadata().lod();
                if (lod == null || lod.bytesSaved() <= 0 || lod.quadsSaved() <= 0) continue;
                CompactReject reject = compactRejectedAtlas.get(uploader.mesh());
                if (reject != null) {
                    if (reject.atlasKey == atlasKey) {
                        reject.lastSeenNanos = nowNanos;
                        continue;
                    }
                    compactRejectedAtlas.remove(uploader.mesh());
                }

                int sectionIndex = uploader.index();
                double dx = infos.x(sectionIndex) + 8 - camera.x,
                        dy = infos.y(sectionIndex) + 8 - camera.y,
                        dz = infos.z(sectionIndex) + 8 - camera.z;
                double distanceSq = dx * dx + dy * dy + dz * dz;
                double boundary =
                        selectionDistance(
                                configuredDistance, lod, selected.containsKey(uploader.mesh()));
                if (distanceSq < boundary * boundary) continue;

                if (eligible.put(uploader.mesh(), true) != null) continue;
                eligibleSections++;
                Entry entry = entries.get(uploader.mesh());
                if (entry != null) {
                    entry.sectionIndex = sectionIndex;
                    entry.lastSeenNanos = nowNanos;
                    continue;
                }

                Candidate candidate = CANDIDATE_POOL.pollFirst();
                if (candidate == null) candidate = new Candidate();
                else candidateReuses++;
                candidate.mesh = uploader.mesh();
                candidate.lod = lod;
                candidate.buckets = extras.veil$metadata().lodBuckets();
                candidate.sectionIndex = sectionIndex;
                candidate.distanceSq = distanceSq;
                UPLOAD_CANDIDATES.add(candidate);
            }

        UPLOAD_CANDIDATES.sort(UPLOAD_ORDER);
    }

    private static void retireResidentMeshes(long nowNanos) {
        if (arena != null || !entries.isEmpty()) {
            for (var it = entries.entrySet().iterator(); it.hasNext(); ) {
                var entry = it.next();
                if (nowNanos - entry.getValue().lastSeenNanos > RESIDENCY_RETENTION_NS) {
                    if (entry.getValue().gpuStride == PlanarTerrainLod.GPU_STRIDE)
                        arena.removeAllocation(entry.getKey());
                    else VeilPackedTerrain.remove(entry.getKey());
                    residentBytes -= entry.getValue().gpuBytes;
                    it.remove();
                }
            }
        }
    }

    private static boolean stageCandidates(
            VeilTerrainFrameData infos, int configuredBudget, long atlasKey, long nowNanos) {
        boolean staged = false;
        long uploadStartNs = System.nanoTime();
        long cpuUploadBudgetNs =
                Math.clamp(
                        (long)
                                (ReviveRuntime.maintenanceBudgetNanos()
                                        * 0.25
                                        * VeilRebuildBudget.lodUploadScale()),
                        100_000L,
                        1_000_000L);
        UPLOAD_BUDGET.begin(
                uploadStartNs,
                adaptiveUploadBudget(configuredBudget),
                MAX_UPLOAD_RESERVE_BYTES,
                cpuUploadBudgetNs);

        for (Candidate candidate : UPLOAD_CANDIDATES) {
            long uploadNowNs = System.nanoTime();
            if (!UPLOAD_BUDGET.timeAvailable(uploadNowNs)) {
                uploadDeadlineDeferrals++;
                break;
            }
            var lod = candidate.lod();
            int bytes = lod.optimizedBytes();
            if (!UPLOAD_BUDGET.canUpload(bytes, uploadNowNs) || residentBytes + bytes > MAX_BYTES)
                continue;
            ensureUploadScratch(bytes);
            uploadScratch.clear();
            if (!PlanarTerrainLod.writeGpuVertices(
                    lod, infos.atlasWidth(), infos.atlasHeight(), uploadScratch)) {
                compactRejectedAtlas.put(candidate.mesh(), new CompactReject(atlasKey, nowNanos));
                continue;
            }
            uploadScratch.flip();
            int packedStride = VeilPackedTerrain.stage(candidate.mesh(), uploadScratch);
            if (packedStride != 0) {
                int packedBytes = lod.quads() * 4 * packedStride;
                Entry entry = new Entry(lod, candidate.buckets, candidate.sectionIndex, nowNanos);
                entry.gpuStride = packedStride;
                entry.gpuBytes = packedBytes;
                entries.put(candidate.mesh(), entry);
                UPLOAD_BUDGET.consume(packedBytes);
                residentBytes += packedBytes;
                uploadedBytes += packedBytes;
                staged = true;
                continue;
            }
            if (arena == null) {
                staging =
                        new VeilPersistentStagingBuffer(
                                "Veil exact merged terrain upload ring", 4 << 20);
                arena =
                        new VeilManagedGpuArena<>(
                                "Veil exact merged terrain",
                                GpuBuffer.USAGE_VERTEX,
                                16 << 20,
                                PlanarTerrainLod.GPU_STRIDE,
                                staging);
            }
            if (!arena.addAllocation(candidate.mesh(), null, uploadScratch)) continue;
            staged = true;
            entries.put(
                    candidate.mesh(),
                    new Entry(lod, candidate.buckets, candidate.sectionIndex, nowNanos));
            UPLOAD_BUDGET.consume(bytes);
            residentBytes += bytes;
            uploadedBytes += bytes;
        }

        return staged;
    }

    private static void retireRejectedMeshes(long nowNanos) {
        for (var it = compactRejectedAtlas.entrySet().iterator(); it.hasNext(); ) {
            if (nowNanos - it.next().getValue().lastSeenNanos > RESIDENCY_RETENTION_NS) it.remove();
        }
    }

    private static void uploadStagedMeshes(boolean staged) {
        if (staged) VeilPackedTerrain.upload();
        if (arena != null) {
            if (staged)
                try (var uploader =
                        staging.startUploading(RenderSystem.getDevice().createCommandEncoder())) {
                    arena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
                }
        }
    }

    private static void publishSelection(
            VeilTerrainFrameData infos, net.minecraft.world.phys.Vec3 camera) {
        SELECTED_ENTRIES.clear();
        SELECTED_SLICES.clear();
        var rings = clipmapRings(camera);
        if (arena != null || !entries.isEmpty()) {
            for (var mesh : eligible.keySet()) {
                var entry = entries.get(mesh);
                if (entry == null) continue;
                var owner =
                        entry.gpuStride == PlanarTerrainLod.GPU_STRIDE
                                ? arena
                                : VeilPackedTerrain.arena(mesh);
                var allocation = owner == null ? null : owner.getAllocation(mesh);
                if (allocation != null) {
                    GpuBuffer buffer =
                            entry.gpuStride == PlanarTerrainLod.GPU_STRIDE
                                    ? owner.getGpuBuffer(allocation)
                                    : VeilPackedTerrain.buffer(mesh, allocation);
                    int baseVertex = (int) (allocation.offset() / entry.gpuStride);
                    int indexCount = entry.mesh.quads() * 6;
                    int faceMask = visibleMask(entry, infos, camera);
                    boolean voxelCells = useVoxelCells(entry, infos, rings);
                    Slice slice = selected.get(mesh);
                    if (slice != null
                            && slice.buffer() == buffer
                            && slice.baseVertex() == baseVertex
                            && slice.indexCount() == indexCount
                            && slice.buckets() == entry.buckets
                            && slice.faceMask() == faceMask
                            && slice.voxelCells() == voxelCells) sliceReuses++;
                    else
                        slice =
                                new Slice(
                                        buffer,
                                        baseVertex,
                                        indexCount,
                                        entry.buckets,
                                        faceMask,
                                        voxelCells);
                    next.put(mesh, slice);
                    SELECTED_ENTRIES.add(entry);
                    SELECTED_SLICES.add(slice);
                    if (voxelCells) voxelCellSectionsCurrent++;
                    if (entry.buckets != null) {
                        int omitted = entry.buckets.culledQuads(faceMask);
                        directionalQuadsOmittedCurrent += omitted;
                        directionalQuadsOmitted += omitted;
                    }
                    int savedQuads = entry.mesh.quadsSaved();
                    selectedQuadsSaved += savedQuads;
                    selectedQuadsSavedCurrent += savedQuads;
                    selectedBytesSavedCurrent += entry.mesh.originalBytes() - entry.gpuBytes;
                    selectedOriginalBytesCurrent += entry.mesh.originalBytes();
                    selectedOptimizedBytesCurrent += entry.gpuBytes;
                    selectedProtectedQuadsCurrent += entry.mesh.protectedQuads();
                    selectedMergedInputQuadsCurrent += entry.mesh.mergedInputQuads();
                    selectedAffineGradientQuadsCurrent += entry.mesh.affineGradientQuads();
                    selectedSubBlockQuadsCurrent += entry.mesh.subBlockQuads();
                    selectedDuplicateQuadsCurrent += entry.mesh.duplicateQuadsRemoved();
                }
            }
        }
        boolean changed = next.size() != selected.size();
        if (!changed)
            for (var entry : next.entrySet())
                if (!entry.getValue().equals(selected.get(entry.getKey()))) {
                    changed = true;
                    break;
                }
        if (RESIDENT_COMMANDS) {
            for (var iterator = residentSelections.entrySet().iterator(); iterator.hasNext(); ) {
                var retained = iterator.next();
                var refreshed = refreshResidentSlice(retained.getKey(), retained.getValue());
                if (refreshed == null) {
                    iterator.remove();
                    residentSelectionRetirements++;
                    changed = true;
                } else if (!refreshed.equals(retained.getValue())) {
                    retained.setValue(refreshed);
                    changed = true;
                }
            }
            for (var selection : next.entrySet()) {
                var previous = residentSelections.put(selection.getKey(), selection.getValue());
                if (!selection.getValue().equals(previous)) changed = true;
            }
        }
        if (changed) revision++;
        var old = selected;
        selected = next;
        next = old;
        refreshAutoStandaloneProfitability();
    }

    private static void recycleCandidates() {
        for (Candidate candidate : UPLOAD_CANDIDATES) {
            candidate.mesh = null;
            candidate.lod = null;
            candidate.buckets = null;
            if (CANDIDATE_POOL.size() < MAX_POOLED_CANDIDATES) CANDIDATE_POOL.addLast(candidate);
        }
        UPLOAD_CANDIDATES.clear();
    }

    private static final class Candidate {
        SectionMesh mesh;
        PlanarTerrainLod.Result lod;
        DirectionalQuadBuckets.Layout buckets;
        int sectionIndex;
        double distanceSq;

        SectionMesh mesh() {
            return mesh;
        }

        PlanarTerrainLod.Result lod() {
            return lod;
        }

        double distanceSq() {
            return distanceSq;
        }

        double uploadValue() {
            return (double) lod.bytesSaved() / Math.max(1, lod.optimizedBytes());
        }
    }

    private static double selectionDistance(
            int configuredDistance, PlanarTerrainLod.Result lod, boolean alreadySelected) {
        double byteReduction = (double) lod.bytesSaved() / Math.max(1, lod.originalBytes());

        double boundary =
                byteReduction >= 0.60
                        ? 0.0
                        : byteReduction >= 0.45
                                ? Math.min(16.0, configuredDistance)
                                : byteReduction >= 0.30
                                        ? Math.min(32.0, configuredDistance)
                                        : byteReduction >= 0.18
                                                ? Math.min(48.0, configuredDistance)
                                                : configuredDistance;
        if (alreadySelected) boundary = Math.max(0.0, boundary - 16.0);
        return boundary;
    }

    private static int adaptiveUploadBudget(int configuredBytes) {
        double framePressure = ReviveRuntime.framePressure();
        double frameScale;
        if (framePressure <= 0.80) frameScale = 1.50;
        else if (framePressure <= 1.00) frameScale = 1.00;
        else if (framePressure <= 1.15) frameScale = 0.60;
        else if (framePressure <= 1.35) frameScale = 0.35;
        else frameScale = 0.15;

        double memoryPressure = VeilMemoryMonitor.pressure();
        double memoryScale =
                memoryPressure >= 0.97
                        ? 0.10
                        : memoryPressure >= 0.92 ? 0.35 : memoryPressure >= 0.85 ? 0.65 : 1.0;

        long scaled =
                Math.round(
                        configuredBytes
                                * frameScale
                                * memoryScale
                                * VeilRebuildBudget.lodUploadScale());
        return (int) Math.max(16L << 10, Math.min((long) configuredBytes * 2L, scaled));
    }

    private static void ensureUploadScratch(int minimumBytes) {
        if (uploadScratch != null && uploadScratch.capacity() >= minimumBytes) return;
        int capacity = Math.max(64, minimumBytes);
        if (capacity < (1 << 30)) {
            int highest = Integer.highestOneBit(capacity - 1);
            capacity = highest <= 0 ? 64 : highest << 1;
        }
        if (uploadScratch != null) MemoryUtil.memFree(uploadScratch);
        uploadScratch = MemoryUtil.memAlloc(capacity);
    }

    private static void refreshAutoStandaloneProfitability() {
        autoStandaloneEvaluations++;
        boolean nextProfitable =
                AutoLodProfitabilityPolicy.profitable(
                        autoStandaloneProfitable,
                        selected.size(),
                        selectedBytesSavedCurrent,
                        selectedOriginalBytesCurrent);
        if (nextProfitable) autoStandaloneAccepted++;
        else autoStandaloneRejected++;
        if (nextProfitable != autoStandaloneProfitable) {
            if (nextProfitable) autoStandaloneEnables++;
            else autoStandaloneDisables++;
            autoStandaloneProfitable = nextProfitable;
        }
    }

    public static Slice get(SectionMesh mesh) {
        return selected.get(mesh);
    }

    static Slice getForDraw(SectionMesh mesh, int sectionSlot) {
        Slice active = selected.get(mesh);
        if (active != null
                || !RESIDENT_COMMANDS
                || !VeilTerrainDrawBridge.inactiveResidentSlot(sectionSlot)) return active;
        Slice retained = residentSelections.get(mesh);
        if (retained != null) {
            residentSelectionReuses++;
            if (VERIFY_RESIDENT_SELECTIONS && verifiedResidentSelections < 100_000) {
                if (!retained.equals(refreshResidentSlice(mesh, retained)))
                    throw new IllegalStateException(
                            "Retained LOD allocation no longer matches GPU");
                if (++verifiedResidentSelections == 100_000)
                    dev.veil.revive.ReviveMod.LOGGER.info(
                            "Veil resident LOD validation PASS: 100000 hidden selections matched live GPU allocations");
            }
        }
        return retained;
    }

    private static Slice refreshResidentSlice(SectionMesh mesh, Slice previous) {
        Entry entry = entries.get(mesh);
        if (entry == null) return null;
        var owner =
                entry.gpuStride == PlanarTerrainLod.GPU_STRIDE
                        ? arena
                        : VeilPackedTerrain.arena(mesh);
        var allocation = owner == null ? null : owner.getAllocation(mesh);
        if (allocation == null) return null;
        GpuBuffer buffer =
                entry.gpuStride == PlanarTerrainLod.GPU_STRIDE
                        ? owner.getGpuBuffer(allocation)
                        : VeilPackedTerrain.buffer(mesh, allocation);
        if (buffer == null || buffer.isClosed()) return null;
        int baseVertex = (int) (allocation.offset() / entry.gpuStride);
        int indexCount = entry.mesh.quads() * 6;
        if (previous.buffer() == buffer
                && previous.baseVertex() == baseVertex
                && previous.indexCount() == indexCount
                && previous.buckets() == entry.buckets) return previous;
        return new Slice(
                buffer,
                baseVertex,
                indexCount,
                entry.buckets,
                previous.faceMask(),
                previous.voxelCells());
    }

    static String residentSelectionTelemetry() {
        return "lod_resident_selections="
                + residentSelections.size()
                + "\nlod_resident_selection_reuses="
                + residentSelectionReuses
                + "\nlod_resident_selection_retirements="
                + residentSelectionRetirements
                + "\nlod_resident_selection_verified="
                + verifiedResidentSelections;
    }

    static void requireResidentSelectionVerification() {
        if (RESIDENT_COMMANDS && VERIFY_RESIDENT_SELECTIONS && verifiedResidentSelections == 0)
            throw new IllegalStateException(
                    "Resident LOD probe never exercised a hidden selection");
    }

    public static boolean hasSelected() {
        return !selected.isEmpty();
    }

    public static boolean autoStandaloneProfitable() {
        return autoStandaloneProfitable;
    }

    public static long revision() {
        return revision;
    }

    public static void recordDraws(int count) {
        if (submittedDraws == 0 && count > 0)
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil exact merged terrain ACTIVE: reduced meshes submitted through Vulkan MDI");
        submittedDraws += count;
    }

    public static void resetSelectionTelemetry() {
        selectionUpdateRuns = 0L;
        selectionFastSkips = 0L;
        selectionRevisionForces = 0L;
        selectionCameraForces = 0L;
        selectionCadenceRefreshes = 0L;
        selectionUpdateNanos = 0L;
        uploadDeadlineDeferrals = 0L;
    }

    public static void close() {
        VeilPackedTerrain.close();
        SELECTED_ENTRIES.clear();
        SELECTED_SLICES.clear();
        selected.clear();
        residentSelections.clear();
        next.clear();
        eligible.clear();
        compactRejectedAtlas.clear();
        entries.clear();
        UPLOAD_CANDIDATES.clear();
        CANDIDATE_POOL.clear();
        residentBytes = 0;
        eligibleSections = selectedQuadsSavedCurrent = selectedProtectedQuadsCurrent = 0;
        selectedBytesSavedCurrent = 0L;
        selectedOriginalBytesCurrent = 0L;
        selectedOptimizedBytesCurrent = 0L;
        selectedMergedInputQuadsCurrent = selectedAffineGradientQuadsCurrent = 0L;
        selectedSubBlockQuadsCurrent = selectedDuplicateQuadsCurrent = 0L;
        directionalQuadsOmittedCurrent = 0;
        voxelCellSectionsCurrent = 0;
        autoStandaloneProfitable = false;
        selectionStampValid = false;
        SELECTION_CADENCE.reset();
        UPLOAD_BUDGET.reset();
        lastVisibilityRevision =
                lastMeshRevision = lastOriginRevision = lastGlobalRevision = Long.MIN_VALUE;
        lastAtlasKey = Long.MIN_VALUE;
        lastConfiguredDistance = Integer.MIN_VALUE;
        revision++;
        if (arena != null) {
            arena.close();
            arena = null;
        }
        if (staging != null) {
            staging.close();
            staging = null;
        }
        if (uploadScratch != null) {
            MemoryUtil.memFree(uploadScratch);
            uploadScratch = null;
        }
    }

    public static String telemetry() {
        return VeilLodBuildCache.telemetry()
                + VeilPackedTerrain.telemetry()
                + (arena == null
                        ? ""
                        : arena.telemetry().replace("arena_defrag_", "lod_arena_defrag_"))
                + "lod_candidate_reuses_total="
                + candidateReuses
                + "\nlod_slice_reuses_total="
                + sliceReuses
                + "\nlod_selected_sections="
                + selected.size()
                + "\nlod_eligible_sections="
                + eligibleSections
                + "\nlod_upload_credit_bytes="
                + UPLOAD_BUDGET.availableBytes()
                + "\nlod_upload_deadline_deferrals_total="
                + uploadDeadlineDeferrals
                + "\nlod_resident_bytes="
                + residentBytes
                + "\nlod_uploaded_bytes_total="
                + uploadedBytes
                + "\nlod_quads_saved_current="
                + selectedQuadsSavedCurrent
                + "\nlod_bytes_saved_current="
                + selectedBytesSavedCurrent
                + "\nlod_original_bytes_current="
                + selectedOriginalBytesCurrent
                + "\nlod_optimized_bytes_current="
                + selectedOptimizedBytesCurrent
                + "\nlod_byte_reduction_current="
                + String.format(
                        java.util.Locale.ROOT,
                        "%.4f",
                        selectedOriginalBytesCurrent == 0L
                                ? 0.0
                                : (double) selectedBytesSavedCurrent
                                        / (double) selectedOriginalBytesCurrent)
                + "\nlod_protected_quads_current="
                + selectedProtectedQuadsCurrent
                + "\nlod_merged_input_quads_current="
                + selectedMergedInputQuadsCurrent
                + "\nlod_affine_gradient_quads_current="
                + selectedAffineGradientQuadsCurrent
                + "\nlod_sub_block_quads_current="
                + selectedSubBlockQuadsCurrent
                + "\nlod_duplicate_quads_removed_current="
                + selectedDuplicateQuadsCurrent
                + "\nlod_quads_saved_total="
                + selectedQuadsSaved
                + "\nlod_submitted_draws_total="
                + submittedDraws
                + "\nlod_directional_quads_omitted_current="
                + directionalQuadsOmittedCurrent
                + "\nlod_voxel_cell_sections_current="
                + voxelCellSectionsCurrent
                + "\nlod_directional_quads_omitted_in_selections_total="
                + directionalQuadsOmitted
                + "\nlod_upload_scratch_bytes="
                + (uploadScratch == null ? 0 : uploadScratch.capacity())
                + "\nlod_selection_update_runs_total="
                + selectionUpdateRuns
                + "\nlod_selection_fast_skips_total="
                + selectionFastSkips
                + "\nlod_selection_revision_forces_total="
                + selectionRevisionForces
                + "\nlod_selection_camera_forces_total="
                + selectionCameraForces
                + "\nlod_selection_cadence_refreshes_total="
                + selectionCadenceRefreshes
                + "\nlod_selection_update_ms_total="
                + String.format(java.util.Locale.ROOT, "%.4f", selectionUpdateNanos / 1_000_000.0)
                + "\nlod_selection_update_avg_ms="
                + String.format(
                        java.util.Locale.ROOT,
                        "%.5f",
                        selectionUpdateRuns == 0L
                                ? 0.0
                                : (selectionUpdateNanos / 1_000_000.0) / selectionUpdateRuns)
                + "\nlod_auto_standalone_profitable="
                + autoStandaloneProfitable
                + "\nlod_auto_standalone_evaluations_total="
                + autoStandaloneEvaluations
                + "\nlod_auto_standalone_accepted_total="
                + autoStandaloneAccepted
                + "\nlod_auto_standalone_rejected_total="
                + autoStandaloneRejected
                + "\nlod_auto_standalone_enables_total="
                + autoStandaloneEnables
                + "\nlod_auto_standalone_disables_total="
                + autoStandaloneDisables
                + "\nlod_auto_standalone_threshold_on_sections="
                + AutoLodProfitabilityPolicy.ENABLE_MIN_SECTIONS
                + "\nlod_auto_standalone_threshold_on_saved_bytes="
                + AutoLodProfitabilityPolicy.ENABLE_MIN_SAVED_BYTES
                + "\nlod_auto_standalone_threshold_on_reduction="
                + String.format(
                        java.util.Locale.ROOT,
                        "%.4f",
                        AutoLodProfitabilityPolicy.ENABLE_MIN_REDUCTION)
                + "\n";
    }
}
