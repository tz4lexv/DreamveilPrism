package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.CompactVectorArray;
import com.mojang.blaze3d.vertex.VertexSorting;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import org.joml.Vector3f;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;

public final class VeilTransparencyOrder {
    private static final boolean REQUESTED = Boolean.getBoolean("veil.transparencyTriggers");
    private final int[] order;
    private VeilTransparencyRegion region;
    private CompactVectorArray regionPoints;
    private static final boolean SPATIAL = Boolean.getBoolean("veil.transparencySpatialTriggers");
    private static final AtomicLong PREQUEUE = new AtomicLong();
    private static final AtomicLong REGION_BUILDS = new AtomicLong(),
            REGION_BUILD_NS = new AtomicLong();

    public record Counters(long skipped, long avoidedTasks, long regionBuilds, long regionBuildNs) {
        public Counters minus(Counters start) {
            return new Counters(
                    skipped - start.skipped,
                    avoidedTasks - start.avoidedTasks,
                    regionBuilds - start.regionBuilds,
                    regionBuildNs - start.regionBuildNs);
        }
    }

    public static Counters counters() {
        return new Counters(
                SKIPPED.get(), PREQUEUE.get(), REGION_BUILDS.get(), REGION_BUILD_NS.get());
    }

    public static boolean spatialRequested() {
        return REQUESTED && SPATIAL;
    }

    public static VeilTransparencyOrder committed(
            int[] order, CompactVectorArray points, float x, float y, float z) {
        var result = new VeilTransparencyOrder(order);
        if (spatialRequested()) {
            long started = System.nanoTime();
            result.region = VeilTransparencyRegion.create(points, result.order, x, y, z);
            result.regionPoints = points;
            REGION_BUILD_NS.addAndGet(System.nanoTime() - started);
            REGION_BUILDS.incrementAndGet();
        }
        return result;
    }

    public boolean insideRegion(CompactVectorArray points, float x, float y, float z) {
        return points == regionPoints && region != null && region.contains(x, y, z);
    }

    public void recordPrequeue(CompactVectorArray points, float x, float y, float z) {
        recordSkip(
                points,
                Boolean.getBoolean("veil.verifyTransparencyTriggers")
                        ? VertexSorting.byDistance(x, y, z)
                        : null);
        PREQUEUE.incrementAndGet();
    }

    private static final AtomicLong VERIFIED = new AtomicLong(), SKIPPED = new AtomicLong();
    private static final AtomicLong FALLBACK_TASKS = new AtomicLong();

    public static void recordFallbackTask() {
        FALLBACK_TASKS.incrementAndGet();
    }

    public void recordSkip(CompactVectorArray centroids, VertexSorting sorting) {
        if (Boolean.getBoolean("veil.verifyTransparencyTriggers")
                && VeilPlatform.get().isDevelopmentEnvironment()) {
            if (!Arrays.equals(order, sorting.sort(centroids)))
                throw new IllegalStateException("Transparency trigger changed native index order");
            VERIFIED.addAndGet(centroids.size());
        }
        long skipped = SKIPPED.incrementAndGet();
        if (skipped == 1 || skipped == 1000)
            ReviveMod.LOGGER.info(
                    "Veil transparency trigger: skipped {} unchanged native index sorts/uploads",
                    skipped);
    }

    static void requireComplete() {
        ReviveMod.LOGGER.info(
                "Veil transparency spatial metrics: requested={} avoided_tasks={}",
                spatialRequested(),
                PREQUEUE.get());
        ReviveMod.LOGGER.info(
                "Veil transparency metrics: requested={} skipped_sorts={} native_quads={} fallback_tasks={}",
                REQUESTED,
                SKIPPED.get(),
                VERIFIED.get(),
                FALLBACK_TASKS.get());
        if (!Boolean.getBoolean("veil.verifyTransparencyTriggers")) return;
        if (spatialRequested() && PREQUEUE.get() == 0)
            throw new IllegalStateException("Spatial transparency trigger never avoided a task");
        if (SKIPPED.get() == 0 || VERIFIED.get() < 100000)
            throw new IllegalStateException(
                    "Transparency trigger verification incomplete: sorts="
                            + SKIPPED.get()
                            + " quads="
                            + VERIFIED.get());
        if (Boolean.getBoolean("veil.transparencyTransitionProbe") && FALLBACK_TASKS.get() == 0)
            throw new IllegalStateException(
                    "Transparency transition did not exercise native fallback tasks");
        ReviveMod.LOGGER.info(
                "Veil transparency triggers: PASS (skipped_sorts={} native_quads={} fallback_tasks={})",
                SKIPPED.get(),
                VERIFIED.get(),
                FALLBACK_TASKS.get());
    }

    public static boolean enabled() {
        return REQUESTED
                && ReviveRuntime.optimizationsEnabled()
                && VeilSectionChanges.notificationsSupported();
    }

    public static boolean requested() {
        return REQUESTED;
    }

    public VeilTransparencyOrder(int[] order) {
        this.order = order.clone();
    }

    public boolean unchanged(CompactVectorArray centroids, float x, float y, float z) {
        if (centroids.size() != order.length || order.length == 0) return false;
        Vector3f camera = new Vector3f(x, y, z), point = new Vector3f();
        float previous = Float.POSITIVE_INFINITY;
        int previousIndex = -1;
        for (int index : order) {
            if (index < 0 || index >= centroids.size()) return false;
            float distance = camera.distanceSquared(centroids.get(index, point));
            if (!Float.isFinite(distance)) return false;
            int comparison = Float.compare(previous, distance);
            if (comparison < 0 || (comparison == 0 && previousIndex > index)) return false;
            previous = distance;
            previousIndex = index;
        }
        return true;
    }
}
