package dev.veil.revive.client.terrain.capture;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.buffers.GpuBuffer;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.jspecify.annotations.Nullable;

public record PacketSignature(
        SectionMesh mesh,
        ChunkSectionLayer layer,
        GpuBuffer vertexBuffer,
        long vertexOffset,
        @Nullable GpuBuffer indexBuffer,
        long indexOffset,
        @Nullable IndexType indexType,
        int indexCount,
        boolean customIndex,
        int uboIndex) {

    public static PacketSignature of(
            SectionMesh mesh,
            ChunkSectionLayer layer,
            SectionMesh.SectionDraw draw,
            SectionRenderDispatcher.RenderSectionBufferSlice slice,
            int uboIndex) {
        return new PacketSignature(
                mesh,
                layer,
                slice.vertexBuffer(),
                slice.vertexBufferOffset(),
                slice.indexBuffer(),
                slice.indexBufferOffset(),
                draw.indexType(),
                draw.indexCount(),
                draw.hasCustomIndexBuffer(),
                uboIndex);
    }

    public boolean matches(
            SectionMesh currentMesh,
            ChunkSectionLayer currentLayer,
            SectionMesh.SectionDraw currentDraw,
            SectionRenderDispatcher.RenderSectionBufferSlice currentSlice,
            int currentUboIndex) {
        return mesh == currentMesh
                && layer == currentLayer
                && vertexBuffer == currentSlice.vertexBuffer()
                && vertexOffset == currentSlice.vertexBufferOffset()
                && indexBuffer == currentSlice.indexBuffer()
                && indexOffset == currentSlice.indexBufferOffset()
                && indexType == currentDraw.indexType()
                && indexCount == currentDraw.indexCount()
                && customIndex == currentDraw.hasCustomIndexBuffer()
                && uboIndex == currentUboIndex;
    }
}
