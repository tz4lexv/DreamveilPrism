package dev.veil.revive.client;

import jdk.jfr.Category;
import jdk.jfr.Event;
import jdk.jfr.EventType;
import jdk.jfr.Label;
import jdk.jfr.Name;
import jdk.jfr.StackTrace;

import java.util.concurrent.atomic.AtomicLong;

public final class VeilPublicationLockJfrProbe {
    private static final boolean ENABLED = Boolean.getBoolean("veil.publicationLockJfrEvents");
    private static final long THRESHOLD_NS =
            Math.max(1L, Long.getLong("veil.publicationLockJfrThresholdNanos", 1_000_000L));
    private static final EventType TYPE = ENABLED ? EventType.getEventType(LockTiming.class) : null;
    private static final AtomicLong IDS = new AtomicLong();
    private final long id = IDS.incrementAndGet();
    private final ThreadLocal<State> states = ThreadLocal.withInitial(State::new);

    public long id() {
        return id;
    }

    public void beforeLock() {
        if (!ENABLED) return;
        State state = states.get();
        if (state.depth != 0) return;
        state.pending = TYPE.isEnabled();
        state.releaseObserved = false;
        if (state.pending) state.requestNanos = System.nanoTime();
    }

    public void afterLock() {
        if (!ENABLED) return;
        State state = states.get();
        if (state.depth != 0) {
            state.depth++;
            state.acquisitions++;
        } else {
            state.tracking = state.pending;
            if (state.tracking) state.acquiredNanos = System.nanoTime();
            state.pending = false;
            state.depth = 1;
            state.acquisitions = 1;
        }
    }

    public void beforeUnlock() {
        if (!ENABLED) return;
        State state = states.get();
        if (state.depth == 1 && state.tracking) {
            state.releaseBeforeNanos = System.nanoTime();
            state.releaseObserved = true;
        }
    }

    public void afterUnlock() {
        if (!ENABLED) return;
        State state = states.get();
        if (state.depth == 0 || --state.depth != 0) return;
        long releasedNanos = System.nanoTime();
        long requested = state.requestNanos;
        long acquired = state.acquiredNanos;
        long releasing = state.releaseBeforeNanos;
        int acquisitions = state.acquisitions;
        boolean observed = state.tracking && state.releaseObserved;
        state.pending = false;
        state.tracking = false;
        state.releaseObserved = false;
        state.acquisitions = 0;
        long wait = acquired - requested;
        long inside = releasing - acquired;
        if (!observed
                || wait < 0
                || inside < 0
                || releasedNanos - releasing < 0
                || (wait < THRESHOLD_NS && inside < THRESHOLD_NS)
                || !TYPE.isEnabled()) return;
        LockTiming event = new LockTiming();
        event.dispatcherId = id;
        event.requestNanos = requested;
        event.acquiredNanos = acquired;
        event.releaseBeforeNanos = releasing;
        event.releasedNanos = releasedNanos;
        event.acquisitions = acquisitions;
        event.thresholdNanos = THRESHOLD_NS;
        event.commit();
    }

    private static final class State {
        int depth, acquisitions;
        boolean pending, tracking, releaseObserved;
        long requestNanos, acquiredNanos, releaseBeforeNanos;
    }

    @Name("dev.veil.PublicationLockTiming")
    @Label("Veil publication lock timing")
    @Category({"Veil", "Diagnostics"})
    @StackTrace(false)
    static final class LockTiming extends Event {
        public long dispatcherId;
        public long requestNanos;
        public long acquiredNanos;
        public long releaseBeforeNanos;
        public long releasedNanos;
        public int acquisitions;
        public long thresholdNanos;
    }
}
