package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFaceVisibilityCache;

import net.minecraft.client.renderer.block.ModelBlockRenderer;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ModelBlockRenderer.class)
public abstract class BlockFaceVisibilityMixin {
    @org.spongepowered.asm.mixin.Shadow private boolean cull;

    @org.spongepowered.asm.mixin.injection.Inject(
            method =
                    "shouldRenderFace(Lnet/minecraft/client/renderer/block/BlockAndTintGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/core/BlockPos;)Z",
            at = @At("RETURN"),
            cancellable = true,
            require = 1)
    private void veil$skipDeepLeafFace(
            net.minecraft.client.renderer.block.BlockAndTintGetter level,
            BlockState state,
            Direction direction,
            net.minecraft.core.BlockPos neighbor,
            org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable<Boolean> ci) {
        if (cull
                && ci.getReturnValueZ()
                && dev.veil.revive.client.VeilLeafCulling.hidesFace(
                        level, state, direction, neighbor)) ci.setReturnValue(false);
    }

    @Redirect(
            method =
                    "shouldRenderFace(Lnet/minecraft/client/renderer/block/BlockAndTintGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/core/BlockPos;)Z",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/world/level/block/Block;shouldRenderFace(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z"),
            require = 1)
    private static boolean veil$cachedFace(
            BlockState state, BlockState neighborState, Direction direction) {
        return VeilFaceVisibilityCache.shouldRenderFace(state, neighborState, direction);
    }
}
