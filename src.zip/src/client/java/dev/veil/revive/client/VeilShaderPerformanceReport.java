package dev.veil.revive.client;

import java.util.List;
import java.util.function.Function;
import java.util.function.IntFunction;

final class VeilShaderPerformanceReport {
    interface PassInfo {
        VeilShaderPack.Pass definition();

        VeilShaderProgram program();

        VeilShaderInterface layoutInterface();
    }

    record TargetSize(int width, int height) {}

    record State(
            VeilShaderPack pack,
            String limitsReport,
            List<? extends PassInfo> passes,
            int[][] dispatch,
            IntFunction<String> profile,
            Function<String, TargetSize> target,
            int width,
            int height,
            boolean presenter,
            long rayAllocatedBytes,
            List<String> hostTelemetry) {}

    private VeilShaderPerformanceReport() {}

    static String build(State state) {
        var pack = state.pack();
        var passes = state.passes();
        StringBuilder out =
                new StringBuilder("Veil native shader report: ")
                        .append(pack.name())
                        .append('\n')
                        .append(state.limitsReport())
                        .append('\n');
        for (int index = 0; index < passes.size(); index++) {
            var pass = passes.get(index);
            if (pass.definition().transfer()) {
                out.append("PASS ")
                        .append(pass.definition().name())
                        .append(" type=transfer operations=")
                        .append(pass.definition().transfers().size())
                        .append('\n')
                        .append(state.profile().apply(index))
                        .append('\n');
                continue;
            }
            if (pass.definition().scenePass()) {
                var target = state.target().apply(pass.definition().target());
                out.append("PASS ")
                        .append(pass.definition().name())
                        .append(" type=scene target=")
                        .append(target.width())
                        .append('x')
                        .append(target.height())
                        .append(" categories=")
                        .append(pass.definition().scene().categories())
                        .append('\n')
                        .append(state.profile().apply(index))
                        .append('\n');
                continue;
            }
            out.append("PASS ")
                    .append(pass.definition().name())
                    .append(" program=")
                    .append(pass.program().id())
                    .append(" variant=")
                    .append(pass.definition().specialization())
                    .append("\n")
                    .append(state.profile().apply(index))
                    .append('\n');
            for (var binary : pass.program().stages().values())
                out.append(binary.stage())
                        .append(" entry=")
                        .append(binary.entryPoint())
                        .append(" hash=")
                        .append(binary.contentHash())
                        .append("\n")
                        .append(VeilSpirvAnalysis.inspect(binary).report())
                        .append('\n');
            out.append("descriptors=")
                    .append(pass.layoutInterface().descriptors().size())
                    .append(" push_blocks=")
                    .append(pass.layoutInterface().pushConstants().size())
                    .append(" specialization_constants=")
                    .append(pass.layoutInterface().specializationConstants().size())
                    .append('\n');
            if (pass.definition().compute()) {
                int[] local =
                        VeilShaderBaseline.fixedLocalSize(
                                pass.program().stage(VeilShaderStage.COMPUTE));
                if (pass.definition().dispatch().indirect()) {
                    out.append("dispatch=INDIRECT buffer=")
                            .append(pass.definition().dispatch().indirectResource())
                            .append(" offset=")
                            .append(pass.definition().dispatch().indirectOffset())
                            .append(" local=")
                            .append(java.util.Arrays.toString(local))
                            .append(" launched_invocations_calculated=GPU_PROVIDED\n");
                } else {
                    int[] groups = state.dispatch()[index];
                    var invocations = java.math.BigInteger.ONE;
                    for (int axis = 0; axis < 3; axis++)
                        invocations =
                                invocations.multiply(
                                        java.math.BigInteger.valueOf(
                                                (long) groups[axis] * local[axis]));
                    out.append("dispatch=")
                            .append(java.util.Arrays.toString(groups))
                            .append(" local=")
                            .append(java.util.Arrays.toString(local))
                            .append(" launched_invocations_calculated=")
                            .append(invocations)
                            .append('\n');
                }
            } else if (pass.definition().raytrace()) {
                int[] dimensions = state.dispatch()[index];
                out.append("trace=")
                        .append(java.util.Arrays.toString(dimensions))
                        .append(" max_recursion_depth=")
                        .append(pass.definition().maxRecursionDepth())
                        .append('\n');
            } else {
                var target = state.target().apply(pass.definition().target());
                out.append("target=")
                        .append(target.width())
                        .append('x')
                        .append(target.height())
                        .append(" geometry=")
                        .append(pass.definition().geometry())
                        .append(" fragment_invocations=see_GPU_query_counters\n");
            }
        }
        if (state.presenter())
            out.append("PASS @present\n").append(state.profile().apply(passes.size())).append('\n');
        long total = 0;
        for (var resource : pack.resources().values()) {
            if (resource.source() != VeilShaderPack.Source.OWNED) {
                out.append("RESOURCE ")
                        .append(resource.name())
                        .append(" borrowed=")
                        .append(resource.source())
                        .append('\n');
                continue;
            }
            long bytes =
                    resource.kind() == VeilRenderGraph.Kind.BUFFER
                            ? resource.bytes()
                            : resource.resolvedBytes(
                                    state.width(), state.height(), pack.resources());
            long allocation = bytes * resource.historyCount();
            total += allocation;
            out.append("RESOURCE ")
                    .append(resource.name())
                    .append(" format=")
                    .append(resource.format())
                    .append(" bytes_each=")
                    .append(bytes)
                    .append(" lifetime=")
                    .append(resource.lifetime())
                    .append(" history=")
                    .append(resource.history())
                    .append(" logical_bytes_total=")
                    .append(allocation)
                    .append('\n');
        }
        out.append("ray_acceleration_allocated_bytes=")
                .append(state.rayAllocatedBytes())
                .append(
                        "; includes BLAS/TLAS, build scratch, vertices and instances; build_gpu_ms=UNAVAILABLE\n");
        for (String telemetry : state.hostTelemetry()) out.append(telemetry).append('\n');
        return out.append("logical_owned_bytes=")
                .append(total)
                .append(
                        "; excludes driver padding/compression and ray allocations reported separately; bandwidth=UNAVAILABLE\n")
                .append(
                        "register_pressure=UNAVAILABLE spills=UNAVAILABLE occupancy=UNAVAILABLE divergence=UNAVAILABLE cache_behavior=UNAVAILABLE\n")
                .append(
                        "overdraw=UNAVAILABLE helper_invocations=UNAVAILABLE early_z=UNAVAILABLE atomic_contention=UNAVAILABLE bank_conflicts=UNAVAILABLE\n")
                .append(
                        "GPU pass intervals include resource barriers and commands; they are not isolated shader ISA timings.\n")
                .toString();
    }
}
