package dev.veil.revive.client;

import dev.veil.revive.core.Aabb;
import dev.veil.revive.core.OpaqueWallOcclusion;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.IdentityHashMap;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

public final class VeilAsyncEntityOcclusion {
    private static final AtomicLong REVISION = new AtomicLong();
    private static final IdentityHashMap<Object, Entry> ENTRIES = new IdentityHashMap<>();
    private static final ThreadPoolExecutor WORKER =
            new ThreadPoolExecutor(
                    1,
                    1,
                    0,
                    TimeUnit.MILLISECONDS,
                    new ArrayBlockingQueue<>(8),
                    task -> {
                        Thread thread = new Thread(task, "Veil entity occlusion");
                        thread.setDaemon(true);
                        return thread;
                    });
    private static ClientLevel world;
    private static int captures;
    private static long captureNanos;
    private static long observedRevision;
    private static long submitted, rejected, expired;

    private VeilAsyncEntityOcclusion() {}

    public static void beginExtraction() {
        Minecraft client = Minecraft.getInstance();
        long revision = REVISION.get();
        if (world != client.level || revision != observedRevision || ENTRIES.size() > 2048) {
            ENTRIES.values()
                    .forEach(
                            entry -> {
                                if (entry.pending != null) entry.pending.cancel(false);
                            });
            ENTRIES.clear();
            WORKER.purge();
            world = client.level;
            observedRevision = revision;
        }
        captures = 0;
        captureNanos = 0;
    }

    public static void invalidate() {
        REVISION.incrementAndGet();
    }

    public static boolean isOccluded(Object identity, AABB bounds) {
        Minecraft client = Minecraft.getInstance();
        if (!ReviveRuntime.optimizationsEnabled()
                || !VeilVideoConfig.on("renderer.entityCulling")
                || !VeilVideoConfig.on("renderer.asyncEntityOcclusion")
                || world == null
                || world != client.level
                || client.gameRenderer.mainCamera() == null
                || VeilShaderPackBridge.shaderPackActive()
                || VeilShaderPackBridge.renderingShadowPass()
                || REVISION.get() != observedRevision) return false;
        Entry entry = ENTRIES.get(identity);
        if (entry == null && (captures >= 2 || captureNanos >= 500_000L)) return false;
        Vec3 position = client.gameRenderer.mainCamera().position();
        Aabb camera =
                new Aabb(position.x, position.y, position.z, position.x, position.y, position.z);
        Aabb target =
                new Aabb(
                        bounds.minX,
                        bounds.minY,
                        bounds.minZ,
                        bounds.maxX,
                        bounds.maxY,
                        bounds.maxZ);
        long now = System.nanoTime();
        double distance = target.distanceTo(position.x, position.y, position.z);
        if (distance < 2
                || distance > 64
                || target.sizeX() > 8
                || target.sizeY() > 8
                || target.sizeZ() > 8) return false;
        if (entry != null && entry.pending != null && entry.pending.isDone()) {
            try {
                entry.hidden = entry.pending.get();
            } catch (InterruptedException failure) {
                Thread.currentThread().interrupt();
                entry.hidden = false;
            } catch (ExecutionException | CancellationException failure) {
                entry.hidden = false;
            }
            entry.pending = null;
        }
        boolean valid =
                entry != null
                        && now - entry.created < 250_000_000L
                        && OpaqueWallOcclusion.contains(entry.camera, camera)
                        && OpaqueWallOcclusion.contains(entry.target, target);
        if (valid && entry.hidden) {
            rejected++;
            return true;
        }
        if (entry != null && !valid) {
            entry.hidden = false;
            expired++;
        }
        if (captures >= 2
                || captureNanos >= 500_000L
                || (entry != null && (entry.pending != null || now - entry.created < 100_000_000L))
                || WORKER.getQueue().remainingCapacity() == 0) return false;
        captures++;
        Aabb cameraRegion = camera.inflate(0.25), targetRegion = target.inflate(0.25);
        long captureStart = System.nanoTime();
        OpaqueWallOcclusion.Wall wall =
                captureWall(position, target, captureStart + 500_000L - captureNanos);
        captureNanos += System.nanoTime() - captureStart;
        Entry next = new Entry(cameraRegion, targetRegion, now);
        ENTRIES.put(identity, next);
        if (wall != null) {
            next.pending =
                    WORKER.submit(
                            () -> OpaqueWallOcclusion.hides(cameraRegion, targetRegion, wall));
            submitted++;
        }
        return false;
    }

    private static OpaqueWallOcclusion.Wall captureWall(Vec3 camera, Aabb target, long deadline) {
        double dx = target.centerX() - camera.x,
                dy = target.centerY() - camera.y,
                dz = target.centerZ() - camera.z;
        double length = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int axis =
                Math.abs(dx) >= Math.abs(dy) && Math.abs(dx) >= Math.abs(dz)
                        ? 0
                        : Math.abs(dy) >= Math.abs(dz) ? 1 : 2;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (double distance = 1; distance < Math.min(length - 1, 32); distance += 0.75) {
            if (System.nanoTime() > deadline) return null;
            pos.set(
                    (int) Math.floor(camera.x + dx * distance / length),
                    (int) Math.floor(camera.y + dy * distance / length),
                    (int) Math.floor(camera.z + dz * distance / length));
            if (!opaque(pos)) continue;
            int[] coordinates = {pos.getX(), pos.getY(), pos.getZ()};
            int u = (axis + 1) % 3, v = (axis + 2) % 3;
            int minU = coordinates[u] - 3, minV = coordinates[v] - 3;
            long mask = 0;
            for (int y = 0; y < OpaqueWallOcclusion.WIDTH; y++)
                for (int x = 0; x < OpaqueWallOcclusion.WIDTH; x++) {
                    if (System.nanoTime() > deadline) return null;
                    coordinates[u] = minU + x;
                    coordinates[v] = minV + y;
                    pos.set(coordinates[0], coordinates[1], coordinates[2]);
                    if (opaque(pos)) mask |= 1L << (y * OpaqueWallOcclusion.WIDTH + x);
                }
            return new OpaqueWallOcclusion.Wall(axis, coordinates[axis] + 0.5, minU, minV, mask);
        }
        return null;
    }

    private static boolean opaque(BlockPos pos) {
        if (!world.hasChunkAt(pos)) return false;
        var state = world.getBlockState(pos);
        return state.canOcclude() && state.isSolidRender();
    }

    public static String telemetry() {
        return "entity_occlusion_jobs_total="
                + submitted
                + "\nentity_occlusion_rejects_total="
                + rejected
                + "\nentity_occlusion_expired_total="
                + expired
                + "\nentity_occlusion_cached="
                + ENTRIES.size();
    }

    public static void close() {
        ENTRIES.clear();
        world = null;
        WORKER.shutdownNow();
    }

    private static final class Entry {
        final Aabb camera, target;
        final long created;
        Future<Boolean> pending;
        boolean hidden;

        Entry(Aabb camera, Aabb target, long created) {
            this.camera = camera;
            this.target = target;
            this.created = created;
        }
    }
}
