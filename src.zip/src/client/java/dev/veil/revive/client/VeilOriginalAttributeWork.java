package dev.veil.revive.client;

import dev.veil.revive.core.LightOnlyUpdateTracker;

import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import java.util.ArrayDeque;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BooleanSupplier;

public final class VeilOriginalAttributeWork {
    static final boolean VERIFY =
            Boolean.getBoolean("veil.verifyPreviousAttributeReplay")
                    && VeilOriginalQuadCapture.REQUESTED
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    static final boolean REUSE =
            Boolean.getBoolean("veil.reuseOriginalModels") && VeilOriginalQuadCapture.REQUESTED;
    static final boolean VERIFY_REUSE =
            REUSE
                    && Boolean.getBoolean("veil.verifyOriginalModelReuse")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final java.util.concurrent.atomic.AtomicBoolean INJECT_RETRY =
            new java.util.concurrent.atomic.AtomicBoolean();
    private static final ConcurrentHashMap<Long, Source> SOURCES = new ConcurrentHashMap<>();
    private static final ThreadLocal<ArrayDeque<Scope>> WORK = new ThreadLocal<>();

    private static long probeStarted, lastProbe;
    private static int forcedNotifications;
    private static boolean fixtureRefreshed;
    private static boolean fixtureReported;
    private static final java.util.concurrent.atomic.LongAdder
            REUSED_EMPTY = new java.util.concurrent.atomic.LongAdder(),
            REUSED_SPRITES = new java.util.concurrent.atomic.LongAdder();

    static void requireProvenance() {
        if (!VERIFY_REUSE || !Boolean.getBoolean("veil.verifyModelProvenance")) return;
        if (REUSED_EMPTY.sum() == 0 || REUSED_SPRITES.sum() == 0)
            throw new IllegalStateException(
                    "Empty/animated model reuse not exercised: empty="
                            + REUSED_EMPTY.sum()
                            + " sprites="
                            + REUSED_SPRITES.sum()
                            + " notifications="
                            + forcedNotifications
                            + " sources="
                            + SOURCES.size());
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil model provenance: PASS (empty_reused={} sprite_refs_reused={} retained_models={} retained_sprites={})",
                REUSED_EMPTY.sum(),
                REUSED_SPRITES.sum(),
                VeilOriginalQuadCapture.retainedModels(),
                VeilOriginalQuadCapture.retainedSprites());
    }

    private VeilOriginalAttributeWork() {}

    static int forcedNotifications() {
        return forcedNotifications;
    }

    static void tick(
            net.minecraft.client.Minecraft client,
            java.util.List<SectionRenderDispatcher.RenderSection> visible) {
        if (!VERIFY || forcedNotifications >= 16 || client.level == null) return;
        var server = client.getSingleplayerServer();
        if (server == null
                || !server.getWorldData().getLevelName().startsWith("Veil-Benchmark-26.2-"))
            throw new IllegalStateException("Previous attribute probe requires dedicated world");
        long now = System.nanoTime();
        VeilChangedLightGpuProbe.request(client, forcedNotifications);
        if (probeStarted == 0) probeStarted = now;
        if (now - probeStarted < 35_000_000_000L || now - lastProbe < 2_000_000_000L) return;
        for (var section : visible) {
            long node = section.getSectionNode();
            var source = SOURCES.get(node);
            if (Boolean.getBoolean("veil.verifyModelProvenance")
                    && fixtureRefreshed
                    && !fixtureReported
                    && node == VeilBenchmarkWorld.provenanceSection) {
                fixtureReported = true;
                int quads = -1, models = -1, sprites = -1;
                if (source != null)
                    try (var input = source.snapshot.acquire(node)) {
                        if (input != null) {
                            quads = input.quads().size();
                            models = input.models().size();
                            sprites =
                                    input.models().stream().mapToInt(m -> m.sprites().size()).sum();
                        }
                    }
                var mesh = section.getSectionMesh();
                int meshSprites =
                        mesh instanceof VeilMeshExtras extras && extras.veil$metadata() != null
                                ? extras.veil$metadata().animatedSprites().length
                                : -1;
                var texture =
                        client.getAtlasManager()
                                .get(
                                        new net.minecraft.client.resources.model.sprite.SpriteId(
                                                net.minecraft.client.renderer.texture.TextureAtlas
                                                        .LOCATION_BLOCKS,
                                                net.minecraft.resources.Identifier
                                                        .withDefaultNamespace("block/prismarine")));
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil model provenance checkpoint: source={} quads={} models={} sprites={} mesh_sprites={} texture_animated={} retained_quads={} retained_models={} retained_sprites={}",
                        source != null,
                        quads,
                        models,
                        sprites,
                        meshSprites,
                        texture.contents().isAnimated(),
                        VeilOriginalQuadCapture.retained(),
                        VeilOriginalQuadCapture.retainedModels(),
                        VeilOriginalQuadCapture.retainedSprites());
            }
            if (Boolean.getBoolean("veil.verifyModelProvenance")
                    && !fixtureRefreshed
                    && node == VeilBenchmarkWorld.provenanceSection) {
                var at = net.minecraft.core.SectionPos.of(node);
                client.levelExtractor.setSectionDirty(at.getX(), at.getY(), at.getZ());
                fixtureRefreshed = true;
                lastProbe = now;
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil model provenance fixture: installed capture refresh requested");
                return;
            }
            if (source == null || !source.current.getAsBoolean() || !source.snapshot.current(node))
                continue;
            if (Boolean.getBoolean("veil.verifyModelProvenance")) {
                try (var input = source.snapshot.acquire(node)) {
                    if (input == null
                            || input.models().stream().noneMatch(m -> !m.sprites().isEmpty()))
                        continue;
                }
            }
            client.level
                    .getChunkSource()
                    .onLightUpdate(
                            net.minecraft.world.level.LightLayer.BLOCK,
                            net.minecraft.core.SectionPos.of(node));
            forcedNotifications++;
            lastProbe = now;
            return;
        }
    }

    public static void installed(SectionRenderDispatcher.RenderSection section, SectionMesh mesh) {
        if (!VERIFY && !REUSE) return;
        long node = section.getSectionNode();
        SOURCES.remove(node);
        if (!(mesh instanceof VeilMeshExtras extras) || extras.veil$metadata() == null) return;
        var snapshot = extras.veil$metadata().originalAttributeSnapshot();
        if (snapshot == null || snapshot.section() != node) return;
        install(
                node,
                mesh,
                () ->
                        section.getSectionNode() == node
                                && section.getSectionMesh() == mesh
                                && !extras.veil$metadata().closed(),
                snapshot);
    }

    static void install(
            long node,
            Object owner,
            BooleanSupplier current,
            VeilOriginalQuadCapture.Snapshot snapshot) {
        if (!snapshot.modelsOnly() || !snapshot.current(node)) return;
        SOURCES.put(node, new Source(owner, current, snapshot));
    }

    public static void retired(long node, Object owner) {
        SOURCES.computeIfPresent(node, (key, source) -> source.owner == owner ? null : source);
    }

    public static void invalidate() {
        SOURCES.clear();
    }

    static Scope open(long node, LightOnlyUpdateTracker.Update requested) {
        return open(node, requested, VERIFY || REUSE);
    }

    static Scope open(long node, LightOnlyUpdateTracker.Update requested, boolean enabled) {
        if (!enabled && WORK.get() == null) return Scope.NONE;
        var source =
                enabled && requested == LightOnlyUpdateTracker.Update.ATTRIBUTES_ONLY
                        ? SOURCES.get(node)
                        : null;
        VeilOriginalQuadCapture.Lease lease = null;
        if (source != null && source.current.getAsBoolean()) lease = source.snapshot.acquire(node);
        Scope scope;
        try {
            scope = new Scope(node, source, lease);
            if (!scope.current()) scope.release();
        } catch (RuntimeException | Error failure) {
            if (lease != null) lease.close();
            throw failure;
        }
        var stack = WORK.get();
        if (stack == null) {
            stack = new ArrayDeque<>();
            WORK.set(stack);
        }
        stack.push(scope);
        return scope;
    }

    static Scope current() {
        var stack = WORK.get();
        return stack == null || stack.isEmpty() ? null : stack.peek();
    }

    private record Source(
            Object owner, BooleanSupplier current, VeilOriginalQuadCapture.Snapshot snapshot) {}

    static final class Unstable extends RuntimeException {
        Unstable() {
            super(null, null, false, false);
        }
    }

    static final class Scope implements AutoCloseable {
        private static final Scope NONE = new Scope(0, null, null);

        static {
            NONE.thread = null;
        }

        private final long node;
        private final Source source;
        private VeilOriginalQuadCapture.Lease lease;
        private Thread thread = Thread.currentThread();
        private PreparedOriginalModels prepared;
        private java.util.function.Function<VeilOriginalQuadCapture.Quad, VeilModelGeometryStamp>
                sample;
        private int reused;

        int reused() {
            return reused;
        }

        void prepare(
                java.util.function.Function<VeilOriginalQuadCapture.Quad, VeilModelGeometryStamp>
                        sample) {
            if (!current()) return;
            this.sample = sample;
            prepared = PreparedOriginalModels.prepare(node, lease.quads(), lease.models(), sample);
            if (!current()) prepared = null;
        }

        boolean replay(
                net.minecraft.client.renderer.chunk.RenderSectionRegion region,
                net.minecraft.core.BlockPos position,
                net.minecraft.world.level.block.state.BlockState state,
                net.minecraft.client.renderer.block.dispatch.BlockStateModel model,
                VeilSectionRenderAdapter.Session renderer) {
            if (prepared == null) return false;
            if (!current()) {
                if (reused != 0) throw new Unstable();
                return false;
            }
            var input = prepared.input(position);
            if (input == null) return false;
            int from = input.from(), to = input.to();
            var originals = lease.quads();
            var first = input.probe();
            if (first.state() != state || first.model() != model) throw new Unstable();
            var stamp = prepared.stamp(position);
            if (!stamp.matches(sample.apply(first))) throw new Unstable();
            if (from != to && !renderer.replayBlock(region, originals, from, to)) return false;
            reused++;
            if (!current() || !stamp.matches(sample.apply(first))) throw new Unstable();
            if (VERIFY_REUSE
                    && Boolean.getBoolean("veil.verifyOriginalReuseRetry")
                    && INJECT_RETRY.compareAndSet(false, true)) throw new Unstable();
            VeilOriginalQuadCapture.beginModel(position, state, model, stamp);
            for (var sprite : input.sprites()) VeilAnimatedSpriteUsage.recordOrMark(sprite);
            if (VeilOriginalQuadCapture.active())
                for (int i = from; i < to; i++) {
                    var quad = originals.get(i);
                    VeilOriginalQuadCapture.record(
                            position,
                            state,
                            model,
                            quad.x(),
                            quad.y(),
                            quad.z(),
                            quad.cullFace(),
                            quad.ambient(),
                            quad.neighborLight(),
                            quad::geometry);
                }
            VeilOriginalQuadCapture.finishModelGeometry(stamp);
            if (from == to) REUSED_EMPTY.increment();
            REUSED_SPRITES.add(input.sprites().size());
            return true;
        }

        void validate() {
            if (reused > 0 && !current()) throw new Unstable();
        }

        private Scope(long node, Source source, VeilOriginalQuadCapture.Lease lease) {
            this.node = node;
            this.source = source;
            this.lease = lease;
        }

        boolean current() {
            return thread == Thread.currentThread()
                    && lease != null
                    && lease.current()
                    && SOURCES.get(node) == source
                    && source.current.getAsBoolean();
        }

        VeilOriginalQuadCapture.Lease input() {
            if (!current()) return null;
            return lease;
        }

        private void release() {
            if (lease != null) lease.close();
            lease = null;
        }

        @Override
        public void close() {
            if (thread == null) return;
            var stack = WORK.get();
            if (thread != Thread.currentThread() || stack == null || stack.peek() != this)
                throw new IllegalStateException("Foreign or unordered original attribute work");
            stack.pop();
            if (stack.isEmpty()) WORK.remove();
            release();
            sample = null;
            prepared = null;
            thread = null;
        }
    }
}
