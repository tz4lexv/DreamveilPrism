package dev.veil.revive.client.graphics.resources;

import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.vulkan.VulkanGpuTexture;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;

public final class TextureInitialization {
    private TextureInitialization() {}

    public static void clearZero(VkCommandBuffer command, GpuTexture texture) {
        if (!(texture instanceof VulkanGpuTexture image))
            throw new IllegalStateException("Zero initialization requires a Vulkan image");
        int aspect =
                texture.getFormat().hasDepthAspect()
                        ? VK_IMAGE_ASPECT_DEPTH_BIT
                        : VK_IMAGE_ASPECT_COLOR_BIT;
        if (texture.getFormat().hasStencilAspect()) aspect |= VK_IMAGE_ASPECT_STENCIL_BIT;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var barriers = VkImageMemoryBarrier2.calloc(1, stack);
            var barrier =
                    barriers.get(0)
                            .sType$Default()
                            .srcStageMask(VK_PIPELINE_STAGE_2_TOP_OF_PIPE_BIT)
                            .srcAccessMask(0)
                            .dstStageMask(VK_PIPELINE_STAGE_2_TRANSFER_BIT)
                            .dstAccessMask(VK_ACCESS_2_TRANSFER_WRITE_BIT)
                            .oldLayout(VK_IMAGE_LAYOUT_UNDEFINED)
                            .newLayout(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL)
                            .srcQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                            .dstQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                            .image(image.vkImage());
            barrier.subresourceRange()
                    .aspectMask(aspect)
                    .baseMipLevel(0)
                    .levelCount(1)
                    .baseArrayLayer(0)
                    .layerCount(1);
            KHRSynchronization2.vkCmdPipelineBarrier2KHR(
                    command,
                    VkDependencyInfo.calloc(stack).sType$Default().pImageMemoryBarriers(barriers));
            var range = VkImageSubresourceRange.calloc(1, stack);
            range.get(0)
                    .aspectMask(aspect)
                    .baseMipLevel(0)
                    .levelCount(1)
                    .baseArrayLayer(0)
                    .layerCount(1);
            if (texture.getFormat().hasDepthAspect() || texture.getFormat().hasStencilAspect()) {
                vkCmdClearDepthStencilImage(
                        command,
                        image.vkImage(),
                        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                        VkClearDepthStencilValue.calloc(stack).depth(0.0f).stencil(0),
                        range);
            } else {
                var clear = VkClearColorValue.calloc(stack);
                clear.float32(0, 0).float32(1, 0).float32(2, 0).float32(3, 0);
                vkCmdClearColorImage(
                        command,
                        image.vkImage(),
                        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                        clear,
                        range);
            }
        }
    }
}
