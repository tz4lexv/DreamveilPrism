package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.MultiArenaAllocator;
import dev.veil.revive.core.terrain.PackedTerrainVertices;

import net.minecraft.client.renderer.chunk.SectionMesh;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;

final class VeilPackedTerrain {
    private static boolean enabled = Boolean.getBoolean("veil.packedTerrainVertices");
    private static final HashMap<Long, Integer> TILES = new HashMap<>();
    private static final ArrayList<Long> TILE_VALUES = new ArrayList<>();
    private static final ArrayList<GpuBuffer> RETIRED_TABLES = new ArrayList<>();
    private static final IdentityHashMap<GpuBuffer, Integer> FORMATS = new IdentityHashMap<>();
    private static final IdentityHashMap<SectionMesh, Integer> OWNERS = new IdentityHashMap<>();
    private static final java.util.List<VeilManagedGpuArena<SectionMesh>> ARENAS =
            new ArrayList<>(java.util.Arrays.asList(null, null));
    private static VeilPersistentStagingBuffer staging;
    private static GpuBuffer tileBuffer;
    private static ByteBuffer scratch;
    private static int uploadedTiles;
    private static int tileCapacity;
    private static long encoded16, encoded20, rejected;
    private static final boolean VERIFY =
            dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.verifyPackedVertices");
    private static long verifiedVertices;

    private VeilPackedTerrain() {}

    static int stage(SectionMesh mesh, ByteBuffer wide) {
        if (!enabled) return 0;
        int vertices = wide.remaining() / 32;
        int start = wide.position();
        boolean half = !"false".equalsIgnoreCase(System.getProperty("veil.packedTerrainPrefer16"));
        for (int i = 0; i < vertices; i++) {
            int at = start + i * 32;
            int light = light(wide, at);
            if (!PackedTerrainVertices.canEncode(
                    position(wide, at),
                    position(wide, at + 2),
                    position(wide, at + 4),
                    wide.getFloat(at + 12),
                    wide.getFloat(at + 16),
                    light,
                    0,
                    20)) {
                rejected++;
                return 0;
            }
            half &=
                    PackedTerrainVertices.exactHalf(wide.getFloat(at + 12))
                            && PackedTerrainVertices.exactHalf(wide.getFloat(at + 16));
        }
        int stride = half ? 16 : 20;
        int bytes = Math.multiplyExact(vertices, stride);
        if (scratch == null || scratch.capacity() < bytes) {
            if (scratch != null) MemoryUtil.memFree(scratch);
            scratch = MemoryUtil.memAlloc(Math.max(4096, bytes)).order(ByteOrder.LITTLE_ENDIAN);
        }
        scratch.clear();
        for (int i = 0; i < vertices; i++) {
            int at = start + i * 32;
            long tile = wide.getLong(at + 24);
            Integer tileIndex = TILES.get(tile);
            if (tileIndex == null) {
                if (TILE_VALUES.size() == 65536) {
                    rejected++;
                    return 0;
                }
                tileIndex = TILE_VALUES.size();
                TILES.put(tile, tileIndex);
                TILE_VALUES.add(tile);
            }
            PackedTerrainVertices.put(
                    scratch,
                    position(wide, at),
                    position(wide, at + 2),
                    position(wide, at + 4),
                    wide.getInt(at + 8),
                    wide.getFloat(at + 12),
                    wide.getFloat(at + 16),
                    light(wide, at),
                    tileIndex,
                    stride);
        }
        scratch.flip();
        if (VERIFY) verify(wide, scratch, stride);
        int slot = stride == 16 ? 0 : 1;
        if (staging == null)
            staging = new VeilPersistentStagingBuffer("Veil packed terrain uploads", 4 << 20);
        if (ARENAS.get(slot) == null)
            ARENAS.set(
                    slot,
                    new VeilManagedGpuArena<>(
                            "Veil terrain " + stride + " byte vertices",
                            GpuBuffer.USAGE_VERTEX,
                            16 << 20,
                            stride,
                            staging));
        if (!ARENAS.get(slot).addAllocation(mesh, null, scratch)) return 0;
        OWNERS.put(mesh, slot);
        if ((stride == 16 ? encoded16 : encoded20) == 0)
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil packed terrain ACTIVE: {} bytes per vertex, exact UV/position eligibility, wide fallback",
                    stride);
        if (stride == 16) encoded16 += vertices;
        else encoded20 += vertices;
        return stride;
    }

    private static float position(ByteBuffer data, int offset) {
        return (data.getShort(offset) & 65535) / 2048.0f;
    }

    private static void verify(ByteBuffer wide, ByteBuffer packed, int stride) {
        for (int i = 0; i < wide.remaining() / 32 && verifiedVertices < 100000; i++) {
            int source = wide.position() + i * 32, target = packed.position() + i * stride;
            int coordinates = packed.getInt(target);
            for (int axis = 0; axis < 3; axis++)
                if (PackedTerrainVertices.coordinate(coordinates, axis)
                        != position(wide, source + axis * 2))
                    throw new IllegalStateException(
                            "Packed terrain position differs from wide vertex");
            float u =
                    stride == 20
                            ? packed.getFloat(target + 8)
                            : Float.float16ToFloat(packed.getShort(target + 8));
            float v =
                    stride == 20
                            ? packed.getFloat(target + 12)
                            : Float.float16ToFloat(packed.getShort(target + 10));
            int lightTile = packed.getInt(target + stride - 4);
            int decodedLight = (lightTile & 255) | (((lightTile >>> 8) & 255) << 16);
            if (packed.getInt(target + 4) != wide.getInt(source + 8)
                    || Float.floatToRawIntBits(u)
                            != Float.floatToRawIntBits(wide.getFloat(source + 12))
                    || Float.floatToRawIntBits(v)
                            != Float.floatToRawIntBits(wide.getFloat(source + 16))
                    || decodedLight != light(wide, source)
                    || TILE_VALUES.get(lightTile >>> 16) != wide.getLong(source + 24))
                throw new IllegalStateException(
                        "Packed terrain attributes differ from wide vertex");
            if (++verifiedVertices == 100000)
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil packed vertex verification PASS: 100000 attributes match wide source");
        }
    }

    private static int light(ByteBuffer data, int offset) {
        return (data.getShort(offset + 20) & 65535) | ((data.getShort(offset + 22) & 65535) << 16);
    }

    static void upload() {
        if (staging == null) return;
        try (var uploader =
                staging.startUploading(RenderSystem.getDevice().createCommandEncoder())) {
            for (var arena : ARENAS)
                if (arena != null)
                    arena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
        }
        if (uploadedTiles != TILE_VALUES.size()) {
            boolean resize = tileCapacity < TILE_VALUES.size();
            int first = resize ? 0 : uploadedTiles;
            ByteBuffer table =
                    MemoryUtil.memAlloc((TILE_VALUES.size() - first) * 8)
                            .order(ByteOrder.LITTLE_ENDIAN);
            try {
                for (int i = first; i < TILE_VALUES.size(); i++) table.putLong(TILE_VALUES.get(i));
                table.flip();
                if (resize) {
                    tileCapacity =
                            Math.max(1024, Integer.highestOneBit(TILE_VALUES.size() - 1) << 1);
                    GpuBuffer next =
                            RenderSystem.getDevice()
                                    .createBuffer(
                                            () -> "Veil atlas tile table",
                                            GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER
                                                    | GpuBuffer.USAGE_COPY_DST,
                                            tileCapacity * 8);
                    if (tileBuffer != null) RETIRED_TABLES.add(tileBuffer);
                    tileBuffer = next;
                }
                RenderSystem.getDevice()
                        .createCommandEncoder()
                        .writeToBuffer(tileBuffer.slice(first * 8L, table.remaining()), table);
                uploadedTiles = TILE_VALUES.size();
            } finally {
                MemoryUtil.memFree(table);
            }
        }
    }

    static VeilManagedGpuArena<SectionMesh> arena(SectionMesh mesh) {
        Integer slot = OWNERS.get(mesh);
        return slot == null ? null : ARENAS.get(slot);
    }

    static GpuBuffer buffer(SectionMesh mesh, MultiArenaAllocator.Allocation allocation) {
        var arena = arena(mesh);
        var buffer = arena.getGpuBuffer(allocation);
        FORMATS.put(buffer, OWNERS.get(mesh) == 0 ? 16 : 20);
        return buffer;
    }

    static int stride(GpuBuffer buffer) {
        return FORMATS.getOrDefault(buffer, 32);
    }

    static boolean enabled() {
        return enabled;
    }

    static void disable() {
        enabled = false;
    }

    static GpuBuffer tiles() {
        return tileBuffer;
    }

    static void maintain() {
        for (var arena : ARENAS) if (arena != null) arena.maintain();
    }

    static void remove(SectionMesh mesh) {
        var arena = arena(mesh);
        if (arena != null) arena.removeAllocation(mesh);
        OWNERS.remove(mesh);
    }

    static void close() {
        for (int i = 0; i < ARENAS.size(); i++) {
            if (ARENAS.get(i) != null) ARENAS.get(i).close();
            ARENAS.set(i, null);
        }
        if (staging != null) staging.close();
        staging = null;
        if (tileBuffer != null) tileBuffer.close();
        tileBuffer = null;
        for (var buffer : RETIRED_TABLES) buffer.close();
        RETIRED_TABLES.clear();
        if (scratch != null) MemoryUtil.memFree(scratch);
        scratch = null;
        FORMATS.clear();
        OWNERS.clear();
        TILES.clear();
        TILE_VALUES.clear();
        uploadedTiles = 0;
        tileCapacity = 0;
    }

    static String telemetry() {
        return "terrain_packed16_vertices_total="
                + encoded16
                + "\nterrain_packed20_vertices_total="
                + encoded20
                + "\nterrain_packed_rejected_total="
                + rejected
                + "\nterrain_atlas_tiles="
                + TILE_VALUES.size()
                + "\n";
    }
}
