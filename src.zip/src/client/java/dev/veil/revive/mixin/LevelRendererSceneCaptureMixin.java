package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilSceneReplay;

import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.LevelRenderState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererSceneCaptureMixin {
    @Inject(method = "submitFeatures", at = @At("HEAD"))
    private void veil$captureSceneFeatures(
            LevelRenderState state,
            SubmitNodeCollector output,
            boolean renderOutline,
            CallbackInfo callback) {
        VeilSceneReplay.capture((LevelRenderer) (Object) this, state);
    }
}
