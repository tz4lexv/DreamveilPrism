package dev.veil.api;

import java.util.Objects;

public record VeilTransfer(
        Kind kind,
        String source,
        String destination,
        long sourceOffset,
        long destinationOffset,
        long size,
        int fillValue,
        ImageRegion sourceRegion,
        ImageRegion destinationRegion,
        ClearValue clear,
        BufferLayout bufferLayout) {
    /**
     * Vulkan buffer/image copy strides, specified in whole texels (not bytes). Zero selects the
     * tightly packed Vulkan default for that dimension. These are NOT staging buffer alignment
     * requirements; format and access capabilities are checked by the transfer planner.
     */
    public record BufferLayout(int rowLengthTexels, int imageHeightTexels) {
        public BufferLayout {
            if (rowLengthTexels < 0 || imageHeightTexels < 0)
                throw new IllegalArgumentException("Buffer/image strides must be non-negative");
        }

        /** The byte extent from the first copied byte to the last, including interior padding. */
        public long requiredBytes(int width, int height, int slices, int texelBytes) {
            if (width < 1 || height < 1 || slices < 1 || texelBytes < 1)
                throw new IllegalArgumentException("Invalid transfer region dimensions");
            if ((rowLengthTexels != 0 && rowLengthTexels < width)
                    || (imageHeightTexels != 0 && imageHeightTexels < height))
                throw new IllegalArgumentException(
                        "Buffer layout is smaller than copied image region");
            long row = rowLengthTexels == 0 ? width : rowLengthTexels;
            long rows = imageHeightTexels == 0 ? height : imageHeightTexels;
            try {
                return Math.multiplyExact(
                        Math.addExact(
                                Math.multiplyExact(slices - 1L, Math.multiplyExact(row, rows)),
                                Math.addExact(Math.multiplyExact(height - 1L, row), width)),
                        texelBytes);
            } catch (ArithmeticException overflow) {
                throw new IllegalArgumentException(
                        "Buffer/image transfer extent overflow", overflow);
            }
        }
    }

    /** Source compatibility for existing VeilTransfer declarations. */
    public VeilTransfer(
            Kind kind,
            String source,
            String destination,
            long sourceOffset,
            long destinationOffset,
            long size,
            int fillValue,
            ImageRegion sourceRegion,
            ImageRegion destinationRegion,
            ClearValue clear) {
        this(
                kind,
                source,
                destination,
                sourceOffset,
                destinationOffset,
                size,
                fillValue,
                sourceRegion,
                destinationRegion,
                clear,
                null);
    }

    public enum Kind {
        BUFFER_COPY,
        BUFFER_FILL,
        BUFFER_TO_IMAGE,
        IMAGE_TO_BUFFER,
        IMAGE_COPY,
        IMAGE_CLEAR,
        IMAGE_RESOLVE,
        IMAGE_BLIT_NEAREST,
        IMAGE_BLIT_LINEAR
    }

    public enum Aspect {
        COLOR,
        DEPTH,
        STENCIL
    }

    public record ImageRegion(
            int mip,
            int baseLayer,
            int layerCount,
            int x,
            int y,
            int z,
            int width,
            int height,
            int depth,
            Aspect aspect) {
        public ImageRegion {
            if (mip < 0
                    || baseLayer < 0
                    || layerCount < 1
                    || x < 0
                    || y < 0
                    || z < 0
                    || width < 1
                    || height < 1
                    || depth < 1)
                throw new IllegalArgumentException("Invalid image transfer region");
            Objects.requireNonNull(aspect, "aspect");
        }
    }

    /** Image clears use Vulkan's typed color union. Integer channels retain their 32-bit bits. */
    public enum ClearColorType {
        FLOAT,
        SINT,
        UINT
    }

    public record ClearValue(
            float r,
            float g,
            float b,
            float a,
            float depth,
            int stencil,
            ClearColorType colorType,
            int c0,
            int c1,
            int c2,
            int c3) {
        /** Source compatibility: existing color clears remain floating-point. */
        public ClearValue(float r, float g, float b, float a, float depth, int stencil) {
            this(r, g, b, a, depth, stencil, ClearColorType.FLOAT, 0, 0, 0, 0);
        }

        public static ClearValue signed(int r, int g, int b, int a) {
            return new ClearValue(0, 0, 0, 0, 0, 0, ClearColorType.SINT, r, g, b, a);
        }

        /** Unsigned components are stored as raw 32-bit values, including 0xffffffff. */
        public static ClearValue unsigned(int r, int g, int b, int a) {
            return new ClearValue(0, 0, 0, 0, 0, 0, ClearColorType.UINT, r, g, b, a);
        }

        public ClearValue {
            Objects.requireNonNull(colorType, "colorType");
            if (!Float.isFinite(r)
                    || !Float.isFinite(g)
                    || !Float.isFinite(b)
                    || !Float.isFinite(a)
                    || !Float.isFinite(depth)
                    || depth < 0
                    || depth > 1
                    || stencil < 0
                    || (colorType != ClearColorType.FLOAT && (r != 0 || g != 0 || b != 0 || a != 0))
                    || (colorType == ClearColorType.FLOAT
                            && (c0 != 0 || c1 != 0 || c2 != 0 || c3 != 0))) {
                throw new IllegalArgumentException("Invalid image clear value");
            }
        }
    }

    public VeilTransfer {
        Objects.requireNonNull(kind, "kind");
        if (bufferLayout != null && kind != Kind.BUFFER_TO_IMAGE && kind != Kind.IMAGE_TO_BUFFER)
            throw new IllegalArgumentException("Only buffer/image copies accept bufferLayout");
        if (sourceOffset < 0 || destinationOffset < 0 || size < 0)
            throw new IllegalArgumentException("Transfer offsets and size must be non-negative");
        switch (kind) {
            case BUFFER_COPY ->
                    require(
                            true,
                            source,
                            destination,
                            size > 0
                                    && fillValue == 0
                                    && sourceRegion == null
                                    && destinationRegion == null
                                    && clear == null,
                            "buffer copy");
            case BUFFER_FILL ->
                    require(
                            false,
                            source,
                            destination,
                            size > 0
                                    && sourceOffset == 0
                                    && sourceRegion == null
                                    && destinationRegion == null
                                    && clear == null,
                            "buffer fill");
            case BUFFER_TO_IMAGE ->
                    require(
                            true,
                            source,
                            destination,
                            destinationOffset == 0
                                    && size == 0
                                    && fillValue == 0
                                    && sourceRegion == null
                                    && destinationRegion != null
                                    && clear == null,
                            "buffer to image");
            case IMAGE_TO_BUFFER ->
                    require(
                            true,
                            source,
                            destination,
                            sourceOffset == 0
                                    && size == 0
                                    && fillValue == 0
                                    && sourceRegion != null
                                    && destinationRegion == null
                                    && clear == null,
                            "image to buffer");
            case IMAGE_COPY, IMAGE_RESOLVE, IMAGE_BLIT_NEAREST, IMAGE_BLIT_LINEAR ->
                    require(
                            true,
                            source,
                            destination,
                            sourceOffset == 0
                                    && destinationOffset == 0
                                    && size == 0
                                    && fillValue == 0
                                    && sourceRegion != null
                                    && destinationRegion != null
                                    && clear == null,
                            "image copy");
            case IMAGE_CLEAR ->
                    require(
                            false,
                            source,
                            destination,
                            sourceOffset == 0
                                    && destinationOffset == 0
                                    && size == 0
                                    && fillValue == 0
                                    && sourceRegion == null
                                    && destinationRegion != null
                                    && clear != null,
                            "image clear");
        }
        if ((kind == Kind.BUFFER_FILL) && ((destinationOffset | size) & 3L) != 0) {
            throw new IllegalArgumentException(
                    "Buffer fill offset and size must be 4-byte aligned");
        }
    }

    private static void require(
            boolean sourceRequired,
            String source,
            String destination,
            boolean shape,
            String operation) {
        if (destination == null
                || destination.isBlank()
                || sourceRequired && (source == null || source.isBlank())
                || !sourceRequired && source != null
                || !shape) {
            throw new IllegalArgumentException("Invalid " + operation + " operation");
        }
    }
}
