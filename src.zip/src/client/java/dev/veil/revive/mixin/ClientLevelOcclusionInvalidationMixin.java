package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilAsyncEntityOcclusion;

import net.minecraft.client.multiplayer.ClientLevel;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientLevel.class)
public abstract class ClientLevelOcclusionInvalidationMixin {
    @Inject(method = "setBlock", at = @At("HEAD"), require = 1)
    private void veil$invalidateBlock(CallbackInfoReturnable<Boolean> ci) {
        VeilAsyncEntityOcclusion.invalidate();
    }

    @Inject(method = "unload", at = @At("HEAD"), require = 1)
    private void veil$invalidateChunk(CallbackInfo ci) {
        VeilAsyncEntityOcclusion.invalidate();
    }
}
