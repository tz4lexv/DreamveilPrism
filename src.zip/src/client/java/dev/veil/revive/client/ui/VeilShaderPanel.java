package dev.veil.revive.client.ui;

import dev.veil.revive.client.VeilShaderPack;
import dev.veil.revive.client.VeilShaderService;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.util.*;

final class VeilShaderPanel {
    private final VeilSettingsScreen host;
    private final Font font;
    private final boolean spanish;
    private final List<AbstractWidget> widgets = new ArrayList<>();
    private final Map<String, String> drafts = new HashMap<>();
    private List<String> packs = List.of();
    private Map<String, VeilShaderPack.Setting> settings = Map.of();
    private boolean settingsPage, reportPage, previousProfiling;
    private int ticks;
    private List<String> report = List.of();
    private int scroll, top, bottom, width;
    private String path = "", query = "", notice = "";
    private List<String> visible = List.of();

    VeilShaderPanel(VeilSettingsScreen host, Font font, boolean spanish) {
        this.host = host;
        this.font = font;
        this.spanish = spanish;
        discover();
    }

    private String tr(String es, String en) {
        return spanish ? es : en;
    }

    private void discover() {
        try {
            packs = VeilShaderService.availablePacks();
        } catch (IOException failure) {
            notice = failure.getMessage();
        }
        settings = VeilShaderService.settingsSnapshot();
    }

    void build(int top, int bottom, int width, String query) {
        clear();
        this.top = top;
        this.bottom = bottom;
        this.width = width;
        this.query = query;
        int third = (width - 8) / 3;
        int half = (width - 4) / 2;
        button(
                tr("Packs", "Packs"),
                8,
                top,
                third,
                () -> {
                    deactivate();
                    settingsPage = false;
                    scroll = 0;
                    refresh();
                });
        button(
                tr("Ajustes", "Settings"),
                12 + third,
                top,
                third,
                () -> {
                    deactivate();
                    settingsPage = true;
                    scroll = 0;
                    refresh();
                });
        button(
                tr("Medir GPU", "GPU report"),
                16 + third * 2,
                top,
                third,
                () -> {
                    if (!reportPage) {
                        previousProfiling = VeilShaderService.profiling();
                        VeilShaderService.profiling(true);
                    }
                    reportPage = true;
                    scroll = 0;
                    refresh();
                });
        if (reportPage) {
            var lines = new ArrayList<String>();
            for (String line : VeilShaderService.performanceReport().split("\n")) {
                while (font.width(line) > width - 12) {
                    String part = font.plainSubstrByWidth(line, width - 12);
                    if (part.isEmpty()) break;
                    lines.add(part);
                    line = line.substring(part.length());
                }
                lines.add(line);
            }
            report = List.copyOf(lines);
            scroll =
                    Math.clamp(
                            scroll,
                            0,
                            Math.max(0, report.size() - Math.max(0, (bottom - top - 26) / 12)));
            return;
        }
        int first = top + 26;
        if (!settingsPage) {
            EditBox selection =
                    new EditBox(
                            font,
                            8,
                            first,
                            Math.max(40, width - 80),
                            20,
                            Component.literal(tr("Pack o ruta", "Pack or path")));
            selection.setMaxLength(1024);
            selection.setHint(Component.literal(tr("Nombre o ruta del pack", "Pack name or path")));
            selection.setValue(path);
            selection.setResponder(value -> path = value);
            add(selection);
            button(tr("Cargar", "Load"), 12 + width - 80, first, 76, () -> select(path));
            button(tr("Desactivar", "Disable"), 8, first + 24, half, () -> select(""));
            button(
                    tr("Recargar", "Reload"),
                    12 + half,
                    first + 24,
                    half,
                    () -> {
                        VeilShaderService.requestReload();
                        notice = "";
                    });
            first += 50;
        }
        visible =
                (settingsPage ? settings.keySet().stream().sorted().toList() : packs)
                        .stream()
                                .filter(
                                        name ->
                                                name.toLowerCase(Locale.ROOT)
                                                        .contains(query.toLowerCase(Locale.ROOT)))
                                .toList();
        int capacity = Math.max(0, (bottom - first) / 24);
        scroll = Math.clamp(scroll, 0, Math.max(0, visible.size() - capacity));
        for (int i = scroll; i < Math.min(visible.size(), scroll + capacity); i++) {
            String name = visible.get(i);
            int y = first + (i - scroll) * 24;
            if (!settingsPage)
                button(
                        name,
                        8,
                        y,
                        width,
                        () -> {
                            path = name;
                            select(name);
                        });
            else {
                int label = Math.min(130, width / 3);
                EditBox value =
                        new EditBox(
                                font,
                                8 + label,
                                y,
                                Math.max(30, width - label - 66),
                                20,
                                Component.literal(name));
                value.setMaxLength(128);
                value.setValue(drafts.getOrDefault(name, settings.get(name).value()));
                value.setResponder(text -> drafts.put(name, text));
                add(value);
                button(
                        tr("Aplicar", "Apply"),
                        12 + width - 66,
                        y,
                        62,
                        () -> {
                            try {
                                VeilShaderService.setting(name, value.getValue());
                                drafts.remove(name);
                                notice = "";
                            } catch (IllegalArgumentException failure) {
                                notice = failure.getMessage();
                            }
                        });
            }
        }
    }

    private void add(AbstractWidget widget) {
        widgets.add(widget);
        host.addShaderWidget(widget);
    }

    private void button(String title, int x, int y, int width, Runnable action) {
        add(host.shaderButton(x, y, width, title, action));
    }

    private void select(String name) {
        VeilShaderService.select(name);
        drafts.clear();
        notice = "";
    }

    private void refresh() {
        discover();
        build(top, bottom, width, query);
    }

    void clear() {
        widgets.forEach(host::removeShaderWidget);
        widgets.clear();
    }

    void scrolled(double delta) {
        scroll -= (int) Math.signum(delta) * 3;
        build(top, bottom, width, query);
    }

    void deactivate() {
        if (reportPage) {
            VeilShaderService.profiling(previousProfiling);
            reportPage = false;
        }
    }

    void tick() {
        if (reportPage && ++ticks % 20 == 0) {
            build(top, bottom, width, query);
            return;
        }
        if (settings != VeilShaderService.settingsSnapshot()) {
            settings = VeilShaderService.settingsSnapshot();
            build(top, bottom, width, query);
        }
    }

    String status() {
        return notice == null || notice.isBlank() ? VeilShaderService.userStatus(spanish) : notice;
    }

    String description() {
        return tr(
                "Elige un pack o introduce su ruta. Sus ajustes aparecen en esta misma pestaña. Cargar, recargar y aplicar un ajuste del pack tienen efecto inmediato.",
                "Choose a pack or enter its path. Its settings appear in this tab. Loading, reloading and applying a pack setting take effect immediately.");
    }

    void render(GuiGraphicsExtractor graphics) {
        if (reportPage) {
            int first = top + 26, capacity = Math.max(0, (bottom - first) / 12);
            for (int i = scroll; i < Math.min(report.size(), scroll + capacity); i++)
                graphics.text(font, report.get(i), 8, first + (i - scroll) * 12, 0xffedf1f5);
            return;
        }
        if (!settingsPage) {
            if (visible.isEmpty() && top + 85 < bottom)
                graphics.text(
                        font,
                        tr("No hay packs en shaderpacks", "No packs in shaderpacks"),
                        8,
                        top + 85,
                        0xffa8b4bd);
            return;
        }
        int first = top + 26,
                capacity = Math.max(0, (bottom - first) / 24),
                label = Math.min(130, width / 3);
        for (int i = scroll; i < Math.min(visible.size(), scroll + capacity); i++) {
            int y = first + (i - scroll) * 24;
            graphics.fill(8, y, 8 + label - 3, y + 20, 0xc0111921);
            graphics.text(
                    font,
                    font.plainSubstrByWidth(visible.get(i), label - 12),
                    14,
                    y + 6,
                    0xffedf1f5);
        }
    }
}
