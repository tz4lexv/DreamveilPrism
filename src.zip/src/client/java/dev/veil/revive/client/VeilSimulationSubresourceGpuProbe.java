package dev.veil.revive.client;

import dev.veil.api.VeilSimulationFieldSnapshot;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.util.Arrays;

final class VeilSimulationSubresourceGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.simulationSubresourceGpuProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();

    private record Selection(String resource, int mip, int layer, int width, int depth) {}

    private static final Selection[] SELECTIONS = {
        new Selection("array", 1, 1, 2, 1),
        new Selection("array", 2, 0, 1, 1),
        new Selection("cube", 1, 5, 2, 1),
        new Selection("volume", 1, 0, 2, 2),
        new Selection("volume", 2, 0, 1, 1)
    };
    private static long started;
    private static boolean requested, completed;
    private static int index;
    private static final java.util.concurrent.atomic.AtomicReference<Runnable> diskCompletion =
            new java.util.concurrent.atomic.AtomicReference<>();

    private VeilSimulationSubresourceGpuProbe() {}

    static void checkTimeout(boolean failed) {
        if (!ENABLED || completed) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 120_000_000_000L)
            fail(new IllegalStateException("Simulation subresource GPU timeout/reload failure"));
    }

    static void tick(VeilShaderPackRuntime active) {
        if (!ENABLED || completed) return;
        var completion = diskCompletion.getAndSet(null);
        if (completion != null) completion.run();
        if (requested || completed) return;
        if (!System.getProperty("veil.shaderPack", "").equals("veil-simulation-subresources-v1"))
            throw new IllegalStateException("Simulation subresource probe requires its fixture");
        requested = true;
        for (int[] invalid : new int[][] {{-1, 0}, {3, 0}, {0, -1}, {0, 2}}) {
            boolean rejected = false;
            try {
                active.readSimulationField(
                        "array",
                        invalid[0],
                        invalid[1],
                        field -> {
                            fail(new IllegalStateException("Invalid selection was enqueued"));
                        });
            } catch (IllegalArgumentException expected) {
                rejected = true;
            }
            require(rejected, "invalid selection rejected before readback");
        }
        var joint =
                java.util.Map.of(
                        "creator-array",
                                new dev.veil.api.VeilSimulationCheckpoint.Selection("array", 1, 1),
                        "creator-volume",
                                new dev.veil.api.VeilSimulationCheckpoint.Selection(
                                        "volume", 1, 0));
        boolean budgetRejected = false;
        try {
            active.readSimulationCheckpoint(
                    joint,
                    1,
                    ignored -> fail(new IllegalStateException("Overbudget checkpoint enqueued")));
        } catch (IllegalArgumentException expected) {
            budgetRejected = true;
        }
        require(budgetRejected, "joint budget rejected before copy");
        var originalArray =
                new VeilSimulationFieldSnapshot(
                        2, 2, 1, 4, VeilSimulationFieldSnapshot.ScalarType.UINT8, new byte[16]);
        var originalVolume =
                new VeilSimulationFieldSnapshot(
                        2, 2, 2, 4, VeilSimulationFieldSnapshot.ScalarType.UINT8, new byte[32]);
        byte[] arrayPattern = new byte[16];
        byte[] volumePattern = new byte[32];
        Arrays.fill(arrayPattern, (byte) 37);
        Arrays.fill(volumePattern, (byte) 93);
        active.restoreSimulationField(
                "array",
                1,
                1,
                new VeilSimulationFieldSnapshot(
                        2, 2, 1, 4, VeilSimulationFieldSnapshot.ScalarType.UINT8, arrayPattern));
        active.restoreSimulationField(
                "volume",
                1,
                0,
                new VeilSimulationFieldSnapshot(
                        2, 2, 2, 4, VeilSimulationFieldSnapshot.ScalarType.UINT8, volumePattern));
        VeilShaderService.captureSimulationCheckpoint(
                joint,
                48,
                checkpoint -> {
                    try {
                        require(
                                checkpoint.frame() > 0 && checkpoint.generation() != null,
                                "joint provenance");
                        require(checkpoint.fields().size() == 2, "joint complete publication");
                        var array = checkpoint.fields().get("creator-array");
                        var volume = checkpoint.fields().get("creator-volume");
                        require(
                                array.selection().equals(joint.get("creator-array"))
                                        && volume.selection().equals(joint.get("creator-volume")),
                                "joint selection metadata");
                        require(
                                array.format() == dev.veil.api.VeilFormat.RGBA8_UNORM
                                        && volume.format() == dev.veil.api.VeilFormat.RGBA8_UNORM,
                                "joint exact format");
                        require(
                                Arrays.equals(array.data().pixels(), arrayPattern)
                                        && Arrays.equals(volume.data().pixels(), volumePattern),
                                "joint independent field contents");
                        ReviveMod.LOGGER.info(
                                "Veil simulation joint checkpoint GPU: PASS (2 fields, exact patterns/format/subresource, provenance, budget rejection)");
                        persist(active, joint, checkpoint, originalArray, originalVolume);
                    } catch (RuntimeException failure) {
                        fail(failure);
                    }
                });
    }

    private static void persist(
            VeilShaderPackRuntime active,
            java.util.Map<String, dev.veil.api.VeilSimulationCheckpoint.Selection> joint,
            dev.veil.api.VeilSimulationCheckpoint original,
            VeilSimulationFieldSnapshot originalArray,
            VeilSimulationFieldSnapshot originalVolume) {
        var directory =
                java.nio.file.Path.of(
                        System.getProperty("veil.simulationCheckpointProofDirectory"));
        var store = new dev.veil.api.VeilSimulationCheckpointStore(directory, 1024);
        var scope =
                new dev.veil.api.VeilSimulationCheckpointStore.Scope(
                        "probe-world", "minecraft:overworld", "subresource-fixture", "fields", 1);
        var clock = new dev.veil.api.VeilSimulationClock(.01, 128);
        clock.advance(.37, (seconds, index) -> {});
        var cpuState =
                java.util.Map.of(
                        "author/clock",
                        new dev.veil.api.VeilSimulationCheckpoint.CpuState(clock.snapshotBytes()));
        var saving = VeilShaderService.saveSimulationCheckpoint(store, scope, joint, 48, cpuState);
        clock.advance(.56, (seconds, index) -> {});
        saving.thenCompose(ignored -> store.load(scope))
                .whenComplete(
                        (loaded, failure) -> {
                            boolean offRender =
                                    Thread.currentThread()
                                            .getName()
                                            .equals("Veil simulation checkpoint I/O");
                            diskCompletion.set(
                                    () -> {
                                        try {
                                            if (failure != null)
                                                throw new IllegalStateException(
                                                        "Checkpoint I/O failed", failure);
                                            require(
                                                    offRender,
                                                    "checkpoint I/O completes on worker");
                                            var checkpoint = loaded.orElseThrow();
                                            var restoredClock =
                                                    new dev.veil.api.VeilSimulationClock(.01, 128);
                                            restoredClock.restoreBytes(
                                                    checkpoint
                                                            .cpuState()
                                                            .get("author/clock")
                                                            .data());
                                            require(
                                                    restoredClock.totalSteps() == 37
                                                            && clock.totalSteps() == 93,
                                                    "CPU producer clock frozen before deferred GPU/disk completion");
                                            require(
                                                    checkpoint
                                                                    .generation()
                                                                    .equals(original.generation())
                                                            && checkpoint.frame()
                                                                    >= original.frame(),
                                                    "disk provenance");
                                            for (var entry : checkpoint.fields().entrySet()) {
                                                var expected =
                                                        original.fields().get(entry.getKey());
                                                require(
                                                        expected != null
                                                                && entry.getValue().format()
                                                                        == expected.format()
                                                                && entry.getValue()
                                                                        .selection()
                                                                        .equals(
                                                                                expected
                                                                                        .selection())
                                                                && Arrays.equals(
                                                                        entry.getValue()
                                                                                .data()
                                                                                .pixels(),
                                                                        expected.data().pixels()),
                                                        "disk exact metadata/pattern");
                                            }
                                            active.restoreSimulationField(
                                                    "array", 1, 1, originalArray);
                                            active.restoreSimulationField(
                                                    "volume", 1, 0, originalVolume);
                                            for (var field : checkpoint.fields().values()) {
                                                var selection = field.selection();
                                                active.restoreSimulationField(
                                                        selection.resource(),
                                                        selection.mip(),
                                                        selection.layer(),
                                                        field.data());
                                            }
                                            active.readSimulationCheckpoint(
                                                    joint,
                                                    48,
                                                    restored -> {
                                                        try {
                                                            require(
                                                                    restored.fields().size() == 2,
                                                                    "disk restore complete");
                                                            for (var entry :
                                                                    restored.fields().entrySet())
                                                                require(
                                                                        Arrays.equals(
                                                                                entry.getValue()
                                                                                        .data()
                                                                                        .pixels(),
                                                                                original.fields()
                                                                                        .get(
                                                                                                entry
                                                                                                        .getKey())
                                                                                        .data()
                                                                                        .pixels()),
                                                                        "disk to GPU exact");
                                                            active.restoreSimulationField(
                                                                    "array", 1, 1, originalArray);
                                                            active.restoreSimulationField(
                                                                    "volume", 1, 0, originalVolume);
                                                            ReviveMod.LOGGER.info(
                                                                    "Veil simulation persisted checkpoint GPU: PASS (GPU capture, bounded worker save/load, exact metadata/patterns, render-thread restore)");
                                                            store.close();
                                                            run(active);
                                                        } catch (RuntimeException problem) {
                                                            store.close();
                                                            fail(problem);
                                                        }
                                                    });
                                        } catch (java.io.IOException | RuntimeException problem) {
                                            store.close();
                                            fail(
                                                    new IllegalStateException(
                                                            "Checkpoint restore failed", problem));
                                        }
                                    });
                        });
    }

    private static void run(VeilShaderPackRuntime active) {
        if (index == SELECTIONS.length) {
            completed = true;
            ReviveMod.LOGGER.info(
                    "Veil simulation subresources GPU: PASS (5 mip/layer roundtrips, 5 neighbor checks, array/cube/3D, 4 invalid selections)");
            Minecraft.getInstance().stop();
            return;
        }
        var selection = SELECTIONS[index];
        active.readSimulationField(
                selection.resource,
                selection.mip,
                selection.layer,
                original -> {
                    try {
                        require(
                                original.width() == selection.width
                                        && original.height() == selection.width
                                        && original.depth() == selection.depth
                                        && original.components() == 4
                                        && original.type()
                                                == VeilSimulationFieldSnapshot.ScalarType.UINT8,
                                "selected shape");
                        require(
                                Arrays.equals(
                                        original.pixels(), new byte[original.pixels().length]),
                                "initial zero");
                        byte[] pattern = original.pixels();
                        for (int i = 0; i < pattern.length; i++) pattern[i] = (byte) (17 + i * 43);
                        var changed =
                                new VeilSimulationFieldSnapshot(
                                        original.width(),
                                        original.height(),
                                        original.depth(),
                                        original.components(),
                                        original.type(),
                                        pattern);
                        active.restoreSimulationField(
                                selection.resource, selection.mip, selection.layer, changed);
                        active.readSimulationField(
                                selection.resource,
                                selection.mip,
                                selection.layer,
                                captured -> {
                                    try {
                                        require(
                                                Arrays.equals(captured.pixels(), pattern),
                                                "upload/readback exact");
                                        int neighborMip =
                                                selection.resource.equals("volume")
                                                        ? 0
                                                        : selection.mip;
                                        int neighborLayer =
                                                selection.layer == 0
                                                                && !selection.resource.equals(
                                                                        "volume")
                                                        ? 1
                                                        : 0;
                                        active.readSimulationField(
                                                selection.resource,
                                                neighborMip,
                                                neighborLayer,
                                                neighbor -> {
                                                    try {
                                                        require(
                                                                Arrays.equals(
                                                                        neighbor.pixels(),
                                                                        new byte
                                                                                [neighbor.pixels()
                                                                                        .length]),
                                                                "neighbor preserved");
                                                        active.restoreSimulationField(
                                                                selection.resource,
                                                                selection.mip,
                                                                selection.layer,
                                                                original);
                                                        active.readSimulationField(
                                                                selection.resource,
                                                                selection.mip,
                                                                selection.layer,
                                                                restored -> {
                                                                    try {
                                                                        require(
                                                                                Arrays.equals(
                                                                                        restored
                                                                                                .pixels(),
                                                                                        original
                                                                                                .pixels()),
                                                                                "restore exact");
                                                                        index++;
                                                                        run(active);
                                                                    } catch (
                                                                            RuntimeException
                                                                                    failure) {
                                                                        fail(failure);
                                                                    }
                                                                });
                                                    } catch (RuntimeException failure) {
                                                        fail(failure);
                                                    }
                                                });
                                    } catch (RuntimeException failure) {
                                        fail(failure);
                                    }
                                });
                    } catch (RuntimeException failure) {
                        fail(failure);
                    }
                });
    }

    private static void require(boolean okay, String label) {
        if (!okay) throw new IllegalStateException("Simulation subresource mismatch: " + label);
    }

    private static void fail(RuntimeException problem) {
        if (completed) return;
        completed = true;
        ReviveMod.LOGGER.error("Veil simulation subresources GPU: FAIL", problem);
        Minecraft.getInstance().stop();
    }
}
