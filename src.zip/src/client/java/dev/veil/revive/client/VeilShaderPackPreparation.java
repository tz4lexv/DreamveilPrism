package dev.veil.revive.client;

import static dev.veil.revive.client.VeilShaderPack.PRESENTER;
import static dev.veil.revive.client.shaderpack.preparation.BindingValidator.*;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.api.VeilResourceUsage;
import dev.veil.revive.client.VeilShaderPack.Binding;
import dev.veil.revive.client.VeilShaderPack.BindingAccess;
import dev.veil.revive.client.VeilShaderPack.BufferAsset;
import dev.veil.revive.client.VeilShaderPack.ColorAttachment;
import dev.veil.revive.client.VeilShaderPack.Geometry;
import dev.veil.revive.client.VeilShaderPack.ImageAsset;
import dev.veil.revive.client.VeilShaderPack.InitialContent;
import dev.veil.revive.client.VeilShaderPack.LoadOp;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.Prepared;
import dev.veil.revive.client.VeilShaderPack.Resource;
import dev.veil.revive.client.VeilShaderPack.Source;
import dev.veil.revive.client.shaderpack.preparation.BindingValidator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

final class VeilShaderPackPreparation {
    private static long maxImageAssetBytes() {
        return VeilShaderLimits.current().bufferBytes();
    }

    private final VeilShaderPack pack;
    private final int abiVersion;
    private final Map<String, Resource> resources;
    private final Map<VeilShaderId, Map<VeilShaderStage, VeilShaderId>> programs;
    private final List<Pass> passes;
    private final String present;

    VeilShaderPackPreparation(VeilShaderPack pack) {
        this.pack = pack;
        abiVersion = pack.abiVersion();
        resources = pack.resources();
        programs = pack.programs();
        passes = pack.passes();
        present = pack.present();
    }

    Prepared prepare(VeilShaderLibrary library) throws IOException {
        var declarations = new LinkedHashMap<VeilShaderId, Map<VeilShaderStage, VeilShaderId>>();
        for (Pass pass : passes)
            if (!pass.transfer() && !pass.scenePass())
                declarations.put(pass.program(), programs.get(pass.program()));
        if (present != null)
            declarations.put(
                    PRESENTER,
                    Map.of(
                            VeilShaderStage.VERTEX, VeilShaderId.parse("veil:shaders/present.vert"),
                            VeilShaderStage.FRAGMENT,
                                    VeilShaderId.parse("veil:shaders/present.frag")));
        Map<VeilShaderId, VeilShaderProgram> compiled =
                declarations.isEmpty()
                        ? Map.of()
                        : library.prepare(declarations, pack.entryPoints());
        var assets =
                dev.veil.revive.client.shaderpack.preparation.PackAssetLoader.load(
                        resources,
                        library::readAsset,
                        VeilKtx2::decode,
                        maxImageAssetBytes(),
                        VeilShaderLimits.current().packBytes());
        var imageAssets = new LinkedHashMap<String, ImageAsset>();
        var bufferAssets = new LinkedHashMap<String, BufferAsset>();
        assets.images()
                .forEach(
                        (name, asset) ->
                                imageAssets.put(name, new ImageAsset(asset.bytes(), asset.hash())));
        assets.buffers()
                .forEach(
                        (name, asset) ->
                                bufferAssets.put(
                                        name, new BufferAsset(asset.bytes(), asset.hash())));
        var graph = new ArrayList<VeilRenderGraph.Pass>();
        var kinds = new LinkedHashMap<String, VeilRenderGraph.Kind>();
        var initialized = new LinkedHashSet<String>();
        var readOnly = new LinkedHashSet<String>();
        resources.forEach(
                (id, resource) -> {
                    kinds.put(id, resource.kind());
                    if (resource.initialContent() != InitialContent.UNDEFINED) initialized.add(id);
                    if (resource.hostImport() || resource.sampledAsset()) readOnly.add(id);
                    if (resource.history()) {
                        for (int offset = 1; offset < resource.historyCount(); offset++) {
                            kinds.put(id + "#history:" + offset, resource.kind());
                            initialized.add(id + "#history:" + offset);
                        }
                    }
                });
        for (Pass pass : passes) {
            if (pass.transfer()) {
                graph.add(prepareTransfers(pass));
                continue;
            }
            if (pass.scenePass()) {
                graph.add(prepareScene(pass));
                continue;
            }
            var program = compiled.get(pass.program());
            if (program == null)
                throw new IllegalArgumentException(
                        "Pass " + pass.name() + ": missing program " + pass.program());
            if (program.stages().containsKey(VeilShaderStage.COMPUTE) != pass.compute()
                    || program.rayTracing() != pass.raytrace())
                throw new IllegalArgumentException("Pass/program stage mismatch: " + pass.name());
            program.stages().values().forEach(VeilShaderBaseline::validate);
            if (pass.compute() && pass.dispatch().dynamic()) {
                int[] local =
                        VeilShaderBaseline.fixedLocalSize(program.stage(VeilShaderStage.COMPUTE));
                if (local[0] != pass.dispatch().localX()
                        || local[1] != pass.dispatch().localY()
                        || local[2] != pass.dispatch().localZ()) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": dispatch localSize "
                                    + pass.dispatch().localX()
                                    + "x"
                                    + pass.dispatch().localY()
                                    + "x"
                                    + pass.dispatch().localZ()
                                    + " does not match reflected SPIR-V LocalSize "
                                    + local[0]
                                    + "x"
                                    + local[1]
                                    + "x"
                                    + local[2]);
                }
            }
            if (pass.graphics()) {
                var stages = program.stages().keySet();
                if (pass.geometry() == Geometry.FULLSCREEN)
                    VeilGraphicsPipeline.validateFullscreen(
                            program.shaderInterface(), pass.colors().size(), stages);
                else if (pass.geometry().fluid())
                    VeilGraphicsPipeline.validateFluidGeometry(
                            program.shaderInterface(), pass.colors().size(), stages);
                else
                    VeilGraphicsPipeline.validateVertexLayout(
                            pass.vertexLayout(),
                            program.shaderInterface(),
                            pass.colors().size(),
                            stages);
                validateFragmentFormats(pass, program.shaderInterface());
            }
            for (var spec : pass.specialization().entrySet()) {
                if (!program.stages().containsKey(spec.getKey()))
                    throw new IllegalArgumentException(
                            "Specialization stage absent: " + pass.name());
                spec.getValue().validate(program.shaderInterface(), spec.getKey());
            }
            if (pass.frameData()) VeilFrameAbi.validate(program.shaderInterface());
            else if (!program.shaderInterface().pushConstants().isEmpty())
                throw new IllegalArgumentException(
                        "Pass " + pass.name() + ": push constants require frameData=true");
            if (pass.cameraData()) VeilCameraAbi.validate(program.shaderInterface());
            if (pass.sceneProjectionData())
                VeilSceneProjectionAbi.validate(program.shaderInterface());
            if (pass.sceneCamera() != null) VeilSceneCameraAbi.validate(program.shaderInterface());
            var uses = new LinkedHashMap<String, VeilRenderGraph.Access>();
            var graphUses = new ArrayList<VeilRenderGraph.Use>();
            var descriptors = program.shaderInterface().descriptors();
            int systemDescriptors =
                    (pass.cameraData() ? 1 : 0)
                            + (pass.sceneProjectionData() ? 1 : 0)
                            + (pass.sceneCamera() != null ? 1 : 0);
            if (descriptors.size() != pass.bindings().size() + systemDescriptors)
                throw new IllegalArgumentException(
                        "Pass "
                                + pass.name()
                                + ": expected "
                                + descriptors.size()
                                + " reflected bindings, got "
                                + (pass.bindings().size() + systemDescriptors));
            var aliases = new LinkedHashMap<String, List<BindingUse>>();
            for (var descriptor : descriptors) {
                if (VeilCameraAbi.isBinding(descriptor)) {
                    if (!pass.cameraData())
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + ": set=0 binding="
                                        + VeilCameraAbi.BINDING
                                        + " is reserved for CameraData; set cameraData=true");
                    continue;
                }
                if (VeilSceneProjectionAbi.isBinding(descriptor)) {
                    if (!pass.sceneProjectionData())
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + ": set=0 binding="
                                        + VeilSceneProjectionAbi.BINDING
                                        + " is reserved for SceneProjectionData; set sceneProjectionData=true");
                    continue;
                }
                if (VeilSceneCameraAbi.isBinding(descriptor)) {
                    if (pass.sceneCamera() == null)
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + ": set=0 binding="
                                        + VeilSceneCameraAbi.BINDING
                                        + " is reserved for custom scene camera data; set sceneCamera");
                    continue;
                }
                Binding binding = pass.bindings().get(descriptor.binding());
                if (descriptor.set() != 0 || binding == null) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": unsupported or missing descriptor set="
                                    + descriptor.set()
                                    + " binding="
                                    + descriptor.binding());
                }
                int boundCount = binding.resources().size();
                if (descriptor.runtimeArray()) {
                    if (abiVersion < 5 || boundCount < 1 || boundCount > 32) {
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + " binding="
                                        + descriptor.binding()
                                        + ": runtime descriptor array requires ABI 5 and 1..32 manifest resources");
                    }
                } else if (descriptor.descriptorCount() != boundCount) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + " binding="
                                    + descriptor.binding()
                                    + ": descriptor array size mismatch; shader="
                                    + descriptor.descriptorCount()
                                    + " manifest="
                                    + boundCount);
                }
                if (pass.graphics()
                        && pass.geometry() != Geometry.CUSTOM
                        && (descriptor.stageFlags() & VK_SHADER_STAGE_VERTEX_BIT) != 0) {
                    throw new IllegalArgumentException(
                            (pass.geometry() == Geometry.FULLSCREEN
                                            ? "Fullscreen"
                                            : "Fluid geometry")
                                    + " vertex shader cannot access creator descriptors: "
                                    + pass.name());
                }

                for (String resourceName : binding.resources()) {
                    Resource resource = resources.get(resourceName);
                    if (resource == null)
                        throw new IllegalArgumentException("Missing resource " + resourceName);
                    if (binding.historyOffset() > 0
                            && (!resource.history()
                                    || binding.writes()
                                    || binding.historyOffset() >= resource.historyCount())) {
                        throw new IllegalArgumentException(
                                "Previous binding/history offset requires a valid read-only temporal resource: "
                                        + resource.name());
                    }
                    if (resource.hostImport() && binding.writes()) {
                        throw new IllegalArgumentException(
                                "Host import is read-only: " + resource.name());
                    }
                    validateSubresource(pass, descriptor, binding, resource);
                    VeilRenderGraph.Access access =
                            validateDescriptorResource(pass, descriptor, binding, resource);
                    String graphResource = binding.graphResource(resourceName);
                    List<BindingUse> previousUses =
                            aliases.computeIfAbsent(graphResource, ignored -> new ArrayList<>());
                    for (BindingUse previousUse : previousUses) {
                        if (resource.kind() == VeilRenderGraph.Kind.BUFFER
                                && (binding.access() == BindingAccess.READ
                                                && previousUse.binding().access()
                                                        == BindingAccess.READ
                                        || !subresourcesOverlap(
                                                previousUse.binding(), binding, resource)))
                            continue;
                        if (descriptor.descriptorType() == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                                && previousUse.descriptorType()
                                        == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                                && binding.access() == BindingAccess.READ
                                && previousUse.binding().access() == BindingAccess.READ) continue;
                        if ((resource.raySceneAsset() || resource.worldRayScene())
                                && binding.access() == BindingAccess.READ
                                && previousUse.binding().access() == BindingAccess.READ) continue;
                        if (descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_STORAGE_IMAGE
                                || previousUse.descriptorType() != VK_DESCRIPTOR_TYPE_STORAGE_IMAGE
                                || subresourcesOverlap(previousUse.binding(), binding, resource)) {
                            throw new IllegalArgumentException(
                                    "Resource alias overlaps or mixes descriptor classes in pass "
                                            + pass.name()
                                            + ": "
                                            + resource.name());
                        }
                    }
                    previousUses.add(
                            new BindingUse(descriptor.descriptorType(), binding, resource));
                    graphUses.add(
                            new VeilRenderGraph.Use(
                                    graphResource,
                                    access,
                                    graphSubresource(descriptor, binding, resource)));
                    if (previousUses.size() == 1
                            || descriptor.descriptorType()
                                            == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                                    && previousUses.stream()
                                            .allMatch(
                                                    use ->
                                                            use.descriptorType()
                                                                            == VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                                                                    && use.binding().access()
                                                                            == BindingAccess.READ)
                            || resource.raySceneAsset()
                            || resource.worldRayScene()) {
                        uses.put(graphResource, access);
                    } else {
                        uses.put(
                                graphResource,
                                resource.kind() == VeilRenderGraph.Kind.BUFFER
                                        ? pass.compute()
                                                ? VeilRenderGraph.Access.COMPUTE_READ_WRITE
                                                : pass.raytrace()
                                                        ? VeilRenderGraph.Access.RAY_READ_WRITE
                                                        : VeilRenderGraph.Access
                                                                .GRAPHICS_BUFFER_READ_WRITE
                                        : pass.compute()
                                                ? VeilRenderGraph.Access.COMPUTE_IMAGE_READ_WRITE
                                                : pass.raytrace()
                                                        ? VeilRenderGraph.Access
                                                                .RAY_IMAGE_READ_WRITE
                                                        : VeilRenderGraph.Access
                                                                .FRAGMENT_IMAGE_READ_WRITE);
                    }
                }
            }
            if (pass.compute() && pass.dispatch().dynamic()) {
                Resource dispatchResource = resources.get(pass.dispatch().resource());
                if (dispatchResource == null
                        || dispatchResource.kind() != VeilRenderGraph.Kind.IMAGE
                        || dispatchResource.source() != Source.OWNED) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": dispatch resource must be an owned image: "
                                    + pass.dispatch().resource());
                }
                if (pass.dispatch().mip() >= dispatchResource.mipLevels()) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": dispatch mip exceeds resource mip chain: "
                                    + pass.dispatch().resource()
                                    + " mip="
                                    + pass.dispatch().mip());
                }
            }
            if (pass.compute() && pass.dispatch().indirect()) {
                Resource indirect = resources.get(pass.dispatch().indirectResource());
                if (indirect == null
                        || indirect.kind() != VeilRenderGraph.Kind.BUFFER
                        || indirect.source() != Source.OWNED) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": indirect dispatch requires an owned buffer: "
                                    + pass.dispatch().indirectResource());
                }
                if (abiVersion >= 11 && !indirect.usages().contains(VeilResourceUsage.INDIRECT)) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": indirect dispatch buffer requires indirect usage: "
                                    + indirect.name());
                }
                if (pass.dispatch().indirectOffset() > indirect.bytes() - 12L) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": indirect dispatch requires 12 bytes at offset="
                                    + pass.dispatch().indirectOffset()
                                    + " in buffer "
                                    + indirect.name());
                }
                if (uses.putIfAbsent(indirect.name(), VeilRenderGraph.Access.INDIRECT_READ)
                        != null) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": an indirect argument buffer cannot also be bound as a descriptor in the same dispatch");
                }
                graphUses.add(
                        VeilRenderGraph.Use.whole(
                                indirect.name(), VeilRenderGraph.Access.INDIRECT_READ));
            }
            if (pass.raytrace() && pass.trace().dynamic()) {
                Resource traceResource = resources.get(pass.trace().resource());
                if (traceResource == null
                        || traceResource.kind() != VeilRenderGraph.Kind.IMAGE
                        || traceResource.source() != Source.OWNED) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": ray trace resource must be an owned image: "
                                    + pass.trace().resource());
                }
                if (pass.trace().mip() >= traceResource.mipLevels()) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": ray trace mip exceeds resource mip chain: "
                                    + pass.trace().resource());
                }
            }
            if (pass.graphics()) {
                validateDraws(pass, uses, graphUses);
                for (ColorAttachment attachment : pass.colors()) {
                    Resource target = resources.get(attachment.resource());
                    if (target == null
                            || !target.renderTarget()
                            || target.source() != Source.OWNED
                            || !target.format().color()) {
                        throw new IllegalArgumentException(
                                "Invalid 2D color attachment: " + attachment.resource());
                    }
                    validateAttachmentSubresource(target, attachment.mip(), attachment.layer());
                    if (attachment.clear() != null) {
                        dev.veil.revive.client.graphics.resources.AttachmentClearRules.validate(
                                target.format(), attachment.clear().colorType());
                    }
                    VeilRenderGraph.Access access =
                            attachment.load() == LoadOp.LOAD && abiVersion >= 11
                                    ? VeilRenderGraph.Access.COLOR_READ_WRITE
                                    : VeilRenderGraph.Access.COLOR_WRITE;
                    if (uses.putIfAbsent(target.name(), access) != null) {
                        throw new IllegalArgumentException(
                                "Attachment feedback or duplicate attachment is unsupported: "
                                        + pass.name());
                    }
                    graphUses.add(
                            new VeilRenderGraph.Use(
                                    target.name(),
                                    access,
                                    VeilRenderGraph.Subresource.image(
                                            attachment.mip(), 1, attachment.layer(), 1)));
                }
                if (pass.depth() != null) {
                    Resource depthTarget = resources.get(pass.depth().resource());
                    boolean validHost =
                            depthTarget != null
                                    && VeilHostResourceRegistry.SCENE_DEPTH.equals(
                                            depthTarget.hostId());
                    if (depthTarget == null
                            || depthTarget.kind() != VeilRenderGraph.Kind.IMAGE
                            || !validHost
                                    && (!depthTarget.depthTarget()
                                            || depthTarget.source() != Source.OWNED)) {
                        throw new IllegalArgumentException(
                                "Invalid depth attachment: " + pass.depth().resource());
                    }
                    if (validHost && pass.depth().write())
                        throw new IllegalArgumentException(
                                "Minecraft scene depth import is read-only");
                    if (pass.pipeline().stencil().enabled()
                            && (depthTarget.format() == null || !depthTarget.format().stencil())) {
                        throw new IllegalArgumentException(
                                "Stencil state requires a depth-stencil attachment: "
                                        + pass.name());
                    }
                    validateAttachmentSubresource(
                            depthTarget, pass.depth().mip(), pass.depth().layer());
                    VeilRenderGraph.Access access =
                            pass.depth().load() == LoadOp.LOAD
                                    ? pass.depth().access()
                                    : VeilRenderGraph.Access.DEPTH_WRITE;
                    if (uses.putIfAbsent(depthTarget.name(), access) != null) {
                        throw new IllegalArgumentException(
                                "Depth attachment is already used by another binding in pass "
                                        + pass.name());
                    }
                    graphUses.add(
                            new VeilRenderGraph.Use(
                                    depthTarget.name(),
                                    access,
                                    VeilRenderGraph.Subresource.image(
                                            pass.depth().mip(), 1, pass.depth().layer(), 1)));
                }
                if (pass.pipeline().stencil().enabled() && pass.depth() == null) {
                    throw new IllegalArgumentException(
                            "Stencil state requires a depth-stencil attachment: " + pass.name());
                }
            }
            graph.add(new VeilRenderGraph.Pass(pass.name(), uses, graphUses, pass.after()));
        }
        var ordered = VeilRenderGraph.compile(kinds, graph, initialized, readOnly);
        validateDiscardedAttachments(ordered);
        for (Resource resource : resources.values()) {
            if (resource.history()
                    && graph.stream()
                            .noneMatch(
                                    pass -> {
                                        VeilRenderGraph.Access access =
                                                pass.resources().get(resource.name());
                                        return access != null && access.writes();
                                    })) {
                throw new IllegalArgumentException(
                        "Temporal resource requires a producer: " + resource.name());
            }
        }
        if (present != null) {
            Resource output = resources.get(present);
            if (output == null
                    || !output.renderTarget()
                    || !output.sampled()
                    || !output.image2d()
                    || output.samples() != 1
                    || output.source() != Source.OWNED) {
                throw new IllegalArgumentException(
                        "Present output must reference an owned 2D color producer: " + present);
            }
            boolean hasColorProducer =
                    graph.stream()
                            .anyMatch(
                                    pass ->
                                            pass.resources().get(output.name())
                                                    == VeilRenderGraph.Access.COLOR_WRITE);
            if (!hasColorProducer) {
                throw new IllegalArgumentException(
                        "Present output requires a color producer: " + present);
            }
            VeilGraphicsPipeline.validateFullscreen(compiled.get(PRESENTER).shaderInterface(), 1);
        }
        return new Prepared(pack, compiled, ordered, imageAssets, bufferAssets);
    }

    private record BindingUse(int descriptorType, Binding binding, Resource resource) {}

    private VeilRenderGraph.Pass prepareScene(Pass pass) {
        return new dev.veil.revive.client.shaderpack.preparation.ScenePlanBuilder(resources)
                .prepare(pass);
    }

    private void validateDraws(
            Pass pass,
            Map<String, VeilRenderGraph.Access> uses,
            List<VeilRenderGraph.Use> graphUses) {
        new dev.veil.revive.client.shaderpack.preparation.DrawPlanValidator(resources)
                .validate(pass, uses, graphUses);
    }

    private VeilRenderGraph.Pass prepareTransfers(Pass pass) {
        return new dev.veil.revive.client.shaderpack.preparation.TransferPlanBuilder(resources)
                .prepare(pass);
    }

    private void validateFragmentFormats(Pass pass, VeilShaderInterface shaderInterface) {
        new dev.veil.revive.client.shaderpack.preparation.AttachmentValidator(
                        resources, passes, present)
                .validateFragmentFormats(pass, shaderInterface);
    }

    private void validateDiscardedAttachments(List<VeilRenderGraph.Pass> ordered) {
        new dev.veil.revive.client.shaderpack.preparation.AttachmentValidator(
                        resources, passes, present)
                .validateDiscardedAttachments(ordered);
    }

    static VeilShaderInterface pipelineInterface(Pass pass, VeilShaderInterface shaderInterface) {
        return BindingValidator.pipelineInterface(pass, shaderInterface);
    }

    private static VeilRenderGraph.Access validateDescriptorResource(
            Pass pass,
            VeilShaderInterface.Descriptor descriptor,
            Binding binding,
            Resource resource) {
        return BindingValidator.validateDescriptorResource(
                pass,
                descriptor,
                binding,
                resource,
                id -> VeilHostResourceRegistry.definition(id).bytes(),
                VeilHostResourceRegistry.BLOCK_ATLAS::equals);
    }
}
