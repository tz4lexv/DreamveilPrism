package dev.veil.revive.client.diagnostics;

import java.util.Arrays;
import java.util.List;

public record DistributionStats(
        int count,
        double avg,
        double p50,
        double p90,
        double p95,
        double p99,
        double min,
        double max,
        double stdDev,
        double mad) {

    public static DistributionStats of(List<Double> input) {
        if (input.isEmpty()) return new DistributionStats(0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        double[] a = new double[input.size()];
        double sum = 0.0;
        for (int i = 0; i < a.length; i++) {
            a[i] = input.get(i);
            sum += a[i];
        }
        Arrays.sort(a);
        double avg = sum / a.length;
        double variance = 0.0;
        for (double value : a) {
            double d = value - avg;
            variance += d * d;
        }
        variance /= a.length;
        double median = percentile(a, .50);
        double[] deviations = new double[a.length];
        for (int i = 0; i < a.length; i++) deviations[i] = Math.abs(a[i] - median);
        Arrays.sort(deviations);
        return new DistributionStats(
                a.length,
                avg,
                median,
                percentile(a, .90),
                percentile(a, .95),
                percentile(a, .99),
                a[0],
                a[a.length - 1],
                Math.sqrt(variance),
                percentile(deviations, .50));
    }

    private static double percentile(double[] a, double q) {
        if (a.length == 1) return a[0];
        double idx = q * (a.length - 1);
        int lo = (int) Math.floor(idx);
        int hi = Math.min(a.length - 1, lo + 1);
        double f = idx - lo;
        return a[lo] * (1.0 - f) + a[hi] * f;
    }
}
