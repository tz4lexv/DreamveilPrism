package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.particle.ParticleEngine;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleEngine.class)
public abstract class ParticleEngineFullTelemetryMixin {
    @Inject(method = "extract", at = @At("HEAD"), require = 0)
    private void veil$particleExtractStart(CallbackInfo ci) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.PARTICLE_EXTRACT);
    }

    @Inject(method = "extract", at = @At("RETURN"), require = 0)
    private void veil$particleExtractEnd(CallbackInfo ci) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.PARTICLE_EXTRACT);
    }
}
