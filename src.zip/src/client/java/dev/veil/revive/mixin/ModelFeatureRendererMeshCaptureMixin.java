package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilEntityMeshCapture;

import net.minecraft.client.renderer.feature.ModelFeatureRenderer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ModelFeatureRenderer.class)
public abstract class ModelFeatureRendererMeshCaptureMixin {
    @Inject(method = "prepareModel", at = @At("HEAD"), require = 1)
    private <S> void veil$beginExactMesh(ModelFeatureRenderer.Submit<S> submit, CallbackInfo ci) {
        VeilEntityMeshCapture.beginModel(submit.state());
    }

    @Inject(method = "prepareModel", at = @At("RETURN"), require = 1)
    private <S> void veil$endExactMesh(ModelFeatureRenderer.Submit<S> submit, CallbackInfo ci) {
        VeilEntityMeshCapture.endModel();
    }
}
