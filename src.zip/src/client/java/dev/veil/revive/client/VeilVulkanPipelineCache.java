package dev.veil.revive.client;

import dev.veil.revive.client.graphics.pipelines.PersistentPipelineCache;

import net.minecraft.client.Minecraft;

final class VeilVulkanPipelineCache {
    private static final PersistentPipelineCache CACHE =
            new PersistentPipelineCache(() -> Minecraft.getInstance().gameDirectory.toPath());

    private VeilVulkanPipelineCache() {}

    static long handle(VeilVulkanRuntime runtime) {
        return CACHE.handle(runtime);
    }

    static String telemetry() {
        return CACHE.telemetry();
    }

    static void close() {
        CACHE.close();
    }
}
