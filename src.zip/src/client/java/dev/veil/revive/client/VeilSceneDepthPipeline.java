package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.resources.Identifier;

import java.util.Optional;

final class VeilSceneDepthPipeline {
    private static RenderPipeline pipeline;
    private static Object checkedDevice;
    private static boolean valid;

    private VeilSceneDepthPipeline() {}

    static RenderPipeline opaque() {
        RenderSystem.assertOnRenderThread();
        if (!Boolean.parseBoolean(System.getProperty("veil.sceneDepthOnlyTerrain", "true")))
            return null;
        if (pipeline == null) {
            var original = ChunkSectionLayer.SOLID.pipeline();
            pipeline =
                    RenderPipelines.register(
                            RenderPipeline.builder()
                                    .withLocation(
                                            Identifier.fromNamespaceAndPath(
                                                    "veil", "pipeline/scene_opaque_depth"))
                                    .withVertexShader(
                                            Identifier.fromNamespaceAndPath(
                                                    "veil", "core/scene_opaque_depth"))
                                    .withFragmentShader(
                                            Identifier.fromNamespaceAndPath(
                                                    "veil", "core/depth_only"))
                                    .withBindGroupLayout(BindGroupLayouts.GLOBALS)
                                    .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                                    .withBindGroupLayout(BindGroupLayouts.CHUNK_SECTION)
                                    .withVertexBinding(0, original.getVertexFormatBinding(0))
                                    .withPrimitiveTopology(original.getPrimitiveTopology())
                                    .withDepthStencilState(original.getDepthStencilState())
                                    .withCull(original.isCull())
                                    .withColorTargetState(
                                            new ColorTargetState(
                                                    Optional.empty(),
                                                    GpuFormat.RGBA8_UNORM,
                                                    ColorTargetState.WRITE_NONE))
                                    .build());
        }
        var device = RenderSystem.getDevice();
        if (checkedDevice != device) {
            checkedDevice = device;
            try {
                valid = device.precompilePipeline(pipeline).isValid();
            } catch (RuntimeException failure) {
                valid = false;
                dev.veil.revive.ReviveMod.LOGGER.warn(
                        "Veil scene depth pipeline unavailable; keeping terrain pipeline", failure);
            }
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil scene opaque depth pipeline: {}", valid ? "ACTIVE" : "FALLBACK");
        }
        return valid ? pipeline : null;
    }
}
