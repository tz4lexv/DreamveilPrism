package dev.veil.revive.client.graphics.minecraft;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.api.VeilScenePass;

import org.lwjgl.vulkan.VkPipelineRasterizationStateCreateInfo;

public final class SceneRasterRules {
    private SceneRasterRules() {}

    public static void validate(
            VeilScenePass.Raster raster, boolean depthClamp, boolean biasClamp) {
        if (Boolean.TRUE.equals(raster.depthClamp()) && !depthClamp)
            throw new IllegalArgumentException("Scene raster requires enabled depthClamp");
        if (raster.depthBiasClamp() != null && raster.depthBiasClamp() != 0f && !biasClamp)
            throw new IllegalArgumentException("Scene raster requires enabled depthBiasClamp");
    }

    public static void apply(
            VeilScenePass.Raster raster, VkPipelineRasterizationStateCreateInfo state) {
        if (raster.depthBiasConstant() != null)
            state.depthBiasConstantFactor(raster.depthBiasConstant());
        if (raster.depthBiasSlope() != null) state.depthBiasSlopeFactor(raster.depthBiasSlope());
        if (raster.depthBiasClamp() != null) state.depthBiasClamp(raster.depthBiasClamp());
        if (raster.depthClamp() != null) state.depthClampEnable(raster.depthClamp());
        if (raster.depthBias() != null) state.depthBiasEnable(raster.depthBias());
        else if (raster.depthBiasConstant() != null || raster.depthBiasSlope() != null)
            state.depthBiasEnable(
                    state.depthBiasConstantFactor() != 0f || state.depthBiasSlopeFactor() != 0f);
        if (raster.cullMode() != null)
            state.cullMode(
                    switch (raster.cullMode()) {
                        case NONE -> VK_CULL_MODE_NONE;
                        case FRONT -> VK_CULL_MODE_FRONT_BIT;
                        case BACK -> VK_CULL_MODE_BACK_BIT;
                        case FRONT_AND_BACK -> VK_CULL_MODE_FRONT_AND_BACK;
                    });
        if (raster.frontFace() != null)
            state.frontFace(
                    raster.frontFace() == VeilScenePass.FrontFace.CLOCKWISE
                            ? VK_FRONT_FACE_CLOCKWISE
                            : VK_FRONT_FACE_COUNTER_CLOCKWISE);
    }
}
