package dev.veil.revive.client;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

public final class VeilTechniqueCounters {
    private static volatile boolean COLLECTING;
    private static final LongAdder TERRAIN_PREPARE_CALLS = new LongAdder();
    private static final LongAdder TERRAIN_PREPARE_SUCCESSES = new LongAdder();
    private static final LongAdder TERRAIN_RETURN_OVERRIDES = new LongAdder();
    private static final LongAdder TERRAIN_BYPASS_SKIPS = new LongAdder();
    private static final LongAdder TERRAIN_CACHE_DISABLED_SKIPS = new LongAdder();
    private static final LongAdder TERRAIN_NO_DISPATCHER_SKIPS = new LongAdder();
    private static final LongAdder TERRAIN_CACHE_REUSES = new LongAdder();
    private static final LongAdder TERRAIN_CACHE_REBUILDS = new LongAdder();
    private static final LongAdder TERRAIN_CACHE_INVALIDATIONS = new LongAdder();
    private static final LongAdder CACHE_MISS_EMPTY = new LongAdder();
    private static final LongAdder CACHE_MISS_DISPATCHER = new LongAdder();
    private static final LongAdder CACHE_MISS_SIGNATURE = new LongAdder();
    private static final LongAdder CACHE_MISS_PACKET_COUNT = new LongAdder();
    private static final LongAdder TERRAIN_BRIDGE_FALLBACKS = new LongAdder();
    private static final LongAdder TERRAIN_VISIBLE_SECTION_SAMPLES = new LongAdder();
    private static final LongAdder TERRAIN_VISIBLE_SECTIONS_TOTAL = new LongAdder();
    private static final LongAdder TERRAIN_SECTIONS_SCANNED = new LongAdder();
    private static final LongAdder TERRAIN_DRAW_PACKETS_VALIDATED = new LongAdder();
    private static final LongAdder TERRAIN_DRAW_PACKETS_REBUILT = new LongAdder();
    private static final LongAdder TERRAIN_GROUPS_BUILT = new LongAdder();
    private static final LongAdder TERRAIN_DYNAMIC_UBOS_WRITTEN = new LongAdder();

    private static final LongAdder TERRAIN_PREPARE_NS = new LongAdder();
    private static final LongAdder TERRAIN_UPLOAD_NS = new LongAdder();
    private static final LongAdder TERRAIN_VALIDATE_NS = new LongAdder();
    private static final LongAdder TERRAIN_REBUILD_NS = new LongAdder();
    private static final LongAdder TERRAIN_UBO_WRITE_NS = new LongAdder();

    private static final LongAdder VERTEX_BIND_CALLS = new LongAdder();
    private static final LongAdder INDEX_BIND_CALLS = new LongAdder();
    private static final LongAdder SKIPPED_VERTEX_BINDS = new LongAdder();
    private static final LongAdder SKIPPED_INDEX_BINDS = new LongAdder();

    private static final LongAdder FAR_ANALYSIS_REQUESTS = new LongAdder();
    private static final LongAdder FAR_ANALYSIS_RUNS = new LongAdder();
    private static final LongAdder FAR_ANALYSIS_CADENCE_SKIPS = new LongAdder();
    private static final LongAdder FAR_SECTIONS_ANALYZED = new LongAdder();
    private static final LongAdder FAR_EXACT_CANDIDATES = new LongAdder();
    private static final LongAdder FAR_SSE_CANDIDATES = new LongAdder();
    private static final LongAdder FAR_VOXEL_CANDIDATES = new LongAdder();
    private static final LongAdder FAR_VASC_CANDIDATES = new LongAdder();
    private static final LongAdder FAR_DIRTY_FALLBACKS = new LongAdder();
    private static final LongAdder FAR_TRANSLUCENT_FALLBACKS = new LongAdder();
    private static final LongAdder FAR_ANALYSIS_NS = new LongAdder();

    private static final LongAdder SECTION_DIRTY_EVENTS = new LongAdder();
    private static final LongAdder SECTION_MESH_UPDATE_EVENTS = new LongAdder();
    private static final LongAdder GLOBAL_INVALIDATIONS = new LongAdder();

    private static final AtomicLong MAX_VISIBLE_SECTIONS = new AtomicLong();
    private static final AtomicLong MAX_DRAW_PACKETS = new AtomicLong();
    private static final AtomicLong MAX_GROUPS = new AtomicLong();

    private VeilTechniqueCounters() {}

    public static void setCollecting(boolean collecting) {
        COLLECTING = collecting;
    }

    public static boolean collecting() {
        return COLLECTING;
    }

    private static boolean active() {
        return COLLECTING;
    }

    public static void terrainPrepareCall() {
        if (!active()) return;
        TERRAIN_PREPARE_CALLS.increment();
    }

    public static void terrainPrepareSuccess() {
        if (!active()) return;
        TERRAIN_PREPARE_SUCCESSES.increment();
    }

    public static void terrainReturnOverride() {
        if (!active()) return;
        TERRAIN_RETURN_OVERRIDES.increment();
    }

    public static void terrainBypassSkip() {
        if (!active()) return;
        TERRAIN_BYPASS_SKIPS.increment();
    }

    public static void terrainCacheDisabledSkip() {
        if (!active()) return;
        TERRAIN_CACHE_DISABLED_SKIPS.increment();
    }

    public static void terrainNoDispatcherSkip() {
        if (!active()) return;
        TERRAIN_NO_DISPATCHER_SKIPS.increment();
    }

    public static void terrainCacheReuse() {
        if (!active()) return;
        TERRAIN_CACHE_REUSES.increment();
    }

    public static void terrainCacheRebuild() {
        if (!active()) return;
        TERRAIN_CACHE_REBUILDS.increment();
    }

    public static void terrainCacheInvalidation() {
        if (!active()) return;
        TERRAIN_CACHE_INVALIDATIONS.increment();
    }

    public static void cacheMissEmpty() {
        if (!active()) return;
        CACHE_MISS_EMPTY.increment();
    }

    public static void cacheMissDispatcher() {
        if (!active()) return;
        CACHE_MISS_DISPATCHER.increment();
    }

    public static void cacheMissSignature() {
        if (!active()) return;
        CACHE_MISS_SIGNATURE.increment();
    }

    public static void cacheMissPacketCount() {
        if (!active()) return;
        CACHE_MISS_PACKET_COUNT.increment();
    }

    public static void terrainBridgeFallback() {
        if (!active()) return;
        TERRAIN_BRIDGE_FALLBACKS.increment();
    }

    public static void terrainVisibleSectionsObserved(long count) {
        if (!active()) return;
        TERRAIN_VISIBLE_SECTION_SAMPLES.increment();
        add(TERRAIN_VISIBLE_SECTIONS_TOTAL, count);
        max(MAX_VISIBLE_SECTIONS, count);
    }

    public static void terrainSectionsScanned(long count) {
        if (!active()) return;
        add(TERRAIN_SECTIONS_SCANNED, count);
    }

    public static void terrainDrawPacketsValidated(long count) {
        if (!active()) return;
        add(TERRAIN_DRAW_PACKETS_VALIDATED, count);
        max(MAX_DRAW_PACKETS, count);
    }

    public static void terrainDrawPacketsRebuilt(long count) {
        if (!active()) return;
        add(TERRAIN_DRAW_PACKETS_REBUILT, count);
        max(MAX_DRAW_PACKETS, count);
    }

    public static void terrainGroupsBuilt(long count) {
        if (!active()) return;
        add(TERRAIN_GROUPS_BUILT, count);
        max(MAX_GROUPS, count);
    }

    public static void terrainDynamicUbosWritten(long count) {
        if (!active()) return;
        add(TERRAIN_DYNAMIC_UBOS_WRITTEN, count);
    }

    public static void terrainPrepareNanos(long ns) {
        if (!active()) return;
        add(TERRAIN_PREPARE_NS, ns);
    }

    public static void terrainUploadNanos(long ns) {
        if (!active()) return;
        add(TERRAIN_UPLOAD_NS, ns);
    }

    public static void terrainValidateNanos(long ns) {
        if (!active()) return;
        add(TERRAIN_VALIDATE_NS, ns);
    }

    public static void terrainRebuildNanos(long ns) {
        if (!active()) return;
        add(TERRAIN_REBUILD_NS, ns);
    }

    public static void terrainUboWriteNanos(long ns) {
        if (!active()) return;
        add(TERRAIN_UBO_WRITE_NS, ns);
    }

    public static void vertexBindCall() {
        if (!active()) return;
        VERTEX_BIND_CALLS.increment();
    }

    public static void indexBindCall() {
        if (!active()) return;
        INDEX_BIND_CALLS.increment();
    }

    public static void skippedVertexBind() {
        if (!active()) return;
        SKIPPED_VERTEX_BINDS.increment();
    }

    public static void skippedIndexBind() {
        if (!active()) return;
        SKIPPED_INDEX_BINDS.increment();
    }

    public static void farAnalysisRequest() {
        if (!active()) return;
        FAR_ANALYSIS_REQUESTS.increment();
    }

    public static void farAnalysisRun() {
        if (!active()) return;
        FAR_ANALYSIS_RUNS.increment();
    }

    public static void farAnalysisCadenceSkip() {
        if (!active()) return;
        FAR_ANALYSIS_CADENCE_SKIPS.increment();
    }

    public static void farSectionsAnalyzed(long count) {
        if (!active()) return;
        add(FAR_SECTIONS_ANALYZED, count);
    }

    public static void farExactCandidates(long count) {
        if (!active()) return;
        add(FAR_EXACT_CANDIDATES, count);
    }

    public static void farSseCandidates(long count) {
        if (!active()) return;
        add(FAR_SSE_CANDIDATES, count);
    }

    public static void farVoxelCandidates(long count) {
        if (!active()) return;
        add(FAR_VOXEL_CANDIDATES, count);
    }

    public static void farVascCandidates(long count) {
        if (!active()) return;
        add(FAR_VASC_CANDIDATES, count);
    }

    public static void farDirtyFallbacks(long count) {
        if (!active()) return;
        add(FAR_DIRTY_FALLBACKS, count);
    }

    public static void farTranslucentFallbacks(long count) {
        if (!active()) return;
        add(FAR_TRANSLUCENT_FALLBACKS, count);
    }

    public static void farAnalysisNanos(long ns) {
        if (!active()) return;
        add(FAR_ANALYSIS_NS, ns);
    }

    public static void sectionDirtyEvent() {
        if (!active()) return;
        SECTION_DIRTY_EVENTS.increment();
    }

    public static void sectionMeshUpdateEvent() {
        if (!active()) return;
        SECTION_MESH_UPDATE_EVENTS.increment();
    }

    public static void globalInvalidation() {
        if (!active()) return;
        GLOBAL_INVALIDATIONS.increment();
    }

    public static void reset() {
        TERRAIN_PREPARE_CALLS.reset();
        TERRAIN_PREPARE_SUCCESSES.reset();
        TERRAIN_RETURN_OVERRIDES.reset();
        TERRAIN_BYPASS_SKIPS.reset();
        TERRAIN_CACHE_DISABLED_SKIPS.reset();
        TERRAIN_NO_DISPATCHER_SKIPS.reset();
        TERRAIN_CACHE_REUSES.reset();
        TERRAIN_CACHE_REBUILDS.reset();
        TERRAIN_CACHE_INVALIDATIONS.reset();
        CACHE_MISS_EMPTY.reset();
        CACHE_MISS_DISPATCHER.reset();
        CACHE_MISS_SIGNATURE.reset();
        CACHE_MISS_PACKET_COUNT.reset();
        TERRAIN_BRIDGE_FALLBACKS.reset();
        TERRAIN_VISIBLE_SECTION_SAMPLES.reset();
        TERRAIN_VISIBLE_SECTIONS_TOTAL.reset();
        TERRAIN_SECTIONS_SCANNED.reset();
        TERRAIN_DRAW_PACKETS_VALIDATED.reset();
        TERRAIN_DRAW_PACKETS_REBUILT.reset();
        TERRAIN_GROUPS_BUILT.reset();
        TERRAIN_DYNAMIC_UBOS_WRITTEN.reset();
        TERRAIN_PREPARE_NS.reset();
        TERRAIN_UPLOAD_NS.reset();
        TERRAIN_VALIDATE_NS.reset();
        TERRAIN_REBUILD_NS.reset();
        TERRAIN_UBO_WRITE_NS.reset();
        VERTEX_BIND_CALLS.reset();
        INDEX_BIND_CALLS.reset();
        SKIPPED_VERTEX_BINDS.reset();
        SKIPPED_INDEX_BINDS.reset();
        FAR_ANALYSIS_REQUESTS.reset();
        FAR_ANALYSIS_RUNS.reset();
        FAR_ANALYSIS_CADENCE_SKIPS.reset();
        FAR_SECTIONS_ANALYZED.reset();
        FAR_EXACT_CANDIDATES.reset();
        FAR_SSE_CANDIDATES.reset();
        FAR_VOXEL_CANDIDATES.reset();
        FAR_VASC_CANDIDATES.reset();
        FAR_DIRTY_FALLBACKS.reset();
        FAR_TRANSLUCENT_FALLBACKS.reset();
        FAR_ANALYSIS_NS.reset();
        SECTION_DIRTY_EVENTS.reset();
        SECTION_MESH_UPDATE_EVENTS.reset();
        GLOBAL_INVALIDATIONS.reset();
        MAX_VISIBLE_SECTIONS.set(0L);
        MAX_DRAW_PACKETS.set(0L);
        MAX_GROUPS.set(0L);
    }

    public static Snapshot snapshot() {
        return new Snapshot(
                TERRAIN_PREPARE_CALLS.sum(),
                TERRAIN_PREPARE_SUCCESSES.sum(),
                TERRAIN_RETURN_OVERRIDES.sum(),
                TERRAIN_BYPASS_SKIPS.sum(),
                TERRAIN_CACHE_DISABLED_SKIPS.sum(),
                TERRAIN_NO_DISPATCHER_SKIPS.sum(),
                TERRAIN_CACHE_REUSES.sum(),
                TERRAIN_CACHE_REBUILDS.sum(),
                TERRAIN_CACHE_INVALIDATIONS.sum(),
                CACHE_MISS_EMPTY.sum(),
                CACHE_MISS_DISPATCHER.sum(),
                CACHE_MISS_SIGNATURE.sum(),
                CACHE_MISS_PACKET_COUNT.sum(),
                TERRAIN_BRIDGE_FALLBACKS.sum(),
                TERRAIN_VISIBLE_SECTION_SAMPLES.sum(),
                TERRAIN_VISIBLE_SECTIONS_TOTAL.sum(),
                TERRAIN_SECTIONS_SCANNED.sum(),
                TERRAIN_DRAW_PACKETS_VALIDATED.sum(),
                TERRAIN_DRAW_PACKETS_REBUILT.sum(),
                TERRAIN_GROUPS_BUILT.sum(),
                TERRAIN_DYNAMIC_UBOS_WRITTEN.sum(),
                TERRAIN_PREPARE_NS.sum(),
                TERRAIN_UPLOAD_NS.sum(),
                TERRAIN_VALIDATE_NS.sum(),
                TERRAIN_REBUILD_NS.sum(),
                TERRAIN_UBO_WRITE_NS.sum(),
                VERTEX_BIND_CALLS.sum(),
                INDEX_BIND_CALLS.sum(),
                SKIPPED_VERTEX_BINDS.sum(),
                SKIPPED_INDEX_BINDS.sum(),
                FAR_ANALYSIS_REQUESTS.sum(),
                FAR_ANALYSIS_RUNS.sum(),
                FAR_ANALYSIS_CADENCE_SKIPS.sum(),
                FAR_SECTIONS_ANALYZED.sum(),
                FAR_EXACT_CANDIDATES.sum(),
                FAR_SSE_CANDIDATES.sum(),
                FAR_VOXEL_CANDIDATES.sum(),
                FAR_VASC_CANDIDATES.sum(),
                FAR_DIRTY_FALLBACKS.sum(),
                FAR_TRANSLUCENT_FALLBACKS.sum(),
                FAR_ANALYSIS_NS.sum(),
                SECTION_DIRTY_EVENTS.sum(),
                SECTION_MESH_UPDATE_EVENTS.sum(),
                GLOBAL_INVALIDATIONS.sum(),
                MAX_VISIBLE_SECTIONS.get(),
                MAX_DRAW_PACKETS.get(),
                MAX_GROUPS.get());
    }

    private static void add(LongAdder adder, long value) {
        if (value > 0L) adder.add(value);
    }

    private static void max(AtomicLong target, long value) {
        long current = target.get();
        while (value > current && !target.compareAndSet(current, value)) current = target.get();
    }

    public record Snapshot(
            long terrainPrepareCalls,
            long terrainPrepareSuccesses,
            long terrainReturnOverrides,
            long terrainBypassSkips,
            long terrainCacheDisabledSkips,
            long terrainNoDispatcherSkips,
            long terrainCacheReuses,
            long terrainCacheRebuilds,
            long terrainCacheInvalidations,
            long cacheMissEmpty,
            long cacheMissDispatcher,
            long cacheMissSignature,
            long cacheMissPacketCount,
            long terrainBridgeFallbacks,
            long terrainVisibleSectionSamples,
            long terrainVisibleSectionsTotal,
            long terrainSectionsScanned,
            long terrainDrawPacketsValidated,
            long terrainDrawPacketsRebuilt,
            long terrainGroupsBuilt,
            long terrainDynamicUbosWritten,
            long terrainPrepareNs,
            long terrainUploadNs,
            long terrainValidateNs,
            long terrainRebuildNs,
            long terrainUboWriteNs,
            long vertexBindCalls,
            long indexBindCalls,
            long skippedVertexBinds,
            long skippedIndexBinds,
            long farAnalysisRequests,
            long farAnalysisRuns,
            long farAnalysisCadenceSkips,
            long farSectionsAnalyzed,
            long farExactCandidates,
            long farSseCandidates,
            long farVoxelCandidates,
            long farVascCandidates,
            long farDirtyFallbacks,
            long farTranslucentFallbacks,
            long farAnalysisNs,
            long sectionDirtyEvents,
            long sectionMeshUpdateEvents,
            long globalInvalidations,
            long maxVisibleSections,
            long maxDrawPackets,
            long maxGroups) {

        public Snapshot minus(Snapshot before) {
            return new Snapshot(
                    terrainPrepareCalls - before.terrainPrepareCalls,
                    terrainPrepareSuccesses - before.terrainPrepareSuccesses,
                    terrainReturnOverrides - before.terrainReturnOverrides,
                    terrainBypassSkips - before.terrainBypassSkips,
                    terrainCacheDisabledSkips - before.terrainCacheDisabledSkips,
                    terrainNoDispatcherSkips - before.terrainNoDispatcherSkips,
                    terrainCacheReuses - before.terrainCacheReuses,
                    terrainCacheRebuilds - before.terrainCacheRebuilds,
                    terrainCacheInvalidations - before.terrainCacheInvalidations,
                    cacheMissEmpty - before.cacheMissEmpty,
                    cacheMissDispatcher - before.cacheMissDispatcher,
                    cacheMissSignature - before.cacheMissSignature,
                    cacheMissPacketCount - before.cacheMissPacketCount,
                    terrainBridgeFallbacks - before.terrainBridgeFallbacks,
                    terrainVisibleSectionSamples - before.terrainVisibleSectionSamples,
                    terrainVisibleSectionsTotal - before.terrainVisibleSectionsTotal,
                    terrainSectionsScanned - before.terrainSectionsScanned,
                    terrainDrawPacketsValidated - before.terrainDrawPacketsValidated,
                    terrainDrawPacketsRebuilt - before.terrainDrawPacketsRebuilt,
                    terrainGroupsBuilt - before.terrainGroupsBuilt,
                    terrainDynamicUbosWritten - before.terrainDynamicUbosWritten,
                    terrainPrepareNs - before.terrainPrepareNs,
                    terrainUploadNs - before.terrainUploadNs,
                    terrainValidateNs - before.terrainValidateNs,
                    terrainRebuildNs - before.terrainRebuildNs,
                    terrainUboWriteNs - before.terrainUboWriteNs,
                    vertexBindCalls - before.vertexBindCalls,
                    indexBindCalls - before.indexBindCalls,
                    skippedVertexBinds - before.skippedVertexBinds,
                    skippedIndexBinds - before.skippedIndexBinds,
                    farAnalysisRequests - before.farAnalysisRequests,
                    farAnalysisRuns - before.farAnalysisRuns,
                    farAnalysisCadenceSkips - before.farAnalysisCadenceSkips,
                    farSectionsAnalyzed - before.farSectionsAnalyzed,
                    farExactCandidates - before.farExactCandidates,
                    farSseCandidates - before.farSseCandidates,
                    farVoxelCandidates - before.farVoxelCandidates,
                    farVascCandidates - before.farVascCandidates,
                    farDirtyFallbacks - before.farDirtyFallbacks,
                    farTranslucentFallbacks - before.farTranslucentFallbacks,
                    farAnalysisNs - before.farAnalysisNs,
                    sectionDirtyEvents - before.sectionDirtyEvents,
                    sectionMeshUpdateEvents - before.sectionMeshUpdateEvents,
                    globalInvalidations - before.globalInvalidations,
                    Math.max(maxVisibleSections, before.maxVisibleSections),
                    Math.max(maxDrawPackets, before.maxDrawPackets),
                    Math.max(maxGroups, before.maxGroups));
        }

        public Snapshot plus(Snapshot other) {
            return new Snapshot(
                    terrainPrepareCalls + other.terrainPrepareCalls,
                    terrainPrepareSuccesses + other.terrainPrepareSuccesses,
                    terrainReturnOverrides + other.terrainReturnOverrides,
                    terrainBypassSkips + other.terrainBypassSkips,
                    terrainCacheDisabledSkips + other.terrainCacheDisabledSkips,
                    terrainNoDispatcherSkips + other.terrainNoDispatcherSkips,
                    terrainCacheReuses + other.terrainCacheReuses,
                    terrainCacheRebuilds + other.terrainCacheRebuilds,
                    terrainCacheInvalidations + other.terrainCacheInvalidations,
                    cacheMissEmpty + other.cacheMissEmpty,
                    cacheMissDispatcher + other.cacheMissDispatcher,
                    cacheMissSignature + other.cacheMissSignature,
                    cacheMissPacketCount + other.cacheMissPacketCount,
                    terrainBridgeFallbacks + other.terrainBridgeFallbacks,
                    terrainVisibleSectionSamples + other.terrainVisibleSectionSamples,
                    terrainVisibleSectionsTotal + other.terrainVisibleSectionsTotal,
                    terrainSectionsScanned + other.terrainSectionsScanned,
                    terrainDrawPacketsValidated + other.terrainDrawPacketsValidated,
                    terrainDrawPacketsRebuilt + other.terrainDrawPacketsRebuilt,
                    terrainGroupsBuilt + other.terrainGroupsBuilt,
                    terrainDynamicUbosWritten + other.terrainDynamicUbosWritten,
                    terrainPrepareNs + other.terrainPrepareNs,
                    terrainUploadNs + other.terrainUploadNs,
                    terrainValidateNs + other.terrainValidateNs,
                    terrainRebuildNs + other.terrainRebuildNs,
                    terrainUboWriteNs + other.terrainUboWriteNs,
                    vertexBindCalls + other.vertexBindCalls,
                    indexBindCalls + other.indexBindCalls,
                    skippedVertexBinds + other.skippedVertexBinds,
                    skippedIndexBinds + other.skippedIndexBinds,
                    farAnalysisRequests + other.farAnalysisRequests,
                    farAnalysisRuns + other.farAnalysisRuns,
                    farAnalysisCadenceSkips + other.farAnalysisCadenceSkips,
                    farSectionsAnalyzed + other.farSectionsAnalyzed,
                    farExactCandidates + other.farExactCandidates,
                    farSseCandidates + other.farSseCandidates,
                    farVoxelCandidates + other.farVoxelCandidates,
                    farVascCandidates + other.farVascCandidates,
                    farDirtyFallbacks + other.farDirtyFallbacks,
                    farTranslucentFallbacks + other.farTranslucentFallbacks,
                    farAnalysisNs + other.farAnalysisNs,
                    sectionDirtyEvents + other.sectionDirtyEvents,
                    sectionMeshUpdateEvents + other.sectionMeshUpdateEvents,
                    globalInvalidations + other.globalInvalidations,
                    Math.max(maxVisibleSections, other.maxVisibleSections),
                    Math.max(maxDrawPackets, other.maxDrawPackets),
                    Math.max(maxGroups, other.maxGroups));
        }

        public long forwardedVertexBinds() {
            return Math.max(0L, vertexBindCalls - skippedVertexBinds);
        }

        public long forwardedIndexBinds() {
            return Math.max(0L, indexBindCalls - skippedIndexBinds);
        }

        public double vertexElisionRate() {
            return ratio(skippedVertexBinds, vertexBindCalls);
        }

        public double indexElisionRate() {
            return ratio(skippedIndexBinds, indexBindCalls);
        }

        public double terrainSuccessRate() {
            return ratio(terrainPrepareSuccesses, terrainPrepareCalls);
        }

        public double averageVisibleSections() {
            return terrainVisibleSectionSamples == 0L
                    ? 0.0
                    : (double) terrainVisibleSectionsTotal / terrainVisibleSectionSamples;
        }

        public double cacheHitRate() {
            long total = terrainCacheReuses + terrainCacheRebuilds;
            return ratio(terrainCacheReuses, total);
        }

        public double avgPrepareMs() {
            return averageMs(terrainPrepareNs, terrainPrepareCalls);
        }

        public double avgValidateMs() {
            return averageMs(terrainValidateNs, terrainPrepareSuccesses);
        }

        public double avgUploadMs() {
            return averageMs(terrainUploadNs, terrainPrepareSuccesses);
        }

        public double avgRebuildMs() {
            return averageMs(terrainRebuildNs, terrainCacheRebuilds);
        }

        public double avgUboWriteMs() {
            return averageMs(terrainUboWriteNs, terrainPrepareSuccesses);
        }

        public double avgFarAnalysisMs() {
            return averageMs(farAnalysisNs, farAnalysisRuns);
        }

        private static double ratio(long numerator, long denominator) {
            return denominator <= 0L ? 0.0 : (double) numerator / (double) denominator;
        }

        private static double averageMs(long nanos, long count) {
            return count <= 0L ? 0.0 : (nanos / 1_000_000.0) / (double) count;
        }
    }
}
