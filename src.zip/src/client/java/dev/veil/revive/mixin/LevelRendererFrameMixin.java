package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.client.renderer.LevelRenderer")
public abstract class LevelRendererFrameMixin {
    @Inject(
            method =
                    "render(Lcom/mojang/blaze3d/resource/GraphicsResourceAllocator;Lnet/minecraft/client/DeltaTracker;ZLnet/minecraft/client/renderer/state/level/CameraRenderState;Lorg/joml/Matrix4fc;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V",
            at = @At("HEAD"),
            require = 1)
    private void revive$frameStart(CallbackInfo ci) {
        dev.veil.revive.client.VeilMaterialHost.beginFrame();
        ReviveRuntime.onWorldRenderStart();
    }

    @Inject(
            method =
                    "render(Lcom/mojang/blaze3d/resource/GraphicsResourceAllocator;Lnet/minecraft/client/DeltaTracker;ZLnet/minecraft/client/renderer/state/level/CameraRenderState;Lorg/joml/Matrix4fc;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;Lorg/joml/Vector4f;Z)V",
            at = @At("RETURN"),
            require = 1)
    private void revive$frameEnd(CallbackInfo ci) {
        dev.veil.revive.client.VeilShaderService.executeScene();
        ReviveRuntime.onWorldRenderEnd();
    }
}
