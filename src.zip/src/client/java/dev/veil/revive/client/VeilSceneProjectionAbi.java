package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;

import java.util.List;

public final class VeilSceneProjectionAbi {
    public static final int SET = 0;
    public static final int BINDING = 14;
    public static final int SIZE = 64;

    private VeilSceneProjectionAbi() {}

    public static boolean isBinding(VeilShaderInterface.Descriptor descriptor) {
        return descriptor.set() == SET && descriptor.binding() == BINDING;
    }

    public static VeilShaderInterface.Descriptor validate(VeilShaderInterface shader) {
        List<VeilShaderInterface.Descriptor> matches =
                shader.descriptors().stream().filter(VeilSceneProjectionAbi::isBinding).toList();
        if (matches.size() != 1) {
            throw new IllegalArgumentException(
                    "SceneProjectionData requires exactly one set=0 binding="
                            + BINDING
                            + " uniform buffer");
        }
        var descriptor = matches.getFirst();
        if (descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
                || descriptor.descriptorCount() != 1
                || descriptor.runtimeArray()
                || descriptor.minimumBufferSize() != SIZE
                || descriptor.writable()) {
            throw new IllegalArgumentException(
                    "SceneProjectionData binding requires a fixed readonly uniform buffer of "
                            + SIZE
                            + " bytes; actual="
                            + descriptor);
        }
        return descriptor;
    }
}
