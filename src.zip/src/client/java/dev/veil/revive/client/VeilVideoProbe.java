package dev.veil.revive.client;

import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.*;
import net.minecraft.client.gui.screens.options.VideoSettingsScreen;

import java.nio.file.*;

final class VeilVideoProbe {
    private static int ticks, step;
    private static VeilVideoScreen screen;

    static void tick(Minecraft client) {
        if (!VeilPlatform.get().isDevelopmentEnvironment()
                || !Boolean.getBoolean("veil.videoProbe")
                || step >= 10
                || client.player == null) return;
        if (++ticks < (screen == null ? 100 : 15)) return;
        if (screen == null) {
            client.gui.setScreen(
                    new VideoSettingsScreen(
                            new net.minecraft.client.gui.screens.PauseScreen(true),
                            client,
                            client.options));
            if (!(client.gui.screen() instanceof VeilVideoScreen s))
                throw new AssertionError("Vanilla video screen was not replaced");
            screen = s;
            screen.developmentCheck();
            ticks = 0;
            return;
        }
        if (client.gui.screen() != screen) return;
        if (ticks < 15) return;
        if (step < 9) {
            final int page = step;
            try {
                Path dir = VeilPlatform.get().getGameDir().resolve("screenshots/veil-video");
                Files.createDirectories(dir);
                Screenshot.takeScreenshot(
                        client.gameRenderer.mainRenderTarget(),
                        image -> {
                            try {
                                image.writeToFile(dir.resolve("veil-video-" + page + ".png"));
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            } finally {
                                image.close();
                            }
                        });
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        step++;
        ticks = 0;
        if (step < 9) screen.developmentTab(step);
        else {
            screen.developmentTab(0);
            step = 10;
            dev.veil.revive.ReviveMod.LOGGER.info("Veil video UI capture complete; menu left open");
        }
    }
}
