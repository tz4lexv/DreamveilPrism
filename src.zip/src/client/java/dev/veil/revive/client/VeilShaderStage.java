package dev.veil.revive.client;

import static org.lwjgl.vulkan.KHRRayTracingPipeline.*;
import static org.lwjgl.vulkan.VK10.*;

import org.lwjgl.util.shaderc.Shaderc;

public enum VeilShaderStage {
    VERTEX(Shaderc.shaderc_vertex_shader, VK_SHADER_STAGE_VERTEX_BIT),
    TESS_CONTROL(Shaderc.shaderc_tess_control_shader, VK_SHADER_STAGE_TESSELLATION_CONTROL_BIT),
    TESS_EVALUATION(
            Shaderc.shaderc_tess_evaluation_shader, VK_SHADER_STAGE_TESSELLATION_EVALUATION_BIT),
    GEOMETRY(Shaderc.shaderc_geometry_shader, VK_SHADER_STAGE_GEOMETRY_BIT),
    FRAGMENT(Shaderc.shaderc_fragment_shader, VK_SHADER_STAGE_FRAGMENT_BIT),
    COMPUTE(Shaderc.shaderc_compute_shader, VK_SHADER_STAGE_COMPUTE_BIT),
    RAYGEN(Shaderc.shaderc_raygen_shader, VK_SHADER_STAGE_RAYGEN_BIT_KHR),
    MISS(Shaderc.shaderc_miss_shader, VK_SHADER_STAGE_MISS_BIT_KHR),
    CLOSEST_HIT(Shaderc.shaderc_closesthit_shader, VK_SHADER_STAGE_CLOSEST_HIT_BIT_KHR),
    ANY_HIT(Shaderc.shaderc_anyhit_shader, VK_SHADER_STAGE_ANY_HIT_BIT_KHR),
    INTERSECTION(Shaderc.shaderc_intersection_shader, VK_SHADER_STAGE_INTERSECTION_BIT_KHR),
    CALLABLE(Shaderc.shaderc_callable_shader, VK_SHADER_STAGE_CALLABLE_BIT_KHR);

    private final int shadercKind;
    private final int vkStageFlags;

    VeilShaderStage(int shadercKind, int vkStageFlags) {
        this.shadercKind = shadercKind;
        this.vkStageFlags = vkStageFlags;
    }

    int shadercKind() {
        return shadercKind;
    }

    public int vkStageFlags() {
        return vkStageFlags;
    }
}
