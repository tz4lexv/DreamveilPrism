package dev.veil.revive.client;

import dev.veil.api.VeilCreatorMeshes;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;

final class AutomaticMeshUvGpuProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.automaticMeshUvProbe");
    private static Object world;
    private static volatile int entityId = -1;

    private AutomaticMeshUvGpuProbe() {}

    static void prepare() {
        if (!ENABLED) return;
        var client = Minecraft.getInstance();
        if (client.level == null || client.player == null || client.gui.screen() != null) return;
        if (world == client.level) return;
        world = client.level;
        entityId = -1;
        var server = client.getSingleplayerServer();
        if (server == null)
            throw new IllegalStateException(
                    "Automatic UV probe requires private integrated server");
        var dimension = client.level.dimension();
        var position = client.gameRenderer.mainCamera().position();
        var look = client.player.getLookAngle();
        double x = position.x + look.x * 10,
                y = position.y + look.y * 10 - 0.5,
                z = position.z + look.z * 10;
        server.execute(
                () -> {
                    var level = server.getLevel(dimension);
                    var pig = EntityTypes.PIG.create(level, EntitySpawnReason.COMMAND);
                    if (pig == null) throw new IllegalStateException("UV probe entity unavailable");
                    pig.setPos(x, y, z);
                    pig.setNoGravity(true);
                    pig.setNoAi(true);
                    if (!level.addFreshEntity(pig))
                        throw new IllegalStateException("UV probe entity spawn failed");
                    entityId = pig.getId();
                    ReviveMod.LOGGER.info(
                            "Veil automatic UV fixture: spawned dimension={} entity={}",
                            dimension.identifier(),
                            entityId);
                });
    }

    static boolean ready() {
        return !ENABLED
                || entityId >= 0
                        && VeilCreatorMeshes.meshes().stream()
                                .anyMatch(
                                        mesh ->
                                                mesh.id()
                                                                == (0x5645000000000000L
                                                                        | Integer.toUnsignedLong(
                                                                                entityId))
                                                        && mesh.hasTextureCoordinates()
                                                        && mesh.triangleCount() > 0);
    }

    static int expectedEntity() {
        return ENABLED ? entityId : -1;
    }
}
