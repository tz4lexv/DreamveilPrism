package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.DirectionalQuadBuckets;
import dev.veil.revive.core.terrain.DeferredMeshWork;

import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.LongAdder;

public final class VeilProgressiveMeshing {
    private static final boolean REQUESTED = Boolean.getBoolean("veil.progressiveMeshing");
    private static final boolean PAIRS_REQUESTED = Boolean.getBoolean("veil.progressivePairs");
    private static final DeferredMeshWork<Result> WORK =
            new DeferredMeshWork<>("Veil mesh refinement", 64, 32L << 20);
    private static final ArrayBlockingQueue<VeilMeshMetadata> READY = new ArrayBlockingQueue<>(256);
    private static final AtomicBoolean OVERFLOW = new AtomicBoolean();
    private static final LongAdder NOTIFIED = new LongAdder(), STALE = new LongAdder();
    private static final boolean VERIFY =
            Boolean.getBoolean("veil.verifyProgressiveMeshing")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final java.util.concurrent.atomic.AtomicReference<Hold> HELD =
            new java.util.concurrent.atomic.AtomicReference<>();
    private static final AtomicBoolean INITIAL_PROVED = new AtomicBoolean();
    private static final LongAdder VERIFIED_VERTICES = new LongAdder();
    private static final LongAdder VERIFIED_PAIRS = new LongAdder();
    private static final LongAdder REORDERED_PAIRS = new LongAdder();
    private static final boolean VERIFY_PAIRS =
            Boolean.getBoolean("veil.verifyProgressivePairs")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();

    private record Hold(VeilMeshMetadata metadata, java.util.concurrent.CountDownLatch release) {}

    private VeilProgressiveMeshing() {}

    record Result(
            DirectionalQuadBuckets.Layout layout,
            dev.veil.revive.core.terrain.PairedTerrainMesh.Result paired,
            dev.veil.revive.core.terrain.ParametricTerrainQuads.Result parametric) {}

    static boolean pairsEnabled() {
        return PAIRS_REQUESTED && enabled() && VeilRegularPackedTerrain.enabled();
    }

    public static boolean enabled() {
        return REQUESTED
                && ReviveRuntime.optimizationsEnabled()
                && VeilSectionChanges.notificationsSupported();
    }

    static Request submit(
            VeilMeshMetadata metadata, ByteBuffer vertices, int count, boolean lightOnly) {
        return submit(metadata, vertices, count, lightOnly, true, false);
    }

    static Request submit(
            VeilMeshMetadata metadata,
            ByteBuffer vertices,
            int count,
            boolean lightOnly,
            boolean fuse,
            boolean pack) {
        int size = vertices.remaining();
        if (size <= 0 || size > (4 << 20)) return null;
        long generation = VeilHostRevisions.global();
        boolean captureAttributes = pack && metadata.hasOriginalAttributeSource();
        int attributeBytes = captureAttributes ? Math.multiplyExact(count, 36) : 0;
        var ticket =
                WORK.submit(
                        size,
                        Math.addExact(
                                attributeBytes,
                                pack && VeilParametricTerrainArena.requested()
                                        ? count
                                                * VeilParametricTerrainArena
                                                        .temporaryBytesPerVertex()
                                        : 0),
                        () -> {
                            byte[] copy = new byte[size];
                            vertices.duplicate().get(copy);
                            return copy;
                        },
                        copy -> {
                            if (VERIFY
                                    && fuse
                                    && !INITIAL_PROVED.get()
                                    && VeilBenchmarkWorld.terrainReady()) {
                                var hold =
                                        new Hold(
                                                metadata,
                                                new java.util.concurrent.CountDownLatch(1));
                                if (HELD.compareAndSet(null, hold)) {
                                    try {
                                        if (!hold.release.await(
                                                30, java.util.concurrent.TimeUnit.SECONDS))
                                            throw new IllegalStateException(
                                                    "Initial mesh did not publish while refinement blocked");
                                    } catch (InterruptedException failure) {
                                        Thread.currentThread().interrupt();
                                        throw new IllegalStateException(failure);
                                    }
                                }
                            }
                            var built =
                                    !fuse
                                            ? null
                                            : VeilLodBuildCache.build(
                                                    ByteBuffer.wrap(copy)
                                                            .order(ByteOrder.nativeOrder()),
                                                    count,
                                                    lightOnly);
                            var layout =
                                    built == null ? null : DirectionalQuadBuckets.prepare(built);
                            if (VERIFY && fuse && VERIFIED_VERTICES.sum() < 100000) {
                                var expected =
                                        dev.veil.revive.core.PlanarTerrainLod.build(
                                                ByteBuffer.wrap(copy)
                                                        .order(ByteOrder.nativeOrder()),
                                                count);
                                var oracle =
                                        expected == null
                                                ? null
                                                : DirectionalQuadBuckets.prepare(expected);
                                if ((layout == null) != (oracle == null)
                                        || (layout != null
                                                && (!java.util.Arrays.equals(
                                                                layout.mesh().vertices(),
                                                                oracle.mesh().vertices())
                                                        || layout.mesh().quads()
                                                                != oracle.mesh().quads()
                                                        || layout.mesh().originalBytes()
                                                                != oracle.mesh().originalBytes())))
                                    throw new IllegalStateException(
                                            "Deferred fusion differs from synchronous builder");
                                VERIFIED_VERTICES.add(count);
                            }
                            var parametric =
                                    pack && VeilParametricTerrainArena.enabled()
                                            ? dev.veil.revive.core.terrain.ParametricTerrainQuads
                                                    .encode(
                                                            ByteBuffer.wrap(copy)
                                                                    .order(ByteOrder.nativeOrder()),
                                                            count)
                                            : null;
                            if (parametric != null)
                                VeilParametricTerrainArena.verifyCpu(copy, parametric);
                            var paired =
                                    pack && parametric == null
                                            ? dev.veil.revive.core.terrain.PairedTerrainMesh.build(
                                                    ByteBuffer.wrap(copy)
                                                            .order(ByteOrder.nativeOrder()),
                                                    count,
                                                    !"false"
                                                            .equalsIgnoreCase(
                                                                    System.getProperty(
                                                                            "veil.regularPackedPrefer16")),
                                                    !"false"
                                                            .equalsIgnoreCase(
                                                                    System.getProperty(
                                                                            "veil.regularPackedWidePositions")),
                                                    Boolean.getBoolean("veil.indexedTerrainCache"),
                                                    captureAttributes)
                                            : null;
                            if (paired != null && paired.sourceQuads() != null)
                                REORDERED_PAIRS.increment();
                            if (VERIFY_PAIRS && paired != null && VERIFIED_PAIRS.sum() < 100000) {
                                dev.veil.revive.core.terrain.PairedTerrainMesh.verify(
                                        ByteBuffer.wrap(copy).order(ByteOrder.nativeOrder()),
                                        paired);
                                VERIFIED_PAIRS.add(count);
                            }
                            return layout == null && paired == null && parametric == null
                                    ? null
                                    : new Result(layout, paired, parametric);
                        },
                        () -> ready(metadata));
        return ticket == null ? null : new Request(generation, ticket);
    }

    static void ready(VeilMeshMetadata metadata) {
        if (!READY.offer(metadata)) OVERFLOW.set(true);
    }

    static final class Request implements AutoCloseable {
        final long generation;
        final DeferredMeshWork<Result>.Ticket ticket;
        private boolean notified;

        Request(long generation, DeferredMeshWork<Result>.Ticket ticket) {
            this.generation = generation;
            this.ticket = ticket;
        }

        Result get() {
            if (generation != VeilHostRevisions.global()) {
                close();
                return null;
            }
            return ticket.get();
        }

        boolean claimNotification() {
            if (notified || get() == null) return false;
            notified = true;
            return true;
        }

        @Override
        public void close() {
            ticket.close();
        }
    }

    static void tick(List<SectionRenderDispatcher.RenderSection> visible) {
        if (!REQUESTED) return;
        var held = HELD.get();
        if (held != null && held.release.getCount() != 0) {
            var owner = held.metadata.progressiveOwner();
            if (held.metadata.closed()
                    || (owner != null && owner.section().getSectionMesh() != owner.mesh())) {
                HELD.compareAndSet(held, null);
                held.release.countDown();
            } else if (owner != null
                    && owner.mesh()
                            instanceof net.minecraft.client.renderer.chunk.CompiledSectionMesh mesh
                    && mesh.isVertexBufferUploaded(
                            net.minecraft.client.renderer.chunk.ChunkSectionLayer.SOLID)) {
                if (held.metadata.progressiveReady())
                    throw new IllegalStateException("Blocked refinement already visible");
                INITIAL_PROVED.set(true);
                held.release.countDown();
                ReviveMod.LOGGER.info(
                        "Veil progressive initial mesh: PASS (native mesh installed/uploaded while refinement blocked)");
            }
        }
        for (int i = 0; i < 64; i++) {
            var metadata = READY.poll();
            if (metadata == null) break;
            notifyOwner(metadata);
        }
        if (OVERFLOW.getAndSet(false)) {
            for (var section : visible)
                if (section.getSectionMesh() instanceof VeilMeshExtras extras)
                    notifyOwner(extras.veil$metadata());
        }
    }

    private static void notifyOwner(VeilMeshMetadata metadata) {
        if (metadata == null || !metadata.progressiveReady()) return;
        var owner = metadata.progressiveOwner();
        if (owner == null) return;
        if (metadata.closed()
                || owner.section().getSectionNode() != owner.node()
                || owner.section().getSectionMesh() != owner.mesh()) {
            metadata.discardProgressive();
            STALE.increment();
            return;
        }
        if (metadata.claimProgressiveNotification()) {
            VeilHostRevisions.meshChanged(owner.section());
            NOTIFIED.increment();
        }
    }

    record Owner(SectionRenderDispatcher.RenderSection section, SectionMesh mesh, long node) {}

    static void requirePairedParity() {
        if (!VERIFY_PAIRS || VERIFIED_PAIRS.sum() < 100000 || WORK.counters().failed() != 0)
            throw new IllegalStateException(
                    "Paired index parity requires verifyProgressivePairs and complete CPU coverage");
    }

    static void requireComplete() {
        if (!REQUESTED) return;
        var stats = WORK.counters();
        ReviveMod.LOGGER.info(
                "Veil progressive meshing: accepted={} rejected={} refined={} cancelled_queued={} failed={} source_bytes={} source_peak={} notified={} stale={}",
                stats.accepted(),
                stats.rejected(),
                stats.completed(),
                stats.cancelled(),
                stats.failed(),
                stats.bytes(),
                stats.peakBytes(),
                NOTIFIED.sum(),
                STALE.sum());
        if (VERIFY
                && (stats.completed() == 0
                        || NOTIFIED.sum() == 0
                        || stats.failed() != 0
                        || !INITIAL_PROVED.get()
                        || VERIFIED_VERTICES.sum() < 100000))
            throw new IllegalStateException("Progressive meshing native verification incomplete");
        if (VERIFY)
            ReviveMod.LOGGER.info(
                    "Veil progressive verification: PASS (native_vertices={} initial_published_before_refinement=true)",
                    VERIFIED_VERTICES.sum());
        if (VERIFY_PAIRS) {
            if (Boolean.getBoolean("veil.requireProgressivePairCache")
                    && REORDERED_PAIRS.sum() == 0)
                throw new IllegalStateException("Paired cache reorder was not exercised");
            requirePairedParity();
            VeilPairedTerrainArena.requireComplete();
            ReviveMod.LOGGER.info(
                    "Veil progressive pairs CPU parity: PASS (native_vertices={})",
                    VERIFIED_PAIRS.sum());
            ReviveMod.LOGGER.info(
                    "Veil progressive pair cache: reordered_meshes={}", REORDERED_PAIRS.sum());
        } else if (pairsEnabled()) {
            if (VeilParametricTerrainArena.requested())
                VeilParametricTerrainArena.requireComplete();
            else VeilPairedTerrainArena.requireActiveRoute();
            VeilPairedTerrainArena.logStatistics();
        }
    }
}
