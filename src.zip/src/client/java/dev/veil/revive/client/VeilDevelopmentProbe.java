package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

final class VeilDevelopmentProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.developmentProbe");
    private static long worldStart;
    private static boolean started;
    private static final boolean VISUAL =
            VeilPlatform.get().isDevelopmentEnvironment() && Boolean.getBoolean("veil.visualProbe");

    static void tick(Minecraft client) {
        if (!VeilBenchmarkWorld.tick(client)) return;
        if (Boolean.getBoolean("veil.fixtureHandoff")) return;
        if ((!ENABLED && !VISUAL) || client.player == null) return;
        if (VeilSceneRasterGpuProbe.enabled()
                || VeilBasicShadowSlangGpuProbe.enabled()
                || VeilCreatorHostPerformanceProbe.enabled()
                || VeilColorPipelineGpuProbe.enabled()
                || VeilVolumeSupportGpuProbe.enabled()
                || VeilGiConformanceProbe.enabled()) return;
        long now = System.nanoTime();
        if (worldStart == 0L) worldStart = now;
        if (!started && now - worldStart > 30_000_000_000L) {
            if (VISUAL) VeilDiagnostics.startVisualValidation(client);
            else VeilDiagnostics.startBenchmark(client);
            started = true;
        } else if (!VISUAL && started && !VeilDiagnostics.benchmarkActive()) {
            ReviveMod.LOGGER.info(
                    "Veil development probe ended: {}",
                    VeilDiagnostics.lastBenchmark() == null
                            ? "CANCELLED"
                            : VeilDiagnostics.lastBenchmark().shortResult());
            client.stop();
        }
    }
}
