package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import java.util.IdentityHashMap;

final class VeilParametricDescriptorProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.verifyParametricLifecycle")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final IdentityHashMap<Object, Boolean> SEEN = new IdentityHashMap<>();
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static byte[] expected;
    private static Object identity;

    private VeilParametricDescriptorProbe() {}

    static boolean verify(Object key, byte[] bytes, GpuBuffer source, long offset) {
        if (!ENABLED) throw new IllegalStateException("Parametric lifecycle verifier disabled");
        tick();
        if (Boolean.TRUE.equals(SEEN.get(key))) return true;
        if (fence != null) return false;
        identity = key;
        expected = bytes;
        readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil parametric replacement parity",
                                GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                                bytes.length);
        var encoder = RenderSystem.getDevice().createCommandEncoder();
        encoder.copyToBuffer(source.slice(offset, bytes.length), readback.slice());
        fence = encoder.createFence();
        return false;
    }

    private static void tick() {
        if (fence == null || !fence.awaitCompletion(0)) return;
        try (var mapped = readback.map(true, false)) {
            var bytes = mapped.data();
            for (int i = 0; i < expected.length; i++)
                if (bytes.get(i) != expected[i])
                    throw new IllegalStateException("Parametric replacement GPU mismatch at " + i);
            SEEN.put(identity, Boolean.TRUE);
        } finally {
            release();
        }
    }

    private static void release() {
        if (fence != null) fence.close();
        if (readback != null) readback.close();
        fence = null;
        readback = null;
        identity = null;
        expected = null;
    }

    static void close() {
        release();
        SEEN.clear();
    }
}
