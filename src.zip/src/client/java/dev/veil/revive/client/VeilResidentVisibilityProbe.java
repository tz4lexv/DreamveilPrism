package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class VeilResidentVisibilityProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.commandVisibilityProbe")
                    && VeilHzb.residentVisibilityCompactionEnabled();
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static Map<List<Integer>, Integer> expected;
    private static int expectedCount, hidden;
    private static boolean complete;

    private VeilResidentVisibilityProbe() {}

    static void capture(VeilIndirectTerrain.Batch batch, VeilHzbCompute compute) {
        if (!ENABLED || complete || fence != null) return;
        hidden = 0;
        for (int slot : batch.sectionIndices)
            if (VeilTerrainDrawBridge.inactiveResidentSlot(slot)) hidden++;
        if (hidden == 0) return;
        expected = new HashMap<>();
        expectedCount = 0;
        for (int i = 0; i < batch.sectionIndices.length; i++) {
            int count = batch.directCommands.get(i * 3 + 1);
            if (count == 0) continue;
            expected.merge(
                    List.of(
                            count,
                            1,
                            batch.firstIndices[i],
                            batch.baseVertices[i],
                            batch.sectionIndices[i]),
                    1,
                    Integer::sum);
            expectedCount++;
        }
        readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil resident visibility readback",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                4L + batch.sectionIndices.length * 20L);
        compute.prepareCountReadback();
        var encoder = RenderSystem.getDevice().createCommandEncoder();
        encoder.copyToBuffer(batch.count(), readback.slice(0, 4));
        encoder.copyToBuffer(
                batch.compacted(), readback.slice(4, batch.sectionIndices.length * 20L));
        fence = encoder.createFence();
    }

    static void poll() {
        if (fence == null || !fence.awaitCompletion(0)) return;
        try (var mapped = readback.map(true, false)) {
            var data = mapped.data();
            int count = data.getInt(0);
            if (count != expectedCount)
                throw new IllegalStateException(
                        "Resident GPU compacted count mismatch: " + count + " != " + expectedCount);
            for (int i = 0; i < count; i++) {
                int offset = 4 + i * 20;
                var key =
                        List.of(
                                data.getInt(offset),
                                data.getInt(offset + 4),
                                data.getInt(offset + 8),
                                data.getInt(offset + 12),
                                data.getInt(offset + 16));
                Integer remaining = expected.get(key);
                if (remaining == null || remaining == 0)
                    throw new IllegalStateException(
                            "Resident GPU compaction changed or duplicated a command");
                if (remaining == 1) expected.remove(key);
                else expected.put(key, remaining - 1);
            }
            if (!expected.isEmpty())
                throw new IllegalStateException("Resident GPU compaction lost active commands");
            complete = true;
            ReviveMod.LOGGER.info(
                    "Veil resident visibility GPU probe: PASS ({} active commands, {} retained inactive commands excluded; exact unordered command multiset and GPU count)",
                    count,
                    hidden);
        } finally {
            fence.close();
            readback.close();
            fence = null;
            readback = null;
            expected = null;
        }
    }

    static void requireComplete() {
        if (ENABLED && !complete)
            throw new IllegalStateException("Resident visibility GPU probe incomplete");
    }
}
