package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilServerAiCounters;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.sensing.Sensor;
import net.minecraft.world.entity.npc.villager.Villager;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Sensor.class)
public abstract class SensorTimingMixin {
    @Unique private long veil$sensorStartNs;
    @Unique private boolean veil$sensorVillager;

    @Inject(method = "tick", at = @At("HEAD"), require = 1)
    private void veil$beginSensor(ServerLevel level, LivingEntity body, CallbackInfo ci) {
        if (!VeilDiagnostics.benchmarkActive()) {
            veil$sensorStartNs = 0L;
            return;
        }
        veil$sensorVillager = body instanceof Villager;
        veil$sensorStartNs = System.nanoTime();
    }

    @Inject(method = "tick", at = @At("RETURN"), require = 1)
    private void veil$endSensor(ServerLevel level, LivingEntity body, CallbackInfo ci) {
        long start = veil$sensorStartNs;
        veil$sensorStartNs = 0L;
        if (start != 0L && VeilDiagnostics.benchmarkActive()) {
            VeilServerAiCounters.sensor(System.nanoTime() - start, veil$sensorVillager);
        }
    }
}
