package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.QuadInstance;

import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.ARGB;
import net.minecraft.world.level.block.state.BlockState;

public final class VeilFlatQuadLighting {
    private final BlockPos.MutableBlockPos sample = new BlockPos.MutableBlockPos();
    private final Lookup lookup;

    public VeilFlatQuadLighting(Lookup lookup) {
        this.lookup = lookup;
    }

    public void prepare(
            BlockAndTintGetter world,
            BlockState state,
            BlockPos position,
            int suppliedLight,
            BakedQuad quad,
            QuadInstance output,
            boolean vertexShade) {
        if (suppliedLight == -1) {
            var face = quad.direction();
            float lo = 32f, hi = -32f;
            for (int vertex = 0; vertex < 4; vertex++) {
                var p = quad.position(vertex);
                float coordinate =
                        switch (face.getAxis()) {
                            case X -> p.x();
                            case Y -> p.y();
                            case Z -> p.z();
                        };
                lo = Math.min(lo, coordinate);
                hi = Math.max(hi, coordinate);
            }
            boolean outer =
                    face.getAxisDirection() == Direction.AxisDirection.POSITIVE
                            ? hi > 0.9999f
                            : lo < 0.0001f;
            boolean neighbor =
                    lo == hi && (outer || state.isCollisionShapeFullBlock(world, position));
            if (neighbor) sample.setWithOffset(position, face);
            output.setLightCoords(lookup.light(state, world, neighbor ? sample : position));
        } else output.setLightCoords(suppliedLight);
        if (!vertexShade) {
            var lighting = world.cardinalLighting();
            output.setColor(
                    ARGB.gray(
                            quad.materialInfo().shade()
                                    ? lighting.byFace(quad.direction())
                                    : lighting.up()));
        }
    }

    @FunctionalInterface
    public interface Lookup {
        int light(BlockState state, BlockAndTintGetter world, BlockPos position);
    }
}
