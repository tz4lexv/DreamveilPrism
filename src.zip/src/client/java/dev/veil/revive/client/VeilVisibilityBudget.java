package dev.veil.revive.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;

import java.util.IdentityHashMap;

public final class VeilVisibilityBudget {
    private static final IdentityHashMap<Object, Boolean> IMPORTANT_PARTICLES =
            new IdentityHashMap<>();
    private static final IdentityHashMap<Object, Boolean> PARTICLE_TYPE_ENABLED =
            new IdentityHashMap<>();
    private static long second = -1,
            sequence,
            particlesAccepted,
            particlesRejected,
            entitiesRejected;
    private static int admittedThisSecond;
    private static int softBudget = 4000;
    private static double cachedFramePressure = 1.0;
    private static boolean tickStateValid;

    private VeilVisibilityBudget() {}

    public static void beginClientTick() {
        long now = System.nanoTime() / 1_000_000_000L;
        if (now != second) {
            second = now;
            admittedThisSecond = 0;
        }
        Minecraft minecraft = Minecraft.getInstance();
        int fps = Math.max(1, minecraft.getFps());
        softBudget =
                fps >= 120 ? 7000 : fps >= 90 ? 5500 : fps >= 60 ? 4000 : fps >= 45 ? 2600 : 1600;
        cachedFramePressure = ReviveRuntime.framePressure();
        tickStateValid = true;
    }

    public static boolean entityOutsideRenderDistance(Entity entity, double x, double y, double z) {
        var player = Minecraft.getInstance().player;
        if (!ReviveRuntime.optimizationsEnabled()
                || !VeilVideoConfig.on("renderer.entityCulling")
                || player != null && entity.hasIndirectPassenger(player)) return false;
        if (!entity.shouldRender(x, y, z)) {
            entitiesRejected++;
            return true;
        }
        return false;
    }

    public static boolean particleTypeEnabled(ParticleOptions options) {
        Object type = options.getType();
        Boolean cached = PARTICLE_TYPE_ENABLED.get(type);
        if (cached != null) return cached;
        var id = BuiltInRegistries.PARTICLE_TYPE.getKey(options.getType());
        boolean enabled = VeilVideoConfig.on("particle." + id);
        PARTICLE_TYPE_ENABLED.put(type, enabled);
        return enabled;
    }

    public static void resetConfigCaches() {
        PARTICLE_TYPE_ENABLED.clear();
        tickStateValid = false;
    }

    public static boolean rejectParticle(ParticleOptions options, double x, double y, double z) {
        if (!VeilVideoConfig.on("particle.adaptive")) return false;
        if (!tickStateValid) beginClientTick();

        var camera = Minecraft.getInstance().gameRenderer.mainCamera();
        var p = camera.position();
        double dx = x - p.x, dy = y - p.y, dz = z - p.z, distance2 = dx * dx + dy * dy + dz * dz;
        Object type = options.getType();
        if (distance2 <= 24.0 * 24.0 || isImportant(options, type)) {
            particlesAccepted++;
            admittedThisSecond++;
            return false;
        }

        double spawnPressure =
                admittedThisSecond <= softBudget
                        ? 1.0
                        : (double) admittedThisSecond / (double) softBudget;
        double pressure = Math.max(cachedFramePressure, spawnPressure);

        if (pressure <= 1.03) {
            admittedThisSecond++;
            particlesAccepted++;
            return false;
        }

        double severity = Math.min(1.0, (pressure - 1.0) / 1.25);
        double priority = distance2 < 64.0 * 64.0 ? 1.0 : distance2 < 128.0 * 128.0 ? 0.82 : 0.58;
        double minimum = distance2 < 64.0 * 64.0 ? 0.78 : distance2 < 128.0 * 128.0 ? 0.58 : 0.38;
        double survival = Math.max(minimum, 1.0 - severity * (1.0 - priority + 0.32));
        long hash = mix(++sequence ^ Double.doubleToLongBits(x * 31.0 + z));
        double sample = (hash >>> 11) * 0x1.0p-53;
        boolean reject = sample >= survival;
        if (reject) particlesRejected++;
        else {
            admittedThisSecond++;
            particlesAccepted++;
        }
        return reject;
    }

    private static boolean isImportant(ParticleOptions options, Object type) {
        Boolean cached = IMPORTANT_PARTICLES.get(type);
        if (cached != null) return cached;
        String path = BuiltInRegistries.PARTICLE_TYPE.getKey(options.getType()).getPath();
        boolean important =
                path.contains("totem")
                        || path.contains("damage_indicator")
                        || path.contains("flash")
                        || path.contains("sonic_boom")
                        || path.contains("explosion");
        IMPORTANT_PARTICLES.put(type, important);
        return important;
    }

    private static long mix(long z) {
        z = (z ^ (z >>> 30)) * 0xbf58476d1ce4e5b9L;
        z = (z ^ (z >>> 27)) * 0x94d049bb133111ebL;
        return z ^ (z >>> 31);
    }

    public static String telemetry() {
        return "entity_exact_rejected_total="
                + entitiesRejected
                + "\nparticle_admitted_total="
                + particlesAccepted
                + "\nparticle_budget_rejected_total="
                + particlesRejected
                + "\n";
    }
}
