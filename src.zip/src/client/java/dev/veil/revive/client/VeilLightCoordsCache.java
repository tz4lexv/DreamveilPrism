package dev.veil.revive.client;

import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;

import net.minecraft.core.SectionPos;

public final class VeilLightCoordsCache {
    private static final int MISS = Integer.MIN_VALUE;
    private static final int HALO = 1;
    private static final int DIM = 16 + HALO * 2;
    private static final int CELLS = DIM * DIM * DIM;
    private static final ThreadLocal<State> STATE = ThreadLocal.withInitial(State::new);

    private static final java.util.concurrent.atomic.LongAdder hits =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder denseHits =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder fallbackHits =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder misses =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder stores =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder compiles =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder revisionInvalidations =
            new java.util.concurrent.atomic.LongAdder();

    private VeilLightCoordsCache() {}

    public static boolean enabled() {
        return VeilLightingPipeline.enabled()
                && VeilVideoConfig.flag("renderer.lightCompileCache", true);
    }

    public static void beginSectionCompile(SectionPos sectionPos) {
        State state = STATE.get();
        if (state.depth++ == 0) {
            state.active = enabled();
            state.originX = (sectionPos.getX() << 4) - HALO;
            state.originY = (sectionPos.getY() << 4) - HALO;
            state.originZ = (sectionPos.getZ() << 4) - HALO;
            state.lightRevision = state.active ? VeilLightingPipeline.lightGlobalRevision() : 0L;
            state.fallback.clear();
            state.nextGeneration();
            if (state.active && VeilTechniqueCounters.collecting()) compiles.increment();
        }
    }

    public static void endSectionCompile() {
        State state = STATE.get();
        if (state.depth <= 0) return;
        if (--state.depth == 0) {
            state.active = false;
            state.fallback.clear();
        }
    }

    public static int lookup(int x, int y, int z) {
        State state = STATE.get();
        if (!state.active) return MISS;
        refreshForLiveLighting(state);

        int denseIndex = state.denseIndex(x, y, z);
        if (denseIndex >= 0) {
            if (state.generations[denseIndex] == state.generation) {
                if (VeilTechniqueCounters.collecting()) {
                    hits.increment();
                    denseHits.increment();
                }
                return state.values[denseIndex];
            }
            if (VeilTechniqueCounters.collecting()) misses.increment();
            return MISS;
        }

        long key = net.minecraft.core.BlockPos.asLong(x, y, z);
        int value = state.fallback.get(key);
        if (VeilTechniqueCounters.collecting()) {
            if (value == MISS) misses.increment();
            else {
                hits.increment();
                fallbackHits.increment();
            }
        }
        return value;
    }

    public static boolean isMiss(int value) {
        return value == MISS;
    }

    public static void store(int x, int y, int z, int packedLight) {
        State state = STATE.get();
        if (!state.active) return;
        refreshForLiveLighting(state);

        int denseIndex = state.denseIndex(x, y, z);
        if (denseIndex >= 0) {
            state.values[denseIndex] = packedLight;
            state.generations[denseIndex] = state.generation;
        } else {
            state.fallback.put(net.minecraft.core.BlockPos.asLong(x, y, z), packedLight);
        }
        if (VeilTechniqueCounters.collecting()) stores.increment();
    }

    private static void refreshForLiveLighting(State state) {
        long currentRevision = VeilLightingPipeline.lightGlobalRevision();
        if (currentRevision == state.lightRevision) return;
        state.lightRevision = currentRevision;
        state.fallback.clear();
        state.nextGeneration();
        if (VeilTechniqueCounters.collecting()) revisionInvalidations.increment();
    }

    public static String telemetry() {
        long h = hits.sum();
        long m = misses.sum();
        long total = h + m;
        double reuse = total == 0L ? 0.0 : (double) h / (double) total;
        return "light_coords_cache_compiles_total="
                + compiles.sum()
                + "\nlight_coords_cache_hits_total="
                + h
                + "\nlight_coords_cache_dense_hits_total="
                + denseHits.sum()
                + "\nlight_coords_cache_fallback_hits_total="
                + fallbackHits.sum()
                + "\nlight_coords_cache_misses_total="
                + m
                + "\nlight_coords_cache_stores_total="
                + stores.sum()
                + "\nlight_coords_cache_revision_invalidations_total="
                + revisionInvalidations.sum()
                + "\nlight_coords_cache_reuse="
                + String.format(java.util.Locale.ROOT, "%.4f", reuse)
                + "\n";
    }

    private static final class State {
        final int[] values = new int[CELLS];
        final int[] generations = new int[CELLS];
        final Long2IntOpenHashMap fallback = new Long2IntOpenHashMap(128);
        int depth;
        int originX;
        int originY;
        int originZ;
        int generation;
        boolean active;
        long lightRevision;

        State() {
            fallback.defaultReturnValue(MISS);
        }

        void nextGeneration() {
            if (++generation == 0) {
                java.util.Arrays.fill(generations, 0);
                generation = 1;
            }
        }

        int denseIndex(int x, int y, int z) {
            int lx = x - originX;
            int ly = y - originY;
            int lz = z - originZ;
            if ((lx | ly | lz) < 0 || lx >= DIM || ly >= DIM || lz >= DIM) return -1;
            return (ly * DIM + lz) * DIM + lx;
        }
    }
}
