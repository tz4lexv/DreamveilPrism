package dev.veil.revive.client;

public interface VeilPbrAnimationOwner {
    void veil$setPbrAnimation(Object animation);
}
