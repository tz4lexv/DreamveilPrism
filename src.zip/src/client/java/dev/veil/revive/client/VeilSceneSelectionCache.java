package dev.veil.revive.client;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;

import java.lang.ref.WeakReference;
import java.util.LinkedHashMap;
import java.util.function.Supplier;

final class VeilSceneSelectionCache {
    private static final int MAX_PASSES = 16;
    private final LinkedHashMap<String, Entry> entries = new LinkedHashMap<>(16, 0.75f, true);
    private long hits;
    private long rebuilds;

    long[] select(
            String pass,
            Object area,
            int count,
            long originRevision,
            long globalRevision,
            Matrix4fc viewProjection,
            double x,
            double y,
            double z,
            Supplier<long[]> rebuild) {
        var entry = entries.get(pass);
        if (entry != null
                && entry.area.get() == area
                && entry.count == count
                && entry.originRevision == originRevision
                && entry.globalRevision == globalRevision
                && entry.viewProjection.equals(viewProjection)
                && Double.doubleToLongBits(entry.x) == Double.doubleToLongBits(x)
                && Double.doubleToLongBits(entry.y) == Double.doubleToLongBits(y)
                && Double.doubleToLongBits(entry.z) == Double.doubleToLongBits(z)) {
            hits++;
            return entry.nodes;
        }
        long[] nodes = rebuild.get();
        entry =
                new Entry(
                        new WeakReference<>(area),
                        count,
                        originRevision,
                        globalRevision,
                        new Matrix4f(viewProjection),
                        x,
                        y,
                        z,
                        nodes.clone());
        entries.put(pass, entry);
        while (entries.size() > MAX_PASSES) entries.remove(entries.keySet().iterator().next());
        rebuilds++;
        return entry.nodes;
    }

    long hits() {
        return hits;
    }

    long rebuilds() {
        return rebuilds;
    }

    private record Entry(
            WeakReference<Object> area,
            int count,
            long originRevision,
            long globalRevision,
            Matrix4f viewProjection,
            double x,
            double y,
            double z,
            long[] nodes) {}
}
