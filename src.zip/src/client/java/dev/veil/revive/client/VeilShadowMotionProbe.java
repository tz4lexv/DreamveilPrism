package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.state.level.CameraRenderState;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

final class VeilShadowMotionProbe {
    private static final boolean CLOUDS = Boolean.getBoolean("veil.cloudMotionProbe");
    private static final boolean WALK = Boolean.getBoolean("veil.shadowWalkProbe");
    private static final boolean MULTI = WALK && Boolean.getBoolean("veil.shadowMultiplePassProbe");
    private static final boolean QUALITY = Boolean.getBoolean("veil.shadowNearQualityProbe");
    private static final boolean SECONDARY = MULTI || QUALITY;
    private static int secondaryWidth, secondaryHeight;
    private static final boolean NO_CLOUDS = Boolean.getBoolean("veil.shadowNoCloudsProbe");
    private static final boolean ENABLED =
            (Boolean.getBoolean("veil.shadowMotionProbe") || CLOUDS || WALK)
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static boolean pending, complete;
    private static int phase, returned;
    private static long started, phaseReady;
    private static final float[][] depths = new float[3][];
    private static final byte[][] colors = new byte[3][];
    private static int walkingTicks;
    private static float[] baselineMain, baselineShadow, baselineProjection;
    private static double[] baselinePosition;
    private static float firstBobX;
    private static VeilSceneCameraAbi.Snapshot shadowCamera;
    private static VeilSceneCameraAbi.Snapshot secondaryCamera;
    private static org.joml.Matrix4f mainViewRotation;
    private static com.google.gson.JsonObject capturedCamera;
    private static com.google.gson.JsonObject capturedSecondaryCamera;
    private static long capturedMeshRevision, capturedOriginRevision;
    private static int capturedCompileQueue;

    private VeilShadowMotionProbe() {}

    static boolean enabled() {
        return ENABLED;
    }

    static boolean includeLocalPlayer() {
        return !ENABLED || !WALK || (phase != 1 && phase != 3);
    }

    static boolean includeFixtureEntities() {
        return !ENABLED
                || !Boolean.getBoolean("veil.shadowObjectsProbe")
                || (phase != 1 && phase != 3);
    }

    static void secondaryCamera(VeilSceneCameraAbi.Snapshot snapshot) {
        if (ENABLED && SECONDARY) secondaryCamera = snapshot;
    }

    private static int expectedReadbacks() {
        return SECONDARY ? 7 : WALK ? 6 : 5;
    }

    static void sceneCamera(VeilSceneCameraAbi.Snapshot shadow, VeilCameraAbi.Snapshot main) {
        if (!ENABLED) return;
        shadowCamera = shadow;
        mainViewRotation = main.viewRotation();
    }

    static Map<String, String> overrides() {
        if (ENABLED && CLOUDS)
            return Map.of(
                    "enabled",
                    "true",
                    "debugView",
                    "4",
                    "density",
                    "0.05",
                    "coverage",
                    "0.6",
                    "steps",
                    "96");
        return ENABLED
                ? Map.of(
                        "enabled",
                        "true",
                        "debugView",
                        Boolean.getBoolean("veil.shadowNormalViewProbe") ? "0" : "3",
                        "shadowCoverage",
                        "128",
                        "shadowRange",
                        "256",
                        "shadowResolution",
                        "1024",
                        "density",
                        NO_CLOUDS ? "0.0" : "0.05")
                : Map.of();
    }

    static void checkTimeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 300_000_000_000L)
            fail(new IllegalStateException("Execution failed or timed out"));
    }

    static void tick(VeilShaderPackRuntime active, CameraRenderState camera) {
        if (!ENABLED || complete || pending || !VeilBenchmarkWorld.terrainReady()) return;
        long now = System.nanoTime();
        if (phaseReady == 0) phaseReady = now;
        if (now - phaseReady < (phase == 0 ? 60_000_000_000L : 3_000_000_000L)) return;
        if (phase == 0
                && Boolean.getBoolean("veil.shadowSurfaceProbe")
                && !VeilSceneResidentCompiler.settled()) return;
        try {
            if (!Boolean.getBoolean("veil.worldSpaceProbe"))
                throw new IllegalStateException(
                        "Motion probe requires the native bobbing injection");
            capture(active, camera);
        } catch (RuntimeException failure) {
            fail(failure);
        }
    }

    private static Path directory() {
        return VeilPlatform.get()
                .getGameDir()
                .resolve(
                        WALK
                                ? "logs/shadow-walk"
                                : CLOUDS ? "logs/cloud-motion" : "logs/shadow-motion");
    }

    private static void capture(VeilShaderPackRuntime active, CameraRenderState camera) {
        capturedMeshRevision = VeilHostRevisions.mesh();
        capturedOriginRevision = VeilHostRevisions.origin();
        capturedCompileQueue =
                Minecraft.getInstance()
                        .levelRenderer
                        .sectionRenderDispatcher()
                        .getCompileQueueSize();
        pending = true;
        returned = 0;
        int capturedPhase = phase;
        int width = active.output("output").getWidth(0),
                height = active.output("output").getHeight(0);
        int shadowWidth = active.output("shadowDepth").getWidth(0),
                shadowHeight = active.output("shadowDepth").getHeight(0);
        float[] projection = new float[16];
        VeilBenchmarkWorld.worldSpaceProbeProjection.get(projection);
        double[] position = {camera.pos.x, camera.pos.y, camera.pos.z};
        if (shadowCamera == null || mainViewRotation == null)
            throw new IllegalStateException("Native scene camera was not captured");
        var gson = new com.google.gson.Gson();
        capturedCamera = new com.google.gson.JsonObject();
        capturedCamera.add(
                "view_projection",
                gson.toJsonTree(shadowCamera.viewProjection().get(new float[16])));
        capturedCamera.add(
                "main_view_rotation", gson.toJsonTree(mainViewRotation.get(new float[16])));
        capturedCamera.add(
                "anchor",
                gson.toJsonTree(
                        new double[] {
                            shadowCamera.anchorX(), shadowCamera.anchorY(), shadowCamera.anchorZ()
                        }));
        capturedCamera.add(
                "light_direction",
                gson.toJsonTree(
                        new float[] {
                            -shadowCamera.direction().x,
                            -shadowCamera.direction().y,
                            -shadowCamera.direction().z
                        }));
        if (SECONDARY) {
            if (secondaryCamera == null)
                throw new IllegalStateException("Secondary native camera was not captured");
            capturedSecondaryCamera = new com.google.gson.JsonObject();
            capturedSecondaryCamera.add(
                    "view_projection",
                    gson.toJsonTree(secondaryCamera.viewProjection().get(new float[16])));
            capturedSecondaryCamera.add(
                    "anchor",
                    gson.toJsonTree(
                            new double[] {
                                secondaryCamera.anchorX(),
                                secondaryCamera.anchorY(),
                                secondaryCamera.anchorZ()
                            }));
        }
        String secondaryResource = QUALITY ? "shadowDepthNear" : "shadowDepthSecondary";
        if (SECONDARY) {
            secondaryWidth = active.output(secondaryResource).getWidth(0);
            secondaryHeight = active.output(secondaryResource).getHeight(0);
        }
        for (int slot = 0; slot < (SECONDARY ? 6 : WALK ? 5 : 4); slot++) {
            int index = slot;
            boolean shadow = slot == 1 || slot == 5;
            int count =
                    shadow
                            ? Math.multiplyExact(
                                    slot == 5 ? secondaryWidth : shadowWidth,
                                    slot == 5 ? secondaryHeight : shadowHeight)
                            : Math.multiplyExact(width, height);
            long size = (long) count * 4;
            if (size > 64 * 1024 * 1024)
                throw new IllegalStateException("Motion readback exceeds budget");
            var buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil shadow motion readback",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    size);
            try {
                Runnable callback =
                        () -> {
                            try (var mapped = buffer.map(true, false)) {
                                if (index < 2 || index == 5) {
                                    int depthIndex = index == 5 ? 2 : index;
                                    depths[depthIndex] = new float[count];
                                    mapped.data()
                                            .order(ByteOrder.nativeOrder())
                                            .asFloatBuffer()
                                            .get(depths[depthIndex]);
                                } else {
                                    colors[index - 2] = new byte[(int) size];
                                    mapped.data().get(colors[index - 2]);
                                }
                                if (++returned == expectedReadbacks())
                                    verify(
                                            capturedPhase,
                                            width,
                                            height,
                                            shadowWidth,
                                            shadowHeight,
                                            projection,
                                            position);
                            } catch (Exception failure) {
                                fail(failure);
                            } finally {
                                buffer.close();
                                if (returned == expectedReadbacks()) pending = false;
                                if (complete) Minecraft.getInstance().stop();
                            }
                        };
                if (slot < 2)
                    active.readDepthOutput(shadow ? "shadowDepth" : "sceneDepth", buffer, callback);
                else if (slot == 2) active.readOutput("output", buffer, callback);
                else if (slot == 3) active.readPresented(buffer, callback);
                else if (slot == 4) active.readOutput("original", buffer, callback);
                else active.readDepthOutput(secondaryResource, buffer, callback);
            } catch (RuntimeException failure) {
                buffer.close();
                throw failure;
            }
        }
        net.minecraft.client.Screenshot.takeScreenshot(
                Minecraft.getInstance().gameRenderer.mainRenderTarget(),
                image -> {
                    try {
                        Files.createDirectories(directory());
                        image.writeToFile(
                                directory().resolve("phase-" + capturedPhase + "-native.png"));
                        if (++returned == expectedReadbacks())
                            verify(
                                    capturedPhase,
                                    width,
                                    height,
                                    shadowWidth,
                                    shadowHeight,
                                    projection,
                                    position);
                    } catch (Exception failure) {
                        fail(failure);
                    } finally {
                        image.close();
                        if (returned == expectedReadbacks()) pending = false;
                        if (complete) Minecraft.getInstance().stop();
                    }
                });
    }

    private static void verify(
            int capturedPhase,
            int width,
            int height,
            int shadowWidth,
            int shadowHeight,
            float[] projection,
            double[] position)
            throws java.io.IOException {
        Files.createDirectories(directory());
        var captureMetadata = new com.google.gson.JsonObject();
        var captureGson = new com.google.gson.Gson();
        captureMetadata.addProperty("phase", capturedPhase);
        captureMetadata.addProperty("mesh_revision", capturedMeshRevision);
        captureMetadata.addProperty("origin_revision", capturedOriginRevision);
        captureMetadata.addProperty("queued_compiles", capturedCompileQueue);
        captureMetadata.addProperty(
                "texture_animations_enabled", VeilVideoConfig.on("animation.all"));
        captureMetadata.add("position", captureGson.toJsonTree(position));
        captureMetadata.add("contact_fixture", VeilShadowContactFixture.metadata());
        captureMetadata.add("projection", captureGson.toJsonTree(projection));
        captureMetadata.add("scene_camera", capturedCamera);
        if (capturedSecondaryCamera != null)
            captureMetadata.add("secondary_scene_camera", capturedSecondaryCamera);
        Files.writeString(
                directory().resolve("phase-" + capturedPhase + "-capture-metadata.txt"),
                captureMetadata.toString());
        for (int slot = 0; slot < (SECONDARY ? 3 : 2); slot++) {
            ByteBuffer bytes =
                    ByteBuffer.allocate(depths[slot].length * 4).order(ByteOrder.LITTLE_ENDIAN);
            bytes.asFloatBuffer().put(depths[slot]);
            Files.write(
                    directory()
                            .resolve(
                                    "phase-"
                                            + capturedPhase
                                            + (slot == 0
                                                    ? "-main.f32"
                                                    : slot == 1
                                                            ? "-shadow.f32"
                                                            : "-secondary.f32")),
                    bytes.array());
        }
        saveColor(
                directory().resolve("phase-" + capturedPhase + "-presented.png"),
                colors[1],
                width,
                height);
        if (WALK)
            saveColor(
                    directory().resolve("phase-" + capturedPhase + "-original.png"),
                    colors[2],
                    width,
                    height);
        int mainGeometry = 0, shadowGeometry = 0, mainChanged = 0, shadowChanged = 0;
        boolean contactFixture =
                System.getProperty("veil.benchmarkScene", "plain").equals("shadowcontact");
        int comparisonTexels = contactFixture ? 256 * 256 : depths[1].length;
        double shadowError = 0;
        float projectionChange = 0;
        for (int slot = 0; slot < 2; slot++)
            for (int i = 0; i < depths[slot].length; i++) {
                float value = depths[slot][i];
                if (!Float.isFinite(value) || value < 0 || value > 1)
                    throw new IllegalStateException("Invalid motion depth");
                if (value > 0) {
                    if (slot == 0) mainGeometry++;
                    else shadowGeometry++;
                }
                float[] baseline = slot == 0 ? baselineMain : baselineShadow;
                if (baseline != null) {
                    double difference = Math.abs(value - baseline[i]);
                    if (slot == 0 && difference > 0.000001) mainChanged++;
                    if (slot == 1) {
                        if (contactFixture
                                && (i % shadowWidth < 384
                                        || i % shadowWidth >= 640
                                        || i / shadowWidth < 384
                                        || i / shadowWidth >= 640)) continue;
                        shadowError += difference;
                        if (difference > 0.0001) shadowChanged++;
                    }
                }
            }
        if ((!CLOUDS && mainGeometry < 100) || shadowGeometry < 100)
            throw new IllegalStateException("Motion depth coverage insufficient");
        if (Boolean.getBoolean("veil.shadowSurfaceProbe") && baselineShadow != null) {
            var samples = new com.google.gson.JsonArray();
            var level = Minecraft.getInstance().level;
            for (int i = 0; i < depths[1].length && samples.size() < 64; i++) {
                if (Math.abs(depths[1][i] - baselineShadow[i]) <= 0.0001) continue;
                if (i % shadowWidth < 384
                        || i % shadowWidth >= 640
                        || i / shadowWidth < 384
                        || i / shadowWidth >= 640) continue;
                var point =
                        new org.joml.Vector4f(
                                (i % shadowWidth + 0.5f) / shadowWidth * 2 - 1,
                                (i / shadowWidth + 0.5f) / shadowHeight * 2 - 1,
                                baselineShadow[i],
                                1);
                shadowCamera.inverseViewProjection().transform(point);
                double x = point.x / point.w + shadowCamera.anchorX();
                double y = point.y / point.w + shadowCamera.anchorY();
                double z = point.z / point.w + shadowCamera.anchorZ();
                var positionBlock = net.minecraft.core.BlockPos.containing(x, y, z);
                var sample = new com.google.gson.JsonObject();
                sample.add("world_position", captureGson.toJsonTree(new double[] {x, y, z}));
                sample.addProperty(
                        "block",
                        net.minecraft.core.registries.BuiltInRegistries.BLOCK
                                .getKey(level.getBlockState(positionBlock).getBlock())
                                .toString());
                var neighbors = new com.google.gson.JsonArray();
                for (var direction : net.minecraft.core.Direction.values())
                    neighbors.add(
                            net.minecraft.core.registries.BuiltInRegistries.BLOCK
                                    .getKey(
                                            level.getBlockState(positionBlock.relative(direction))
                                                    .getBlock())
                                    .toString());
                sample.add("neighbors", neighbors);
                samples.add(sample);
            }
            Files.writeString(
                    directory().resolve("phase-" + capturedPhase + "-changed-blocks.txt"),
                    samples.toString());
        }
        for (int i = 0; i < colors[0].length; i++)
            if (Math.abs(Byte.toUnsignedInt(colors[0][i]) - Byte.toUnsignedInt(colors[1][i])) > 2)
                throw new IllegalStateException("Motion output differs from presentation");
        if (baselineProjection != null) {
            for (int i = 0; i < 16; i++)
                projectionChange =
                        Math.max(projectionChange, Math.abs(projection[i] - baselineProjection[i]));
            if (!WALK)
                for (int i = 0; i < 3; i++)
                    if (Math.abs(position[i] - baselinePosition[i]) > 0.000001)
                        throw new IllegalStateException("Motion fixture main position moved");
            if (!CLOUDS
                    && !WALK
                    && (shadowChanged > comparisonTexels / 1000
                            || shadowError / comparisonTexels > 0.000001))
                throw new IllegalStateException(
                        "Shadow depth changed during motion: pixels="
                                + shadowChanged
                                + " meanError="
                                + shadowError / comparisonTexels);
            if (!WALK && (capturedPhase == 2 || capturedPhase == 3)) {
                if (projectionChange < 0.0001 || (!CLOUDS && mainChanged < 100))
                    throw new IllegalStateException(
                            "Native bobbing did not change projection and scene depth");
                float horizontalShift = projection[12] - baselineProjection[12];
                if (capturedPhase == 2) firstBobX = horizontalShift;
                else if (firstBobX * horizontalShift >= 0 || Math.abs(horizontalShift) < 0.00001)
                    throw new IllegalStateException(
                            "Bobbing phases did not shift projection in opposite directions");
            } else if (!WALK && projectionChange > 0.000001)
                throw new IllegalStateException("Stationary/restored projection changed");
        }
        var report = new com.google.gson.JsonObject();
        report.addProperty("phase", capturedPhase);
        report.addProperty("width", width);
        report.addProperty("height", height);
        report.addProperty("shadow_width", shadowWidth);
        report.addProperty("shadow_height", shadowHeight);
        report.addProperty("main_geometry_pixels", mainGeometry);
        report.addProperty("shadow_geometry_pixels", shadowGeometry);
        report.addProperty("main_changed_pixels", mainChanged);
        report.addProperty("shadow_changed_pixels", shadowChanged);
        report.addProperty("shadow_mean_error", shadowError / comparisonTexels);
        report.addProperty("shadow_comparison_texels", comparisonTexels);
        if (contactFixture)
            report.add(
                    "shadow_comparison_region",
                    new com.google.gson.Gson().toJsonTree(new int[] {384, 384, 640, 640}));
        report.addProperty("projection_max_change", projectionChange);
        report.add("projection", new com.google.gson.Gson().toJsonTree(projection));
        report.add("position", new com.google.gson.Gson().toJsonTree(position));
        report.add("contact_fixture", VeilShadowContactFixture.metadata());
        report.addProperty("camera_type", Minecraft.getInstance().options.getCameraType().name());
        report.addProperty(
                "vanilla_entity_shadows", Minecraft.getInstance().options.entityShadows().get());
        report.add("scene_camera", capturedCamera.deepCopy());
        report.addProperty("cloud_transmission_view", CLOUDS);
        report.addProperty("shadow_normal_view", Boolean.getBoolean("veil.shadowNormalViewProbe"));
        report.addProperty("multiple_shadow_passes", SECONDARY);
        report.addProperty("near_shadow_quality", QUALITY);
        if (SECONDARY) {
            report.addProperty("secondary_width", secondaryWidth);
            report.addProperty("secondary_height", secondaryHeight);
        }
        if (SECONDARY) report.add("secondary_scene_camera", capturedSecondaryCamera.deepCopy());
        report.addProperty("fixture_objects", Boolean.getBoolean("veil.shadowObjectsProbe"));
        report.addProperty("fixture_casters_enabled", includeFixtureEntities());
        if (WALK) {
            var player = Minecraft.getInstance().player;
            report.addProperty("walk_probe", true);
            report.addProperty("walking_input_ticks", walkingTicks);
            report.addProperty("player_on_ground", player.onGround());
            report.addProperty("local_player_caster", includeLocalPlayer());
            report.add(
                    "player_position",
                    new com.google.gson.Gson()
                            .toJsonTree(
                                    new double[] {player.getX(), player.getY(), player.getZ()}));
            if (capturedPhase >= 2
                    && (walkingTicks != 12 || Math.abs(position[0] - baselinePosition[0]) < 1))
                throw new IllegalStateException(
                        "Walking input did not move the player sufficiently");
        }
        if (NO_CLOUDS)
            report.addProperty(
                    "vanilla_cloud_status",
                    Minecraft.getInstance().options.cloudStatus().get().name());
        if (CLOUDS)
            report.addProperty(
                    "vanilla_cloud_status",
                    Minecraft.getInstance().options.cloudStatus().get().name());
        Files.writeString(
                directory().resolve("phase-" + capturedPhase + ".json"), report.toString());
        ReviveMod.LOGGER.info(
                "Veil shadow motion: phase={} mainChanged={} shadowChanged={} meanShadowError={} projectionChange={}",
                capturedPhase,
                mainChanged,
                shadowChanged,
                shadowError / comparisonTexels,
                projectionChange);
        if (capturedPhase == 0) {
            baselineMain = depths[0];
            baselineShadow = depths[1];
            baselineProjection = projection;
            baselinePosition = position;
        }
        phase++;
        VeilBenchmarkWorld.worldSpaceProbePhase = WALK ? 0 : phase == 2 ? 1 : phase == 3 ? 2 : 0;
        if (WALK && phase == 2) {
            Minecraft.getInstance().player.input =
                    new net.minecraft.client.player.ClientInput() {
                        @Override
                        public void tick() {
                            boolean forward = walkingTicks < 12;
                            keyPresses =
                                    new net.minecraft.world.entity.player.Input(
                                            forward, false, false, false, false, false, false);
                            moveVector =
                                    forward
                                            ? net.minecraft.world.phys.Vec2.UNIT_Y
                                            : net.minecraft.world.phys.Vec2.ZERO;
                            if (forward) walkingTicks++;
                        }
                    };
        }
        phaseReady = System.nanoTime();
        if (phase == 5) {
            complete = true;
            if (WALK) {
                if (Boolean.getBoolean("veil.shadowTerrainBuilderProbe")) {
                    VeilOwnSectionCompiler.requireComplete();
                    VeilBlockModelRenderer.requireComplete();
                }
                VeilBenchmarkWorld.finishGraphicsProbe();
                ReviveMod.LOGGER.info(
                        "Veil shadow walk capture: PASS (actual walking input, player caster controls and presentation; world anchoring requires independent verification)");
                return;
            }
            if (CLOUDS) {
                VeilBenchmarkWorld.finishGraphicsProbe();
                ReviveMod.LOGGER.info(
                        "Veil cloud motion capture: PASS (native bobbing, restored projection and presentation; anchoring requires independent image verification)");
                return;
            }
            ReviveMod.LOGGER.info(
                    "Veil shadow motion: PASS (stationary control, two native bobbing phases, restored projection, main depth response, stable {} and presentation)",
                    contactFixture ? "controlled shadow region" : "full shadow depth");
        }
    }

    private static void saveColor(Path path, byte[] pixels, int width, int height)
            throws java.io.IOException {
        var image =
                new java.awt.image.BufferedImage(
                        width, height, java.awt.image.BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++) {
                int offset = (y * width + x) * 4;
                image.setRGB(
                        x,
                        height - 1 - y,
                        Byte.toUnsignedInt(pixels[offset]) << 16
                                | Byte.toUnsignedInt(pixels[offset + 1]) << 8
                                | Byte.toUnsignedInt(pixels[offset + 2]));
            }
        if (!javax.imageio.ImageIO.write(image, "png", path.toFile()))
            throw new java.io.IOException("PNG encoder unavailable");
    }

    private static void fail(Exception failure) {
        complete = true;
        VeilBenchmarkWorld.worldSpaceProbePhase = 0;
        if (CLOUDS || WALK) VeilBenchmarkWorld.finishGraphicsProbe();
        ReviveMod.LOGGER.error(
                CLOUDS ? "Veil cloud motion capture: FAIL" : "Veil shadow motion: FAIL", failure);
        Minecraft.getInstance().stop();
    }
}
