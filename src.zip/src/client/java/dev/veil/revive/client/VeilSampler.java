package dev.veil.revive.client;

import dev.veil.revive.client.graphics.resources.NativeSampler;

final class VeilSampler extends NativeSampler {
    private VeilSampler(VeilVulkanRuntime runtime, long handle) {
        super(runtime, handle);
    }

    static VeilSampler create(
            VeilVulkanRuntime runtime, VeilShaderPack.Sampler sampler, String label) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        var parameters =
                dev.veil.revive.client.shaderpack.preparation.ImageResourceInputs.sampler(sampler);
        return new VeilSampler(runtime, createHandle(runtime, parameters, label));
    }

    long handle() {
        return nativeHandle();
    }

    @Override
    public void close() {
        super.close();
    }

    static int filter(VeilShaderPack.SampleFilter filter) {
        return dev.veil.revive.client.shaderpack.preparation.ImageResourceInputs.filterValue(
                filter);
    }

    static int mipmapMode(VeilShaderPack.SampleFilter filter) {
        return dev.veil.revive.client.shaderpack.preparation.ImageResourceInputs.mipmapValue(
                filter);
    }

    static int address(VeilShaderPack.SampleAddress mode) {
        return dev.veil.revive.client.shaderpack.preparation.ImageResourceInputs.addressValue(mode);
    }
}
