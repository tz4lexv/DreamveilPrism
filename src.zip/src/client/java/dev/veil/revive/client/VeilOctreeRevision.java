package dev.veil.revive.client;

public interface VeilOctreeRevision {
    long veil$contentRevision();
}
