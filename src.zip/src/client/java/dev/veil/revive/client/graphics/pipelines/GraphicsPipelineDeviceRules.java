package dev.veil.revive.client.graphics.pipelines;

/** Device-dependent graphics-state rules shared by the Vulkan backend and CPU smoke tests. */
public final class GraphicsPipelineDeviceRules {
    private GraphicsPipelineDeviceRules() {}

    /** Validate that the shaderpack does not request a raster line width the device cannot use. */
    public static void validateLineWidth(
            float lineWidth, boolean wideLinesEnabled, float minWidth, float maxWidth) {
        if (!Float.isFinite(lineWidth) || lineWidth <= 0) {
            throw new IllegalArgumentException(
                    "Invalid graphics pipeline line width: " + lineWidth);
        }
        if (!wideLinesEnabled && lineWidth != 1.0f) {
            throw new IllegalArgumentException("Graphics pipeline requires enabled wideLines");
        }
        if (wideLinesEnabled && (lineWidth < minWidth || lineWidth > maxWidth)) {
            throw new IllegalArgumentException(
                    "Graphics pipeline lineWidth="
                            + lineWidth
                            + " is outside the device range ["
                            + minWidth
                            + ", "
                            + maxWidth
                            + "]");
        }
    }

    /** Core Vulkan primitive restart is valid for strip topologies without optional extensions. */
    public static void validatePrimitiveRestart(boolean enabled, boolean stripTopology) {
        if (enabled && !stripTopology) {
            throw new IllegalArgumentException(
                    "primitiveRestart requires a strip topology (lineStrip or triangleStrip)");
        }
    }

    /** Check the live attachment format's COLOR_ATTACHMENT_BLEND support only when blending. */
    public static void validateColorBlend(int attachment, boolean enabled, boolean supported) {
        if (attachment < 0) throw new IllegalArgumentException("Negative color attachment index");
        if (enabled && !supported) {
            throw new IllegalArgumentException(
                    "Color attachment "
                            + attachment
                            + " enables blending but its Vulkan format lacks COLOR_ATTACHMENT_BLEND");
        }
    }

    /** Color attachments and their pipeline blend states must have matching arity. */
    public static void validateAttachmentCount(int formats, int states) {
        if (formats < 0 || states < 0 || formats != states) {
            throw new IllegalArgumentException(
                    "Graphics pipeline color attachment count mismatch: formats="
                            + formats
                            + " blendStates="
                            + states);
        }
    }
}
