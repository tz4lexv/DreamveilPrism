package dev.veil.revive.client;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.mixin.ViewAreaSectionsAccessor;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

public final class VeilSceneTerrainSelection {
    private static final boolean ENABLED =
            Boolean.parseBoolean(System.getProperty("veil.sceneResidentSelection", "true"));
    private static final VeilSceneSelectionCache CACHE = new VeilSceneSelectionCache();
    private static LevelRenderer owner;
    private static ObjectArrayList<SectionRenderDispatcher.RenderSection> selected;
    private static boolean verified;

    private VeilSceneTerrainSelection() {}

    static ChunkSectionsToRender prepare(
            LevelRenderer renderer, VeilSceneCameraAbi.Snapshot camera, String pass) {
        RenderSystem.assertOnRenderThread();
        var area = renderer.viewArea();
        if (!ENABLED || area == null) return prepareScoped(renderer, camera, null);
        var resident = ((ViewAreaSectionsAccessor) area).veil$sections();
        long[] nodes =
                CACHE.select(
                        pass,
                        area,
                        resident.size(),
                        VeilHostRevisions.origin(),
                        VeilHostRevisions.global(),
                        camera.viewProjection(),
                        camera.anchorX(),
                        camera.anchorY(),
                        camera.anchorZ(),
                        () -> {
                            var frustum =
                                    new VeilSceneSectionFrustum(
                                            camera.viewProjection(),
                                            camera.anchorX(),
                                            camera.anchorY(),
                                            camera.anchorZ());
                            var result = new LongArrayList();
                            for (var section : resident) {
                                if (section == null) continue;
                                var origin = section.getRenderOrigin();
                                if (frustum.intersects(origin.getX(), origin.getY(), origin.getZ()))
                                    result.add(section.getSectionNode());
                            }
                            return result.toLongArray();
                        });
        var sections = new ObjectArrayList<SectionRenderDispatcher.RenderSection>(nodes.length);
        for (long node : nodes) {
            var section = resident.getValue(node);
            if (section != null) sections.add(section);
        }
        VeilSceneResidentCompiler.schedule(pass, sections);
        if (!verified
                && Boolean.getBoolean("veil.verifySceneResidentSelection")
                && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment()) {
            var main =
                    new java.util.IdentityHashMap<SectionRenderDispatcher.RenderSection, Boolean>();
            for (var section : renderer.visibleSections()) main.put(section, Boolean.TRUE);
            int extra = 0;
            for (var section : sections) {
                var mesh = section.getSectionMesh();
                if (!main.containsKey(section)
                        && (mesh.getSectionDraw(
                                                net.minecraft.client.renderer.chunk
                                                        .ChunkSectionLayer.SOLID)
                                        != null
                                || mesh.getSectionDraw(
                                                net.minecraft.client.renderer.chunk
                                                        .ChunkSectionLayer.CUTOUT)
                                        != null)) extra++;
            }
            if (!main.isEmpty() && extra > 0 && CACHE.hits() > 0) {
                verified = true;
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil scene resident selection: PASS ({} candidates, {} compiled outside {} main sections, {} cache hits, {} rebuilds)",
                        sections.size(),
                        extra,
                        main.size(),
                        CACHE.hits(),
                        CACHE.rebuilds());
            }
        }
        return prepareScoped(renderer, camera, sections);
    }

    private static ChunkSectionsToRender prepareScoped(
            LevelRenderer renderer,
            VeilSceneCameraAbi.Snapshot camera,
            ObjectArrayList<SectionRenderDispatcher.RenderSection> sections) {
        var previousOwner = owner;
        var previousSelection = selected;
        owner = renderer;
        selected = sections;
        try {
            return renderer.prepareChunkRenders(camera.view());
        } finally {
            owner = previousOwner;
            selected = previousSelection;
        }
    }

    public static ObjectArrayList<SectionRenderDispatcher.RenderSection> sections(
            LevelRenderer renderer,
            ObjectArrayList<SectionRenderDispatcher.RenderSection> original) {
        return owner == renderer && selected != null ? selected : original;
    }

    public static boolean active(LevelRenderer renderer) {
        return owner == renderer && selected != null;
    }

    public static boolean preparing(LevelRenderer renderer) {
        return owner == renderer;
    }
}
