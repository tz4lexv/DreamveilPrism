package dev.veil.revive.mixin;

import dev.veil.revive.ReviveMod;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.locks.ReentrantLock;

@Mixin(SectionRenderDispatcher.class)
public abstract class SectionPublicationFairLockMixin {
    @Shadow @Final private ReentrantLock copyLock;

    @Redirect(
            method = "<init>",
            at = @At(value = "NEW", target = "java/util/concurrent/locks/ReentrantLock"),
            require = 1)
    private static ReentrantLock veil$createFairPublicationLock() {
        return new ReentrantLock(true);
    }

    @Inject(method = "<init>", at = @At("RETURN"), require = 1)
    private void veil$verifyFairPublicationLock(CallbackInfo callback) {
        if (!copyLock.isFair())
            throw new IllegalStateException("Publication lock experiment did not apply");
        ReviveMod.LOGGER.info("Veil experimental publication lock ACTIVE: fair=true");
    }
}
