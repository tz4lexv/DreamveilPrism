package dev.veil.revive.client;

import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

import net.minecraft.client.renderer.Lightmap;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class VeilShadowReceiverCache {
    private static final int DEFAULT_MAX_ENTRIES = 65_536;
    private static final ThreadLocal<FrameCache> CACHE = ThreadLocal.withInitial(FrameCache::new);

    private static long queries;
    private static long hits;
    private static long misses;
    private static long brightnessHits;
    private static long brightnessMisses;
    private static long piecesProduced;
    private static long ineligibleReceivers;
    private static long cacheClears;

    private VeilShadowReceiverCache() {}

    public static boolean enabled() {
        return VeilLightingPipeline.enabled()
                && VeilVideoConfig.flag("renderer.shadowReceiverCache", true);
    }

    public static void beginFrame() {
        FrameCache cache = CACHE.get();
        cache.sectionRevisions.clear();
        cache.lightSectionRevisions.clear();
    }

    public static boolean extract(
            EntityRenderState state,
            Level level,
            float power,
            BlockPos.MutableBlockPos pos,
            ChunkAccess chunk) {
        if (!enabled()) return false;

        queries++;
        FrameCache cache = CACHE.get();
        int belowX = pos.getX();
        int belowY = pos.getY() - 1;
        int belowZ = pos.getZ();
        long key = BlockPos.asLong(belowX, belowY, belowZ);
        long revisionStamp = revisionStamp(cache, belowX, belowY, belowZ);

        Receiver receiver = cache.receivers.get(key);
        if (receiver != null && receiver.revisionStamp == revisionStamp) {
            hits++;
        } else {
            misses++;
            BlockPos.MutableBlockPos below = cache.belowPos;
            below.set(belowX, belowY, belowZ);
            BlockState belowState = chunk.getBlockState(below);
            boolean eligible = false;
            VoxelShape shape = null;

            if (belowState.getRenderShape() != RenderShape.INVISIBLE
                    && belowState.isCollisionShapeFullBlock(chunk, below)) {
                VoxelShape candidate = belowState.getShape(chunk, below);
                if (!candidate.isEmpty()) {
                    eligible = true;
                    shape = candidate;
                }
            }

            receiver = new Receiver(revisionStamp, eligible, shape);
            cache.receivers.put(key, receiver);
            if (!eligible) ineligibleReceivers++;

            int maxEntries =
                    VeilVideoConfig.number(
                            "renderer.shadowReceiverCacheEntries",
                            DEFAULT_MAX_ENTRIES,
                            4_096,
                            262_144);
            if (cache.receivers.size() > maxEntries) {
                cache.receivers.clear();
                cacheClears++;

                cache.receivers.put(key, receiver);
            }
        }

        if (!receiver.eligible) return true;

        long brightnessRevision =
                mix(
                        lightRevision(cache, pos.getX() >> 4, pos.getY() >> 4, pos.getZ() >> 4)
                                ^ (long) level.getSkyDarken() * 0x9e3779b97f4a7c15L);
        int brightness;
        if (receiver.brightnessRevision == brightnessRevision) {
            brightness = receiver.brightness;
            brightnessHits++;
        } else {
            brightness = level.getMaxLocalRawBrightness(pos);
            receiver.brightness = brightness;
            receiver.brightnessRevision = brightnessRevision;
            brightnessMisses++;
        }

        if (brightness <= 3) return true;

        float powerAtDepth = power - (float) (state.y - pos.getY()) * 0.5F;
        float alpha =
                Mth.clamp(
                        powerAtDepth
                                * 0.5F
                                * Lightmap.getBrightness(level.dimensionType(), brightness),
                        0.0F,
                        1.0F);
        float relativeX = (float) (pos.getX() - state.x);
        float relativeY = (float) (pos.getY() - state.y);
        float relativeZ = (float) (pos.getZ() - state.z);
        state.shadowPieces.add(
                new EntityRenderState.ShadowPiece(
                        relativeX, relativeY, relativeZ, receiver.shape, alpha));
        piecesProduced++;
        return true;
    }

    private static long revisionStamp(FrameCache cache, int blockX, int blockY, int blockZ) {
        int sx = blockX >> 4;
        int sy = blockY >> 4;
        int sz = blockZ >> 4;
        long h = mix(revision(cache, sx, sy, sz) ^ SectionPos.asLong(sx, sy, sz));

        int lx = blockX & 15;
        int ly = blockY & 15;
        int lz = blockZ & 15;
        if (lx == 0) h = combine(h, sx - 1, sy, sz, cache);
        else if (lx == 15) h = combine(h, sx + 1, sy, sz, cache);
        if (ly == 0) h = combine(h, sx, sy - 1, sz, cache);
        else if (ly == 15) h = combine(h, sx, sy + 1, sz, cache);
        if (lz == 0) h = combine(h, sx, sy, sz - 1, cache);
        else if (lz == 15) h = combine(h, sx, sy, sz + 1, cache);
        return h;
    }

    private static long combine(long h, int sx, int sy, int sz, FrameCache cache) {
        long node = SectionPos.asLong(sx, sy, sz);
        return mix(h ^ node ^ revision(cache, sx, sy, sz));
    }

    private static long revision(FrameCache cache, int sx, int sy, int sz) {
        long node = SectionPos.asLong(sx, sy, sz);
        if (cache.sectionRevisions.containsKey(node)) {
            return cache.sectionRevisions.get(node);
        }
        long revision = VeilMinecraftTerrainBridge.geometrySectionRevision(node);
        cache.sectionRevisions.put(node, revision);
        return revision;
    }

    private static long lightRevision(FrameCache cache, int sx, int sy, int sz) {
        long node = SectionPos.asLong(sx, sy, sz);
        if (cache.lightSectionRevisions.containsKey(node)) {
            return cache.lightSectionRevisions.get(node);
        }
        long revision = VeilLightingPipeline.lightSectionRevision(node);
        cache.lightSectionRevisions.put(node, revision);
        return revision;
    }

    private static long mix(long z) {
        z ^= z >>> 33;
        z *= 0xff51afd7ed558ccdl;
        z ^= z >>> 33;
        z *= 0xc4ceb9fe1a85ec53l;
        return z ^ (z >>> 33);
    }

    public static void clear() {
        CACHE.remove();
        cacheClears++;
    }

    public static String telemetry() {
        long total = hits + misses;
        double hitRate = total == 0L ? 0.0 : (double) hits / (double) total;
        long brightnessTotal = brightnessHits + brightnessMisses;
        double brightnessHitRate =
                brightnessTotal == 0L ? 0.0 : (double) brightnessHits / (double) brightnessTotal;
        return "shadow_receiver_queries_total="
                + queries
                + "\nshadow_receiver_cache_hits_total="
                + hits
                + "\nshadow_receiver_cache_misses_total="
                + misses
                + "\nshadow_receiver_cache_hit_rate="
                + String.format(java.util.Locale.ROOT, "%.4f", hitRate)
                + "\nshadow_receiver_brightness_hits_total="
                + brightnessHits
                + "\nshadow_receiver_brightness_misses_total="
                + brightnessMisses
                + "\nshadow_receiver_brightness_hit_rate="
                + String.format(java.util.Locale.ROOT, "%.4f", brightnessHitRate)
                + "\nshadow_receiver_ineligible_total="
                + ineligibleReceivers
                + "\nshadow_receiver_pieces_total="
                + piecesProduced
                + "\nshadow_receiver_cache_clears_total="
                + cacheClears
                + "\nshadow_receiver_cache_entries_current="
                + CACHE.get().receivers.size()
                + "\n";
    }

    private static final class FrameCache {
        final Long2ObjectOpenHashMap<Receiver> receivers = new Long2ObjectOpenHashMap<>();
        final Long2LongOpenHashMap sectionRevisions = new Long2LongOpenHashMap();
        final Long2LongOpenHashMap lightSectionRevisions = new Long2LongOpenHashMap();
        final BlockPos.MutableBlockPos belowPos = new BlockPos.MutableBlockPos();
    }

    private static final class Receiver {
        final long revisionStamp;
        final boolean eligible;
        final VoxelShape shape;
        long brightnessRevision = Long.MIN_VALUE;
        int brightness;

        Receiver(long revisionStamp, boolean eligible, VoxelShape shape) {
            this.revisionStamp = revisionStamp;
            this.eligible = eligible;
            this.shape = shape;
        }
    }
}
