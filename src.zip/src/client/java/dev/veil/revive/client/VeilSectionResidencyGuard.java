package dev.veil.revive.client;

import dev.veil.revive.core.terrain.PendingSectionResidency;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import java.util.List;

public final class VeilSectionResidencyGuard {
    private static final PendingSectionResidency<SectionRenderDispatcher.RenderSection> GUARD =
            new PendingSectionResidency<>(
                    VeilSectionResidencyGuard.class,
                    section -> hasGeometry(section.getSectionMesh()));

    private VeilSectionResidencyGuard() {}

    public static synchronized void markRelocated(SectionRenderDispatcher.RenderSection section) {
        GUARD.markRelocated(section);
    }

    public static synchronized void markMeshInstalled(
            SectionRenderDispatcher.RenderSection section) {
        GUARD.markMeshInstalled(section);
    }

    public static List<SectionRenderDispatcher.RenderSection> filterReady(
            List<SectionRenderDispatcher.RenderSection> visible) {
        return GUARD.filterReady(visible);
    }

    public static synchronized void clear() {
        GUARD.clear();
    }

    public static synchronized String telemetry() {
        return GUARD.telemetry();
    }

    private static boolean hasGeometry(SectionMesh mesh) {
        if (mesh == null) return false;
        for (ChunkSectionLayer layer : ChunkSectionLayer.values()) {
            if (mesh.getSectionDraw(layer) != null) return true;
        }
        return false;
    }
}
