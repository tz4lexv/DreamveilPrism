package dev.veil.revive.client;

import static org.lwjgl.vulkan.KHRAccelerationStructure.*;
import static org.lwjgl.vulkan.KHRRayQuery.*;
import static org.lwjgl.vulkan.KHRRayTracingPipeline.*;
import static org.lwjgl.vulkan.VK11.*;

import com.mojang.blaze3d.vulkan.VulkanPhysicalDevice;
import com.mojang.blaze3d.vulkan.init.VulkanFeature;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;

import java.util.Collection;
import java.util.Set;

public final class VeilRayCapabilities {
    private VeilRayCapabilities() {}

    public static void request(
            VulkanPhysicalDevice physical,
            Collection<String> extensions,
            Set<VulkanFeature> features) {
        dev.veil.revive.client.raytracing.RayDeviceCapabilities.request(
                physical, extensions, features);
    }

    public static boolean rayQuery() {
        return dev.veil.revive.client.raytracing.RayDeviceCapabilities.rayQuery();
    }

    public static boolean accelerationStructures() {
        return dev.veil.revive.client.raytracing.RayDeviceCapabilities.accelerationStructures();
    }

    public static boolean rayPipeline() {
        return dev.veil.revive.client.raytracing.RayDeviceCapabilities.rayPipeline();
    }

    public static void validateTraceDimensions(VeilVulkanRuntime runtime, int[] dimensions) {
        if (dimensions.length != 3 || dimensions[0] < 1 || dimensions[1] < 1 || dimensions[2] < 1) {
            throw new IllegalArgumentException(
                    "Ray trace dimensions must be positive x/y/z values");
        }
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var properties =
                    VkPhysicalDeviceRayTracingPipelinePropertiesKHR.calloc(stack).sType$Default();
            vkGetPhysicalDeviceProperties2(
                    runtime.vkDevice().getPhysicalDevice(),
                    VkPhysicalDeviceProperties2.calloc(stack)
                            .sType$Default()
                            .pNext(properties.address()));
            long invocations =
                    Math.multiplyExact(
                            Math.multiplyExact((long) dimensions[0], dimensions[1]), dimensions[2]);
            if (invocations > Integer.toUnsignedLong(properties.maxRayDispatchInvocationCount())) {
                throw new IllegalArgumentException(
                        "Ray trace invocation count="
                                + invocations
                                + " exceeds device limit="
                                + Integer.toUnsignedLong(
                                        properties.maxRayDispatchInvocationCount()));
            }
        }
    }

    public static void validateDescriptors(
            VeilVulkanRuntime runtime,
            java.util.List<VeilPipelineLayout.DescriptorBinding> bindings) {
        var acceleration =
                bindings.stream()
                        .filter(
                                value ->
                                        value.descriptorType()
                                                == VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR)
                        .toList();
        if (acceleration.isEmpty()) return;
        if (!accelerationStructures())
            throw new IllegalStateException(
                    "Acceleration-structure descriptors require enabled Vulkan acceleration-structure capabilities");
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var props =
                    VkPhysicalDeviceAccelerationStructurePropertiesKHR.calloc(stack)
                            .sType$Default();
            vkGetPhysicalDeviceProperties2(
                    runtime.vkDevice().getPhysicalDevice(),
                    VkPhysicalDeviceProperties2.calloc(stack)
                            .sType$Default()
                            .pNext(props.address()));
            long total =
                    acceleration.stream()
                            .mapToLong(VeilPipelineLayout.DescriptorBinding::descriptorCount)
                            .sum();
            if (total > props.maxDescriptorSetAccelerationStructures())
                throw new IllegalArgumentException("Ray descriptors exceed device set limit");
            for (int stage :
                    new int[] {
                        VK_SHADER_STAGE_VERTEX_BIT,
                        VK_SHADER_STAGE_FRAGMENT_BIT,
                        VK_SHADER_STAGE_COMPUTE_BIT,
                        VK_SHADER_STAGE_RAYGEN_BIT_KHR,
                        VK_SHADER_STAGE_MISS_BIT_KHR,
                        VK_SHADER_STAGE_CLOSEST_HIT_BIT_KHR,
                        VK_SHADER_STAGE_ANY_HIT_BIT_KHR,
                        VK_SHADER_STAGE_INTERSECTION_BIT_KHR,
                        VK_SHADER_STAGE_CALLABLE_BIT_KHR
                    }) {
                long count =
                        acceleration.stream()
                                .filter(value -> (value.stageFlags() & stage) != 0)
                                .mapToLong(VeilPipelineLayout.DescriptorBinding::descriptorCount)
                                .sum();
                if (count > props.maxPerStageDescriptorAccelerationStructures())
                    throw new IllegalArgumentException("Ray descriptors exceed device stage limit");
            }
        }
    }

    public static String report() {
        return dev.veil.revive.client.raytracing.RayDeviceCapabilities.report();
    }
}
