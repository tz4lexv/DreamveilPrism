package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;

import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.level.material.FogType;

import org.joml.Matrix4f;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

public final class VeilCameraAbi {
    public static final int VERSION = 1;
    public static final int SET = 0;
    public static final int BINDING = 15;
    public static final int SIZE = 624;
    public static final int PROJECTION_OFFSET = 0;
    public static final int INVERSE_PROJECTION_OFFSET = 64;
    public static final int VIEW_ROTATION_OFFSET = 128;
    public static final int INVERSE_VIEW_ROTATION_OFFSET = 192;
    public static final int PREVIOUS_PROJECTION_OFFSET = 256;
    public static final int PREVIOUS_INVERSE_PROJECTION_OFFSET = 320;
    public static final int PREVIOUS_VIEW_ROTATION_OFFSET = 384;
    public static final int PREVIOUS_INVERSE_VIEW_ROTATION_OFFSET = 448;
    public static final int CAMERA_POSITION_HIGH_OFFSET = 512;
    public static final int CAMERA_POSITION_LOW_OFFSET = 528;
    public static final int PREVIOUS_CAMERA_POSITION_HIGH_OFFSET = 544;
    public static final int PREVIOUS_CAMERA_POSITION_LOW_OFFSET = 560;
    public static final int VIEWPORT_OFFSET = 576;
    public static final int PARAMS_OFFSET = 592;
    public static final int ANGLES_OFFSET = 608;

    public static final int MEDIUM_NONE = 0;
    public static final int MEDIUM_WATER = 1;
    public static final int MEDIUM_LAVA = 2;
    public static final int MEDIUM_POWDER_SNOW = 3;

    public record Snapshot(
            Matrix4f projection,
            Matrix4f inverseProjection,
            Matrix4f viewRotation,
            Matrix4f inverseViewRotation,
            double x,
            double y,
            double z,
            float depthFar,
            float hudFov,
            float yRot,
            float xRot,
            boolean panoramic,
            int medium) {
        public Snapshot {
            projection = new Matrix4f(projection);
            inverseProjection = new Matrix4f(inverseProjection);
            viewRotation = new Matrix4f(viewRotation);
            inverseViewRotation = new Matrix4f(inverseViewRotation);
            if (!Double.isFinite(x)
                    || !Double.isFinite(y)
                    || !Double.isFinite(z)
                    || !Float.isFinite(depthFar)
                    || !Float.isFinite(hudFov)
                    || !Float.isFinite(yRot)
                    || !Float.isFinite(xRot)
                    || medium < MEDIUM_NONE
                    || medium > MEDIUM_POWDER_SNOW) {
                throw new IllegalArgumentException("Invalid CameraData values");
            }
        }

        public Snapshot(
                Matrix4f projection,
                Matrix4f inverseProjection,
                Matrix4f viewRotation,
                Matrix4f inverseViewRotation,
                double x,
                double y,
                double z,
                float depthFar,
                float hudFov,
                float yRot,
                float xRot,
                boolean panoramic) {
            this(
                    projection,
                    inverseProjection,
                    viewRotation,
                    inverseViewRotation,
                    x,
                    y,
                    z,
                    depthFar,
                    hudFov,
                    yRot,
                    xRot,
                    panoramic,
                    MEDIUM_NONE);
        }

        public boolean underwater() {
            return medium == MEDIUM_WATER;
        }
    }

    private VeilCameraAbi() {}

    public static boolean usable(CameraRenderState camera) {
        if (camera == null
                || !camera.initialized
                || camera.pos == null
                || camera.projectionMatrix == null
                || camera.viewRotationMatrix == null) {
            return false;
        }
        float projectionDeterminant = camera.projectionMatrix.determinant();
        float viewDeterminant = camera.viewRotationMatrix.determinant();
        return Float.isFinite(projectionDeterminant)
                && Math.abs(projectionDeterminant) >= 1.0e-12f
                && Float.isFinite(viewDeterminant)
                && Math.abs(viewDeterminant) >= 1.0e-12f;
    }

    public static Snapshot capture(CameraRenderState camera) {
        if (!usable(camera)) {
            throw new IllegalArgumentException(
                    "CameraData requires an initialized Minecraft camera");
        }
        Matrix4f projection = new Matrix4f(camera.projectionMatrix);
        Matrix4f viewRotation = new Matrix4f(camera.viewRotationMatrix);
        return new Snapshot(
                projection,
                inverse(projection, "projection"),
                viewRotation,
                inverse(viewRotation, "view rotation"),
                camera.pos.x,
                camera.pos.y,
                camera.pos.z,
                camera.depthFar,
                camera.hudFov,
                camera.yRot,
                camera.xRot,
                camera.isPanoramicMode,
                medium(camera.fogType));
    }

    public static ByteBuffer write(
            ByteBuffer target,
            Snapshot current,
            Snapshot previous,
            int width,
            int height,
            boolean historyValid) {
        if (target.remaining() < SIZE)
            throw new IllegalArgumentException("CameraData requires " + SIZE + " bytes");
        if (current == null || width <= 0 || height <= 0)
            throw new IllegalArgumentException("Invalid CameraData values");
        Snapshot prior = previous == null ? current : previous;
        int base = target.position();
        ByteBuffer bytes = target.slice().order(ByteOrder.nativeOrder());
        matrix(bytes, PROJECTION_OFFSET, current.projection());
        matrix(bytes, INVERSE_PROJECTION_OFFSET, current.inverseProjection());
        matrix(bytes, VIEW_ROTATION_OFFSET, current.viewRotation());
        matrix(bytes, INVERSE_VIEW_ROTATION_OFFSET, current.inverseViewRotation());
        matrix(bytes, PREVIOUS_PROJECTION_OFFSET, prior.projection());
        matrix(bytes, PREVIOUS_INVERSE_PROJECTION_OFFSET, prior.inverseProjection());
        matrix(bytes, PREVIOUS_VIEW_ROTATION_OFFSET, prior.viewRotation());
        matrix(bytes, PREVIOUS_INVERSE_VIEW_ROTATION_OFFSET, prior.inverseViewRotation());
        position(
                bytes,
                CAMERA_POSITION_HIGH_OFFSET,
                CAMERA_POSITION_LOW_OFFSET,
                current.x(),
                current.y(),
                current.z());
        position(
                bytes,
                PREVIOUS_CAMERA_POSITION_HIGH_OFFSET,
                PREVIOUS_CAMERA_POSITION_LOW_OFFSET,
                prior.x(),
                prior.y(),
                prior.z());
        bytes.putFloat(VIEWPORT_OFFSET, width)
                .putFloat(VIEWPORT_OFFSET + 4, height)
                .putFloat(VIEWPORT_OFFSET + 8, 1.0f / width)
                .putFloat(VIEWPORT_OFFSET + 12, 1.0f / height);
        bytes.putFloat(PARAMS_OFFSET, current.depthFar())
                .putFloat(PARAMS_OFFSET + 4, current.hudFov())
                .putFloat(PARAMS_OFFSET + 8, historyValid && previous != null ? 1.0f : 0.0f)
                .putFloat(PARAMS_OFFSET + 12, current.panoramic() ? 1.0f : 0.0f);
        bytes.putFloat(ANGLES_OFFSET, current.yRot())
                .putFloat(ANGLES_OFFSET + 4, current.xRot())
                .putFloat(ANGLES_OFFSET + 8, VERSION)
                .putFloat(ANGLES_OFFSET + 12, current.medium());
        target.limit(base + SIZE);
        return target;
    }

    public static boolean isBinding(VeilShaderInterface.Descriptor descriptor) {
        return descriptor.set() == SET && descriptor.binding() == BINDING;
    }

    public static VeilShaderInterface.Descriptor validate(VeilShaderInterface shader) {
        List<VeilShaderInterface.Descriptor> matches =
                shader.descriptors().stream().filter(VeilCameraAbi::isBinding).toList();
        if (matches.size() != 1)
            throw new IllegalArgumentException(
                    "CameraData requires exactly one set=0 binding=" + BINDING + " uniform buffer");
        var descriptor = matches.getFirst();
        if (descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
                || descriptor.descriptorCount() != 1
                || descriptor.runtimeArray()
                || descriptor.minimumBufferSize() != SIZE
                || descriptor.writable()) {
            throw new IllegalArgumentException(
                    "CameraData binding requires a fixed readonly uniform buffer of "
                            + SIZE
                            + " bytes; actual="
                            + descriptor);
        }
        return descriptor;
    }

    private static int medium(FogType fogType) {
        if (fogType == FogType.WATER) return MEDIUM_WATER;
        if (fogType == FogType.LAVA) return MEDIUM_LAVA;
        if (fogType == FogType.POWDER_SNOW) return MEDIUM_POWDER_SNOW;
        return MEDIUM_NONE;
    }

    private static Matrix4f inverse(Matrix4f source, String name) {
        float determinant = source.determinant();
        if (!Float.isFinite(determinant) || Math.abs(determinant) < 1.0e-12f) {
            throw new IllegalArgumentException("CameraData " + name + " matrix is not invertible");
        }
        return new Matrix4f(source).invert();
    }

    private static void matrix(ByteBuffer target, int offset, Matrix4f matrix) {
        target.putFloat(offset, matrix.m00())
                .putFloat(offset + 4, matrix.m01())
                .putFloat(offset + 8, matrix.m02())
                .putFloat(offset + 12, matrix.m03());
        target.putFloat(offset + 16, matrix.m10())
                .putFloat(offset + 20, matrix.m11())
                .putFloat(offset + 24, matrix.m12())
                .putFloat(offset + 28, matrix.m13());
        target.putFloat(offset + 32, matrix.m20())
                .putFloat(offset + 36, matrix.m21())
                .putFloat(offset + 40, matrix.m22())
                .putFloat(offset + 44, matrix.m23());
        target.putFloat(offset + 48, matrix.m30())
                .putFloat(offset + 52, matrix.m31())
                .putFloat(offset + 56, matrix.m32())
                .putFloat(offset + 60, matrix.m33());
    }

    private static void position(
            ByteBuffer target, int highOffset, int lowOffset, double x, double y, double z) {
        float hx = (float) x, hy = (float) y, hz = (float) z;
        target.putFloat(highOffset, hx)
                .putFloat(highOffset + 4, hy)
                .putFloat(highOffset + 8, hz)
                .putFloat(highOffset + 12, 0.0f);
        target.putFloat(lowOffset, (float) (x - hx))
                .putFloat(lowOffset + 4, (float) (y - hy))
                .putFloat(lowOffset + 8, (float) (z - hz))
                .putFloat(lowOffset + 12, 0.0f);
    }
}
