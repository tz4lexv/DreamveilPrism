package dev.veil.revive.client.graphics.resources;

import static org.lwjgl.vulkan.VK10.*;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.client.graphics.minecraft.DeferredGpuRetirement;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.client.graphics.minecraft.VulkanResult;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;
import org.lwjgl.vulkan.VkSamplerCreateInfo;

public class NativeSampler implements AutoCloseable {
    private final MinecraftVulkanContext runtime;
    private final DeferredGpuRetirement closeRequested = new DeferredGpuRetirement();
    private long handle;

    protected NativeSampler(MinecraftVulkanContext runtime, long handle) {
        this.runtime = runtime;
        this.handle = handle;
    }

    protected static long createHandle(
            MinecraftVulkanContext runtime, SamplerParameters sampler, String label) {
        RenderSystem.assertOnRenderThread();
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var properties = VkPhysicalDeviceProperties.calloc(stack);
            vkGetPhysicalDeviceProperties(runtime.vkDevice().getPhysicalDevice(), properties);
            SamplerLodRules.validateDeviceBias(
                    sampler.lodBias(), properties.limits().maxSamplerLodBias());
            var info =
                    VkSamplerCreateInfo.calloc(stack)
                            .sType$Default()
                            .magFilter(sampler.mag())
                            .minFilter(sampler.min())
                            .mipmapMode(sampler.mip())
                            .addressModeU(sampler.u())
                            .addressModeV(sampler.v())
                            .addressModeW(sampler.w())
                            .mipLodBias(sampler.lodBias())
                            .anisotropyEnable(false)
                            .maxAnisotropy(1.0f)
                            .compareEnable(sampler.compareEnable())
                            .compareOp(sampler.compareOp())
                            .minLod(sampler.minLod())
                            // Imported views own their mip range; the sampler additionally
                            // applies the creator's explicit LOD range.
                            .maxLod(sampler.maxLod())
                            .borderColor(sampler.borderColor())
                            .unnormalizedCoordinates(false);
            var pSampler = stack.mallocLong(1);
            VulkanResult.check(
                    vkCreateSampler(runtime.vkDevice(), info, null, pSampler),
                    "vkCreateSampler(" + label + ")");
            return pSampler.get(0);
        }
    }

    protected long nativeHandle() {
        if (closeRequested.closeRequested() || handle == VK_NULL_HANDLE)
            throw new IllegalStateException("Sampler is closed");
        return handle;
    }

    @Override
    public void close() {
        RenderSystem.assertOnRenderThread();
        if (handle == VK_NULL_HANDLE) return;
        long old = handle;
        closeRequested.defer(
                action -> runtime.deferDestroy(action::run),
                () -> vkDestroySampler(runtime.vkDevice(), old, null));
        // Do not publish the old handle to callers while the host still owns it.
        if (closeRequested.closeRequested()) handle = VK_NULL_HANDLE;
    }
}
