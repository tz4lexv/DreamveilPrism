package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import dev.veil.revive.client.VeilOctreeRevision;
import dev.veil.revive.core.terrain.StableLeafIdentityTracker;

import net.minecraft.client.renderer.Octree;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.atomic.AtomicLong;

@Mixin(Octree.class)
public abstract class OctreeRevisionMixin implements VeilOctreeRevision {
    @Unique
    private static final boolean veil$tracking = Boolean.getBoolean("veil.asyncTerrainSelection");

    @Unique private AtomicLong veil$revision;

    @Unique private StableLeafIdentityTracker<SectionRenderDispatcher.RenderSection> veil$leaves;

    @Inject(method = "<init>", at = @At("RETURN"), require = 1)
    private void veil$initializeRevision(CallbackInfo callback) {
        veil$revision = new AtomicLong();
        veil$leaves = veil$tracking ? new StableLeafIdentityTracker<>(65536) : null;
    }

    @WrapMethod(method = "add")
    private boolean veil$trackContent(
            SectionRenderDispatcher.RenderSection section, Operation<Boolean> original) {
        if (!veil$tracking) return original.call(section);
        synchronized (veil$revision) {
            long before = veil$revision.get();
            veil$revision.incrementAndGet();
            boolean changed = true;
            try {
                long node = section.getSectionNode();
                boolean added = original.call(section);
                changed = veil$leaves.observe(node, section, added);
                return added;
            } finally {
                if (changed) veil$revision.incrementAndGet();
                else veil$revision.set(before);
            }
        }
    }

    public long veil$contentRevision() {
        return veil$revision.get();
    }
}
