package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.core.SectionPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.material.FluidState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class VeilFluidGeometryCapture {
    private static final ThreadLocal<SectionCapture> SECTION = new ThreadLocal<>();
    private static final ThreadLocal<ArrayDeque<FluidCapture>> STACK =
            ThreadLocal.withInitial(ArrayDeque::new);
    private static final AtomicLong CAPTURED_FLUIDS = new AtomicLong();
    private static final AtomicLong CAPTURED_QUADS = new AtomicLong();
    private static final AtomicLong CAPTURED_TOP_QUADS = new AtomicLong();
    private static final AtomicLong CAPTURED_SIDE_QUADS = new AtomicLong();
    private static final AtomicLong CAPTURED_SOURCE_SIDE_QUADS = new AtomicLong();
    private static final AtomicLong MALFORMED_FLUIDS = new AtomicLong();

    private VeilFluidGeometryCapture() {}

    public static void beginSectionCompile(SectionPos sectionPos) {
        SECTION.set(sectionPos == null ? null : new SectionCapture(sectionPos));
        STACK.remove();
    }

    public static VeilFluidGeometry[] endSectionCompile() {
        ArrayDeque<FluidCapture> stack = STACK.get();
        while (!stack.isEmpty()) finish(stack.pop());
        STACK.remove();
        SectionCapture section = SECTION.get();
        SECTION.remove();
        return section == null ? new VeilFluidGeometry[0] : section.finish();
    }

    public static boolean shouldReplace(FluidState state) {
        return SECTION.get() != null
                && state != null
                && !state.isEmpty()
                && (state.is(FluidTags.WATER)
                                && VeilShaderService.fluidGeometryWaterReplacementEnabled()
                        || state.is(FluidTags.LAVA)
                                && VeilShaderService.fluidGeometryLavaReplacementEnabled());
    }

    public static boolean capturing() {
        return !STACK.get().isEmpty();
    }

    public static void begin(FluidState state) {
        if (!shouldReplace(state)) return;
        int materialId =
                state.is(FluidTags.WATER)
                        ? VeilMaterialIds.WATER
                        : state.is(FluidTags.LAVA)
                                ? VeilMaterialIds.LAVA
                                : VeilMaterialIds.OTHER_FLUID;
        STACK.get().push(new FluidCapture(materialId, state.isSource()));
    }

    public static VertexConsumer builder(ChunkSectionLayer layer) {
        FluidCapture fluid = STACK.get().peek();
        if (fluid == null)
            throw new IllegalStateException("Fluid geometry builder requested outside capture");
        return fluid.layers.computeIfAbsent(layer, ignored -> new CaptureConsumer());
    }

    public static void end() {
        ArrayDeque<FluidCapture> stack = STACK.get();
        FluidCapture fluid = stack.poll();
        if (fluid != null) finish(fluid);
        if (stack.isEmpty()) STACK.remove();
    }

    private static void finish(FluidCapture fluid) {
        SectionCapture section = SECTION.get();
        if (section == null) return;
        GeometryBuilder merged =
                section.byMaterial.computeIfAbsent(
                        fluid.materialId, ignored -> new GeometryBuilder());
        int beforeQuads = merged.flags.size;
        for (CaptureConsumer consumer : fluid.layers.values()) {
            float[] positions = consumer.positions.toArray();
            if ((positions.length % 12) != 0) {
                MALFORMED_FLUIDS.incrementAndGet();
                continue;
            }
            for (int base = 0; base < positions.length; base += 12) {
                byte flags = classifyQuad(positions, base, fluid.source);
                merged.positions.addRange(positions, base, 12);
                merged.flags.add(flags);
                if ((flags & VeilFluidGeometry.QUAD_TOP) != 0) CAPTURED_TOP_QUADS.incrementAndGet();
                if ((flags & VeilFluidGeometry.QUAD_SIDE) != 0) {
                    CAPTURED_SIDE_QUADS.incrementAndGet();
                    if ((flags & VeilFluidGeometry.QUAD_SOURCE) != 0)
                        CAPTURED_SOURCE_SIDE_QUADS.incrementAndGet();
                }
            }
        }
        int addedQuads = merged.flags.size - beforeQuads;
        if (addedQuads != 0) {
            CAPTURED_FLUIDS.incrementAndGet();
            CAPTURED_QUADS.addAndGet(addedQuads);
        }
    }

    static byte classifyQuad(float[] p, int base, boolean source) {
        float ux = p[base + 3] - p[base];
        float uy = p[base + 4] - p[base + 1];
        float uz = p[base + 5] - p[base + 2];
        float vx = p[base + 6] - p[base];
        float vy = p[base + 7] - p[base + 1];
        float vz = p[base + 8] - p[base + 2];
        float nx = uy * vz - uz * vy;
        float ny = uz * vx - ux * vz;
        float nz = ux * vy - uy * vx;
        float len2 = nx * nx + ny * ny + nz * nz;

        byte flags = source ? VeilFluidGeometry.QUAD_SOURCE : 0;
        if (!(len2 > 1.0e-12f) || !Float.isFinite(len2)) {
            return (byte) (flags | VeilFluidGeometry.QUAD_DEGENERATE);
        }

        float yRatio = Math.abs(ny) / (float) Math.sqrt(len2);

        return (byte)
                (flags
                        | (yRatio >= 0.45f
                                ? VeilFluidGeometry.QUAD_TOP
                                : VeilFluidGeometry.QUAD_SIDE));
    }

    public static long capturedFluids() {
        return CAPTURED_FLUIDS.get();
    }

    public static long capturedQuads() {
        return CAPTURED_QUADS.get();
    }

    public static long capturedTopQuads() {
        return CAPTURED_TOP_QUADS.get();
    }

    public static long capturedSideQuads() {
        return CAPTURED_SIDE_QUADS.get();
    }

    public static long capturedSourceSideQuads() {
        return CAPTURED_SOURCE_SIDE_QUADS.get();
    }

    public static long malformedFluids() {
        return MALFORMED_FLUIDS.get();
    }

    private static final class SectionCapture {
        final SectionPos pos;
        final Map<Integer, GeometryBuilder> byMaterial = new LinkedHashMap<>();

        SectionCapture(SectionPos pos) {
            this.pos = pos;
        }

        VeilFluidGeometry[] finish() {
            List<VeilFluidGeometry> out = new ArrayList<>();
            for (var entry : byMaterial.entrySet()) {
                float[] values = entry.getValue().positions.toArray();
                byte[] flags = entry.getValue().flags.toArray();
                if (values.length == 0) continue;
                if ((values.length % 12) != 0 || flags.length != values.length / 12) {
                    MALFORMED_FLUIDS.incrementAndGet();
                    continue;
                }
                out.add(
                        new VeilFluidGeometry(
                                entry.getKey(),
                                pos.minBlockX(),
                                pos.minBlockY(),
                                pos.minBlockZ(),
                                values,
                                flags));
            }
            return out.toArray(VeilFluidGeometry[]::new);
        }
    }

    private static final class FluidCapture {
        final int materialId;
        final boolean source;
        final Map<ChunkSectionLayer, CaptureConsumer> layers = new LinkedHashMap<>();

        FluidCapture(int materialId, boolean source) {
            this.materialId = materialId;
            this.source = source;
        }
    }

    private static final class GeometryBuilder {
        final FloatBuilder positions = new FloatBuilder();
        final ByteBuilder flags = new ByteBuilder();
    }

    private static final class FloatBuilder {
        float[] values = new float[192];
        int size;

        void add(float value) {
            ensure(1);
            values[size++] = value;
        }

        void addRange(float[] source, int offset, int length) {
            ensure(length);
            System.arraycopy(source, offset, values, size, length);
            size += length;
        }

        private void ensure(int additional) {
            while (size + additional > values.length) {
                float[] grown = new float[values.length << 1];
                System.arraycopy(values, 0, grown, 0, size);
                values = grown;
            }
        }

        float[] toArray() {
            float[] out = new float[size];
            System.arraycopy(values, 0, out, 0, size);
            return out;
        }
    }

    private static final class ByteBuilder {
        byte[] values = new byte[64];
        int size;

        void add(byte value) {
            if (size == values.length) {
                byte[] grown = new byte[values.length << 1];
                System.arraycopy(values, 0, grown, 0, values.length);
                values = grown;
            }
            values[size++] = value;
        }

        byte[] toArray() {
            byte[] out = new byte[size];
            System.arraycopy(values, 0, out, 0, size);
            return out;
        }
    }

    private static final class CaptureConsumer implements VertexConsumer {
        final FloatBuilder positions = new FloatBuilder();

        private void vertex(float x, float y, float z) {
            positions.add(x);
            positions.add(y);
            positions.add(z);
        }

        @Override
        public VertexConsumer addVertex(float x, float y, float z) {
            vertex(x, y, z);
            return this;
        }

        @Override
        public void addVertex(
                float x,
                float y,
                float z,
                int color,
                float u,
                float v,
                int overlayCoords,
                int lightCoords,
                float nx,
                float ny,
                float nz) {
            vertex(x, y, z);
        }

        @Override
        public VertexConsumer setColor(int r, int g, int b, int a) {
            return this;
        }

        @Override
        public VertexConsumer setColor(int color) {
            return this;
        }

        @Override
        public VertexConsumer setUv(float u, float v) {
            return this;
        }

        @Override
        public VertexConsumer setUv1(int u, int v) {
            return this;
        }

        @Override
        public VertexConsumer setUv2(int u, int v) {
            return this;
        }

        @Override
        public VertexConsumer setNormal(float x, float y, float z) {
            return this;
        }

        @Override
        public VertexConsumer setLineWidth(float width) {
            return this;
        }
    }
}
