package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.LongAdder;

public final class VeilFaceVisibilityCache {
    private static final int SIZE = 4096;
    private static final int MASK = SIZE - 1;
    private static final ThreadLocal<Table> TABLE = ThreadLocal.withInitial(Table::new);
    private static final LongAdder HITS = new LongAdder();
    private static final LongAdder MISSES = new LongAdder();
    private static final AtomicBoolean PROOF_LOGGED = new AtomicBoolean();
    private static final boolean VERIFY = Boolean.getBoolean("veil.verifyFaceCache");
    private static final LongAdder VERIFIED = new LongAdder();
    private static final LongAdder VERIFIED_LEAVES = new LongAdder();
    private static final AtomicBoolean VERIFY_LOGGED = new AtomicBoolean();

    private VeilFaceVisibilityCache() {}

    public static void beginSectionCompile() {
        Table table = TABLE.get();
        table.active =
                VeilVideoConfig.on("renderer.faceCache") && ReviveRuntime.optimizationsEnabled();
        table.countMetrics = VeilTechniqueCounters.collecting();
        if (++table.generation == 0) {

            java.util.Arrays.fill(table.generations, 0);
            table.generation = 1;
        }
    }

    public static void endSectionCompile() {
        TABLE.get().active = false;
        if (VERIFY
                && VERIFIED.sum() > 1000
                && VERIFIED_LEAVES.sum() > 100
                && VERIFY_LOGGED.compareAndSet(false, true)) {
            ReviveMod.LOGGER.info(
                    "Veil exact foliage face verification: PASS ({} cached decisions compared with native, {} leaf decisions)",
                    VERIFIED.sum(),
                    VERIFIED_LEAVES.sum());
        }
        if (!VeilTechniqueCounters.collecting()) return;
        Snapshot snapshot = snapshot();
        if (snapshot.hits() > 0L && PROOF_LOGGED.compareAndSet(false, true)) {
            ReviveMod.LOGGER.info(
                    "Veil exact face-visibility cache ACTIVE: {} reused / {} evaluated ({}% reuse)",
                    snapshot.hits(),
                    snapshot.misses(),
                    String.format(java.util.Locale.ROOT, "%.1f", snapshot.hitRate() * 100.0));
        }
    }

    public static Boolean lookup(BlockState state, BlockState neighbor, Direction direction) {
        Table table = TABLE.get();
        if (!table.active || !ReviveRuntime.optimizationsEnabled()) return null;
        int slot = slot(state, neighbor, direction);
        if (table.generations[slot] == table.generation
                && table.states[slot] == state
                && table.neighbors[slot] == neighbor
                && table.directions[slot] == (byte) direction.ordinal()) {
            if (table.countMetrics) HITS.increment();
            return table.results[slot];
        }
        if (table.countMetrics) MISSES.increment();
        return null;
    }

    public static boolean shouldRenderFace(
            BlockState state, BlockState neighbor, Direction direction) {
        Boolean cached = lookup(state, neighbor, direction);
        if (cached != null) {
            if (VERIFY) {
                if (cached
                        != net.minecraft.world.level.block.Block.shouldRenderFace(
                                state, neighbor, direction)) {
                    throw new IllegalStateException(
                            "Face cache disagrees with native face visibility");
                }
                VERIFIED.increment();
                if (state.is(net.minecraft.tags.BlockTags.LEAVES)) VERIFIED_LEAVES.increment();
            }
            return cached;
        }
        boolean result =
                net.minecraft.world.level.block.Block.shouldRenderFace(state, neighbor, direction);
        store(state, neighbor, direction, result);
        return result;
    }

    public static void store(
            BlockState state, BlockState neighbor, Direction direction, boolean result) {
        Table table = TABLE.get();
        if (!table.active || !ReviveRuntime.optimizationsEnabled()) return;
        int slot = slot(state, neighbor, direction);
        table.states[slot] = state;
        table.neighbors[slot] = neighbor;
        table.directions[slot] = (byte) direction.ordinal();
        table.results[slot] = result;
        table.generations[slot] = table.generation;
    }

    public static Snapshot snapshot() {
        return new Snapshot(HITS.sum(), MISSES.sum());
    }

    private static int slot(BlockState state, BlockState neighbor, Direction direction) {
        int hash = System.identityHashCode(state) * 0x9e3779b9;
        hash ^= Integer.rotateLeft(System.identityHashCode(neighbor), 13);
        hash ^= direction.ordinal() * 0x85ebca6b;
        hash ^= hash >>> 16;
        return hash & MASK;
    }

    private static final class Table {
        final BlockState[] states = new BlockState[SIZE];
        final BlockState[] neighbors = new BlockState[SIZE];
        final byte[] directions = new byte[SIZE];
        final boolean[] results = new boolean[SIZE];
        final int[] generations = new int[SIZE];
        int generation;
        boolean active;
        boolean countMetrics;
    }

    public record Snapshot(long hits, long misses) {
        public Snapshot minus(Snapshot before) {
            return new Snapshot(hits - before.hits, misses - before.misses);
        }

        public Snapshot plus(Snapshot other) {
            return new Snapshot(hits + other.hits, misses + other.misses);
        }

        public long queries() {
            return hits + misses;
        }

        public double hitRate() {
            long total = queries();
            return total == 0L ? 0.0 : (double) hits / total;
        }
    }
}
