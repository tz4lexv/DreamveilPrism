package dev.veil.api;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * Owned CPU fields captured together from one shader generation and completed frame. No disk I/O.
 */
public record VeilSimulationCheckpoint(
        UUID generation, long frame, Map<String, Field> fields, Map<String, CpuState> cpuState) {
    /** Opaque author bytes; neither clocks nor algorithms are imposed by the engine. */
    public record CpuState(byte[] data) {
        public CpuState {
            Objects.requireNonNull(data, "CPU state");
            if (data.length > VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES)
                throw new IllegalArgumentException("CPU state exceeds checkpoint budget");
            data = data.clone();
        }

        @Override
        public byte[] data() {
            return data.clone();
        }

        public int size() {
            return data.length;
        }
    }

    /** Existing GPU-only construction remains source and binary compatible. */
    public VeilSimulationCheckpoint(UUID generation, long frame, Map<String, Field> fields) {
        this(generation, frame, fields, Map.of());
    }

    public record Selection(String resource, int mip, int layer) {
        public Selection {
            Objects.requireNonNull(resource, "resource");
            if (resource.isBlank() || resource.length() > 256 || mip < 0 || layer < 0)
                throw new IllegalArgumentException("Invalid simulation checkpoint selection");
        }
    }

    /** Exact original GPU format is retained, including normalized versus integer semantics. */
    public record Field(Selection selection, VeilFormat format, VeilSimulationFieldSnapshot data) {
        public Field {
            Objects.requireNonNull(selection, "selection");
            Objects.requireNonNull(format, "format");
            Objects.requireNonNull(data, "data");
            var layout =
                    VeilSimulationGpuField.plan(format, data.width(), data.height(), data.depth());
            if (layout.components() != data.components() || layout.type() != data.type())
                throw new IllegalArgumentException("Checkpoint format does not match CPU field");
        }
    }

    public VeilSimulationCheckpoint {
        Objects.requireNonNull(generation, "generation");
        if (frame < 1) throw new IllegalArgumentException("Checkpoint needs a completed frame");
        fields = Map.copyOf(fields);
        cpuState = Map.copyOf(cpuState);
        if (fields.isEmpty() || fields.size() > 128)
            throw new IllegalArgumentException("Checkpoint requires 1 to 128 fields");
        long bytes = 0;
        for (var entry : fields.entrySet()) {
            checkId(entry.getKey());
            bytes += entry.getValue().data().data().remaining();
        }
        if (cpuState.size() > 128)
            throw new IllegalArgumentException("Checkpoint permits at most 128 CPU entries");
        for (var entry : cpuState.entrySet()) {
            checkId(entry.getKey());
            bytes += entry.getValue().size();
        }
        if (bytes > VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES)
            throw new IllegalArgumentException("Checkpoint exceeds CPU payload budget");
    }

    public static void checkId(String id) {
        Objects.requireNonNull(id, "field id");
        if (id.isBlank() || id.length() > 256 || id.codePoints().anyMatch(Character::isISOControl))
            throw new IllegalArgumentException("Invalid checkpoint field id");
    }
}
