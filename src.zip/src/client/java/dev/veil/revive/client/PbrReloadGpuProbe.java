package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

public final class PbrReloadGpuProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.pbrReloadProbe")
                    && Boolean.getBoolean("veil.pbrMipProbe");
    private static final int[] MASKS = {0, 1, 2, 3, 2, 0, 3};
    private static Object world, device;
    private static VeilShaderPackRuntime previous;
    private static int step;
    private static long deadline;
    private static boolean started;

    private PbrReloadGpuProbe() {}

    public static boolean enabled() {
        return ENABLED;
    }

    public static boolean started() {
        return ENABLED && started;
    }

    static int expectedMask(VeilShaderPackRuntime active) {
        if (started())
            return active == previous || step == MASKS.length ? active.pbrAtlasMask() : MASKS[step];
        return Integer.getInteger("veil.pbrMipExpectedMask", 3);
    }

    public static boolean start(Minecraft client, long now) {
        world = client.level;
        device = MinecraftVulkanContext.currentDeviceOrNull();
        previous = PbrMipGpuProbe.generation();
        if (previous == null || device == null || !PbrMipGpuProbe.verified(world))
            throw new IllegalStateException("PBR reload requires verified initial runtime");
        started = true;
        request(now);
        return false;
    }

    public static boolean tick(Minecraft client, long now) {
        if (world != client.level || device != MinecraftVulkanContext.currentDeviceOrNull())
            throw new IllegalStateException("PBR reload changed world or Vulkan device");
        if (now > deadline)
            throw new IllegalStateException("PBR reload/readback timeout at step " + step);
        var active = PbrMipGpuProbe.generation();
        if (active == previous || !PbrMipGpuProbe.verified(world)) return false;
        if (active.pbrAtlasMask() != MASKS[step])
            throw new IllegalStateException("Wrong published PBR reload mask");
        ReviveMod.LOGGER.info(
                "Veil PBR reload GPU: PASS step={} mask={} same_world=true same_device=true new_runtime=true",
                step,
                MASKS[step]);
        previous = active;
        if (++step == MASKS.length) {
            ReviveMod.LOGGER.info("Veil PBR reload sequence: PASS steps=7");
            ReviveMod.LOGGER.info(
                    "Veil benchmark world: PASS (world lifecycle and PBR reload fixture)");
            return true;
        }
        request(now);
        return false;
    }

    private static void request(long now) {
        deadline = now + 60_000_000_000L;
        VeilShaderService.select("veil-pbr-demand-" + MASKS[step] + "-v1");
    }
}
