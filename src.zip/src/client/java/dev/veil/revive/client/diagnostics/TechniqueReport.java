package dev.veil.revive.client.diagnostics;

import dev.veil.revive.client.VeilFaceVisibilityCache;
import dev.veil.revive.client.VeilSharedSectionUniforms;
import dev.veil.revive.client.VeilTechniqueCounters;
import dev.veil.revive.core.ReviveConfig;
import dev.veil.revive.core.VeilTechniqueRegistry;

import java.util.Locale;

public final class TechniqueReport {
    private TechniqueReport() {}

    public record LiveCounters(
            boolean detailedOverlay,
            long animationMarks,
            long animationSkips,
            long animationCaptured,
            long coalesced,
            long staleSkipped,
            long revisionFastHits,
            long periodicIdentityAudits,
            long revisionSelfHeals,
            long relocationRevisionForces,
            long relocationSelfHeals) {}

    public static void append(
            StringBuilder out,
            VeilTechniqueCounters.Snapshot t,
            VeilFaceVisibilityCache.Snapshot face,
            VeilSharedSectionUniforms.Snapshot sharedWork,
            ReviveConfig cfg,
            LiveCounters live) {

        String cacheStatus;
        if (!cfg.staticDrawPacketCache()) cacheStatus = "CONFIG_OFF";
        else if (t.terrainPrepareSuccesses() == 0 && t.terrainBridgeFallbacks() > 0)
            cacheStatus = "FALLBACK_ERROR";
        else if (t.terrainPrepareSuccesses() == 0) cacheStatus = "HOOK_NO_SUCCESS";
        else if (t.terrainCacheReuses() > 0) cacheStatus = "ACTIVE_EFFECT";
        else cacheStatus = "ACTIVE_NO_REUSE";
        matrix(
                out,
                "Cached Static Draw Packets",
                cacheStatus,
                "prepareSuccess="
                        + t.terrainPrepareSuccesses()
                        + ", returnOverrides="
                        + t.terrainReturnOverrides()
                        + ", reuses="
                        + t.terrainCacheReuses()
                        + ", rebuilds="
                        + t.terrainCacheRebuilds()
                        + ", invalidations="
                        + t.terrainCacheInvalidations());

        long bindCalls = t.vertexBindCalls() + t.indexBindCalls();
        long bindSkips = t.skippedVertexBinds() + t.skippedIndexBinds();
        String bindStatus =
                bindCalls == 0L
                        ? "HOOK_NOT_OBSERVED"
                        : bindSkips > 0L ? "ACTIVE_EFFECT" : "ACTIVE_NO_EFFECT";
        matrix(
                out,
                "Vulkan Redundant Bind Elision",
                bindStatus,
                "calls=" + bindCalls + ", skipped=" + bindSkips);

        long revisionEvents =
                t.sectionDirtyEvents() + t.sectionMeshUpdateEvents() + t.globalInvalidations();
        matrix(
                out,
                "World/Section Revision Invalidation",
                revisionEvents > 0L ? "OBSERVED_ACTIVE" : "NO_EVENT_DURING_TEST",
                "dirty="
                        + t.sectionDirtyEvents()
                        + ", meshUpdated="
                        + t.sectionMeshUpdateEvents()
                        + ", global="
                        + t.globalInvalidations());

        String faceStatus =
                face.queries() == 0L
                        ? "NO_EVENT_DURING_TEST"
                        : face.hits() > 0L ? "ACTIVE_EFFECT" : "ACTIVE_NO_REUSE";
        matrix(
                out,
                "Section Face Visibility Memoization",
                faceStatus,
                "reused="
                        + face.hits()
                        + ", evaluated="
                        + face.misses()
                        + ", reuse="
                        + formatPercent(face.hitRate()));
        matrix(
                out,
                "Shared Camera and Section Uniforms",
                sharedWork.matrixCopiesAvoided() > 0L ? "ACTIVE_EFFECT" : "NO_EVENT_DURING_TEST",
                sharedWork.toString());

        String farStatus;
        if (!cfg.farTerrainPlanning()) farStatus = "CONFIG_OFF";
        else if (t.farAnalysisRuns() == 0L && !cfg.profilerEnabled() && !live.detailedOverlay())
            farStatus = "DIAGNOSTICS_ONLY_NOT_RUN";
        else if (t.farAnalysisRuns() == 0L) farStatus = "HOOK_NOT_OBSERVED";
        else if (t.farSseCandidates() + t.farVoxelCandidates() + t.farVascCandidates() > 0L)
            farStatus = "ANALYSIS_ONLY_CANDIDATES";
        else farStatus = "ANALYSIS_ONLY_ALL_EXACT";
        matrix(
                out,
                "Screen-space-error Far Classification",
                farStatus,
                "runs="
                        + t.farAnalysisRuns()
                        + ", SSE="
                        + t.farSseCandidates()
                        + ", voxel="
                        + t.farVoxelCandidates()
                        + ", VASC="
                        + t.farVascCandidates()
                        + ", renderEffect=0");
        matrix(
                out,
                "VASC Deep/Subpixel/Detail Classification",
                farStatus,
                "VASC candidates=" + t.farVascCandidates() + ", renderEffect=0");

        matrix(
                out,
                "Hierarchical Frustum Index",
                "VULKAN_CONNECTED",
                "GPU hierarchical frustum has measured-cost profitability autotune and can fall back to direct MDI; see gpu_frustum_cull_* and frustum_autotune_* counters");
        matrix(
                out,
                "HZB Occlusion GPU",
                "VULKAN_CONNECTED",
                "see session hzb_queries_total and GPU-completed hzb_sampled_hidden above");
        matrix(
                out,
                "GPU Indirect Command Compaction",
                "VULKAN_CONNECTED",
                "HZB survivors are compacted into a GPU draw stream and submitted with DrawIndirectCount; session counters above");
        matrix(
                out,
                "True Multi-Draw Indirect",
                "VULKAN_CONNECTED",
                "actual indexed indirect-count path; session mdi_calls_total above");
        matrix(
                out,
                "Exact Geometry Reduction",
                "VULKAN_CONNECTED",
                "compatible opaque planar geometry is merged across full-block and sub-block faces; affine color/AO gradients are preserved, changing lightmap samples remain protected, and conflicting overlaps fall back to the native mesh; see lod_* counters above");
        matrix(
                out,
                "Compact Vertex Format",
                "VULKAN_CONNECTED",
                "exact merged terrain replacements use Veil's 36-byte GPU vertex format with exact UV-texel fallback; see lod_* counters above");
        matrix(out, "Voxel/Clipmap Far Renderer", "BACKEND_REQUIRED", "replacement draws=0");
        matrix(out, "Light-only Updates Without Remesh", "BRIDGE_REQUIRED", "runtime effect=0");
        long animationMarks = live.animationMarks();
        long animationSkips = live.animationSkips();
        matrix(
                out,
                "Visible-only Animation Updates",
                animationSkips > 0L
                        ? "ACTIVE_EFFECT"
                        : animationMarks > 0L ? "ACTIVE_NO_EFFECT" : "NO_EVENT_DURING_TEST",
                "activeMarks="
                        + animationMarks
                        + ", atlasUploadsSkipped="
                        + animationSkips
                        + ", compileSpritesCaptured="
                        + live.animationCaptured());

        long coalesced = live.coalesced();
        long staleSkipped = live.staleSkipped();
        matrix(
                out,
                "Latest-state Chunk Rebuild Coalescing",
                coalesced > 0L || staleSkipped > 0L ? "ACTIVE_EFFECT" : "NO_EVENT_DURING_TEST",
                "obsoleteTasksCancelled=" + coalesced + ", stalePollsSkipped=" + staleSkipped);
        matrix(
                out,
                "Adaptive CPU+Upload Rebuild Budget",
                "MINECRAFT_BRIDGE_ACTIVE",
                "see rebuild_budget_* session telemetry above; V45 preserves native first-time compile admission while recompiles remain budgeted with progress and visible/near priority");
        matrix(
                out,
                "Stable-frame Zero-scan Topology Cache",
                live.revisionFastHits() > 0L ? "ACTIVE_EFFECT" : "NO_EVENT_DURING_TEST",
                "revisionFastHits="
                        + live.revisionFastHits()
                        + ", periodicIdentityAudits="
                        + live.periodicIdentityAudits()
                        + ", selfHeals="
                        + live.revisionSelfHeals()
                        + ", relocationForces="
                        + live.relocationRevisionForces()
                        + ", relocationSelfHeals="
                        + live.relocationSelfHeals());
        matrix(
                out,
                "Adaptive Cached-Work Cadence",
                "MINECRAFT_BRIDGE_ACTIVE",
                "integrated AUTO caches exact merged-terrain selection for stable frames; see lod_selection_* counters");
        matrix(
                out,
                "Standalone LOD Profitability Gate",
                "MINECRAFT_BRIDGE_ACTIVE",
                "integrated AUTO keeps Minecraft native opaque submission when exact merged replacements do not amortize the custom path; see lod_auto_standalone_* and submission_auto_lod_profitability_* counters");
        matrix(
                out,
                "Measured Standalone LOD GPU Autotune",
                "MINECRAFT_BRIDGE_ACTIVE",
                "integrated AUTO A/B probes Minecraft host vs exact merged custom opaque with non-blocking GPU timestamps; see lod_gpu_autotune_* and gpu_auto_lod_* counters");

        matrix(
                out,
                "Incremental Defrag Planner",
                "MINECRAFT_BRIDGE_ACTIVE",
                "live command and LOD arenas relocate through GPU scratch copies; see arena_defrag_* counters");
        matrix(
                out,
                "Immediate Batching Planner",
                "MINECRAFT_BRIDGE_ACTIVE",
                "opaque terrain groups compatible vertex/index buffers; translucent order is preserved");
        matrix(
                out,
                "LOD Memory/Disk Cache Core",
                "MINECRAFT_BRIDGE_ACTIVE",
                "exact mesh SHA-256 keys, validated geometry payloads and bounded worker writes; see lod_cache_* counters");
        matrix(
                out,
                "Direct Vulkan Multi-Draw",
                "DEVICE_DEPENDENT",
                "AUTO uses native multi-draw for uncompacted batches when supported; see submission_direct_multi_* counters");
        matrix(
                out,
                "Imperceptible Far-Field Quality Guard",
                "ANALYSIS_ONLY",
                "policy concept; no approximation renderer or runtime quality decision in this build");
        for (VeilTechniqueRegistry.Technique technique : VeilTechniqueRegistry.all()) {
            if (technique.name().equals("Adaptive Cached-Work Cadence")) continue;
            if (technique.stage() != VeilTechniqueRegistry.Stage.CORE_READY) continue;
            matrix(
                    out,
                    technique.name(),
                    "CORE_READY_NOT_INTEGRATED",
                    "no Minecraft runtime call-site/effect counter in this build");
        }
    }

    private static void matrix(StringBuilder out, String name, String status, String proof) {
        out.append(String.format(Locale.ROOT, "%-44s : %-28s | %s%n", name, status, proof));
    }

    private static String formatPercent(double ratio) {
        return String.format(Locale.ROOT, "%.2f%%", ratio * 100.0);
    }
}
