package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import dev.veil.revive.client.VeilPublicationLockJfrProbe;
import dev.veil.revive.client.VeilPublicationLockTimingAccess;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.concurrent.locks.ReentrantLock;

@Mixin(SectionRenderDispatcher.RenderSection.class)
public abstract class RenderSectionPublicationLockTimingMixin
        implements VeilPublicationLockTimingAccess {
    @Shadow @Final private SectionRenderDispatcher this$0;

    @Override
    public VeilPublicationLockJfrProbe veil$publicationLockTiming() {
        return ((VeilPublicationLockTimingAccess) this$0).veil$publicationLockTiming();
    }

    @WrapOperation(
            method = {"reset", "addSectionBuffersToUberBuffer"},
            at =
                    @At(
                            value = "INVOKE",
                            target = "Ljava/util/concurrent/locks/ReentrantLock;lock()V"),
            require = 2)
    private void veil$acquire(ReentrantLock lock, Operation<Void> original) {
        var timing = veil$publicationLockTiming();
        timing.beforeLock();
        original.call(lock);
        timing.afterLock();
    }

    @WrapOperation(
            method = {"reset", "addSectionBuffersToUberBuffer"},
            at =
                    @At(
                            value = "INVOKE",
                            target = "Ljava/util/concurrent/locks/ReentrantLock;unlock()V"),
            require = 4)
    private void veil$release(ReentrantLock lock, Operation<Void> original) {
        var timing = veil$publicationLockTiming();
        timing.beforeUnlock();
        original.call(lock);
        timing.afterUnlock();
    }
}
