package dev.veil.api;

import java.nio.ByteBuffer;
import java.util.Objects;

/**
 * Conservative, format-aware bridge between tightly packed Vulkan color image readbacks and CPU
 * simulation fields. Values are copied bit-for-bit; normalized formats are NOT converted to floats.
 * Only uncompressed formats representable by the existing CPU field scalar types are accepted. No
 * GPU commands are issued by this class.
 */
public final class VeilSimulationGpuField {
    private VeilSimulationGpuField() {}

    public record Plan(
            VeilFormat format,
            int width,
            int height,
            int depth,
            int components,
            VeilSimulationFieldSnapshot.ScalarType type,
            int bytes) {
        public Plan {
            Objects.requireNonNull(format, "format");
            Objects.requireNonNull(type, "type");
            if (width < 1
                    || height < 1
                    || depth < 1
                    || components < 1
                    || components > 4
                    || bytes < 1
                    || bytes > VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES - 36
                    || (long) width * height * depth * components * type.bytes() != bytes
                    || format.channels() != components
                    || format.bytesPerTexel() != components * type.bytes()
                    || scalarType(format) != type)
                throw new IllegalArgumentException("Invalid GPU simulation field layout");
        }

        public VeilSimulationFieldSnapshot capture(ByteBuffer completedReadback) {
            Objects.requireNonNull(completedReadback, "completedReadback");
            int row = Math.toIntExact((long) width * components * type.bytes());
            int slice = Math.toIntExact((long) row * height);
            return VeilSimulationStaging.capture(
                    completedReadback,
                    new VeilSimulationStaging.Layout(
                            width, height, depth, components, type, 0, row, slice));
        }

        public void prepareUpload(VeilSimulationFieldSnapshot field, ByteBuffer mappedDestination) {
            Objects.requireNonNull(field, "field");
            int row = Math.toIntExact((long) width * components * type.bytes());
            int slice = Math.toIntExact((long) row * height);
            VeilSimulationStaging.prepareUpload(
                    field,
                    mappedDestination,
                    new VeilSimulationStaging.Layout(
                            width, height, depth, components, type, 0, row, slice));
        }
    }

    /**
     * Only plain R/RG/RGBA color formats with an exact scalar representation are allowed. Packed
     * RGB10A2/RG11B10, depth/stencil and sRGB must be handled separately rather than silently
     * treating them as generic array-of-components simulation fields.
     */
    public static Plan plan(VeilFormat format, int width, int height, int depth) {
        Objects.requireNonNull(format, "format");
        VeilSimulationFieldSnapshot.ScalarType type = scalarType(format);
        if (width < 1 || height < 1 || depth < 1)
            throw new IllegalArgumentException("Simulation extent must be positive");
        long total;
        try {
            total =
                    Math.multiplyExact(
                            Math.multiplyExact((long) width, height),
                            Math.multiplyExact((long) depth, format.bytesPerTexel()));
        } catch (ArithmeticException overflow) {
            throw new IllegalArgumentException("Simulation checkpoint extent overflow", overflow);
        }
        // Field header is 36 bytes and a checkpoint must fit in the bounded state store.
        if (total > VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES - 36L)
            throw new IllegalArgumentException("GPU simulation checkpoint exceeds 16 MiB budget");
        return new Plan(format, width, height, depth, format.channels(), type, (int) total);
    }

    private static VeilSimulationFieldSnapshot.ScalarType scalarType(VeilFormat format) {
        return switch (format) {
            case R8_UNORM, RG8_UNORM, RGBA8_UNORM, R8_UINT, RG8_UINT, RGBA8_UINT ->
                    VeilSimulationFieldSnapshot.ScalarType.UINT8;
            case R16_UNORM, RG16_UNORM, RGBA16_UNORM, R16_UINT, RG16_UINT, RGBA16_UINT ->
                    VeilSimulationFieldSnapshot.ScalarType.UINT16;
            case R16_FLOAT, RG16_FLOAT, RGBA16_FLOAT ->
                    VeilSimulationFieldSnapshot.ScalarType.FLOAT16;
            case R32_UINT, RG32_UINT, RGBA32_UINT -> VeilSimulationFieldSnapshot.ScalarType.UINT32;
            case R32_FLOAT, RG32_FLOAT, RGBA32_FLOAT ->
                    VeilSimulationFieldSnapshot.ScalarType.FLOAT32;
            default ->
                    throw new IllegalArgumentException(
                            "GPU simulation checkpoint needs a plain uncompressed scalar color format: "
                                    + format);
        };
    }

    public static Plan plan(
            VeilFormat format, int width, int height, int depth, int mip, int mipLevels) {
        if (width < 1
                || height < 1
                || depth < 1
                || mipLevels < 1
                || mipLevels
                        > 32
                                - Integer.numberOfLeadingZeros(
                                        Math.max(width, Math.max(height, depth)))
                || mip < 0
                || mip >= mipLevels)
            throw new IllegalArgumentException("Invalid simulation mip selection");
        return plan(
                format,
                Math.max(1, width >>> mip),
                Math.max(1, height >>> mip),
                Math.max(1, depth >>> mip));
    }
}
