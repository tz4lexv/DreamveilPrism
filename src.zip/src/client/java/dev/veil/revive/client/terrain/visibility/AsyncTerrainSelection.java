package dev.veil.revive.client.terrain.visibility;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.VeilOctreeRevision;
import dev.veil.revive.core.Aabb;
import dev.veil.revive.core.AsyncVisibilityEngine;
import dev.veil.revive.core.FrustumSnapshot;
import dev.veil.revive.core.Plane;
import dev.veil.revive.core.VisibilityCandidate;
import dev.veil.revive.core.VisibilitySnapshot;
import dev.veil.revive.core.terrain.ConservativeFrustumEnvelope;
import dev.veil.revive.mixin.FrustumAccessor;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.renderer.Octree;
import net.minecraft.client.renderer.SectionOcclusionGraph;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.phys.AABB;

import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

public final class AsyncTerrainSelection {
    private static final boolean ENABLED = Boolean.getBoolean("veil.asyncTerrainSelection");
    private static final boolean VERIFY =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.verifyAsyncTerrainSelection");
    private static final long SETTLE_NS = 50_000_000L;
    private static final Frustum ALL =
            new Frustum(new Matrix4f(), new Matrix4f()) {
                @Override
                public int cubeInFrustum(BoundingBox bounds) {
                    return -2;
                }

                @Override
                public boolean isVisible(AABB bounds) {
                    return true;
                }
            };
    private Octree observedTree;
    private long observedRevision, observedAt;
    private Source source;
    private Request pending;
    private Ready ready;
    private AsyncVisibilityEngine engine;
    private boolean disabled, logged;
    private long acceptedCalls, fallbackCalls, snapshotBuilds, verifiedSections, failures;
    private long nextVerificationNanos, incoherentSnapshots;
    private long treeChanges, contentChanges, stateChanges, settleFallbacks;
    private long coverageFallbacks, waitingFallbacks, snapshotCaptureNanos, requestLatencyNanos;
    private int snapshotSections;

    private final BooleanSupplier optimizationsEnabled;
    private final Supplier<AsyncVisibilityEngine> visibilityEngine;
    private final LongSupplier originRevision;
    private final LongSupplier globalRevision;

    public AsyncTerrainSelection(
            BooleanSupplier optimizationsEnabled,
            Supplier<AsyncVisibilityEngine> visibilityEngine,
            LongSupplier originRevision,
            LongSupplier globalRevision) {
        this.optimizationsEnabled = java.util.Objects.requireNonNull(optimizationsEnabled);
        this.visibilityEngine = java.util.Objects.requireNonNull(visibilityEngine);
        this.originRevision = java.util.Objects.requireNonNull(originRevision);
        this.globalRevision = java.util.Objects.requireNonNull(globalRevision);
    }

    public void prepare(SectionOcclusionGraph graph, Frustum frustum) {
        trySelect(graph, frustum, null, null);
    }

    public boolean trySelect(
            SectionOcclusionGraph graph,
            Frustum frustum,
            List<SectionRenderDispatcher.RenderSection> visible,
            List<SectionRenderDispatcher.RenderSection> nearby) {
        if (!ENABLED
                || disabled
                || !optimizationsEnabled.getAsBoolean()
                || frustum == null
                || frustum.getClass() != Frustum.class) return false;
        AsyncVisibilityEngine currentEngine = visibilityEngine.get();
        if (currentEngine == null) return false;
        if (engine != currentEngine) {
            invalidate();
            engine = currentEngine;
        }
        Octree tree = graph.getOctree();
        long revision = ((VeilOctreeRevision) tree).veil$contentRevision();
        long now = System.nanoTime();
        if (tree != observedTree
                || revision != observedRevision
                || (source != null && !source.valid(graph))) {
            if (tree != observedTree) treeChanges++;
            else if (revision != observedRevision) contentChanges++;
            else stateChanges++;
            invalidate();
            engine = currentEngine;
            observedTree = tree;
            observedRevision = revision;
            observedAt = now;
        }
        if ((revision & 1L) != 0 || now - observedAt < SETTLE_NS) {
            settleFallbacks++;
            return fallback(visible != null);
        }
        if (source == null) {
            long started = System.nanoTime();
            source = capture(graph, tree, revision);
            snapshotCaptureNanos += System.nanoTime() - started;
            if (source == null) {
                observedAt = now;
                return fallback(visible != null);
            }
            snapshotBuilds++;
            snapshotSections = source.sections.length;
        }
        Frustum current = new Frustum(frustum).offsetToFullyIncludeCameraCube(8);
        FrustumSnapshot planes;
        try {
            planes = planes(current);
        } catch (IllegalArgumentException invalid) {
            return fallback(visible != null);
        }
        if (pending != null && pending.result.isDone()) {
            Request completed = pending;
            pending = null;
            requestLatencyNanos += System.nanoTime() - completed.started;
            try {
                VisibilitySnapshot result = completed.result.join();
                if (completed.source == source && source.valid(graph))
                    ready = new Ready(source, completed.envelope, result.visibleIds());
            } catch (java.util.concurrent.CancellationException ignored) {
                ready = null;
            } catch (java.util.concurrent.CompletionException failure) {
                failures++;
                disabled = true;
                invalidate();
                ReviveMod.LOGGER.warn(
                        "Async terrain selection unavailable; retaining native selection",
                        failure.getCause());
                return false;
            }
        }
        Ready selected = ready;
        boolean covered =
                selected != null
                        && selected.source == source
                        && source.valid(graph)
                        && selected.envelope.covers(planes);
        if (pending == null && !covered) {
            try {
                var envelope = new ConservativeFrustumEnvelope(planes, source.universe, 16, 0.25);
                pending =
                        new Request(
                                source,
                                envelope,
                                engine.submitHierarchical(source.candidates, envelope.expanded()),
                                System.nanoTime());
            } catch (IllegalArgumentException invalid) {
                return fallback(visible != null);
            }
        }
        if (!covered) {
            coverageFallbacks++;
            if (pending != null && !pending.result.isDone()) waitingFallbacks++;
            return fallback(visible != null);
        }
        if (visible == null) return false;
        if (VERIFY && (verifiedSections < 100_000 || now >= nextVerificationNanos)) {
            if (!verify(graph, current, selected)) return fallback(true);
            nextVerificationNanos = now + 1_000_000_000L;
        }
        if (!source.valid(graph)) return fallback(true);
        int visibleStart = visible.size(), nearbyStart = nearby.size();
        for (long ordinal : selected.ids) {
            int index = Math.toIntExact(ordinal);
            visible.add(source.sections[index]);
            if (source.nearby[index]) nearby.add(source.sections[index]);
        }
        if (!source.valid(graph)) {
            visible.subList(visibleStart, visible.size()).clear();
            nearby.subList(nearbyStart, nearby.size()).clear();
            return fallback(true);
        }
        acceptedCalls++;
        if (!logged) {
            logged = true;
            ReviveMod.LOGGER.info(
                    "Veil async terrain selection ACTIVE: immutable connected sections, conservative envelope, native fallback");
        }
        return true;
    }

    private boolean fallback(boolean selecting) {
        if (selecting) fallbackCalls++;
        return false;
    }

    private Source capture(SectionOcclusionGraph graph, Octree tree, long revision) {
        long origin = originRevision.getAsLong(), global = globalRevision.getAsLong();
        var sections = new ArrayList<SectionRenderDispatcher.RenderSection>();
        var nearby = new ArrayList<Boolean>();
        var candidates = new ArrayList<VisibilityCandidate>();
        var identities = new IdentityHashMap<SectionRenderDispatcher.RenderSection, Boolean>();
        Aabb[] universe = new Aabb[1];
        AABB[] branchBounds = new AABB[64];
        boolean[] valid = {true};
        tree.visitNodes(
                (node, fullyVisible, depth, close) -> {
                    if (depth < 0 || depth >= branchBounds.length) {
                        valid[0] = false;
                        return;
                    }
                    var section = node.getSection();
                    if (!valid[0]) return;
                    if (section == null) {
                        branchBounds[depth] = node.getAABB();
                        return;
                    }
                    if (identities.put(section, Boolean.TRUE) != null) {
                        valid[0] = false;
                        return;
                    }
                    AABB nativeBox = section.getBoundingBox();
                    if (depth == 0 || !contains(branchBounds[depth - 1], nativeBox)) {
                        incoherentSnapshots++;
                        valid[0] = false;
                        return;
                    }
                    Aabb bounds =
                            new Aabb(
                                    nativeBox.minX,
                                    nativeBox.minY,
                                    nativeBox.minZ,
                                    nativeBox.maxX,
                                    nativeBox.maxY,
                                    nativeBox.maxZ);
                    if (!finite(bounds)) {
                        valid[0] = false;
                        return;
                    }
                    candidates.add(new VisibilityCandidate(sections.size(), bounds));
                    sections.add(section);
                    nearby.add(close);
                    universe[0] = universe[0] == null ? bounds : universe[0].union(bounds);
                },
                ALL,
                32);
        if (!valid[0]
                || universe[0] == null
                || tree != graph.getOctree()
                || revision != ((VeilOctreeRevision) tree).veil$contentRevision()
                || origin != originRevision.getAsLong()
                || global != globalRevision.getAsLong()) return null;
        boolean[] close = new boolean[nearby.size()];
        for (int i = 0; i < close.length; i++) close[i] = nearby.get(i);
        return new Source(
                tree,
                revision,
                origin,
                global,
                sections.toArray(SectionRenderDispatcher.RenderSection[]::new),
                close,
                List.copyOf(candidates),
                universe[0],
                originRevision,
                globalRevision);
    }

    private boolean finite(Aabb bounds) {
        return Double.isFinite(bounds.minX())
                && Double.isFinite(bounds.minY())
                && Double.isFinite(bounds.minZ())
                && Double.isFinite(bounds.maxX())
                && Double.isFinite(bounds.maxY())
                && Double.isFinite(bounds.maxZ());
    }

    private boolean contains(AABB parent, AABB child) {
        return parent != null
                && child.minX >= parent.minX
                && child.minY >= parent.minY
                && child.minZ >= parent.minZ
                && child.maxX <= parent.maxX
                && child.maxY <= parent.maxY
                && child.maxZ <= parent.maxZ;
    }

    public static FrustumSnapshot planes(Frustum frustum) {
        var matrix = ((FrustumAccessor) frustum).revive$getMatrix();
        var planes = new ArrayList<Plane>(6);
        Vector4f coefficients = new Vector4f();
        for (int i = 0; i < 6; i++) {
            matrix.frustumPlane(i, coefficients);
            double w =
                    coefficients.w
                            - coefficients.x * frustum.getCamX()
                            - coefficients.y * frustum.getCamY()
                            - coefficients.z * frustum.getCamZ();
            if (!Float.isFinite(coefficients.x)
                    || !Float.isFinite(coefficients.y)
                    || !Float.isFinite(coefficients.z)
                    || !Double.isFinite(w))
                throw new IllegalArgumentException("Unsupported terrain frustum");
            planes.add(new Plane(coefficients.x, coefficients.y, coefficients.z, w));
        }
        return new FrustumSnapshot(planes);
    }

    private boolean verify(SectionOcclusionGraph graph, Frustum current, Ready selected) {
        var ordinals = new IdentityHashMap<SectionRenderDispatcher.RenderSection, Integer>();
        for (long id : selected.ids) ordinals.put(selected.source.sections[(int) id], (int) id);
        int[] previous = {-1};
        int[] checked = {0};
        String[] mismatch = {null};
        graph.getOctree()
                .visitNodes(
                        (node, fullyVisible, depth, close) -> {
                            var section = node.getSection();
                            if (section == null) return;
                            Integer ordinal = ordinals.get(section);
                            if (mismatch[0] == null) {
                                if (ordinal == null) {
                                    int captured = -1;
                                    for (int i = 0; i < selected.source.sections.length; i++)
                                        if (selected.source.sections[i] == section) {
                                            captured = i;
                                            break;
                                        }
                                    mismatch[0] =
                                            "omitted section "
                                                    + section.getSectionNode()
                                                    + " captured="
                                                    + captured
                                                    + " native_leaf_visible="
                                                    + current.isVisible(section.getBoundingBox())
                                                    + (captured < 0
                                                            ? ""
                                                            : " expanded_rejected="
                                                                    + selected.envelope
                                                                            .expanded()
                                                                            .definitelyOutside(
                                                                                    selected.source
                                                                                            .candidates
                                                                                            .get(
                                                                                                    captured)
                                                                                            .bounds()));
                                } else if (ordinal <= previous[0])
                                    mismatch[0] = "reordered ordinal " + ordinal;
                                else if (close && !selected.source.nearby[ordinal])
                                    mismatch[0] = "omitted nearby ordinal " + ordinal;
                            }
                            if (ordinal != null) previous[0] = ordinal;
                            checked[0]++;
                        },
                        current,
                        32);
        if (!selected.source.valid(graph)) return false;
        if (mismatch[0] != null)
            throw new IllegalStateException(
                    "Async terrain selection "
                            + mismatch[0]
                            + " in stable revision "
                            + selected.source.revision);
        long before = verifiedSections;
        verifiedSections += checked[0];
        if (before < 100_000 && verifiedSections >= 100_000)
            ReviveMod.LOGGER.info(
                    "Veil async terrain selection verification PASS: 100000 native sections retained in order");
        return true;
    }

    public void invalidate() {
        if (engine != null) engine.invalidate();
        source = null;
        pending = null;
        ready = null;
        observedTree = null;
        observedRevision = 0;
        observedAt = 0;
    }

    public void requireVerificationComplete() {
        if (ENABLED
                && VERIFY
                && (verifiedSections < 100_000 || acceptedCalls == 0 || failures != 0))
            throw new IllegalStateException(
                    "Async terrain verification incomplete: retained="
                            + verifiedSections
                            + ", accepted="
                            + acceptedCalls
                            + ", failures="
                            + failures);
    }

    public String telemetry() {
        return "terrain_async_selection_enabled="
                + ENABLED
                + "\nterrain_async_selection_accepted_total="
                + acceptedCalls
                + "\nterrain_async_selection_fallback_total="
                + fallbackCalls
                + "\nterrain_async_selection_snapshots_total="
                + snapshotBuilds
                + "\nterrain_async_selection_verified_total="
                + verifiedSections
                + "\nterrain_async_selection_failures_total="
                + failures
                + "\nterrain_async_selection_incoherent_snapshots_total="
                + incoherentSnapshots
                + "\nterrain_async_selection_tree_changes_total="
                + treeChanges
                + "\nterrain_async_selection_content_changes_total="
                + contentChanges
                + "\nterrain_async_selection_state_changes_total="
                + stateChanges
                + "\nterrain_async_selection_settle_fallbacks_total="
                + settleFallbacks
                + "\nterrain_async_selection_coverage_fallbacks_total="
                + coverageFallbacks
                + "\nterrain_async_selection_waiting_fallbacks_total="
                + waitingFallbacks
                + "\nterrain_async_selection_snapshot_sections="
                + snapshotSections
                + "\nterrain_async_selection_capture_ms_total="
                + snapshotCaptureNanos / 1e6
                + "\nterrain_async_selection_request_latency_ms_total="
                + requestLatencyNanos / 1e6
                + "\n";
    }

    private record Source(
            Octree tree,
            long revision,
            long origin,
            long global,
            SectionRenderDispatcher.RenderSection[] sections,
            boolean[] nearby,
            List<VisibilityCandidate> candidates,
            Aabb universe,
            LongSupplier originRevision,
            LongSupplier globalRevision) {
        boolean valid(SectionOcclusionGraph graph) {
            return tree == graph.getOctree()
                    && revision == ((VeilOctreeRevision) tree).veil$contentRevision()
                    && origin == originRevision.getAsLong()
                    && global == globalRevision.getAsLong();
        }
    }

    private record Request(
            Source source,
            ConservativeFrustumEnvelope envelope,
            CompletableFuture<VisibilitySnapshot> result,
            long started) {}

    private record Ready(Source source, ConservativeFrustumEnvelope envelope, long[] ids) {}
}
