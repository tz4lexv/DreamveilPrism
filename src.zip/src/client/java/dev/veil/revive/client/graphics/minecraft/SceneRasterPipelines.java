package dev.veil.revive.client.graphics.minecraft;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanRenderPipeline;

import dev.veil.api.VeilScenePass;
import dev.veil.revive.mixin.VulkanScenePipelineAccessor;

import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.UnaryOperator;

public final class SceneRasterPipelines implements AutoCloseable {
    private final MinecraftVulkanContext runtime;
    private final Map<RenderPipeline, Map<VeilScenePass.Raster, SceneRasterPipeline>> variants =
            new IdentityHashMap<>();
    private final Map<SceneRasterPipeline, DeferredGpuRetirement> retirements =
            new IdentityHashMap<>();
    private boolean closed;

    public SceneRasterPipelines(MinecraftVulkanContext runtime) {
        this.runtime = runtime;
    }

    public void validate(VeilScenePass.Raster raster) {
        SceneRasterRules.validate(
                raster,
                EnabledRasterFeatures.enabled(
                        runtime.vkDevice(), EnabledRasterFeatures.Feature.DEPTH_CLAMP),
                EnabledRasterFeatures.enabled(
                        runtime.vkDevice(), EnabledRasterFeatures.Feature.BIAS_CLAMP));
    }

    public SceneRasterScope begin(VeilScenePass.Raster raster) {
        RenderSystem.assertOnRenderThread();
        if (closed) throw new IllegalStateException("Scene raster pipelines are closed");
        if (raster.inherits())
            return SceneRasterScope.active()
                    ? SceneRasterScope.enter(UnaryOperator.identity())
                    : null;
        validate(raster);
        return SceneRasterScope.enter(pipeline -> variant(pipeline, raster));
    }

    private RenderPipeline variant(RenderPipeline pipeline, VeilScenePass.Raster raster) {
        RenderPipeline original =
                pipeline instanceof SceneRasterPipeline variant ? variant.original() : pipeline;
        Map<VeilScenePass.Raster, SceneRasterPipeline> states = variants.get(original);
        if (states == null) {
            states = new LinkedHashMap<>();
            variants.put(original, states);
        }
        SceneRasterPipeline result = states.get(raster);
        if (result == null) {
            result = new SceneRasterPipeline(original, raster);
            states.put(raster, result);
            retirements.put(result, new DeferredGpuRetirement());
        }
        return result;
    }

    @Override
    public void close() {
        RenderSystem.assertOnRenderThread();
        closed = true;
        if (retirements.isEmpty()) return;
        Map<RenderPipeline, VulkanRenderPipeline> cache =
                ((VulkanScenePipelineAccessor) runtime.device()).veil$scenePipelineCache();
        var cleanup = new dev.veil.revive.core.lifecycle.CloseSequence();
        for (var entry : retirements.entrySet()) {
            RenderPipeline variant = entry.getKey();
            VulkanRenderPipeline compiled = cache.get(variant);
            if (compiled == null) continue;
            cleanup.run(
                    () -> {
                        entry.getValue()
                                .defer(
                                        action -> runtime.deferDestroy(action::run),
                                        compiled::destroy);
                        if (entry.getValue().closeRequested()) cache.remove(variant, compiled);
                    });
        }
        variants.clear();
        cleanup.finish();
        retirements.clear();
    }
}
