package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.veil.revive.client.VeilFluidGeometryCapture;
import dev.veil.revive.client.VeilFluidMaterialCapture;

import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRendering;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.FluidRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = FluidRendering.class, remap = false)
public abstract class FabricFluidMaterialCaptureMixin {
    @WrapMethod(method = "render")
    private static void veil$captureFluidGeometry(
            FluidRenderer fluidRenderer,
            FluidRenderHandler handler,
            BlockAndTintGetter level,
            BlockPos pos,
            FluidRenderer.Output output,
            BlockState blockState,
            FluidState fluidState,
            FluidRendering.DefaultRenderer defaultRenderer,
            Operation<Void> original) {

        if (VeilFluidGeometryCapture.capturing()) {
            original.call(
                    fluidRenderer,
                    handler,
                    level,
                    pos,
                    output,
                    blockState,
                    fluidState,
                    defaultRenderer);
            return;
        }
        VeilFluidMaterialCapture.beginFluid(fluidState);
        FluidRenderer.Output observed =
                layer -> {
                    VertexConsumer consumer = output.getBuilder(layer);
                    return VeilFluidMaterialCapture.wrapBuilder(layer, consumer);
                };
        try {
            original.call(
                    fluidRenderer,
                    handler,
                    level,
                    pos,
                    observed,
                    blockState,
                    fluidState,
                    defaultRenderer);
        } finally {
            VeilFluidMaterialCapture.endFluid();
        }
    }
}
