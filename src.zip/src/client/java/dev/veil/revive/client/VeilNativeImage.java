package dev.veil.revive.client;

import dev.veil.revive.client.graphics.resources.NativeImageResource;

import java.util.Map;

final class VeilNativeImage implements AutoCloseable {
    private final NativeImageResource resource;

    private VeilNativeImage(NativeImageResource resource) {
        this.resource = resource;
    }

    static VeilNativeImage create(
            VeilVulkanRuntime runtime,
            VeilShaderPack.Resource declaration,
            Map<String, VeilShaderPack.Resource> resources,
            VeilShaderPack.ImageAsset asset,
            int viewportWidth,
            int viewportHeight,
            String label) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        var plan =
                dev.veil.revive.client.shaderpack.preparation.ImageResourceInputs.plan(
                        declaration, resources, viewportWidth, viewportHeight);
        return new VeilNativeImage(
                NativeImageResource.create(
                        runtime, plan, asset == null ? null : asset::bytesForUpload, label));
    }

    void clearZero() {
        resource.clearZero();
    }

    long view(int mip, int baseLayer, int layerCount) {
        return resource.view(mip, baseLayer, layerCount);
    }

    long attachmentView(int mip, int layer) {
        return resource.attachmentView(mip, layer);
    }

    long view() {
        return resource.view();
    }

    long image() {
        return resource.image();
    }

    long sampler() {
        return resource.sampler();
    }

    int format() {
        return resource.format();
    }

    int width() {
        return resource.width();
    }

    int height() {
        return resource.height();
    }

    int depth() {
        return resource.depth();
    }

    int layers() {
        return resource.layers();
    }

    int mipLevels() {
        return resource.mipLevels();
    }

    int aspect() {
        return resource.aspect();
    }

    static int sampleCount(int samples) {
        return NativeImageResource.sampleCount(samples);
    }

    @Override
    public void close() {
        resource.close();
    }
}
