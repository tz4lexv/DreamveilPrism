package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK12.*;
import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;
import com.mojang.blaze3d.vulkan.VulkanGpuSampler;
import com.mojang.blaze3d.vulkan.VulkanGpuTextureView;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.KHRSynchronization2;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkBufferMemoryBarrier2;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDependencyInfo;
import org.lwjgl.vulkan.VkMemoryBarrier;
import org.lwjgl.vulkan.VkMemoryBarrier2;

import java.io.IOException;
import java.nio.IntBuffer;

final class VeilHzbPyramidCompute implements AutoCloseable {
    static final int MAX_MIPS = 16;
    private static final int LEVELS_PER_DISPATCH = 5;
    private static final int PUSH_WORDS = 8 + MAX_MIPS;

    private final VeilVulkanRuntime runtime;
    private final VeilComputePipeline pipeline;
    private final boolean slang;

    VeilHzbPyramidCompute(VeilVulkanRuntime runtime) {
        this(runtime, !Boolean.getBoolean("veil.hzbGlsl"));
    }

    VeilHzbPyramidCompute(VeilVulkanRuntime runtime, boolean slang) {
        this.runtime = runtime;
        this.slang = slang;
        try {
            var spirv = VeilInternalShaders.hzbPyramid(slang);
            VeilShaderInterface reflected = VeilSpirvReflection.reflect(spirv);
            validateReflectedAbi(reflected);
            pipeline = VeilComputePipeline.createReflected(runtime, spirv, reflected);
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil HZB pyramid shader: {}",
                    slang ? "Slang precompiled SPIR-V" : "GLSL reference");
        } catch (IOException | RuntimeException failure) {
            throw new IllegalStateException("HZB pyramid compute initialization failed", failure);
        }
    }

    static void validateReflectedAbi(VeilShaderInterface shader) {
        if (shader.descriptors().size() != 2) {
            throw new IllegalStateException(
                    "HZB pyramid reflected descriptor count mismatch: "
                            + shader.descriptors().size());
        }
        var source =
                shader.descriptors().stream()
                        .filter(value -> value.set() == 0 && value.binding() == 0)
                        .findFirst()
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "HZB pyramid reflection missing source depth binding"));
        var hzb =
                shader.descriptors().stream()
                        .filter(value -> value.set() == 0 && value.binding() == 1)
                        .findFirst()
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "HZB pyramid reflection missing HZB buffer binding"));
        if (source.descriptorType() != VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER
                || hzb.descriptorType() != VK_DESCRIPTOR_TYPE_STORAGE_BUFFER) {
            throw new IllegalStateException(
                    "HZB pyramid reflected descriptor types do not match the Vulkan ABI");
        }
        if (shader.pushConstants().size() != 1
                || shader.pushConstants().getFirst().offset() != 0
                || shader.pushConstants().getFirst().size() != PUSH_WORDS * Integer.BYTES) {
            throw new IllegalStateException(
                    "HZB pyramid reflected push-constant ABI mismatch: " + shader.pushConstants());
        }
    }

    int build(
            VulkanGpuTextureView depth,
            VulkanGpuSampler sampler,
            GpuBufferSlice hzb,
            int viewportWidth,
            int viewportHeight,
            int baseWidth,
            int baseHeight,
            int mipCount,
            int[] mipOffsets) {
        if (mipCount <= 0 || mipCount > MAX_MIPS)
            throw new IllegalArgumentException("Invalid HZB mip count " + mipCount);

        VkCommandBuffer cmd = runtime.commandBuffer();
        depthWriteToComputeRead(cmd);
        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline.handle());
        pushDescriptors(cmd, depth, sampler, hzb);

        int dispatches = 0;
        int firstDstMip = 0;
        int sourceMip = -1;
        int srcWidth = viewportWidth;
        int srcHeight = viewportHeight;

        while (firstDstMip < mipCount) {
            int levels = Math.min(LEVELS_PER_DISPATCH, mipCount - firstDstMip);
            int dstWidth = mipDimension(baseWidth, firstDstMip);
            int dstHeight = mipDimension(baseHeight, firstDstMip);
            pushConstants(
                    cmd,
                    srcWidth,
                    srcHeight,
                    sourceMip,
                    firstDstMip,
                    levels,
                    baseWidth,
                    baseHeight,
                    mipCount,
                    mipOffsets);
            vkCmdDispatch(cmd, (dstWidth + 15) / 16, (dstHeight + 15) / 16, 1);
            dispatches++;

            firstDstMip += levels;
            sourceMip = firstDstMip - 1;
            srcWidth = mipDimension(baseWidth, sourceMip);
            srcHeight = mipDimension(baseHeight, sourceMip);
            if (firstDstMip < mipCount) hzbComputeToCompute(cmd, hzb);
        }

        hzbAndDepthFinalBarrier(cmd, hzb);
        if (slang)
            VeilSlangHzbProbe.compare(
                    runtime,
                    depth,
                    sampler,
                    hzb,
                    viewportWidth,
                    viewportHeight,
                    baseWidth,
                    baseHeight,
                    mipCount,
                    mipOffsets);
        return dispatches;
    }

    private void pushDescriptors(
            VkCommandBuffer cmd,
            VulkanGpuTextureView depth,
            VulkanGpuSampler sampler,
            GpuBufferSlice hzb) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            VeilResourceBindings.allocate(stack, 2)
                    .image(
                            0,
                            depth.vkImageView(),
                            sampler.vkSampler(),
                            VK_IMAGE_LAYOUT_GENERAL,
                            VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER)
                    .buffer(1, hzb, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
                    .push(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline.layout(), 0);
        }
    }

    private void pushConstants(
            VkCommandBuffer cmd,
            int srcWidth,
            int srcHeight,
            int sourceMip,
            int firstDstMip,
            int levels,
            int baseWidth,
            int baseHeight,
            int mipCount,
            int[] mipOffsets) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer data = stack.mallocInt(PUSH_WORDS);
            data.put(0, srcWidth);
            data.put(1, srcHeight);
            data.put(2, sourceMip);
            data.put(3, firstDstMip);
            data.put(4, levels);
            data.put(5, baseWidth);
            data.put(6, baseHeight);
            data.put(7, mipCount);
            for (int i = 0; i < MAX_MIPS; i++)
                data.put(8 + i, i < mipOffsets.length ? mipOffsets[i] : 0);
            vkCmdPushConstants(cmd, pipeline.layout(), VK_SHADER_STAGE_COMPUTE_BIT, 0, data);
        }
    }

    private static int mipDimension(int base, int level) {
        int scale = 1 << level;
        return Math.max(1, (base + scale - 1) >> level);
    }

    private static void depthWriteToComputeRead(VkCommandBuffer cmd) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            if (VeilVulkanCapabilities.synchronization2()) {
                var memory =
                        VkMemoryBarrier2.calloc(1, stack)
                                .sType$Default()
                                .srcStageMask(
                                        VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                                                | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT)
                                .srcAccessMask(VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT)
                                .dstStageMask(VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT)
                                .dstAccessMask(VK_ACCESS_2_SHADER_READ_BIT);
                KHRSynchronization2.vkCmdPipelineBarrier2KHR(
                        cmd,
                        VkDependencyInfo.calloc(stack).sType$Default().pMemoryBarriers(memory));
            } else {
                var memory =
                        VkMemoryBarrier.calloc(1, stack)
                                .sType$Default()
                                .srcAccessMask(VK10.VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT)
                                .dstAccessMask(VK10.VK_ACCESS_SHADER_READ_BIT);
                VK10.vkCmdPipelineBarrier(
                        cmd,
                        VK10.VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT
                                | VK10.VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT,
                        VK10.VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                        0,
                        memory,
                        null,
                        null);
            }
        }
    }

    private static void hzbComputeToCompute(VkCommandBuffer cmd, GpuBufferSlice hzb) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            if (VeilVulkanCapabilities.synchronization2()) {
                var buffer =
                        VkBufferMemoryBarrier2.calloc(1, stack)
                                .sType$Default()
                                .srcStageMask(VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT)
                                .srcAccessMask(VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT)
                                .dstStageMask(VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT)
                                .dstAccessMask(
                                        VK_ACCESS_2_SHADER_STORAGE_READ_BIT
                                                | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT)
                                .srcQueueFamilyIndex(VK10.VK_QUEUE_FAMILY_IGNORED)
                                .dstQueueFamilyIndex(VK10.VK_QUEUE_FAMILY_IGNORED)
                                .buffer(((VulkanGpuBuffer) hzb.buffer()).vkBuffer())
                                .offset(hzb.offset())
                                .size(hzb.length());
                KHRSynchronization2.vkCmdPipelineBarrier2KHR(
                        cmd,
                        VkDependencyInfo.calloc(stack)
                                .sType$Default()
                                .pBufferMemoryBarriers(buffer));
            } else {
                var memory =
                        VkMemoryBarrier.calloc(1, stack)
                                .sType$Default()
                                .srcAccessMask(VK10.VK_ACCESS_SHADER_WRITE_BIT)
                                .dstAccessMask(
                                        VK10.VK_ACCESS_SHADER_READ_BIT
                                                | VK10.VK_ACCESS_SHADER_WRITE_BIT);
                VK10.vkCmdPipelineBarrier(
                        cmd,
                        VK10.VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                        VK10.VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                        0,
                        memory,
                        null,
                        null);
            }
        }
    }

    private static void hzbAndDepthFinalBarrier(VkCommandBuffer cmd, GpuBufferSlice hzb) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            if (VeilVulkanCapabilities.synchronization2()) {
                var buffer =
                        VkBufferMemoryBarrier2.calloc(1, stack)
                                .sType$Default()
                                .srcStageMask(VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT)
                                .srcAccessMask(VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT)
                                .dstStageMask(VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT)
                                .dstAccessMask(VK_ACCESS_2_SHADER_STORAGE_READ_BIT)
                                .srcQueueFamilyIndex(VK10.VK_QUEUE_FAMILY_IGNORED)
                                .dstQueueFamilyIndex(VK10.VK_QUEUE_FAMILY_IGNORED)
                                .buffer(((VulkanGpuBuffer) hzb.buffer()).vkBuffer())
                                .offset(hzb.offset())
                                .size(hzb.length());
                var memory =
                        VkMemoryBarrier2.calloc(1, stack)
                                .sType$Default()
                                .srcStageMask(VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT)
                                .srcAccessMask(VK_ACCESS_2_SHADER_READ_BIT)
                                .dstStageMask(
                                        VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                                                | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT)
                                .dstAccessMask(
                                        VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_READ_BIT
                                                | VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT);
                KHRSynchronization2.vkCmdPipelineBarrier2KHR(
                        cmd,
                        VkDependencyInfo.calloc(stack)
                                .sType$Default()
                                .pMemoryBarriers(memory)
                                .pBufferMemoryBarriers(buffer));
            } else {
                var memory =
                        VkMemoryBarrier.calloc(1, stack)
                                .sType$Default()
                                .srcAccessMask(
                                        VK10.VK_ACCESS_SHADER_READ_BIT
                                                | VK10.VK_ACCESS_SHADER_WRITE_BIT)
                                .dstAccessMask(
                                        VK10.VK_ACCESS_SHADER_READ_BIT
                                                | VK10.VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT
                                                | VK10.VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT);
                VK10.vkCmdPipelineBarrier(
                        cmd,
                        VK10.VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                        VK10.VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT
                                | VK10.VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT
                                | VK10.VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT,
                        0,
                        memory,
                        null,
                        null);
            }
        }
    }

    @Override
    public void close() {
        pipeline.close();
    }
}
