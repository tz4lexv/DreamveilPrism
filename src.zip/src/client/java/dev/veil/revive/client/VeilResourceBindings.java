package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.KHRPushDescriptor;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDescriptorBufferInfo;
import org.lwjgl.vulkan.VkDescriptorImageInfo;
import org.lwjgl.vulkan.VkWriteDescriptorSet;

final class VeilResourceBindings {
    private final MemoryStack stack;
    private final VkWriteDescriptorSet.Buffer writes;
    private int count;

    private VeilResourceBindings(MemoryStack stack, int capacity) {
        if (capacity <= 0) throw new IllegalArgumentException("capacity <= 0");
        this.stack = stack;
        this.writes = VkWriteDescriptorSet.calloc(capacity, stack);
    }

    public static VeilResourceBindings allocate(MemoryStack stack, int capacity) {
        return new VeilResourceBindings(stack, capacity);
    }

    public VeilResourceBindings buffer(int binding, GpuBufferSlice slice, int descriptorType) {
        if (slice == null) throw new IllegalArgumentException("Descriptor buffer is null");
        if (count >= writes.capacity())
            throw new IllegalStateException("Push descriptor capacity exceeded");
        var info = VkDescriptorBufferInfo.calloc(1, stack);
        info.get(0)
                .buffer(((VulkanGpuBuffer) slice.buffer()).vkBuffer())
                .offset(slice.offset())
                .range(slice.length());
        writes.get(count++)
                .sType$Default()
                .dstBinding(binding)
                .dstArrayElement(0)
                .descriptorCount(1)
                .descriptorType(descriptorType)
                .pBufferInfo(info);
        return this;
    }

    public VeilResourceBindings buffers(int binding, GpuBufferSlice[] slices, int descriptorType) {
        if (slices == null || slices.length == 0)
            throw new IllegalArgumentException("Descriptor buffer array is empty");
        var infos = buffers(binding, slices.length, descriptorType);
        for (int i = 0; i < slices.length; i++) {
            GpuBufferSlice slice = slices[i];
            infos.get(i)
                    .buffer(((VulkanGpuBuffer) slice.buffer()).vkBuffer())
                    .offset(slice.offset())
                    .range(slice.length());
        }
        return this;
    }

    public VkDescriptorBufferInfo.Buffer buffers(int binding, int length, int descriptorType) {
        if (length < 1) throw new IllegalArgumentException("Descriptor buffer array is empty");
        if (count >= writes.capacity())
            throw new IllegalStateException("Push descriptor capacity exceeded");
        var infos = VkDescriptorBufferInfo.calloc(length, stack);
        writes.get(count++)
                .sType$Default()
                .dstBinding(binding)
                .dstArrayElement(0)
                .descriptorCount(length)
                .descriptorType(descriptorType)
                .pBufferInfo(infos);
        return infos;
    }

    public VeilResourceBindings image(
            int binding, long imageView, long sampler, int imageLayout, int descriptorType) {
        if (imageView == 0L)
            throw new IllegalArgumentException("Descriptor image requires a valid view");
        if (count >= writes.capacity())
            throw new IllegalStateException("Push descriptor capacity exceeded");
        var info = VkDescriptorImageInfo.calloc(1, stack);
        info.get(0).imageView(imageView).sampler(sampler).imageLayout(imageLayout);
        writes.get(count++)
                .sType$Default()
                .dstBinding(binding)
                .dstArrayElement(0)
                .descriptorCount(1)
                .descriptorType(descriptorType)
                .pImageInfo(info);
        return this;
    }

    public VeilResourceBindings images(
            int binding, long[] imageViews, long[] samplers, int imageLayout, int descriptorType) {
        if (imageViews == null
                || samplers == null
                || imageViews.length == 0
                || imageViews.length != samplers.length) {
            throw new IllegalArgumentException(
                    "Descriptor image array requires matching non-empty view/sampler arrays");
        }
        var infos = images(binding, imageViews.length, imageLayout, descriptorType);
        for (int i = 0; i < imageViews.length; i++) {
            infos.get(i).imageView(imageViews[i]).sampler(samplers[i]).imageLayout(imageLayout);
        }
        return this;
    }

    public VkDescriptorImageInfo.Buffer images(
            int binding, int length, int imageLayout, int descriptorType) {
        if (length < 1) throw new IllegalArgumentException("Descriptor image array is empty");
        if (count >= writes.capacity())
            throw new IllegalStateException("Push descriptor capacity exceeded");
        var infos = VkDescriptorImageInfo.calloc(length, stack);
        writes.get(count++)
                .sType$Default()
                .dstBinding(binding)
                .dstArrayElement(0)
                .descriptorCount(length)
                .descriptorType(descriptorType)
                .pImageInfo(infos);
        return infos;
    }

    public void push(VkCommandBuffer cmd, int bindPoint, long pipelineLayout, int set) {
        if (count != writes.capacity()) {
            throw new IllegalStateException(
                    "Expected " + writes.capacity() + " push descriptors, wrote " + count);
        }
        KHRPushDescriptor.vkCmdPushDescriptorSetKHR(cmd, bindPoint, pipelineLayout, set, writes);
    }

    public VeilResourceBindings accelerationStructure(int binding, long handle) {
        if (handle == 0 || count >= writes.capacity())
            throw new IllegalArgumentException("Invalid acceleration-structure descriptor");
        var acceleration =
                org.lwjgl.vulkan.VkWriteDescriptorSetAccelerationStructureKHR.calloc(stack)
                        .sType$Default()
                        .pAccelerationStructures(stack.longs(handle));
        writes.get(count++)
                .sType$Default()
                .dstBinding(binding)
                .dstArrayElement(0)
                .descriptorCount(1)
                .descriptorType(
                        org.lwjgl.vulkan.KHRAccelerationStructure
                                .VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR)
                .pNext(acceleration.address());
        return this;
    }
}
