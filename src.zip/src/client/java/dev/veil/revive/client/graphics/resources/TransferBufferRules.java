package dev.veil.revive.client.graphics.resources;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilTransfer;

import java.util.Objects;

/**
 * Device-independent validation for Vulkan buffer fills and buffer/image copy regions. The transfer
 * planner runs these checks before recording commands on the GPU.
 */
public final class TransferBufferRules {
    private TransferBufferRules() {}

    /**
     * vkCmdFillBuffer requires both the destination offset and explicit size to be 4-byte aligned.
     */
    public static void validateFill(long offset, long size) {
        if (offset < 0 || size <= 0 || (offset & 3L) != 0 || (size & 3L) != 0) {
            throw new IllegalArgumentException(
                    "Vulkan buffer fill requires a positive size and 4-byte aligned offset/size");
        }
    }

    /**
     * Validate vkCmdCopyBufferToImage/vkCmdCopyImageToBuffer byte offsets and row pitches. Veil
     * retains its conservative 4-byte alignment to support transfer-only queues, but also requires
     * the actual texel-block alignment (which differs for RGB8/RGB16).
     */
    public static void validateImageCopy(
            long offset,
            VeilFormat format,
            int width,
            int height,
            VeilTransfer.BufferLayout layout) {
        Objects.requireNonNull(format, "format");
        int blockSize = format.bytesPerTexel();
        if (!format.color()
                || width < 1
                || height < 1
                || offset < 0
                || (offset & 3L) != 0
                || offset % blockSize != 0) {
            throw new IllegalArgumentException(
                    "Buffer/image copy requires a non-negative offset aligned to both "
                            + "4 bytes and the color texel size ("
                            + blockSize
                            + " bytes)");
        }
        if (layout != null) {
            // VkBufferImageCopy's explicitly supplied row pitch must fit a signed 31-bit
            // byte count. This is checked before the Vulkan command is recorded.
            if (layout.rowLengthTexels() != 0
                    && (long) layout.rowLengthTexels() * blockSize > Integer.MAX_VALUE) {
                throw new IllegalArgumentException(
                        "Buffer/image copy row pitch exceeds Vulkan's 31-bit limit");
            }
            if ((layout.rowLengthTexels() != 0 && layout.rowLengthTexels() < width)
                    || (layout.imageHeightTexels() != 0 && layout.imageHeightTexels() < height)) {
                throw new IllegalArgumentException(
                        "Buffer/image copy row/image height is smaller than the copied region");
            }
        }
    }
}
