package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.QuadInstance;

import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.ARGB;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.world.level.block.state.BlockState;

public final class VeilVanillaQuadLighting {
    private static final Direction[] FIRST = {
        Direction.WEST, Direction.EAST, Direction.UP, Direction.WEST, Direction.UP, Direction.DOWN
    };
    private static final Direction[] SECOND = {
        Direction.NORTH,
        Direction.NORTH,
        Direction.EAST,
        Direction.DOWN,
        Direction.NORTH,
        Direction.NORTH
    };
    private static final int[] ROTATION = {0, 2, 3, 0, 3, 1};
    private final VeilFlatQuadLighting.Lookup lookup;
    private final BlockPos.MutableBlockPos scratch = new BlockPos.MutableBlockPos();
    private final float[] minimum = new float[3], maximum = new float[3], shade = new float[9];
    private final int[] samples = new int[9];
    private final boolean[] clear = new boolean[4];
    private final float[] brightness = new float[48];
    private final int[] light = new int[48];
    private final float[] weights = new float[4];
    private int ready;

    public VeilVanillaQuadLighting(VeilFlatQuadLighting.Lookup lookup) {
        this.lookup = lookup;
    }

    public void begin() {
        ready = 0;
    }

    public void prepare(
            BlockAndTintGetter world,
            BlockState state,
            BlockPos pos,
            Direction face,
            float[] coordinates,
            boolean directional,
            QuadInstance output) {
        java.util.Arrays.fill(minimum, 32f);
        java.util.Arrays.fill(maximum, -32f);
        for (int v = 0; v < 4; v++)
            for (int axis = 0; axis < 3; axis++) {
                float value = coordinates[v * 3 + axis];
                minimum[axis] = Math.min(minimum[axis], value);
                maximum[axis] = Math.max(maximum[axis], value);
            }
        int normal = face.getAxis().ordinal();
        boolean planar = minimum[normal] == maximum[normal];
        boolean outside =
                planar
                        && ((face.getAxisDirection() == Direction.AxisDirection.POSITIVE
                                        ? maximum[normal] > 0.9999f
                                        : minimum[normal] < 0.0001f)
                                || state.isCollisionShapeFullBlock(world, pos));
        int offset = face(world, state, pos, face, outside);
        Direction a = FIRST[face.ordinal()], b = SECOND[face.ordinal()];
        int au = a.getAxis().ordinal(), bv = b.getAxis().ordinal();
        boolean partial =
                minimum[au] >= 0.0001f
                        || minimum[bv] >= 0.0001f
                        || maximum[au] <= 0.9999f
                        || maximum[bv] <= 0.9999f;
        for (int corner = 0; corner < 4; corner++) {
            int vertex = (ROTATION[face.ordinal()] + corner) & 3;
            if (!partial) {
                output.setColor(vertex, ARGB.gray(brightness[offset + corner]));
                output.setLightCoords(vertex, light[offset + corner]);
            } else {
                boolean aFirst = corner < 2, bFirst = corner == 1 || corner == 2;
                float u =
                        (aFirst == (a.getAxisDirection() == Direction.AxisDirection.POSITIVE))
                                ? maximum[au]
                                : minimum[au];
                float v =
                        (bFirst == (b.getAxisDirection() == Direction.AxisDirection.POSITIVE))
                                ? maximum[bv]
                                : minimum[bv];
                float a0 = a.getAxisDirection() == Direction.AxisDirection.POSITIVE ? u : 1f - u;
                float a1 = a.getAxisDirection() == Direction.AxisDirection.POSITIVE ? 1f - u : u;
                float b0 = b.getAxisDirection() == Direction.AxisDirection.POSITIVE ? v : 1f - v;
                float b1 = b.getAxisDirection() == Direction.AxisDirection.POSITIVE ? 1f - v : v;
                weights[0] = a0 * b1;
                weights[1] = a0 * b0;
                weights[2] = a1 * b0;
                weights[3] = a1 * b1;
                float value =
                        brightness[offset] * weights[0]
                                + brightness[offset + 1] * weights[1]
                                + brightness[offset + 2] * weights[2]
                                + brightness[offset + 3] * weights[3];
                output.setColor(vertex, ARGB.gray(Math.clamp(value, 0f, 1f)));
                output.setLightCoords(
                        vertex,
                        LightCoordsUtil.smoothWeightedBlend(
                                light[offset],
                                light[offset + 1],
                                light[offset + 2],
                                light[offset + 3],
                                weights[0],
                                weights[1],
                                weights[2],
                                weights[3]));
            }
        }
        var lighting = world.cardinalLighting();
        output.scaleColor(directional ? lighting.byFace(face) : lighting.up());
    }

    private int face(
            BlockAndTintGetter world,
            BlockState renderedState,
            BlockPos pos,
            Direction face,
            boolean outside) {
        int key = face.ordinal() + (outside ? 6 : 0), offset = key * 4;
        if ((ready & (1 << key)) != 0) return offset;
        int x = pos.getX() + (outside ? face.getStepX() : 0),
                y = pos.getY() + (outside ? face.getStepY() : 0),
                z = pos.getZ() + (outside ? face.getStepZ() : 0);
        Direction a = FIRST[face.ordinal()], b = SECOND[face.ordinal()];
        for (int side = 0; side < 4; side++) {
            Direction delta = side < 2 ? a : b;
            int sign = (side & 1) == 0 ? 1 : -1;
            scratch.set(
                    x + sign * delta.getStepX(),
                    y + sign * delta.getStepY(),
                    z + sign * delta.getStepZ());
            sample(world, world.getBlockState(scratch), side);
            scratch.move(face);
            var blocking = world.getBlockState(scratch);
            clear[side] =
                    !blocking.isViewBlocking(world, scratch) || blocking.getLightDampening() == 0;
        }
        for (int corner = 0; corner < 4; corner++) {
            int ai = corner < 2 ? 0 : 1, bi = (corner & 1) + 2;
            if (!clear[ai] && !clear[bi]) {
                shade[4 + corner] = shade[0];
                samples[4 + corner] = samples[0];
            } else {
                int sa = ai == 0 ? 1 : -1, sb = bi == 2 ? 1 : -1;
                scratch.set(
                        x + sa * a.getStepX() + sb * b.getStepX(),
                        y + sa * a.getStepY() + sb * b.getStepY(),
                        z + sa * a.getStepZ() + sb * b.getStepZ());
                sample(world, world.getBlockState(scratch), 4 + corner);
            }
        }
        scratch.set(x, y, z);
        shade[8] = world.getBlockState(scratch).getShadeBrightness(world, scratch);
        scratch.setWithOffset(pos, face);
        var neighbor = world.getBlockState(scratch);
        if (outside || !neighbor.isSolidRender())
            samples[8] = lookup.light(neighbor, world, scratch);
        else samples[8] = lookup.light(renderedState, world, pos);
        for (int corner = 0; corner < 4; corner++) {
            int ai = corner < 2 ? 0 : 1,
                    bi = corner == 0 || corner == 3 ? 3 : 2,
                    diagonal = 4 + ai * 2 + bi - 2;
            brightness[offset + corner] =
                    (shade[bi] + shade[ai] + shade[diagonal] + shade[8]) * 0.25f;
            light[offset + corner] =
                    LightCoordsUtil.smoothBlend(
                            samples[bi], samples[ai], samples[diagonal], samples[8]);
        }
        ready |= 1 << key;
        return offset;
    }

    private void sample(BlockAndTintGetter world, BlockState state, int index) {
        samples[index] = lookup.light(state, world, scratch);
        shade[index] = state.getShadeBrightness(world, scratch);
    }
}
