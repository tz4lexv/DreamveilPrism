package dev.veil.revive.client;

import static org.lwjgl.util.spvc.Spv.*;
import static org.lwjgl.vulkan.VK11.*;

import dev.veil.api.VeilVertexLayout;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties2;
import org.lwjgl.vulkan.VkPhysicalDeviceSubgroupProperties;
import org.lwjgl.vulkan.VkQueueFamilyProperties;

record VeilShaderDeviceLimits(
        String device,
        int groupX,
        int groupY,
        int groupZ,
        int sizeX,
        int sizeY,
        int sizeZ,
        int invocations,
        int sharedBytes,
        int timestampBits,
        double timestampPeriod,
        int subgroupSize,
        int subgroupStages,
        int subgroupOperations,
        int maxVertexAttributes,
        int maxVertexBindings,
        int maxVertexOffset,
        int maxVertexStride,
        long maxIndirectDrawCount) {
    VeilShaderDeviceLimits(
            String device,
            int groupX,
            int groupY,
            int groupZ,
            int sizeX,
            int sizeY,
            int sizeZ,
            int invocations,
            int sharedBytes,
            int timestampBits,
            double timestampPeriod,
            int subgroupSize,
            int subgroupStages,
            int subgroupOperations) {
        this(
                device,
                groupX,
                groupY,
                groupZ,
                sizeX,
                sizeY,
                sizeZ,
                invocations,
                sharedBytes,
                timestampBits,
                timestampPeriod,
                subgroupSize,
                subgroupStages,
                subgroupOperations,
                16,
                16,
                2047,
                2048,
                65_535);
    }

    static VeilShaderDeviceLimits capture(VeilVulkanRuntime runtime) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var physical = runtime.vkDevice().getPhysicalDevice();
            var subgroup = VkPhysicalDeviceSubgroupProperties.calloc(stack).sType$Default();
            var properties =
                    VkPhysicalDeviceProperties2.calloc(stack)
                            .sType$Default()
                            .pNext(subgroup.address());
            vkGetPhysicalDeviceProperties2(physical, properties);
            var limit = properties.properties().limits();
            var count = stack.ints(0);
            vkGetPhysicalDeviceQueueFamilyProperties(physical, count, null);
            var queues = VkQueueFamilyProperties.calloc(count.get(0), stack);
            vkGetPhysicalDeviceQueueFamilyProperties(physical, count, queues);
            return new VeilShaderDeviceLimits(
                    properties.properties().deviceNameString(),
                    limit.maxComputeWorkGroupCount(0),
                    limit.maxComputeWorkGroupCount(1),
                    limit.maxComputeWorkGroupCount(2),
                    limit.maxComputeWorkGroupSize(0),
                    limit.maxComputeWorkGroupSize(1),
                    limit.maxComputeWorkGroupSize(2),
                    limit.maxComputeWorkGroupInvocations(),
                    limit.maxComputeSharedMemorySize(),
                    queues.get(runtime.graphicsQueue().queueFamilyIndex()).timestampValidBits(),
                    limit.timestampPeriod(),
                    subgroup.subgroupSize(),
                    subgroup.supportedStages(),
                    subgroup.supportedOperations(),
                    limit.maxVertexInputAttributes(),
                    limit.maxVertexInputBindings(),
                    limit.maxVertexInputAttributeOffset(),
                    limit.maxVertexInputBindingStride(),
                    Integer.toUnsignedLong(limit.maxDrawIndirectCount()));
        }
    }

    void validate(VeilVertexLayout layout, String pass) {
        if (layout.bindings().size() > maxVertexBindings) {
            throw new IllegalArgumentException(
                    pass + ": vertex binding count exceeds live device limit=" + maxVertexBindings);
        }
        if (layout.attributes().size() > maxVertexAttributes) {
            throw new IllegalArgumentException(
                    pass
                            + ": vertex attribute count exceeds live device limit="
                            + maxVertexAttributes);
        }
        for (var binding : layout.bindings()) {
            if (binding.binding() >= maxVertexBindings || binding.stride() > maxVertexStride) {
                throw new IllegalArgumentException(
                        pass
                                + ": vertex binding="
                                + binding.binding()
                                + " exceeds live device limits");
            }
        }
        for (var attribute : layout.attributes()) {
            if (attribute.location() >= maxVertexAttributes
                    || attribute.offset() > maxVertexOffset) {
                throw new IllegalArgumentException(
                        pass
                                + ": vertex attribute location="
                                + attribute.location()
                                + " exceeds live device limits");
            }
        }
    }

    void validate(int[] local, int[] groups, String pass) {
        if (local.length != 3 || groups.length != 3 || local[0] < 1 || local[1] < 1 || local[2] < 1)
            throw new IllegalArgumentException(pass + ": invalid compute dimensions");
        if (local[0] > sizeX
                || local[1] > sizeY
                || local[2] > sizeZ
                || (long) local[0] * local[1] * local[2] > invocations) {
            throw new IllegalArgumentException(
                    pass + ": compute local size exceeds live device limits");
        }
        if (groups[0] < 1
                || groups[1] < 1
                || groups[2] < 1
                || groups[0] > groupX
                || groups[1] > groupY
                || groups[2] > groupZ) {
            throw new IllegalArgumentException(pass + ": dispatch exceeds live device limits");
        }
    }

    static int subgroupFeature(int capability) {
        return switch (capability) {
            case SpvCapabilityGroupNonUniform -> VK_SUBGROUP_FEATURE_BASIC_BIT;
            case SpvCapabilityGroupNonUniformVote -> VK_SUBGROUP_FEATURE_VOTE_BIT;
            case SpvCapabilityGroupNonUniformArithmetic -> VK_SUBGROUP_FEATURE_ARITHMETIC_BIT;
            case SpvCapabilityGroupNonUniformBallot -> VK_SUBGROUP_FEATURE_BALLOT_BIT;
            case SpvCapabilityGroupNonUniformShuffle -> VK_SUBGROUP_FEATURE_SHUFFLE_BIT;
            case SpvCapabilityGroupNonUniformShuffleRelative ->
                    VK_SUBGROUP_FEATURE_SHUFFLE_RELATIVE_BIT;
            case SpvCapabilityGroupNonUniformClustered -> VK_SUBGROUP_FEATURE_CLUSTERED_BIT;
            case SpvCapabilityGroupNonUniformQuad -> VK_SUBGROUP_FEATURE_QUAD_BIT;
            default -> 0;
        };
    }

    void validateShaderFeatures(VeilSpirvBinary binary) {
        var capabilities = VeilSpirvAnalysis.inspect(binary).capabilities();
        boolean subgroup = false;
        for (int capability : capabilities) {
            int required = subgroupFeature(capability);
            if (required == 0) continue;
            subgroup = true;
            if ((subgroupStages & binary.stage().vkStageFlags()) == 0
                    || (subgroupOperations & required) == 0) {
                throw new IllegalArgumentException(
                        binary.sourceName()
                                + ": subgroup operation/stage is not supported by the live device");
            }
        }
        if (subgroup
                && !VeilVulkanCapabilities.subgroupExtendedTypes()
                && (capabilities.contains(SpvCapabilityFloat16)
                        || capabilities.contains(SpvCapabilityInt8)
                        || capabilities.contains(SpvCapabilityInt16))) {
            throw new IllegalArgumentException(
                    binary.sourceName()
                            + ": reduced-precision subgroup modules require enabled shaderSubgroupExtendedTypes");
        }
    }

    String report() {
        return "device="
                + device
                + " maxWorkgroup="
                + sizeX
                + "x"
                + sizeY
                + "x"
                + sizeZ
                + " maxInvocations="
                + invocations
                + " maxDispatch="
                + groupX
                + "x"
                + groupY
                + "x"
                + groupZ
                + " maxSharedBytes="
                + sharedBytes
                + "\nsubgroups: physicalSize="
                + subgroupSize
                + " supportedStages="
                + subgroupStages
                + " supportedOperations="
                + subgroupOperations
                + "\nvertexInput: attributes="
                + maxVertexAttributes
                + " bindings="
                + maxVertexBindings
                + " maxOffset="
                + maxVertexOffset
                + " maxStride="
                + maxVertexStride
                + " maxIndirectDrawCount="
                + maxIndirectDrawCount
                + "; subgroup size is queried, never inferred from vendor\n"
                + "enabled: float16="
                + VeilVulkanCapabilities.shaderFloat16()
                + " int16="
                + VeilVulkanCapabilities.shaderInt16()
                + " int8="
                + VeilVulkanCapabilities.shaderInt8()
                + " storage16="
                + VeilVulkanCapabilities.storageBuffer16()
                + " storage8="
                + VeilVulkanCapabilities.storageBuffer8()
                + " subgroupExtendedTypes="
                + VeilVulkanCapabilities.subgroupExtendedTypes()
                + "\n"
                + VeilRayCapabilities.report();
    }
}
