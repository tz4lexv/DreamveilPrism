package dev.veil.revive.client;

import dev.veil.revive.core.FrameRateBudgetScaler;
import dev.veil.revive.core.UploadBackpressureGovernor;
import dev.veil.revive.mixin.SectionTaskAccessor;

import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.phys.Vec3;

public final class VeilRebuildBudget {
    private static final long DEFAULT_COMPILE_NS = 350_000L;
    private static final long DEFAULT_UPLOAD_BYTES = 128L * 1024L;
    private static final double DEFAULT_UPLOAD_NS_PER_BYTE = 0.35;
    private static final long MIN_CPU_BUDGET_NS = 150_000L;
    private static final long MIN_UPLOAD_BUDGET = 512L * 1024L;
    private static final long MAX_UPLOAD_BUDGET = 8L * 1024L * 1024L;
    private static final long MIN_UPLOAD_DURATION_BUDGET_NS = 100_000L;
    private static final long MAX_UPLOAD_DURATION_BUDGET_NS = 2_000_000L;
    private static final int MAX_SECTION_ESTIMATES = 32_768;

    private static final Long2LongOpenHashMap SECTION_MESH_BYTES = new Long2LongOpenHashMap();
    private static final long[] SECTION_ESTIMATE_KEYS = new long[MAX_SECTION_ESTIMATES];
    private static int sectionEstimateKeyCount;
    private static int sectionEstimateEvictCursor;
    private static long sectionEstimateEvictions;
    private static final FrameRateBudgetScaler FRAME_RATE_SCALER = new FrameRateBudgetScaler();
    private static final UploadBackpressureGovernor UPLOAD_BACKPRESSURE =
            new UploadBackpressureGovernor();

    static {
        SECTION_MESH_BYTES.defaultReturnValue(-1L);
    }

    private static long cpuBudgetNs = 1_250_000L;
    private static long uploadBudgetBytes = 2L * 1024L * 1024L;
    private static long uploadDurationBudgetNs = 500_000L;
    private static long admittedCpuNs;
    private static long admittedUploadBytes;
    private static long admittedUploadDurationNs;
    private static int admittedTasks;
    private static int admittedFirstCompiles;
    private static int admittedPriorityOverBudget;

    private static double compileEmaNs = DEFAULT_COMPILE_NS;
    private static double meshBytesEma = DEFAULT_UPLOAD_BYTES;
    private static double uploadNsPerByteEma = DEFAULT_UPLOAD_NS_PER_BYTE;
    private static boolean compileEmaValid;
    private static boolean meshEmaValid;
    private static boolean uploadEmaValid;

    private static long installedMeshBytesTotal;
    private static long frames;
    private static long asyncKicks;
    private static long admitted;
    private static long deferred;
    private static long firstCompileAdmissions;
    private static long firstCompileBypasses;
    private static long firstCompileDeferred;
    private static long firstCompileProgressAdmissions;
    private static long firstCompileNativePriorityAdmissions;
    private static long priorityOverBudgetAdmissions;
    private static long visiblePriorityAdmissions;
    private static long nearPriorityAdmissions;
    private static long compileSamples;
    private static long meshSamples;
    private static long sectionEstimateHits;
    private static long sectionEstimateMisses;
    private static long uploadSamples;
    private static long uploadSampleBytes;
    private static int lastQueueDepth;
    private static double frameRateBudgetScale = 1.0;
    private static double uploadBackpressureScale = 1.0;
    private static double uploadBackpressurePressure;

    private VeilRebuildBudget() {}

    public static synchronized void beginFrame(int queueDepth) {
        frames++;
        lastQueueDepth = Math.max(0, queueDepth);
        admittedCpuNs = 0L;
        admittedUploadBytes = 0L;
        admittedUploadDurationNs = 0L;
        admittedTasks = 0;
        admittedFirstCompiles = 0;
        admittedPriorityOverBudget = 0;

        long baseCpu = Math.max(MIN_CPU_BUDGET_NS, ReviveRuntime.maintenanceBudgetNanos());
        long targetFrameNs = Math.max(1L, (long) (ReviveRuntime.targetFrameMs() * 1_000_000.0));
        long nowNs = System.nanoTime();
        frameRateBudgetScale = FRAME_RATE_SCALER.nextScale(nowNs, targetFrameNs);
        uploadBackpressureScale =
                UPLOAD_BACKPRESSURE.update(
                        nowNs, VeilRebuildCoalescer.uploadBackoffParkedNsTotal());
        uploadBackpressurePressure = UPLOAD_BACKPRESSURE.pressure();
        double framePressure = ReviveRuntime.framePressure();
        double backlogHeadroom = Math.clamp((1.1 - framePressure) / 0.3, 0.0, 1.0);
        double backlogScale =
                1.0 + backlogHeadroom * (queueDepth >= 256 ? 0.75 : queueDepth >= 64 ? 0.35 : 0.0);
        cpuBudgetNs =
                Math.max(
                        MIN_CPU_BUDGET_NS,
                        (long)
                                (baseCpu
                                        * backlogScale
                                        * frameRateBudgetScale
                                        * uploadBackpressureScale));

        long configuredStaging =
                Math.max(MIN_UPLOAD_BUDGET, ReviveRuntime.config().stagingBudgetBytes());
        long baseUpload = Math.clamp(configuredStaging / 8L, MIN_UPLOAD_BUDGET, MAX_UPLOAD_BUDGET);
        double frameScale =
                framePressure <= 0.85
                        ? 1.50
                        : framePressure <= 1.0 ? 1.0 : framePressure <= 1.20 ? 0.65 : 0.35;
        double memoryPressure = VeilMemoryMonitor.pressure();
        double memoryScale = memoryPressure >= 0.95 ? 0.40 : memoryPressure >= 0.88 ? 0.65 : 1.0;
        boolean shaderHeavy = VeilShaderPackBridge.efficiencyModeActive();
        double shaderScale = shaderHeavy ? 0.75 : 1.0;
        if (shaderHeavy) VeilShaderPackBridge.recordConservativeBudgetFrame();
        uploadBudgetBytes =
                Math.clamp(
                        (long)
                                (baseUpload
                                        * backlogScale
                                        * frameScale
                                        * memoryScale
                                        * shaderScale
                                        * frameRateBudgetScale
                                        * uploadBackpressureScale),
                        MIN_UPLOAD_BUDGET,
                        MAX_UPLOAD_BUDGET);

        long durationBase = Math.max(MIN_UPLOAD_DURATION_BUDGET_NS, (long) (baseCpu * 0.45));
        uploadDurationBudgetNs =
                Math.clamp(
                        (long)
                                (durationBase
                                        * backlogScale
                                        * frameScale
                                        * memoryScale
                                        * shaderScale
                                        * frameRateBudgetScale
                                        * uploadBackpressureScale),
                        MIN_UPLOAD_DURATION_BUDGET_NS,
                        MAX_UPLOAD_DURATION_BUDGET_NS);
    }

    public static synchronized boolean tryAdmit(
            SectionRenderDispatcher.RenderSection.SectionTask task, Vec3 cameraPos) {
        if (!ReviveRuntime.optimizationsEnabled() || !VeilVideoConfig.on("renderer.rebuildBudget"))
            return true;

        boolean recompile = ((SectionTaskAccessor) (Object) task).veil$isRecompile();
        long predictedBytes = predictedBytes(task);
        long predictedCpu = predictedCpuNs(predictedBytes);
        long predictedUploadNs = predictedUploadNs(predictedBytes);

        boolean cpuFits = admittedCpuNs + predictedCpu <= cpuBudgetNs;
        boolean uploadBytesFit = admittedUploadBytes + predictedBytes <= uploadBudgetBytes;
        boolean uploadTimeFits =
                admittedUploadDurationNs + predictedUploadNs <= uploadDurationBudgetNs;
        boolean fits = cpuFits && uploadBytesFit && uploadTimeFits;

        if (!recompile) {
            if (!fits) {
                firstCompileBypasses++;
                if (admittedTasks == 0) firstCompileProgressAdmissions++;
            }
            admittedCpuNs += predictedCpu;
            admittedUploadBytes += predictedBytes;
            admittedUploadDurationNs += predictedUploadNs;
            admittedTasks++;
            admittedFirstCompiles++;
            firstCompileAdmissions++;
            firstCompileNativePriorityAdmissions++;
            admitted++;
            return true;
        }

        boolean nearPriority = isCameraNear(task, cameraPos);
        boolean visiblePriority = VeilTerrainDrawBridge.isSectionVisible(task.getRenderOrigin());
        boolean priority = nearPriority || visiblePriority;

        int logicalProcessors = Math.max(1, Runtime.getRuntime().availableProcessors());
        int priorityEscapeLimit = logicalProcessors <= 4 ? 1 : 2;
        boolean progressGuarantee = admittedTasks == 0;
        boolean priorityEscape =
                priority
                        && uploadBytesFit
                        && uploadTimeFits
                        && admittedPriorityOverBudget < priorityEscapeLimit
                        && ReviveRuntime.framePressure() <= 1.20;

        if (!progressGuarantee && !fits && !priorityEscape) {
            deferred++;
            return false;
        }

        if (!fits) {

            if (!progressGuarantee && priorityEscape) {
                admittedPriorityOverBudget++;
                priorityOverBudgetAdmissions++;
                if (visiblePriority) visiblePriorityAdmissions++;
                if (nearPriority) nearPriorityAdmissions++;
            }
        }

        admittedCpuNs += predictedCpu;
        admittedUploadBytes += predictedBytes;
        admittedUploadDurationNs += predictedUploadNs;
        admittedTasks++;
        admitted++;
        return true;
    }

    private static long predictedBytes(SectionRenderDispatcher.RenderSection.SectionTask task) {
        long key = sectionKey(task.getRenderOrigin());
        long sectionBytes = SECTION_MESH_BYTES.get(key);
        if (sectionBytes >= 0L) {
            sectionEstimateHits++;
            return Math.max(16L * 1024L, sectionBytes);
        }
        sectionEstimateMisses++;
        return Math.max(16L * 1024L, (long) (meshEmaValid ? meshBytesEma : DEFAULT_UPLOAD_BYTES));
    }

    private static long predictedCpuNs(long predictedBytes) {
        double base = compileEmaValid ? compileEmaNs : DEFAULT_COMPILE_NS;
        double reference =
                Math.max(16.0 * 1024.0, meshEmaValid ? meshBytesEma : DEFAULT_UPLOAD_BYTES);

        double ratio = Math.clamp(predictedBytes / reference, 0.35, 3.0);
        return Math.max(50_000L, (long) (base * (0.45 + 0.55 * ratio)));
    }

    private static long predictedUploadNs(long predictedBytes) {
        double nsPerByte = uploadEmaValid ? uploadNsPerByteEma : DEFAULT_UPLOAD_NS_PER_BYTE;
        return Math.max(10_000L, (long) (predictedBytes * nsPerByte));
    }

    private static boolean isCameraNear(
            SectionRenderDispatcher.RenderSection.SectionTask task, Vec3 cameraPos) {
        if (cameraPos == null) return false;
        BlockPos origin = task.getRenderOrigin();
        double dx = origin.getX() + 8.0 - cameraPos.x;
        double dy = origin.getY() + 8.0 - cameraPos.y;
        double dz = origin.getZ() + 8.0 - cameraPos.z;
        return dx * dx + dy * dy + dz * dz <= 64.0 * 64.0;
    }

    private static long sectionKey(BlockPos origin) {
        return SectionPos.asLong(origin.getX() >> 4, origin.getY() >> 4, origin.getZ() >> 4);
    }

    public static synchronized void recordCompileDuration(long nanos) {
        if (nanos <= 0L || nanos > 5_000_000_000L) return;
        compileEmaNs = compileEmaValid ? compileEmaNs * 0.90 + nanos * 0.10 : nanos;
        compileEmaValid = true;
        compileSamples++;
    }

    public static synchronized void recordMeshBytes(long bytes) {
        if (bytes < 0L || bytes > 1L << 31) return;
        meshBytesEma = meshEmaValid ? meshBytesEma * 0.90 + bytes * 0.10 : bytes;
        meshEmaValid = true;
        meshSamples++;
    }

    public static synchronized void recordInstalledMesh(long sectionNode, long bytes) {
        if (bytes < 0L || bytes > 1L << 31) return;
        if (!SECTION_MESH_BYTES.containsKey(sectionNode)) {
            if (sectionEstimateKeyCount < MAX_SECTION_ESTIMATES) {
                SECTION_ESTIMATE_KEYS[sectionEstimateKeyCount++] = sectionNode;
            } else {
                long evicted = SECTION_ESTIMATE_KEYS[sectionEstimateEvictCursor];
                SECTION_MESH_BYTES.remove(evicted);
                SECTION_ESTIMATE_KEYS[sectionEstimateEvictCursor] = sectionNode;
                sectionEstimateEvictCursor++;
                if (sectionEstimateEvictCursor == MAX_SECTION_ESTIMATES)
                    sectionEstimateEvictCursor = 0;
                sectionEstimateEvictions++;
            }
        }
        SECTION_MESH_BYTES.put(sectionNode, bytes);
        installedMeshBytesTotal += bytes;
    }

    public static synchronized void resetSectionPredictors() {
        SECTION_MESH_BYTES.clear();
        sectionEstimateKeyCount = 0;
        sectionEstimateEvictCursor = 0;
        installedMeshBytesTotal = 0L;

        FRAME_RATE_SCALER.reset();
        UPLOAD_BACKPRESSURE.reset(VeilRebuildCoalescer.uploadBackoffParkedNsTotal());
        frameRateBudgetScale = 1.0;
        uploadBackpressureScale = 1.0;
        uploadBackpressurePressure = 0.0;
    }

    public static synchronized long installedMeshBytesTotal() {
        return installedMeshBytesTotal;
    }

    public static synchronized void recordAsyncKick() {
        asyncKicks++;
    }

    public static synchronized double lodUploadScale() {
        if (!ReviveRuntime.optimizationsEnabled() || !VeilVideoConfig.on("renderer.rebuildBudget"))
            return 1.0;
        return Math.min(
                uploadBackpressureScale,
                Math.min(frameRateBudgetScale, admittedFirstCompiles > 0 ? 0.35 : 1.0));
    }

    public static synchronized void recordUploadBatch(long nanos, long bytes) {
        if (nanos <= 0L || nanos > 2_000_000_000L || bytes <= 0L || bytes > 1L << 34) return;
        double sample = (double) nanos / (double) bytes;

        if (!Double.isFinite(sample) || sample <= 0.0 || sample > 100.0) return;
        uploadNsPerByteEma = uploadEmaValid ? uploadNsPerByteEma * 0.90 + sample * 0.10 : sample;
        uploadEmaValid = true;
        uploadSamples++;
        uploadSampleBytes += bytes;
    }

    public static synchronized String telemetry() {
        return "rebuild_budget_frames_total="
                + frames
                + "\n"
                + "rebuild_budget_async_kicks_total="
                + asyncKicks
                + "\n"
                + "rebuild_budget_last_queue_depth="
                + lastQueueDepth
                + "\n"
                + "rebuild_budget_cpu_ns="
                + cpuBudgetNs
                + "\n"
                + "rebuild_budget_frame_rate_scale="
                + String.format(java.util.Locale.ROOT, "%.4f", frameRateBudgetScale)
                + "\n"
                + "rebuild_budget_upload_backpressure_scale="
                + String.format(java.util.Locale.ROOT, "%.4f", uploadBackpressureScale)
                + "\n"
                + "rebuild_budget_upload_backpressure_pressure="
                + String.format(java.util.Locale.ROOT, "%.4f", uploadBackpressurePressure)
                + "\n"
                + "rebuild_budget_upload_bytes="
                + uploadBudgetBytes
                + "\n"
                + "rebuild_budget_upload_duration_ns="
                + uploadDurationBudgetNs
                + "\n"
                + "rebuild_budget_compile_ema_ns="
                + (long) compileEmaNs
                + "\n"
                + "rebuild_budget_mesh_bytes_ema="
                + (long) meshBytesEma
                + "\n"
                + "rebuild_budget_upload_ns_per_byte_ema="
                + String.format(java.util.Locale.ROOT, "%.4f", uploadNsPerByteEma)
                + "\n"
                + "rebuild_budget_admitted_total="
                + admitted
                + "\n"
                + "rebuild_budget_deferred_total="
                + deferred
                + "\n"
                + "rebuild_budget_first_compile_admitted_total="
                + firstCompileAdmissions
                + "\n"
                + "rebuild_budget_first_compile_bypass_total="
                + firstCompileBypasses
                + "\n"
                + "rebuild_budget_first_compile_deferred_total="
                + firstCompileDeferred
                + "\n"
                + "rebuild_budget_first_compile_progress_admissions_total="
                + firstCompileProgressAdmissions
                + "\n"
                + "rebuild_budget_first_compile_native_priority_total="
                + firstCompileNativePriorityAdmissions
                + "\n"
                + "rebuild_budget_priority_over_budget_total="
                + priorityOverBudgetAdmissions
                + "\n"
                + "rebuild_budget_visible_priority_over_budget_total="
                + visiblePriorityAdmissions
                + "\n"
                + "rebuild_budget_near_priority_over_budget_total="
                + nearPriorityAdmissions
                + "\n"
                + "rebuild_budget_compile_samples="
                + compileSamples
                + "\n"
                + "rebuild_budget_mesh_samples="
                + meshSamples
                + "\n"
                + "rebuild_budget_section_estimate_hits_total="
                + sectionEstimateHits
                + "\n"
                + "rebuild_budget_section_estimate_misses_total="
                + sectionEstimateMisses
                + "\n"
                + "rebuild_budget_section_estimate_evictions_total="
                + sectionEstimateEvictions
                + "\n"
                + "rebuild_budget_upload_samples="
                + uploadSamples
                + "\n"
                + "rebuild_budget_upload_sample_bytes="
                + uploadSampleBytes
                + "\n"
                + "rebuild_budget_section_estimates="
                + SECTION_MESH_BYTES.size()
                + "\n";
    }
}
