package dev.veil.api.graphics;

public enum RasterFeature {
    GEOMETRY,
    TESSELLATION,
    NON_SOLID,
    DEPTH_CLAMP,
    BIAS_CLAMP,
    WIDE_LINES,
    IMAGE_CUBE_ARRAY
}
