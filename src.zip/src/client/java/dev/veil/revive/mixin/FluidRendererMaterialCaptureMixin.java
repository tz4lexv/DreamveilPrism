package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.veil.revive.client.VeilFluidGeometryCapture;
import dev.veil.revive.client.VeilFluidMaterialCapture;

import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.FluidRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import org.spongepowered.asm.mixin.Mixin;

@Mixin(FluidRenderer.class)
public abstract class FluidRendererMaterialCaptureMixin {
    @WrapMethod(method = "tesselate")
    private void veil$captureOrRedirectFluidTessellation(
            BlockAndTintGetter level,
            BlockPos pos,
            FluidRenderer.Output output,
            BlockState blockState,
            FluidState fluidState,
            Operation<Void> original) {

        if (VeilFluidGeometryCapture.capturing()) {
            original.call(level, pos, output, blockState, fluidState);
            return;
        }

        if (VeilFluidGeometryCapture.shouldReplace(fluidState)) {
            VeilFluidGeometryCapture.begin(fluidState);
            FluidRenderer.Output redirected = VeilFluidGeometryCapture::builder;
            try {

                original.call(level, pos, redirected, blockState, fluidState);
            } finally {
                VeilFluidGeometryCapture.end();
            }
            return;
        }

        VeilFluidMaterialCapture.beginFluid(fluidState);
        FluidRenderer.Output observed =
                layer -> {
                    VertexConsumer consumer = output.getBuilder(layer);
                    return VeilFluidMaterialCapture.wrapBuilder(layer, consumer);
                };
        try {
            original.call(level, pos, observed, blockState, fluidState);
        } finally {
            VeilFluidMaterialCapture.endFluid();
        }
    }
}
