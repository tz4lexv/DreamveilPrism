package dev.veil.revive.client.scene.geometry;

import org.joml.Matrix4fc;
import org.joml.Vector4f;

public final class SceneSectionFrustum {
    private final double[][] planes = new double[6][4];
    private final double anchorX, anchorY, anchorZ;

    public SceneSectionFrustum(Matrix4fc matrix, double x, double y, double z) {
        if (!matrix.isFinite() || !Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z))
            throw new IllegalArgumentException("Invalid scene frustum");
        anchorX = x;
        anchorY = y;
        anchorZ = z;
        Vector4f a = new Vector4f(), w = matrix.getRow(3, new Vector4f());
        for (int axis = 0; axis < 3; axis++) {
            matrix.getRow(axis, a);
            set(axis * 2, axis == 2 ? a : new Vector4f(w).add(a));
            set(axis * 2 + 1, new Vector4f(w).sub(a));
        }
    }

    private void set(int index, Vector4f plane) {
        double scale =
                Math.sqrt(
                        (double) plane.x * plane.x
                                + (double) plane.y * plane.y
                                + (double) plane.z * plane.z);
        if (scale == 0) scale = 1;
        planes[index][0] = plane.x / scale;
        planes[index][1] = plane.y / scale;
        planes[index][2] = plane.z / scale;
        planes[index][3] = plane.w / scale;
    }

    public boolean intersects(int x, int y, int z) {
        double cx = x + 8.0 - anchorX, cy = y + 8.0 - anchorY, cz = z + 8.0 - anchorZ;
        for (double[] p : planes) {
            double support = 8 * (Math.abs(p[0]) + Math.abs(p[1]) + Math.abs(p[2]));
            if (p[0] * cx + p[1] * cy + p[2] * cz + p[3] + support < -0.001) return false;
        }
        return true;
    }
}
