package dev.veil.revive.client.graphics.resources;

/**
 * Splits a Vulkan indirect draw stream into submissions permitted by the live device.
 *
 * <p>If the device has not enabled multiDrawIndirect, each draw is submitted separately. With
 * multiDrawIndirect enabled, a large draw can be submitted in batches that never exceed
 * maxDrawIndirectCount. No command bytes are copied or reinterpreted: every submission points to
 * the corresponding byte offset in the original buffer.
 */
public final class IndirectDrawBatches {
    private IndirectDrawBatches() {}

    @FunctionalInterface
    public interface Submit {
        void draw(long offset, int drawCount, int stride);
    }

    public static void submit(
            long offset,
            int count,
            int stride,
            int commandBytes,
            boolean multiDrawEnabled,
            long maxDrawIndirectCount,
            Submit command) {
        if (command == null
                || offset < 0
                || (offset & 3L) != 0
                || count < 0
                || commandBytes < 1
                || stride < 0
                || (stride & 3) != 0
                || (count > 1 && stride < commandBytes)) {
            throw new IllegalArgumentException("Invalid indirect draw stream");
        }
        if (maxDrawIndirectCount < 1) {
            throw new IllegalArgumentException("Invalid maxDrawIndirectCount");
        }
        if (count == 0) return;
        try {
            // Check the final command before submitting any commands (no partial recording).
            Math.addExact(
                    Math.addExact(offset, Math.multiplyExact((long) count - 1, stride)),
                    commandBytes);
        } catch (ArithmeticException overflow) {
            throw new IllegalArgumentException(
                    "Indirect draw stream offset overflows long", overflow);
        }
        long maxBatch = multiDrawEnabled ? Math.min(maxDrawIndirectCount, Integer.MAX_VALUE) : 1;
        int cursor = 0;
        while (cursor < count) {
            int batchCount = (int) Math.min(maxBatch, (long) count - cursor);
            long batchOffset = offset + (long) cursor * stride; // prechecked above
            command.draw(batchOffset, batchCount, stride);
            cursor += batchCount;
        }
    }
}
