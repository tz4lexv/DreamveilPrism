package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.gui.render.GuiRenderer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiRenderer.class)
public abstract class GuiRendererFullTelemetryMixin {
    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void veil$guiStart(CallbackInfo ci) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.GUI_RENDER);
    }

    @Inject(method = "render", at = @At("RETURN"), require = 0)
    private void veil$guiEnd(CallbackInfo ci) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.GUI_RENDER);
    }
}
