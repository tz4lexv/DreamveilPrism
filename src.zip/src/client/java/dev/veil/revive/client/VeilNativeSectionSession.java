package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.BufferBuilder;

import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.block.BlockQuadOutput;
import net.minecraft.client.renderer.block.FluidRenderer;
import net.minecraft.client.renderer.block.FluidStateModelSet;
import net.minecraft.client.renderer.block.ModelBlockRenderer;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.function.Function;

public class VeilNativeSectionSession implements VeilSectionRenderAdapter.Session {
    private ModelBlockRenderer models;
    private final boolean ambientOcclusion;
    private final BlockColors colors;
    protected final FluidRenderer fluids;
    protected final FluidRenderer.Output fluidOutput;
    private final boolean cutoutLeaves;
    private final BlockQuadOutput layered, solid;

    protected BlockQuadOutput outputFor(BlockState state) {
        return ModelBlockRenderer.forceOpaque(cutoutLeaves, state) ? solid : layered;
    }

    public VeilNativeSectionSession(
            boolean ambientOcclusion,
            boolean cutoutLeaves,
            BlockColors colors,
            FluidStateModelSet fluidModels,
            Function<ChunkSectionLayer, BufferBuilder> builders) {
        this.cutoutLeaves = cutoutLeaves;
        this.ambientOcclusion = ambientOcclusion;
        this.colors = colors;
        fluids = new FluidRenderer(fluidModels);
        fluidOutput = builders::apply;
        layered =
                (x, y, z, quad, instance) -> {
                    VeilAnimatedSpriteUsage.recordOrMark(quad.materialInfo().sprite());
                    var target = builders.apply(quad.materialInfo().layer());
                    if (!VeilTerrainQuadWriter.emit(target, x, y, z, quad, instance))
                        target.putBlockBakedQuad(x, y, z, quad, instance);
                };
        solid =
                (x, y, z, quad, instance) -> {
                    VeilAnimatedSpriteUsage.recordOrMark(quad.materialInfo().sprite());
                    var target = builders.apply(ChunkSectionLayer.SOLID);
                    if (!VeilTerrainQuadWriter.emit(target, x, y, z, quad, instance))
                        target.putBlockBakedQuad(x, y, z, quad, instance);
                };
    }

    protected final ModelBlockRenderer nativeModels() {
        if (models == null) {
            models = new ModelBlockRenderer(ambientOcclusion, true, colors);
            VeilBlockModelRenderer.recordNativeContext();
        }
        return models;
    }

    @Override
    public void model(
            RenderSectionRegion region,
            BlockPos position,
            BlockState state,
            BlockStateModel model,
            int x,
            int y,
            int z) {
        nativeModels()
                .tesselateBlock(
                        outputFor(state),
                        x,
                        y,
                        z,
                        region,
                        position,
                        state,
                        model,
                        state.getSeed(position));
    }

    @Override
    public void fluid(
            RenderSectionRegion region, BlockPos position, BlockState state, FluidState fluid) {
        fluids.tesselate(region, position, fluidOutput, state, fluid);
    }
}
