package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import org.joml.Vector4f;

import java.util.Map;

final class VeilShaderSceneProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.sceneProbe") && VeilPlatform.get().isDevelopmentEnvironment();
    private static long start;
    private static boolean pending;
    private static boolean completed;
    private static TextureTarget target;
    private static VeilShaderPackRuntime previousGeneration;
    private static int generation;
    private static int step;
    private static int pixels;
    private static float[][] previous;

    private VeilShaderSceneProbe() {}

    static Map<String, String> overrides() {
        return ENABLED
                ? Map.of("exposure", "0.5", "historyMix", "0.5", "depthMix", "0.25")
                : Map.of();
    }

    static void tick(VeilShaderPackRuntime active, boolean failed) {
        if (!ENABLED || completed) return;
        if (start == 0) start = System.nanoTime();
        if (failed || System.nanoTime() - start > 90_000_000_000L) {
            fail(new IllegalStateException("Scene probe runtime unavailable or timed out"));
            return;
        }
        if (pending || active == null || active == previousGeneration) return;
        if (!active.requiresScene()) {
            fail(new IllegalStateException("Scene probe requires the scene pack"));
            return;
        }
        try {
            int width = step >= 3 ? 96 : 64;
            int height = step >= 3 ? 48 : 64;
            if (target == null)
                target =
                        new TextureTarget(
                                "Veil scene probe", width, height, true, GpuFormat.RGBA8_UNORM);
            else if (target.width != width || target.height != height) target.resize(width, height);
            if (step == 0 || step == 2) active.invalidateHistory();
            boolean useHistory = step == 1 || step == 4;
            float[][] expected = new float[4][3];
            var encoder = RenderSystem.getDevice().createCommandEncoder();
            for (int quadrant = 0; quadrant < 4; quadrant++) {
                float red = ((step + quadrant) % 5) * 0.2f;
                float green = ((step + quadrant + 2) % 5) * 0.2f;
                float blue = ((step + quadrant + 4) % 5) * 0.2f;
                float depth = ((step + quadrant) % 4) * 0.25f;
                encoder.clearColorAndDepthTextures(
                        target.getColorTexture(),
                        new Vector4f(red, green, blue, 1),
                        target.getDepthTexture(),
                        depth,
                        (quadrant & 1) * (width / 2),
                        (quadrant >> 1) * (height / 2),
                        width / 2,
                        height / 2);
                float[] color = {red, green, blue};
                for (int channel = 0; channel < 3; channel++) {
                    float current = color[channel] * 0.375f + depth * 0.25f;
                    expected[quadrant][channel] =
                            useHistory ? (current + previous[quadrant][channel]) * 0.5f : current;
                }
            }
            active.executeScene(target, step * 0.016f, 0.016f);
            var readback =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil scene probe readback",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    (long) width * height * 4);
            pending = true;
            try {
                active.readPresented(
                        readback,
                        () -> {
                            try (var mapped = readback.map(true, false)) {
                                var bytes = mapped.data();
                                for (int y = 0; y < height; y++)
                                    for (int x = 0; x < width; x++) {
                                        int quadrant =
                                                (x >= width / 2 ? 1 : 0)
                                                        + (y >= height / 2 ? 2 : 0);
                                        for (int channel = 0; channel < 4; channel++) {
                                            int actual =
                                                    Byte.toUnsignedInt(
                                                            bytes.get(
                                                                    (y * width + x) * 4 + channel));
                                            int wanted =
                                                    channel == 3
                                                            ? 255
                                                            : Math.round(
                                                                    expected[quadrant][channel]
                                                                            * 255);
                                            if (Math.abs(actual - wanted) > 2)
                                                throw new IllegalStateException(
                                                        "step="
                                                                + step
                                                                + " x="
                                                                + x
                                                                + " y="
                                                                + y
                                                                + " channel="
                                                                + channel
                                                                + " expected="
                                                                + wanted
                                                                + " actual="
                                                                + actual);
                                        }
                                    }
                                pixels += width * height;
                                previous = expected;
                                step++;
                                if (step == 5) {
                                    if (VeilShaderService.profiling()) {
                                        active.requireProfileSamples(1);
                                        ReviveMod.LOGGER.info(
                                                "Veil scene shader profile:\n{}",
                                                VeilShaderService.performanceReport());
                                    }
                                    generation++;
                                    if (generation == 2) {
                                        completed = true;
                                        ReviveMod.LOGGER.info(
                                                "Veil scene GPU probe: PASS ({} pixels, 2 generations, scene color/depth, presentation orientation, temporal ping-pong, invalidation, resize)",
                                                pixels);
                                    } else {
                                        previousGeneration = active;
                                        step = 0;
                                        VeilShaderService.requestReload();
                                        ReviveMod.LOGGER.info(
                                                "Veil scene GPU probe: first generation verified; requesting reload");
                                    }
                                }
                            } catch (RuntimeException failure) {
                                fail(failure);
                            } finally {
                                readback.close();
                                pending = false;
                                if (completed) finish();
                            }
                        });
            } catch (RuntimeException failure) {
                readback.close();
                pending = false;
                throw failure;
            }
        } catch (RuntimeException failure) {
            fail(failure);
        }
    }

    private static void fail(RuntimeException failure) {
        completed = true;
        ReviveMod.LOGGER.error("Veil scene GPU probe: FAIL ({})", failure.getMessage(), failure);
        if (!pending) finish();
    }

    private static void finish() {
        if (target != null) {
            target.destroyBuffers();
            target = null;
        }
        Minecraft.getInstance().stop();
    }
}
