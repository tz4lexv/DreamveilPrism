package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

final class VeilLatencyController {
    private static final long MAX_WAIT_NS = 50_000_000L;
    private static GpuFence previousFrame;
    private static boolean earlyWaitPerformed;
    private static long waits;
    private static long earlyWaits;
    private static long fallbackWaits;
    private static long completed;
    private static long timeouts;
    private static long waitedNs;
    private static long benchmarkSuppressedFrames;

    private VeilLatencyController() {}

    static void beforeClientFrame() {
        if (benchmarkSuppressed()) benchmarkSuppressedFrames++;
        if (!enabled()) {
            closeFence();
            earlyWaitPerformed = false;
            return;
        }
        waitPrevious(true);
        earlyWaitPerformed = true;
    }

    static void beforeWorldRender() {
        if (!enabled()) {
            closeFence();
            earlyWaitPerformed = false;
            return;
        }
        if (!earlyWaitPerformed) waitPrevious(false);
    }

    static void afterWorldRender() {
        if (!enabled()) return;
        closeFence();

        previousFrame = RenderSystem.getDevice().createCommandEncoder().createFence();
        earlyWaitPerformed = false;
    }

    private static void waitPrevious(boolean early) {
        GpuFence fence = previousFrame;
        previousFrame = null;
        if (fence == null) return;
        long start = System.nanoTime();
        try {
            waits++;
            if (early) earlyWaits++;
            else fallbackWaits++;
            if (fence.awaitCompletion(MAX_WAIT_NS)) completed++;
            else timeouts++;
        } finally {
            waitedNs += System.nanoTime() - start;
            fence.close();
        }
    }

    private static boolean configured() {
        return VeilVideoConfig.flag("latency.lowLatency", false);
    }

    private static boolean benchmarkSuppressed() {
        return configured()
                && (VeilDiagnostics.benchmarkActive() || VeilSubmissionBenchmark.active());
    }

    private static boolean enabled() {
        if (benchmarkSuppressed()) return false;
        if (!ReviveRuntime.optimizationsEnabled()) return false;
        return configured();
    }

    static void resetCounters() {
        waits = 0L;
        earlyWaits = 0L;
        fallbackWaits = 0L;
        completed = 0L;
        timeouts = 0L;
        waitedNs = 0L;
        benchmarkSuppressedFrames = 0L;
    }

    static String telemetry() {
        return "latency_configured="
                + configured()
                + "\n"
                + "latency_benchmark_suppressed="
                + benchmarkSuppressed()
                + "\n"
                + "latency_benchmark_suppressed_frames_total="
                + benchmarkSuppressedFrames
                + "\n"
                + "latency_mode="
                + (enabled() ? "low" : "throughput")
                + "\n"
                + "latency_render_ahead_limit="
                + (enabled() ? 1 : 2)
                + "\n"
                + "latency_waits_total="
                + waits
                + "\n"
                + "latency_early_waits_total="
                + earlyWaits
                + "\n"
                + "latency_world_render_fallback_waits_total="
                + fallbackWaits
                + "\n"
                + "latency_wait_completed_total="
                + completed
                + "\n"
                + "latency_wait_timeouts_total="
                + timeouts
                + "\n"
                + "latency_wait_ms_total="
                + String.format(java.util.Locale.ROOT, "%.3f", waitedNs / 1_000_000.0)
                + "\n";
    }

    static void close() {
        closeFence();
        earlyWaitPerformed = false;
    }

    private static void closeFence() {
        if (previousFrame != null) {
            previousFrame.close();
            previousFrame = null;
        }
    }
}
