package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilCreatorLightUpdates;
import dev.veil.revive.client.VeilLightingPipeline;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Deque;

@Mixin(ClientLevel.class)
public abstract class ClientLevelLightUpdateMixin {
    @Shadow @Final private Deque<Runnable> lightUpdateQueue;

    @Inject(method = "setBlock", at = @At("RETURN"), require = 1)
    private void veil$changedLight(
            BlockPos position,
            BlockState state,
            int flags,
            int recursion,
            CallbackInfoReturnable<Boolean> ci) {
        if (ci.getReturnValueZ())
            VeilCreatorLightUpdates.blockChanged((ClientLevel) (Object) this, position);
    }

    @Inject(method = "setBlocksDirty", at = @At("RETURN"), require = 1)
    private void veil$dirtyLight(
            BlockPos position, BlockState before, BlockState after, CallbackInfo ci) {
        if (before.getLightEmission() != after.getLightEmission())
            VeilCreatorLightUpdates.blockChanged((ClientLevel) (Object) this, position);
    }

    @Inject(method = "pollLightUpdates", at = @At("HEAD"), cancellable = true, require = 0)
    private void veil$budgetLightUpdates(CallbackInfo ci) {
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.LIGHT_UPDATE);
        if (!VeilLightingPipeline.schedulerEnabled()) return;
        VeilLightingPipeline.drainQueuedLightUpdates(this.lightUpdateQueue);
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.LIGHT_UPDATE);
        ci.cancel();
    }

    @Inject(method = "pollLightUpdates", at = @At("RETURN"), require = 0)
    private void veil$endLightUpdates(CallbackInfo ci) {
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.LIGHT_UPDATE);
    }
}
