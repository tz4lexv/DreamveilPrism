package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilEntityPipelineCounters;
import dev.veil.revive.client.VeilShaderPackBridge;
import dev.veil.revive.client.VeilVisibilityBudget;

import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.extract.LevelExtractor;
import net.minecraft.world.entity.Entity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LevelExtractor.class)
public abstract class LevelExtractorEntityCullMixin {
    @Inject(method = "isEntityVisible", at = @At("HEAD"), cancellable = true, require = 1)
    private void veil$rejectExactDistance(
            Entity entity,
            Frustum frustum,
            double x,
            double y,
            double z,
            CallbackInfoReturnable<Boolean> cir) {
        boolean diagnostics = VeilDiagnostics.benchmarkActive();
        if (diagnostics) VeilEntityPipelineCounters.visibilityCheck();
        if (VeilShaderPackBridge.renderingShadowPass()) return;
        if (VeilVisibilityBudget.entityOutsideRenderDistance(entity, x, y, z)) {
            if (diagnostics) VeilEntityPipelineCounters.exactDistanceReject();
            cir.setReturnValue(false);
        }
    }
}
