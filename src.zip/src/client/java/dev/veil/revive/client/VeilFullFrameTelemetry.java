package dev.veil.revive.client;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.GpuQueryPool;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;

import java.lang.management.ManagementFactory;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;
import java.util.OptionalLong;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

public final class VeilFullFrameTelemetry {
    public enum Mode {
        OFF,
        LIGHT,
        CAPTURE,
        DEEP
    }

    public enum CpuZone {
        CLIENT_FRAME("client_frame"),
        CLIENT_TICK("client_tick"),
        WORLD_EXTRACT("world_extract"),
        WORLD_RENDER("world_render"),
        TERRAIN_PREPARE("terrain_prepare"),
        OCCLUSION_GRAPH("occlusion_graph"),
        TERRAIN_UPLOAD("terrain_upload"),
        SECTION_COMPILE("section_compile"),
        LIGHT_UPDATE("light_update"),
        LIGHTMAP("lightmap"),
        ENTITY_VISIBLE_LOOP("entity_visible_loop"),
        ENTITY_EXTRACT("entity_extract"),
        ENTITY_SUBMIT("entity_submit"),
        BLOCK_ENTITY_EXTRACT("block_entity_extract"),
        BLOCK_ENTITY_SUBMIT("block_entity_submit"),
        PARTICLE_EXTRACT("particle_extract"),
        WEATHER_EXTRACT("weather_extract"),
        SKY_EXTRACT("sky_extract"),
        FEATURE_PREPARE("feature_prepare"),
        FEATURE_SOLID("feature_solid"),
        FEATURE_TRANSLUCENT("feature_translucent"),
        FEATURE_OTHER("feature_other"),
        GUI_RENDER("gui_render"),
        TERRAIN_OPAQUE_SUBMIT("terrain_opaque_submit"),
        TERRAIN_TRANSLUCENT_SUBMIT("terrain_translucent_submit"),
        SHADER_GEOMETRY_REDUCTION("shader_geometry_reduction"),
        COMMAND_SUBMIT("command_submit"),
        COMMAND_SUBMIT_PACING_WAIT("command_submit_pacing_wait"),
        RENDER_PASS_RECORDING("render_pass_recording");

        public final String key;

        CpuZone(String key) {
            this.key = key;
        }
    }

    public enum GpuCategory {
        SHADOW("shadow"),
        GBUFFER("gbuffer"),
        DEFERRED("deferred"),
        COMPOSITE("composite"),
        POST("post"),
        TERRAIN("terrain"),
        ENTITY_FEATURES("entity_features"),
        PARTICLES("particles"),
        SKY("sky"),
        CLOUDS("clouds"),
        WEATHER("weather"),
        GUI("gui"),
        HZB("hzb"),
        VEIL("veil"),
        OTHER("other");

        public final String key;

        GpuCategory(String key) {
            this.key = key;
        }
    }

    public enum LoadCounter {
        RENDER_PASSES("render_passes"),
        PIPELINE_BINDS("pipeline_binds"),
        DRAW_CALLS("draw_calls"),
        INDEXED_DRAW_CALLS("indexed_draw_calls"),
        INDIRECT_DRAW_CALLS("indirect_draw_calls"),
        MULTI_DRAW_CALLS("multi_draw_calls"),
        VERTICES_SUBMITTED("vertices_submitted"),
        INDICES_SUBMITTED("indices_submitted"),
        INSTANCES_SUBMITTED("instances_submitted"),
        COMMAND_SUBMITS("command_submits"),
        SECTIONS_COMPILED("sections_compiled"),
        SECTION_COMPILE_ALLOC_BYTES("section_compile_alloc_bytes"),
        CLIENT_FRAME_ALLOC_BYTES("client_frame_alloc_bytes"),
        LIGHT_TASKS("light_tasks"),
        LIGHT_TASKS_DEFERRED("light_tasks_deferred"),
        TERRAIN_UPLOAD_BYTES("terrain_upload_bytes"),
        ENTITY_STATES("entity_states"),
        BLOCK_ENTITY_STATES("block_entity_states"),
        SHADER_GEOMETRY_QUADS("shader_geometry_quads"),
        SHADER_GEOMETRY_QUADS_REMOVED("shader_geometry_quads_removed");

        public final String key;

        LoadCounter(String key) {
            this.key = key;
        }
    }

    private static final LongAdder[] CPU_NS = adders(CpuZone.values().length);
    private static final LongAdder[] CPU_CALLS = adders(CpuZone.values().length);
    private static final LongAdder[] LOAD = adders(LoadCounter.values().length);
    private static final LongAdder[] GPU_NS = adders(GpuCategory.values().length);
    private static final LongAdder[] GPU_SAMPLES = adders(GpuCategory.values().length);

    private static final ThreadLocal<CpuState> CPU_STATE = ThreadLocal.withInitial(CpuState::new);
    private static final ConcurrentHashMap<String, RawGpuTotals> RAW_GPU =
            new ConcurrentHashMap<>();

    private static final int GPU_SLOT_COUNT = 4;
    private static final int MAX_GPU_SEGMENTS = 96;
    private static final int QUERIES_PER_SEGMENT = 2;
    private static final int QUERIES_PER_SLOT = MAX_GPU_SEGMENTS * QUERIES_PER_SEGMENT;
    private static final GpuFrameSlot[] GPU_SLOTS = new GpuFrameSlot[GPU_SLOT_COUNT];
    private static GpuQueryPool gpuPool;
    private static int currentGpuSlot = -1;
    private static long clientFrameOrdinal;
    private static long gpuFramesSampled;
    private static long gpuFramesSkippedBusy;
    private static long gpuSegmentOverflow;
    private static volatile Mode mode = Mode.OFF;
    private static volatile boolean clientFrameOpen;
    private static volatile long clientFrameStartNs;
    private static volatile long clientFrameAllocStart = -1L;
    private static final com.sun.management.ThreadMXBean THREAD_MX = threadMx();

    static {
        for (int i = 0; i < GPU_SLOTS.length; i++) GPU_SLOTS[i] = new GpuFrameSlot();
    }

    private VeilFullFrameTelemetry() {}

    public static Mode mode() {
        return mode;
    }

    public static boolean active() {
        return mode != Mode.OFF;
    }

    public static boolean captureOrDeep() {
        return mode == Mode.CAPTURE || mode == Mode.DEEP;
    }

    public static void beginClientFrame() {
        Mode next = resolveMode();
        mode = next;
        clientFrameOrdinal++;
        pollGpuSlots();
        armGpuFrame(next);
        if (next == Mode.OFF) {
            clientFrameOpen = false;
            return;
        }
        clientFrameOpen = true;
        clientFrameStartNs = System.nanoTime();
        clientFrameAllocStart =
                allocatedBytesCurrentThread(next == Mode.CAPTURE || next == Mode.DEEP);
        beginCpu(CpuZone.CLIENT_FRAME);
    }

    public static void endClientFrame() {
        if (!clientFrameOpen) return;
        endCpu(CpuZone.CLIENT_FRAME);
        long allocStart = clientFrameAllocStart;
        if (allocStart >= 0L) {
            long end = allocatedBytesCurrentThread(true);
            if (end >= allocStart) addLoad(LoadCounter.CLIENT_FRAME_ALLOC_BYTES, end - allocStart);
        }
        clientFrameAllocStart = -1L;
        clientFrameStartNs = 0L;
        clientFrameOpen = false;
        sealGpuFrame();
    }

    public static void beginCpu(CpuZone zone) {
        if (!active()) return;
        CpuState state = CPU_STATE.get();
        int i = zone.ordinal();
        if (state.depth[i]++ == 0) state.start[i] = System.nanoTime();
    }

    public static void endCpu(CpuZone zone) {
        CpuState state = CPU_STATE.get();
        int i = zone.ordinal();
        int depth = state.depth[i];
        if (depth <= 0) return;
        if (--state.depth[i] == 0) {
            long start = state.start[i];
            state.start[i] = 0L;
            if (start != 0L) {
                long end = System.nanoTime();
                CPU_NS[i].add(Math.max(0L, end - start));
                CPU_CALLS[i].increment();
                VeilCpuZoneJfrProbe.record(zone.name(), start, end);
            }
        }
    }

    public static long allocationMarker() {
        return captureOrDeep() ? allocatedBytesCurrentThread(true) : -1L;
    }

    public static void sectionCompileFinished(long allocationMarker) {
        addLoad(LoadCounter.SECTIONS_COMPILED, 1L);
        if (allocationMarker >= 0L) {
            long end = allocatedBytesCurrentThread(true);
            if (end >= allocationMarker)
                addLoad(LoadCounter.SECTION_COMPILE_ALLOC_BYTES, end - allocationMarker);
        }
    }

    public static void addLoad(LoadCounter counter, long value) {
        if (!active() || value <= 0L) return;
        LOAD[counter.ordinal()].add(value);
    }

    public static int beginGpuRenderPass(RenderPass pass, RenderPipeline pipeline) {
        if (!active()) return -1;
        addLoad(LoadCounter.RENDER_PASSES, 1L);
        addLoad(LoadCounter.PIPELINE_BINDS, 1L);
        beginCpu(CpuZone.RENDER_PASS_RECORDING);
        String label = pipelineLabel(pipeline);
        int slotIndex = currentGpuSlot;
        if (slotIndex < 0 || gpuPool == null) return encodeCpuOnlyToken(classify(label));
        GpuFrameSlot slot = GPU_SLOTS[slotIndex];
        int segment = slot.segmentCount;
        if (segment >= MAX_GPU_SEGMENTS) {
            gpuSegmentOverflow++;
            return encodeCpuOnlyToken(classify(label));
        }
        int token = (slotIndex << 16) | segment;
        slot.segmentCount++;
        slot.labels[segment] = label;
        slot.categories[segment] = classify(label);
        slot.started[segment] = true;
        slot.ended[segment] = false;
        slot.drawCalls[segment] = 0L;
        slot.vertices[segment] = 0L;
        slot.indices[segment] = 0L;
        try {
            writeGpuTimestamp(pass, query(slotIndex, segment, 0));
            slot.pending = true;
        } catch (RuntimeException ignored) {
            slot.started[segment] = false;
            return encodeCpuOnlyToken(slot.categories[segment]);
        }
        return token;
    }

    public static void pipelineBound(int token, RenderPipeline pipeline) {
        if (!active()) return;
        addLoad(LoadCounter.PIPELINE_BINDS, 1L);
        if (token < 0 || isCpuOnlyToken(token)) return;
        int slotIndex = token >>> 16;
        int segment = token & 0xFFFF;
        if (!validSegment(slotIndex, segment)) return;
        String next = pipelineLabel(pipeline);
        GpuFrameSlot slot = GPU_SLOTS[slotIndex];
        String primary = slot.labels[segment];
        if (primary != null && !primary.equals(next)) {

            slot.pipelineChanges[segment]++;
        }
    }

    public static void draw(
            int token, long vertices, long indices, long instances, boolean indexed) {
        if (!active()) return;
        addLoad(LoadCounter.DRAW_CALLS, 1L);
        if (indexed) addLoad(LoadCounter.INDEXED_DRAW_CALLS, 1L);
        if (vertices > 0L) addLoad(LoadCounter.VERTICES_SUBMITTED, vertices);
        if (indices > 0L) addLoad(LoadCounter.INDICES_SUBMITTED, indices);
        if (instances > 0L) addLoad(LoadCounter.INSTANCES_SUBMITTED, instances);
        if (token < 0 || isCpuOnlyToken(token)) return;
        int slotIndex = token >>> 16;
        int segment = token & 0xFFFF;
        if (!validSegment(slotIndex, segment)) return;
        GpuFrameSlot slot = GPU_SLOTS[slotIndex];
        slot.drawCalls[segment]++;
        slot.vertices[segment] += Math.max(0L, vertices);
        slot.indices[segment] += Math.max(0L, indices);
    }

    public static void indirectDraw(int token, int drawCount, boolean indexed) {
        if (!active()) return;
        int count = Math.max(0, drawCount);
        addLoad(LoadCounter.INDIRECT_DRAW_CALLS, 1L);
        addLoad(LoadCounter.DRAW_CALLS, Math.max(1, count));
        if (indexed) addLoad(LoadCounter.INDEXED_DRAW_CALLS, Math.max(1, count));
        recordDrawCountOnGpuSegment(token, count);
    }

    public static void multiDraw(int token, int drawCount, boolean indexed) {
        if (!active()) return;
        int count = Math.max(0, drawCount);
        addLoad(LoadCounter.MULTI_DRAW_CALLS, 1L);
        addLoad(LoadCounter.DRAW_CALLS, Math.max(1, count));
        if (indexed) addLoad(LoadCounter.INDEXED_DRAW_CALLS, Math.max(1, count));
        recordDrawCountOnGpuSegment(token, count);
    }

    public static void drawMultipleIndexed(
            int token, java.util.Collection<? extends RenderPass.Draw<?>> draws) {
        if (!active() || draws == null || draws.isEmpty()) return;
        long drawCount = draws.size();
        long indices = 0L;
        for (RenderPass.Draw<?> draw : draws) indices += Math.max(0, draw.indexCount());
        addLoad(LoadCounter.MULTI_DRAW_CALLS, 1L);
        addLoad(LoadCounter.DRAW_CALLS, drawCount);
        addLoad(LoadCounter.INDEXED_DRAW_CALLS, drawCount);
        addLoad(LoadCounter.INDICES_SUBMITTED, indices);
        recordDrawCountOnGpuSegment(token, drawCount);
        recordIndicesOnGpuSegment(token, indices);
    }

    private static void recordDrawCountOnGpuSegment(int token, long draws) {
        if (token < 0 || isCpuOnlyToken(token)) return;
        int slotIndex = token >>> 16;
        int segment = token & 0xFFFF;
        if (!validSegment(slotIndex, segment)) return;
        GPU_SLOTS[slotIndex].drawCalls[segment] += Math.max(0L, draws);
    }

    private static void recordIndicesOnGpuSegment(int token, long indices) {
        if (token < 0 || isCpuOnlyToken(token)) return;
        int slotIndex = token >>> 16;
        int segment = token & 0xFFFF;
        if (!validSegment(slotIndex, segment)) return;
        GPU_SLOTS[slotIndex].indices[segment] += Math.max(0L, indices);
    }

    public static void endGpuRenderPass(RenderPass pass, int token) {
        endCpu(CpuZone.RENDER_PASS_RECORDING);
        if (!active()) return;
        if (token < 0 || isCpuOnlyToken(token) || gpuPool == null) return;
        int slotIndex = token >>> 16;
        int segment = token & 0xFFFF;
        if (!validSegment(slotIndex, segment)) return;
        GpuFrameSlot slot = GPU_SLOTS[slotIndex];
        if (!slot.started[segment] || slot.ended[segment]) return;
        try {
            writeGpuTimestamp(pass, query(slotIndex, segment, 1));
            slot.ended[segment] = true;
            slot.pending = true;
        } catch (RuntimeException ignored) {
            slot.started[segment] = false;
        }
    }

    public static void commandSubmitStart() {
        if (!active()) return;
        beginCpu(CpuZone.COMMAND_SUBMIT);
        addLoad(LoadCounter.COMMAND_SUBMITS, 1L);
    }

    public static void commandSubmitEnd() {
        endCpu(CpuZone.COMMAND_SUBMIT);
    }

    public static void commandSubmitPacingWaitStart() {
        beginCpu(CpuZone.COMMAND_SUBMIT_PACING_WAIT);
    }

    public static void commandSubmitPacingWaitEnd() {
        endCpu(CpuZone.COMMAND_SUBMIT_PACING_WAIT);
    }

    public static Snapshot snapshot() {
        long[] cpuNs = sums(CPU_NS), cpuCalls = sums(CPU_CALLS), load = sums(LOAD);
        long[] gpuNs = sums(GPU_NS), gpuSamples = sums(GPU_SAMPLES);
        return new Snapshot(
                cpuNs,
                cpuCalls,
                load,
                gpuNs,
                gpuSamples,
                gpuFramesSampled,
                gpuFramesSkippedBusy,
                gpuSegmentOverflow);
    }

    public static String telemetry() {
        Snapshot s = snapshot();
        StringBuilder out = new StringBuilder(4096);
        out.append("v43_telemetry_mode=").append(mode).append('\n');
        out.append("v43_gpu_profiled_frames_total=").append(s.gpuFramesSampled).append('\n');
        out.append("v43_gpu_skipped_busy_frames_total=")
                .append(s.gpuFramesSkippedBusy)
                .append('\n');
        out.append("v43_gpu_segment_overflow_total=").append(s.gpuSegmentOverflow).append('\n');
        for (CpuZone z : CpuZone.values()) {
            long calls = s.cpuCalls[z.ordinal()];
            out.append("v43_cpu_").append(z.key).append("_calls=").append(calls).append('\n');
            out.append("v43_cpu_")
                    .append(z.key)
                    .append("_avg_ms=")
                    .append(f4(avgMs(s.cpuNs[z.ordinal()], calls)))
                    .append('\n');
        }
        for (GpuCategory c : GpuCategory.values()) {
            long samples = s.gpuSamples[c.ordinal()];
            out.append("v43_gpu_").append(c.key).append("_samples=").append(samples).append('\n');
            out.append("v43_gpu_")
                    .append(c.key)
                    .append("_avg_ms=")
                    .append(f4(avgMs(s.gpuNs[c.ordinal()], samples)))
                    .append('\n');
            out.append("v43_gpu_")
                    .append(c.key)
                    .append("_ms_per_profiled_frame=")
                    .append(f4(msPerProfiledFrame(s, c)))
                    .append('\n');
        }
        for (LoadCounter c : LoadCounter.values()) {
            out.append("v43_load_")
                    .append(c.key)
                    .append("_total=")
                    .append(s.load[c.ordinal()])
                    .append('\n');
        }
        appendRawGpuTop(out, 12);
        return out.toString();
    }

    public static String analysis(Snapshot delta) {
        StringBuilder out = new StringBuilder(4096);
        out.append("--- V45 FULL FRAME TELEMETRY / BOTTLENECK ANALYSIS ---\n");
        out.append(
                "Measurement policy: CPU zones may overlap/nest; GPU timestamp results are non-blocking and may cover fewer frames than CPU.\n");
        out.append("MEASURED CPU TOP:\n");
        Arrays.stream(CpuZone.values())
                .filter(z -> delta.cpuCalls[z.ordinal()] > 0)
                .sorted(
                        Comparator.comparingDouble(
                                        (CpuZone z) ->
                                                avgMs(
                                                        delta.cpuNs[z.ordinal()],
                                                        delta.cpuCalls[z.ordinal()]))
                                .reversed())
                .limit(8)
                .forEach(
                        z ->
                                out.append("  ")
                                        .append(z.key)
                                        .append(": ")
                                        .append(
                                                f4(
                                                        avgMs(
                                                                delta.cpuNs[z.ordinal()],
                                                                delta.cpuCalls[z.ordinal()])))
                                        .append(" ms/call | calls=")
                                        .append(delta.cpuCalls[z.ordinal()])
                                        .append('\n'));
        out.append("MEASURED GPU TOP (classified from pipeline/pass identity):\n");
        out.append("  profiled_frames=")
                .append(delta.gpuFramesSampled)
                .append(" | skipped_busy=")
                .append(delta.gpuFramesSkippedBusy)
                .append('\n');
        Arrays.stream(GpuCategory.values())
                .filter(c -> delta.gpuSamples[c.ordinal()] > 0)
                .sorted(
                        Comparator.comparingDouble((GpuCategory c) -> msPerProfiledFrame(delta, c))
                                .reversed())
                .limit(8)
                .forEach(
                        c ->
                                out.append("  ")
                                        .append(c.key)
                                        .append(": ")
                                        .append(f4(msPerProfiledFrame(delta, c)))
                                        .append(" ms/profiled frame | avg_pass=")
                                        .append(
                                                f4(
                                                        avgMs(
                                                                delta.gpuNs[c.ordinal()],
                                                                delta.gpuSamples[c.ordinal()])))
                                        .append(" ms | pass_samples=")
                                        .append(delta.gpuSamples[c.ordinal()])
                                        .append('\n'));
        out.append("MEASURED LOAD:\n");
        for (LoadCounter c : LoadCounter.values()) {
            long v = delta.load[c.ordinal()];
            if (v != 0L) out.append("  ").append(c.key).append('=').append(v).append('\n');
        }
        out.append("INFERENCE: ").append(infer(delta)).append('\n');
        out.append(
                "Raw pass/pipeline labels are session telemetry; classifier labels are heuristic, timings are measured.\n");
        return out.toString();
    }

    private static String infer(Snapshot s) {
        GpuCategory gpuTop = null;
        double gpuTopMs = 0.0;
        for (GpuCategory c : GpuCategory.values()) {
            double ms = msPerProfiledFrame(s, c);
            if (ms > gpuTopMs) {
                gpuTopMs = ms;
                gpuTop = c;
            }
        }
        CpuZone cpuTop = null;
        double cpuTopMs = 0.0;
        for (CpuZone z : CpuZone.values()) {
            if (z == CpuZone.CLIENT_FRAME
                    || z == CpuZone.WORLD_RENDER
                    || z == CpuZone.WORLD_EXTRACT) continue;
            double ms = avgMs(s.cpuNs[z.ordinal()], s.cpuCalls[z.ordinal()]);
            if (ms > cpuTopMs) {
                cpuTopMs = ms;
                cpuTop = z;
            }
        }
        if (gpuTop == GpuCategory.SHADOW)
            return "shader/shadow work is the strongest measured GPU candidate; investigate shadow-caster culling and shadow geometry first.";
        if (gpuTop == GpuCategory.HZB)
            return "HZB/occlusion work is the strongest measured GPU candidate; compare measured rejection benefit against HZB build/cull cost before increasing occlusion work.";
        if (gpuTop == GpuCategory.GBUFFER || gpuTop == GpuCategory.TERRAIN)
            return "terrain/G-buffer work is the strongest measured GPU candidate; prioritize exact geometry reduction, overdraw reduction and draw/vertex count.";
        if (gpuTop == GpuCategory.COMPOSITE
                || gpuTop == GpuCategory.POST
                || gpuTop == GpuCategory.DEFERRED)
            return "shader post/deferred work dominates sampled GPU passes; geometry-only changes may have limited effect, so inspect shader pass resolution/work before replacing vanilla systems.";
        if (cpuTop == CpuZone.SECTION_COMPILE || cpuTop == CpuZone.SHADER_GEOMETRY_REDUCTION)
            return "chunk meshing/geometry processing is the strongest CPU candidate; profile model lookup, face/AO/light work and reducer amortization next.";
        if (cpuTop == CpuZone.ENTITY_VISIBLE_LOOP
                || cpuTop == CpuZone.ENTITY_EXTRACT
                || cpuTop == CpuZone.ENTITY_SUBMIT)
            return "entity preparation/submission is the strongest CPU candidate; prioritize shared model geometry, instancing and extraction reduction.";
        if (cpuTop == CpuZone.LIGHT_UPDATE || cpuTop == CpuZone.LIGHTMAP)
            return "lighting update work is the strongest CPU candidate; prioritize light-only updates and avoid geometry rebuilds caused only by light.";
        if (gpuTop != null || cpuTop != null)
            return "no single specialized subsystem dominates conclusively; use the top measured CPU/GPU zones and raw pass labels before replacing another pipeline.";
        return "insufficient samples; run F9 in the target scene (normal world, jungle, mob crowd, and shader pack) before choosing the next replacement.";
    }

    private static void appendRawGpuTop(StringBuilder out, int limit) {
        out.append("v42_raw_gpu_top_begin\n");
        RAW_GPU.entrySet().stream()
                .sorted(
                        Comparator.comparingDouble(
                                        (java.util.Map.Entry<String, RawGpuTotals> e) ->
                                                e.getValue().averageMs())
                                .reversed())
                .limit(limit)
                .forEach(
                        e ->
                                out.append("v42_raw_gpu_pass=")
                                        .append(sanitize(e.getKey()))
                                        .append(" avg_ms=")
                                        .append(f4(e.getValue().averageMs()))
                                        .append(" samples=")
                                        .append(e.getValue().samples.sum())
                                        .append(" draws=")
                                        .append(e.getValue().draws.sum())
                                        .append(" vertices=")
                                        .append(e.getValue().vertices.sum())
                                        .append(" indices=")
                                        .append(e.getValue().indices.sum())
                                        .append(" pipeline_changes=")
                                        .append(e.getValue().pipelineChanges.sum())
                                        .append('\n'));
        out.append("v42_raw_gpu_top_end\n");
    }

    private static void armGpuFrame(Mode currentMode) {
        currentGpuSlot = -1;
        if (currentMode == Mode.OFF || !supportsGpuTimestamps()) return;
        int cadence =
                switch (currentMode) {
                    case LIGHT -> 32;
                    case CAPTURE -> 4;
                    case DEEP -> 1;
                    default -> Integer.MAX_VALUE;
                };
        if (clientFrameOrdinal % cadence != 0L) return;
        ensureGpuPool();
        int candidate = (int) (gpuFramesSampled % GPU_SLOT_COUNT);
        GpuFrameSlot slot = GPU_SLOTS[candidate];
        if (slot.pending) {
            gpuFramesSkippedBusy++;
            return;
        }
        slot.reset();
        if (VeilVulkanRuntime.isCurrentBackend()) {
            org.lwjgl.vulkan.VK10.vkCmdResetQueryPool(
                    VeilVulkanRuntime.requireCurrent().commandBuffer(),
                    ((dev.veil.revive.mixin.VulkanQueryPoolInvoker) gpuPool).veil$queryPool(),
                    candidate * QUERIES_PER_SLOT,
                    QUERIES_PER_SLOT);
        }
        currentGpuSlot = candidate;
        gpuFramesSampled++;
    }

    private static void sealGpuFrame() {
        int slotIndex = currentGpuSlot;
        if (slotIndex < 0) return;
        GpuFrameSlot slot = GPU_SLOTS[slotIndex];
        if (slot.segmentCount > 0) {
            slot.pending = true;
            if (VeilVulkanRuntime.isCurrentBackend()) {
                GpuQueryPool submittedPool = gpuPool;
                VeilVulkanRuntime.requireCurrent()
                        .deferDestroy(
                                () -> {
                                    if (gpuPool == submittedPool) slot.completed = true;
                                });
            } else slot.completed = true;
        }
        currentGpuSlot = -1;
    }

    private static void pollGpuSlots() {
        if (gpuPool == null) return;
        for (int slotIndex = 0; slotIndex < GPU_SLOT_COUNT; slotIndex++) {
            GpuFrameSlot slot = GPU_SLOTS[slotIndex];
            if (!slot.pending || !slot.completed || slot.segmentCount == 0) continue;
            boolean ready = true;
            for (int segment = 0; segment < slot.segmentCount; segment++) {
                if (!slot.started[segment] || !slot.ended[segment]) continue;
                OptionalLong start = gpuPool.getValue(query(slotIndex, segment, 0));
                OptionalLong end = gpuPool.getValue(query(slotIndex, segment, 1));
                if (start.isEmpty() || end.isEmpty()) {
                    ready = false;
                    break;
                }
            }
            if (!ready) continue;
            for (int segment = 0; segment < slot.segmentCount; segment++) {
                if (!slot.started[segment] || !slot.ended[segment]) continue;
                OptionalLong start = gpuPool.getValue(query(slotIndex, segment, 0));
                OptionalLong end = gpuPool.getValue(query(slotIndex, segment, 1));
                if (start.isEmpty() || end.isEmpty()) continue;
                long ticks = Math.max(0L, end.getAsLong() - start.getAsLong());
                double period = RenderSystem.getDevice().getDeviceInfo().timestampPeriod();
                long ns = (long) Math.max(0.0, ticks * period);
                GpuCategory category =
                        slot.categories[segment] == null
                                ? GpuCategory.OTHER
                                : slot.categories[segment];
                GPU_NS[category.ordinal()].add(ns);
                GPU_SAMPLES[category.ordinal()].increment();
                String label = slot.labels[segment] == null ? "unknown" : slot.labels[segment];
                RawGpuTotals raw = RAW_GPU.computeIfAbsent(label, ignored -> new RawGpuTotals());
                raw.ns.add(ns);
                raw.samples.increment();
                raw.draws.add(slot.drawCalls[segment]);
                raw.vertices.add(slot.vertices[segment]);
                raw.indices.add(slot.indices[segment]);
                raw.pipelineChanges.add(slot.pipelineChanges[segment]);
            }
            slot.reset();
        }
    }

    private static int query(int slot, int segment, int endpoint) {
        return slot * QUERIES_PER_SLOT + segment * QUERIES_PER_SEGMENT + endpoint;
    }

    private static void writeGpuTimestamp(RenderPass pass, int index) {
        if (VeilVulkanRuntime.isCurrentBackend()) {
            org.lwjgl.vulkan.KHRSynchronization2.vkCmdWriteTimestamp2KHR(
                    VeilVulkanRuntime.requireCurrent().commandBuffer(),
                    org.lwjgl.vulkan.VK13.VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                    ((dev.veil.revive.mixin.VulkanQueryPoolInvoker) gpuPool).veil$queryPool(),
                    index);
        } else pass.writeTimestamp(gpuPool, index);
    }

    private static void ensureGpuPool() {
        if (gpuPool == null)
            gpuPool =
                    RenderSystem.getDevice()
                            .createTimestampQueryPool(GPU_SLOT_COUNT * QUERIES_PER_SLOT);
    }

    private static boolean supportsGpuTimestamps() {
        try {
            return RenderSystem.getDevice() != null;
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    private static boolean validSegment(int slot, int segment) {
        return slot >= 0
                && slot < GPU_SLOT_COUNT
                && segment >= 0
                && segment < GPU_SLOTS[slot].segmentCount;
    }

    private static String pipelineLabel(RenderPipeline pipeline) {
        if (pipeline == null) return "unknown";
        try {
            return pipeline.getLocation().toString();
        } catch (RuntimeException ignored) {
            return pipeline.toString();
        }
    }

    static GpuCategory classifyPipelineLabel(String label) {
        String s = label == null ? "" : label.toLowerCase(Locale.ROOT);
        if (s.contains("shadow")) return GpuCategory.SHADOW;
        if (s.contains("hzb") || s.contains("occluder")) return GpuCategory.HZB;
        if (s.contains("gbuffer") || s.contains("geometry")) return GpuCategory.GBUFFER;
        if (s.contains("deferred")) return GpuCategory.DEFERRED;
        if (s.contains("composite")) return GpuCategory.COMPOSITE;
        if (s.contains("post")
                || s.contains("final")
                || s.contains("bloom")
                || s.contains("tonemap")
                || s.contains("vignette")
                || s.contains("blit")) return GpuCategory.POST;

        if (s.contains("indirect_solid") || s.contains("terrain") || s.contains("chunk"))
            return GpuCategory.TERRAIN;
        if (s.contains("entity")
                || s.contains("feature")
                || s.contains("armor")
                || s.contains("item")) return GpuCategory.ENTITY_FEATURES;
        if (s.contains("particle")) return GpuCategory.PARTICLES;
        if (s.contains("cloud")) return GpuCategory.CLOUDS;
        if (s.contains("weather") || s.contains("rain") || s.contains("snow"))
            return GpuCategory.WEATHER;
        if (s.contains("sky") || s.contains("sun") || s.contains("moon") || s.contains("star"))
            return GpuCategory.SKY;
        if (s.contains("gui") || s.contains("hud") || s.contains("text")) return GpuCategory.GUI;
        if (s.contains("veil")) return GpuCategory.VEIL;
        return GpuCategory.OTHER;
    }

    private static GpuCategory classify(String label) {
        return classifyPipelineLabel(label);
    }

    private static int encodeCpuOnlyToken(GpuCategory category) {
        return -2 - category.ordinal();
    }

    private static boolean isCpuOnlyToken(int token) {
        return token <= -2;
    }

    private static Mode resolveMode() {
        if (!ReviveRuntime.enabled()) return Mode.OFF;
        if (VeilVideoConfig.flag("profiling.deepTelemetry", false)) return Mode.DEEP;
        if (VeilDiagnostics.benchmarkActive()
                || VeilSubmissionBenchmark.active()
                || VeilVisualValidation.active()) return Mode.CAPTURE;
        if (VeilVideoConfig.flag("profiling.fullFrame", false)
                || VeilVideoConfig.flag("profiling.liveTelemetry", false)
                || VeilVideoConfig.flag("profiling.gpu", false)
                || VeilCameraSweepProbe.enabled()
                || ReviveRuntime.config().profilerEnabled()
                || VeilDiagnostics.detailedOverlay()) return Mode.LIGHT;
        return Mode.OFF;
    }

    private static LongAdder[] adders(int count) {
        LongAdder[] out = new LongAdder[count];
        for (int i = 0; i < count; i++) out[i] = new LongAdder();
        return out;
    }

    private static long[] sums(LongAdder[] adders) {
        long[] out = new long[adders.length];
        for (int i = 0; i < adders.length; i++) out[i] = adders[i].sum();
        return out;
    }

    private static double avgMs(long ns, long calls) {
        return calls <= 0L ? 0.0 : ns / 1_000_000.0 / calls;
    }

    private static double msPerProfiledFrame(Snapshot s, GpuCategory category) {
        long frames = Math.max(1L, s.gpuFramesSampled);
        return s.gpuNs[category.ordinal()] / 1_000_000.0 / frames;
    }

    private static String f4(double v) {
        return String.format(Locale.ROOT, "%.4f", v);
    }

    private static String sanitize(String s) {
        return s.replace('\n', ' ').replace('\r', ' ').replace('=', '_');
    }

    private static com.sun.management.ThreadMXBean threadMx() {
        try {
            var bean = ManagementFactory.getThreadMXBean();
            if (bean instanceof com.sun.management.ThreadMXBean sun
                    && sun.isThreadAllocatedMemorySupported()) {
                if (!sun.isThreadAllocatedMemoryEnabled())
                    sun.setThreadAllocatedMemoryEnabled(true);
                return sun;
            }
        } catch (RuntimeException ignored) {
        }
        return null;
    }

    private static long allocatedBytesCurrentThread(boolean enabled) {
        if (!enabled || THREAD_MX == null) return -1L;
        try {
            return THREAD_MX.getThreadAllocatedBytes(Thread.currentThread().threadId());
        } catch (RuntimeException ignored) {
            return -1L;
        }
    }

    public static void close() {
        if (gpuPool != null) {
            gpuPool.close();
            gpuPool = null;
        }
        for (GpuFrameSlot slot : GPU_SLOTS) slot.reset();
        currentGpuSlot = -1;
        mode = Mode.OFF;
    }

    public record Snapshot(
            long[] cpuNs,
            long[] cpuCalls,
            long[] load,
            long[] gpuNs,
            long[] gpuSamples,
            long gpuFramesSampled,
            long gpuFramesSkippedBusy,
            long gpuSegmentOverflow) {
        public Snapshot minus(Snapshot before) {
            return new Snapshot(
                    sub(cpuNs, before.cpuNs),
                    sub(cpuCalls, before.cpuCalls),
                    sub(load, before.load),
                    sub(gpuNs, before.gpuNs),
                    sub(gpuSamples, before.gpuSamples),
                    gpuFramesSampled - before.gpuFramesSampled,
                    gpuFramesSkippedBusy - before.gpuFramesSkippedBusy,
                    gpuSegmentOverflow - before.gpuSegmentOverflow);
        }

        public Snapshot plus(Snapshot other) {
            return new Snapshot(
                    add(cpuNs, other.cpuNs),
                    add(cpuCalls, other.cpuCalls),
                    add(load, other.load),
                    add(gpuNs, other.gpuNs),
                    add(gpuSamples, other.gpuSamples),
                    gpuFramesSampled + other.gpuFramesSampled,
                    gpuFramesSkippedBusy + other.gpuFramesSkippedBusy,
                    gpuSegmentOverflow + other.gpuSegmentOverflow);
        }

        private static long[] sub(long[] a, long[] b) {
            long[] r = new long[a.length];
            for (int i = 0; i < a.length; i++) r[i] = a[i] - b[i];
            return r;
        }

        private static long[] add(long[] a, long[] b) {
            long[] r = new long[a.length];
            for (int i = 0; i < a.length; i++) r[i] = a[i] + b[i];
            return r;
        }
    }

    private static final class CpuState {
        final long[] start = new long[CpuZone.values().length];
        final int[] depth = new int[CpuZone.values().length];
    }

    private static final class GpuFrameSlot {
        boolean pending;
        boolean completed;
        int segmentCount;
        final boolean[] started = new boolean[MAX_GPU_SEGMENTS];
        final boolean[] ended = new boolean[MAX_GPU_SEGMENTS];
        final String[] labels = new String[MAX_GPU_SEGMENTS];
        final GpuCategory[] categories = new GpuCategory[MAX_GPU_SEGMENTS];
        final long[] drawCalls = new long[MAX_GPU_SEGMENTS];
        final long[] vertices = new long[MAX_GPU_SEGMENTS];
        final long[] indices = new long[MAX_GPU_SEGMENTS];
        final long[] pipelineChanges = new long[MAX_GPU_SEGMENTS];

        void reset() {
            pending = false;
            completed = false;
            segmentCount = 0;
            Arrays.fill(started, false);
            Arrays.fill(ended, false);
            Arrays.fill(labels, null);
            Arrays.fill(categories, null);
            Arrays.fill(drawCalls, 0L);
            Arrays.fill(vertices, 0L);
            Arrays.fill(indices, 0L);
            Arrays.fill(pipelineChanges, 0L);
        }
    }

    private static final class RawGpuTotals {
        final LongAdder ns = new LongAdder();
        final LongAdder samples = new LongAdder();
        final LongAdder draws = new LongAdder();
        final LongAdder vertices = new LongAdder();
        final LongAdder indices = new LongAdder();
        final LongAdder pipelineChanges = new LongAdder();

        double averageMs() {
            long s = samples.sum();
            return s == 0L ? 0.0 : ns.sum() / 1_000_000.0 / s;
        }
    }
}
