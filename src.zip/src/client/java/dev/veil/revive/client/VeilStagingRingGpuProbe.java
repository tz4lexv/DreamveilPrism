package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import org.lwjgl.system.MemoryUtil;

final class VeilStagingRingGpuProbe {
    private VeilStagingRingGpuProbe() {}

    static void requireComplete() {
        if (!VeilPlatform.get().isDevelopmentEnvironment()
                || !Boolean.getBoolean("veil.stagingRingGpuProbe")) return;
        var device = RenderSystem.getDevice();
        var encoder = device.createCommandEncoder();
        byte[] expected = new byte[12 * 256];
        new VeilPersistentStagingBuffer("Veil unused staging proof", 256).close();
        var input = MemoryUtil.memAlloc(256);
        try (var target =
                        device.createBuffer(
                                () -> "Veil staging proof target",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_COPY_SRC,
                                expected.length);
                var readback =
                        device.createBuffer(
                                () -> "Veil staging proof readback",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                expected.length);
                var staging = new VeilPersistentStagingBuffer("Veil staging wrap proof", 256)) {
            for (int round = 0; round < 12; round++) {
                input.clear();
                for (int index = 0; index < 256; index++) {
                    byte value = (byte) (round * 31 + index * 7);
                    expected[round * 256 + index] = value;
                    input.put(value);
                }
                input.flip();
                var first = staging.tryAppend(input.slice(0, 80));
                var second = staging.tryAppend(input.slice(80, 176));
                if (first == null || second == null || staging.tryAppend(input.slice(0, 1)) != null)
                    throw new IllegalStateException("Staging capacity proof failed");
                try (var upload = staging.startUploading(encoder);
                        first;
                        second) {
                    upload.copyTo(first, target, round * 256L);
                    upload.copyTo(second, target, round * 256L + 80);
                }
                encoder.submit();
            }
            encoder.copyToBuffer(target.slice(), readback.slice());
            try (var fence = encoder.createFence()) {
                encoder.submit();
                if (!fence.awaitCompletion(5_000_000_000L))
                    throw new IllegalStateException("Staging readback did not complete");
            }
            try (var mapping = readback.map(true, false)) {
                for (int index = 0; index < expected.length; index++)
                    if (mapping.data().get(index) != expected[index])
                        throw new IllegalStateException("Staging GPU byte mismatch at " + index);
            }
        } finally {
            MemoryUtil.memFree(input);
        }
        try (var staging = new VeilPersistentStagingBuffer("Veil staged close proof", 256)) {
            var data = MemoryUtil.memAlloc(16);
            try {
                var handle = staging.tryAppend(data);
                if (handle == null) throw new IllegalStateException("Cannot stage before close");
                handle.close();
            } finally {
                MemoryUtil.memFree(data);
            }
        }
        ReviveMod.LOGGER.info(
                "Veil staging ring GPU: PASS bytes={} rotations=12 saturation=true unused_close=true staged_close=true",
                expected.length);
    }
}
