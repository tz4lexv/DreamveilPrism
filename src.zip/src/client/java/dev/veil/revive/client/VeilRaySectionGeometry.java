package dev.veil.revive.client;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionCompiler;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

final class VeilRaySectionGeometry {
    static final int FLAG_CUTOUT = 1;
    static final int FLAG_TRANSLUCENT = 2;
    private static final int SCALE = 256;

    private static int maxVertices() {
        return Math.min(Integer.MAX_VALUE / 12, VeilShaderLimits.current().rayBytes() / 22) & ~3;
    }

    private final short[] positions;
    private final int[] attributes;
    private final byte[] materials;
    private final byte[] flags;

    private VeilRaySectionGeometry(
            short[] positions, int[] attributes, byte[] materials, byte[] flags) {
        this.positions = positions;
        this.attributes = attributes;
        this.materials = materials;
        this.flags = flags;
    }

    static VeilRaySectionGeometry capture(SectionCompiler.Results results) {
        int vertices =
                (int)
                        Math.min(
                                maxVertices(),
                                results.renderedLayers.values().stream()
                                        .mapToLong(VeilRaySectionGeometry::captureVertexCount)
                                        .sum());
        short[] positions = new short[vertices * 3];
        int[] attributes = new int[vertices * 3];
        byte[] materials = new byte[vertices / 4];
        byte[] flags = new byte[vertices / 4];
        int count = 0;
        int quads = 0;
        VeilMaterialRange[] ranges =
                ((VeilSectionCompileExtras) (Object) results).veil$materialRanges();
        for (var entry : results.renderedLayers.entrySet()) {
            var mesh = entry.getValue();
            var format = mesh.drawState().format();
            if (captureVertexCount(mesh) == 0) continue;
            ByteBuffer source = mesh.vertexBuffer().duplicate().order(ByteOrder.nativeOrder());
            ByteBuffer indices =
                    mesh.indexBuffer() == null
                            ? null
                            : mesh.indexBuffer().duplicate().order(ByteOrder.nativeOrder());
            int[] corners = new int[4];
            int stride = format.getVertexSize();
            int uvOffset = format.getElement(DefaultVertexFormat.UV0_SEMANTIC_NAME).offset();
            int colorOffset = format.getElement(DefaultVertexFormat.COLOR_SEMANTIC_NAME).offset();
            int lightOffset = format.getElement(DefaultVertexFormat.UV2_SEMANTIC_NAME).offset();
            int limit = Math.min(captureVertexCount(mesh), vertices - count);
            int layerFlags =
                    entry.getKey() == ChunkSectionLayer.CUTOUT
                            ? FLAG_CUTOUT
                            : entry.getKey() == ChunkSectionLayer.TRANSLUCENT
                                    ? FLAG_TRANSLUCENT
                                    : 0;
            for (int quad = 0; quad < limit; quad += 4) {
                if (indices == null) {
                    for (int corner = 0; corner < 4; corner++) corners[corner] = quad + corner;
                } else if (!indexedQuad(
                        indices,
                        mesh.drawState().indexType(),
                        quad / 4,
                        mesh.drawState().vertexCount(),
                        corners)) continue;
                boolean valid = true;
                int surfaceMaterial = material(ranges, entry.getKey(), corners[0]);
                for (int vertex = 0; vertex < 4; vertex++) {
                    int base = source.position() + corners[vertex] * stride;
                    if (material(ranges, entry.getKey(), corners[vertex]) != surfaceMaterial)
                        valid = false;
                    int target = count + vertex;
                    for (int axis = 0; axis < 3; axis++) {
                        float value = source.getFloat(base + axis * 4);
                        int quantized = Math.round(value * SCALE);
                        if (!Float.isFinite(value)
                                || quantized < Short.MIN_VALUE
                                || quantized > Short.MAX_VALUE) valid = false;
                        positions[target * 3 + axis] = (short) quantized;
                    }
                    float u = source.getFloat(base + uvOffset);
                    float v = source.getFloat(base + uvOffset + 4);
                    if (!Float.isFinite(u) || !Float.isFinite(v)) valid = false;
                    attributes[target * 3] = (half(u) & 0xffff) | (half(v) << 16);
                    attributes[target * 3 + 1] = source.getInt(base + colorOffset);
                    attributes[target * 3 + 2] = source.getInt(base + lightOffset);
                }
                if (valid) {
                    materials[quads] = (byte) surfaceMaterial;
                    flags[quads] = (byte) layerFlags;
                    count += 4;
                    quads++;
                }
            }
            if (count == vertices) break;
        }
        return new VeilRaySectionGeometry(
                Arrays.copyOf(positions, count * 3),
                Arrays.copyOf(attributes, count * 3),
                Arrays.copyOf(materials, quads),
                Arrays.copyOf(flags, quads));
    }

    private static int captureVertexCount(MeshData mesh) {
        var state = mesh.drawState();
        if (!state.format().equals(DefaultVertexFormat.BLOCK)
                || state.primitiveTopology() != PrimitiveTopology.QUADS
                || state.vertexCount() < 0
                || (long) state.vertexCount() * state.format().getVertexSize()
                        > mesh.vertexBuffer().remaining()) return 0;
        if (mesh.indexBuffer() == null) return Math.min(maxVertices(), state.vertexCount() & ~3);
        int bytes = state.indexType() == IndexType.SHORT ? 2 : 4;
        if (state.indexCount() < 0
                || state.indexCount() % 6 != 0
                || (long) state.indexCount() * bytes > mesh.indexBuffer().remaining()) return 0;
        return (int) Math.min(maxVertices(), (long) state.indexCount() / 6 * 4);
    }

    // Read the actual draw order; a sorted or deduplicated mesh need not retain vertex groups.
    static boolean indexedQuad(
            ByteBuffer indices, IndexType type, int quad, int vertices, int[] corners) {
        int bytes = type == IndexType.SHORT ? 2 : 4;
        long offset = (long) quad * 6 * bytes;
        if (quad < 0 || offset + 6 * bytes > indices.remaining() || corners.length < 4)
            return false;
        int base = indices.position() + (int) offset;
        int a = index(indices, base, type),
                b = index(indices, base + bytes, type),
                c = index(indices, base + 2 * bytes, type),
                repeatedC = index(indices, base + 3 * bytes, type),
                d = index(indices, base + 4 * bytes, type),
                repeatedA = index(indices, base + 5 * bytes, type);
        if (a < 0
                || b < 0
                || c < 0
                || d < 0
                || a >= vertices
                || b >= vertices
                || c >= vertices
                || d >= vertices
                || c != repeatedC
                || a != repeatedA) return false;
        corners[0] = a;
        corners[1] = b;
        corners[2] = c;
        corners[3] = d;
        return true;
    }

    private static int index(ByteBuffer source, int offset, IndexType type) {
        return type == IndexType.SHORT
                ? Short.toUnsignedInt(source.getShort(offset))
                : source.getInt(offset);
    }

    int triangleCount() {
        return positions.length / 6;
    }

    int append(
            float[] target,
            int[] surface,
            int[] triangleMaterials,
            int triangleOffset,
            float x,
            float y,
            float z,
            int triangleLimit) {
        int triangles = Math.min(triangleCount(), triangleLimit);
        int quads = triangles / 2;
        for (int quad = 0; quad < quads; quad++) {
            int vertex = quad * 4;
            int triangle = triangleOffset + quad * 2;
            putTriangle(
                    target,
                    surface,
                    triangle,
                    vertex,
                    vertex + 1,
                    vertex + 2,
                    x,
                    y,
                    z,
                    flags[quad] & 0xff);
            putTriangle(
                    target,
                    surface,
                    triangle + 1,
                    vertex,
                    vertex + 2,
                    vertex + 3,
                    x,
                    y,
                    z,
                    flags[quad] & 0xff);
            triangleMaterials[triangle] = materials[quad] & 0xff;
            triangleMaterials[triangle + 1] = materials[quad] & 0xff;
        }
        return quads * 2;
    }

    private void putTriangle(
            float[] target,
            int[] surface,
            int triangle,
            int a,
            int b,
            int c,
            float x,
            float y,
            float z,
            int quadFlags) {
        int[] vertices = {a, b, c};
        int positionOutput = triangle * 9;
        int surfaceOutput = triangle * 12;
        for (int vertex : vertices) {
            int source = vertex * 3;
            target[positionOutput++] = x + positions[source] / (float) SCALE;
            target[positionOutput++] = y + positions[source + 1] / (float) SCALE;
            target[positionOutput++] = z + positions[source + 2] / (float) SCALE;
            surface[surfaceOutput++] = attributes[source];
            surface[surfaceOutput++] = attributes[source + 1];
            surface[surfaceOutput++] = attributes[source + 2];
            surface[surfaceOutput++] = quadFlags;
        }
    }

    private static int material(VeilMaterialRange[] ranges, ChunkSectionLayer layer, int vertex) {
        for (VeilMaterialRange range : ranges) {
            if (range.layer() == layer
                    && vertex >= range.firstVertex()
                    && vertex < range.firstVertex() + range.vertexCount())
                return range.materialId();
        }
        return VeilMaterialIds.NONE;
    }

    private static int half(float value) {
        int bits = Float.floatToRawIntBits(value);
        int sign = bits >>> 16 & 0x8000;
        int exponent = (bits >>> 23 & 0xff) - 127 + 15;
        int mantissa = bits & 0x7fffff;
        if (exponent <= 0) {
            if (exponent < -10) return sign;
            mantissa = (mantissa | 0x800000) >> (1 - exponent);
            return sign | (mantissa + 0x1000 >> 13);
        }
        if (exponent >= 31) return sign | 0x7c00;
        int rounded = mantissa + 0x1000;
        if ((rounded & 0x800000) != 0) {
            rounded = 0;
            exponent++;
            if (exponent >= 31) return sign | 0x7c00;
        }
        return sign | exponent << 10 | rounded >> 13;
    }
}
