package dev.veil.revive.client.shaderpack.reload;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

public final class PackConfiguration {
    private PackConfiguration() {}

    public record Loaded(String selected, Map<String, String> settings) {
        public Loaded {
            settings = Map.copyOf(settings);
        }
    }

    public static Loaded read(Path path, String selected, Consumer<String> diagnostic) {
        var values = new LinkedHashMap<String, String>();
        if (selected == null) {
            selected = "";
            try {
                if (Files.isRegularFile(path)) {
                    if (Files.size(path) > 65536)
                        throw new IOException("Shader configuration exceeds 64 KiB");
                    var root = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
                    selected = root.get("pack").getAsString();
                    if (root.has("settings"))
                        root.getAsJsonObject("settings")
                                .entrySet()
                                .forEach(
                                        entry ->
                                                values.put(
                                                        entry.getKey(),
                                                        entry.getValue().getAsString()));
                }
            } catch (IOException | RuntimeException failure) {
                diagnostic.accept(failure.getMessage());
            }
        }
        return new Loaded(selected, values);
    }

    public static void save(Path path, String selected, Map<String, String> settings)
            throws IOException {
        var root = new JsonObject();
        root.addProperty("pack", selected);
        var values = new JsonObject();
        settings.forEach(values::addProperty);
        root.add("settings", values);
        Files.createDirectories(path.getParent());
        Path temporary = path.resolveSibling("veil-shaders.json.tmp");
        Files.writeString(temporary, root.toString());
        try {
            Files.move(
                    temporary,
                    path,
                    StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
            Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
