package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilAiCadence;
import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilServerAiCounters;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.npc.villager.Villager;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Brain.class)
public abstract class BrainTimingMixin {
    @Unique private long veil$brainStartNs;
    @Unique private boolean veil$brainVillager;

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true, require = 1)
    private void veil$beginBrain(ServerLevel level, LivingEntity body, CallbackInfo ci) {
        if (!VeilAiCadence.shouldRunBrain(level, body)) {
            veil$brainStartNs = 0L;
            ci.cancel();
            return;
        }
        if (!VeilDiagnostics.benchmarkActive()) {
            veil$brainStartNs = 0L;
            return;
        }
        veil$brainVillager = body instanceof Villager;
        veil$brainStartNs = System.nanoTime();
    }

    @Inject(method = "tick", at = @At("RETURN"), require = 1)
    private void veil$endBrain(ServerLevel level, LivingEntity body, CallbackInfo ci) {
        long start = veil$brainStartNs;
        veil$brainStartNs = 0L;
        if (start != 0L && VeilDiagnostics.benchmarkActive()) {
            VeilServerAiCounters.brain(System.nanoTime() - start, veil$brainVillager);
        }
    }
}
