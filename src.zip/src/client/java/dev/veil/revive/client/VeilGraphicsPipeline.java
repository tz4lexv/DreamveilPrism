package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.*;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.vulkan.VulkanConst;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilVertexLayout;
import dev.veil.revive.client.graphics.pipelines.NativeGraphicsPipeline;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

final class VeilGraphicsPipeline implements AutoCloseable {
    private final NativeGraphicsPipeline pipeline;

    private VeilGraphicsPipeline(NativeGraphicsPipeline pipeline) {
        this.pipeline = pipeline;
    }

    static VeilGraphicsPipeline createSimple(
            VeilVulkanRuntime runtime,
            VeilSpirvBinary vertexBinary,
            VeilSpirvBinary fragmentBinary,
            GpuFormat colorFormat) {
        VeilShaderInterface shaderInterface =
                VeilShaderInterface.merge(
                        VeilSpirvReflection.reflect(vertexBinary),
                        VeilSpirvReflection.reflect(fragmentBinary));
        return createSimple(runtime, vertexBinary, fragmentBinary, colorFormat, shaderInterface);
    }

    static VeilGraphicsPipeline createSimple(
            VeilVulkanRuntime runtime,
            VeilSpirvBinary vertexBinary,
            VeilSpirvBinary fragmentBinary,
            GpuFormat colorFormat,
            VeilShaderInterface shaderInterface) {
        return createSimple(
                runtime,
                vertexBinary,
                fragmentBinary,
                colorFormat,
                shaderInterface,
                VeilSpecializationValues.empty(),
                VeilSpecializationValues.empty());
    }

    static VeilGraphicsPipeline createSimple(
            VeilVulkanRuntime runtime,
            VeilSpirvBinary vertexBinary,
            VeilSpirvBinary fragmentBinary,
            GpuFormat colorFormat,
            VeilShaderInterface shaderInterface,
            VeilSpecializationValues vertexValues,
            VeilSpecializationValues fragmentValues) {
        var color =
                new VeilShaderPack.ColorAttachment(
                        "present",
                        0,
                        0,
                        VeilShaderPack.LoadOp.LOAD,
                        VeilShaderPack.StoreOp.STORE,
                        null,
                        VeilShaderPack.BlendState.DISABLED,
                        java.util.EnumSet.allOf(VeilShaderPack.ColorChannel.class));
        return create(
                runtime,
                vertexBinary,
                fragmentBinary,
                new int[] {VulkanConst.toVk(colorFormat)},
                VK_FORMAT_UNDEFINED,
                false,
                1,
                VeilShaderPack.Geometry.FULLSCREEN,
                List.of(color),
                null,
                VeilShaderPack.PipelineState.DEFAULT,
                VeilVertexLayout.EMPTY,
                shaderInterface,
                vertexValues,
                fragmentValues);
    }

    static VeilGraphicsPipeline createFluidGeometry(
            VeilVulkanRuntime runtime,
            VeilSpirvBinary vertexBinary,
            VeilSpirvBinary fragmentBinary,
            GpuFormat colorFormat,
            GpuFormat depthFormat,
            VeilShaderInterface shaderInterface,
            VeilSpecializationValues vertexValues,
            VeilSpecializationValues fragmentValues) {
        var color =
                new VeilShaderPack.ColorAttachment(
                        "color",
                        0,
                        0,
                        VeilShaderPack.LoadOp.LOAD,
                        VeilShaderPack.StoreOp.STORE,
                        null,
                        VeilShaderPack.BlendState.DISABLED,
                        java.util.EnumSet.allOf(VeilShaderPack.ColorChannel.class));
        var depth =
                new VeilShaderPack.DepthAttachment(
                        "depth",
                        0,
                        0,
                        VeilShaderPack.LoadOp.LOAD,
                        VeilShaderPack.StoreOp.STORE,
                        1.0f,
                        0,
                        true,
                        false,
                        VeilShaderPack.CompareOp.GREATER_OR_EQUAL);
        return create(
                runtime,
                vertexBinary,
                fragmentBinary,
                new int[] {VulkanConst.toVk(colorFormat)},
                VulkanConst.toVk(depthFormat),
                depthFormat.hasStencilAspect(),
                1,
                VeilShaderPack.Geometry.FLUID_WATER,
                List.of(color),
                depth,
                VeilShaderPack.PipelineState.DEFAULT,
                VeilVertexLayout.EMPTY,
                shaderInterface,
                vertexValues,
                fragmentValues);
    }

    static VeilGraphicsPipeline createPack(
            VeilVulkanRuntime runtime,
            VeilShaderProgram program,
            List<VeilFormat> colorFormats,
            VeilFormat depthFormat,
            int samples,
            VeilShaderPack.Pass pass,
            VeilShaderInterface shaderInterface) {
        int[] nativeColors = colorFormats.stream().mapToInt(VeilVulkanFormats::vk).toArray();
        int nativeDepth =
                depthFormat == null ? VK_FORMAT_UNDEFINED : VeilVulkanFormats.vk(depthFormat);
        return create(
                runtime,
                program.stages(),
                nativeColors,
                nativeDepth,
                depthFormat != null && depthFormat.stencil(),
                samples,
                pass.geometry(),
                pass.colors(),
                pass.depth(),
                pass.pipeline(),
                pass.vertexLayout(),
                shaderInterface,
                pass.specialization());
    }

    private static VeilGraphicsPipeline create(
            VeilVulkanRuntime runtime,
            VeilSpirvBinary vertexBinary,
            VeilSpirvBinary fragmentBinary,
            int[] colorFormats,
            int depthFormat,
            boolean stencil,
            int samples,
            VeilShaderPack.Geometry geometry,
            List<VeilShaderPack.ColorAttachment> colors,
            VeilShaderPack.DepthAttachment depthState,
            VeilShaderPack.PipelineState pipelineState,
            VeilVertexLayout vertexLayout,
            VeilShaderInterface shaderInterface,
            VeilSpecializationValues vertexValues,
            VeilSpecializationValues fragmentValues) {
        return create(
                runtime,
                Map.of(
                        VeilShaderStage.VERTEX,
                        vertexBinary,
                        VeilShaderStage.FRAGMENT,
                        fragmentBinary),
                colorFormats,
                depthFormat,
                stencil,
                samples,
                geometry,
                colors,
                depthState,
                pipelineState,
                vertexLayout,
                shaderInterface,
                Map.of(
                        VeilShaderStage.VERTEX,
                        vertexValues,
                        VeilShaderStage.FRAGMENT,
                        fragmentValues));
    }

    private static VeilGraphicsPipeline create(
            VeilVulkanRuntime runtime,
            Map<VeilShaderStage, VeilSpirvBinary> binaries,
            int[] colorFormats,
            int depthFormat,
            boolean stencil,
            int samples,
            VeilShaderPack.Geometry geometry,
            List<VeilShaderPack.ColorAttachment> colors,
            VeilShaderPack.DepthAttachment depthState,
            VeilShaderPack.PipelineState pipelineState,
            VeilVertexLayout vertexLayout,
            VeilShaderInterface shaderInterface,
            Map<VeilShaderStage, VeilSpecializationValues> specialization) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        Objects.requireNonNull(runtime, "runtime");
        Objects.requireNonNull(shaderInterface, "shaderInterface");
        if (!binaries.containsKey(VeilShaderStage.VERTEX)
                || !binaries.containsKey(VeilShaderStage.FRAGMENT)) {
            throw new IllegalArgumentException(
                    "Graphics pipeline requires vertex and fragment stages");
        }
        if (binaries.containsKey(VeilShaderStage.TESS_CONTROL)
                != binaries.containsKey(VeilShaderStage.TESS_EVALUATION)) {
            throw new IllegalArgumentException(
                    "Graphics pipeline requires both tessellation stages");
        }
        if (binaries.containsKey(VeilShaderStage.TESS_CONTROL)
                != (pipelineState.topology() == VeilShaderPack.Topology.PATCH_LIST)) {
            throw new IllegalArgumentException(
                    "Tessellation stages require patchList topology and patchList requires tessellation stages");
        }
        Set<VeilShaderStage> activeStages = binaries.keySet();
        if (geometry.fluid()) validateFluidGeometry(shaderInterface, colors.size(), activeStages);
        else if (geometry == VeilShaderPack.Geometry.FULLSCREEN)
            validateFullscreen(shaderInterface, colors.size(), activeStages);
        else validateVertexLayout(vertexLayout, shaderInterface, colors.size(), activeStages);
        binaries.forEach(
                (stage, binary) -> {
                    if (binary.stage() != stage)
                        throw new IllegalArgumentException(
                                "Graphics shader stage mismatch: " + stage);
                    specialization
                            .getOrDefault(stage, VeilSpecializationValues.empty())
                            .validate(shaderInterface, stage);
                });

        var modules = new ArrayList<VeilShaderModule>();
        var nativeSpecialization = new ArrayList<VeilSpecializationValues.NativeData>();
        VeilPipelineLayout layout = null;
        NativeGraphicsPipeline pipeline = null;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var nativeState =
                    dev.veil.revive.client.shaderpack.preparation.GraphicsPipelineInputs.from(
                            pipelineState, geometry, colors, depthState);
            int stageFlags = 0;
            for (var stage : binaries.keySet()) stageFlags |= stage.vkStageFlags();
            NativeGraphicsPipeline.validateFeatures(
                    runtime,
                    nativeState,
                    vertexLayout,
                    colorFormats,
                    stageFlags,
                    stack,
                    VeilVulkanCapabilities::independentBlend);
            layout = VeilPipelineLayout.createFromReflection(runtime, shaderInterface);
            List<VeilShaderStage> order =
                    List.of(
                                    VeilShaderStage.VERTEX,
                                    VeilShaderStage.TESS_CONTROL,
                                    VeilShaderStage.TESS_EVALUATION,
                                    VeilShaderStage.GEOMETRY,
                                    VeilShaderStage.FRAGMENT)
                            .stream()
                            .filter(binaries::containsKey)
                            .toList();
            var stages = VkPipelineShaderStageCreateInfo.calloc(order.size(), stack);
            for (int index = 0; index < order.size(); index++) {
                VeilShaderStage stage = order.get(index);
                VeilSpirvBinary binary = binaries.get(stage);
                VeilShaderModule module = VeilShaderModule.create(runtime, binary);
                VeilSpecializationValues.NativeData values =
                        specialization
                                .getOrDefault(stage, VeilSpecializationValues.empty())
                                .nativeData();
                modules.add(module);
                nativeSpecialization.add(values);
                stages.get(index)
                        .sType$Default()
                        .stage(stage.vkStageFlags())
                        .module(module.handle())
                        .pName(stack.UTF8(binary.entryPoint()))
                        .pSpecializationInfo(values.info());
            }

            var ownedLayout = layout;
            var ownedModules = List.copyOf(modules);
            pipeline =
                    NativeGraphicsPipeline.create(
                            runtime,
                            stages,
                            layout::handle,
                            colorFormats,
                            depthFormat,
                            stencil,
                            VeilNativeImage.sampleCount(samples),
                            nativeState,
                            vertexLayout,
                            binaries.containsKey(VeilShaderStage.TESS_CONTROL),
                            () -> VeilVulkanPipelineCache.handle(runtime),
                            () -> {
                                ownedLayout.destroyNow();
                                ownedModules.forEach(VeilShaderModule::destroyNow);
                            });
            return new VeilGraphicsPipeline(pipeline);
        } catch (RuntimeException failure) {
            if (pipeline != null) pipeline.destroyNow();
            else {
                if (layout != null) layout.destroyNow();
                modules.forEach(VeilShaderModule::destroyNow);
            }
            throw failure;
        } finally {
            nativeSpecialization.forEach(VeilSpecializationValues.NativeData::close);
        }
    }

    static void validateFluidGeometry(VeilShaderInterface shader) {
        validateFluidGeometry(shader, 1);
    }

    static void validateFluidGeometry(VeilShaderInterface shader, int colorAttachments) {
        dev.veil.revive.client.shaderpack.preparation.GraphicsInterfaceValidation
                .validateFluidGeometry(shader, colorAttachments);
    }

    static void validateFluidGeometry(
            VeilShaderInterface shader, int colorAttachments, Set<VeilShaderStage> stages) {
        dev.veil.revive.client.shaderpack.preparation.GraphicsInterfaceValidation
                .validateFluidGeometry(shader, colorAttachments, stages);
    }

    static void validateFullscreen(VeilShaderInterface shader) {
        dev.veil.revive.client.shaderpack.preparation.GraphicsInterfaceValidation
                .validateFullscreen(shader);
    }

    static void validateFullscreen(VeilShaderInterface shader, int colorAttachments) {
        dev.veil.revive.client.shaderpack.preparation.GraphicsInterfaceValidation
                .validateFullscreen(shader, colorAttachments);
    }

    static void validateFullscreen(
            VeilShaderInterface shader, int colorAttachments, Set<VeilShaderStage> stages) {
        dev.veil.revive.client.shaderpack.preparation.GraphicsInterfaceValidation
                .validateFullscreen(shader, colorAttachments, stages);
    }

    static void validateVertexLayout(
            VeilVertexLayout layout, VeilShaderInterface shader, int colorAttachments) {
        dev.veil.revive.client.shaderpack.preparation.GraphicsInterfaceValidation
                .validateVertexLayout(layout, shader, colorAttachments);
    }

    static void validateVertexLayout(
            VeilVertexLayout layout,
            VeilShaderInterface shader,
            int colorAttachments,
            Set<VeilShaderStage> stages) {
        dev.veil.revive.client.shaderpack.preparation.GraphicsInterfaceValidation
                .validateVertexLayout(layout, shader, colorAttachments, stages);
    }

    long handle() {
        return pipeline.handle();
    }

    long layout() {
        return pipeline.layout();
    }

    @Override
    public void close() {
        pipeline.close();
    }
}
