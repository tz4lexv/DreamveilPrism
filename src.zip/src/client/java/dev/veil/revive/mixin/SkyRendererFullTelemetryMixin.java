package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.renderer.SkyRenderer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRenderer.class)
public abstract class SkyRendererFullTelemetryMixin {
    @Inject(method = "extractRenderState", at = @At("HEAD"), require = 0)
    private void veil$skyStart(CallbackInfo ci) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.SKY_EXTRACT);
    }

    @Inject(method = "extractRenderState", at = @At("RETURN"), require = 0)
    private void veil$skyEnd(CallbackInfo ci) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.SKY_EXTRACT);
    }
}
