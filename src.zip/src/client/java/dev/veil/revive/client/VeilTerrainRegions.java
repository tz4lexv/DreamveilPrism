package dev.veil.revive.client;

import net.minecraft.core.SectionPos;

final class VeilTerrainRegions {
    private static final int SHIFT =
            Math.clamp(Integer.getInteger("veil.terrainRegionShift", 5), 2, 5);

    private VeilTerrainRegions() {}

    static long key(long sectionNode, boolean enabled) {
        return enabled
                ? SectionPos.asLong(
                        SectionPos.x(sectionNode) >> SHIFT,
                        SectionPos.y(sectionNode) >> SHIFT,
                        SectionPos.z(sectionNode) >> SHIFT)
                : 0L;
    }

    static int sectionSpan() {
        return 1 << SHIFT;
    }
}
