package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

public final class VeilRendererInfo {
    public static final String NAME = "Veil Renderer";
    public static final String VERSION = VeilPlatform.get().rendererVersion();
    public static final String VEIL_VERSION = VeilPlatform.get().modVersion("veil");
    public static final String PACKAGE_REVISION = VeilPlatform.get().packageRevision();

    private VeilRendererInfo() {}

    public static String displayName() {
        return NAME + " " + VERSION;
    }

    public static void logStartup(String profile) {
        ReviveMod.LOGGER.info("============================================================");
        ReviveMod.LOGGER.info("{} - ACTIVE", displayName());
        ReviveMod.LOGGER.info("Veil {}", VEIL_VERSION);
        ReviveMod.LOGGER.info("Package revision: {}", PACKAGE_REVISION);
        ReviveMod.LOGGER.info("Minecraft: 26.2 / {}", VeilPlatform.get().loaderName());
        ReviveMod.LOGGER.info("Profile: {}", profile);
        ReviveMod.LOGGER.info("Runtime: standalone");
        ReviveMod.LOGGER.info(
                "Core policy: PROGRAMMABLE - graphics algorithms belong to shader packs");
        ReviveMod.LOGGER.info("============================================================");
    }
}
