package dev.veil.revive.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.CompiledSectionMesh;
import net.minecraft.client.renderer.chunk.RenderRegionCache;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.core.SectionPos;

import java.util.List;

final class VeilSceneResidentCompiler {
    private static final java.util.Map<String, Integer> cursors = new java.util.WeakHashMap<>();
    private static java.lang.ref.WeakReference<net.minecraft.client.multiplayer.ClientLevel> owner =
            new java.lang.ref.WeakReference<>(null);
    private static long lastActivity;
    private static long observedMeshRevision;

    static boolean settled() {
        var renderer = Minecraft.getInstance().levelRenderer;
        var dispatcher = renderer.sectionRenderDispatcher();
        long revision = VeilHostRevisions.mesh();
        if (revision != observedMeshRevision) {
            observedMeshRevision = revision;
            lastActivity = System.nanoTime();
        }
        var area = renderer.viewArea();
        if (area == null) return false;
        for (var section :
                ((dev.veil.revive.mixin.ViewAreaSectionsAccessor) area).veil$sections()) {
            if (section != null && ((VeilRayCompileState) section).veil$rayCompilePending())
                return false;
        }
        return dispatcher != null
                && dispatcher.getCompileQueueSize() == 0
                && System.nanoTime() - lastActivity >= 5_000_000_000L;
    }

    static void schedule(String pass, List<SectionRenderDispatcher.RenderSection> sections) {
        var client = Minecraft.getInstance();
        var world = client.level;
        var dispatcher = client.levelRenderer.sectionRenderDispatcher();
        if (owner.get() != world) {
            owner = new java.lang.ref.WeakReference<>(world);
            cursors.clear();
            lastActivity = System.nanoTime();
        }
        int budget = Math.clamp(Integer.getInteger("veil.sceneResidentCompiles", 2), 0, 8);
        if (world == null
                || dispatcher == null
                || budget == 0
                || dispatcher.getCompileQueueSize() != 0
                || dispatcher.getFreeBufferCount() == 0) return;
        RenderRegionCache cache = null;
        long deadline = System.nanoTime() + 1_000_000L;
        int scheduled = 0;
        int count = sections.size();
        if (count == 0) return;
        int cursor = Math.floorMod(cursors.getOrDefault(pass, 0), count);
        for (int scanned = 0; scanned < count; scanned++) {
            if (scheduled >= budget || System.nanoTime() >= deadline) break;
            var section = sections.get(cursor);
            cursor = (cursor + 1) % count;
            if (((VeilRayCompileState) section).veil$rayCompilePending()) {
                lastActivity = System.nanoTime();
                continue;
            }
            if (section.getSectionMesh() != CompiledSectionMesh.UNCOMPILED) continue;
            long node = section.getSectionNode();
            int x = SectionPos.x(node), z = SectionPos.z(node);
            boolean loaded = true;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    loaded &= world.getChunkSource().hasChunk(x + dx, z + dz);
            if (!loaded) continue;
            if (cache == null) cache = new RenderRegionCache();
            section.compileAsync(cache.createRegion(world, node));
            lastActivity = System.nanoTime();
            scheduled++;
        }
        cursors.put(pass, cursor);
    }
}
