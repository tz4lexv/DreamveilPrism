package dev.veil.revive.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;

@Mixin(targets = "net.minecraft.client.renderer.texture.SpriteContents$AnimatedTexture")
public interface PbrAnimatedTextureAccessor {
    @Accessor("frames")
    List<?> veil$pbrFrames();

    @Accessor("interpolateFrames")
    boolean veil$pbrInterpolate();
}
