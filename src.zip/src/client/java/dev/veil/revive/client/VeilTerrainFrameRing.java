package dev.veil.revive.client;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Util;

import org.joml.Matrix4fc;

final class VeilTerrainFrameRing {
    private static final int SLOT_COUNT = 8;
    private static final boolean RETAIN_ORIGINS =
            Boolean.getBoolean("veil.residentTerrainCommands");
    private final VeilTerrainFrameData[] slots = new VeilTerrainFrameData[SLOT_COUNT];
    private int cursor = -1;

    private int[] shadowX = new int[0];
    private int[] shadowY = new int[0];
    private int[] shadowZ = new int[0];
    private int[] shadowVisibilityBits = new int[0];
    private int shadowCount;
    private long captureCalls;
    private long captureNanos;

    VeilTerrainFrameRing() {
        for (int i = 0; i < slots.length; i++) slots[i] = new VeilTerrainFrameData();
    }

    VeilTerrainFrameData capture(
            Matrix4fc modelView,
            int atlasWidth,
            int atlasHeight,
            SectionRenderDispatcher.RenderSection[] sections,
            int[] sectionIndices) {
        long captureStartNs =
                (VeilDiagnostics.benchmarkActive() || ReviveRuntime.config().profilerEnabled())
                        ? System.nanoTime()
                        : 0L;
        cursor = (cursor + 1) & (SLOT_COUNT - 1);
        VeilTerrainFrameData frame = slots[cursor];
        int count = sectionIndices.length;
        frame.begin(modelView, atlasWidth, atlasHeight, count);
        ensureShadowCapacity(count);

        long now = Util.getMillis();
        for (int i = 0; i < count; i++) {
            int sectionIndex = sectionIndices[i];
            if (sectionIndex < 0) {
                if (RETAIN_ORIGINS && i < shadowCount) {
                    frame.set(
                            i,
                            shadowX[i],
                            shadowY[i],
                            shadowZ[i],
                            0.0f,
                            shadowVisibilityBits[i] != 0);
                    shadowVisibilityBits[i] = 0;
                    continue;
                }
                boolean changed =
                        i >= shadowCount
                                || shadowX[i] != 0
                                || shadowY[i] != 0
                                || shadowZ[i] != 0
                                || shadowVisibilityBits[i] != 0;
                frame.set(i, 0, 0, 0, 0.0f, changed);
                shadowX[i] = shadowY[i] = shadowZ[i] = shadowVisibilityBits[i] = 0;
                continue;
            }
            SectionRenderDispatcher.RenderSection section = sections[sectionIndex];
            BlockPos liveOrigin = section.getRenderOrigin();
            int x = liveOrigin.getX();
            int y = liveOrigin.getY();
            int z = liveOrigin.getZ();
            float visibility = section.getVisibility(now);
            int visibilityBits = Float.floatToRawIntBits(visibility);
            boolean changed =
                    i >= shadowCount
                            || shadowX[i] != x
                            || shadowY[i] != y
                            || shadowZ[i] != z
                            || shadowVisibilityBits[i] != visibilityBits;
            frame.set(i, x, y, z, visibility, changed);
            shadowX[i] = x;
            shadowY[i] = y;
            shadowZ[i] = z;
            shadowVisibilityBits[i] = visibilityBits;
        }
        shadowCount = count;
        if (captureStartNs != 0L) {
            captureCalls++;
            captureNanos += System.nanoTime() - captureStartNs;
        }
        return frame;
    }

    private void ensureShadowCapacity(int required) {
        if (shadowX.length >= required) return;
        int next = Math.max(16, Integer.highestOneBit(Math.max(1, required - 1)) << 1);
        if (next < required) next = required;
        shadowX = java.util.Arrays.copyOf(shadowX, next);
        shadowY = java.util.Arrays.copyOf(shadowY, next);
        shadowZ = java.util.Arrays.copyOf(shadowZ, next);
        shadowVisibilityBits = java.util.Arrays.copyOf(shadowVisibilityBits, next);
    }

    void clear() {
        cursor = -1;
        shadowCount = 0;
    }

    void resetTelemetry() {
        captureCalls = 0L;
        captureNanos = 0L;
    }

    String telemetry() {
        long primitiveUpdates = 0L;
        long fallbackMaterializations = 0L;
        for (VeilTerrainFrameData slot : slots) {
            primitiveUpdates += slot.primitiveUpdates();
            fallbackMaterializations += slot.fallbackMaterializations();
        }
        return "terrain_frame_primitive_updates_total="
                + primitiveUpdates
                + "\n"
                + "terrain_frame_fallback_materializations_total="
                + fallbackMaterializations
                + "\n"
                + "terrain_frame_capture_calls_total="
                + captureCalls
                + "\n"
                + "terrain_frame_capture_ms_total="
                + String.format(java.util.Locale.ROOT, "%.4f", captureNanos / 1_000_000.0)
                + "\n"
                + "terrain_frame_capture_avg_ms="
                + String.format(
                        java.util.Locale.ROOT,
                        "%.5f",
                        captureCalls == 0L ? 0.0 : (captureNanos / 1_000_000.0) / captureCalls)
                + "\n";
    }
}
