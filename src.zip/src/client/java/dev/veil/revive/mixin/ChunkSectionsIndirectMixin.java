package dev.veil.revive.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.textures.GpuSampler;

import dev.veil.revive.client.VeilChunkSectionsExtras;
import dev.veil.revive.client.VeilIndirectTerrain;
import dev.veil.revive.client.VeilTerrainDrawBridge;
import dev.veil.revive.client.VeilTerrainFrameData;

import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChunkSectionsToRender.class)
public abstract class ChunkSectionsIndirectMixin implements VeilChunkSectionsExtras {
    @Shadow @Final @Mutable private GpuBufferSlice[] chunkSectionInfos;
    @Unique private VeilTerrainFrameData veil$fallbackFrame;
    @Unique private boolean veil$hostGpuProfile;

    @Override
    public void veil$setFallbackSectionFrame(VeilTerrainFrameData frameData) {
        veil$fallbackFrame = frameData;
    }

    @Override
    public void veil$ensureHostUniforms() {
        if (chunkSectionInfos.length != 0 || veil$fallbackFrame == null) return;
        chunkSectionInfos = VeilTerrainDrawBridge.materializeFallbackUniforms(veil$fallbackFrame);
    }

    @Inject(method = "renderGroup", at = @At("HEAD"), cancellable = true, require = 1)
    private void veil$indirect(ChunkSectionLayerGroup group, GpuSampler sampler, CallbackInfo ci) {
        dev.veil.revive.client.VeilMaterialHost.beforeTerrainGroup(group);
        ChunkSectionsToRender self = (ChunkSectionsToRender) (Object) this;
        if (VeilIndirectTerrain.render(self, group, sampler)) {
            ci.cancel();
            return;
        }
        veil$ensureHostUniforms();

        veil$hostGpuProfile = VeilIndirectTerrain.beginHostTerrainGpuProfile(group);
    }

    @Inject(method = "renderGroup", at = @At("RETURN"), require = 1)
    private void veil$finishHostGpuProfile(
            ChunkSectionLayerGroup group, GpuSampler sampler, CallbackInfo ci) {
        if (!veil$hostGpuProfile) return;
        VeilIndirectTerrain.endHostTerrainGpuProfile(true);
        veil$hostGpuProfile = false;
    }
}
