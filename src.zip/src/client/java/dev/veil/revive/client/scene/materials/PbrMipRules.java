package dev.veil.revive.client.scene.materials;

public final class PbrMipRules {
    private PbrMipRules() {}

    public static int levels(int requested, int width, int height) {
        if (requested < 1 || width < 1 || height < 1)
            throw new IllegalArgumentException("Invalid PBR mip dimensions");
        return Math.min(requested, 32 - Integer.numberOfLeadingZeros(Math.min(width, height)));
    }

    public static int spriteLevels(int requested, int x, int y, int width, int height) {
        if (x < 0 || y < 0) throw new IllegalArgumentException("Invalid PBR sprite origin");
        int levels = levels(requested, width, height);
        while (levels > 1 && ((x | y | width | height) & ((1 << (levels - 1)) - 1)) != 0) levels--;
        return levels;
    }

    public static long atlasBytes(int width, int height, int levels) {
        return atlasBytes(width, height, levels, true, true);
    }

    public static long atlasBytes(
            int width, int height, int levels, boolean normal, boolean specular) {
        if (levels != levels(levels, width, height))
            throw new IllegalArgumentException("Invalid PBR mip count");
        long bytes = 0;
        int bytesPerPixel = (normal ? 4 : 0) + (specular ? 4 : 0);
        for (int mip = 0; mip < levels; mip++)
            bytes =
                    Math.addExact(
                            bytes,
                            Math.multiplyExact(
                                    (long) (width >> mip) * (height >> mip), bytesPerPixel));
        return bytes;
    }
}
