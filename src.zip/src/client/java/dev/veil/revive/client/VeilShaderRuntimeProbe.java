package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

final class VeilShaderRuntimeProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.shaderProbe") && VeilPlatform.get().isDevelopmentEnvironment();
    private static long firstFrame;
    private static long startedAt;
    private static int frames;
    private static boolean requested;
    private static boolean completed;
    private static int verifiedGenerations;
    private static VeilShaderPackRuntime previousGeneration;
    private static java.util.List<String> variants;
    private static boolean rejectionPending, rejectionVerified;

    private VeilShaderRuntimeProbe() {}

    static void tick(VeilShaderPackRuntime active, boolean failed) {
        if (!ENABLED || completed) return;
        boolean nativeLighting = System.getProperty("veil.shaderPack", "").equals("lightingtest");
        long now = System.nanoTime();
        if (startedAt == 0) startedAt = now;
        if (firstFrame == 0 && active != null && active != previousGeneration) firstFrame = now;
        if (failed
                || (firstFrame == 0
                        ? now - startedAt > 180_000_000_000L
                        : now - firstFrame > 60_000_000_000L)) {
            completed = true;
            ReviveMod.LOGGER.error(
                    "Veil shader GPU probe: FAIL (runtime unavailable, stopped, or readback timed out)");
            Minecraft.getInstance().stop();
            return;
        }
        if (rejectionPending) {
            if (active != previousGeneration) {
                completed = true;
                ReviveMod.LOGGER.error(
                        "Veil shader GPU probe: FAIL (unsupported ray query replaced the active generation)");
                Minecraft.getInstance().stop();
                return;
            }
            if (!VeilShaderService.reloadRejected()) return;
            rejectionPending = false;
            rejectionVerified = true;
            previousGeneration = null;
            firstFrame = now;
            ReviveMod.LOGGER.info(
                    "Veil ray SDK: unsupported hardware variant rejected; previous generation retained; checking pixels again");
        }
        if (nativeLighting && !VeilNativeLightingHost.ready()) return;
        if (active == null
                || active == previousGeneration
                || requested
                || ++frames < (VeilShaderService.profiling() ? 120 : 8)) return;
        boolean performance = System.getProperty("veil.shaderPack", "").equals("performance");
        boolean ray = System.getProperty("veil.shaderPack", "").equals("raytest");
        boolean rayPipeline = System.getProperty("veil.shaderPack", "").equals("raypipeline");
        boolean genericGraphics =
                System.getProperty("veil.shaderPack", "").equals("genericgraphics");
        boolean creatorGraphics =
                System.getProperty("veil.shaderPack", "").equals("creatorgraphics");
        if (ray && variants == null) {
            variants =
                    VeilRayCapabilities.rayQuery()
                            ? java.util.List.of("PORTABLE", "RAY_QUERY")
                            : java.util.List.of("PORTABLE");
            ReviveMod.LOGGER.info(
                    "Veil ray SDK GPU probe variants: {}; {}",
                    variants,
                    VeilRayCapabilities.report());
        }
        if (!ray
                && !performance
                && !genericGraphics
                && !creatorGraphics
                && !nativeLighting
                && !System.getProperty("veil.shaderPack", "").equals("example")
                && !System.getProperty("veil.shaderPack", "").equals("raypipeline")
                && !System.getProperty("veil.shaderPack", "").equals("slangtest")
                && !System.getProperty("veil.shaderPack", "").equals("slangvolume")) {
            throw new IllegalArgumentException(
                    "Veil shader GPU probe requires a supported bundled conformance pack");
        }
        if (performance && variants == null) {
            var supported = new java.util.ArrayList<String>();
            supported.add("BASELINE");
            if (VeilVulkanCapabilities.shaderFloat16()) supported.add("FP16");
            var device = VeilShaderDeviceLimits.capture(VeilVulkanRuntime.requireCurrent());
            int required =
                    org.lwjgl.vulkan.VK11.VK_SUBGROUP_FEATURE_BASIC_BIT
                            | org.lwjgl.vulkan.VK11.VK_SUBGROUP_FEATURE_ARITHMETIC_BIT;
            if ((device.subgroupStages() & org.lwjgl.vulkan.VK10.VK_SHADER_STAGE_COMPUTE_BIT) != 0
                    && (device.subgroupOperations() & required) == required)
                supported.add("SUBGROUP");
            variants = java.util.List.copyOf(supported);
            ReviveMod.LOGGER.info("Veil capability GPU probe supported variants: {}", variants);
        }
        requested = true;
        String outputName = genericGraphics ? "main" : "output";
        var texture = active.output(outputName).texture();
        int width = texture.getWidth(0), height = texture.getHeight(0);
        if (nativeLighting && (width != 16 || height != 16))
            throw new IllegalStateException(
                    "Native lighting probe requires all 256 lightmap texels");
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil shader GPU probe readback",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                (long) width * height * 4);
        try {
            active.readOutput(
                    outputName,
                    readback,
                    () -> {
                        try (var mapped = readback.map(true, false)) {
                            var bytes = mapped.data();
                            if (creatorGraphics)
                                VeilCreatorGraphicsProbe.verify(
                                        bytes,
                                        width,
                                        height,
                                        verifiedGenerations == 0 ? 0.0f : 0.4f);
                            int[] expected = {32, 64, 128, 255};
                            if (nativeLighting) expected = new int[] {0, 0, 0, 255};
                            for (int pixel = 0;
                                    !creatorGraphics && pixel < width * height;
                                    pixel++) {
                                for (int channel = 0; channel < 4; channel++) {
                                    int actual = Byte.toUnsignedInt(bytes.get(pixel * 4 + channel));
                                    int tolerance = nativeLighting && channel != 0 ? 0 : 1;
                                    if (Math.abs(actual - expected[channel]) > tolerance) {
                                        throw new IllegalStateException(
                                                "pixel="
                                                        + pixel
                                                        + " channel="
                                                        + channel
                                                        + " expected="
                                                        + expected[channel]
                                                        + " actual="
                                                        + actual);
                                    }
                                }
                            }
                            verifiedGenerations++;
                            if (nativeLighting)
                                saveNativeLightingReadback(bytes, verifiedGenerations);
                            if (VeilShaderService.profiling()) {
                                active.requireProfileSamples(16);
                                ReviveMod.LOGGER.info(
                                        "Veil native shader profile generation {}:\n{}",
                                        verifiedGenerations,
                                        VeilShaderService.performanceReport());
                            }
                            if (ray && !VeilRayCapabilities.rayQuery() && !rejectionVerified) {
                                previousGeneration = active;
                                requested = false;
                                frames = 0;
                                firstFrame = System.nanoTime();
                                rejectionPending = true;
                                VeilShaderService.setting("backend", "RAY_QUERY");
                            } else if ((performance || ray)
                                    && verifiedGenerations < variants.size()) {
                                previousGeneration = active;
                                requested = false;
                                frames = 0;
                                VeilShaderService.setting(
                                        ray ? "backend" : "mode",
                                        variants.get(verifiedGenerations));
                                firstFrame = 0;
                                startedAt = System.nanoTime();
                            } else if (!performance && !ray && verifiedGenerations == 1) {
                                previousGeneration = active;
                                requested = false;
                                frames = 0;
                                if (creatorGraphics) VeilShaderService.setting("cameraYaw", "0.4");
                                else VeilShaderService.requestReload();
                                firstFrame = 0;
                                startedAt = System.nanoTime();
                                ReviveMod.LOGGER.info(
                                        "Veil shader GPU probe: first generation pixels verified; requesting transactional reload");
                            } else {
                                completed = true;
                                ReviveMod.LOGGER.info(
                                        "Veil shader GPU probe: PASS ({} pixels per readback, {} verified readbacks, creator variants={}, {})",
                                        width * height,
                                        verifiedGenerations,
                                        performance || ray
                                                ? variants
                                                : genericGraphics
                                                        ? "genericgraphics reload"
                                                        : creatorGraphics
                                                                ? "creatorgraphics camera change"
                                                                : rayPipeline
                                                                        ? "raypipeline reload"
                                                                        : nativeLighting
                                                                                ? "native lighting reload"
                                                                                : "example reload",
                                        creatorGraphics
                                                ? "fragment-defined camera + analytic surface shadows + ray-marched volumetric shadowed fog"
                                                : genericGraphics
                                                        ? "direct + indexed + instanced + compute-generated multi-draw indirect"
                                                        : nativeLighting
                                                                ? "native lightmap versus original lighting parameters; unshadowed reconstruction and local/ambient preservation before postprocessing"
                                                                : rayPipeline
                                                                        ? "raygen/miss/closest-hit/any-hit/callable -> storage buffer -> sampled RGBA8"
                                                                        : "compute -> storage buffer -> fullscreen HDR -> sampled RGBA8");
                            }
                        } catch (RuntimeException failure) {
                            completed = true;
                            ReviveMod.LOGGER.error(
                                    "Veil shader GPU probe: FAIL ({})",
                                    failure.getMessage(),
                                    failure);
                        } finally {
                            readback.close();
                            if (completed) Minecraft.getInstance().stop();
                        }
                    });
        } catch (RuntimeException failure) {
            readback.close();
            throw failure;
        }
    }

    private static void saveNativeLightingReadback(java.nio.ByteBuffer bytes, int generation) {
        byte[] pixels = new byte[16 * 16 * 4];
        bytes.duplicate().position(0).get(pixels);
        int maximum = 0;
        for (int i = 0; i < pixels.length; i += 4)
            maximum = Math.max(maximum, Byte.toUnsignedInt(pixels[i]));
        try {
            var directory = java.nio.file.Path.of("logs", "native-lighting");
            java.nio.file.Files.createDirectories(directory);
            java.nio.file.Files.write(
                    directory.resolve("generation-" + generation + ".rgba"), pixels);
        } catch (java.io.IOException failure) {
            throw new java.io.UncheckedIOException(failure);
        }
        ReviveMod.LOGGER.info(
                "Veil native lighting readback: generation={} texels=256 max_native_table_error_u8={} local_ambient_error_u8=0 valid=true",
                generation,
                maximum);
    }
}
