package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.FrameTimeSeries;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

final class VeilCameraSweepProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.cameraSweepProbe");
    private static final long WARMUP_NS =
            Math.clamp(Long.getLong("veil.cameraSweepWarmupMillis", 30000L), 1000L, 120000L)
                    * 1_000_000L;
    private static final long PHASE_NS =
            Math.clamp(Long.getLong("veil.cameraSweepPhaseMillis", 5000L), 1000L, 30000L)
                    * 1_000_000L;
    private static final int REPETITIONS =
            Math.clamp(Integer.getInteger("veil.cameraSweepRepetitions", 1), 1, 5);
    private static final int PHASE_COUNT = 3 * REPETITIONS;
    private static final boolean TRAVEL = Boolean.getBoolean("veil.cameraSweepTravel");
    private static final long[] START_FLUID_RESOLVED = ENABLED ? new long[PHASE_COUNT] : null;
    private static final long[] START_FLUID_UNRESOLVED = ENABLED ? new long[PHASE_COUNT] : null;
    private static final String[] NAMES = phaseNames();
    private static final com.sun.management.ThreadMXBean ALLOCATIONS =
            ENABLED
                    ? java.lang.management.ManagementFactory.getPlatformMXBean(
                            com.sun.management.ThreadMXBean.class)
                    : null;
    private static final VeilSectionVisibility.Counters[] START_CONNECTIVITY =
            new VeilSectionVisibility.Counters[PHASE_COUNT];
    private static final long[] START_ALLOCATIONS = new long[PHASE_COUNT];
    private static final JvmSample[] START_JVM = new JvmSample[PHASE_COUNT];
    private static final VeilBlockModelRenderer.LightingLeases[] START_LIGHTING =
            new VeilBlockModelRenderer.LightingLeases[PHASE_COUNT];
    private static final java.util.List<java.lang.management.GarbageCollectorMXBean> COLLECTORS =
            ENABLED
                    ? java.lang.management.ManagementFactory.getGarbageCollectorMXBeans()
                    : java.util.List.of();
    private static double originX, originY, originZ;
    private static boolean originCaptured;
    private static final FrameTimeSeries[] FRAME = seriesArray();
    private static final FrameTimeSeries[] RENDER = seriesArray();
    private static final VeilCameraSweepContext[] CONTEXT = contextArray();
    private static final VeilIndirectTerrain.PlanCounters[] START =
            new VeilIndirectTerrain.PlanCounters[PHASE_COUNT];
    private static final VeilFullFrameTelemetry.Snapshot[] START_CPU =
            new VeilFullFrameTelemetry.Snapshot[PHASE_COUNT];
    private static final VeilGpuProfiler.Snapshot[] START_GPU =
            new VeilGpuProfiler.Snapshot[PHASE_COUNT];
    private static final VeilTechniqueCounters.Snapshot[] START_TERRAIN =
            new VeilTechniqueCounters.Snapshot[PHASE_COUNT];
    private static final VeilLodArena.SelectionCounters[] START_LOD =
            new VeilLodArena.SelectionCounters[PHASE_COUNT];
    private static final VeilTransparencyOrder.Counters[] START_TRANSPARENCY =
            new VeilTransparencyOrder.Counters[PHASE_COUNT];
    private static int phase = -1;
    private static boolean captureRequested;
    private static volatile boolean captureComplete;
    private static boolean transparencyBypassStarted, transparencyBypassRestored;

    private VeilCameraSweepProbe() {}

    private static String[] phaseNames() {
        String[] names = new String[PHASE_COUNT];
        String[] base = {"still-before", TRAVEL ? "travelling" : "rotating", "still-after"};
        for (int i = 0; i < names.length; i++)
            names[i] = base[i % 3] + (REPETITIONS == 1 ? "" : "-round" + (i / 3));
        return names;
    }

    private static FrameTimeSeries[] seriesArray() {
        FrameTimeSeries[] series = new FrameTimeSeries[PHASE_COUNT];
        for (int i = 0; i < series.length; i++) series[i] = new FrameTimeSeries();
        return series;
    }

    private static VeilCameraSweepContext[] contextArray() {
        if (!ENABLED) return null;
        VeilCameraSweepContext[] contexts = new VeilCameraSweepContext[PHASE_COUNT];
        for (int i = 0; i < contexts.length; i++) contexts[i] = new VeilCameraSweepContext();
        return contexts;
    }

    static boolean enabled() {
        return ENABLED;
    }

    static boolean tick(Minecraft client, long elapsedNs) {
        if (!ENABLED) return false;
        if (Boolean.getBoolean("veil.transparencyTransitionProbe")) {
            if (!transparencyBypassStarted && elapsedNs >= 8_000_000_000L) {
                if (VeilDiagnostics.bypassed())
                    throw new IllegalStateException(
                            "Transparency probe requires initial active renderer");
                transparencyBypassStarted = true;
                VeilDiagnostics.setBypassed(true, client, false);
                ReviveMod.LOGGER.info("Veil transparency transition: native fallback started");
            }
            if (transparencyBypassStarted
                    && !transparencyBypassRestored
                    && elapsedNs >= 10_000_000_000L) {
                transparencyBypassRestored = true;
                VeilDiagnostics.setBypassed(false, client, false);
                ReviveMod.LOGGER.info("Veil transparency transition: renderer restored");
            }
        }
        String captureName = System.getProperty("veil.terrainCapture");
        if (captureName != null && !captureRequested && elapsedNs >= WARMUP_NS - 1_000_000_000L) {
            if (!captureName.matches("[A-Za-z0-9._-]+"))
                throw new IllegalArgumentException("Invalid terrain capture filename");
            var directory = VeilPlatform.get().getGameDir().resolve("screenshots/terrain-proof");
            try {
                java.nio.file.Files.createDirectories(directory);
            } catch (java.io.IOException failure) {
                throw new IllegalStateException(failure);
            }
            captureRequested = true;
            net.minecraft.client.Screenshot.takeScreenshot(
                    client.gameRenderer.mainRenderTarget(),
                    image -> {
                        try {
                            image.writeToFile(directory.resolve(captureName + ".png"));
                            captureComplete = true;
                            ReviveMod.LOGGER.info("Veil terrain capture PASS: {}", captureName);
                        } catch (java.io.IOException failure) {
                            throw new IllegalStateException(failure);
                        } finally {
                            image.close();
                        }
                    });
        }
        if (TRAVEL && !originCaptured) {
            originX = client.player.getX();
            originY = client.player.getY();
            originZ = client.player.getZ();
            originCaptured = true;
        }
        if (TRAVEL && elapsedNs < WARMUP_NS) {
            double seconds = elapsedNs / 1.0e9;
            travel(client, seconds < 20.0 ? seconds / 20.0 : 0.0);
        }
        if (elapsedNs < WARMUP_NS) return false;
        int next = (int) ((elapsedNs - WARMUP_NS) / PHASE_NS);
        if (next > PHASE_COUNT) next = PHASE_COUNT;
        if (next != phase) {
            if (phase >= 0 && phase < PHASE_COUNT) report(phase);
            phase = next;
            if (phase == PHASE_COUNT) {
                if (Boolean.getBoolean("veil.transparencyTransitionProbe")
                        && !transparencyBypassRestored)
                    throw new IllegalStateException("Transparency transition probe incomplete");
                VeilAsyncTerrainSelection.requireVerificationComplete();
                VeilSlangHzbProbe.requireComplete();
                VeilSlangCullProbe.requireComplete();
                VeilCommandVisibilityProbe.requireComplete();
                VeilResidentVisibilityProbe.requireComplete();
                VeilLodArena.requireResidentSelectionVerification();
                VeilTerrainDrawBridge.requireIncrementalOwnerVerification();
                VeilResidentRetirementProbe.requireComplete();
                VeilIndexedTerrain.requireComplete();
                VeilTransparencyOrder.requireComplete();
                VeilTerrainPlanScratch.requireComplete();
                VeilIndirectTerrain.requireCompactPlanProof();
                VeilTransparencyLifecycleProbe.requireComplete();
                VeilProgressiveMeshing.requireComplete();
                VeilPairedTerrainLifecycleProbe.requireComplete();
                VeilParametricTerrainLifecycleProbe.requireComplete();
                VeilTerrainQuadWriter.requireComplete();
                VeilSectionStateSnapshot.requireComplete();
                VeilOwnSectionCompiler.requireComplete();
                VeilSectionVisibility.requireComplete();
                VeilBlockModelRenderer.requireComplete();
                VeilCompilerCancellationProbe.requireComplete();
                VeilRegularPackedTerrain.requireComplete();
                VeilRegularPackedGpuProbe.requireComplete();
                VeilAttributePatchGpuProbe.requireComplete();
                VeilSparseAttributeGpuProbe.requireComplete();
                VeilChangedLightGpuProbe.requireComplete();
                VeilCanonicalSparseUploads.requireComplete();
                VeilCanonicalGpuProbe.requireComplete();
                VeilCanonicalArenaGpuProbe.requireComplete();
                VeilBufferTransferGpuProbe.requireComplete();
                VeilStagingRingGpuProbe.requireComplete();
                VeilParametricQuadsGpuProbe.requireComplete();
                VeilParametricTerrainGpuProbe.requireComplete();
                VeilParametricTerrainArena.requireComplete();
                VeilRegularPackedLifecycleProbe.requireComplete();
                if (captureName != null && !captureComplete)
                    throw new IllegalStateException("Terrain capture did not complete");
                exportSamples(client);
                ReviveMod.LOGGER.info("Veil camera sweep: PASS");
                return true;
            }
            START[phase] = VeilIndirectTerrain.planCounters();
            START_CPU[phase] = VeilFullFrameTelemetry.snapshot();
            START_GPU[phase] = VeilGpuProfiler.snapshot();
            START_TERRAIN[phase] = VeilTechniqueCounters.snapshot();
            START_LOD[phase] = VeilLodArena.selectionCounters();
            START_TRANSPARENCY[phase] = VeilTransparencyOrder.counters();
            START_ALLOCATIONS[phase] = allocatedBytes();
            START_JVM[phase] = jvmSample();
            START_LIGHTING[phase] = VeilBlockModelRenderer.lightingLeases();
            START_CONNECTIVITY[phase] = VeilSectionVisibility.counters();
            START_FLUID_RESOLVED[phase] = VeilFluidMaterialCapture.resolvedGroups();
            START_FLUID_UNRESOLVED[phase] = VeilFluidMaterialCapture.unresolvedGroups();
            ReviveMod.LOGGER.info("Veil camera sweep: {} started", NAMES[phase]);
        }
        if (TRAVEL) {
            travel(
                    client,
                    phase % 3 == 1
                            ? (double) (elapsedNs - WARMUP_NS - phase * PHASE_NS) / PHASE_NS
                            : 0.0);
            return false;
        }
        double rotation =
                phase % 3 == 1 ? (elapsedNs - WARMUP_NS - phase * PHASE_NS) / 1.0e9 * 360.0 : 0.0;
        client.player.setYRot((float) (135.0 + rotation));
        client.player.setXRot(20.0f);
        return false;
    }

    private static void travel(Minecraft client, double fraction) {
        double angle = fraction * Math.PI * 2.0;
        client.player.setPos(
                originX + Math.sin(angle) * 32.0,
                originY,
                originZ + (1.0 - Math.cos(angle)) * 32.0);
        client.player.setYRot((float) (135.0 + fraction * 360.0));
        client.player.setXRot(20.0f);
    }

    private static long allocatedBytes() {
        return ALLOCATIONS != null
                        && ALLOCATIONS.isThreadAllocatedMemorySupported()
                        && ALLOCATIONS.isThreadAllocatedMemoryEnabled()
                ? ALLOCATIONS.getCurrentThreadAllocatedBytes()
                : -1;
    }

    private record JvmSample(long allocatedBytes, long collections, long collectionMillis) {}

    private static JvmSample jvmSample() {
        long allocated = -1;
        if (ALLOCATIONS != null
                && ALLOCATIONS.isThreadAllocatedMemorySupported()
                && ALLOCATIONS.isThreadAllocatedMemoryEnabled()) {
            try {
                allocated = ALLOCATIONS.getTotalThreadAllocatedBytes();
            } catch (UnsupportedOperationException ignored) {
            }
        }
        long count = 0, millis = 0;
        boolean counted = false, timed = false;
        for (var collector : COLLECTORS) {
            long c = collector.getCollectionCount(), t = collector.getCollectionTime();
            if (c >= 0) {
                count += c;
                counted = true;
            }
            if (t >= 0) {
                millis += t;
                timed = true;
            }
        }
        return new JvmSample(allocated, counted ? count : -1, timed ? millis : -1);
    }

    private static long availableDelta(long end, long start) {
        return start >= 0 && end >= start ? end - start : -1;
    }

    static void onFrameStart(double frameMs, long frameEndNanos) {
        if (ENABLED && phase >= 0 && phase < PHASE_COUNT && frameMs > 0.0) {
            FRAME[phase].add(frameMs);
            VeilFrameJfrAnchor.sample(phase, NAMES[phase], frameEndNanos);
            CONTEXT[phase].sample(Minecraft.getInstance());
        }
    }

    static void onFrameEnd(double renderMs) {
        if (ENABLED && phase >= 0 && phase < PHASE_COUNT && renderMs >= 0.0)
            RENDER[phase].add(renderMs);
    }

    private static void report(int index) {
        ReviveMod.LOGGER.info(
                "Veil camera sweep fluid materials: {} resolved_groups={} unresolved_groups={}",
                NAMES[index],
                VeilFluidMaterialCapture.resolvedGroups() - START_FLUID_RESOLVED[index],
                VeilFluidMaterialCapture.unresolvedGroups() - START_FLUID_UNRESOLVED[index]);
        CONTEXT[index].report(NAMES[index]);
        var gpuDelta = START_GPU[index].deltaTo(VeilGpuProfiler.snapshot());
        for (var pass : VeilGpuProfiler.Pass.values()) {
            ReviveMod.LOGGER.info(
                    "Veil camera sweep GPU: {} pass={} samples={} average_ms={}",
                    NAMES[index],
                    pass.key,
                    gpuDelta.samples(pass),
                    gpuDelta.averageMs(pass));
        }
        var loadDelta = VeilFullFrameTelemetry.snapshot().minus(START_CPU[index]);
        ReviveMod.LOGGER.info(
                "Veil camera sweep uploads: {} bytes={}",
                NAMES[index],
                loadDelta
                        .load()[VeilFullFrameTelemetry.LoadCounter.TERRAIN_UPLOAD_BYTES.ordinal()]);
        ReviveMod.LOGGER.info(
                "Veil camera sweep memory: {} {}", NAMES[index], VeilMemoryMonitor.telemetry());

        var connectivity = VeilSectionVisibility.counters().minus(START_CONNECTIVITY[index]);
        ReviveMod.LOGGER.info(
                "Veil camera sweep connectivity: {} own_resolved={} native_resolved={} own_ms={} native_ms={} created={} reused={} nested={} spans={}",
                NAMES[index],
                connectivity.ownResolved(),
                connectivity.nativeResolved(),
                connectivity.ownNs() / 1_000_000.0,
                connectivity.nativeNs() / 1_000_000.0,
                connectivity.created(),
                connectivity.reused(),
                connectivity.nested(),
                connectivity.spans());
        var transparency = VeilTransparencyOrder.counters().minus(START_TRANSPARENCY[index]);
        ReviveMod.LOGGER.info(
                "Veil camera sweep transparency: {} skipped_sorts={} avoided_tasks={} region_builds={} region_worker_ms={}",
                NAMES[index],
                transparency.skipped(),
                transparency.avoidedTasks(),
                transparency.regionBuilds(),
                transparency.regionBuildNs() / 1_000_000.0);
        VeilIndirectTerrain.PlanCounters start = START[index];
        VeilIndirectTerrain.PlanCounters end = VeilIndirectTerrain.planCounters();
        FrameTimeSeries.Summary frame = FRAME[index].summary();
        FrameTimeSeries.Summary render = RENDER[index].summary();
        var jvm = jvmSample();
        var jvmStart = START_JVM[index];
        var lighting = VeilBlockModelRenderer.lightingLeases().minus(START_LIGHTING[index]);
        long totalBytes = availableDelta(jvm.allocatedBytes(), jvmStart.allocatedBytes());
        ReviveMod.LOGGER.info(
                "Veil camera sweep JVM: {} total_bytes={} total_bytes_per_frame={} gc_collections={} gc_time_ms={} lighting_created={} lighting_reused={} lighting_nested={}",
                NAMES[index],
                totalBytes,
                totalBytes < 0 ? -1.0 : (double) totalBytes / Math.max(1, frame.count()),
                availableDelta(jvm.collections(), jvmStart.collections()),
                availableDelta(jvm.collectionMillis(), jvmStart.collectionMillis()),
                lighting.created(),
                lighting.reused(),
                lighting.nested());
        long allocationEnd = allocatedBytes();
        long bytes =
                allocationEnd >= 0 && START_ALLOCATIONS[index] >= 0
                        ? allocationEnd - START_ALLOCATIONS[index]
                        : -1;
        ReviveMod.LOGGER.info(
                "Veil camera sweep allocation: {} render_bytes={} render_bytes_per_frame={}",
                NAMES[index],
                bytes,
                bytes < 0 ? -1.0 : (double) bytes / Math.max(1, frame.count()));
        ReviveMod.LOGGER.info(
                "Veil camera sweep: {} frames={} frame_ms_avg={} frame_ms_p99={} frame_ms_max={} render_cpu_ms_avg={} render_cpu_ms_p99={} mdi_plan_builds={} mdi_topology_changes={} mdi_plan_retired={} mdi_plan_hits={} mdi_build_ms={} mdi_reconcile_ms={}",
                NAMES[index],
                frame.count(),
                frame.average(),
                frame.p99(),
                frame.max(),
                render.average(),
                render.p99(),
                end.builds() - start.builds(),
                end.topologyChanges() - start.topologyChanges(),
                end.retired() - start.retired(),
                end.hits() - start.hits(),
                (end.buildNanos() - start.buildNanos()) / 1_000_000.0,
                (end.reconcileNanos() - start.reconcileNanos()) / 1_000_000.0);
        ReviveMod.LOGGER.info(
                "Veil camera sweep stability: {} frame_ms_p50={} frame_ms_p95={} frames_over_1ms={} frames_within_1ms_percent={}",
                NAMES[index],
                frame.p50(),
                frame.p95(),
                frame.overOneMillisecond(),
                frame.count() == 0
                        ? 0.0
                        : 100.0 * (frame.count() - frame.overOneMillisecond()) / frame.count());
        VeilFullFrameTelemetry.Snapshot cpu =
                VeilFullFrameTelemetry.snapshot().minus(START_CPU[index]);
        ReviveMod.LOGGER.info(
                "Veil camera sweep CPU: {} extract_ms={} prepare_ms={} opaque_submit_ms={} occlusion_ms={} client_frame_ms={} command_submit_ms={} pacing_wait_ms={}",
                NAMES[index],
                cpuMs(cpu, VeilFullFrameTelemetry.CpuZone.WORLD_EXTRACT),
                cpuMs(cpu, VeilFullFrameTelemetry.CpuZone.TERRAIN_PREPARE),
                cpuMs(cpu, VeilFullFrameTelemetry.CpuZone.TERRAIN_OPAQUE_SUBMIT),
                cpuMs(cpu, VeilFullFrameTelemetry.CpuZone.OCCLUSION_GRAPH),
                cpuMs(cpu, VeilFullFrameTelemetry.CpuZone.CLIENT_FRAME),
                cpuMs(cpu, VeilFullFrameTelemetry.CpuZone.COMMAND_SUBMIT),
                cpuMs(cpu, VeilFullFrameTelemetry.CpuZone.COMMAND_SUBMIT_PACING_WAIT));
        VeilTechniqueCounters.Snapshot terrain =
                VeilTechniqueCounters.snapshot().minus(START_TERRAIN[index]);
        ReviveMod.LOGGER.info(
                "Veil camera sweep terrain: {} prepares={} cache_rebuilds={} prepare_ms={} upload_ms={} validate_ms={} rebuild_ms={}",
                NAMES[index],
                terrain.terrainPrepareCalls(),
                terrain.terrainCacheRebuilds(),
                terrain.terrainPrepareNs() / 1_000_000.0,
                terrain.terrainUploadNs() / 1_000_000.0,
                terrain.terrainValidateNs() / 1_000_000.0,
                terrain.terrainRebuildNs() / 1_000_000.0);
        ReviveMod.LOGGER.info(
                "Veil camera sweep plan stages: {} resolve_ms={} order_ms={} batches_ms={} capture_ms={}",
                NAMES[index],
                (end.resolveNanos() - start.resolveNanos()) / 1_000_000.0,
                (end.orderNanos() - start.orderNanos()) / 1_000_000.0,
                (end.batchNanos() - start.batchNanos()) / 1_000_000.0,
                (end.captureNanos() - start.captureNanos()) / 1_000_000.0);
        ReviveMod.LOGGER.info(
                "Veil camera sweep frame cache totals: {} fast_hits={} fast_misses={} section_checks={} revision_hits={} revalidations={} identity_audits={} verified_slices={}",
                NAMES[index],
                VeilTerrainDrawBridge.fastTopologyHits(),
                VeilTerrainDrawBridge.fastTopologyMisses(),
                VeilTerrainDrawBridge.fastSectionChecks(),
                VeilTerrainDrawBridge.revisionFastHits(),
                VeilTerrainDrawBridge.revisionRevalidations(),
                VeilTerrainDrawBridge.periodicIdentityAudits(),
                VeilTerrainDrawBridge.verifiedSlices());
        ReviveMod.LOGGER.info(
                "Veil camera sweep batch stages: {} spatial_ms={} region_ms={} stage_ms={}",
                NAMES[index],
                (end.spatialNanos() - start.spatialNanos()) / 1_000_000.0,
                (end.regionNanos() - start.regionNanos()) / 1_000_000.0,
                (end.stageNanos() - start.stageNanos()) / 1_000_000.0);
        VeilLodArena.SelectionCounters lodStart = START_LOD[index];
        VeilLodArena.SelectionCounters lodEnd = VeilLodArena.selectionCounters();
        ReviveMod.LOGGER.info(
                "Veil camera sweep LOD: {} runs={} skips={} revision_forces={} selection_ms={}",
                NAMES[index],
                lodEnd.runs() - lodStart.runs(),
                lodEnd.skips() - lodStart.skips(),
                lodEnd.revisionForces() - lodStart.revisionForces(),
                (lodEnd.updateNanos() - lodStart.updateNanos()) / 1_000_000.0);
    }

    private static void exportSamples(Minecraft client) {
        java.nio.file.Path output =
                client.gameDirectory
                        .toPath()
                        .resolve("logs")
                        .resolve("camera-sweep-frames-" + java.util.UUID.randomUUID() + ".csv");
        try {
            java.nio.file.Files.createDirectories(output.getParent());
            try (var writer =
                    java.nio.file.Files.newBufferedWriter(
                            output,
                            java.nio.file.StandardOpenOption.CREATE_NEW,
                            java.nio.file.StandardOpenOption.WRITE)) {
                writer.write("phase,series,sample_index,duration_ms\n");
                for (int index = 0; index < NAMES.length; index++) {
                    writeSamples(writer, NAMES[index], "frame_interval", FRAME[index]);
                    writeSamples(writer, NAMES[index], "render_cpu", RENDER[index]);
                }
            }
            VeilFrameJfrAnchor.captureWritten(output);
            ReviveMod.LOGGER.info("Veil camera sweep raw frames: {}", output);
        } catch (java.io.IOException failure) {
            throw new IllegalStateException("Cannot export camera sweep raw frames", failure);
        }
    }

    private static void writeSamples(
            java.io.Writer writer, String phaseName, String seriesName, FrameTimeSeries series)
            throws java.io.IOException {
        double[] samples = series.copySamples();
        for (int index = 0; index < samples.length; index++) {
            writer.write(
                    phaseName
                            + ","
                            + seriesName
                            + ","
                            + index
                            + ","
                            + Double.toString(samples[index])
                            + "\n");
        }
    }

    private static double cpuMs(
            VeilFullFrameTelemetry.Snapshot cpu, VeilFullFrameTelemetry.CpuZone zone) {
        return cpu.cpuNs()[zone.ordinal()] / 1_000_000.0;
    }
}
