package dev.veil.revive.client;

import dev.veil.revive.core.AiCadencePolicy;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.Villager;

import java.util.concurrent.atomic.LongAdder;

public final class VeilAiCadence {
    private static final LongAdder BRAIN_RUNS = new LongAdder();
    private static final LongAdder BRAIN_SKIPS = new LongAdder();
    private static final LongAdder MID_SKIPS = new LongAdder();
    private static final LongAdder FAR_SKIPS = new LongAdder();

    private VeilAiCadence() {}

    public static boolean shouldRunBrain(ServerLevel level, LivingEntity body) {
        if (!(body instanceof Villager)
                || !ReviveRuntime.optimizationsEnabled()
                || !VeilVideoConfig.flag("simulation.aiLod", false)) {
            return true;
        }

        var nearest = level.getNearestPlayer(body, 96.0);
        double nearestDistanceSq =
                nearest == null ? Double.POSITIVE_INFINITY : body.distanceToSqr(nearest);
        int cadence = AiCadencePolicy.cadenceForDistanceSquared(nearestDistanceSq);

        boolean run = AiCadencePolicy.shouldRun(level.getGameTime(), body.getId(), cadence);
        if (VeilDiagnostics.benchmarkActive()) {
            if (run) BRAIN_RUNS.increment();
            else {
                BRAIN_SKIPS.increment();
                if (cadence == 2) MID_SKIPS.increment();
                else FAR_SKIPS.increment();
            }
        }
        return run;
    }

    public static void resetTelemetry() {
        BRAIN_RUNS.reset();
        BRAIN_SKIPS.reset();
        MID_SKIPS.reset();
        FAR_SKIPS.reset();
    }

    public static String telemetry() {
        return "ai_lod_enabled="
                + VeilVideoConfig.flag("simulation.aiLod", false)
                + "\nai_lod_brain_runs="
                + BRAIN_RUNS.sum()
                + "\nai_lod_brain_skips="
                + BRAIN_SKIPS.sum()
                + "\nai_lod_mid_skips="
                + MID_SKIPS.sum()
                + "\nai_lod_far_skips="
                + FAR_SKIPS.sum()
                + "\n";
    }
}
