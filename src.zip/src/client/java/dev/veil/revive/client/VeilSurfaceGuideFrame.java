package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;

import dev.veil.api.VeilSurfaceGuides;

import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

final class VeilSurfaceGuideFrame {
    private final VeilSurfaceGuides.Frame frame;
    private final AtomicBoolean released = new AtomicBoolean();

    VeilSurfaceGuideFrame(
            VeilSurfaceGuides.Context context, java.util.function.Consumer<Runnable> retire) {
        frame = VeilSurfaceGuides.acquire(context);
        try {
            if (frame.token() != context.token())
                throw new IllegalArgumentException("Stale surface guide frame token");
            for (var channel : context.requested()) {
                var view = frame.images().get(channel);
                if (view == null
                        || view.getWidth(0) != context.scene().width
                        || view.getHeight(0) != context.scene().height)
                    throw new IllegalArgumentException(
                            "Surface guide extent/missing channel: " + channel);
                var format = view.texture().getFormat();
                boolean exact =
                        channel == VeilSurfaceGuides.Channel.IDENTITY
                                || channel == VeilSurfaceGuides.Channel.MOTION_DEPTH;
                if (format != GpuFormat.RGBA32_FLOAT && (exact || format != GpuFormat.RGBA16_FLOAT))
                    throw new IllegalArgumentException("Surface guide format: " + channel);
                if (view.texture() == context.scene().getColorTexture()
                        || view.texture() == context.scene().getDepthTexture())
                    throw new IllegalArgumentException(
                            "Surface guides must not alias scene attachments");
            }
        } catch (RuntimeException failure) {
            retire.accept(this::release);
            throw failure;
        }
    }

    VeilHostResourceRegistry.Resolved resolve(String host) {
        for (var channel : VeilSurfaceGuides.Channel.values())
            if (channel.hostId().equals(host)) {
                var view = frame.images().get(channel);
                return VeilHostResourceRegistry.Resolved.image(view.texture(), view);
            }
        throw new IllegalArgumentException("Unknown surface guide " + host);
    }

    void release() {
        if (released.compareAndSet(false, true)) frame.afterGpu().run();
    }

    static boolean isHost(String id) {
        for (var channel : VeilSurfaceGuides.Channel.values())
            if (channel.hostId().equals(id)) return true;
        return false;
    }

    static Set<VeilSurfaceGuides.Channel> requested(VeilShaderPack pack) {
        var result = java.util.EnumSet.noneOf(VeilSurfaceGuides.Channel.class);
        for (var channel : VeilSurfaceGuides.Channel.values())
            if (pack.resources().values().stream()
                    .anyMatch(resource -> channel.hostId().equals(resource.hostId())))
                result.add(channel);
        return Set.copyOf(result);
    }
}
