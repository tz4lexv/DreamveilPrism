package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilLightCoordsCache;

import net.minecraft.core.BlockPos;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.world.level.BlockAndLightGetter;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LightCoordsUtil.class)
public abstract class LightCoordsUtilCacheMixin {
    @Inject(
            method =
                    "getLightCoords(Lnet/minecraft/world/level/BlockAndLightGetter;Lnet/minecraft/core/BlockPos;)I",
            at = @At("HEAD"),
            cancellable = true,
            require = 0)
    private static void veil$reuseLightCoords(
            BlockAndLightGetter level, BlockPos pos, CallbackInfoReturnable<Integer> cir) {
        int cached = VeilLightCoordsCache.lookup(pos.getX(), pos.getY(), pos.getZ());
        if (!VeilLightCoordsCache.isMiss(cached)) {
            cir.setReturnValue(cached);
        }
    }

    @Inject(
            method =
                    "getLightCoords(Lnet/minecraft/world/level/BlockAndLightGetter;Lnet/minecraft/core/BlockPos;)I",
            at = @At("RETURN"),
            require = 0)
    private static void veil$rememberLightCoords(
            BlockAndLightGetter level, BlockPos pos, CallbackInfoReturnable<Integer> cir) {
        VeilLightCoordsCache.store(pos.getX(), pos.getY(), pos.getZ(), cir.getReturnValueI());
    }
}
