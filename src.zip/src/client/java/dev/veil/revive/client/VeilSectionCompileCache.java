package dev.veil.revive.client;

import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.core.SectionPos;

import java.util.function.Supplier;

public final class VeilSectionCompileCache {
    private VeilSectionCompileCache() {}

    public static SectionCompiler.Results compile(
            SectionPos sectionPos,
            RenderSectionRegion region,
            Supplier<SectionCompiler.Results> compile) {
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.SECTION_COMPILE);
        long allocationMarker = dev.veil.revive.client.VeilFullFrameTelemetry.allocationMarker();
        if (ReviveRuntime.optimizationsEnabled()) VeilFaceVisibilityCache.beginSectionCompile();
        VeilLightCoordsCache.beginSectionCompile(sectionPos);
        VeilAnimatedSpriteUsage.beginSectionCompile();
        dev.veil.revive.client.VeilFluidMaterialCapture.beginSectionCompile();
        dev.veil.revive.client.VeilFluidGeometryCapture.beginSectionCompile(sectionPos);
        VeilOriginalQuadCapture.begin(sectionPos);
        SectionCompiler.Results results = null;
        boolean originalScopeEnded = false;
        boolean snapshotStarted = false;
        boolean worldLightStarted = false;
        var kernel = ReviveRuntime.veilKernel();
        try (var update = kernel == null ? null : kernel.lightUpdates().begin(sectionPos.asLong());
                var originalWork =
                        VeilOriginalAttributeWork.open(
                                sectionPos.asLong(),
                                update == null
                                        ? dev.veil.revive.core.LightOnlyUpdateTracker.Update.NONE
                                        : update.requestedUpdate())) {
            try {
                worldLightStarted = VeilWorldLightSampler.begin(sectionPos, region);
                snapshotStarted =
                        dev.veil.revive.client.VeilSectionStateSnapshot.begin(sectionPos, region);
                results = compile.get();
            } finally {
                if (worldLightStarted) VeilWorldLightSampler.end();
                if (snapshotStarted) dev.veil.revive.client.VeilSectionStateSnapshot.end();
                VeilFaceVisibilityCache.endSectionCompile();
                VeilLightCoordsCache.endSectionCompile();
                var sprites = VeilAnimatedSpriteUsage.endSectionCompile();
                var materialRanges =
                        dev.veil.revive.client.VeilFluidMaterialCapture.endSectionCompile(results);
                var fluidGeometry =
                        dev.veil.revive.client.VeilFluidGeometryCapture.endSectionCompile();
                if (results != null) {
                    VeilSectionCompileExtras extras = (VeilSectionCompileExtras) (Object) results;
                    extras.veil$setAnimatedSprites(sprites);
                    extras.veil$setMaterialRanges(materialRanges);
                    extras.veil$setFluidGeometry(fluidGeometry);
                }
                dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                        dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.SECTION_COMPILE);
                dev.veil.revive.client.VeilFullFrameTelemetry.sectionCompileFinished(
                        allocationMarker);
            }
            originalScopeEnded = true;
            var originals = VeilOriginalQuadCapture.end(results != null);
            if (results != null)
                ((VeilSectionCompileExtras) (Object) results).veil$setOriginalQuads(originals);
            originalWork.validate();
            if (results != null && update != null) {
                var reason = update.complete();
                if (originalWork.reused() > 0
                        && reason
                                != dev.veil.revive.core.LightOnlyUpdateTracker.Update
                                        .ATTRIBUTES_ONLY)
                    throw new VeilOriginalAttributeWork.Unstable();
                ((VeilSectionCompileExtras) (Object) results)
                        .veil$setLightOnlyUpdate(
                                reason
                                        == dev.veil.revive.core.LightOnlyUpdateTracker.Update
                                                .ATTRIBUTES_ONLY);
                ((VeilSectionCompileExtras) (Object) results)
                        .veil$setReusedModels(originalWork.reused());
            }
            return results;
        } catch (RuntimeException | Error failure) {
            if (results != null)
                try {
                    results.release();
                } catch (RuntimeException | Error cleanup) {
                    failure.addSuppressed(cleanup);
                }
            throw failure;
        } finally {
            if (!originalScopeEnded) VeilOriginalQuadCapture.end(false);
        }
    }
}
