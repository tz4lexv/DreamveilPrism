package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;

import org.joml.Matrix4f;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

final class VeilVolumeSupportGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.volumeSupportProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final List<String> RESULTS = new ArrayList<>();
    private static int stage, frames;
    private static boolean initialized, pending, complete, ready;
    private static long started;
    private static long stageStarted;
    private static boolean historyBefore;
    private static VeilShaderPackRuntime oldRuntime;

    private VeilVolumeSupportGpuProbe() {}

    static boolean enabled() {
        return ENABLED;
    }

    static void adjustProjection(Matrix4f projection) {
        if (!ENABLED || stage != 4) return;
        projection.translate(.03f, -.02f, 0).rotateZ(.015f);
        projection.m20(projection.m20() + ((frames & 1) == 0 ? .001f : -.001f));
    }

    static void timeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 240_000_000_000L)
            fail(new IllegalStateException("Volume support timeout/runtime failure"));
    }

    static void before(VeilShaderPackRuntime active) {
        if (!ENABLED || complete || pending || !VeilBenchmarkWorld.terrainReady()) return;
        try {
            var client = Minecraft.getInstance();
            ready = false;
            if (!initialized) {
                initialized = true;
                frames = 0;
                stageStarted = System.nanoTime();
                if (stage == 0) active.invalidateHistory();
                if (stage == 2) client.player.setYRot(client.player.getYRot() + 5f);
                if (stage == 3) client.player.setPos(client.player.position().add(.25, 0, .125));
                if (stage == 5) client.getWindow().setWindowed(800, 450);
                if (stage == 7) {
                    oldRuntime = active;
                    VeilShaderService.requestReload();
                }
                if (stage == 8 || stage == 9) {
                    var server = client.getSingleplayerServer();
                    var dimension = stage == 8 ? Level.NETHER : Level.OVERWORLD;
                    var uuid = client.player.getUUID();
                    server.execute(
                            () -> {
                                var player = server.getPlayerList().getPlayer(uuid);
                                player.teleportTo(
                                        server.getLevel(dimension),
                                        8,
                                        100,
                                        8,
                                        Set.of(),
                                        0f,
                                        0f,
                                        true);
                            });
                }
            }
            if (stage == 5
                    && (client.gameRenderer.mainRenderTarget().width != 800
                            || client.gameRenderer.mainRenderTarget().height != 450)) return;
            if (stage == 7 && active == oldRuntime) return;
            if (stage == 8 && !client.level.dimension().equals(Level.NETHER)) return;
            if (stage == 9 && !client.level.dimension().equals(Level.OVERWORLD)) return;
            ready = true;
            historyBefore = active.historyValid();
            frames++;
        } catch (RuntimeException failure) {
            fail(failure);
        }
    }

    static void after(VeilShaderPackRuntime active) {
        if (!ENABLED || complete || pending || !ready) return;
        boolean reset = stage == 0 || stage == 5 || stage == 7 || stage == 8 || stage == 9;
        if (!reset
                && (frames < 12
                        || !historyBefore
                        || System.nanoTime() - stageStarted < 1_000_000_000L)) return;
        pending = true;
        int capturedStage = stage;
        byte[][] results = new byte[2][];
        for (int index = 0; index < 2; index++) {
            int slot = index;
            int size = slot == 0 ? 256 : 32;
            var readback =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil volume support readback",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    size);
            try {
                active.readOutput(
                        slot == 0 ? "diagnostics" : "slangProof",
                        readback,
                        () -> {
                            try (var mapped = readback.map(true, false)) {
                                results[slot] = new byte[size];
                                mapped.data().get(results[slot]);
                                if (results[0] != null && results[1] != null) {
                                    verify(
                                            ByteBuffer.wrap(results[0])
                                                    .order(ByteOrder.nativeOrder()),
                                            reset,
                                            capturedStage);
                                    var proof =
                                            ByteBuffer.wrap(results[1])
                                                    .order(ByteOrder.nativeOrder());
                                    close(proof.getFloat(0), 0, "Slang effective transform");
                                    close(proof.getFloat(4), 0, "Slang wind reprojection");
                                    close(proof.getFloat(8), 1, "Slang validity");
                                    close(proof.getFloat(12), 1, "Slang output");
                                    var glsl =
                                            ByteBuffer.wrap(results[0])
                                                    .order(ByteOrder.nativeOrder());
                                    for (int channel = 0; channel < 3; channel++)
                                        close(
                                                proof.getFloat(16 + channel * 4),
                                                value(glsl, 13, channel),
                                                "Slang/GLSL matrix layout agreement");
                                    if (stage == 10) {
                                        var directory =
                                                VeilPlatform.get().getGameDir().resolve("logs");
                                        Files.createDirectories(directory);
                                        Files.write(
                                                directory.resolve("volume-support-probe.txt"),
                                                RESULTS);
                                        ReviveMod.LOGGER.info(
                                                "Veil volume support GPU: PASS stages={} nonuniform_3d=true mips=true temporal=true slang=true resize=true reload=true dimensions=true",
                                                RESULTS.size());
                                        complete = true;
                                        Minecraft.getInstance().stop();
                                    } else {
                                        stage++;
                                        initialized = false;
                                        ready = false;
                                    }
                                    pending = false;
                                }
                            } catch (Exception failure) {
                                fail(failure);
                            } finally {
                                readback.close();
                            }
                        });
            } catch (RuntimeException failure) {
                readback.close();
                fail(failure);
            }
        }
    }

    private static float value(ByteBuffer bytes, int pixel, int channel) {
        return bytes.getFloat(pixel * 16 + channel * 4);
    }

    private static void close(float actual, float expected, String message) {
        if (!Float.isFinite(actual) || Math.abs(actual - expected) > .0003f)
            throw new IllegalStateException(message + ": " + actual + " != " + expected);
    }

    private static void verify(ByteBuffer bytes, boolean reset, int capturedStage) {
        float[][] expected = {
            {.125f, .375f, .625f, 1},
            {.25f, .5f, .75f, 1},
            {.25f, .25f, .25f, 1},
            {.5f, .5f, .5f, 1},
            {.125f, .875f, .5f, 1},
            {.5f, .5f, .5f, 1},
            {.25f, .25f, .25f, 1}
        };
        for (int pixel = 0; pixel < expected.length; pixel++)
            for (int channel = 0; channel < 4; channel++)
                close(
                        value(bytes, pixel, channel),
                        expected[pixel][channel],
                        "3D sample " + pixel + "/" + channel);
        if (reset) {
            close(value(bytes, 7, 0), 1, "history starts fresh");
            close(value(bytes, 7, 1), 0, "image history invalid");
            close(value(bytes, 7, 2), 0, "transform history invalid");
        } else {
            if (value(bytes, 7, 0) < 2)
                throw new IllegalStateException("History did not accumulate");
            close(value(bytes, 7, 1), 1, "image history valid");
            close(value(bytes, 7, 2), 1, "transform history valid");
        }
        for (int pixel = 8; pixel <= 10; pixel++) {
            for (int channel = 0; channel < 3; channel++)
                close(value(bytes, pixel, channel), 0, "temporal error");
            close(value(bytes, pixel, 3), 1, "temporal validity");
        }
        for (int pixel : new int[] {11, 14, 15})
            close(value(bytes, pixel, 0), 1, "temporal rejection");
        close(value(bytes, 12, 0), 0, "actual depth producer transform");
        var target = Minecraft.getInstance().gameRenderer.mainRenderTarget();
        close(value(bytes, 12, 1), target.width, "viewport width");
        close(value(bytes, 12, 2), target.height, "viewport height");
        close(value(bytes, 13, 3), 1, "reconstructed point");
        String result =
                "stage="
                        + capturedStage
                        + " reset="
                        + reset
                        + " counter="
                        + value(bytes, 7, 0)
                        + " viewport="
                        + target.width
                        + "x"
                        + target.height
                        + " samples=7 temporal=6 PASS";
        RESULTS.add(result);
        ReviveMod.LOGGER.info("Veil volume support GPU stage: {}", result);
    }

    private static void fail(Throwable failure) {
        complete = true;
        ReviveMod.LOGGER.error("Veil volume support GPU: FAIL stage=" + stage, failure);
        Minecraft.getInstance().stop();
    }
}
