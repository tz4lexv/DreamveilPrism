package dev.veil.api;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.textures.GpuTextureView;

import org.joml.Matrix4f;

import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

public final class VeilSurfaceGuides {
    public enum Channel {
        NORMAL_ROUGHNESS,
        ALBEDO_METALLIC,
        EMISSION_TRANSMISSION,
        ABSORPTION_IOR,
        EXTRAS,
        MOTION_DEPTH,
        IDENTITY;

        public String hostId() {
            return "minecraft:surface_" + name().toLowerCase(java.util.Locale.ROOT);
        }
    }

    public static final int NORMAL_VALID = 1, MATERIAL_VALID = 2, MOTION_VALID = 4, REACTIVE = 8;

    public record Context(
            Object token,
            Object world,
            long frame,
            RenderTarget scene,
            Matrix4f clip,
            Matrix4f previousClip,
            double x,
            double y,
            double z,
            double previousX,
            double previousY,
            double previousZ,
            boolean historyValid,
            Set<Channel> requested) {
        public Context {
            Objects.requireNonNull(token);
            Objects.requireNonNull(world);
            Objects.requireNonNull(scene);
            clip = new Matrix4f(clip);
            previousClip = new Matrix4f(previousClip);
            requested = Set.copyOf(requested);
        }
    }

    public record Frame(Object token, Map<Channel, GpuTextureView> images, Runnable afterGpu) {
        public Frame {
            Objects.requireNonNull(token);
            images = Map.copyOf(images);
            Objects.requireNonNull(afterGpu);
        }
    }

    @FunctionalInterface
    public interface Provider {
        Frame acquire(Context context);
    }

    public interface Registration extends AutoCloseable {
        @Override
        void close();
    }

    private record Slot(Provider provider) {}

    private static final AtomicReference<Slot> CURRENT = new AtomicReference<>();

    private VeilSurfaceGuides() {}

    public static Registration register(Provider provider) {
        Objects.requireNonNull(provider);
        Slot slot = new Slot(provider);
        if (!CURRENT.compareAndSet(null, slot))
            throw new IllegalStateException("Surface guide provider already registered");
        return () -> CURRENT.compareAndSet(slot, null);
    }

    public static boolean available() {
        return CURRENT.get() != null;
    }

    public static Frame acquire(Context context) {
        Slot slot = CURRENT.get();
        if (slot == null)
            throw new IllegalStateException(
                    "Surface guides requested without a registered renderer provider");
        Frame frame =
                Objects.requireNonNull(slot.provider().acquire(context), "Surface guide frame");
        return frame;
    }
}
