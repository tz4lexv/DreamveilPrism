package dev.veil.revive.client.graphics.minecraft;

import dev.veil.api.graphics.GraphicsCapabilitySource;
import dev.veil.api.graphics.RasterFeature;
import dev.veil.revive.client.VeilHostResourceRegistry;
import dev.veil.revive.client.VeilRayCapabilities;

import java.util.Set;

public final class MinecraftGraphicsCapabilities implements GraphicsCapabilitySource {
    public MinecraftGraphicsCapabilities() {}

    @Override
    public boolean accelerationStructures() {
        return VeilRayCapabilities.accelerationStructures();
    }

    @Override
    public boolean rayQuery() {
        return VeilRayCapabilities.rayQuery();
    }

    @Override
    public boolean rayPipeline() {
        return VeilRayCapabilities.rayPipeline();
    }

    @Override
    public Set<String> hostResources() {
        return Set.copyOf(VeilHostResourceRegistry.definitions().keySet());
    }

    @Override
    public boolean shaderInt64() {
        return dev.veil.revive.client.VeilVulkanCapabilities.shaderInt64();
    }

    @Override
    public boolean shaderBufferInt64Atomics() {
        return dev.veil.revive.client.VeilVulkanCapabilities.shaderBufferInt64Atomics();
    }

    @Override
    public boolean shaderSharedInt64Atomics() {
        return dev.veil.revive.client.VeilVulkanCapabilities.shaderSharedInt64Atomics();
    }

    @Override
    public Set<String> enabledDeviceFeatures() {
        var device = MinecraftVulkanContext.currentDeviceOrNull();
        return EnabledDeviceFeatures.publicNames(device == null ? null : device.vkDevice());
    }

    @Override
    public Set<RasterFeature> rasterFeatures() {
        var device = MinecraftVulkanContext.currentDeviceOrNull();
        return EnabledRasterFeatures.publicFeatures(device == null ? null : device.vkDevice());
    }
}
