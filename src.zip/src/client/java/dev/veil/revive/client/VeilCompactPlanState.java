package dev.veil.revive.client;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;

import java.util.List;

final class VeilCompactPlanState {
    private final Binding[] bindings;

    private VeilCompactPlanState(int size) {
        bindings = new Binding[size];
    }

    static VeilCompactPlanState captureSource(VeilIndirectTerrain.SourceState source) {
        var state = new VeilCompactPlanState(source.meshes.length);
        for (int i = 0; i < source.meshes.length; i++) {
            var mesh = source.meshes[i];
            var parametric = VeilParametricTerrainArena.peek(mesh, source.layer);
            var paired = parametric == null ? VeilPairedTerrainArena.get(mesh, source.layer) : null;
            var regular =
                    parametric == null && paired == null
                            ? VeilRegularPackedTerrain.get(mesh, source.layer)
                            : null;
            state.bindings[i] = Binding.capture(parametric, paired, regular);
        }
        return state;
    }

    boolean matches(List<RenderPass.Draw<GpuBufferSlice[]>> source) {
        if (source.size() != bindings.length) return false;
        for (int i = 0; i < source.size(); i++) {
            var uploader = owner(source.get(i));
            if (!matches(bindings[i], uploader.mesh(), uploader.layer())) return false;
        }
        return true;
    }

    private static boolean matches(Binding binding, SectionMesh mesh, ChunkSectionLayer layer) {
        var parametric = VeilParametricTerrainArena.peek(mesh, layer);
        if (parametric != null) return binding.matches(parametric, null, null);
        var paired = VeilPairedTerrainArena.get(mesh, layer);
        if (paired != null) return binding.matches(null, paired, null);
        return binding.matches(null, null, VeilRegularPackedTerrain.get(mesh, layer));
    }

    private static VeilSectionUniformUploader owner(RenderPass.Draw<GpuBufferSlice[]> draw) {
        if (draw.uniformUploaderConsumer() instanceof VeilSectionUniformUploader uploader)
            return uploader;
        throw new IllegalStateException("Unknown terrain uniform owner");
    }

    record Binding(
            int route,
            GpuBuffer vertices,
            GpuBuffer indices,
            IndexType indexType,
            int baseVertex,
            int firstIndex,
            int indexCount) {
        private static final Binding NATIVE = new Binding(0, null, null, null, 0, 0, 0);

        static Binding capture(
                VeilParametricTerrainArena.Slice parametric,
                VeilPairedTerrainArena.Slice paired,
                VeilRegularPackedTerrain.Slice regular) {
            if (parametric != null)
                return new Binding(
                        3,
                        parametric.buffer(),
                        null,
                        null,
                        parametric.baseVertex(),
                        0,
                        parametric.indexCount());
            if (paired != null)
                return new Binding(
                        2,
                        paired.vertices(),
                        paired.indices(),
                        paired.indexType(),
                        paired.baseVertex(),
                        paired.firstIndex(),
                        paired.indexCount());
            if (regular != null)
                return new Binding(1, regular.buffer(), null, null, regular.baseVertex(), 0, 0);
            return NATIVE;
        }

        boolean matches(
                VeilParametricTerrainArena.Slice parametric,
                VeilPairedTerrainArena.Slice paired,
                VeilRegularPackedTerrain.Slice regular) {
            if (parametric != null)
                return route == 3
                        && vertices == parametric.buffer()
                        && baseVertex == parametric.baseVertex()
                        && indexCount == parametric.indexCount();
            if (paired != null)
                return route == 2
                        && vertices == paired.vertices()
                        && indices == paired.indices()
                        && indexType == paired.indexType()
                        && baseVertex == paired.baseVertex()
                        && firstIndex == paired.firstIndex()
                        && indexCount == paired.indexCount();
            if (regular != null)
                return route == 1
                        && vertices == regular.buffer()
                        && baseVertex == regular.baseVertex();
            return route == 0;
        }
    }
}
