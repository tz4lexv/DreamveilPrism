package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilRebuildBudget;
import dev.veil.revive.client.VeilRebuildCoalescer;
import dev.veil.revive.client.VeilVideoConfig;
import dev.veil.revive.client.terrain.QueuedSectionTaskOrigin;
import dev.veil.revive.core.FirstLoadQueueProgress;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.chunk.SectionTaskDynamicQueue;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.phys.Vec3;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.ListIterator;

@Mixin(SectionTaskDynamicQueue.class)
public abstract class SectionTaskQueueCoalescingMixin {
    @Shadow @Final private List<SectionRenderDispatcher.RenderSection.SectionTask> tasks;

    @Unique
    private static final ThreadLocal<Boolean> veil$budgetRequeue =
            ThreadLocal.withInitial(() -> Boolean.FALSE);

    @Unique
    private static final ThreadLocal<Boolean> veil$rawPoll =
            ThreadLocal.withInitial(() -> Boolean.FALSE);

    @Unique
    private Long2ObjectOpenHashMap<SectionRenderDispatcher.RenderSection.SectionTask>
            veil$latestCompile;

    @Unique
    private Long2ObjectOpenHashMap<SectionRenderDispatcher.RenderSection.SectionTask>
            veil$latestResort;

    @Inject(method = "clear", at = @At("HEAD"), require = 0)
    private void veil$clearLatestTaskIndexes(CallbackInfo ci) {
        veil$clearIndexes();
    }

    @Unique
    private void veil$clearIndexes() {
        if (veil$latestCompile != null) veil$latestCompile.clear();
        if (veil$latestResort != null) veil$latestResort.clear();
    }

    @Inject(method = "add", at = @At("HEAD"), require = 1)
    private void veil$cancelOlderTask(
            SectionRenderDispatcher.RenderSection.SectionTask task, CallbackInfo ci) {
        if (!ReviveRuntime.optimizationsEnabled()
                || !VeilVideoConfig.on("renderer.rebuildCoalescing")) {
            veil$clearIndexes();
            return;
        }
        if (veil$budgetRequeue.get()) return;

        boolean newCompile = veil$isCompileTask(task);
        boolean newResort = veil$isResortTask(task);
        long key = veil$sectionKey(task.getRenderOrigin());

        if (newCompile) {

            if (!((SectionTaskAccessor) (Object) task).veil$isRecompile()) {
                return;
            }
            ((QueuedSectionTaskOrigin) (Object) task).veil$setQueueIndexKey(key);
            veil$cancelIfOlder(veil$compileMap().put(key, task), task);

            veil$cancelIfOlder(veil$resortMap().remove(key), task);
            return;
        }
        if (newResort) {
            ((QueuedSectionTaskOrigin) (Object) task).veil$setQueueIndexKey(key);
            veil$cancelIfOlder(veil$resortMap().put(key, task), task);
            return;
        }

        Class<?> newType = task.getClass();
        var origin = task.getRenderOrigin();
        for (int i = tasks.size() - 1; i >= 0; --i) {
            var old = tasks.get(i);
            if (old == task || old.getClass() != newType || !old.getRenderOrigin().equals(origin))
                continue;
            veil$cancelIfOlder(old, task);
        }
    }

    @WrapOperation(
            method = "poll",
            at = @At(value = "INVOKE", target = "Ljava/util/ListIterator;remove()V"),
            require = 1)
    private void veil$releaseRemovedTask(
            ListIterator<?> iterator,
            Operation<Void> original,
            @Local SectionRenderDispatcher.RenderSection.SectionTask task) {
        original.call(iterator);
        veil$untrackIfSame(task);
    }

    @Inject(method = "poll", at = @At("RETURN"), cancellable = true, require = 0)
    private void veil$filterPoll(
            Vec3 cameraPos,
            CallbackInfoReturnable<SectionRenderDispatcher.RenderSection.SectionTask> cir) {
        if (veil$rawPoll.get()) return;
        if (!ReviveRuntime.optimizationsEnabled()) {
            veil$clearIndexes();
            return;
        }
        if (!VeilVideoConfig.on("renderer.rebuildCoalescing")) veil$clearIndexes();
        var task = cir.getReturnValue();
        if (task == null) return;

        if (VeilVideoConfig.on("renderer.rebuildCoalescing")) {
            var self = (SectionTaskDynamicQueue) (Object) this;
            while (task != null && ((SectionTaskAccessor) (Object) task).veil$isCancelled().get()) {
                veil$untrackIfSame(task);
                VeilRebuildCoalescer.recordStalePollSkipped();
                veil$rawPoll.set(Boolean.TRUE);
                try {
                    task = self.poll(cameraPos);
                } finally {
                    veil$rawPoll.set(Boolean.FALSE);
                }
            }
            cir.setReturnValue(task);
            if (task == null) return;
        }

        if (VeilVideoConfig.on("renderer.rebuildBudget")
                && !VeilRebuildBudget.tryAdmit(task, cameraPos)) {

            veil$budgetRequeue.set(Boolean.TRUE);
            try {
                ((SectionTaskDynamicQueue) (Object) this).add(task);
            } finally {
                veil$budgetRequeue.set(Boolean.FALSE);
            }
            VeilRebuildCoalescer.recordBudgetDeferred();
            var self = (SectionTaskDynamicQueue) (Object) this;
            veil$rawPoll.set(Boolean.TRUE);
            veil$budgetRequeue.set(Boolean.TRUE);
            try {
                task =
                        FirstLoadQueueProgress.poll(
                                () -> self.poll(cameraPos),
                                self::add,
                                SectionRenderDispatcher.RenderSection.SectionTask::isRecompile);
            } finally {
                veil$budgetRequeue.set(Boolean.FALSE);
                veil$rawPoll.set(Boolean.FALSE);
            }
            cir.setReturnValue(task);
            if (task == null) return;
            VeilRebuildBudget.tryAdmit(task, cameraPos);
            VeilRebuildCoalescer.recordFirstLoadUnblocked();
        }

        if (VeilVideoConfig.on("renderer.rebuildCoalescing")) veil$untrackIfSame(task);
    }

    @Unique
    private Long2ObjectOpenHashMap<SectionRenderDispatcher.RenderSection.SectionTask>
            veil$compileMap() {
        if (veil$latestCompile == null) veil$latestCompile = new Long2ObjectOpenHashMap<>();
        return veil$latestCompile;
    }

    @Unique
    private Long2ObjectOpenHashMap<SectionRenderDispatcher.RenderSection.SectionTask>
            veil$resortMap() {
        if (veil$latestResort == null) veil$latestResort = new Long2ObjectOpenHashMap<>();
        return veil$latestResort;
    }

    @Unique
    private void veil$cancelIfOlder(
            SectionRenderDispatcher.RenderSection.SectionTask old,
            SectionRenderDispatcher.RenderSection.SectionTask replacement) {
        if (old == null
                || old == replacement
                || ((SectionTaskAccessor) (Object) old).veil$isCancelled().get()) return;
        old.cancel();
        VeilRebuildCoalescer.recordCancelled();
    }

    @Unique
    private void veil$untrackIfSame(SectionRenderDispatcher.RenderSection.SectionTask task) {
        long key = ((QueuedSectionTaskOrigin) (Object) task).veil$getQueueIndexKey();
        if (veil$isCompileTask(task)
                && veil$latestCompile != null
                && veil$latestCompile.get(key) == task) {
            veil$latestCompile.remove(key);
        }
        if (veil$isResortTask(task)
                && veil$latestResort != null
                && veil$latestResort.get(key) == task) {
            veil$latestResort.remove(key);
        }
    }

    @Unique
    private static long veil$sectionKey(BlockPos origin) {
        return SectionPos.asLong(origin.getX() >> 4, origin.getY() >> 4, origin.getZ() >> 4);
    }

    @Unique
    private static boolean veil$isCompileTask(
            SectionRenderDispatcher.RenderSection.SectionTask task) {
        return task.getClass().getName().endsWith("$CompileTask");
    }

    @Unique
    private static boolean veil$isResortTask(
            SectionRenderDispatcher.RenderSection.SectionTask task) {
        return task.getClass().getName().endsWith("$ResortTransparencyTask");
    }
}
