package dev.veil.revive.client;

final class VeilPbrPixels {
    private VeilPbrPixels() {}

    static int interpolate(int a, int b, float blend, boolean specular) {
        return dev.veil.revive.client.scene.materials.PbrPixels.interpolate(a, b, blend, specular);
    }
}
