package dev.veil.revive.client;

import net.minecraft.client.Minecraft;

public final class ReviveClient {
    private ReviveClient() {}

    public static void initialize() {
        VeilVideoConfig.load();
        ReviveRuntime.initialize();
        VeilIndirectTerrain.initializePipelines();
        VeilHzb.initializePipelines();
    }

    public static void tick(Minecraft client) {
        VeilControls.handleTick(client);
        VeilDiagnostics.onClientTick(client);
        ReviveRuntime.onClientTick();
        VeilDevelopmentProbe.tick(client);
        VeilVideoProbe.tick(client);
    }

    public static void close() {
        VeilAsyncTerrainSelection.invalidate();
        VeilAsyncEntityOcclusion.close();
        VeilHzb.close();
        VeilIndirectTerrain.close();
        VeilLodArena.close();
        ReviveRuntime.close();
    }
}
