package dev.veil.revive.client.graphics.minecraft;

import com.mojang.blaze3d.vulkan.VulkanBackend;
import com.mojang.blaze3d.vulkan.init.VulkanFeature;

import dev.veil.api.graphics.RasterFeature;

import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkPhysicalDeviceFeatures;
import org.lwjgl.vulkan.VkPhysicalDeviceFeatures2;

import java.lang.ref.WeakReference;
import java.util.EnumSet;
import java.util.Set;

public final class EnabledRasterFeatures {
    public enum Feature {
        GEOMETRY("geometryShader", VkPhysicalDeviceFeatures.GEOMETRYSHADER),
        TESSELLATION("tessellationShader", VkPhysicalDeviceFeatures.TESSELLATIONSHADER),
        NON_SOLID("fillModeNonSolid", VkPhysicalDeviceFeatures.FILLMODENONSOLID),
        DEPTH_CLAMP("depthClamp", VkPhysicalDeviceFeatures.DEPTHCLAMP),
        BIAS_CLAMP("depthBiasClamp", VkPhysicalDeviceFeatures.DEPTHBIASCLAMP),
        WIDE_LINES("wideLines", VkPhysicalDeviceFeatures.WIDELINES),
        IMAGE_CUBE_ARRAY("imageCubeArray", VkPhysicalDeviceFeatures.IMAGECUBEARRAY);

        private final VulkanFeature declaration;

        Feature(String name, long offset) {
            declaration = new VulkanFeature(VulkanBackend.VK10_FEATURES_STRUCT, name, offset);
        }
    }

    private record Snapshot(
            WeakReference<VkDevice> device,
            Set<Feature> features,
            Set<RasterFeature> publicFeatures) {}

    private static volatile Snapshot snapshot;

    private EnabledRasterFeatures() {}

    public static void requestSupported(
            VkPhysicalDeviceFeatures2 supported, Set<VulkanFeature> requested) {
        for (Feature feature : Feature.values()) {
            if (feature.declaration.get(supported)) requested.add(feature.declaration);
        }
    }

    public static Set<Feature> selected(Set<VulkanFeature> requested) {
        var selected = EnumSet.noneOf(Feature.class);
        for (Feature feature : Feature.values()) {
            if (requested.contains(feature.declaration)) selected.add(feature);
        }
        return Set.copyOf(selected);
    }

    public static void record(VkDevice device, Set<VulkanFeature> enabled) {
        EnabledDeviceFeatures.record(device, enabled);
        var selected = selected(enabled);
        snapshot = new Snapshot(new WeakReference<>(device), selected, publicSelection(selected));
        org.slf4j.LoggerFactory.getLogger("Veil")
                .info("Veil enabled raster features: {}", snapshot.features());
    }

    public static Set<RasterFeature> publicSelection(Set<Feature> selected) {
        var result = EnumSet.noneOf(RasterFeature.class);
        for (Feature feature : selected) result.add(RasterFeature.valueOf(feature.name()));
        return Set.copyOf(result);
    }

    public static Set<RasterFeature> publicFeatures(VkDevice device) {
        Snapshot current = snapshot;
        return device != null && current != null && current.device().get() == device
                ? current.publicFeatures()
                : Set.of();
    }

    public static boolean enabled(VkDevice device, Feature feature) {
        Snapshot current = snapshot;
        return device != null
                && current != null
                && current.device().get() == device
                && current.features().contains(feature);
    }

    public static boolean enabledOnCurrentDevice(Feature feature) {
        var device = MinecraftVulkanContext.currentDeviceOrNull();
        return device != null && enabled(device.vkDevice(), feature);
    }
}
