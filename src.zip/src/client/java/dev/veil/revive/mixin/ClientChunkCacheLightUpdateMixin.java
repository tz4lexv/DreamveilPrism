package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import dev.veil.revive.client.VeilLightingPipeline;

import net.minecraft.client.multiplayer.ClientChunkCache;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.LightLayer;

import org.spongepowered.asm.mixin.Mixin;

@Mixin(ClientChunkCache.class)
public abstract class ClientChunkCacheLightUpdateMixin {
    @WrapMethod(method = "onLightUpdate", require = 1)
    private void veil$lightSectionUpdate(
            LightLayer layer, SectionPos pos, Operation<Void> original) {
        VeilLightingPipeline.beginLightSectionUpdate(pos.asLong());
        try {
            original.call(layer, pos);
        } finally {
            VeilLightingPipeline.endLightSectionUpdate();
        }
    }
}
