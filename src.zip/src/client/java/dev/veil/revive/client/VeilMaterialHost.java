package dev.veil.revive.client;

import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.revive.client.scene.materials.MaterialSceneInputs;

import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;

import org.joml.Matrix4fc;

public final class VeilMaterialHost {
    private static final MaterialSceneInputs INPUTS =
            new MaterialSceneInputs(
                    VeilShaderService::opaqueSceneInputsRequested,
                    VeilShaderService::materialInputsRequested,
                    VeilMaterialHost::materialRanges);

    private VeilMaterialHost() {}

    private static VeilMaterialRange[] materialRanges(
            net.minecraft.client.renderer.chunk.SectionMesh mesh) {
        if (!(mesh instanceof VeilMeshExtras extras)) return null;
        var metadata = extras.veil$metadata();
        return metadata == null ? null : metadata.materialRanges();
    }

    public static void beginFrame() {
        INPUTS.beginFrame();
    }

    public static void captureModelView(Matrix4fc matrix) {
        INPUTS.captureModelView(matrix);
    }

    public static void beforeTerrainGroup(ChunkSectionLayerGroup group) {
        INPUTS.beforeTerrainGroup(group);
    }

    public static void prepareForShaderGraph() {
        INPUTS.prepareForShaderGraph();
    }

    public static boolean readyOpaque() {
        return INPUTS.readyOpaque();
    }

    public static boolean readyMaterials() {
        return INPUTS.readyMaterials();
    }

    public static GpuTexture opaqueColorTexture() {
        return INPUTS.opaqueColorTexture();
    }

    public static GpuTextureView opaqueColorView() {
        return INPUTS.opaqueColorView();
    }

    public static GpuTexture opaqueDepthTexture() {
        return INPUTS.opaqueDepthTexture();
    }

    public static GpuTextureView opaqueDepthView() {
        return INPUTS.opaqueDepthView();
    }

    public static GpuTexture materialIdTexture() {
        return INPUTS.materialIdTexture();
    }

    public static GpuTextureView materialIdView() {
        return INPUTS.materialIdView();
    }

    public static GpuTexture materialDepthTexture() {
        return INPUTS.materialDepthTexture();
    }

    public static GpuTextureView materialDepthView() {
        return INPUTS.materialDepthView();
    }

    public static String telemetry() {
        return INPUTS.telemetry();
    }

    public static void close() {
        INPUTS.close();
    }
}
