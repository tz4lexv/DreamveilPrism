package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.Minecraft;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftTickFullTelemetryMixin {
    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void veil$clientTickStart(CallbackInfo ci) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.CLIENT_TICK);
    }

    @Inject(method = "tick", at = @At("RETURN"), require = 0)
    private void veil$clientTickEnd(CallbackInfo ci) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.CLIENT_TICK);
    }
}
