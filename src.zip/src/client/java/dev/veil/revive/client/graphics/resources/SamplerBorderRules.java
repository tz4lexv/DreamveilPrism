package dev.veil.revive.client.graphics.resources;

import dev.veil.api.VeilFormat;

/** Type validation for a sampler border that can actually be read outside an image. */
public final class SamplerBorderRules {
    private SamplerBorderRules() {}

    public static void validate(VeilFormat format, boolean usesBorder, boolean integerBorder) {
        if (!usesBorder) return;
        boolean integerImage =
                format.numericType() == VeilFormat.NumericType.SINT
                        || format.numericType() == VeilFormat.NumericType.UINT
                        || format.numericType() == VeilFormat.NumericType.STENCIL;
        if (integerImage != integerBorder) {
            throw new IllegalArgumentException(
                    "Sampler border color type must match image format "
                            + format
                            + ": expected "
                            + (integerImage ? "int" : "float")
                            + " borderColor");
        }
    }
}
