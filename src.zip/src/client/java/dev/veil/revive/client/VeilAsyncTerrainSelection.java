package dev.veil.revive.client;

import dev.veil.revive.client.terrain.visibility.AsyncTerrainSelection;
import dev.veil.revive.core.FrustumSnapshot;

import net.minecraft.client.renderer.SectionOcclusionGraph;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;

import java.util.List;

public final class VeilAsyncTerrainSelection {
    private static final AsyncTerrainSelection SELECTION =
            new AsyncTerrainSelection(
                    ReviveRuntime::optimizationsEnabled, ReviveRuntime::visibilityEngine,
                    VeilHostRevisions::origin, VeilHostRevisions::global);

    private VeilAsyncTerrainSelection() {}

    public static void prepare(SectionOcclusionGraph graph, Frustum frustum) {
        SELECTION.prepare(graph, frustum);
    }

    public static boolean trySelect(
            SectionOcclusionGraph graph,
            Frustum frustum,
            List<SectionRenderDispatcher.RenderSection> visible,
            List<SectionRenderDispatcher.RenderSection> nearby) {
        return SELECTION.trySelect(graph, frustum, visible, nearby);
    }

    static FrustumSnapshot planes(Frustum frustum) {
        return AsyncTerrainSelection.planes(frustum);
    }

    public static void invalidate() {
        SELECTION.invalidate();
    }

    public static void requireVerificationComplete() {
        SELECTION.requireVerificationComplete();
    }

    public static String telemetry() {
        return SELECTION.telemetry();
    }
}
