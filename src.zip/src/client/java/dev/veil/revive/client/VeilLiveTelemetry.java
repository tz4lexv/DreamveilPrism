package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.ReviveStats;
import dev.veil.revive.core.RollingSampleWindow;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class VeilLiveTelemetry {
    private static final long PUBLISH_INTERVAL_NS = 1_000_000_000L;
    private static final AtomicBoolean WRITE_PENDING = new AtomicBoolean();
    private static final AtomicBoolean ERROR_LOGGED = new AtomicBoolean();
    private static final ExecutorService WRITER =
            Executors.newSingleThreadExecutor(
                    r -> {
                        Thread thread = new Thread(r, "Veil-Telemetry");
                        thread.setDaemon(true);
                        thread.setPriority(Thread.MIN_PRIORITY);
                        return thread;
                    });

    private static long lastPublishNs;
    private static boolean initialized;
    private static Path liveFile;
    private static Path liveTempFile;
    private static Path sessionCsv;
    private static VeilTelemetryCsv.Session csvSession;
    private static VeilTechniqueCounters.Snapshot previousTechniques;
    private static VeilFaceVisibilityCache.Snapshot previousFaces;
    private static ReviveStats.Snapshot previousRuntime;

    private VeilLiveTelemetry() {}

    public static void onClientTick(Minecraft client) {
        long now = System.nanoTime();
        if (now - lastPublishNs < PUBLISH_INTERVAL_NS || !WRITE_PENDING.compareAndSet(false, true))
            return;
        lastPublishNs = now;

        try {
            ensureInitialized();
            Sample sample = capture(client);
            WRITER.execute(
                    () -> {
                        try {
                            write(sample);
                        } catch (IOException | RuntimeException e) {
                            if (ERROR_LOGGED.compareAndSet(false, true)) {
                                ReviveMod.LOGGER.warn("Could not write Veil live telemetry", e);
                            }
                        } finally {
                            WRITE_PENDING.set(false);
                        }
                    });
        } catch (IOException | RuntimeException e) {
            WRITE_PENDING.set(false);
            if (ERROR_LOGGED.compareAndSet(false, true)) {
                ReviveMod.LOGGER.warn("Could not initialize Veil live telemetry", e);
            }
        }
    }

    private static synchronized void ensureInitialized() throws IOException {
        if (initialized) return;
        Path directory = VeilPlatform.get().getGameDir().resolve("logs").resolve("veil-telemetry");
        Files.createDirectories(directory);
        liveFile = directory.resolve("live.txt");
        liveTempFile = directory.resolve("live.tmp");
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        sessionCsv = directory.resolve("session-" + stamp + ".csv");
        csvSession = new VeilTelemetryCsv.Session(sessionCsv);
        previousTechniques = VeilTechniqueCounters.snapshot();
        previousFaces = VeilFaceVisibilityCache.snapshot();
        previousRuntime = ReviveRuntime.stats();
        initialized = true;
        ReviveMod.LOGGER.info("Veil live telemetry ACTIVE: {}", liveFile.toAbsolutePath());
    }

    private static Sample capture(Minecraft client) {
        RollingSampleWindow.Snapshot frames = VeilDiagnostics.longFrameIntervals();
        RollingSampleWindow.Snapshot render = VeilDiagnostics.worldRenderCpu();
        VeilTechniqueCounters.Snapshot techniques = VeilTechniqueCounters.snapshot();
        VeilFaceVisibilityCache.Snapshot faces = VeilFaceVisibilityCache.snapshot();
        ReviveStats.Snapshot runtime = ReviveRuntime.stats();

        VeilTechniqueCounters.Snapshot techniqueDelta = techniques.minus(previousTechniques);
        VeilFaceVisibilityCache.Snapshot faceDelta = faces.minus(previousFaces);
        ReviveStats.Snapshot runtimeDelta = runtime.minus(previousRuntime);
        previousTechniques = techniques;
        previousFaces = faces;
        previousRuntime = runtime;

        Runtime jvm = Runtime.getRuntime();
        long heapUsed = jvm.totalMemory() - jvm.freeMemory();
        double visibleSections =
                techniqueDelta.terrainVisibleSectionSamples() > 0L
                        ? (double) techniqueDelta.terrainVisibleSectionsTotal()
                                / techniqueDelta.terrainVisibleSectionSamples()
                        : 0.0;

        return new Sample(
                Instant.now().toString(),
                client.level != null,
                VeilDiagnostics.bypassed() ? "BYPASS" : "ON",
                client.options.getEffectiveRenderDistance(),
                client.getWindow().getWidth(),
                client.getWindow().getHeight(),
                VeilDiagnostics.lastFrameIntervalMs(),
                frames,
                render,
                runtime.lastFrameMs(),
                runtimeDelta.terrainUploadPasses(),
                runtimeDelta.totalTerrainUploadMs(),
                runtimeDelta.occlusionUpdates(),
                runtimeDelta.totalOcclusionUpdateMs(),
                visibleSections,
                nonNegative(techniqueDelta.sectionDirtyEvents()),
                nonNegative(techniqueDelta.sectionMeshUpdateEvents()),
                nonNegative(techniqueDelta.terrainCacheReuses()),
                nonNegative(techniqueDelta.terrainCacheRebuilds()),
                nonNegative(
                        techniqueDelta.skippedVertexBinds() + techniqueDelta.skippedIndexBinds()),
                nonNegative(techniqueDelta.terrainBridgeFallbacks()),
                nonNegative(faceDelta.hits()),
                nonNegative(faceDelta.misses()),
                faces.hitRate(),
                heapUsed,
                jvm.totalMemory(),
                jvm.maxMemory(),
                VeilTerrainDrawBridge.sharedWork(),
                client.isPaused(),
                client.isWindowActive(),
                ReviveRuntime.profiling(),
                techniques.farAnalysisRuns(),
                VeilTerrainDrawBridge.sliceCacheHits(),
                VeilTerrainDrawBridge.sliceCacheMisses(),
                VeilTerrainDrawBridge.verifiedSlices(),
                VeilVulkanWork.snapshot(),
                VeilIndirectTerrain.telemetry()
                        + VeilHzb.telemetry()
                        + VeilLodArena.telemetry()
                        + VeilVisibilityBudget.telemetry()
                        + VeilGpuProfiler.telemetry()
                        + VeilMemoryMonitor.telemetry()
                        + VeilLatencyController.telemetry()
                        + VeilGpuArena.telemetry()
                        + VeilSectionTable.telemetry()
                        + VeilSectionResidencyGuard.telemetry()
                        + VeilRebuildCoalescer.telemetry()
                        + VeilRebuildBudget.telemetry()
                        + VeilAnimatedSpriteUsage.telemetry()
                        + VeilLightingPipeline.telemetry()
                        + "\n"
                        + VeilVulkanCapabilities.telemetry()
                        + VeilFullFrameTelemetry.telemetry());
    }

    private static long nonNegative(long value) {
        return Math.max(0L, value);
    }

    private static void write(Sample sample) throws IOException {

        sessionCsv = csvSession.append(Sample.csvHeader(sample.advancedRenderer), sample.csvRow());
        Files.writeString(
                liveTempFile,
                sample.liveText(),
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING,
                StandardOpenOption.WRITE);
        for (int attempt = 0; ; attempt++) {
            try {
                replaceLiveFile();
                break;
            } catch (AccessDeniedException readerLock) {
                if (attempt == 3) throw readerLock;
                try {
                    Thread.sleep(10L << attempt);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw new IOException("Telemetry writer interrupted", interrupted);
                }
            }
        }
    }

    private static void replaceLiveFile() throws IOException {
        try {
            Files.move(
                    liveTempFile,
                    liveFile,
                    StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(liveTempFile, liveFile, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public static void close() {
        WRITER.shutdown();
        try {
            WRITER.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private record Sample(
            String timestamp,
            boolean worldLoaded,
            String veilState,
            int renderDistance,
            int width,
            int height,
            double currentFrameMs,
            RollingSampleWindow.Snapshot frames,
            RollingSampleWindow.Snapshot render,
            double currentRenderMs,
            long uploadPasses,
            double uploadTotalMs,
            long occlusionUpdates,
            double occlusionTotalMs,
            double visibleSections,
            long dirtySections,
            long meshUpdates,
            long terrainCacheHits,
            long terrainCacheMisses,
            long skippedBinds,
            long bridgeFallbacks,
            long faceHits,
            long faceMisses,
            double cumulativeFaceHitRate,
            long heapUsed,
            long heapCommitted,
            long heapMax,
            VeilSharedSectionUniforms.Snapshot sharedWork,
            boolean paused,
            boolean focused,
            boolean hostTimingsEnabled,
            long farAnalysisRuns,
            long sliceHits,
            long sliceMisses,
            long verifiedSlices,
            VeilVulkanWork.Snapshot vulkanWork,
            String advancedRenderer) {

        static String csvHeader(String advancedRenderer) {
            return "timestamp,world,veil,render_distance,width,height,frame_samples,fps_current,fps_avg,fps_1pct_low,fps_0_1pct_low,"
                    + "frame_ms_current,frame_ms_avg,frame_ms_p50,frame_ms_p95,frame_ms_p99,frame_ms_p999,frame_ms_max,"
                    + "render_cpu_ms_current,render_cpu_ms_avg,render_cpu_ms_p95,render_cpu_ms_p99,"
                    + "upload_passes,upload_ms_total,occlusion_updates,occlusion_ms_total,visible_sections_avg,"
                    + "dirty_sections,mesh_updates,terrain_cache_hits,terrain_cache_misses,skipped_binds,bridge_fallbacks,"
                    + "face_cache_hits,face_cache_misses,face_cache_cumulative_pct,heap_used_mib,heap_committed_mib,heap_max_mib,"
                    + "matrix_copies_total,matrix_copies_avoided_total,uniform_records_reused_total,uniform_records_created_total,"
                    + "paused,focused,host_timings_enabled,far_analysis_runs_total,"
                    + "slice_cache_hits_total,slice_cache_misses_total,slice_verified_total,vulkan_uniform_skips_total,vulkan_pipeline_skips_total,"
                    + advancedColumns(advancedRenderer, true)
                    + "\n";
        }

        String liveText() {
            return String.format(
                            Locale.ROOT,
                            "timestamp=%s%nworld_loaded=%s%nveil_state=%s%nrender_distance_chunks=%d%nresolution=%dx%d%n"
                                    + "frame_samples=%d%nfps_current=%.2f%nfps_average=%.2f%nfps_1_percent_low=%.2f%nfps_0_1_percent_low=%.2f%n"
                                    + "frame_ms_current=%.3f%nframe_ms_average=%.3f%nframe_ms_p50=%.3f%nframe_ms_p95=%.3f%nframe_ms_p99=%.3f%nframe_ms_p999=%.3f%nframe_ms_max=%.3f%n"
                                    + "render_cpu_ms_current=%.3f%nrender_cpu_ms_average=%.3f%nrender_cpu_ms_p95=%.3f%nrender_cpu_ms_p99=%.3f%n"
                                    + "terrain_upload_passes_last_second=%d%nterrain_upload_ms_last_second=%.3f%n"
                                    + "occlusion_updates_last_second=%d%nocclusion_ms_last_second=%.3f%nvisible_sections_average_last_second=%.2f%n"
                                    + "dirty_sections_last_second=%d%nmesh_updates_last_second=%d%nterrain_cache_hits_last_second=%d%nterrain_cache_misses_last_second=%d%n"
                                    + "skipped_binds_last_second=%d%nbridge_fallbacks_last_second=%d%nface_cache_hits_last_second=%d%nface_cache_misses_last_second=%d%n"
                                    + "face_cache_cumulative_reuse_percent=%.2f%nheap_used_mib=%.2f%nheap_committed_mib=%.2f%nheap_max_mib=%.2f%nsession_csv=%s%n",
                            timestamp,
                            worldLoaded,
                            veilState,
                            renderDistance,
                            width,
                            height,
                            frames.count(),
                            fps(currentFrameMs),
                            fps(frames.average()),
                            fps(frames.p99()),
                            fps(frames.p999()),
                            currentFrameMs,
                            frames.average(),
                            frames.p50(),
                            frames.p95(),
                            frames.p99(),
                            frames.p999(),
                            frames.max(),
                            currentRenderMs,
                            render.average(),
                            render.p95(),
                            render.p99(),
                            uploadPasses,
                            uploadTotalMs,
                            occlusionUpdates,
                            occlusionTotalMs,
                            visibleSections,
                            dirtySections,
                            meshUpdates,
                            terrainCacheHits,
                            terrainCacheMisses,
                            skippedBinds,
                            bridgeFallbacks,
                            faceHits,
                            faceMisses,
                            cumulativeFaceHitRate * 100.0,
                            mib(heapUsed),
                            mib(heapCommitted),
                            mib(heapMax),
                            sessionCsv.toAbsolutePath())
                    + "matrix_copies_total="
                    + sharedWork.matrixCopies()
                    + "\n"
                    + "matrix_copies_avoided_total="
                    + sharedWork.matrixCopiesAvoided()
                    + "\n"
                    + "uniform_records_reused_total="
                    + sharedWork.recordsReused()
                    + "\n"
                    + "uniform_records_created_total="
                    + sharedWork.recordsCreated()
                    + "\n"
                    + "paused="
                    + paused
                    + "\nfocused="
                    + focused
                    + "\n"
                    + "host_timings_enabled="
                    + hostTimingsEnabled
                    + "\nfar_analysis_runs_total="
                    + farAnalysisRuns
                    + "\n"
                    + "slice_cache_hits_total="
                    + sliceHits
                    + "\nslice_cache_misses_total="
                    + sliceMisses
                    + "\n"
                    + "slice_verified_total="
                    + verifiedSlices
                    + "\n"
                    + "vulkan_uniform_skips_total="
                    + vulkanWork.uniforms()
                    + "\n"
                    + "vulkan_pipeline_skips_total="
                    + vulkanWork.pipelines()
                    + "\n"
                    + advancedRenderer
                    + "fps_low_definition=reciprocal_frame_percentile_p99_and_p999\n";
        }

        String csvRow() {
            return String.format(
                            Locale.ROOT,
                            "%s,%s,%s,%d,%d,%d,%d,%.3f,%.3f,%.3f,%.3f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,"
                                    + "%.4f,%.4f,%.4f,%.4f,%d,%.4f,%d,%.4f,%.3f,%d,%d,%d,%d,%d,%d,%d,%d,%.3f,%.3f,%.3f,%.3f",
                            timestamp,
                            worldLoaded,
                            veilState,
                            renderDistance,
                            width,
                            height,
                            frames.count(),
                            fps(currentFrameMs),
                            fps(frames.average()),
                            fps(frames.p99()),
                            fps(frames.p999()),
                            currentFrameMs,
                            frames.average(),
                            frames.p50(),
                            frames.p95(),
                            frames.p99(),
                            frames.p999(),
                            frames.max(),
                            currentRenderMs,
                            render.average(),
                            render.p95(),
                            render.p99(),
                            uploadPasses,
                            uploadTotalMs,
                            occlusionUpdates,
                            occlusionTotalMs,
                            visibleSections,
                            dirtySections,
                            meshUpdates,
                            terrainCacheHits,
                            terrainCacheMisses,
                            skippedBinds,
                            bridgeFallbacks,
                            faceHits,
                            faceMisses,
                            cumulativeFaceHitRate * 100.0,
                            mib(heapUsed),
                            mib(heapCommitted),
                            mib(heapMax))
                    + ","
                    + sharedWork.matrixCopies()
                    + ","
                    + sharedWork.matrixCopiesAvoided()
                    + ","
                    + sharedWork.recordsReused()
                    + ","
                    + sharedWork.recordsCreated()
                    + ","
                    + paused
                    + ","
                    + focused
                    + ","
                    + hostTimingsEnabled
                    + ","
                    + farAnalysisRuns
                    + ","
                    + sliceHits
                    + ","
                    + sliceMisses
                    + ","
                    + verifiedSlices
                    + ","
                    + vulkanWork.uniforms()
                    + ","
                    + vulkanWork.pipelines()
                    + ","
                    + advancedColumns(advancedRenderer, false)
                    + "\n";
        }

        private static String advancedColumns(String text, boolean names) {
            return VeilTelemetryCsv.columns(text, names);
        }

        private static double fps(double frameMs) {
            return frameMs > 0.0 ? 1000.0 / frameMs : 0.0;
        }

        private static double mib(long bytes) {
            return bytes / (1024.0 * 1024.0);
        }
    }
}
