package dev.veil.api;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

/**
 * Opt-in fixed-step clock for creator-defined simulations. No weather, physics or GPU algorithm is
 * prescribed. Create one instance per simulation/world; only the caller decides when to tick.
 */
public final class VeilSimulationClock {
    private static final int MAGIC = 0x56534331; // VSC1
    private static final int VERSION = 1;
    private static final int SNAPSHOT_BYTES = Integer.BYTES * 3 + Double.BYTES * 2 + Long.BYTES;

    @FunctionalInterface
    public interface Step {
        void run(double stepSeconds, long stepIndex);
    }

    public record Advance(
            int steps, double interpolation, double droppedSeconds, long totalSteps) {}

    private final double stepSeconds;
    private final int maxCatchUpSteps;
    private long totalSteps;
    private double remainder;

    public VeilSimulationClock(double stepSeconds, int maxCatchUpSteps) {
        if (!Double.isFinite(stepSeconds) || stepSeconds <= 0 || stepSeconds > 3600)
            throw new IllegalArgumentException("Invalid simulation step duration");
        if (maxCatchUpSteps < 1
                || maxCatchUpSteps > 1024
                || !Double.isFinite(stepSeconds * maxCatchUpSteps))
            throw new IllegalArgumentException("Invalid catch-up budget");
        this.stepSeconds = stepSeconds;
        this.maxCatchUpSteps = maxCatchUpSteps;
    }

    /**
     * Processes elapsed time without tying simulation speed to rendering FPS. Excess backlog is
     * discarded rather than causing an unbounded CPU/GPU workload. A thrown callback leaves the
     * unsuccessful step queued; successful steps remain committed.
     */
    public synchronized Advance advance(double elapsedSeconds, Step callback) {
        Objects.requireNonNull(callback, "callback");
        if (!Double.isFinite(elapsedSeconds) || elapsedSeconds < 0)
            throw new IllegalArgumentException("Elapsed seconds must be finite and nonnegative");
        double available = remainder + elapsedSeconds;
        double cap = stepSeconds * maxCatchUpSteps;
        double dropped = Math.max(0, available - cap);
        remainder = Math.min(available, cap);
        int completed = 0;
        double tolerance = stepSeconds * 1e-12;
        while (completed < maxCatchUpSteps && remainder + tolerance >= stepSeconds) {
            if (totalSteps == Long.MAX_VALUE)
                throw new IllegalStateException("Simulation step index exhausted");
            callback.run(stepSeconds, totalSteps);
            totalSteps++;
            completed++;
            remainder = Math.max(0, remainder - stepSeconds);
        }
        return new Advance(
                completed, Math.clamp(remainder / stepSeconds, 0, 1), dropped, totalSteps);
    }

    public synchronized long totalSteps() {
        return totalSteps;
    }

    public synchronized double interpolation() {
        return Math.clamp(remainder / stepSeconds, 0, 1);
    }

    /** Clears accumulated time and the counter when starting an unrelated simulation/world. */
    public synchronized void reset() {
        remainder = 0;
        totalSteps = 0;
    }

    /** Portable clock checkpoint, suitable for inclusion in an atomic multi-field bundle. */
    public synchronized byte[] snapshotBytes() {
        ByteBuffer data = ByteBuffer.allocate(SNAPSHOT_BYTES).order(ByteOrder.LITTLE_ENDIAN);
        data.putInt(MAGIC).putInt(VERSION).putDouble(stepSeconds).putInt(maxCatchUpSteps);
        data.putDouble(remainder).putLong(totalSteps);
        return data.array();
    }

    /** Rejects an incompatible checkpoint without changing this clock. */
    public synchronized void restoreBytes(byte[] snapshot) throws IOException {
        Objects.requireNonNull(snapshot, "snapshot");
        if (snapshot.length != SNAPSHOT_BYTES)
            throw new IOException("Invalid simulation clock checkpoint size");
        ByteBuffer data = ByteBuffer.wrap(snapshot).order(ByteOrder.LITTLE_ENDIAN);
        int magic = data.getInt();
        int version = data.getInt();
        double storedStep = data.getDouble();
        int storedBudget = data.getInt();
        double storedRemainder = data.getDouble();
        long storedSteps = data.getLong();
        if (magic != MAGIC
                || version != VERSION
                || Double.compare(storedStep, stepSeconds) != 0
                || storedBudget != maxCatchUpSteps
                || !Double.isFinite(storedRemainder)
                || storedRemainder < 0
                || storedRemainder >= stepSeconds
                || storedSteps < 0)
            throw new IOException("Invalid or incompatible simulation clock checkpoint");
        remainder = storedRemainder;
        totalSteps = storedSteps;
    }

    /** Saves clock metadata, not the creator's actual simulation fields. */
    public synchronized void save(
            VeilSimulationStateStore store, String worldId, String packId, String stateId)
            throws IOException {
        Objects.requireNonNull(store, "store");
        store.save(worldId, packId, stateId, snapshotBytes());
    }

    /** Returns false for an absent checkpoint. Malformed/incompatible data cannot change state. */
    public synchronized boolean restore(
            VeilSimulationStateStore store, String worldId, String packId, String stateId)
            throws IOException {
        Objects.requireNonNull(store, "store");
        var saved = store.load(worldId, packId, stateId);
        if (saved.isEmpty()) return false;
        restoreBytes(saved.get());
        return true;
    }
}
