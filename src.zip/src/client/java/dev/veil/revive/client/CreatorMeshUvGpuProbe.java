package dev.veil.revive.client;

import dev.veil.api.VeilCreatorMeshes;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

final class CreatorMeshUvGpuProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment() && Boolean.getBoolean("veil.meshUvProbe");
    private static Object world;
    private static VeilCreatorMeshes.Registration textured, legacy;

    private CreatorMeshUvGpuProbe() {}

    static void prepare() {
        if (!ENABLED || world == Minecraft.getInstance().level) return;
        if (textured != null) textured.close();
        if (legacy != null) legacy.close();
        world = Minecraft.getInstance().level;
        float[] positions = {0, 0, 0, 1, 0, 0, 0, 1, 0};
        int[] indices = {0, 1, 2};
        textured =
                VeilCreatorMeshes.register(
                        new VeilCreatorMeshes.Mesh(
                                0x5647555600000001L,
                                73,
                                0,
                                positions,
                                null,
                                indices,
                                new float[] {0.125f, 0.25f, 0.875f, 0.25f, 0.125f, 0.75f}));
        legacy =
                VeilCreatorMeshes.register(
                        new VeilCreatorMeshes.Mesh(
                                0x5647555600000002L, 74, 0, positions, null, indices));
    }
}
