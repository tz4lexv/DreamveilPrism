package dev.veil.revive.client.shaderpack.runtime;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PackResourceSet<R, N, S> implements AutoCloseable {
    public final Map<String, GpuBuffer> buffers = new LinkedHashMap<>();
    public final Map<String, R> rayScenes = new LinkedHashMap<>();
    public final Map<String, GpuTexture> images = new LinkedHashMap<>();
    public final Map<String, GpuTextureView> views = new LinkedHashMap<>();
    public final Map<String, N> nativeImages = new LinkedHashMap<>();
    public final Map<String, S> samplers = new LinkedHashMap<>();
    public final List<GpuBuffer> ownedBuffers = new ArrayList<>();
    public final List<GpuTexture> ownedImages = new ArrayList<>();
    public final List<GpuTextureView> ownedViews = new ArrayList<>();
    public final List<S> ownedSamplers = new ArrayList<>();
    public long frame;
    public boolean initialized;
    public int[][] dispatch;

    private final java.util.function.Consumer<R> closeRayScene;
    private final java.util.function.Consumer<N> closeNativeImage;
    private final java.util.function.Consumer<S> closeSampler;

    public PackResourceSet(
            java.util.function.Consumer<R> closeRayScene,
            java.util.function.Consumer<N> closeNativeImage,
            java.util.function.Consumer<S> closeSampler) {
        this.closeRayScene = closeRayScene;
        this.closeNativeImage = closeNativeImage;
        this.closeSampler = closeSampler;
    }

    @Override
    public void close() {
        var cleanup = new dev.veil.revive.core.lifecycle.CloseSequence();
        cleanup.each(rayScenes.values(), closeRayScene);
        rayScenes.clear();
        cleanup.each(nativeImages.values(), closeNativeImage);
        cleanup.each(ownedViews, GpuTextureView::close);
        cleanup.each(ownedImages, GpuTexture::close);
        cleanup.each(ownedSamplers, closeSampler);
        cleanup.each(ownedBuffers, GpuBuffer::close);
        nativeImages.clear();
        samplers.clear();
        views.clear();
        images.clear();
        buffers.clear();
        ownedViews.clear();
        ownedImages.clear();
        ownedSamplers.clear();
        ownedBuffers.clear();
        cleanup.finish();
    }
}
