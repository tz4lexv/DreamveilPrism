package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.terrain.SparseUploadPlanner;

import org.lwjgl.system.MemoryUtil;

import java.util.BitSet;
import java.util.Random;

final class VeilBufferTransferGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.verifyBatchedTransfers")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static GpuBuffer source, target, readback;
    private static GpuFence fence;
    private static byte[] expected, expectedSnapshots;
    private static boolean complete;

    static void tick() {
        if (!ENABLED || complete) return;
        if (fence == null) {
            if (!Boolean.getBoolean("veil.batchedTransfers"))
                throw new IllegalStateException("Transfer GPU proof requires batchedTransfers");
            var device = RenderSystem.getDevice();
            source =
                    device.createBuffer(
                            () -> "Veil transfer probe source",
                            GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                            4096);
            target =
                    device.createBuffer(
                            () -> "Veil transfer probe target",
                            GpuBuffer.USAGE_COPY_DST
                                    | GpuBuffer.USAGE_COPY_SRC
                                    | GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER
                                    | VeilHzb.STORAGE_USAGE,
                            4096);
            readback =
                    device.createBuffer(
                            () -> "Veil transfer probe readback",
                            GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                            12288);
            var random = new Random(19558);
            var input = new byte[4096];
            expected = new byte[4096];
            expectedSnapshots = new byte[12288];
            random.nextBytes(input);
            random.nextBytes(expected);
            try (var mapping = source.map(false, true)) {
                mapping.data().put(input);
            }
            var encoder = device.createCommandEncoder();
            var direct = MemoryUtil.memAlloc(expected.length);
            try {
                direct.put(expected).flip();
                encoder.writeToBuffer(target.slice(), direct);
            } finally {
                MemoryUtil.memFree(direct);
            }
            var planner = new SparseUploadPlanner(0, 64);
            var dirty = new BitSet();
            long batchesBefore = VeilBufferTransferBatch.batches();
            long nativeBefore = VeilBufferTransferBatch.nativeRanges();
            long sectionBefore = VeilBufferTransferBatch.sectionBatches();
            for (int pass = 0; pass < 3; pass++) {
                dirty.clear();
                if (pass == 0) {
                    dirty.set(1);
                    dirty.set(9);
                    dirty.set(255);
                } else if (pass == 1) for (int i = 0; i < 64; i++) dirty.set(i * 3 + 1);
                else dirty.set(7, 12);
                planner.plan(dirty, 256);
                VeilBufferTransferBatch.copySectionTable(encoder, source, target, planner, 16);
                for (int i = dirty.nextSetBit(0); i >= 0; i = dirty.nextSetBit(i + 1))
                    System.arraycopy(input, i * 16, expected, i * 16, 16);
                System.arraycopy(expected, 0, expectedSnapshots, pass * 4096, 4096);
                encoder.copyToBuffer(target.slice(), readback.slice(pass * 4096L, 4096));
            }
            if (VeilBufferTransferBatch.batches() - batchesBefore != 2
                    || VeilBufferTransferBatch.nativeRanges() - nativeBefore != 1)
                throw new IllegalStateException("Transfer proof did not exercise both routes");
            if (Boolean.getBoolean("veil.sectionTransferDependencies")
                    && VeilBufferTransferBatch.sectionBatches() - sectionBefore != 2)
                throw new IllegalStateException("Explicit section dependencies not exercised");
            fence = encoder.createFence();
            return;
        }
        if (!fence.awaitCompletion(0)) return;
        try {
            try (var mapping = readback.map(true, false)) {
                for (int i = 0; i < expectedSnapshots.length; i++)
                    if (mapping.data().get(i) != expectedSnapshots[i])
                        throw new IllegalStateException("Transfer GPU mismatch at byte " + i);
            }
            complete = true;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil transfer GPU: PASS (12288 snapshot bytes, 3/64 ranges, read-before-overwrite destination, native single-range fallback)");
        } finally {
            fence.close();
            source.close();
            target.close();
            readback.close();
            fence = null;
            source = target = readback = null;
        }
    }

    static void requireComplete() {
        if (!ENABLED) return;
        tick();
        if (!complete) throw new IllegalStateException("Transfer GPU proof incomplete");
    }
}
