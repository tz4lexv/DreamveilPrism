package dev.veil.revive.client.shaderpack.parsing;

import com.google.gson.JsonObject;

import dev.veil.revive.client.VeilShaderId;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class ManifestJson {
    private ManifestJson() {}

    public static String resourceName(String name) {
        if (!name.matches("[a-zA-Z0-9_.-]+"))
            throw new IllegalArgumentException("Invalid pack name/ID: " + name);
        return name;
    }

    public static JsonObject object(JsonObject parent, String field) {
        return parent.has(field) ? parent.getAsJsonObject(field) : new JsonObject();
    }

    public static int integer(JsonObject parent, String field, int fallback) {
        return parent.has(field) ? parent.get(field).getAsBigDecimal().intValueExact() : fallback;
    }

    public static long longInteger(JsonObject parent, String field, long fallback) {
        return parent.has(field) ? parent.get(field).getAsBigDecimal().longValueExact() : fallback;
    }

    public static long unsigned(JsonObject parent, String field, long fallback) {
        long value = longInteger(parent, field, fallback);
        if (value < 0 || value > 0xffff_ffffL)
            throw new IllegalArgumentException(field + " exceeds uint32 range");
        return value;
    }

    public static float floating(JsonObject parent, String field, float fallback) {
        float value = parent.has(field) ? parent.get(field).getAsFloat() : fallback;
        if (!Float.isFinite(value)) throw new IllegalArgumentException(field + " must be finite");
        return value;
    }

    public static List<String> strings(JsonObject parent, String field) {
        var result = new ArrayList<String>();
        if (parent.has(field))
            parent.getAsJsonArray(field).forEach(value -> result.add(value.getAsString()));
        return List.copyOf(result);
    }

    public static void fields(JsonObject object, String... allowed) {
        Set<String> names = Set.of(allowed);
        for (String name : object.keySet())
            if (!names.contains(name))
                throw new IllegalArgumentException("Unsupported manifest field: " + name);
    }

    public static VeilShaderId asset(String namespace, String path) {
        return path.contains(":") ? VeilShaderId.parse(path) : new VeilShaderId(namespace, path);
    }
}
