package dev.veil.revive.client.graphics.resources;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.revive.client.VeilShaderPack.Binding;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;

public record BufferBindingLimits(
        long storageAlignment,
        long uniformAlignment,
        long maximumStorageRange,
        long maximumUniformRange) {
    public BufferBindingLimits {
        if (storageAlignment < 1
                || uniformAlignment < 1
                || maximumStorageRange < 1
                || maximumUniformRange < 1)
            throw new IllegalArgumentException("Invalid Vulkan buffer descriptor limits");
    }

    public static BufferBindingLimits capture(VkPhysicalDevice device) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var properties = VkPhysicalDeviceProperties.calloc(stack);
            vkGetPhysicalDeviceProperties(device, properties);
            var limits = properties.limits();
            return new BufferBindingLimits(
                    limits.minStorageBufferOffsetAlignment(),
                    limits.minUniformBufferOffsetAlignment(),
                    Integer.toUnsignedLong(limits.maxStorageBufferRange()),
                    Integer.toUnsignedLong(limits.maxUniformBufferRange()));
        }
    }

    public long validate(
            Binding binding,
            int descriptorType,
            long bufferBytes,
            long reflectedBytes,
            String label) {
        boolean uniform = descriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        if (!uniform && descriptorType != VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
            throw new IllegalArgumentException(label + ": not a buffer descriptor");
        long range = binding.resolvedBufferRange(bufferBytes);
        long alignment = uniform ? uniformAlignment : storageAlignment;
        if (binding.offset() % alignment != 0)
            throw new IllegalArgumentException(
                    label
                            + ": buffer offset="
                            + binding.offset()
                            + " requires alignment="
                            + alignment);
        long maximum = uniform ? maximumUniformRange : maximumStorageRange;
        if (range > maximum || range < reflectedBytes)
            throw new IllegalArgumentException(
                    label
                            + ": buffer descriptor range="
                            + range
                            + " required="
                            + reflectedBytes
                            + " maximum="
                            + maximum);
        return range;
    }
}
