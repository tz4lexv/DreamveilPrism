package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;

final class VeilShadowContactFixture {
    private static volatile com.google.gson.JsonObject description;

    private VeilShadowContactFixture() {}

    static double prepare(ServerLevel level, int cameraX, int cameraZ) {
        level.getGameRules()
                .set(
                        net.minecraft.world.level.gamerules.GameRules.SPAWN_MOBS,
                        false,
                        level.getServer());
        var entities = new java.util.ArrayList<net.minecraft.world.entity.Entity>();
        level.getAllEntities().forEach(entities::add);
        for (var entity : entities)
            if (!(entity instanceof net.minecraft.world.entity.player.Player)) entity.discard();
        int ground = 88;
        var cursor = new BlockPos.MutableBlockPos();
        for (int x = cameraX - 24; x <= cameraX + 24; x++) {
            for (int z = cameraZ - 24; z <= cameraZ + 24; z++) {
                level.setBlock(cursor.set(x, ground, z), Blocks.STONE.defaultBlockState(), 3);
                for (int y = ground + 1; y <= ground + 40; y++) {
                    if (!level.getBlockState(cursor.set(x, y, z)).isAir())
                        level.setBlock(cursor, Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
        int[][] pillars = {{-8, -8, 6}, {-18, -8, 3}, {-8, -18, 1}};
        for (int[] pillar : pillars) {
            for (int x = 0; x < 3; x++) {
                for (int z = 0; z < 3; z++) {
                    for (int y = 1; y <= pillar[2]; y++) {
                        level.setBlock(
                                cursor.set(
                                        cameraX + pillar[0] + x,
                                        ground + y,
                                        cameraZ + pillar[1] + z),
                                Blocks.PRISMARINE.defaultBlockState(),
                                3);
                    }
                }
            }
        }
        ReviveMod.LOGGER.info(
                "Veil shadow contact fixture: stone top y=89, three grounded 3x3 pillars heights=6/3/1, center=({}, {})",
                cameraX,
                cameraZ);
        var metadata = new com.google.gson.JsonObject();
        metadata.addProperty("center_x", cameraX);
        metadata.addProperty("center_z", cameraZ);
        metadata.addProperty("ground_top", ground + 1);
        var slopes = new com.google.gson.JsonArray();
        if (Boolean.getBoolean("veil.shadowSlopesProbe")) {
            var shape = net.minecraft.world.level.block.state.properties.RailShape.ASCENDING_NORTH;
            for (int x = cameraX; x < cameraX + 10; x += 2) {
                var support = new BlockPos(x, ground + 1, cameraZ - 11);
                var rail = new BlockPos(x, ground + 1, cameraZ - 10);
                level.setBlock(support, Blocks.STONE.defaultBlockState(), 3);
                level.setBlock(
                        rail,
                        Blocks.RAIL
                                .defaultBlockState()
                                .setValue(net.minecraft.world.level.block.RailBlock.SHAPE, shape),
                        3);
                var state = level.getBlockState(rail);
                if (!state.is(Blocks.RAIL)
                        || state.getValue(net.minecraft.world.level.block.RailBlock.SHAPE) != shape)
                    throw new IllegalStateException(
                            "Inclined receiver rail did not retain its native shape");
                var receiver = new com.google.gson.JsonObject();
                receiver.addProperty("x", rail.getX());
                receiver.addProperty("y", rail.getY());
                receiver.addProperty("z", rail.getZ());
                receiver.addProperty(
                        "shape",
                        state.getValue(net.minecraft.world.level.block.RailBlock.SHAPE)
                                .getSerializedName());
                slopes.add(receiver);
            }
            ReviveMod.LOGGER.info(
                    "Veil shadow slope fixture: {} native ascending_north rails", slopes.size());
        }
        metadata.add("inclined_receivers", slopes);
        description = metadata;
        if (Boolean.getBoolean("veil.shadowObjectsProbe")) {
            level.setBlock(
                    new BlockPos(cameraX - 2, ground + 1, cameraZ + 1),
                    Blocks.CHEST.defaultBlockState(),
                    3);
            var stand =
                    new net.minecraft.world.entity.decoration.ArmorStand(
                            level, cameraX - 1.5, ground + 1, cameraZ - 1.2);
            stand.setNoGravity(true);
            if (!level.addFreshEntity(stand))
                throw new IllegalStateException("Shadow fixture armor stand was rejected");
            ReviveMod.LOGGER.info(
                    "Veil shadow objects fixture: chest at (30,89,33), armor stand at (30.5,89,30.8)");
        }
        return ground + 8.0;
    }

    static com.google.gson.JsonObject metadata() {
        var value = description;
        return value == null ? new com.google.gson.JsonObject() : value.deepCopy();
    }
}
