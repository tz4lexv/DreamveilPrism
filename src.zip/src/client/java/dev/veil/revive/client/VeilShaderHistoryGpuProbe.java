package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

final class VeilShaderHistoryGpuProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.modularHistoryGpuProbe");
    private static int frames, verified;
    private static long started;
    private static boolean completed;
    private static VeilShaderPackRuntime generation;
    private static Object device;

    private VeilShaderHistoryGpuProbe() {}

    static void checkTimeout(boolean failed) {
        if (!ENABLED || completed) return;
        long now = System.nanoTime();
        if (started == 0) started = now;
        if (failed || now - started > 60_000_000_000L) fail("runtime/readback timeout");
    }

    static void before(VeilShaderPackRuntime active) {
        if (!ENABLED || completed) return;
        Object currentDevice =
                dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext
                        .currentDeviceOrNull();
        if (generation == null) {
            generation = active;
            device = currentDevice;
        }
        if (generation != active || device == null || device != currentDevice)
            throw new IllegalStateException("History probe changed runtime/device");
        if (!System.getProperty("veil.shaderPack", "").equals("veil-history-reset-v1"))
            throw new IllegalStateException("History probe requires its three-buffer fixture");
        frames++;
        if (frames == 12) {
            if (!active.historyValid())
                throw new IllegalStateException("History never warmed before late reset");
            active.invalidateHistory();
        }
        if (frames >= 12 && frames <= 14 && active.historyValid() != (frames == 14))
            throw new IllegalStateException("Late reset exposed stale temporal frames");
    }

    static void after(VeilShaderPackRuntime active) {
        if (!ENABLED || completed || frames < 12 || frames > 14) return;
        int frame = frames;
        int red = frame == 14 ? 0 : 255;
        int green = frame == 14 ? 255 : 0;
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil history reset readback",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                4);
        try {
            active.readOutput(
                    "output",
                    readback,
                    () -> {
                        try (var mapped = readback.map(true, false)) {
                            var bytes = mapped.data();
                            if (Byte.toUnsignedInt(bytes.get(0)) != red
                                    || Byte.toUnsignedInt(bytes.get(1)) != green
                                    || Byte.toUnsignedInt(bytes.get(2)) != 0
                                    || Byte.toUnsignedInt(bytes.get(3)) != 255)
                                throw new IllegalStateException(
                                        "Unexpected history pixel at frame " + frame);
                            ReviveMod.LOGGER.info(
                                    "Veil history reset readback: frame={} rgba={},{},0,255",
                                    frame,
                                    red,
                                    green);
                            if (++verified == 3) {
                                completed = true;
                                ReviveMod.LOGGER.info(
                                        "Veil history reset GPU: PASS (same runtime; late invalidation; three physical history buffers; exact red/red/green pixels)");
                                Minecraft.getInstance().stop();
                            }
                        } catch (RuntimeException problem) {
                            fail(problem.getMessage());
                        } finally {
                            readback.close();
                        }
                    });
        } catch (RuntimeException | Error problem) {
            readback.close();
            throw problem;
        }
    }

    private static void fail(String reason) {
        completed = true;
        ReviveMod.LOGGER.error("Veil history reset GPU: FAIL ({})", reason);
        Minecraft.getInstance().stop();
    }
}
