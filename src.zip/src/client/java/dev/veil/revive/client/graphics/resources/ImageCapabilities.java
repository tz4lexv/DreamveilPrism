package dev.veil.revive.client.graphics.resources;

import static org.lwjgl.vulkan.VK11.*;

import dev.veil.api.VeilResourceUsage;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkFormatProperties;
import org.lwjgl.vulkan.VkFormatProperties2;
import org.lwjgl.vulkan.VkFormatProperties3;
import org.lwjgl.vulkan.VkImageFormatProperties;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;

public final class ImageCapabilities {
    private ImageCapabilities() {}

    public static void validate(
            VkPhysicalDevice physical,
            ImageAllocationPlan resource,
            int width,
            int height,
            int depth,
            int layers,
            int vkFormat) {
        resource.validateExtent(width, height, depth, layers);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var properties = VkPhysicalDeviceProperties.calloc(stack);
            vkGetPhysicalDeviceProperties(physical, properties);
            var imageProperties = VkImageFormatProperties.calloc(stack);
            int result =
                    vkGetPhysicalDeviceImageFormatProperties(
                            physical,
                            vkFormat,
                            resource.image1d()
                                    ? VK_IMAGE_TYPE_1D
                                    : resource.image3d() ? VK_IMAGE_TYPE_3D : VK_IMAGE_TYPE_2D,
                            VK_IMAGE_TILING_OPTIMAL,
                            usage(resource),
                            resource.cubemap() ? VK_IMAGE_CREATE_CUBE_COMPATIBLE_BIT : 0,
                            imageProperties);
            if (result != VK_SUCCESS) {
                throw new IllegalArgumentException(
                        "Image "
                                + resource.name()
                                + ": unsupported format/type/usage combination (VkResult="
                                + result
                                + ")");
            }
            if (width > imageProperties.maxExtent().width()
                    || height > imageProperties.maxExtent().height()
                    || depth > imageProperties.maxExtent().depth()
                    || layers > imageProperties.maxArrayLayers()
                    || resource.mipLevels() > imageProperties.maxMipLevels()
                    || (imageProperties.sampleCounts() & sampleCount(resource.samples())) == 0) {
                throw new IllegalArgumentException(
                        "Image "
                                + resource.name()
                                + ": extent/layers/mips/samples exceed the format-specific Vulkan limits");
            }
            int maxDimension =
                    resource.image1d()
                            ? properties.limits().maxImageDimension1D()
                            : resource.image3d()
                                    ? properties.limits().maxImageDimension3D()
                                    : resource.cubemap()
                                            ? properties.limits().maxImageDimensionCube()
                                            : properties.limits().maxImageDimension2D();
            if (width > maxDimension
                    || height > maxDimension
                    || depth > (resource.image3d() ? maxDimension : 1)) {
                throw new IllegalArgumentException(
                        "Image "
                                + resource.name()
                                + " exceeds Vulkan max image dimension="
                                + maxDimension);
            }
            if ((resource.image1dArray() || resource.image2dArray() || resource.cubemap())
                    && layers > properties.limits().maxImageArrayLayers()) {
                throw new IllegalArgumentException(
                        "Image "
                                + resource.name()
                                + " exceeds Vulkan maxImageArrayLayers="
                                + properties.limits().maxImageArrayLayers());
            }
            int maxExtent = Math.max(width, Math.max(height, resource.image3d() ? depth : 1));
            int maxMips = 32 - Integer.numberOfLeadingZeros(maxExtent);
            if (resource.mipLevels() > maxMips) {
                throw new IllegalArgumentException(
                        "Image "
                                + resource.name()
                                + " mipLevels="
                                + resource.mipLevels()
                                + " exceeds resolved full chain="
                                + maxMips);
            }
            var formatProperties = VkFormatProperties.calloc(stack);
            vkGetPhysicalDeviceFormatProperties(physical, vkFormat, formatProperties);
            int features = formatProperties.optimalTilingFeatures();
            if (resource.sampled() && resource.sampler().compareEnable())
                validateDepthComparison(physical, vkFormat);
            if (resource.sampled() && (features & VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT) == 0) {
                throw new IllegalArgumentException(
                        "Creator image format is not sampleable on this Vulkan device: "
                                + resource.format());
            }
            if (resource.storageImage() && (features & VK_FORMAT_FEATURE_STORAGE_IMAGE_BIT) == 0) {
                throw new IllegalArgumentException(
                        "Creator image format is not storage-image capable on this Vulkan device: "
                                + resource.format());
            }
            if (resource.renderTarget()
                    && (features & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT) == 0) {
                throw new IllegalArgumentException(
                        "Creator image format is not color-attachment capable on this Vulkan device: "
                                + resource.format());
            }
            if (resource.depthTarget()
                    && (features & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT) == 0) {
                throw new IllegalArgumentException(
                        "Creator image format is not depth-attachment capable on this Vulkan device: "
                                + resource.format());
            }
            if (resource.usages().contains(VeilResourceUsage.TRANSFER_SOURCE)
                    && (features & VK_FORMAT_FEATURE_TRANSFER_SRC_BIT) == 0) {
                throw new IllegalArgumentException(
                        "Creator image format is not transfer-source capable on this Vulkan device: "
                                + resource.format());
            }
            if (resource.usages().contains(VeilResourceUsage.TRANSFER_DESTINATION)
                    && (features & VK_FORMAT_FEATURE_TRANSFER_DST_BIT) == 0) {
                throw new IllegalArgumentException(
                        "Creator image format is not transfer-destination capable on this Vulkan device: "
                                + resource.format());
            }
            if (resource.sampled()
                    && !resource.sampler().compareEnable()
                    && (resource.sampler().min() == VK_FILTER_LINEAR
                            || resource.sampler().mag() == VK_FILTER_LINEAR
                            || resource.sampler().mip() == VK_SAMPLER_MIPMAP_MODE_LINEAR)
                    && (features & VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT) == 0) {
                throw new IllegalArgumentException(
                        "Creator image format does not support linear filtering on this Vulkan device: "
                                + resource.format());
            }
            int supportedSamples =
                    resource.depthTarget()
                            ? properties.limits().framebufferDepthSampleCounts()
                            : properties.limits().framebufferColorSampleCounts();
            if ((supportedSamples & sampleCount(resource.samples())) == 0) {
                throw new IllegalArgumentException(
                        "Image sample count is unsupported for "
                                + resource.name()
                                + ": "
                                + resource.samples());
            }
        }
    }

    public static int usage(ImageAllocationPlan resource) {
        int usage = 0;
        if (resource.usages().contains(VeilResourceUsage.SAMPLED))
            usage |= VK_IMAGE_USAGE_SAMPLED_BIT;
        if (resource.usages().contains(VeilResourceUsage.STORAGE))
            usage |= VK_IMAGE_USAGE_STORAGE_BIT;
        if (resource.usages().contains(VeilResourceUsage.COLOR_ATTACHMENT))
            usage |= VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
        if (resource.usages().contains(VeilResourceUsage.DEPTH_ATTACHMENT))
            usage |= VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT;
        if (resource.usages().contains(VeilResourceUsage.TRANSFER_SOURCE))
            usage |= VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
        if (resource.usages().contains(VeilResourceUsage.TRANSFER_DESTINATION))
            usage |= VK_IMAGE_USAGE_TRANSFER_DST_BIT;
        return usage;
    }

    public static int sampleCount(int samples) {
        return switch (samples) {
            case 1 -> VK_SAMPLE_COUNT_1_BIT;
            case 2 -> VK_SAMPLE_COUNT_2_BIT;
            case 4 -> VK_SAMPLE_COUNT_4_BIT;
            case 8 -> VK_SAMPLE_COUNT_8_BIT;
            case 16 -> VK_SAMPLE_COUNT_16_BIT;
            default -> throw new IllegalArgumentException("Unsupported sample count: " + samples);
        };
    }

    public static void validateDepthComparison(VkPhysicalDevice physical, int vkFormat) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var deviceProperties = VkPhysicalDeviceProperties.calloc(stack);
            vkGetPhysicalDeviceProperties(physical, deviceProperties);
            if (deviceProperties.apiVersion() < org.lwjgl.vulkan.VK13.VK_API_VERSION_1_3) {
                var count = stack.mallocInt(1);
                int result =
                        vkEnumerateDeviceExtensionProperties(
                                physical, (java.nio.ByteBuffer) null, count, null);
                if (result != VK_SUCCESS)
                    throw new IllegalArgumentException(
                            "Cannot query depth comparison format capabilities: " + result);
                var extensions = org.lwjgl.vulkan.VkExtensionProperties.calloc(count.get(0), stack);
                result =
                        vkEnumerateDeviceExtensionProperties(
                                physical, (java.nio.ByteBuffer) null, count, extensions);
                boolean available = false;
                if (result == VK_SUCCESS)
                    for (int i = 0; i < count.get(0); i++)
                        available |=
                                extensions
                                        .get(i)
                                        .extensionNameString()
                                        .equals("VK_KHR_format_feature_flags2");
                if (!available)
                    throw new IllegalArgumentException(
                            "Depth comparison format validation requires Vulkan 1.3 or VK_KHR_format_feature_flags2");
            }
            var features = VkFormatProperties3.calloc(stack).sType$Default();
            var properties =
                    VkFormatProperties2.calloc(stack).sType$Default().pNext(features.address());
            vkGetPhysicalDeviceFormatProperties2(physical, vkFormat, properties);
            if ((features.optimalTilingFeatures()
                            & org.lwjgl
                                    .vulkan
                                    .VK13
                                    .VK_FORMAT_FEATURE_2_SAMPLED_IMAGE_DEPTH_COMPARISON_BIT)
                    == 0)
                throw new IllegalArgumentException(
                        "Format lacks Vulkan depth-comparison sampling support: " + vkFormat);
        }
    }
}
