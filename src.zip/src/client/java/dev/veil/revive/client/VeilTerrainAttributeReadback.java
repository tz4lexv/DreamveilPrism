package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;

import java.nio.ByteBuffer;

final class VeilTerrainAttributeReadback {
    private VeilTerrainAttributeReadback() {}

    static void verify(
            ByteBuffer original,
            GpuBuffer[] readbacks,
            int width,
            int height,
            int mode,
            String context) {
        dev.veil.revive.client.diagnostics.TerrainAttributeReadback.verify(
                original, readbacks, width, height, mode, context);
    }
}
