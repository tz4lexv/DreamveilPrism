package dev.veil.revive.client;

import static org.lwjgl.util.spvc.Spv.*;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashSet;

public final class VeilShaderBaseline {
    private static final int CAP_SAMPLED_IMAGE_ARRAY_DYNAMIC_INDEXING = 29;
    private static final int CAP_STORAGE_BUFFER_ARRAY_DYNAMIC_INDEXING = 30;
    private static final int CAP_STORAGE_IMAGE_ARRAY_DYNAMIC_INDEXING = 31;
    private static final int CAP_SHADER_NON_UNIFORM = 5301;
    private static final int CAP_RUNTIME_DESCRIPTOR_ARRAY = 5302;
    private static final int CAP_SAMPLED_IMAGE_ARRAY_NON_UNIFORM_INDEXING = 5307;
    private static final int CAP_STORAGE_BUFFER_ARRAY_NON_UNIFORM_INDEXING = 5308;
    private static final int CAP_STORAGE_IMAGE_ARRAY_NON_UNIFORM_INDEXING = 5309;

    private VeilShaderBaseline() {}

    public static void validate(VeilSpirvBinary binary) {
        var words =
                ByteBuffer.wrap(binary.unsafeCode()).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer();
        var specializedComposites = new HashSet<Integer>();
        int workgroup = -1;
        boolean localSize = binary.stage() != VeilShaderStage.COMPUTE;
        for (int offset = 5; offset < words.limit(); ) {
            int instruction = words.get(offset),
                    count = instruction >>> 16,
                    operation = instruction & 0xffff;
            if (operation == SpvOpCapability && count >= 2) {
                int capability = words.get(offset + 1);
                if (capability != SpvCapabilityShader
                        && capability != SpvCapabilityMatrix
                        && capability != SpvCapabilityTessellation
                        && capability != SpvCapabilityGeometry
                        && capability != SpvCapabilityImageCubeArray
                        && capability != SpvCapabilitySampledCubeArray
                        && capability != SpvCapabilityImage1D
                        && capability != SpvCapabilitySampled1D
                        && capability != SpvCapabilityImageQuery
                        && capability != SpvCapabilityDerivativeControl
                        && capability != SpvCapabilityStorageImageExtendedFormats
                        && capability != SpvCapabilityFloat16
                        && capability != SpvCapabilityInt8
                        && capability != SpvCapabilityInt16
                        && capability != SpvCapabilityInt64
                        && capability != SpvCapabilityInt64Atomics
                        && capability != SpvCapabilityRayQueryKHR
                        && capability != SpvCapabilityRayTracingKHR
                        && capability != SpvCapabilityStorageBuffer16BitAccess
                        && capability != SpvCapabilityStorageBuffer8BitAccess
                        && VeilShaderDeviceLimits.subgroupFeature(capability) == 0
                        && capability != CAP_SAMPLED_IMAGE_ARRAY_DYNAMIC_INDEXING
                        && capability != CAP_STORAGE_BUFFER_ARRAY_DYNAMIC_INDEXING
                        && capability != CAP_STORAGE_IMAGE_ARRAY_DYNAMIC_INDEXING
                        && capability != CAP_SHADER_NON_UNIFORM
                        && capability != CAP_RUNTIME_DESCRIPTOR_ARRAY
                        && capability != CAP_SAMPLED_IMAGE_ARRAY_NON_UNIFORM_INDEXING
                        && capability != CAP_STORAGE_BUFFER_ARRAY_NON_UNIFORM_INDEXING
                        && capability != CAP_STORAGE_IMAGE_ARRAY_NON_UNIFORM_INDEXING) {
                    throw new IllegalArgumentException(
                            binary.sourceName()
                                    + ": SPIR-V capability "
                                    + capability
                                    + " is outside the implemented creator baseline; device feature enablement is not verified");
                }
            }
            if (operation == SpvOpExecutionModeId) {
                throw new IllegalArgumentException(
                        binary.sourceName()
                                + ": ID-based execution modes are not supported by the creator baseline");
            }
            if (operation == SpvOpExecutionMode
                    && count >= 6
                    && words.get(offset + 2) == SpvExecutionModeLocalSize) {
                int x = words.get(offset + 3), y = words.get(offset + 4), z = words.get(offset + 5);
                if (x < 1 || y < 1 || z < 1 || x > 65535 || y > 65535 || z > 65535) {
                    throw new IllegalArgumentException(
                            binary.sourceName()
                                    + ": invalid creator compute local size; device limits are checked before publication");
                }
                localSize = true;
            }
            if (operation == SpvOpDecorate
                    && count >= 4
                    && words.get(offset + 2) == SpvDecorationBuiltIn
                    && words.get(offset + 3) == SpvBuiltInWorkgroupSize)
                workgroup = words.get(offset + 1);
            if (operation == SpvOpSpecConstantComposite && count >= 3)
                specializedComposites.add(words.get(offset + 2));
            offset += count;
        }
        if (!localSize || specializedComposites.contains(workgroup)) {
            throw new IllegalArgumentException(
                    binary.sourceName()
                            + ": creator compute requires a fixed local workgroup size");
        }
        VeilInt64AtomicRequirements.inspect(binary);
    }

    public static void validateDeviceFeatures(VeilSpirvBinary binary) {
        VeilInt64AtomicRequirements.inspect(binary)
                .validateEnabled(
                        binary.sourceName(),
                        VeilVulkanCapabilities.shaderBufferInt64Atomics(),
                        VeilVulkanCapabilities.shaderSharedInt64Atomics());
        var words =
                ByteBuffer.wrap(binary.unsafeCode()).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer();
        for (int offset = 5; offset < words.limit(); ) {
            int instruction = words.get(offset),
                    count = instruction >>> 16,
                    operation = instruction & 0xffff;
            if (operation == SpvOpCapability && count >= 2) {
                int capability = words.get(offset + 1);
                boolean enabled =
                        switch (capability) {
                            case SpvCapabilityImageCubeArray, SpvCapabilitySampledCubeArray ->
                                    dev.veil.revive.client.graphics.minecraft.EnabledRasterFeatures
                                            .enabledOnCurrentDevice(
                                                    dev.veil.revive.client.graphics.minecraft
                                                            .EnabledRasterFeatures.Feature
                                                            .IMAGE_CUBE_ARRAY);
                            case SpvCapabilityRayQueryKHR -> VeilRayCapabilities.rayQuery();
                            case SpvCapabilityRayTracingKHR -> VeilRayCapabilities.rayPipeline();
                            case SpvCapabilityFloat16 -> VeilVulkanCapabilities.shaderFloat16();
                            case SpvCapabilityInt8 -> VeilVulkanCapabilities.shaderInt8();
                            case SpvCapabilityInt16 -> VeilVulkanCapabilities.shaderInt16();
                            case SpvCapabilityInt64 -> VeilVulkanCapabilities.shaderInt64();
                            case SpvCapabilityStorageBuffer16BitAccess ->
                                    VeilVulkanCapabilities.storageBuffer16();
                            case SpvCapabilityStorageBuffer8BitAccess ->
                                    VeilVulkanCapabilities.storageBuffer8();
                            case SpvCapabilityStorageImageExtendedFormats ->
                                    VeilVulkanCapabilities.shaderStorageImageExtendedFormats();
                            case CAP_SAMPLED_IMAGE_ARRAY_DYNAMIC_INDEXING ->
                                    VeilVulkanCapabilities.shaderSampledImageArrayDynamicIndexing();
                            case CAP_STORAGE_BUFFER_ARRAY_DYNAMIC_INDEXING ->
                                    VeilVulkanCapabilities
                                            .shaderStorageBufferArrayDynamicIndexing();
                            case CAP_STORAGE_IMAGE_ARRAY_DYNAMIC_INDEXING ->
                                    VeilVulkanCapabilities.shaderStorageImageArrayDynamicIndexing();
                            case CAP_RUNTIME_DESCRIPTOR_ARRAY ->
                                    VeilVulkanCapabilities.runtimeDescriptorArray();
                            case CAP_SAMPLED_IMAGE_ARRAY_NON_UNIFORM_INDEXING ->
                                    VeilVulkanCapabilities
                                            .shaderSampledImageArrayNonUniformIndexing();
                            case CAP_STORAGE_BUFFER_ARRAY_NON_UNIFORM_INDEXING ->
                                    VeilVulkanCapabilities
                                            .shaderStorageBufferArrayNonUniformIndexing();
                            case CAP_STORAGE_IMAGE_ARRAY_NON_UNIFORM_INDEXING ->
                                    VeilVulkanCapabilities
                                            .shaderStorageImageArrayNonUniformIndexing();
                            default -> true;
                        };
                if (!enabled) {
                    if (capability == SpvCapabilityRayQueryKHR
                            || capability == SpvCapabilityRayTracingKHR) {
                        throw new IllegalStateException(
                                binary.sourceName()
                                        + ": ray queries require enabled VK_KHR_ray_query, VK_KHR_acceleration_structure and bufferDeviceAddress; no automatic fallback");
                    }
                    throw new IllegalStateException(
                            binary.sourceName()
                                    + ": SPIR-V capability "
                                    + capability
                                    + " requires a shader/storage/descriptor-indexing feature that is not enabled on this Vulkan device");
                }
            }
            offset += count;
        }
    }

    public static int[] fixedLocalSize(VeilSpirvBinary binary) {
        if (binary == null || binary.stage() != VeilShaderStage.COMPUTE) {
            throw new IllegalArgumentException("Compute SPIR-V is required");
        }
        var words =
                ByteBuffer.wrap(binary.unsafeCode()).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer();
        for (int offset = 5; offset < words.limit(); ) {
            int instruction = words.get(offset),
                    count = instruction >>> 16,
                    operation = instruction & 0xffff;
            if (operation == SpvOpExecutionMode
                    && count >= 6
                    && words.get(offset + 2) == SpvExecutionModeLocalSize) {
                return new int[] {
                    words.get(offset + 3), words.get(offset + 4), words.get(offset + 5)
                };
            }
            offset += count;
        }
        throw new IllegalArgumentException(
                binary.sourceName() + ": creator compute requires a fixed local workgroup size");
    }
}
