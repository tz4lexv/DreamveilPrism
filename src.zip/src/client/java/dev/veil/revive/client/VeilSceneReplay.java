package dev.veil.revive.client;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.PoseStack;

import dev.veil.api.VeilScenePass;
import dev.veil.revive.mixin.FeaturePreparedFrameSceneAccessor;
import dev.veil.revive.mixin.LevelRendererSceneAccessor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeStorage;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.feature.FeatureRenderDispatcher;
import net.minecraft.client.renderer.state.level.LevelRenderState;

import org.joml.Vector4f;

import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

public final class VeilSceneReplay {
    private static VeilSceneSubmissions entities;
    private static VeilSceneSubmissions localPlayer;
    private static VeilSceneSubmissions blockEntities;

    private VeilSceneReplay() {}

    static void clear() {
        entities = null;
        localPlayer = null;
        blockEntities = null;
    }

    public static void capture(
            net.minecraft.client.renderer.LevelRenderer renderer, LevelRenderState state) {
        RenderSystem.assertOnRenderThread();
        LevelRendererSceneAccessor access = (LevelRendererSceneAccessor) renderer;
        clear();
        if (VeilShaderService.sceneCategoryRequested(VeilScenePass.Category.ENTITIES)
                && VeilShadowMotionProbe.includeFixtureEntities()) {
            boolean repeated =
                    VeilShaderService.sceneCategoryRepeated(VeilScenePass.Category.ENTITIES);
            var storage = new SubmitNodeStorage();
            Minecraft minecraft = Minecraft.getInstance();
            int excludedPlayer = -1;
            if (minecraft.player != null && !VeilShadowMotionProbe.includeLocalPlayer()) {
                for (int i = 0; i < state.entityRenderStates.size(); i++) {
                    if (state.entityRenderStates.get(i)
                                    instanceof
                                    net.minecraft.client.renderer.entity.state.AvatarRenderState
                                            avatar
                            && avatar.id == minecraft.player.getId()) {
                        excludedPlayer = i;
                        break;
                    }
                }
            }
            var excluded =
                    excludedPlayer < 0 ? null : state.entityRenderStates.remove(excludedPlayer);
            try {
                access.veil$submitEntities(new PoseStack(), state, storage);
            } finally {
                if (excluded != null) state.entityRenderStates.add(excludedPlayer, excluded);
            }
            entities = new VeilSceneSubmissions(storage, repeated);
            if (minecraft.player != null
                    && minecraft.options.getCameraType().isFirstPerson()
                    && VeilShadowMotionProbe.includeLocalPlayer()) {
                var camera = state.cameraRenderState;
                var player =
                        renderer.entityRenderDispatcher()
                                .extractEntity(
                                        minecraft.player,
                                        minecraft
                                                .getDeltaTracker()
                                                .getGameTimeDeltaPartialTick(false));
                if (player != null) {
                    player.outlineColor = 0;
                    var playerStorage = new SubmitNodeStorage();
                    renderer.entityRenderDispatcher()
                            .submit(
                                    player,
                                    camera,
                                    player.x - camera.pos.x,
                                    player.y - camera.pos.y,
                                    player.z - camera.pos.z,
                                    new PoseStack(),
                                    playerStorage);
                    localPlayer = new VeilSceneSubmissions(playerStorage, repeated);
                }
            }
        }
        if (VeilShaderService.sceneCategoryRequested(VeilScenePass.Category.BLOCK_ENTITIES)
                && VeilShadowMotionProbe.includeFixtureEntities()) {
            var storage = new SubmitNodeStorage();
            access.veil$submitBlockEntities(new PoseStack(), state, storage);
            blockEntities =
                    new VeilSceneSubmissions(
                            storage,
                            VeilShaderService.sceneCategoryRepeated(
                                    VeilScenePass.Category.BLOCK_ENTITIES));
        }
    }

    static void render(
            String label,
            VeilShaderPack.Pass definition,
            VeilSceneCameraAbi.Snapshot camera,
            GpuBufferSlice projectionSlice,
            GpuTextureView color,
            GpuTextureView depth,
            boolean depthOnlyTerrain) {
        RenderSystem.assertOnRenderThread();
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.levelRenderer == null) return;
        var categories = definition.scene().categories();
        boolean terrain =
                categories.contains(VeilScenePass.Category.TERRAIN_OPAQUE)
                        || categories.contains(VeilScenePass.Category.TERRAIN_CUTOUT);
        RenderSystem.backupProjectionMatrix();
        try {
            RenderSystem.setProjectionMatrix(
                    projectionSlice,
                    definition.scene().camera().projection() == VeilScenePass.Projection.PERSPECTIVE
                            ? com.mojang.blaze3d.ProjectionType.PERSPECTIVE
                            : com.mojang.blaze3d.ProjectionType.ORTHOGRAPHIC);
            ChunkSectionsToRender prepared =
                    terrain
                            ? VeilSceneTerrainSelection.prepare(
                                    minecraft.levelRenderer, camera, definition.name())
                            : null;
            if (prepared != null)
                ((VeilChunkSectionsExtras) (Object) prepared).veil$ensureHostUniforms();
            var opaqueDepthPipeline =
                    prepared != null && depthOnlyTerrain ? VeilSceneDepthPipeline.opaque() : null;
            Vector4f clear = new Vector4f();
            VeilShaderPack.ClearColor declaredClear = definition.colors().getFirst().clear();
            if (declaredClear != null)
                clear.set(
                        declaredClear.r(), declaredClear.g(), declaredClear.b(), declaredClear.a());
            try (RenderPass pass =
                    RenderSystem.getDevice()
                            .createCommandEncoder()
                            .createRenderPass(
                                    () -> label,
                                    color,
                                    Optional.of(clear),
                                    depth,
                                    OptionalDouble.of(definition.depth().clearDepth()))) {
                RenderSystem.bindDefaultUniforms(pass);
                if (prepared != null) {
                    GpuSampler sampler =
                            ((LevelRendererSceneAccessor) minecraft.levelRenderer)
                                    .veil$chunkLayerSampler();
                    if (sampler == null)
                        sampler = RenderSystem.getSamplerCache().getClampToEdge(FilterMode.NEAREST);
                    pass.bindTexture("Sampler0", prepared.textureView(), sampler);
                    pass.bindTexture(
                            "Sampler2",
                            minecraft.gameRenderer.lightmap(),
                            RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
                    var sequential = RenderSystem.getSequentialBuffer(PrimitiveTopology.QUADS);
                    GpuBuffer sharedIndices =
                            prepared.maxIndicesRequired() == 0
                                    ? null
                                    : sequential.getBuffer(prepared.maxIndicesRequired());
                    var sharedType = prepared.maxIndicesRequired() == 0 ? null : sequential.type();
                    drawLayer(
                            pass,
                            prepared,
                            ChunkSectionLayer.SOLID,
                            categories.contains(VeilScenePass.Category.TERRAIN_OPAQUE),
                            sharedIndices,
                            sharedType,
                            opaqueDepthPipeline);
                    drawLayer(
                            pass,
                            prepared,
                            ChunkSectionLayer.CUTOUT,
                            categories.contains(VeilScenePass.Category.TERRAIN_CUTOUT),
                            sharedIndices,
                            sharedType,
                            null);
                }
            }
            LevelRendererSceneAccessor access =
                    (LevelRendererSceneAccessor) minecraft.levelRenderer;
            if (categories.contains(VeilScenePass.Category.ENTITIES)) {
                renderFeatures(
                        access.veil$featureRenderDispatcher(),
                        entities,
                        camera,
                        color,
                        depth,
                        true);
                renderFeatures(
                        access.veil$featureRenderDispatcher(),
                        localPlayer,
                        camera,
                        color,
                        depth,
                        true);
            }
            if (categories.contains(VeilScenePass.Category.BLOCK_ENTITIES)) {
                renderFeatures(
                        access.veil$featureRenderDispatcher(),
                        blockEntities,
                        camera,
                        color,
                        depth,
                        false);
            }
        } finally {
            RenderSystem.restoreProjectionMatrix();
        }
    }

    private static void renderFeatures(
            FeatureRenderDispatcher dispatcher,
            VeilSceneSubmissions submissions,
            VeilSceneCameraAbi.Snapshot camera,
            GpuTextureView color,
            GpuTextureView depth,
            boolean includeTranslucentModels) {
        if (submissions == null) return;
        SubmitNodeStorage storage = submissions.replay();
        if (storage.getSubmitsPerOrder().isEmpty()) return;
        GpuTextureView oldColor = RenderSystem.outputColorTextureOverride;
        GpuTextureView oldDepth = RenderSystem.outputDepthTextureOverride;
        var modelView = RenderSystem.getModelViewStack();
        modelView.pushMatrix();
        try {
            modelView.mul(camera.view());
            RenderSystem.outputColorTextureOverride = color;
            RenderSystem.outputDepthTextureOverride = depth;
            try (FeatureRenderDispatcher.PreparedFrame frame = dispatcher.prepareFrame(storage)) {
                frame.executeSolid();
                if (includeTranslucentModels) {
                    FeaturePreparedFrameSceneAccessor access =
                            (FeaturePreparedFrameSceneAccessor) (Object) frame;
                    var context = access.veil$context();
                    for (var collection : storage.getSubmitsPerOrder().values()) {
                        access.veil$executePhase(collection.translucentModels, context);
                        access.veil$executePhase(collection.translucentBlocksAndItems, context);
                    }
                }
            }
        } finally {
            RenderSystem.outputColorTextureOverride = oldColor;
            RenderSystem.outputDepthTextureOverride = oldDepth;
            modelView.popMatrix();
        }
    }

    private static void drawLayer(
            RenderPass pass,
            ChunkSectionsToRender prepared,
            ChunkSectionLayer layer,
            boolean enabled,
            GpuBuffer sharedIndices,
            com.mojang.blaze3d.IndexType sharedType,
            com.mojang.blaze3d.pipeline.RenderPipeline replacement) {
        if (!enabled) return;
        pass.setPipeline(replacement == null ? layer.pipeline() : replacement);
        var groups = prepared.drawGroupsPerLayer().get(layer);
        if (groups == null) return;
        for (List<RenderPass.Draw<GpuBufferSlice[]>> draws : groups.values()) {
            if (!draws.isEmpty())
                pass.drawMultipleIndexed(
                        draws,
                        sharedIndices,
                        sharedType,
                        List.of("ChunkSection"),
                        prepared.chunkSectionInfos());
        }
    }
}
