package dev.veil.api;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public final class VeilCreatorMeshes {
    public static final int MAX_VERTICES_PER_MESH = 65_536;
    public static final int MAX_TRIANGLES_PER_MESH = 16_384;

    public static final class Mesh {
        private final long id;
        private final int material;
        private final int flags;
        private final float[] positions;
        private final float[] previousPositions;
        private final int[] indices;
        private final float[] textureCoordinates;

        public Mesh(
                long id,
                int material,
                int flags,
                float[] positions,
                float[] previousPositions,
                int[] indices) {
            this(id, material, flags, positions, previousPositions, indices, null);
        }

        public Mesh(
                long id,
                int material,
                int flags,
                float[] positions,
                float[] previousPositions,
                int[] indices,
                float[] textureCoordinates) {
            Objects.requireNonNull(positions, "positions");
            Objects.requireNonNull(indices, "indices");
            if (material < 0
                    || positions.length == 0
                    || positions.length % 3 != 0
                    || positions.length / 3 > MAX_VERTICES_PER_MESH
                    || indices.length == 0
                    || indices.length % 3 != 0
                    || indices.length / 3 > MAX_TRIANGLES_PER_MESH) {
                throw new IllegalArgumentException("Invalid Veil creator triangle mesh dimensions");
            }
            float[] previous = previousPositions == null ? positions : previousPositions;
            if (previous.length != positions.length)
                throw new IllegalArgumentException(
                        "Previous mesh positions must match current positions");
            for (float value : positions)
                if (!Float.isFinite(value))
                    throw new IllegalArgumentException("Non-finite creator mesh position");
            for (float value : previous)
                if (!Float.isFinite(value))
                    throw new IllegalArgumentException("Non-finite previous creator mesh position");
            int vertices = positions.length / 3;
            if (textureCoordinates != null) {
                if (textureCoordinates.length != vertices * 2)
                    throw new IllegalArgumentException(
                            "Texture coordinates must match mesh vertices");
                for (float value : textureCoordinates)
                    if (!Float.isFinite(value))
                        throw new IllegalArgumentException("Non-finite mesh texture coordinate");
            }
            for (int index : indices)
                if (index < 0 || index >= vertices)
                    throw new IllegalArgumentException("Creator mesh index out of range");
            this.id = id;
            this.material = material;
            this.flags = flags;
            this.positions = positions.clone();
            this.previousPositions = previous.clone();
            this.indices = indices.clone();
            this.textureCoordinates =
                    textureCoordinates == null ? null : textureCoordinates.clone();
        }

        public long id() {
            return id;
        }

        public int material() {
            return material;
        }

        public int flags() {
            return flags;
        }

        public int vertexCount() {
            return positions.length / 3;
        }

        public boolean hasTextureCoordinates() {
            return textureCoordinates != null;
        }

        public float textureCoordinate(int vertex, int axis) {
            if (vertex < 0 || vertex >= vertexCount() || axis < 0 || axis > 1)
                throw new IndexOutOfBoundsException("Mesh texture coordinate index");
            return textureCoordinates == null ? 0 : textureCoordinates[vertex * 2 + axis];
        }

        public int triangleCount() {
            return indices.length / 3;
        }

        public float position(int vertex, int axis) {
            return positions[vertex * 3 + axis];
        }

        public float previousPosition(int vertex, int axis) {
            return previousPositions[vertex * 3 + axis];
        }

        public int index(int index) {
            return indices[index];
        }
    }

    public interface Registration extends AutoCloseable {
        long id();

        void update(Mesh mesh);

        @Override
        void close();
    }

    public record Snapshot(long revision, List<Mesh> meshes) {}

    private static final Object LOCK = new Object();
    private static final HashMap<Long, Entry> MESHES = new HashMap<>();
    private static long revision;

    private VeilCreatorMeshes() {}

    public static Registration register(Mesh mesh) {
        Objects.requireNonNull(mesh, "mesh");
        Entry entry = new Entry(mesh);
        synchronized (LOCK) {
            if (MESHES.putIfAbsent(mesh.id(), entry) != null) {
                throw new IllegalStateException(
                        "Creator mesh ID is already registered: " + mesh.id());
            }
            revision++;
        }
        return new Registration() {
            private boolean closed;

            @Override
            public long id() {
                return mesh.id();
            }

            @Override
            public void update(Mesh replacement) {
                Objects.requireNonNull(replacement, "replacement");
                synchronized (LOCK) {
                    if (closed) throw new IllegalStateException("Mesh registration is closed");
                    if (replacement.id() != mesh.id())
                        throw new IllegalArgumentException("Mesh registration identity changed");
                    entry.mesh = replacement;
                    revision++;
                }
            }

            @Override
            public void close() {
                synchronized (LOCK) {
                    if (closed) return;
                    closed = true;
                    MESHES.remove(mesh.id(), entry);
                    revision++;
                }
            }
        };
    }

    public static Snapshot snapshot() {
        synchronized (LOCK) {
            return new Snapshot(
                    revision, MESHES.values().stream().map(entry -> entry.mesh).toList());
        }
    }

    public static List<Mesh> meshes() {
        return snapshot().meshes();
    }

    private static final class Entry {
        private Mesh mesh;

        private Entry(Mesh mesh) {
            this.mesh = mesh;
        }
    }
}
