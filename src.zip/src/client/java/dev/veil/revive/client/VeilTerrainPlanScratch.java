package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.terrain.WorkerLeaseCache;
import dev.veil.revive.platform.VeilPlatform;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.atomic.LongAdder;

final class VeilTerrainPlanScratch {
    static final int RETAIN_LIMIT = 32768;
    private static final boolean REQUESTED = Boolean.getBoolean("veil.reusePlanScratch");
    private static final boolean VERIFY =
            Boolean.getBoolean("veil.verifyPlanScratch")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static long verifiedPlans, verifiedCommands;
    private static final WorkerLeaseCache<Integer, VeilTerrainPlanScratch> CACHE =
            new WorkerLeaseCache<>(
                    ignored -> new VeilTerrainPlanScratch(), VeilTerrainPlanScratch::clear);
    private static final LongAdder CREATED = new LongAdder(),
            REUSED = new LongAdder(),
            NESTED = new LongAdder(),
            RECORDS_CREATED = new LongAdder(),
            RECORDS_REUSED = new LongAdder(),
            CLEARS = new LongAdder(),
            VERIFIED = new LongAdder();
    ArrayList<VeilIndirectTerrain.Resolved> source = new ArrayList<>();
    ArrayList<VeilIndirectTerrain.Resolved> ordered = new ArrayList<>();
    private final ArrayList<VeilIndirectTerrain.Resolved> records = new ArrayList<>();
    private int used;
    private long created, reused;
    private boolean collecting;

    static boolean requested() {
        return REQUESTED;
    }

    static WorkerLeaseCache.Lease<VeilTerrainPlanScratch> open() {
        var lease = CACHE.borrow(0, true);
        lease.value().collecting = VeilTechniqueCounters.collecting() || VERIFY;
        if (lease.value().collecting) {
            if (lease.reused()) REUSED.increment();
            else CREATED.increment();
            if (lease.nested()) NESTED.increment();
        }
        return lease;
    }

    VeilIndirectTerrain.Resolved record() {
        VeilIndirectTerrain.Resolved result;
        if (used < records.size()) {
            result = records.get(used);
            reused++;
        } else {
            result = new VeilIndirectTerrain.Resolved();
            created++;
            if (records.size() < RETAIN_LIMIT) records.add(result);
        }
        used++;
        return result;
    }

    private void clear() {
        for (int i = 0; i < Math.min(used, records.size()); i++) {
            var record = records.get(i);
            record.clear();
            if (VERIFY && !record.cleared())
                throw new IllegalStateException("plan scratch retained host data");
        }
        if (source.size() > RETAIN_LIMIT) source = new ArrayList<>();
        else source.clear();
        if (ordered.size() > RETAIN_LIMIT) ordered = new ArrayList<>();
        else ordered.clear();
        if (collecting) {
            RECORDS_CREATED.add(created);
            RECORDS_REUSED.add(reused);
            CLEARS.increment();
            if (VERIFY) VERIFIED.increment();
        }
        used = 0;
        created = reused = 0;
        collecting = false;
    }

    static boolean verificationPending() {
        return REQUESTED && VERIFY && verifiedCommands < 100_000;
    }

    static void captureBatch(VeilIndirectTerrain.Batch batch, ByteBuffer upload) {
        if (!verificationPending() && !VeilCompactPlanProbe.pending()) return;
        int commands = batch.sectionIndices.length * 20;
        int bounds = batch.sectionIndices.length * 32;
        int regions = batch.regionCount * 32;
        byte[] bytes = new byte[commands + bounds + regions];
        upload.get(batch.commandsOffset, bytes, 0, commands);
        upload.get(batch.boundsOffset, bytes, commands, bounds);
        upload.get(batch.regionBoundsOffset, bytes, commands + bounds, regions);
        batch.verificationPayload = bytes;
    }

    static void verifyPlan(VeilIndirectTerrain.Plan actual, VeilIndirectTerrain.Plan reference) {
        long commands = comparePlan(actual, reference);
        verifiedPlans++;
        verifiedCommands += commands;
        if (verifiedCommands >= 100_000)
            ReviveMod.LOGGER.info(
                    "Veil plan scratch commands: PASS (plans={} commands={} exact_commands_bounds_regions=true)",
                    verifiedPlans,
                    verifiedCommands);
    }

    static long comparePlan(VeilIndirectTerrain.Plan actual, VeilIndirectTerrain.Plan reference) {
        if (actual.layer != reference.layer
                || actual.usesDefaultIndices != reference.usesDefaultIndices
                || actual.batches.size() != reference.batches.size())
            throw new IllegalStateException("plan scratch changed plan topology");
        long commands = 0;
        for (int i = 0; i < actual.batches.size(); i++) {
            var a = actual.batches.get(i);
            var b = reference.batches.get(i);
            if (a.vertices != b.vertices
                    || a.indices != b.indices
                    || a.indexType != b.indexType
                    || a.layer != b.layer
                    || a.lod != b.lod
                    || a.regionShift != b.regionShift
                    || a.regionCount != b.regionCount
                    || a.allocationSize != b.allocationSize
                    || !Arrays.equals(a.sectionIndices, b.sectionIndices)
                    || !Arrays.equals(a.indexCounts, b.indexCounts)
                    || !Arrays.equals(a.firstIndices, b.firstIndices)
                    || !Arrays.equals(a.baseVertices, b.baseVertices)
                    || a.verificationPayload == null
                    || b.verificationPayload == null
                    || !Arrays.equals(a.verificationPayload, b.verificationPayload))
                throw new IllegalStateException(
                        "terrain plan differs: batch="
                                + i
                                + " vertices="
                                + (a.vertices == b.vertices)
                                + " indices="
                                + (a.indices == b.indices)
                                + " type="
                                + (a.indexType == b.indexType)
                                + " lod="
                                + (a.lod == b.lod)
                                + " regionShift="
                                + a.regionShift
                                + "/"
                                + b.regionShift
                                + " regionCount="
                                + a.regionCount
                                + "/"
                                + b.regionCount
                                + " allocationSize="
                                + a.allocationSize
                                + "/"
                                + b.allocationSize
                                + " sections="
                                + Arrays.mismatch(a.sectionIndices, b.sectionIndices)
                                + " counts="
                                + Arrays.mismatch(a.indexCounts, b.indexCounts)
                                + " firstIndices="
                                + Arrays.mismatch(a.firstIndices, b.firstIndices)
                                + " baseVertices="
                                + Arrays.mismatch(a.baseVertices, b.baseVertices)
                                + " payload="
                                + (a.verificationPayload == null || b.verificationPayload == null
                                        ? "missing"
                                        : Arrays.mismatch(
                                                a.verificationPayload, b.verificationPayload)));
            for (int command = 0; command < a.sectionIndices.length * 3; command++)
                if (a.directCommands.get(command) != b.directCommands.get(command))
                    throw new IllegalStateException("plan scratch changed direct commands");
            commands += a.sectionIndices.length;
        }
        return commands;
    }

    static void requireComplete() {
        if (!REQUESTED) return;
        if (REUSED.sum() == 0
                || RECORDS_REUSED.sum() == 0
                || CLEARS.sum() != CREATED.sum() + REUSED.sum()
                || VERIFY && (VERIFIED.sum() != CLEARS.sum() || verifiedCommands < 100_000))
            throw new IllegalStateException("plan scratch route not completely exercised");
        ReviveMod.LOGGER.info(
                "Veil plan scratch: PASS (created={} reused={} nested={} records_created={} records_reused={} clears={} verified={})",
                CREATED.sum(),
                REUSED.sum(),
                NESTED.sum(),
                RECORDS_CREATED.sum(),
                RECORDS_REUSED.sum(),
                CLEARS.sum(),
                VERIFIED.sum());
    }
}
