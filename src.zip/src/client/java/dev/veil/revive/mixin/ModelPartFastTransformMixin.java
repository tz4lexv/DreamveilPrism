package dev.veil.revive.mixin;

import com.mojang.blaze3d.vertex.PoseStack;

import dev.veil.revive.client.VeilEntityModelFastPath;

import net.minecraft.client.model.geom.ModelPart;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ModelPart.class)
public abstract class ModelPartFastTransformMixin {
    @Unique private static final float VEIL_MODEL_SCALE = 1.0F / 16.0F;

    @Shadow public float x;
    @Shadow public float y;
    @Shadow public float z;

    @Shadow public float xScale;
    @Shadow public float yScale;
    @Shadow public float zScale;

    @Shadow public float xRot;
    @Shadow public float yRot;
    @Shadow public float zRot;

    @Inject(method = "translateAndRotate", at = @At("HEAD"), cancellable = true, require = 1)
    private void veil$fastTranslateAndRotate(PoseStack poseStack, CallbackInfo ci) {
        if (!VeilEntityModelFastPath.enabled()) return;

        boolean translated = this.x != 0.0F || this.y != 0.0F || this.z != 0.0F;
        boolean rotated = this.xRot != 0.0F || this.yRot != 0.0F || this.zRot != 0.0F;
        boolean scaled = this.xScale != 1.0F || this.yScale != 1.0F || this.zScale != 1.0F;

        if (translated) {
            poseStack.translate(
                    this.x * VEIL_MODEL_SCALE,
                    this.y * VEIL_MODEL_SCALE,
                    this.z * VEIL_MODEL_SCALE);
        }

        if (rotated) {
            PoseStack.Pose pose = poseStack.last();
            pose.pose().rotateZYX(this.zRot, this.yRot, this.xRot);
            pose.normal().rotateZYX(this.zRot, this.yRot, this.xRot);
        }

        if (scaled) {
            poseStack.scale(this.xScale, this.yScale, this.zScale);
        }

        VeilEntityModelFastPath.record(translated, rotated, scaled);
        ci.cancel();
    }
}
