package dev.veil.revive.client.graphics.synchronization;

import dev.veil.revive.client.VeilRenderGraph.Subresource;

public final class ImportedImageRanges {
    private ImportedImageRanges() {}

    public static Subresource resolve(Subresource logical, int mipLevels, int layers) {
        if (mipLevels < 1 || layers < 1)
            throw new IllegalArgumentException("Invalid imported image dimensions");
        if (!logical.whole()
                && (logical.bufferRange()
                        || logical.baseMip() != 0
                        || logical.levelCount() != 1
                        || logical.baseLayer() != 0
                        || logical.layerCount() != 1))
            throw new IllegalArgumentException(
                    "Imported image graph range must cover its complete view");
        return Subresource.image(0, mipLevels, 0, layers);
    }
}
