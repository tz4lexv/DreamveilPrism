package dev.veil.revive.client;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.VertexSorting;

import dev.veil.revive.core.terrain.CompileCancellationScope;
import dev.veil.revive.mixin.SectionCompilerStateAccessor;

import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import net.minecraft.ReportedException;
import net.minecraft.client.renderer.SectionBufferBuilderPack;
import net.minecraft.client.renderer.block.BlockModelLighter;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.block.RenderShape;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Function;

public final class VeilOwnSectionCompiler {
    private static final boolean REQUESTED = Boolean.getBoolean("veil.ownSectionCompiler");
    private static final boolean VERIFY =
            Boolean.getBoolean("veil.verifyOwnSectionCompiler")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final ChunkSectionLayer[] LAYERS = ChunkSectionLayer.values();
    private static final Direction[] DIRECTIONS = Direction.values();
    private static final Semaphore ORACLES = new Semaphore(2);
    private static final LongAdder COMPILED = new LongAdder(),
            VERIFIED = new LongAdder(),
            VERTICES = new LongAdder();

    private VeilOwnSectionCompiler() {}

    public static SectionCompiler.Results dispatch(
            SectionCompilerStateAccessor state,
            SectionPos section,
            RenderSectionRegion region,
            VertexSorting sorting,
            SectionBufferBuilderPack builders,
            List<?> additions,
            Function<SectionBufferBuilderPack, SectionCompiler.Results> original) {
        if (!REQUESTED || !ReviveRuntime.optimizationsEnabled())
            return VeilSectionCompileCache.compile(section, region, () -> original.apply(builders));
        if (!VERIFY || VERTICES.sum() >= 100000 || !ORACLES.tryAcquire()) {
            var actual = compileOwn(state, section, region, sorting, builders, additions, original);
            try {
                VeilOriginalQuadReplay.verify(state, section, region, sorting, actual, original);
                return actual;
            } catch (RuntimeException | Error failure) {
                try {
                    actual.release();
                } catch (RuntimeException | Error cleanup) {
                    failure.addSuppressed(cleanup);
                }
                throw failure;
            }
        }
        try (var referenceBuilders = new SectionBufferBuilderPack()) {
            var reference =
                    VeilSectionCompileCache.compile(
                            section, region, () -> original.apply(referenceBuilders));
            try {
                var actual =
                        compileOwn(state, section, region, sorting, builders, additions, original);
                try {
                    compare(reference, actual);
                    VeilOriginalQuadReplay.verify(
                            state, section, region, sorting, actual, original);
                } catch (RuntimeException | Error failure) {
                    actual.release();
                    throw failure;
                }
                return actual;
            } finally {
                reference.release();
            }
        } finally {
            ORACLES.release();
        }
    }

    private static final LongAdder REUSED = new LongAdder(),
            REUSE_VERIFIED = new LongAdder(),
            REUSE_VERTICES = new LongAdder(),
            REUSE_RETRIES = new LongAdder(),
            REUSE_RETRY_VERIFIED = new LongAdder();

    static int pipeline(SectionCompilerStateAccessor state) {
        return (state.veil$ambientOcclusion() ? 1 : 0)
                | (state.veil$cutoutLeaves() ? 2 : 0)
                | (VeilVideoConfig.on("animation.visibleOnly") ? 4 : 0);
    }

    private static SectionCompiler.Results compileOwn(
            SectionCompilerStateAccessor state,
            SectionPos section,
            RenderSectionRegion region,
            VertexSorting sorting,
            SectionBufferBuilderPack builders,
            List<?> additions,
            Function<SectionBufferBuilderPack, SectionCompiler.Results> original) {
        SectionCompiler.Results actual;
        boolean retried = false;
        try {
            actual =
                    VeilSectionCompileCache.compile(
                            section,
                            region,
                            () ->
                                    compile(
                                            state, section, region, sorting, builders, additions,
                                            true));
        } catch (VeilOriginalAttributeWork.Unstable retry) {
            REUSE_RETRIES.increment();
            retried = true;
            actual =
                    VeilSectionCompileCache.compile(
                            section,
                            region,
                            () ->
                                    compile(
                                            state, section, region, sorting, builders, additions,
                                            false));
        }
        int reused = ((VeilSectionCompileExtras) (Object) actual).veil$reusedModels();
        REUSED.add(reused);
        if (!VeilOriginalAttributeWork.VERIFY_REUSE || reused == 0 && !retried) return actual;
        try (var referenceBuilders = new SectionBufferBuilderPack()) {
            var reference =
                    VeilSectionCompileCache.compile(
                            section, region, () -> original.apply(referenceBuilders));
            try {
                compare(reference, actual);
                long vertices = 0;
                for (var mesh : actual.renderedLayers.values())
                    vertices += mesh.drawState().vertexCount();
                REUSE_VERTICES.add(vertices);
                REUSE_VERIFIED.increment();
                if (retried) REUSE_RETRY_VERIFIED.increment();
            } finally {
                reference.release();
            }
            return actual;
        } catch (RuntimeException | Error failure) {
            try {
                actual.release();
            } catch (RuntimeException | Error cleanup) {
                failure.addSuppressed(cleanup);
            }
            throw failure;
        }
    }

    private static SectionCompiler.Results compile(
            SectionCompilerStateAccessor state,
            SectionPos section,
            RenderSectionRegion region,
            VertexSorting sorting,
            SectionBufferBuilderPack buffers,
            List<?> additions,
            boolean allowReuse) {
        var result = new SectionCompiler.Results();
        if (!additions.isEmpty())
            if (VeilOriginalQuadCapture.REQUESTED) VeilOriginalQuadCapture.mixedGeometry();
        var started = new BufferBuilder[LAYERS.length];
        Function<ChunkSectionLayer, BufferBuilder> builder =
                layer -> {
                    int index = layer.ordinal();
                    if (started[index] == null)
                        started[index] =
                                new BufferBuilder(
                                        buffers.buffer(layer),
                                        PrimitiveTopology.QUADS,
                                        layer.vertexFormat());
                    return started[index];
                };
        var position =
                new BlockPos.MutableBlockPos(
                        section.minBlockX(), section.minBlockY(), section.minBlockZ());
        var originalWork =
                VeilOriginalAttributeWork.REUSE && allowReuse && additions.isEmpty()
                        ? VeilOriginalAttributeWork.current()
                        : null;
        int pipeline = pipeline(state);
        BlockModelLighter.enableCaching();
        try (var visibility = VeilSectionVisibility.open();
                var renderer =
                        VeilSectionRenderAdapter.get()
                                .open(
                                        state.veil$ambientOcclusion(),
                                        state.veil$cutoutLeaves(),
                                        state.veil$blockColors(),
                                        state.veil$fluidModels(),
                                        builder,
                                        additions)) {
            if (originalWork != null)
                originalWork.prepare(
                        quad -> {
                            var at = BlockPos.of(quad.position());
                            var block = region.getBlockState(at);
                            if (quad.state() != block
                                    || quad.model() != state.veil$blockModels().get(block))
                                return null;
                            return VeilModelGeometryStamp.capture(
                                    VeilSectionRenderAdapter.get(),
                                    region,
                                    at,
                                    block,
                                    quad.model(),
                                    pipeline);
                        });
            for (int z = 0; z < 16; z++) {
                CompileCancellationScope.check();
                for (int y = 0; y < 16; y++)
                    for (int x = 0; x < 16; x++) {
                        position.set(
                                section.minBlockX() + x,
                                section.minBlockY() + y,
                                section.minBlockZ() + z);
                        var block = region.getBlockState(position);
                        if (block.isAir()) continue;
                        if (block.isSolidRender()) visibility.opaque(x, y, z, position);
                        if (block.hasBlockEntity()) {
                            var entity = region.getBlockEntity(position);
                            if (entity != null) result.blockEntities.add(entity);
                        }
                        var fluid = block.getFluidState();
                        if (!fluid.isEmpty()) {
                            if (VeilOriginalQuadCapture.REQUESTED)
                                VeilOriginalQuadCapture.mixedGeometry();
                            renderer.fluid(region, position, block, fluid);
                        }
                        if (block.getRenderShape() == RenderShape.MODEL) {
                            var model = state.veil$blockModels().get(block);
                            if (originalWork != null
                                    && originalWork.replay(
                                            region, position, block, model, renderer)) continue;
                            if (VeilOriginalQuadCapture.REQUESTED
                                    && VeilOriginalQuadCapture.active())
                                VeilOriginalQuadCapture.beginModel(
                                        position,
                                        block,
                                        model,
                                        VeilModelGeometryStamp.capture(
                                                VeilSectionRenderAdapter.get(),
                                                region,
                                                position,
                                                block,
                                                model,
                                                pipeline));
                            renderer.model(region, position, block, model, x, y, z);
                            if (VeilOriginalQuadCapture.REQUESTED
                                    && VeilOriginalQuadCapture.active())
                                VeilOriginalQuadCapture.finishModelGeometry(
                                        VeilModelGeometryStamp.capture(
                                                VeilSectionRenderAdapter.get(),
                                                region,
                                                position,
                                                block,
                                                model,
                                                pipeline));
                        }
                    }
                VeilCompilerCancellationProbe.traversal(section, started);
            }
            CompileCancellationScope.check();
            renderer.finish(region);
            for (var layer : LAYERS) {
                CompileCancellationScope.check();
                int at = layer.ordinal();
                if (started[at] == null) continue;
                var mesh = started[at].build();
                started[at] = null;
                if (mesh == null) continue;
                result.renderedLayers.put(layer, mesh);
                if (layer == ChunkSectionLayer.TRANSLUCENT)
                    result.transparencyState = mesh.sortQuads(buffers.buffer(layer), sorting);
            }
            result.visibilitySet = visibility.resolve();
            if (originalWork != null) originalWork.validate();
            VeilOriginalQuadReplay.verifyPrevious(state, region, sorting, result);
            VeilCompilerCancellationProbe.beforePublish(section);
            CompileCancellationScope.check();
            if (VERIFY || VeilTechniqueCounters.collecting()) COMPILED.increment();
            return result;
        } catch (Throwable failure) {
            long discardedVertices = 0;
            if (failure instanceof CompileCancellationScope.Aborted
                    && VeilCompilerCancellationProbe.enabled())
                for (var mesh : result.renderedLayers.values())
                    discardedVertices += mesh.drawState().vertexCount();
            result.release();
            for (var pending : started)
                if (pending != null) {
                    try {
                        var mesh = pending.build();
                        if (mesh != null) {
                            discardedVertices += mesh.drawState().vertexCount();
                            mesh.close();
                        }
                    } catch (RuntimeException | Error cleanup) {
                        failure.addSuppressed(cleanup);
                    }
                }
            if (failure instanceof CompileCancellationScope.Aborted aborted) {
                VeilCompilerCancellationProbe.discarded(section, discardedVertices);
                throw aborted;
            }
            if (failure instanceof VeilOriginalAttributeWork.Unstable retry) throw retry;
            if (failure instanceof ReportedException reported) throw reported;
            var report = CrashReport.forThrowable(failure, "Veil section mesh compilation");
            CrashReportCategory.populateBlockDetails(
                    report.addCategory("Block being compiled"),
                    region,
                    position,
                    region.getBlockState(position));
            throw new ReportedException(report);
        } finally {
            BlockModelLighter.clearCache();
        }
    }

    private static void compare(SectionCompiler.Results reference, SectionCompiler.Results actual) {
        if (!reference.blockEntities.equals(actual.blockEntities)
                || !reference.renderedLayers.keySet().equals(actual.renderedLayers.keySet()))
            throw new IllegalStateException("Section compiler entities or layers differ");
        for (var from : DIRECTIONS)
            for (var to : DIRECTIONS)
                if (reference.visibilitySet.visibilityBetween(from, to)
                        != actual.visibilitySet.visibilityBetween(from, to))
                    throw new IllegalStateException("Section compiler visibility differs");
        for (var from : DIRECTIONS)
            for (var to : DIRECTIONS)
                if (reference.visibilitySet.visibilityBetween(from, to)
                        != actual.visibilitySet.visibilityBetween(from, to))
                    throw new IllegalStateException("Section visibility metadata differs");
        long vertices = 0;
        for (var layer : reference.renderedLayers.keySet()) {
            var expected = reference.renderedLayers.get(layer);
            var found = actual.renderedLayers.get(layer);
            if (!expected.drawState().equals(found.drawState()))
                throw new IllegalStateException("Section mesh draw state differs: " + layer);
            compareBytes(expected.vertexBuffer(), found.vertexBuffer(), layer + " vertices");
            compareBytes(expected.indexBuffer(), found.indexBuffer(), layer + " indices");
            vertices += found.drawState().vertexCount();
        }
        var a = (VeilSectionCompileExtras) (Object) reference;
        var b = (VeilSectionCompileExtras) (Object) actual;
        if (!sameSprites(a.veil$animatedSprites(), b.veil$animatedSprites())
                || !Arrays.equals(a.veil$materialRanges(), b.veil$materialRanges()))
            throw new IllegalStateException("Section sprites or material ranges differ");
        var ag = a.veil$fluidGeometry();
        var bg = b.veil$fluidGeometry();
        if (ag.length != bg.length)
            throw new IllegalStateException("Section fluid geometry count differs");
        for (int i = 0; i < ag.length; i++)
            if (ag[i].materialId() != bg[i].materialId()
                    || ag[i].originX() != bg[i].originX()
                    || ag[i].originY() != bg[i].originY()
                    || ag[i].originZ() != bg[i].originZ()
                    || !Arrays.equals(ag[i].positions(), bg[i].positions())
                    || !Arrays.equals(ag[i].quadFlags(), bg[i].quadFlags()))
                throw new IllegalStateException("Section fluid geometry differs");
        VERIFIED.increment();
        VERTICES.add(vertices);
    }

    private static boolean sameSprites(
            net.minecraft.client.renderer.texture.TextureAtlasSprite[] a,
            net.minecraft.client.renderer.texture.TextureAtlasSprite[] b) {
        var sprites =
                new java.util.IdentityHashMap<
                        net.minecraft.client.renderer.texture.TextureAtlasSprite, Boolean>();
        for (var sprite : a) if (sprites.put(sprite, Boolean.TRUE) != null) return false;
        for (var sprite : b) if (sprites.remove(sprite) == null) return false;
        return sprites.isEmpty();
    }

    private static void compareBytes(ByteBuffer expected, ByteBuffer actual, String label) {
        if (expected == null && actual == null) return;
        if (expected == null || actual == null || !expected.equals(actual))
            throw new IllegalStateException("Section compiler bytes differ: " + label);
    }

    static void requireComplete() {
        VeilOriginalAttributeWork.requireProvenance();
        if (!REQUESTED) return;
        if (VeilOriginalAttributeWork.VERIFY_REUSE) {
            if (REUSED.sum() == 0
                    || REUSE_VERIFIED.sum() == 0
                    || REUSE_VERTICES.sum() < 64
                    || Boolean.getBoolean("veil.verifyOriginalReuseRetry")
                            && (REUSE_RETRIES.sum() == 0 || REUSE_RETRY_VERIFIED.sum() == 0))
                throw new IllegalStateException("Original model reuse not exercised");
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil original model reuse: PASS (models={} verified_sections={} verified_vertices={} retries={} retry_verified={})",
                    REUSED.sum(),
                    REUSE_VERIFIED.sum(),
                    REUSE_VERTICES.sum(),
                    REUSE_RETRIES.sum(),
                    REUSE_RETRY_VERIFIED.sum());
        }
        if (COMPILED.sum() == 0 || VERIFY && VERTICES.sum() < 100000)
            throw new IllegalStateException(
                    "Own section compiler incomplete: compiled="
                            + COMPILED.sum()
                            + " verified_vertices="
                            + VERTICES.sum());
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil own section compiler: PASS (compiled={} verified_sections={} verified_vertices={})",
                COMPILED.sum(),
                VERIFIED.sum(),
                VERTICES.sum());
    }
}
