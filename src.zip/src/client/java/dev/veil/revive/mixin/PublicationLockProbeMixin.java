package dev.veil.revive.mixin;

import dev.veil.revive.ReviveMod;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.locks.ReentrantLock;

@Mixin(SectionRenderDispatcher.class)
public abstract class PublicationLockProbeMixin {
    @Shadow @Final private ReentrantLock copyLock;

    @Inject(method = "<init>", at = @At("RETURN"), require = 1)
    private void veil$verifyPublicationLockPolicy(CallbackInfo callback) {
        boolean expected = Boolean.getBoolean("veil.experimentalFairPublicationLock");
        if (copyLock.isFair() != expected)
            throw new IllegalStateException("Unexpected publication lock policy");
        ReviveMod.LOGGER.info("Veil publication lock probe: fair={}", copyLock.isFair());
    }
}
