package dev.veil.revive.client.terrain.lod;

import dev.veil.revive.core.ExactLodCacheCodec;
import dev.veil.revive.core.FarTerrainLodStore;
import dev.veil.revive.core.FarTerrainTile;
import dev.veil.revive.core.LightOnlyLodReuse;
import dev.veil.revive.core.LodDiskCache;
import dev.veil.revive.core.PlanarTerrainLod;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.concurrent.*;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.BooleanSupplier;

public final class ExactLodBuildCache {
    private final FarTerrainLodStore MEMORY = new FarTerrainLodStore(32L << 20);
    private final LightOnlyLodReuse RELIGHT = new LightOnlyLodReuse(8L << 20);
    private final Path ROOT;
    private final BooleanSupplier cacheEnabled, relightEnabled;
    private final ThreadPoolExecutor WRITER =
            new ThreadPoolExecutor(
                    1,
                    1,
                    30,
                    TimeUnit.SECONDS,
                    new ArrayBlockingQueue<>(16),
                    runnable -> {
                        var thread = new Thread(runnable, "Veil LOD cache");
                        thread.setDaemon(true);
                        return thread;
                    },
                    new ThreadPoolExecutor.DiscardPolicy());
    private final LongAdder HITS = new LongAdder(),
            DISK_HITS = new LongAdder(),
            MISSES = new LongAdder(),
            LIGHT_REUSES = new LongAdder(),
            LIGHT_FALLBACKS = new LongAdder(),
            LIGHT_FLAGGED = new LongAdder();
    private int writes;

    public ExactLodBuildCache(
            Path gameDirectory, BooleanSupplier cacheEnabled, BooleanSupplier relightEnabled) {
        ROOT = gameDirectory.resolve("cache/veil/exact-lod-v1");
        this.cacheEnabled = java.util.Objects.requireNonNull(cacheEnabled);
        this.relightEnabled = java.util.Objects.requireNonNull(relightEnabled);
    }

    public PlanarTerrainLod.Result build(ByteBuffer vertices, int vertexCount, boolean lightOnly) {
        if (lightOnly) LIGHT_FLAGGED.increment();
        if (!cacheEnabled.getAsBoolean()) return PlanarTerrainLod.build(vertices, vertexCount);
        byte[] hash;
        try {
            var digest = MessageDigest.getInstance("SHA-256");
            digest.update(vertices.duplicate());
            hash = digest.digest();
        } catch (java.security.NoSuchAlgorithmException failure) {
            throw new IllegalStateException(failure);
        }
        ByteBuffer key = ByteBuffer.wrap(hash);
        int x = key.getInt(), z = key.getInt();
        long revision = key.getLong();
        String name = HexFormat.of().formatHex(hash);
        FarTerrainTile tile = MEMORY.get(x, z, 0, revision);
        PlanarTerrainLod.Result cached =
                tile == null
                        ? null
                        : ExactLodCacheCodec.decodeBuffer(tile.payloadView(), hash, vertexCount);
        if (cached != null) {
            HITS.increment();
            return cached;
        }
        var disk = new LodDiskCache(ROOT.resolve(name));
        try {
            tile = disk.load(0, 0, 0, 1).orElse(null);
            cached =
                    tile == null
                            ? null
                            : ExactLodCacheCodec.decodeBuffer(
                                    tile.payloadView(), hash, vertexCount);
            if (cached != null) {
                MEMORY.put(new FarTerrainTile(x, z, 0, revision, 1, tile.payload()));
                DISK_HITS.increment();
                return cached;
            }
        } catch (IOException ignored) {
        }
        MISSES.increment();
        boolean eligibleRelight = relightEnabled.getAsBoolean();
        LightOnlyLodReuse.Input lightInput =
                eligibleRelight ? LightOnlyLodReuse.inspect(vertices, vertexCount) : null;
        PlanarTerrainLod.Result result = eligibleRelight ? RELIGHT.reuse(lightInput) : null;
        if (result != null) LIGHT_REUSES.increment();
        else {
            if (lightOnly && eligibleRelight) LIGHT_FALLBACKS.increment();
            result = PlanarTerrainLod.build(vertices, vertexCount);
        }
        if (eligibleRelight) RELIGHT.remember(lightInput, result);
        if (result == null || result.vertices().length > (4 << 20)) return result;
        byte[] payload = ExactLodCacheCodec.encode(result, hash);
        MEMORY.put(new FarTerrainTile(x, z, 0, revision, 1, payload));
        WRITER.execute(
                () -> {
                    try {
                        disk.store(new FarTerrainTile(0, 0, 0, 1, 1, payload));
                        if ((++writes & 63) == 0) trimDisk();
                    } catch (IOException ignored) {
                    }
                });
        return result;
    }

    private void trimDisk() throws IOException {
        if (!Files.isDirectory(ROOT)) return;
        try (var files = Files.walk(ROOT, 2)) {
            var entries =
                    files.filter(path -> path.getFileName().toString().endsWith(".vlod"))
                            .sorted(
                                    java.util.Comparator.comparingLong(
                                            path -> path.toFile().lastModified()))
                            .toList();
            long bytes = 0;
            for (Path path : entries) bytes += Files.size(path);
            int remaining = entries.size();
            for (Path path : entries) {
                if (bytes <= (256L << 20) && remaining <= 1024) break;
                long size = Files.size(path);
                Files.deleteIfExists(path);
                bytes -= size;
                remaining--;
            }
        }
    }

    public String telemetry() {
        return "lod_cache_memory_hits_total="
                + HITS.sum()
                + "\nlod_cache_disk_hits_total="
                + DISK_HITS.sum()
                + "\nlod_cache_misses_total="
                + MISSES.sum()
                + "\nlod_light_only_reuses_total="
                + LIGHT_REUSES.sum()
                + "\nlod_light_only_flagged_compiles_total="
                + LIGHT_FLAGGED.sum()
                + "\nlod_light_only_fallbacks_total="
                + LIGHT_FALLBACKS.sum()
                + "\n";
    }
}
