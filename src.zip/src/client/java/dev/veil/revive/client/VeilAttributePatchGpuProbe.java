package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.terrain.AttributeUploadPlan;
import dev.veil.revive.core.terrain.RegularTerrainVertices;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

final class VeilAttributePatchGpuProbe {
    private static final boolean REQUESTED =
            Boolean.getBoolean("veil.attributePatchGpuProbe")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();

    private record Case(
            GpuBuffer original,
            GpuBuffer replacement,
            GpuBuffer oldReadback,
            GpuBuffer newReadback,
            byte[] before,
            byte[] after) {
        void close() {
            original.close();
            replacement.close();
            oldReadback.close();
            newReadback.close();
        }
    }

    private static final ArrayList<Case> cases = new ArrayList<>();
    private static GpuFence fence;
    private static boolean started, complete;
    private static int uploadedBytes;

    private VeilAttributePatchGpuProbe() {}

    static void tick() {
        if (!REQUESTED || complete) return;
        if (!started) {
            started = true;
            for (int mode = 0; mode < 4; mode++)
                for (int sparse = 0; sparse < 2; sparse++) start(mode, sparse);
            fence = RenderSystem.getDevice().createCommandEncoder().createFence();
            return;
        }
        if (!fence.awaitCompletion(0)) return;
        int verified = 0;
        for (var test : cases) {
            try (var old = test.oldReadback().map(true, false);
                    var updated = test.newReadback().map(true, false)) {
                for (int at = 0; at < test.before().length; at++)
                    if (old.data().get(at) != test.before()[at])
                        throw new IllegalStateException(
                                "Attribute patch changed original GPU buffer");
                for (int at = 0; at < test.after().length; at++)
                    if (updated.data().get(at) != test.after()[at])
                        throw new IllegalStateException("Attribute GPU replacement byte mismatch");
                verified += test.before().length + test.after().length;
            }
            test.close();
        }
        cases.clear();
        fence.close();
        fence = null;
        complete = true;
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil attribute patch GPU: PASS (cases=8 verified_bytes={} cpu_upload_bytes={} original_preserved=true)",
                verified,
                uploadedBytes);
    }

    private static void start(int mode, int sparse) {
        int count = 64;
        var canonical = ByteBuffer.allocate(count * 28).order(ByteOrder.LITTLE_ENDIAN);
        for (int vertex = 0; vertex < count; vertex++) {
            canonical.putFloat(mode == 3 ? 1.1f : 1f).putFloat(2).putFloat(3).putInt(0xff6699aa);
            canonical.putFloat(mode == 2 ? 0.1234567f : 0.5f).putFloat(0.25f).putInt(0x00f00080);
        }
        canonical.flip();
        var packed =
                mode == 0
                        ? null
                        : mode == 3
                                ? RegularTerrainVertices.encodeWide(canonical, count)
                                : RegularTerrainVertices.encode(canonical, count, mode == 1, false);
        byte[] before = mode == 0 ? canonical.array().clone() : packed.vertices().clone();
        byte[] after = before.clone();
        int stride = mode == 0 ? 28 : packed.stride(),
                color = mode == 0 ? 12 : packed.layout().colorOffset();
        var next = ByteBuffer.wrap(after).order(ByteOrder.LITTLE_ENDIAN);
        for (int vertex : new int[] {2, 61})
            next.putInt(vertex * stride + color, 0xff112233)
                    .putInt(vertex * stride + stride - 4, 0x008000f0);
        var plan =
                mode == 0
                        ? AttributeUploadPlan.canonical(
                                ByteBuffer.wrap(before), next, 0, sparse == 0 ? 16 : 1)
                        : AttributeUploadPlan.packed(
                                new RegularTerrainVertices.Result(before, packed.layout(), count),
                                new RegularTerrainVertices.Result(after, packed.layout(), count),
                                0,
                                sparse == 0 ? 16 : 1);
        if (plan.coalescedFallback() != (sparse == 1))
            throw new IllegalStateException("Attribute GPU probe did not exercise range fallback");
        var device = RenderSystem.getDevice();
        var encoder = device.createCommandEncoder();
        byte[] container = new byte[before.length + 32];
        java.util.Arrays.fill(container, (byte) 0x5a);
        System.arraycopy(before, 0, container, 16, before.length);
        var direct = MemoryUtil.memAlloc(container.length);
        var original =
                device.createBuffer(
                        () -> "Veil attribute probe original",
                        GpuBuffer.USAGE_VERTEX
                                | GpuBuffer.USAGE_COPY_SRC
                                | GpuBuffer.USAGE_COPY_DST,
                        container.length);
        try {
            direct.put(container).flip();
            encoder.writeToBuffer(original.slice(), direct);
        } finally {
            MemoryUtil.memFree(direct);
        }
        var replacement =
                VeilAttributeBufferPatch.createReplacement(original.slice(16, before.length), plan);
        var oldRead =
                device.createBuffer(
                        () -> "Veil attribute old readback",
                        GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                        container.length);
        var newRead =
                device.createBuffer(
                        () -> "Veil attribute new readback",
                        GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                        after.length);
        encoder.copyToBuffer(original.slice(), oldRead.slice());
        encoder.copyToBuffer(replacement.slice(), newRead.slice());
        cases.add(new Case(original, replacement, oldRead, newRead, container, after));
        uploadedBytes += plan.payloadBytes();
    }

    static void requireComplete() {
        if (REQUESTED && !complete)
            throw new IllegalStateException("Attribute GPU patch probe incomplete");
    }
}
