package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import org.joml.Matrix4f;

final class VeilCommandVisibilityProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.commandVisibilityProbe");
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static int[] expected;
    private static int completed;
    private static long compared, retainedInactiveCompared;

    private VeilCommandVisibilityProbe() {}

    static boolean enabled() {
        return ENABLED;
    }

    static void capture(VeilIndirectTerrain.Batch batch, VeilTerrainFrameData original) {
        if (!ENABLED || fence != null || completed == 4 || batch.sectionIndices.length < 64) return;
        if (Boolean.getBoolean("veil.residentTerrainCommands")) {
            boolean retainedInactive = false;
            for (int slot : batch.sectionIndices)
                retainedInactive |= VeilTerrainDrawBridge.inactiveResidentSlot(slot);
            if (!retainedInactive) return;
        }
        if (completed == 2) {
            int covered = 0;
            for (int section : batch.sectionIndices) covered |= 1 << (section & 3);
            if (covered != 15) return;
        }
        var synthetic = new VeilTerrainFrameData(false);
        synthetic.begin(new Matrix4f(), 1, 1, original.count());
        for (int i = 0; i < original.count(); i++) {
            float visibility =
                    completed == 0
                            ? 0.0f
                            : completed == 1
                                    ? 1.0f
                                    : switch (i % 4) {
                                        case 0 -> -0.0f;
                                        case 1 -> -0.5f;
                                        case 2 -> 0.25f;
                                        default -> Float.NaN;
                                    };
            synthetic.set(i, 0, 0, 0, visibility, true);
        }
        if (completed == 3) {
            for (int i = 0; i < original.count(); i++) synthetic.set(i, 0, 0, 0, 1.0f, true);
            synthetic.set(batch.sectionIndices[0], 0, 0, 0, 0.0f, true);
            synthetic.set(
                    batch.sectionIndices[batch.sectionIndices.length - 1], 0, 0, 0, 0.0f, true);
        }
        int words = batch.sectionIndices.length * 5;
        expected = new int[words * 2];
        for (int i = 0; i < batch.sectionIndices.length; i++) {
            int section = batch.sectionIndices[i];
            int count =
                    section >= 0
                                    && section < synthetic.count()
                                    && !(synthetic.visibility(section) <= 0.0f)
                            ? batch.indexCounts[i]
                            : 0;
            expected[i * 5] = count;
            expected[i * 5 + 1] = 1;
            expected[i * 5 + 2] = batch.firstIndices[i];
            expected[i * 5 + 3] = batch.baseVertices[i];
            expected[i * 5 + 4] = section;
            expected[words + i * 5] =
                    section >= 0
                                    && section < original.count()
                                    && !(original.visibility(section) <= 0.0f)
                            ? batch.indexCounts[i]
                            : 0;
            for (int word = 1; word < 5; word++)
                expected[words + i * 5 + word] = expected[i * 5 + word];
        }
        for (int slot : batch.sectionIndices)
            if (VeilTerrainDrawBridge.inactiveResidentSlot(slot)) retainedInactiveCompared++;
        if (VeilHzb.residentVisibilityCompactionEnabled())
            VeilIndirectTerrain.writeCommandCounts(batch, false);
        VeilIndirectTerrain.updateBatchVisibility(batch, synthetic);
        try {
            readback =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil command visibility readback",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    expected.length * 4L);
            var encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.copyToBuffer(batch.commands(), readback.slice(0, words * 4L));
        } finally {
            VeilIndirectTerrain.updateBatchVisibility(batch, original);
        }
        var encoder = RenderSystem.getDevice().createCommandEncoder();
        encoder.copyToBuffer(batch.commands(), readback.slice(words * 4L, words * 4L));
        if (VeilHzb.residentVisibilityCompactionEnabled())
            VeilIndirectTerrain.writeCommandCounts(batch, true);
        fence = encoder.createFence();
    }

    static void poll() {
        if (fence == null || !fence.awaitCompletion(0)) return;
        try (var mapped = readback.map(true, false)) {
            for (int i = 0; i < expected.length; i++) {
                if (mapped.data().getInt(i * 4) != expected[i])
                    throw new IllegalStateException(
                            "GPU command visibility differs at case=" + completed + " word=" + i);
            }
            compared += expected.length / 10;
            if (++completed == 4)
                ReviveMod.LOGGER.info(
                        "Veil command visibility GPU probe: PASS ({} commands, {} retained inactive commands; inactive, reactivation, all mixed signed zero/negative/fractional/NaN classes, separated boundary changes, original frame restored; exact GPU count and all address words)",
                        compared,
                        retainedInactiveCompared);
        } finally {
            fence.close();
            readback.close();
            fence = null;
            readback = null;
            expected = null;
        }
    }

    static void requireComplete() {
        if (ENABLED && completed != 4)
            throw new IllegalStateException(
                    "Command visibility GPU probe incomplete: " + completed);
    }
}
