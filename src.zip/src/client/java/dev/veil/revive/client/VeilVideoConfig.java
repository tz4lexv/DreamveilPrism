package dev.veil.revive.client;

import dev.veil.revive.platform.VeilPlatform;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class VeilVideoConfig {
    private static volatile Map<String, String> values = Map.of();

    private VeilVideoConfig() {}

    private static Path path() {
        return VeilPlatform.get().getConfigDir().resolve("veil-video.properties");
    }

    public static void load() {
        Properties p = new Properties();
        if (Files.exists(path()))
            try (var in = Files.newInputStream(path())) {
                p.load(in);
            } catch (IOException e) {
                dev.veil.revive.ReviveMod.LOGGER.warn("Could not load Veil video settings", e);
            }
        Map<String, String> next = new HashMap<>();
        p.forEach((k, v) -> next.put(k.toString(), v.toString()));
        values = Map.copyOf(next);
        VeilVisibilityBudget.resetConfigCaches();
        VeilLeafCulling.refreshConfig();
        VeilShaderLimits.refreshConfig();
    }

    public static Map<String, String> snapshot() {
        return values;
    }

    public static String value(String key, String fallback) {
        return values.getOrDefault(key, fallback);
    }

    public static boolean on(String key) {
        return !"false".equals(values.get(key));
    }

    public static boolean flag(String key, boolean fallback) {
        String value = values.get(key);
        return value == null ? fallback : Boolean.parseBoolean(value);
    }

    public static int number(String key, int fallback, int min, int max) {
        try {
            return Math.clamp(
                    Integer.parseInt(values.getOrDefault(key, Integer.toString(fallback))),
                    min,
                    max);
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public static void save(Map<String, String> next) throws IOException {
        Files.createDirectories(path().getParent());
        Path temp = path().resolveSibling("veil-video.properties.tmp");
        Properties p = new Properties();
        p.putAll(next);
        try (var out = Files.newOutputStream(temp)) {
            p.store(out, "Veil video settings");
        }
        try {
            Files.move(
                    temp,
                    path(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(temp, path(), StandardCopyOption.REPLACE_EXISTING);
        }
        values = Map.copyOf(next);
        VeilVisibilityBudget.resetConfigCaches();
        VeilLeafCulling.refreshConfig();
        VeilShaderLimits.refreshConfig();
    }

    public static boolean animation(net.minecraft.resources.Identifier name) {
        String p = name.getPath();
        String group =
                p.contains("water")
                        ? "water"
                        : p.contains("lava")
                                ? "lava"
                                : p.contains("fire")
                                        ? "fire"
                                        : p.contains("portal")
                                                ? "portal"
                                                : p.contains("sculk") ? "sculk" : "other";
        return on("animation.all") && on("animation." + group);
    }
}
