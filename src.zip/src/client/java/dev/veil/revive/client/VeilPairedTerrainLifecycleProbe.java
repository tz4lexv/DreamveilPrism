package dev.veil.revive.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

final class VeilPairedTerrainLifecycleProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.verifyProgressivePairLifecycle")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static SectionRenderDispatcher.RenderSection section;
    private static SectionMesh previous;
    private static BlockPos position;
    private static volatile BlockState original, edited;
    private static long started;
    private static long lastStatus;
    private static int phase;

    static void tick(Minecraft client, List<SectionRenderDispatcher.RenderSection> visible) {
        if (!ENABLED || phase == 3 || client.level == null) return;
        var server = client.getSingleplayerServer();
        if (server == null
                || !server.getWorldData().getLevelName().startsWith("Veil-Benchmark-26.2-"))
            throw new IllegalStateException("Paired edits require dedicated benchmark world");
        long now = System.nanoTime();
        if (started == 0) started = now;
        if (now - started > 100_000_000_000L) {
            if (original != null)
                server.execute(() -> server.overworld().setBlock(position, original, 3));
            throw new IllegalStateException("Paired lifecycle timed out at " + phase);
        }
        if (section == null) {
            if (now - started < 24_000_000_000L) return;
            if (now - started > 55_000_000_000L)
                throw new IllegalStateException(
                        "No paired lifecycle candidate in stable camera window");
            for (var candidate : visible) {
                var origin = candidate.getRenderOrigin();
                if (Math.abs(origin.getX() - client.player.getX()) > 64
                        || Math.abs(origin.getZ() - client.player.getZ()) > 64
                        || VeilPairedTerrainArena.get(
                                        candidate.getSectionMesh(), ChunkSectionLayer.SOLID)
                                == null) continue;
                BlockPos target = null;
                for (var block : BlockPos.betweenClosed(origin, origin.offset(15, 15, 15))) {
                    var state = client.level.getBlockState(block);
                    if (!state.is(Blocks.STONE) && !state.is(Blocks.DIRT)) continue;
                    boolean exposed = false;
                    for (var direction : net.minecraft.core.Direction.values()) {
                        var neighbor = client.level.getBlockState(block.relative(direction));
                        if (neighbor.isAir() || !neighbor.getFluidState().isEmpty()) {
                            exposed = true;
                            break;
                        }
                    }
                    if (exposed) {
                        target = block.immutable();
                        break;
                    }
                }
                if (target == null) continue;
                section = candidate;
                previous = candidate.getSectionMesh();
                position = target;
                phase = 1;
                server.execute(
                        () -> {
                            original = server.overworld().getBlockState(position);
                            edited =
                                    original.is(Blocks.STONE)
                                            ? Blocks.DIRT.defaultBlockState()
                                            : Blocks.STONE.defaultBlockState();
                            server.overworld().setBlock(position, edited, 3);
                        });
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil paired edit: requested block change at {}", position);
                return;
            }
            return;
        }
        var replacement = section.getSectionMesh();
        if (now - lastStatus > 10_000_000_000L) {
            lastStatus = now;
            var metadata =
                    replacement instanceof VeilMeshExtras extras ? extras.veil$metadata() : null;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil paired edit status: phase={} position={} original={} edited={} client={} replaced={} native_solid={} pair_ready={} gpu_owner={} paired_enabled={} native_uploaded={} admission_failure={} visible={} submitted={} previous_submitted={} origin={}",
                    phase,
                    position,
                    original,
                    edited,
                    client.level.getBlockState(position),
                    replacement != previous,
                    replacement.getSectionDraw(ChunkSectionLayer.SOLID) != null,
                    metadata != null && metadata.pairedTerrain(ChunkSectionLayer.SOLID) != null,
                    VeilPairedTerrainArena.hasOwner(replacement),
                    VeilPairedTerrainArena.enabled(),
                    replacement
                                    instanceof
                                    net.minecraft.client.renderer.chunk.CompiledSectionMesh compiled
                            && compiled.isVertexBufferUploaded(ChunkSectionLayer.SOLID),
                    VeilPairedTerrainArena.failureReason(replacement, ChunkSectionLayer.SOLID),
                    visible.contains(section),
                    VeilIndirectTerrain.submissionContainsMesh(replacement),
                    VeilIndirectTerrain.submissionContainsMesh(previous),
                    section.getRenderOrigin());
        }
        if (original == null
                || replacement == previous
                || VeilPairedTerrainArena.get(replacement, ChunkSectionLayer.SOLID) == null
                || !VeilPairedTerrainArena.verifyGpuPair(replacement, ChunkSectionLayer.SOLID)
                || !client.level.getBlockState(position).equals(phase == 1 ? edited : original))
            return;
        if (!(previous instanceof VeilMeshExtras extras)
                || !extras.veil$metadata().closed()
                || extras.veil$metadata().progressiveReady()
                || VeilPairedTerrainArena.hasOwner(previous))
            throw new IllegalStateException("Closed paired owner retained result or allocations");
        if (phase == 1) {
            previous = replacement;
            phase = 2;
            server.execute(() -> server.overworld().setBlock(position, original, 3));
        } else {
            phase = 3;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil paired lifecycle: PASS (two native replacements with GPU byte parity, block restored, closed results and old mesh draw owners empty)");
        }
    }

    static void requireComplete() {
        if (ENABLED && phase != 3)
            throw new IllegalStateException("Paired lifecycle incomplete at " + phase);
    }
}
