package dev.veil.revive.client.shaderpack.reload;

import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;

public final class ReloadCoordinator<P, G extends ReloadCoordinator.Generation>
        implements AutoCloseable {
    @FunctionalInterface
    public interface Preparation<P> {
        P prepare() throws java.io.IOException;
    }

    public interface Generation extends AutoCloseable {
        @Override
        void close();
    }

    private record Prepared<P>(long revision, P value, Throwable failure) {}

    private final Executor worker;
    private final Function<P, G> install;
    private final Runnable reloadSuccess;
    private final Runnable reloadFailure;
    private final Thread owner = Thread.currentThread();
    private final AtomicLong requested = new AtomicLong();
    private final AtomicReference<Prepared<P>> pending = new AtomicReference<>();
    private volatile boolean closed;
    private volatile String diagnostic = "No shader pack loaded";
    private volatile long settled;
    private volatile boolean failed;
    private G active;

    public ReloadCoordinator(
            Executor worker,
            Function<P, G> install,
            Runnable reloadSuccess,
            Runnable reloadFailure) {
        this.worker = Objects.requireNonNull(worker, "worker");
        this.install = Objects.requireNonNull(install, "install");
        this.reloadSuccess = Objects.requireNonNull(reloadSuccess, "reloadSuccess");
        this.reloadFailure = Objects.requireNonNull(reloadFailure, "reloadFailure");
    }

    public synchronized long request(Preparation<P> prepare) {
        if (closed) throw new IllegalStateException("Shader reload is closed");
        long revision = requested.incrementAndGet();
        failed = false;
        worker.execute(
                () -> {
                    if (closed || requested.get() != revision) return;
                    Prepared<P> result;
                    try {
                        result =
                                new Prepared<>(
                                        revision,
                                        Objects.requireNonNull(
                                                prepare.prepare(), "prepared generation"),
                                        null);
                    } catch (java.io.IOException | RuntimeException failure) {
                        result = new Prepared<>(revision, null, failure);
                    }
                    completed(result);
                });
        return revision;
    }

    private synchronized void completed(Prepared<P> result) {
        if (!closed && requested.get() == result.revision()) pending.set(result);
    }

    public synchronized boolean publishAtFrameBoundary() {
        checkOwner();
        if (closed) return false;
        Prepared<P> prepared = pending.getAndSet(null);
        if (prepared == null || prepared.revision() != requested.get()) return false;
        if (prepared.failure() != null) {
            fail(prepared.failure());
            return false;
        }
        G replacement;
        try {
            replacement =
                    Objects.requireNonNull(install.apply(prepared.value()), "installed generation");
        } catch (RuntimeException failure) {
            fail(failure);
            return false;
        }
        if (closed || prepared.revision() != requested.get()) {
            replacement.close();
            return false;
        }
        G previous = active;
        active = replacement;
        settled = prepared.revision();
        diagnostic = "Generation " + prepared.revision() + " published";
        reloadSuccess.run();
        if (previous != null) previous.close();
        return true;
    }

    private void fail(Throwable failure) {
        settled = requested.get();
        failed = true;
        reloadFailure.run();
        diagnostic = failure.getClass().getSimpleName() + ": " + failure.getMessage();
    }

    public G active() {
        checkOwner();
        return active;
    }

    public String diagnostic() {
        return diagnostic;
    }

    public boolean isPending() {
        return !closed && settled < requested.get();
    }

    public boolean failed() {
        return failed;
    }

    @Override
    public synchronized void close() {
        checkOwner();
        closed = true;
        requested.incrementAndGet();
        pending.set(null);
        if (active != null) {
            G previous = active;
            active = null;
            previous.close();
        }
    }

    private void checkOwner() {
        if (Thread.currentThread() != owner)
            throw new IllegalStateException(
                    "Shader GPU generations must stay on their owner thread");
    }
}
