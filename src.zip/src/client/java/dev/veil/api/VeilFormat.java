package dev.veil.api;

public enum VeilFormat {
    R8_UNORM(1, 1, NumericType.UNORM, false, false, false, true, true, true),
    R8_SNORM(1, 1, NumericType.SNORM, false, false, false, true, true, true),
    RG8_UNORM(2, 2, NumericType.UNORM, false, false, false, true, true, true),
    RG8_SNORM(2, 2, NumericType.SNORM, false, false, false, true, true, true),
    RGB8_UNORM(3, 3, NumericType.UNORM, false, false, false, false, true, true),
    RGB8_SNORM(3, 3, NumericType.SNORM, false, false, false, false, true, true),
    RGBA8_UNORM(4, 4, NumericType.UNORM, false, false, false, true, true, true),
    RGBA8_SNORM(4, 4, NumericType.SNORM, false, false, false, true, true, true),
    RGBA8_SRGB(4, 4, NumericType.SRGB, false, false, true, false, true, true),
    R16_UNORM(2, 1, NumericType.UNORM, false, false, false, true, true, true),
    R16_SNORM(2, 1, NumericType.SNORM, false, false, false, true, true, true),
    RG16_UNORM(4, 2, NumericType.UNORM, false, false, false, true, true, true),
    RG16_SNORM(4, 2, NumericType.SNORM, false, false, false, true, true, true),
    RGB16_UNORM(6, 3, NumericType.UNORM, false, false, false, false, true, true),
    RGB16_SNORM(6, 3, NumericType.SNORM, false, false, false, false, true, true),
    RGBA16_UNORM(8, 4, NumericType.UNORM, false, false, false, true, true, true),
    RGBA16_SNORM(8, 4, NumericType.SNORM, false, false, false, true, true, true),
    R8_UINT(1, 1, NumericType.UINT, false, false, false, true, false, true),
    R8_SINT(1, 1, NumericType.SINT, false, false, false, true, false, true),
    RG8_UINT(2, 2, NumericType.UINT, false, false, false, true, false, true),
    RG8_SINT(2, 2, NumericType.SINT, false, false, false, true, false, true),
    RGB8_UINT(3, 3, NumericType.UINT, false, false, false, false, false, true),
    RGB8_SINT(3, 3, NumericType.SINT, false, false, false, false, false, true),
    RGBA8_UINT(4, 4, NumericType.UINT, false, false, false, true, false, true),
    RGBA8_SINT(4, 4, NumericType.SINT, false, false, false, true, false, true),
    R16_UINT(2, 1, NumericType.UINT, false, false, false, true, false, true),
    R16_SINT(2, 1, NumericType.SINT, false, false, false, true, false, true),
    RG16_UINT(4, 2, NumericType.UINT, false, false, false, true, false, true),
    RG16_SINT(4, 2, NumericType.SINT, false, false, false, true, false, true),
    RGB16_UINT(6, 3, NumericType.UINT, false, false, false, false, false, true),
    RGB16_SINT(6, 3, NumericType.SINT, false, false, false, false, false, true),
    RGBA16_UINT(8, 4, NumericType.UINT, false, false, false, true, false, true),
    RGBA16_SINT(8, 4, NumericType.SINT, false, false, false, true, false, true),
    R32_UINT(4, 1, NumericType.UINT, false, false, false, true, false, true),
    R32_SINT(4, 1, NumericType.SINT, false, false, false, true, false, true),
    RG32_UINT(8, 2, NumericType.UINT, false, false, false, true, false, true),
    RG32_SINT(8, 2, NumericType.SINT, false, false, false, true, false, true),
    RGB32_UINT(12, 3, NumericType.UINT, false, false, false, false, false, true),
    RGB32_SINT(12, 3, NumericType.SINT, false, false, false, false, false, true),
    RGBA32_UINT(16, 4, NumericType.UINT, false, false, false, true, false, true),
    RGBA32_SINT(16, 4, NumericType.SINT, false, false, false, true, false, true),
    R16_FLOAT(2, 1, NumericType.FLOAT, false, false, false, true, true, true),
    RG16_FLOAT(4, 2, NumericType.FLOAT, false, false, false, true, true, true),
    RGB16_FLOAT(6, 3, NumericType.FLOAT, false, false, false, false, true, true),
    RGBA16_FLOAT(8, 4, NumericType.FLOAT, false, false, false, true, true, true),
    R32_FLOAT(4, 1, NumericType.FLOAT, false, false, false, true, true, true),
    RG32_FLOAT(8, 2, NumericType.FLOAT, false, false, false, true, true, true),
    RGB32_FLOAT(12, 3, NumericType.FLOAT, false, false, false, false, true, true),
    RGBA32_FLOAT(16, 4, NumericType.FLOAT, false, false, false, true, true, true),
    RGB10A2_UNORM(4, 4, NumericType.UNORM, false, false, false, true, true, true),
    RGB10A2_UINT(4, 4, NumericType.UINT, false, false, false, true, false, true),
    RG11B10_FLOAT(4, 3, NumericType.FLOAT, false, false, false, true, true, true),
    D16_UNORM(2, 1, NumericType.DEPTH, true, false, false, false, true, true),
    D32_FLOAT(4, 1, NumericType.DEPTH, true, false, false, false, true, true),
    D24_UNORM_S8_UINT(4, 2, NumericType.DEPTH_STENCIL, true, true, false, false, false, true),
    D32_FLOAT_S8_UINT(8, 2, NumericType.DEPTH_STENCIL, true, true, false, false, false, true),
    S8_UINT(1, 1, NumericType.STENCIL, false, true, false, false, false, true);

    public enum NumericType {
        UNORM,
        SNORM,
        UINT,
        SINT,
        FLOAT,
        SRGB,
        DEPTH,
        STENCIL,
        DEPTH_STENCIL
    }

    private final int bytesPerTexel;
    private final int channels;
    private final NumericType numericType;
    private final boolean depth;
    private final boolean stencil;
    private final boolean srgb;
    private final boolean storageCandidate;
    private final boolean filterableCandidate;
    private final boolean renderableCandidate;

    VeilFormat(
            int bytesPerTexel,
            int channels,
            NumericType numericType,
            boolean depth,
            boolean stencil,
            boolean srgb,
            boolean storageCandidate,
            boolean filterableCandidate,
            boolean renderableCandidate) {
        this.bytesPerTexel = bytesPerTexel;
        this.channels = channels;
        this.numericType = numericType;
        this.depth = depth;
        this.stencil = stencil;
        this.srgb = srgb;
        this.storageCandidate = storageCandidate;
        this.filterableCandidate = filterableCandidate;
        this.renderableCandidate = renderableCandidate;
    }

    public int bytesPerTexel() {
        return bytesPerTexel;
    }

    public int channels() {
        return channels;
    }

    public NumericType numericType() {
        return numericType;
    }

    public boolean color() {
        return !depth && !stencil;
    }

    public boolean depth() {
        return depth;
    }

    public boolean stencil() {
        return stencil;
    }

    public boolean srgb() {
        return srgb;
    }

    public boolean storageCandidate() {
        return storageCandidate;
    }

    public boolean filterableCandidate() {
        return filterableCandidate;
    }

    public boolean renderableCandidate() {
        return renderableCandidate;
    }

    public boolean vertexCandidate() {
        if (!color() || srgb) return false;
        return switch (this) {
            case RGB8_UNORM,
                    RGB8_SNORM,
                    RGB8_UINT,
                    RGB8_SINT,
                    RGB16_UNORM,
                    RGB16_SNORM,
                    RGB16_UINT,
                    RGB16_SINT,
                    RGB16_FLOAT,
                    RGB10A2_UNORM,
                    RGB10A2_UINT,
                    RG11B10_FLOAT ->
                    false;
            default -> true;
        };
    }
}
