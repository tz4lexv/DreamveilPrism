package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilAnimatedSpriteUsage;
import dev.veil.revive.client.VeilVideoConfig;

import net.fabricmc.fabric.api.client.renderer.v1.mesh.QuadView;
import net.fabricmc.fabric.api.client.renderer.v1.sprite.FabricTextureAtlas;
import net.minecraft.client.Minecraft;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets = "net.fabricmc.fabric.impl.client.indigo.renderer.mesh.QuadViewImpl", remap = false)
public abstract class FabricAnimatedQuadUsageMixin {
    @Inject(
            method = {
                "buffer(ILcom/mojang/blaze3d/vertex/VertexConsumer;)V",
                "buffer(ILcom/mojang/blaze3d/vertex/PoseStack$Pose;Lcom/mojang/blaze3d/vertex/VertexConsumer;)V"
            },
            at = @At("HEAD"),
            require = 1)
    private void veil$recordAnimatedQuad(CallbackInfo ci) {
        if (!ReviveRuntime.optimizationsEnabled() || !VeilVideoConfig.on("animation.visibleOnly"))
            return;
        var quad = (QuadView) (Object) this;
        if (!quad.animated()) return;
        var atlas = Minecraft.getInstance().getAtlasManager().getAtlasOrThrow(quad.atlas().getId());
        var finder = ((FabricTextureAtlas) (Object) atlas).spriteFinder();
        VeilAnimatedSpriteUsage.recordOrMark(finder.find(quad));
    }
}
