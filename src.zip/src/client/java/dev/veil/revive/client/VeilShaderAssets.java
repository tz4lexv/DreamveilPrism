package dev.veil.revive.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

@FunctionalInterface
public interface VeilShaderAssets {
    static long maxAssetBytes() {
        return VeilShaderLimits.current().bufferBytes();
    }

    int MAX_SHADER_ASSET_BYTES = 4 * 1024 * 1024;
    int MAX_PACK_FILES = 4096;

    static long maxArchiveBytes() {
        return VeilShaderLimits.current().packBytes();
    }

    byte[] read(VeilShaderId id) throws IOException;

    default String text(VeilShaderId id) throws IOException {
        byte[] bytes = read(id);
        if (bytes.length > MAX_SHADER_ASSET_BYTES)
            throw new IOException("Text shader asset exceeds 4 MiB: " + id);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    default boolean contains(VeilShaderId id) throws IOException {
        try {
            read(id);
            return true;
        } catch (java.nio.file.NoSuchFileException missing) {
            return false;
        }
    }

    default List<String> entries(String namespace) throws IOException {
        throw new IOException("Shader asset source cannot list entries");
    }

    static VeilShaderAssets classpath() {
        return id -> {
            String path = "/assets/" + id.namespace() + "/" + id.path();
            try (var stream = VeilShaderAssets.class.getResourceAsStream(path)) {
                if (stream == null) throw new java.nio.file.NoSuchFileException(id.toString());
                return readBounded(stream, id.toString());
            }
        };
    }

    static VeilShaderAssets external(Path path, String namespace) throws IOException {
        Path source = path.toRealPath();
        if (Files.isDirectory(source)) return directory(source, namespace);
        if (Files.isRegularFile(source) && isZip(source)) return archive(source, namespace);
        throw new IOException("Shader pack must be a directory or .zip archive: " + source);
    }

    static VeilShaderAssets directory(Path root, String namespace) throws IOException {
        Path canonicalRoot = root.toRealPath();
        VeilShaderAssets official = classpath();
        return new VeilShaderAssets() {
            @Override
            public byte[] read(VeilShaderId id) throws IOException {
                if (id.namespace().equals("veil")) return official.read(id);
                requireNamespace(id, namespace);
                Path unresolved = canonicalRoot.resolve(id.path());
                if (!Files.isRegularFile(unresolved))
                    throw new java.nio.file.NoSuchFileException(id.toString());
                Path file = unresolved.toRealPath();
                if (!file.startsWith(canonicalRoot))
                    throw new IOException("Shader asset escapes pack root: " + id);
                try (var stream = Files.newInputStream(file)) {
                    return readBounded(stream, id.toString());
                }
            }

            @Override
            public boolean contains(VeilShaderId id) throws IOException {
                if (id.namespace().equals("veil")) return official.contains(id);
                requireNamespace(id, namespace);
                Path candidate = canonicalRoot.resolve(id.path()).normalize();
                return candidate.startsWith(canonicalRoot) && Files.isRegularFile(candidate);
            }

            @Override
            public List<String> entries(String requestedNamespace) throws IOException {
                if (!namespace.equals(requestedNamespace))
                    throw new IOException("Unknown shader namespace: " + requestedNamespace);
                try (var files = Files.walk(canonicalRoot, 32)) {
                    List<String> result =
                            files.filter(Files::isRegularFile)
                                    .limit(MAX_PACK_FILES + 1L)
                                    .map(canonicalRoot::relativize)
                                    .map(Path::toString)
                                    .map(value -> value.replace('\\', '/'))
                                    .sorted()
                                    .toList();
                    if (result.size() > MAX_PACK_FILES)
                        throw new IOException("External pack exceeds " + MAX_PACK_FILES + " files");
                    return result;
                }
            }
        };
    }

    static VeilShaderAssets archive(Path path, String namespace) throws IOException {
        Path archive = path.toRealPath();
        ArchiveIndex index = indexArchive(archive);
        VeilShaderAssets official = classpath();
        return new VeilShaderAssets() {
            @Override
            public byte[] read(VeilShaderId id) throws IOException {
                if (id.namespace().equals("veil")) return official.read(id);
                requireNamespace(id, namespace);
                String logical = normalizeEntry(id.path());
                String physical = index.prefix() + logical;
                if (!index.entries().contains(logical))
                    throw new java.nio.file.NoSuchFileException(id.toString());
                try (var zip = new ZipFile(archive.toFile())) {
                    ZipEntry entry = zip.getEntry(physical);
                    if (entry == null || entry.isDirectory())
                        throw new java.nio.file.NoSuchFileException(id.toString());
                    if (entry.getSize() > maxAssetBytes())
                        throw new IOException(
                                "Shader asset exceeds configured asset budget: " + id);
                    try (var stream = zip.getInputStream(entry)) {
                        return readBounded(stream, id.toString());
                    }
                }
            }

            @Override
            public boolean contains(VeilShaderId id) throws IOException {
                if (id.namespace().equals("veil")) return official.contains(id);
                requireNamespace(id, namespace);
                return index.entries().contains(normalizeEntry(id.path()));
            }

            @Override
            public List<String> entries(String requestedNamespace) throws IOException {
                if (!namespace.equals(requestedNamespace))
                    throw new IOException("Unknown shader namespace: " + requestedNamespace);
                return index.entries();
            }
        };
    }

    static VeilShaderAssets bundledPack(String folder, String namespace) {
        VeilShaderAssets bundled = classpath();
        return new VeilShaderAssets() {
            @Override
            public byte[] read(VeilShaderId id) throws IOException {
                if (id.namespace().equals("veil")) return bundled.read(id);
                requireNamespace(id, namespace);
                return bundled.read(
                        new VeilShaderId("veil", "shaderpacks/" + folder + "/" + id.path()));
            }

            @Override
            public List<String> entries(String requestedNamespace) throws IOException {
                if (!namespace.equals(requestedNamespace))
                    throw new IOException("Unknown shader namespace: " + requestedNamespace);
                return bundled.text(
                                new VeilShaderId(
                                        "veil", "shaderpacks/" + folder + "/slang-index.txt"))
                        .lines()
                        .filter(line -> !line.isBlank())
                        .toList();
            }
        };
    }

    static boolean isExternalPack(Path path) {
        try {
            if (Files.isDirectory(path)) {
                if (Files.isRegularFile(path.resolve("veilpack.json"))
                        || Files.isRegularFile(path.resolve("veil.properties"))
                        || Files.isRegularFile(path.resolve("pipeline.toml"))) return true;
                Path shaders = path.resolve("shaders");
                return Files.isDirectory(shaders) && hasShaderFile(shaders);
            }
            return Files.isRegularFile(path)
                    && isZip(path)
                    && !indexArchive(path).entries().isEmpty();
        } catch (IOException | RuntimeException ignored) {
            return false;
        }
    }

    static boolean isShaderSource(String path) {
        String lower = path.toLowerCase(Locale.ROOT);
        return lower.endsWith(".vert")
                || lower.endsWith(".frag")
                || lower.endsWith(".comp")
                || lower.endsWith(".geom")
                || lower.endsWith(".tesc")
                || lower.endsWith(".tese")
                || lower.endsWith(".task")
                || lower.endsWith(".mesh")
                || lower.endsWith(".rgen")
                || lower.endsWith(".rmiss")
                || lower.endsWith(".rchit")
                || lower.endsWith(".rahit")
                || lower.endsWith(".rint")
                || lower.endsWith(".rcall")
                || lower.endsWith(".glsl")
                || lower.endsWith(".spv")
                || lower.endsWith(".slang");
    }

    static String hash(byte[] bytes) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }

    private static ArchiveIndex indexArchive(Path archive) throws IOException {
        var physical = new ArrayList<String>();
        var unique = new LinkedHashSet<String>();
        long declaredBytes = 0;
        try (var zip = new ZipFile(archive.toFile())) {
            var entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.isDirectory()) continue;
                if (physical.size() >= MAX_PACK_FILES)
                    throw new IOException("Shader archive exceeds " + MAX_PACK_FILES + " files");
                String name = normalizeEntry(entry.getName());
                if (!unique.add(name))
                    throw new IOException("Shader archive contains duplicate entry " + name);
                long size = entry.getSize();
                if (size > maxAssetBytes())
                    throw new IOException("Shader asset exceeds configured asset budget: " + name);
                if (size >= 0) {
                    declaredBytes = Math.addExact(declaredBytes, size);
                    if (declaredBytes > maxArchiveBytes())
                        throw new IOException(
                                "Shader archive exceeds configured uncompressed pack budget");
                }
                physical.add(name);
            }
        } catch (ArithmeticException overflow) {
            throw new IOException("Shader archive size overflow", overflow);
        }
        String prefix = archivePrefix(physical);
        var logical = new ArrayList<String>();
        for (String entry : physical)
            if (entry.startsWith(prefix)) logical.add(entry.substring(prefix.length()));
        logical.removeIf(String::isEmpty);
        logical.sort(String::compareTo);
        if (!hasPackMarker(logical))
            throw new IOException("ZIP does not contain a Veil shader pack root");
        return new ArchiveIndex(prefix, List.copyOf(logical));
    }

    private static String archivePrefix(List<String> entries) throws IOException {
        if (hasPackMarker(entries)) return "";
        Set<String> roots = new LinkedHashSet<>();
        for (String entry : entries) {
            int slash = entry.indexOf('/');
            if (slash > 0) roots.add(entry.substring(0, slash + 1));
        }
        String match = null;
        for (String root : roots) {
            List<String> nested =
                    entries.stream()
                            .filter(value -> value.startsWith(root))
                            .map(value -> value.substring(root.length()))
                            .toList();
            if (!hasPackMarker(nested)) continue;
            if (match != null) throw new IOException("ZIP contains multiple shader pack roots");
            match = root;
        }
        if (match == null)
            throw new IOException(
                    "ZIP does not contain shaders/, veil.properties, pipeline.toml or veilpack.json");
        return match;
    }

    private static boolean hasPackMarker(List<String> entries) {
        return entries.contains("veilpack.json")
                || entries.contains("veil.properties")
                || entries.contains("pipeline.toml")
                || entries.stream()
                        .anyMatch(value -> value.startsWith("shaders/") && isShaderSource(value));
    }

    private static boolean hasShaderFile(Path root) throws IOException {
        try (var files = Files.walk(root, 16)) {
            return files.filter(Files::isRegularFile)
                    .map(Path::toString)
                    .anyMatch(VeilShaderAssets::isShaderSource);
        }
    }

    private static boolean isZip(Path path) {
        return path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".zip");
    }

    private static String normalizeEntry(String value) throws IOException {
        String path = value.replace('\\', '/');
        if (path.isBlank()
                || path.startsWith("/")
                || path.endsWith("/")
                || path.indexOf('\0') >= 0) {
            throw new IOException("Invalid shader archive entry " + value);
        }
        String[] segments = path.split("/", -1);
        for (String segment : segments) {
            if (segment.isEmpty() || segment.equals(".") || segment.equals("..")) {
                throw new IOException("Noncanonical shader archive entry " + value);
            }
        }
        return String.join("/", segments);
    }

    private static byte[] readBounded(InputStream stream, String label) throws IOException {
        var output = new ByteArrayOutputStream();
        byte[] buffer = new byte[16 * 1024];
        int total = 0;
        while (true) {
            int count = stream.read(buffer);
            if (count < 0) break;
            total = Math.addExact(total, count);
            if (total > maxAssetBytes())
                throw new IOException("Shader asset exceeds configured asset budget: " + label);
            output.write(buffer, 0, count);
        }
        return output.toByteArray();
    }

    private static void requireNamespace(VeilShaderId id, String namespace) throws IOException {
        if (!id.namespace().equals(namespace))
            throw new IOException("Unknown shader namespace: " + id);
    }

    record ArchiveIndex(String prefix, List<String> entries) {}
}
