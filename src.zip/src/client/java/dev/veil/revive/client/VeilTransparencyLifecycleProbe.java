package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.CompiledSectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class VeilTransparencyLifecycleProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.transparencyLifecycleProbe")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final AtomicBoolean CANCEL_CLAIMED = new AtomicBoolean(),
            CANCEL_VERIFIED = new AtomicBoolean();
    private static SectionRenderDispatcher.RenderSection section;
    private static CompiledSectionMesh previous;
    private static BlockPos position;
    private static volatile BlockState originalBlock;
    private static long started;
    private static int phase;

    private VeilTransparencyLifecycleProbe() {}

    public static boolean claimCancellation() {
        return ENABLED && CANCEL_CLAIMED.compareAndSet(false, true);
    }

    public static void verifyCancellation(
            boolean cancelled, VeilTransparencyOrder before, CompiledSectionMesh mesh) {
        boolean closed = mesh instanceof VeilMeshExtras extras && extras.veil$metadata().closed();
        if (!cancelled
                || (!closed && ((VeilTransparencyExtras) mesh).veil$transparencyOrder() != before))
            throw new IllegalStateException(
                    "Cancelled native transparency task published a candidate order");
        CANCEL_VERIFIED.set(true);
        ReviveMod.LOGGER.info(
                "Veil transparency cancellation: PASS (native candidate built, task cancelled, cached order not published)");
    }

    static void tick(Minecraft client, List<SectionRenderDispatcher.RenderSection> visible) {
        if (!ENABLED || phase == 3 || client.level == null) return;
        var server = client.getSingleplayerServer();
        if (server == null
                || !server.getWorldData().getLevelName().startsWith("Veil-Benchmark-26.2-"))
            throw new IllegalStateException(
                    "Transparency edits require the dedicated benchmark world");
        long now = System.nanoTime();
        if (started == 0) started = now;
        if (now - started > 100_000_000_000L)
            throw new IllegalStateException(
                    "Transparency mesh replacement probe timed out at phase " + phase);
        if (section == null) {
            if (now - started < 12_000_000_000L) return;
            for (var candidate : visible) {
                if (!(candidate.getSectionMesh() instanceof CompiledSectionMesh mesh)
                        || mesh.getTransparencyState() == null
                        || mesh.getTransparencyState().centroids().size() < 2
                        || ((VeilTransparencyExtras) mesh).veil$transparencyOrder() == null)
                    continue;
                var origin = candidate.getRenderOrigin();
                if (Math.abs(origin.getX() - client.player.getX()) > 64
                        || Math.abs(origin.getZ() - client.player.getZ()) > 64) continue;
                section = candidate;
                previous = mesh;
                position = origin.offset(8, 15, 8);
                phase = 1;
                server.execute(
                        () -> {
                            var level = server.overworld();
                            originalBlock = level.getBlockState(position);
                            level.setBlock(
                                    position,
                                    Blocks.STAINED_GLASS
                                            .pick(net.minecraft.world.item.DyeColor.BLUE)
                                            .defaultBlockState(),
                                    3);
                        });
                ReviveMod.LOGGER.info(
                        "Veil transparency edit probe: requested glass at {}", position);
                return;
            }
            return;
        }
        if (originalBlock == null
                || !(section.getSectionMesh() instanceof CompiledSectionMesh replacement)
                || replacement == previous
                || replacement.getTransparencyState() == null) return;
        boolean blockReady =
                phase == 1
                        ? client.level
                                .getBlockState(position)
                                .is(
                                        Blocks.STAINED_GLASS.pick(
                                                net.minecraft.world.item.DyeColor.BLUE))
                        : client.level.getBlockState(position).equals(originalBlock);
        if (!blockReady) return;
        if (!(previous instanceof VeilMeshExtras extras)
                || !extras.veil$metadata().closed()
                || ((VeilTransparencyExtras) previous).veil$transparencyOrder() != null)
            throw new IllegalStateException("Retired transparency mesh retained cached order");
        if (phase == 1) {
            previous = replacement;
            phase = 2;
            server.execute(() -> server.overworld().setBlock(position, originalBlock, 3));
            ReviveMod.LOGGER.info(
                    "Veil transparency edit probe: requested original block restoration");
        } else {
            phase = 3;
            ReviveMod.LOGGER.info(
                    "Veil transparency edit probe: PASS (two native mesh replacements, original block restored, retired cached orders empty)");
        }
    }

    static void requireComplete() {
        if (ENABLED && (phase != 3 || !CANCEL_VERIFIED.get()))
            throw new IllegalStateException(
                    "Transparency lifecycle incomplete: phase="
                            + phase
                            + " cancellation="
                            + CANCEL_VERIFIED.get());
    }
}
