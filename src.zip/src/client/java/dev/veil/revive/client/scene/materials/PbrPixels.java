package dev.veil.revive.client.scene.materials;

public final class PbrPixels {
    private PbrPixels() {}

    public static int downsample(int a, int b, int c, int d, boolean specular) {
        int red = average(channel(a, 16), channel(b, 16), channel(c, 16), channel(d, 16));
        int green =
                specular
                        ? groupedAverage(a, b, c, d, 8)
                        : average(channel(a, 8), channel(b, 8), channel(c, 8), channel(d, 8));
        int blue =
                specular
                        ? groupedAverage(a, b, c, d, 0)
                        : average(channel(a, 0), channel(b, 0), channel(c, 0), channel(d, 0));
        int alpha =
                specular
                        ? ((a >>> 24) == 255
                                        && (b >>> 24) == 255
                                        && (c >>> 24) == 255
                                        && (d >>> 24) == 255
                                ? 255
                                : average(emission(a), emission(b), emission(c), emission(d)))
                        : average(a >>> 24, b >>> 24, c >>> 24, d >>> 24);
        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    private static int channel(int pixel, int shift) {
        return pixel >>> shift & 255;
    }

    private static int average(int a, int b, int c, int d) {
        return (a + b + c + d + 2) / 4;
    }

    private static int emission(int pixel) {
        int value = pixel >>> 24;
        return value == 255 ? 0 : value;
    }

    private static int category(int value, int shift) {
        return shift == 8 ? value < 230 ? -1 : value : value <= 64 ? 0 : 1;
    }

    private static int votes(int category, int a, int b, int c, int d) {
        return (category == a ? 1 : 0)
                + (category == b ? 1 : 0)
                + (category == c ? 1 : 0)
                + (category == d ? 1 : 0);
    }

    private static int groupedAverage(int a, int b, int c, int d, int shift) {
        a = channel(a, shift);
        b = channel(b, shift);
        c = channel(c, shift);
        d = channel(d, shift);
        int ca = category(a, shift),
                cb = category(b, shift),
                cc = category(c, shift),
                cd = category(d, shift);
        int selected = ca, count = votes(ca, ca, cb, cc, cd);
        int next = votes(cb, ca, cb, cc, cd);
        if (next > count) {
            selected = cb;
            count = next;
        }
        next = votes(cc, ca, cb, cc, cd);
        if (next > count) {
            selected = cc;
            count = next;
        }
        next = votes(cd, ca, cb, cc, cd);
        if (next > count) {
            selected = cd;
            count = next;
        }
        int sum =
                (ca == selected ? a : 0)
                        + (cb == selected ? b : 0)
                        + (cc == selected ? c : 0)
                        + (cd == selected ? d : 0);
        return (sum + count / 2) / count;
    }

    public static int interpolate(int a, int b, float blend, boolean specular) {
        int result = 0;
        for (int shift = 0; shift <= 24; shift += 8) {
            int left = (a >>> shift) & 255, right = (b >>> shift) & 255;
            boolean categorical = specular && (shift == 8 || shift == 0 || shift == 24);
            int value =
                    categorical
                            ? left
                            : Math.round(left + (right - left) * Math.clamp(blend, 0, 1));
            result |= value << shift;
        }
        return result;
    }
}
