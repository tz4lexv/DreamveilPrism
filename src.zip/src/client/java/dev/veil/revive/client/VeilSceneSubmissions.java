package dev.veil.revive.client;

import net.minecraft.client.renderer.SubmitNodeStorage;
import net.minecraft.client.renderer.feature.phase.FeatureRenderPhase;
import net.minecraft.client.renderer.feature.submit.SubmitNode;

import java.util.ArrayList;
import java.util.List;

final class VeilSceneSubmissions {
    private record Phase(FeatureRenderPhase<SubmitNode> target, List<SubmitNode> nodes) {}

    private final SubmitNodeStorage storage;
    private final List<Phase> phases;

    @SuppressWarnings("unchecked")
    VeilSceneSubmissions(SubmitNodeStorage storage, boolean repeated) {
        this.storage = storage;
        if (!repeated) {
            phases = List.of();
            return;
        }
        var captured = new ArrayList<Phase>();
        for (var collection : storage.getSubmitsPerOrder().values()) {
            for (var phase : collection.allPhases()) {
                if (phase.isEmpty()) continue;
                var nodes = new ArrayList<SubmitNode>();
                phase.sortInto((node, ordered) -> nodes.add(node));
                captured.add(new Phase((FeatureRenderPhase<SubmitNode>) phase, List.copyOf(nodes)));
            }
        }
        phases = List.copyOf(captured);
    }

    SubmitNodeStorage replay() {
        for (Phase phase : phases)
            for (SubmitNode node : phase.nodes()) phase.target().submit(node);
        return storage;
    }
}
