package dev.veil.revive.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;

public final class VeilCreatorLightUpdates {
    private VeilCreatorLightUpdates() {}

    public static void blockChanged(ClientLevel level, BlockPos position) {
        VeilCreatorSceneHost.blockLightChanged(level, position);
    }
}
