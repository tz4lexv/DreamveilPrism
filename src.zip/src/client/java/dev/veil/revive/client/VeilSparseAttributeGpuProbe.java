package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.StagingBuffer;

import dev.veil.revive.core.terrain.AttributeUploadPlan;
import dev.veil.revive.core.terrain.RegularTerrainVertices;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

final class VeilSparseAttributeGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.sparseAttributeGpuProbe")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final ArrayList<Case> CASES = new ArrayList<>();
    private static GpuFence fence;
    private static boolean started, complete;

    private record Case(
            StagingBuffer staging,
            VeilManagedGpuArena<Object> arena,
            GpuBuffer oldReadback,
            GpuBuffer newReadback,
            byte[] before,
            byte[] after)
            implements AutoCloseable {
        public void close() {
            arena.close();
            staging.close();
            oldReadback.close();
            newReadback.close();
        }
    }

    static void tick() {
        if (!ENABLED || complete) return;
        try {
            if (!started) {
                started = true;
                for (int mode = 0; mode < 4; mode++) start(mode);
                fence = RenderSystem.getDevice().createCommandEncoder().createFence();
                return;
            }
            if (!fence.awaitCompletion(0)) return;
            int checked = 0;
            for (var test : CASES) {
                try (var old = test.oldReadback.map(true, false);
                        var updated = test.newReadback.map(true, false)) {
                    for (int at = 0; at < test.before.length; at++) {
                        if (old.data().get(at) != test.before[at]
                                || updated.data().get(at) != test.after[at])
                            throw new IllegalStateException("Sparse arena GPU byte mismatch");
                        checked += 2;
                    }
                }
            }
            complete = true;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil sparse attribute GPU: PASS (layouts=4 verified_bytes={} staging_rollback=true unchanged=true retired=true)",
                    checked);
            close();
        } catch (RuntimeException | Error failure) {
            close();
            throw failure;
        }
    }

    static void requireComplete() {
        if (ENABLED && !complete)
            throw new IllegalStateException("Sparse arena GPU probe incomplete");
    }

    private static void start(int mode) {
        int count = 36;
        var canonical = ByteBuffer.allocate(count * 28).order(ByteOrder.LITTLE_ENDIAN);
        for (int vertex = 0; vertex < count; vertex++)
            canonical
                    .putFloat(vertex % 16)
                    .putFloat(1)
                    .putFloat(1)
                    .putInt(-1)
                    .putFloat(.25f)
                    .putFloat(.5f)
                    .putInt(0x00f00010);
        canonical.flip();
        RegularTerrainVertices.Result packed =
                mode == 0
                        ? null
                        : mode == 3
                                ? RegularTerrainVertices.encodeWide(canonical, count)
                                : RegularTerrainVertices.encode(canonical, count, mode == 1);
        byte[] before = packed == null ? canonical.array() : packed.vertices();
        byte[] after = before.clone();
        int stride = packed == null ? 28 : packed.stride();
        int color = packed == null ? 12 : packed.layout().colorOffset();
        for (int vertex = 0; vertex < 6; vertex++) {
            after[vertex * stride + color] ^= 63;
            after[vertex * stride + stride - 4] ^= 32;
        }
        var plan =
                packed == null
                        ? AttributeUploadPlan.canonical(
                                ByteBuffer.wrap(before), ByteBuffer.wrap(after), 0, 32)
                        : AttributeUploadPlan.packed(
                                packed,
                                new RegularTerrainVertices.Result(after, packed.layout(), count),
                                0,
                                32);
        var device = RenderSystem.getDevice();
        StagingBuffer staging = new VeilPersistentStagingBuffer("Veil sparse arena probe", 4096);
        var arena =
                new VeilManagedGpuArena<Object>(
                        "Veil sparse probe", GpuBuffer.USAGE_VERTEX, 4096, stride, staging, 1);
        GpuBuffer oldReadback = null, newReadback = null;
        boolean transferred = false;
        try {
            Object key = new Object();
            var prefix = ByteBuffer.allocateDirect(stride);
            if (arena.tryAddAllocation(new Object(), null, stride, () -> prefix)
                    != VeilManagedGpuArena.Admission.ADDED)
                throw new IllegalStateException("Sparse prefix admission");
            var input = ByteBuffer.allocateDirect(before.length).put(before).flip();
            if (arena.tryAddAllocation(key, null, before.length, () -> input)
                    != VeilManagedGpuArena.Admission.ADDED)
                throw new IllegalStateException("Sparse initial admission");
            var filler =
                    staging.tryAppend(
                            ByteBuffer.allocateDirect(4096 - stride - before.length - 16));
            try (var uploader = staging.startUploading(device.createCommandEncoder())) {
                arena.uploadStagedAllocations(device, uploader);
            }
            var allocation = arena.getAllocation(key);
            if (allocation.offset() == 0 || allocation.offset() % stride != 0)
                throw new IllegalStateException("Sparse nonzero arena offset not covered");
            var source = arena.getGpuBuffer(allocation);
            oldReadback =
                    device.createBuffer(
                            () -> "Veil sparse before",
                            GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                            before.length);
            newReadback =
                    device.createBuffer(
                            () -> "Veil sparse after",
                            GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                            before.length);
            device.createCommandEncoder()
                    .copyToBuffer(
                            source.slice(allocation.offset(), before.length), oldReadback.slice());
            try (filler) {
                if (arena.tryRestageAttributes(key, plan) != VeilManagedGpuArena.Admission.STAGING
                        || arena.getAllocation(key) == null)
                    throw new IllegalStateException("Sparse staging rollback failed");
            }
            try (var uploader = staging.startUploading(device.createCommandEncoder())) {}
            if (arena.tryRestageAttributes(key, plan) != VeilManagedGpuArena.Admission.ADDED
                    || arena.getAllocation(key) != null)
                throw new IllegalStateException("Sparse publication before upload");
            try (var uploader = staging.startUploading(device.createCommandEncoder())) {
                arena.uploadStagedAllocations(device, uploader);
            }
            allocation = arena.getAllocation(key);
            device.createCommandEncoder()
                    .copyToBuffer(
                            source.slice(allocation.offset(), before.length), newReadback.slice());
            var unchanged =
                    packed == null
                            ? AttributeUploadPlan.canonical(
                                    ByteBuffer.wrap(after), ByteBuffer.wrap(after), 0, 32)
                            : AttributeUploadPlan.packed(
                                    new RegularTerrainVertices.Result(
                                            after, packed.layout(), count),
                                    new RegularTerrainVertices.Result(
                                            after, packed.layout(), count),
                                    0,
                                    32);
            if (arena.tryRestageAttributes(key, unchanged) != VeilManagedGpuArena.Admission.ADDED
                    || arena.getAllocation(key) == null)
                throw new IllegalStateException("Unchanged attributes unavailable");
            if (arena.tryRestageAttributes(key, plan) != VeilManagedGpuArena.Admission.ADDED)
                throw new IllegalStateException("Sparse retirement admission");
            arena.removeAllocation(key);
            if (arena.getAllocation(key) != null)
                throw new IllegalStateException("Sparse retirement leak");
            CASES.add(new Case(staging, arena, oldReadback, newReadback, before, after));
            transferred = true;
        } finally {
            if (!transferred) {
                arena.close();
                staging.close();
                if (oldReadback != null) oldReadback.close();
                if (newReadback != null) newReadback.close();
            }
        }
    }

    private static void close() {
        if (fence != null) fence.close();
        fence = null;
        for (var test : CASES) test.close();
        CASES.clear();
    }
}
