package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.*;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.SectionMesh;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkCommandBuffer;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.IdentityHashMap;
import java.util.Map;

public final class VeilFluidGeometryHost {
    private static final int STRIDE = 32;
    private static final int[] TRI = {0, 1, 2, 0, 2, 3};
    private static final Map<SectionMesh, CachedEntries> CACHE = new IdentityHashMap<>();
    private static final Entry EMPTY = new Entry(null, 0, 0);
    private static long uploads;
    private static long uploadedBytes;
    private static long physicalFilteredSourceSideQuads;
    private static long drawCalls;
    private static long drawnVertices;
    private static long drawnSections;
    private static long emptyFrames;
    private static long ownershipRebuildRequests;
    private static long lastFrameDrawCalls;
    private static long lastFrameVertices;
    private static long lastFrameSections;
    private static boolean loggedAbi7;
    private static boolean loggedAbi8;
    private static boolean loggedLava;

    private VeilFluidGeometryHost() {}

    static boolean lavaDrawn() {
        return loggedLava;
    }

    public static void drawWater(VkCommandBuffer cmd, MemoryStack stack) {
        drawWater(cmd, stack, false);
    }

    public static void drawWater(VkCommandBuffer cmd, MemoryStack stack, boolean physicalWater) {
        drawFluid(cmd, stack, VeilMaterialIds.WATER, physicalWater);
    }

    public static void drawFluid(
            VkCommandBuffer cmd, MemoryStack stack, int materialId, boolean physicalWater) {
        RenderSystem.assertOnRenderThread();
        lastFrameDrawCalls = 0;
        lastFrameVertices = 0;
        lastFrameSections = 0;

        Minecraft client = Minecraft.getInstance();
        if (client.level == null || client.levelRenderer == null) return;
        var visible = client.levelRenderer.visibleSections();
        if (visible == null || visible.isEmpty()) {
            emptyFrames++;
            return;
        }

        var nativeBuffers = stack.mallocLong(1);
        var offsets = stack.mallocLong(1).put(0, 0L);
        for (var section : visible) {
            SectionMesh mesh = section.getSectionMesh();
            if (!(mesh instanceof VeilMeshExtras extras) || extras.veil$metadata() == null)
                continue;
            CachedEntries cached = CACHE.computeIfAbsent(mesh, ignored -> new CachedEntries());
            Entry entry =
                    materialId == VeilMaterialIds.LAVA
                            ? cached.lava
                            : physicalWater ? cached.physical : cached.all;
            if (entry == null) {
                entry = upload(extras.veil$metadata(), materialId, physicalWater);
                if (materialId == VeilMaterialIds.LAVA) cached.lava = entry;
                else if (physicalWater) cached.physical = entry;
                else cached.all = entry;
            }
            if (entry.vertexCount == 0) continue;
            nativeBuffers.put(0, ((VulkanGpuBuffer) entry.buffer).vkBuffer());
            vkCmdBindVertexBuffers(cmd, 0, nativeBuffers, offsets);
            vkCmdDraw(cmd, entry.vertexCount, 1, 0, 0);
            lastFrameDrawCalls++;
            lastFrameVertices += entry.vertexCount;
            lastFrameSections++;
        }
        if (lastFrameDrawCalls == 0) emptyFrames++;
        drawCalls += lastFrameDrawCalls;
        drawnVertices += lastFrameVertices;
        drawnSections += lastFrameSections;
        if (lastFrameDrawCalls != 0) {
            if (materialId == VeilMaterialIds.LAVA && !loggedLava) {
                loggedLava = true;
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil lava geometry ABI17 active: draws={} vertices={}",
                        lastFrameDrawCalls,
                        lastFrameVertices);
            } else if (physicalWater && !loggedAbi8) {
                loggedAbi8 = true;
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil Fluid Geometry ABI 8 PHYSICAL active: source shoreline side closures filtered; visible water draws={} vertices={}",
                        lastFrameDrawCalls,
                        lastFrameVertices);
            } else if (materialId == VeilMaterialIds.WATER && !physicalWater && !loggedAbi7) {
                loggedAbi7 = true;
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil Fluid Geometry ABI 7 ACTIVE: vanilla WATER suppressed at tessellation; visible water draws={} vertices={}",
                        lastFrameDrawCalls,
                        lastFrameVertices);
            }
        }
    }

    private static Entry upload(VeilMeshMetadata metadata, int materialId, boolean physicalWater) {
        VeilFluidGeometry selected = null;
        for (VeilFluidGeometry geometry : metadata.fluidGeometry()) {
            if (geometry.materialId() != materialId || geometry.quadCount() == 0) continue;
            selected = selected == null ? geometry : merge(selected, geometry);
        }
        if (selected == null) return EMPTY;

        int acceptedQuads = 0;
        if (!physicalWater) {
            acceptedQuads = selected.quadCount();
        } else {
            byte[] flags = selected.quadFlagsUnsafe();
            for (int quad = 0; quad < selected.quadCount(); ++quad) {
                if (acceptPhysical(flags[quad])) acceptedQuads++;
                else physicalFilteredSourceSideQuads++;
            }
        }
        if (acceptedQuads == 0) return EMPTY;

        int vertexCount = Math.multiplyExact(acceptedQuads, 6);
        int bytes = Math.multiplyExact(vertexCount, STRIDE);
        GpuBuffer buffer =
                RenderSystem.getDevice()
                        .createBuffer(
                                () ->
                                        physicalWater
                                                ? "Veil ABI8 physical water geometry"
                                                : materialId == VeilMaterialIds.LAVA
                                                        ? "Veil ABI17 lava geometry"
                                                        : "Veil ABI7 water geometry",
                                GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE,
                                bytes);
        try {
            try (var mapping = buffer.map(false, true)) {
                ByteBuffer out = mapping.data().order(ByteOrder.nativeOrder());
                float[] positions = selected.positionsUnsafe();
                byte[] flags = selected.quadFlagsUnsafe();
                int dstVertex = 0;
                for (int quad = 0; quad < selected.quadCount(); ++quad) {
                    if (physicalWater && !acceptPhysical(flags[quad])) continue;
                    int base = quad * 12;
                    for (int corner : TRI) {
                        int src = base + corner * 3;
                        int dst = dstVertex++ * STRIDE;
                        out.putFloat(dst, positions[src]);
                        out.putFloat(dst + 4, positions[src + 1]);
                        out.putFloat(dst + 8, positions[src + 2]);
                        out.putFloat(dst + 12, 0.0f);
                        out.putInt(dst + 16, selected.originX());
                        out.putInt(dst + 20, selected.originY());
                        out.putInt(dst + 24, selected.originZ());
                        out.putInt(dst + 28, selected.materialId());
                    }
                }
            }
        } catch (RuntimeException failure) {
            buffer.close();
            throw failure;
        }
        uploads++;
        uploadedBytes += bytes;
        return new Entry(buffer, vertexCount, bytes);
    }

    private static boolean acceptPhysical(byte flags) {
        if ((flags & VeilFluidGeometry.QUAD_DEGENERATE) != 0) return true;
        if ((flags & VeilFluidGeometry.QUAD_TOP) != 0) return true;

        return (flags & VeilFluidGeometry.QUAD_SIDE) != 0
                && (flags & VeilFluidGeometry.QUAD_SOURCE) == 0;
    }

    private static VeilFluidGeometry merge(VeilFluidGeometry a, VeilFluidGeometry b) {
        if (a.originX() != b.originX()
                || a.originY() != b.originY()
                || a.originZ() != b.originZ()
                || a.materialId() != b.materialId()) {
            throw new IllegalStateException(
                    "Fluid geometries from one SectionMesh disagree on origin/material");
        }
        float[] av = a.positionsUnsafe();
        float[] bv = b.positionsUnsafe();
        float[] merged = new float[av.length + bv.length];
        System.arraycopy(av, 0, merged, 0, av.length);
        System.arraycopy(bv, 0, merged, av.length, bv.length);
        byte[] af = a.quadFlagsUnsafe();
        byte[] bf = b.quadFlagsUnsafe();
        byte[] mergedFlags = new byte[af.length + bf.length];
        System.arraycopy(af, 0, mergedFlags, 0, af.length);
        System.arraycopy(bf, 0, mergedFlags, af.length, bf.length);
        return new VeilFluidGeometry(
                a.materialId(), a.originX(), a.originY(), a.originZ(), merged, mergedFlags);
    }

    public static void release(SectionMesh mesh) {
        if (mesh == null) return;
        CachedEntries entries = CACHE.remove(mesh);
        if (entries != null) entries.close();
    }

    public static void recordOwnershipRebuildRequest() {
        ownershipRebuildRequests++;
    }

    public static String telemetry() {
        return "fluid_geometry_replacement_enabled="
                + VeilShaderService.fluidGeometryWaterReplacementEnabled()
                + "\nfluid_geometry_lava_replacement_enabled="
                + VeilShaderService.fluidGeometryLavaReplacementEnabled()
                + "\nfluid_geometry_captured_fluids_total="
                + VeilFluidGeometryCapture.capturedFluids()
                + "\nfluid_geometry_captured_quads_total="
                + VeilFluidGeometryCapture.capturedQuads()
                + "\nfluid_geometry_captured_top_quads_total="
                + VeilFluidGeometryCapture.capturedTopQuads()
                + "\nfluid_geometry_captured_side_quads_total="
                + VeilFluidGeometryCapture.capturedSideQuads()
                + "\nfluid_geometry_captured_source_side_quads_total="
                + VeilFluidGeometryCapture.capturedSourceSideQuads()
                + "\nfluid_geometry_malformed_fluids_total="
                + VeilFluidGeometryCapture.malformedFluids()
                + "\nfluid_geometry_physical_filtered_source_side_quads_total="
                + physicalFilteredSourceSideQuads
                + "\nfluid_geometry_gpu_uploads_total="
                + uploads
                + "\nfluid_geometry_gpu_uploaded_bytes_total="
                + uploadedBytes
                + "\nfluid_geometry_draw_calls_total="
                + drawCalls
                + "\nfluid_geometry_drawn_vertices_total="
                + drawnVertices
                + "\nfluid_geometry_drawn_sections_total="
                + drawnSections
                + "\nfluid_geometry_last_frame_draw_calls="
                + lastFrameDrawCalls
                + "\nfluid_geometry_last_frame_vertices="
                + lastFrameVertices
                + "\nfluid_geometry_last_frame_sections="
                + lastFrameSections
                + "\nfluid_geometry_empty_frames_total="
                + emptyFrames
                + "\nfluid_geometry_ownership_rebuild_requests_total="
                + ownershipRebuildRequests
                + "\nfluid_geometry_cached_section_buffers="
                + CACHE.size();
    }

    public static void close() {
        RenderSystem.assertOnRenderThread();
        CACHE.values().forEach(CachedEntries::close);
        CACHE.clear();
        loggedAbi7 = false;
        loggedAbi8 = false;
        loggedLava = false;
    }

    private static final class CachedEntries {
        Entry all;
        Entry physical;
        Entry lava;

        void close() {
            closeEntry(all);
            closeEntry(physical);
            closeEntry(lava);
            lava = null;
            all = null;
            physical = null;
        }

        private static void closeEntry(Entry entry) {
            if (entry != null && entry.buffer != null) entry.buffer.close();
        }
    }

    private record Entry(GpuBuffer buffer, int vertexCount, int bytes) {}
}
