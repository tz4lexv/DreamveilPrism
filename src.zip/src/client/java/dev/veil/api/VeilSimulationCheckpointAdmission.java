package dev.veil.api;

import java.util.Objects;

/** Process-wide admission for opt-in checkpoint stores; does not allocate or own GPU resources. */
public final class VeilSimulationCheckpointAdmission {
    public record Limits(int requests, long snapshotCapacityBytes) {
        public Limits {
            if (requests < 1 || snapshotCapacityBytes < 1)
                throw new IllegalArgumentException("Invalid global checkpoint limits");
        }
    }

    public record Usage(Limits limits, int requests, long snapshotCapacityBytes) {}

    private static Limits limits = new Limits(4, 64L * 1024 * 1024);
    private static int requests;
    private static long capacity;

    private VeilSimulationCheckpointAdmission() {}

    public static synchronized Usage usage() {
        return new Usage(limits, requests, capacity);
    }

    /** Host policy may be changed only while no checkpoint operation is admitted. */
    public static synchronized void configure(Limits replacement) {
        Objects.requireNonNull(replacement, "limits");
        if (requests != 0) throw new IllegalStateException("Checkpoint operations are outstanding");
        limits = replacement;
    }

    static synchronized Reservation reserve(long bytes) {
        if (bytes < 1) throw new IllegalArgumentException("Invalid checkpoint capacity");
        if (requests >= limits.requests() || bytes > limits.snapshotCapacityBytes() - capacity)
            return null;
        requests++;
        capacity += bytes;
        return new Reservation(bytes);
    }

    static final class Reservation implements AutoCloseable {
        private final long bytes;
        private boolean released;

        private Reservation(long bytes) {
            this.bytes = bytes;
        }

        @Override
        public void close() {
            synchronized (VeilSimulationCheckpointAdmission.class) {
                if (released) return;
                released = true;
                requests--;
                capacity -= bytes;
            }
        }
    }
}
