package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.ReviveConfig;
import dev.veil.revive.platform.VeilPlatform;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

final class ReviveConfigStore {
    private static final String FILE_NAME = "veil.properties";

    private ReviveConfigStore() {}

    static ReviveConfig loadOrCreate() {
        Path path = VeilPlatform.get().getConfigDir().resolve(FILE_NAME);
        ReviveConfig defaults = ReviveConfig.defaults();
        if (!Files.exists(path)) {
            save(path, defaults);
            return defaults;
        }
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            p.load(in);
            return ReviveConfig.from(p);
        } catch (IOException | RuntimeException e) {
            ReviveMod.LOGGER.warn("Could not read {}; using safe defaults", path, e);
            return defaults;
        }
    }

    private static void save(Path path, ReviveConfig config) {
        try {
            Files.createDirectories(path.getParent());
            Path tmp = path.resolveSibling(path.getFileName() + ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                config.toProperties()
                        .store(
                                out,
                                "Veil. FAITHFUL never changes visual quality. RESCUE is explicit opt-in only.");
            }
            try {
                Files.move(
                        tmp,
                        path,
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicUnsupported) {
                Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            ReviveMod.LOGGER.warn("Could not write default Veil config", e);
        }
    }
}
