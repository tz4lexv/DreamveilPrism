package dev.veil.revive.client;

public final class VeilMaterialIds {
    public static final int NONE = 0;
    public static final int WATER = 1;
    public static final int LAVA = 2;
    public static final int OTHER_FLUID = 3;

    private VeilMaterialIds() {}
}
