package dev.veil.revive.client.graphics.resources;

import static org.lwjgl.vulkan.VK10.*;

/** VkSamplerCreateInfo parameters shared by both owned and imported image samplers. */
public record SamplerParameters(
        int min,
        int mag,
        int mip,
        int u,
        int v,
        int w,
        boolean compareEnable,
        int compareOp,
        int borderColor,
        float minLod,
        float maxLod,
        float lodBias) {
    public SamplerParameters {
        SamplerLodRules.validate(minLod, maxLod, lodBias);
    }

    public SamplerParameters(
            int min,
            int mag,
            int mip,
            int u,
            int v,
            int w,
            boolean compareEnable,
            int compareOp,
            int borderColor) {
        this(
                min,
                mag,
                mip,
                u,
                v,
                w,
                compareEnable,
                compareOp,
                borderColor,
                0.0f,
                SamplerLodRules.DEFAULT_MAX_LOD,
                0.0f);
    }

    public SamplerParameters(
            int min, int mag, int mip, int u, int v, int w, boolean compareEnable, int compareOp) {
        this(
                min,
                mag,
                mip,
                u,
                v,
                w,
                compareEnable,
                compareOp,
                VK_BORDER_COLOR_FLOAT_TRANSPARENT_BLACK);
    }

    public SamplerParameters(int min, int mag, int mip, int u, int v, int w) {
        this(min, mag, mip, u, v, w, false, VK_COMPARE_OP_ALWAYS);
    }
}
