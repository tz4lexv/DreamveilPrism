package dev.veil.api;

import java.nio.ByteBuffer;
import java.util.Objects;

/**
 * CPU-side staging adapter for creator-defined 1D/2D/3D simulation fields.
 *
 * <p>Converts tightly packed field values to/from staging buffers with explicit row and slice
 * pitches. The caller owns Vulkan image/buffer copies, memory coherence, transfer barriers, GPU
 * completion and image format agreement. This class issues NO GPU commands. No weather semantics,
 * shader names or proprietary directives are required.
 */
public final class VeilSimulationStaging {
    private VeilSimulationStaging() {}

    /**
     * Layout of one single-layer, single-mip linear staging region. Offsets and pitches are in
     * bytes, measured from buffer index zero, NOT its current position. Row/slice pitches include
     * padding; each depth slice contains {@code height} complete rows.
     *
     * <p>A caller must derive pitches from the actual transfer/mapping contract. This class does
     * not infer Vulkan rowLength/imageHeight or support compressed/depth formats.
     */
    public record Layout(
            int width,
            int height,
            int depth,
            int components,
            VeilSimulationFieldSnapshot.ScalarType type,
            int byteOffset,
            int rowPitchBytes,
            int slicePitchBytes) {
        public Layout {
            Objects.requireNonNull(type, "type");
            if (width < 1
                    || height < 1
                    || depth < 1
                    || components < 1
                    || components > 4
                    || byteOffset < 0
                    || rowPitchBytes < 1
                    || slicePitchBytes < 1) {
                throw new IllegalArgumentException("Invalid staging field shape or pitches");
            }
            long rowBytes = (long) width * components * type.bytes();
            long sliceBytes = (long) rowPitchBytes * height;
            // Check intermediate pitches before multiplying by depth, to avoid overflow
            // for impossible extents supplied by an untrusted shaderpack declaration.
            if (rowBytes > rowPitchBytes || sliceBytes > slicePitchBytes)
                throw new IllegalArgumentException(
                        "Rows or slices overlap or exceed integer strides");
            long packed = rowBytes * height * depth;
            long end =
                    (long) byteOffset
                            + (long) (depth - 1) * slicePitchBytes
                            + (long) (height - 1) * rowPitchBytes
                            + rowBytes;
            if (packed > VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES - 36L
                    || end > Integer.MAX_VALUE) {
                throw new IllegalArgumentException("Staging offset or checkpoint budget exceeded");
            }
        }

        public int rowBytes() {
            return width * components * type.bytes();
        }

        public int packedBytes() {
            return Math.toIntExact((long) rowBytes() * height * depth);
        }

        /** Buffer limit required to access the last useful byte (trailing padding is optional). */
        public int requiredLimit() {
            return Math.toIntExact(
                    (long) byteOffset
                            + (long) (depth - 1) * slicePitchBytes
                            + (long) (height - 1) * rowPitchBytes
                            + rowBytes());
        }

        /**
         * Create the exact Vulkan copy strides for this staging layout when possible. Vulkan
         * expresses row length and image height in texels, not bytes. A row pitch that is not a
         * whole number of texels, or a non-integral slice stride, cannot be represented by
         * VkBufferImageCopy and must be repacked first. The returned layout is intended for
         * single-mip, single-layer images or 3D fields with depth slices. For arrays, the caller
         * must validate layer shapes.
         */
        public VeilTransfer.BufferLayout transferBufferLayout() {
            int texelBytes = Math.multiplyExact(components, type.bytes());
            if (rowPitchBytes % texelBytes != 0)
                throw new IllegalArgumentException(
                        "Staging row pitch is not a whole number of texels");
            int rowLength = rowPitchBytes / texelBytes;
            if (rowLength < width)
                throw new IllegalArgumentException("Staging row pitch is shorter than width");
            int imageHeight = 0;
            if (depth > 1) {
                if (slicePitchBytes % rowPitchBytes != 0)
                    throw new IllegalArgumentException(
                            "Staging slice pitch cannot be expressed as Vulkan imageHeight");
                imageHeight = slicePitchBytes / rowPitchBytes;
                if (imageHeight < height)
                    throw new IllegalArgumentException(
                            "Staging image height is shorter than height");
            }
            return new VeilTransfer.BufferLayout(
                    rowLength == width ? 0 : rowLength, imageHeight == height ? 0 : imageHeight);
        }

        public static Layout tightlyPacked(VeilSimulationFieldSnapshot field) {
            Objects.requireNonNull(field, "field");
            int row =
                    Math.toIntExact(
                            (long) field.width() * field.components() * field.type().bytes());
            int slice = Math.toIntExact((long) row * field.height());
            return new Layout(
                    field.width(),
                    field.height(),
                    field.depth(),
                    field.components(),
                    field.type(),
                    0,
                    row,
                    slice);
        }

        /** Convenience for host-mapped rows/slices aligned to a caller-specified byte boundary. */
        public static Layout aligned(
                int width,
                int height,
                int depth,
                int components,
                VeilSimulationFieldSnapshot.ScalarType type,
                int byteOffset,
                int rowAlignment,
                int sliceAlignment) {
            Objects.requireNonNull(type, "type");
            if (rowAlignment < 1 || sliceAlignment < 1)
                throw new IllegalArgumentException("Alignments must be positive");
            if (width < 1 || height < 1 || depth < 1 || components < 1 || components > 4)
                throw new IllegalArgumentException("Invalid field dimensions");
            long row = align((long) width * components * type.bytes(), rowAlignment);
            if (row > Integer.MAX_VALUE)
                throw new IllegalArgumentException("Aligned staging row is too large");
            long slice = align(row * height, sliceAlignment);
            if (slice > Integer.MAX_VALUE)
                throw new IllegalArgumentException("Aligned staging slice is too large");
            return new Layout(
                    width, height, depth, components, type, byteOffset, (int) row, (int) slice);
        }

        private static long align(long value, int alignment) {
            return ((value + alignment - 1L) / alignment) * alignment;
        }
    }

    /**
     * Capture the useful field bytes from a completed host-readable staging buffer. No
     * synchronization or GPU readback is performed. Source position/limit are unchanged.
     */
    public static VeilSimulationFieldSnapshot capture(ByteBuffer source, Layout layout) {
        Objects.requireNonNull(source, "source");
        Objects.requireNonNull(layout, "layout");
        requireLimit(source, layout);
        byte[] packed = new byte[layout.packedBytes()];
        ByteBuffer view = source.duplicate();
        int output = 0;
        for (int z = 0; z < layout.depth(); z++) {
            for (int y = 0; y < layout.height(); y++) {
                int start =
                        Math.toIntExact(
                                (long) layout.byteOffset()
                                        + (long) z * layout.slicePitchBytes()
                                        + (long) y * layout.rowPitchBytes());
                view.position(start);
                view.get(packed, output, layout.rowBytes());
                output += layout.rowBytes();
            }
        }
        return new VeilSimulationFieldSnapshot(
                layout.width(),
                layout.height(),
                layout.depth(),
                layout.components(),
                layout.type(),
                packed);
    }

    /**
     * Write only meaningful field bytes into a caller-owned host-writable staging buffer. Padding
     * is preserved; target position/limit are unchanged. Validate the GPU transfer format
     * independently before scheduling the actual upload.
     */
    public static void prepareUpload(
            VeilSimulationFieldSnapshot field, ByteBuffer destination, Layout layout) {
        Objects.requireNonNull(field, "field");
        Objects.requireNonNull(destination, "destination");
        Objects.requireNonNull(layout, "layout");
        if (field.width() != layout.width()
                || field.height() != layout.height()
                || field.depth() != layout.depth()
                || field.components() != layout.components()
                || field.type() != layout.type()) {
            throw new IllegalArgumentException("Field and staging layout differ");
        }
        if (destination.isReadOnly())
            throw new IllegalArgumentException("Staging destination is read-only");
        requireLimit(destination, layout);
        byte[] packed = field.pixels();
        ByteBuffer view = destination.duplicate();
        int input = 0;
        for (int z = 0; z < layout.depth(); z++) {
            for (int y = 0; y < layout.height(); y++) {
                int start =
                        Math.toIntExact(
                                (long) layout.byteOffset()
                                        + (long) z * layout.slicePitchBytes()
                                        + (long) y * layout.rowPitchBytes());
                view.position(start);
                view.put(packed, input, layout.rowBytes());
                input += layout.rowBytes();
            }
        }
    }

    private static void requireLimit(ByteBuffer buffer, Layout layout) {
        if (buffer.limit() < layout.requiredLimit())
            throw new IllegalArgumentException(
                    "Mapped staging buffer is shorter than the field region");
    }
}
