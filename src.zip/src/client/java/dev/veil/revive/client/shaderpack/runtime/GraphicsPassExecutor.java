package dev.veil.revive.client.shaderpack.runtime;

import static org.lwjgl.vulkan.VK13.*;

import dev.veil.api.VeilFormat;
import dev.veil.revive.client.VeilShaderPack;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;

import java.util.function.Function;

public final class GraphicsPassExecutor<P> {
    public record AttachmentView(long handle, int width, int height) {}

    @FunctionalInterface
    public interface Attachments {
        AttachmentView resolve(String resource, int mip, int layer);
    }

    @FunctionalInterface
    public interface Binder<P> {
        void bind(P pass, VkCommandBuffer command, MemoryStack stack, int width, int height);
    }

    @FunctionalInterface
    public interface Geometry<P> {
        void draw(P pass, VkCommandBuffer command, MemoryStack stack);
    }

    private final Function<P, VeilShaderPack.Pass> definitions;
    private final Attachments attachments;
    private final Function<String, VeilFormat> formats;
    private final Binder<P> binder;
    private final Geometry<P> geometry;

    public GraphicsPassExecutor(
            Function<P, VeilShaderPack.Pass> definitions,
            Attachments attachments,
            Function<String, VeilFormat> formats,
            Binder<P> binder,
            Geometry<P> geometry) {
        this.definitions = definitions;
        this.attachments = attachments;
        this.formats = formats;
        this.binder = binder;
        this.geometry = geometry;
    }

    public void execute(P pass, VkCommandBuffer cmd) {
        VeilShaderPack.Pass passDefinition = definitions.apply(pass);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var colors = VkRenderingAttachmentInfo.calloc(passDefinition.colors().size(), stack);
            int targetWidth = -1;
            int targetHeight = -1;
            for (int index = 0; index < passDefinition.colors().size(); index++) {
                var definition = passDefinition.colors().get(index);
                AttachmentView view =
                        attachments.resolve(
                                definition.resource(), definition.mip(), definition.layer());
                if (targetWidth < 0) {
                    targetWidth = view.width();
                    targetHeight = view.height();
                }
                var attachment =
                        colors.get(index)
                                .sType$Default()
                                .imageView(view.handle())
                                .imageLayout(VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL)
                                .loadOp(loadOp(definition.load()))
                                .storeOp(storeOp(definition.store()));
                if (definition.clear() != null) {
                    var clear = definition.clear();
                    var color = attachment.clearValue().color();
                    switch (clear.colorType()) {
                        case FLOAT ->
                                color.float32(0, clear.r())
                                        .float32(1, clear.g())
                                        .float32(2, clear.b())
                                        .float32(3, clear.a());
                        case SINT ->
                                color.int32(0, clear.c0())
                                        .int32(1, clear.c1())
                                        .int32(2, clear.c2())
                                        .int32(3, clear.c3());
                        case UINT ->
                                color.uint32(0, clear.c0())
                                        .uint32(1, clear.c1())
                                        .uint32(2, clear.c2())
                                        .uint32(3, clear.c3());
                    }
                }
            }
            VkRenderingAttachmentInfo depth = null;
            VkRenderingAttachmentInfo stencilAttachment = null;
            if (passDefinition.depth() != null) {
                var definition = passDefinition.depth();
                AttachmentView view =
                        attachments.resolve(
                                definition.resource(), definition.mip(), definition.layer());
                if (targetWidth < 0) {
                    targetWidth = view.width();
                    targetHeight = view.height();
                }
                int layout =
                        definition.write() || definition.load() != VeilShaderPack.LoadOp.LOAD
                                ? VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL
                                : VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
                depth =
                        VkRenderingAttachmentInfo.calloc(stack)
                                .sType$Default()
                                .imageView(view.handle())
                                .imageLayout(layout)
                                .loadOp(loadOp(definition.load()))
                                .storeOp(storeOp(definition.store()));
                depth.clearValue()
                        .depthStencil()
                        .depth(definition.clearDepth())
                        .stencil(definition.clearStencil());
                if (formats.apply(definition.resource()).stencil()) {
                    stencilAttachment =
                            VkRenderingAttachmentInfo.calloc(stack)
                                    .sType$Default()
                                    .imageView(view.handle())
                                    .imageLayout(layout)
                                    .loadOp(loadOp(definition.load()))
                                    .storeOp(storeOp(definition.store()));
                    stencilAttachment
                            .clearValue()
                            .depthStencil()
                            .depth(definition.clearDepth())
                            .stencil(definition.clearStencil());
                }
            }
            if (targetWidth < 1 || targetHeight < 1)
                throw new IllegalStateException("Graphics pass has no usable attachment");
            var rendering = VkRenderingInfo.calloc(stack).sType$Default().layerCount(1).viewMask(0);
            rendering.renderArea().offset().set(0, 0);
            rendering.renderArea().extent().set(targetWidth, targetHeight);
            if (!passDefinition.colors().isEmpty()) rendering.pColorAttachments(colors);
            if (depth != null) {
                rendering.pDepthAttachment(depth);
                if (stencilAttachment != null) rendering.pStencilAttachment(stencilAttachment);
            }
            KHRDynamicRendering.vkCmdBeginRenderingKHR(cmd, rendering);
            try {
                binder.bind(pass, cmd, stack, targetWidth, targetHeight);
                var viewport =
                        VkViewport.calloc(1, stack)
                                .x(0)
                                .y(0)
                                .width(targetWidth)
                                .height(targetHeight)
                                .minDepth(0)
                                .maxDepth(1);
                var scissor = VkRect2D.calloc(1, stack);
                scissor.offset().set(0, 0);
                scissor.extent().set(targetWidth, targetHeight);
                vkCmdSetViewport(cmd, 0, viewport);
                vkCmdSetScissor(cmd, 0, scissor);
                geometry.draw(pass, cmd, stack);
            } finally {
                KHRDynamicRendering.vkCmdEndRenderingKHR(cmd);
            }
        }
    }

    private static int loadOp(VeilShaderPack.LoadOp operation) {
        return switch (operation) {
            case LOAD -> VK_ATTACHMENT_LOAD_OP_LOAD;
            case CLEAR -> VK_ATTACHMENT_LOAD_OP_CLEAR;
            case DONT_CARE -> VK_ATTACHMENT_LOAD_OP_DONT_CARE;
        };
    }

    private static int storeOp(VeilShaderPack.StoreOp operation) {
        return operation == VeilShaderPack.StoreOp.STORE
                ? VK_ATTACHMENT_STORE_OP_STORE
                : VK_ATTACHMENT_STORE_OP_DONT_CARE;
    }
}
