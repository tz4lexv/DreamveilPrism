package dev.veil.revive.client;

import dev.veil.revive.client.graphics.resources.MinecraftStagingRing;

final class VeilPersistentStagingBuffer extends MinecraftStagingRing {
    VeilPersistentStagingBuffer(String name, int size) {
        super(name, size);
    }
}
