package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;

import javax.imageio.ImageIO;

final class VeilBasicShadowSlangGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.basicShadowSlangProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static int stage, frames;
    private static long started;
    private static boolean complete, pending, changing;
    private static VeilShaderPackRuntime previous;
    private static final List<String> RESULTS = new ArrayList<>();

    static boolean enabled() {
        return ENABLED;
    }

    static void timeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 240_000_000_000L)
            fail(new IllegalStateException("Basic Slang shadow probe timeout/runtime failure"));
    }

    static void tick(VeilShaderPackRuntime active) {
        if (!ENABLED || complete || pending || !VeilBenchmarkWorld.terrainReady()) return;
        if (changing && active == previous) return;
        changing = false;
        if (++frames < 120) return;
        try {
            int[] extent = active.outputExtent("output");
            int width = extent[0], height = extent[1], size = width * height * 4;
            var buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Slang shadow proof",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    size);
            pending = true;
            active.readOutput(
                    "output",
                    buffer,
                    () -> {
                        try (var map = buffer.map(true, false)) {
                            byte[] data = new byte[size];
                            map.data().get(data);
                            int low = 255, high = 0, dark = 0, light = 0, nonzero = 0;
                            var image =
                                    new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
                            for (int y = 0; y < height; y++)
                                for (int x = 0; x < width; x++) {
                                    int o = (y * width + x) * 4,
                                            r = Byte.toUnsignedInt(data[o]),
                                            g = Byte.toUnsignedInt(data[o + 1]),
                                            b = Byte.toUnsignedInt(data[o + 2]);
                                    low = Math.min(low, r);
                                    high = Math.max(high, r);
                                    if (r < 200) dark++;
                                    if (r > 250) light++;
                                    if (r + g + b > 0) nonzero++;
                                    image.setRGB(x, y, 0xff000000 | (r << 16) | (g << 8) | b);
                                }
                            Path directory =
                                    VeilPlatform.get()
                                            .getGameDir()
                                            .resolve("logs/basic-shadow-slang");
                            Files.createDirectories(directory);
                            ImageIO.write(
                                    image,
                                    "png",
                                    directory.resolve("stage-" + stage + ".png").toFile());
                            if (stage == 1 && (dark < 100 || light < 100))
                                throw new IllegalStateException(
                                        "Shadow mask must contain lit and shadowed receivers: dark="
                                                + dark
                                                + " lit="
                                                + light);
                            if (stage == 2 && (low != 255 || high != 255))
                                throw new IllegalStateException(
                                        "Disabled shadow mask is not neutral");
                            if (stage == 3 && nonzero < 100)
                                throw new IllegalStateException("Coverage view empty");
                            RESULTS.add(
                                    "stage="
                                            + stage
                                            + " viewport="
                                            + width
                                            + "x"
                                            + height
                                            + " min="
                                            + low
                                            + " max="
                                            + high
                                            + " shadow_pixels="
                                            + dark
                                            + " lit_pixels="
                                            + light
                                            + " PASS");
                            if (stage == 3) {
                                complete = true;
                                Files.write(directory.resolve("proof.txt"), RESULTS);
                                ReviveMod.LOGGER.info(
                                        "Veil basic shadow Slang GPU: PASS final shadow-mask neutral-disable coverage");
                                Minecraft.getInstance().stop();
                            } else {
                                stage++;
                                frames = 0;
                                pending = false;
                                changing = true;
                                previous = active;
                                VeilShaderService.settings(
                                        stage == 1
                                                ? Map.of("DEBUG_VIEW", "1")
                                                : stage == 2
                                                        ? Map.of("SHADOW_ENABLE", "false")
                                                        : Map.of(
                                                                "SHADOW_ENABLE",
                                                                "true",
                                                                "DEBUG_VIEW",
                                                                "2",
                                                                "SHADOW_DISTANCE",
                                                                "256",
                                                                "SHADOW_DEPTH",
                                                                "2048"));
                            }
                        } catch (Exception e) {
                            fail(e);
                        } finally {
                            buffer.close();
                        }
                    });
        } catch (Exception e) {
            fail(e);
        }
    }

    private static void fail(Throwable error) {
        complete = true;
        ReviveMod.LOGGER.error("Veil basic shadow Slang GPU: FAIL stage=" + stage, error);
        Minecraft.getInstance().stop();
    }
}
