package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

public final class VeilShaderPackBridge {
    private static final boolean IRIS_LOADED = VeilPlatform.get().isModLoaded("iris");

    private static volatile boolean initialized;
    private static volatile boolean apiAvailable;
    private static volatile boolean shaderPackActive;
    private static volatile boolean nativeShaderPackActive;
    private static volatile int irisApiMinorRevision = -1;

    private static Object irisApi;
    private static MethodHandle isShaderPackInUse;
    private static MethodHandle isRenderingShadowPass;
    private static MethodHandle getMinorApiRevision;

    private static long refreshes;
    private static long activeFrames;
    private static long shadowPassQueries;
    private static long shadowPassTrue;
    private static long customTerrainAnalysisSkips;
    private static long customTerrainMetadataSkips;
    private static long terrainBridgeFastSkips;
    private static long customSubmissionFastSkips;
    private static long conservativeBudgetFrames;
    private static boolean loggedActive;

    private VeilShaderPackBridge() {}

    public static void beginClientFrame() {
        refreshes++;
        nativeShaderPackActive = VeilShaderService.scenePackActive();
        if (!IRIS_LOADED) {
            shaderPackActive = false;
            return;
        }
        ensureInitialized();
        if (!apiAvailable) {
            shaderPackActive = false;
            return;
        }
        try {
            shaderPackActive = (boolean) isShaderPackInUse.invoke(irisApi);
        } catch (Throwable throwable) {
            disableApi("Iris isShaderPackInUse failed", throwable);
            shaderPackActive = false;
        }
        if (shaderPackActive) {
            activeFrames++;
            if (!loggedActive) {
                loggedActive = true;
                ReviveMod.LOGGER.info(
                        "Veil shader-pack efficiency mode ACTIVE: Iris API v0.{} detected",
                        irisApiMinorRevision);
            }
        }
    }

    public static boolean shaderPackActive() {
        return shaderPackActive;
    }

    public static boolean renderingShadowPass() {
        if (!shaderPackActive || !apiAvailable || isRenderingShadowPass == null) return false;
        shadowPassQueries++;
        try {
            boolean shadow = (boolean) isRenderingShadowPass.invoke(irisApi);
            if (shadow) shadowPassTrue++;
            return shadow;
        } catch (Throwable throwable) {
            disableApi("Iris isRenderingShadowPass failed", throwable);
            return false;
        }
    }

    public static boolean efficiencyModeActive() {
        return (shaderPackActive || nativeShaderPackActive && ReviveRuntime.framePressure() > 1.0)
                && VeilVideoConfig.flag("renderer.shaderPackEfficiency", true);
    }

    public static boolean customTerrainShadersAllowed() {
        return !shaderPackActive;
    }

    public static void recordCustomTerrainAnalysisSkip() {
        customTerrainAnalysisSkips++;
    }

    public static void recordCustomTerrainMetadataSkip() {
        customTerrainMetadataSkips++;
    }

    public static void recordTerrainBridgeFastSkip() {
        terrainBridgeFastSkips++;
    }

    public static void recordCustomSubmissionFastSkip() {
        customSubmissionFastSkips++;
    }

    public static void recordConservativeBudgetFrame() {
        conservativeBudgetFrames++;
    }

    public static String telemetry() {
        return "shader_bridge_iris_loaded="
                + IRIS_LOADED
                + "\nshader_bridge_api_available="
                + apiAvailable
                + "\nshader_bridge_api_minor="
                + irisApiMinorRevision
                + "\nshader_pack_active="
                + shaderPackActive
                + "\nnative_shader_pack_active="
                + nativeShaderPackActive
                + "\nshader_efficiency_mode_active="
                + efficiencyModeActive()
                + "\nshader_bridge_refreshes_total="
                + refreshes
                + "\nshader_bridge_active_frames_total="
                + activeFrames
                + "\nshader_shadow_pass_queries_total="
                + shadowPassQueries
                + "\nshader_shadow_pass_true_total="
                + shadowPassTrue
                + "\nshader_custom_terrain_analysis_skips_total="
                + customTerrainAnalysisSkips
                + "\nshader_custom_terrain_metadata_skips_total="
                + customTerrainMetadataSkips
                + "\nshader_terrain_bridge_fast_skips_total="
                + terrainBridgeFastSkips
                + "\nshader_custom_submission_fast_skips_total="
                + customSubmissionFastSkips
                + "\nshader_conservative_budget_frames_total="
                + conservativeBudgetFrames;
    }

    private static synchronized void ensureInitialized() {
        if (initialized) return;
        initialized = true;
        try {
            Class<?> apiClass =
                    Class.forName(
                            "net.irisshaders.iris.api.v0.IrisApi",
                            false,
                            VeilShaderPackBridge.class.getClassLoader());
            MethodHandles.Lookup lookup = MethodHandles.publicLookup();
            MethodHandle getInstance =
                    lookup.findStatic(apiClass, "getInstance", MethodType.methodType(apiClass));
            Object api = getInstance.invoke();
            MethodHandle shaderPack =
                    lookup.findVirtual(
                            apiClass, "isShaderPackInUse", MethodType.methodType(boolean.class));
            MethodHandle shadowPass =
                    lookup.findVirtual(
                            apiClass,
                            "isRenderingShadowPass",
                            MethodType.methodType(boolean.class));
            MethodHandle minor =
                    lookup.findVirtual(
                            apiClass, "getMinorApiRevision", MethodType.methodType(int.class));

            irisApi = api;
            isShaderPackInUse = shaderPack;
            isRenderingShadowPass = shadowPass;
            getMinorApiRevision = minor;
            irisApiMinorRevision = (int) getMinorApiRevision.invoke(irisApi);
            apiAvailable = true;
        } catch (Throwable throwable) {
            apiAvailable = false;
            ReviveMod.LOGGER.warn(
                    "Iris is installed but Veil could not initialize the optional Iris API bridge; shader-specific policies stay disabled",
                    throwable);
        }
    }

    private static synchronized void disableApi(String message, Throwable throwable) {
        if (!apiAvailable) return;
        apiAvailable = false;
        shaderPackActive = false;
        ReviveMod.LOGGER.warn(
                message + "; Veil is falling back to generic compatibility detection", throwable);
    }
}
