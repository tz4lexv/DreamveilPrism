package dev.veil.revive.client;

final class VeilTerrainPrepareJfrProbe {
    private final long requested = System.nanoTime();
    private long acquired, uploaded, validated, cached, animated, releasing;

    private VeilTerrainPrepareJfrProbe() {}

    static VeilTerrainPrepareJfrProbe begin() {
        return VeilCpuZoneJfrProbe.enabled() ? new VeilTerrainPrepareJfrProbe() : null;
    }

    void acquired() {
        acquired = System.nanoTime();
    }

    void uploadsComplete() {
        uploaded = System.nanoTime();
    }

    void validationComplete() {
        validated = System.nanoTime();
    }

    void cacheComplete() {
        cached = System.nanoTime();
    }

    void animationComplete() {
        animated = System.nanoTime();
    }

    void beforeUnlock() {
        releasing = System.nanoTime();
    }

    void afterUnlock() {
        record("TERRAIN_PUBLICATION_WAIT", requested, acquired);
        record("TERRAIN_PUBLICATION_PROTECTED", acquired, releasing);
        record("TERRAIN_PUBLICATION_UPLOAD", acquired, uploaded);
        record("TERRAIN_PUBLICATION_VALIDATE", uploaded, validated);
        record("TERRAIN_PUBLICATION_CACHE", validated, cached);
        record("TERRAIN_PUBLICATION_ANIMATION", cached, animated);
        record("TERRAIN_PUBLICATION_ASSEMBLY", animated, releasing);
    }

    private static void record(String zone, long begin, long end) {
        if (begin != 0L && end != 0L) VeilCpuZoneJfrProbe.record(zone, begin, end);
    }
}
