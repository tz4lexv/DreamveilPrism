package dev.veil.revive.client;

import dev.veil.api.VeilCreatorMeshes;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.InactivityFpsLimit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.WorldDataConfiguration;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

public final class VeilBenchmarkWorld {
    static volatile long provenanceSection = Long.MIN_VALUE;
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.benchmarkWorld");
    private static final String PREFIX = "Veil-Benchmark-26.2-";
    private static final long SEED = 6840227782638526189L;
    private static final long LOAD_TIMEOUT_NS = 300_000_000_000L;
    private static final long BENCHMARK_TIMEOUT_NS = 180_000_000_000L;
    private static long firstTick;
    private static long nextWaitReport;
    private static volatile long readyAt;

    static boolean terrainReady() {
        return readyAt != 0;
    }

    private static String save;
    private static boolean opened;
    private static boolean preparing;
    private static boolean sawBenchmark;
    private static boolean complete;
    private static volatile boolean prepared;
    private static volatile double preparedCameraY;
    private static volatile double preparedCameraX = 32.5;
    private static volatile double preparedCameraZ = 32.5;
    private static volatile float preparedCameraYaw = 135.0f;
    private static volatile float preparedCameraPitch = 20.0f;
    private static volatile RuntimeException preparationFailure;
    private static SavedOptions options;
    private static VeilDiagnostics.BenchmarkReport initialReport;
    private static net.minecraft.client.player.ClientInput savedInput;
    private static boolean mouseWasGrabbed;
    private static boolean profileReset;
    private static int skyProbeStep;
    public static int worldSpaceProbePhase;
    public static final org.joml.Matrix4f worldSpaceProbeProjection = new org.joml.Matrix4f();
    private static final java.util.concurrent.atomic.AtomicInteger skyCaptures =
            new java.util.concurrent.atomic.AtomicInteger();
    private static VeilCreatorMeshes.Registration meshProbe;

    private VeilBenchmarkWorld() {}

    static boolean tick(Minecraft client) {
        if (!ENABLED) return true;
        try {
            return tickActive(client);
        } catch (RuntimeException failure) {
            complete = true;
            restoreOptions(client);
            ReviveMod.LOGGER.error(
                    "Veil benchmark world: FAIL controlled test stopped: {}", failure.getMessage());
            client.stop();
            return false;
        }
    }

    private static boolean tickActive(Minecraft client) {
        if (!ENABLED || complete) return true;
        long now = System.nanoTime();
        if (firstTick == 0L) firstTick = now;
        if (!Boolean.getBoolean("veil.developmentProbe")
                || Boolean.getBoolean("veil.visualProbe")) {
            throw fail(client, "requires veil.developmentProbe=true and visualProbe=false", null);
        }
        if (preparationFailure != null)
            throw fail(client, "fixture preparation failed", preparationFailure);
        if (readyAt == 0L && now - firstTick > LOAD_TIMEOUT_NS) {
            throw fail(client, "fixture did not become ready within 300 seconds", null);
        }
        if (readyAt != 0L && now - readyAt > BENCHMARK_TIMEOUT_NS) {
            throw fail(
                    client,
                    "benchmark did not finish within 180 seconds after fixture readiness",
                    null);
        }
        if (!opened) {
            if (client.level != null || client.player != null || client.hasSingleplayerServer()) {
                throw fail(
                        client,
                        "refusing to use a world opened outside the dedicated fixture",
                        null);
            }
            if (!client.isGameLoadFinished()
                    || client.gui.overlay() != null
                    || !(client.gui.screen() instanceof TitleScreen)) {
                if (now >= nextWaitReport) {
                    ReviveMod.LOGGER.info(
                            "Veil fixture waiting: loaded={}, overlay={}, screen={}",
                            client.isGameLoadFinished(),
                            client.gui.overlay() == null
                                    ? "none"
                                    : client.gui.overlay().getClass().getName(),
                            client.gui.screen() == null
                                    ? "none"
                                    : client.gui.screen().getClass().getName());
                    nextWaitReport = now + 10_000_000_000L;
                }
                return false;
            }
            try {
                open(client);
            } catch (IOException | RuntimeException failure) {
                throw fail(client, "could not open dedicated fixture", failure);
            }
            return false;
        }
        if (client.level == null
                || client.player == null
                || client.getSingleplayerServer() == null) {
            if (readyAt != 0L)
                throw fail(client, "fixture was left before benchmark completion", null);
            return false;
        }
        if (!save.equals(client.getSingleplayerServer().getWorldData().getLevelName())) {
            throw fail(client, "active world does not match the fixture identity", null);
        }
        if (!preparing) {
            prepare(client);
            return false;
        }
        if (!prepared) return false;
        if (client.gui.overlay() != null || client.gui.screen() != null) {
            if (readyAt == 0L) reportCameraWait(client, now);
            return false;
        }
        if (readyAt == 0L) {
            if (!dev.veil.revive.core.diagnostics.FixtureCameraMatch.matches(
                    client.player.getX(),
                    client.player.getY(),
                    client.player.getZ(),
                    client.player.getYRot(),
                    client.player.getXRot(),
                    preparedCameraX,
                    preparedCameraY,
                    preparedCameraZ,
                    preparedCameraYaw,
                    preparedCameraPitch)) {
                reportCameraWait(client, now);
                return false;
            }
            readyAt = now;
            savedInput = client.player.input;
            client.player.input = new net.minecraft.client.player.ClientInput();
            client.player.setDeltaMovement(net.minecraft.world.phys.Vec3.ZERO);
            mouseWasGrabbed = client.mouseHandler.isMouseGrabbed();
            client.mouseHandler.releaseMouse();
            initialReport = VeilDiagnostics.lastBenchmark();
            installMeshProbe(client);
            ReviveMod.LOGGER.info(
                    "Veil benchmark world: READY save={} seed={} camera=({}, {}, {}) yaw={} pitch={} renderDistance={} simulationDistance={} vsync={} fpsOption={} framebuffer={}x{}; dedicated static scene, production quality unchanged",
                    save,
                    SEED,
                    client.player.getX(),
                    client.player.getY(),
                    client.player.getZ(),
                    client.player.getYRot(),
                    client.player.getXRot(),
                    client.options.renderDistance().get(),
                    client.options.simulationDistance().get(),
                    client.options.enableVsync().get(),
                    client.options.framerateLimit().get(),
                    client.getWindow().getWidth(),
                    client.getWindow().getHeight());
        }
        if (Boolean.getBoolean("veil.fixtureHandoff")) {
            if (now - readyAt > 12_000_000_000L) {
                var directory = Path.of("logs", "cornell-block-room");
                try {
                    Files.createDirectories(directory);
                } catch (IOException failure) {
                    throw new IllegalStateException(failure);
                }
                net.minecraft.client.Screenshot.takeScreenshot(
                        client.gameRenderer.mainRenderTarget(),
                        image -> {
                            try {
                                image.writeToFile(directory.resolve("construction.png"));
                            } catch (IOException failure) {
                                throw new IllegalStateException(failure);
                            } finally {
                                image.close();
                            }
                        });
                finishGraphicsProbe();
                client.getSingleplayerServer()
                        .execute(
                                () -> {
                                    for (var player :
                                            client.getSingleplayerServer()
                                                    .getPlayerList()
                                                    .getPlayers())
                                        player.setGameMode(GameType.CREATIVE);
                                });
                ReviveMod.LOGGER.info(
                        "Veil Cornell block construction: HANDOFF save={} camera=({}, {}, {}); input restored, game remains open",
                        save,
                        preparedCameraX,
                        preparedCameraY,
                        preparedCameraZ);
            }
            return false;
        }
        if (client.mouseHandler.isMouseGrabbed()) client.mouseHandler.releaseMouse();
        if (dev.veil.revive.client.diagnostics.TerrainWorldLifecycleProbe.enabled()) {
            if (dev.veil.revive.client.diagnostics.TerrainWorldLifecycleProbe.tick(client, now)) {
                complete = true;
                restoreOptions(client);
                client.stop();
            }
            return false;
        }
        if (VeilGlobalIlluminationProbe.enabled()
                || VeilWorldRayGpuProbe.enabled()
                || Boolean.getBoolean("veil.worldFogProbe")
                || Boolean.getBoolean("veil.worldCloudProbe")
                || Boolean.getBoolean("veil.sceneCameraProbe")) return false;
        if (Boolean.getBoolean("veil.cameraSweepProbe")) {
            if (VeilCameraSweepProbe.tick(client, now - readyAt)) {
                complete = true;
                restoreOptions(client);
                client.stop();
            }
            return false;
        }
        if (Boolean.getBoolean("veil.shaderWorldProbe")) {
            if (Boolean.getBoolean("veil.physicalSkyProbe"))
                tickPhysicalSkyProbe(client, now - readyAt);
            if (!profileReset && now - readyAt > 30_000_000_000L) {
                VeilShaderService.resetPerformanceSamples();
                profileReset = true;
            }
            if (now - readyAt > 60_000_000_000L) {
                VeilSlangHzbProbe.requireComplete();
                VeilSlangCullProbe.requireComplete();
                VeilShaderService.requirePerformanceSamples(16);
                if (Boolean.getBoolean("veil.physicalSkyProbe")) {
                    if (skyCaptures.get() != 3
                            || !VeilShaderService.replacesVanillaSky()
                            || !VeilShaderService.replacesVanillaSun())
                        throw new IllegalStateException(
                                "Physical sky capture/ownership probe incomplete");
                    ReviveMod.LOGGER.info(
                            "Veil physical sky GPU probe: PASS (day, sunset and night captures; live sky/sun ownership)");
                }
                if (System.getProperty("veil.benchmarkScene", "plain").equals("infrastructure")) {
                    if (!VeilPbrAtlas.ready()
                            || !VeilFluidGeometryHost.lavaDrawn()
                            || !VeilShaderService.replacesWeather()
                            || VeilEnvironmentHost.rain() < .1f)
                        throw new IllegalStateException(
                                "Infrastructure probe requires PBR atlases, visible lava, weather ownership and live rain data");
                    ReviveMod.LOGGER.info(
                            "Veil infrastructure GPU probe: PASS (PBR atlases, lava draws, weather ownership and live rain input)");
                }
                ReviveMod.LOGGER.info(
                        "Veil shader world probe: PASS\n{}{}",
                        VeilShaderService.performanceReport(),
                        VeilShaderPackBridge.telemetry());
                complete = true;
                restoreOptions(client);
                client.stop();
            }
            return false;
        }
        if (VeilDiagnostics.benchmarkActive()) {
            sawBenchmark = true;
        } else if (sawBenchmark) {
            var report = VeilDiagnostics.lastBenchmark();
            if (report == null
                    || report == initialReport
                    || report.blocks().size() != 4
                    || report.veilFrame().count() < 10
                    || report.bypassFrame().count() < 10
                    || report.veilRender().count() < 10
                    || report.bypassRender().count() < 10
                    || !Double.isFinite(report.fpsGainPercent())) {
                throw fail(
                        client,
                        "benchmark cancelled or missing complete measured ON/BYPASS blocks",
                        null);
            }
            VeilArenaGpuProbe.requireComplete();
            VeilIndirectTerrain.requireDirectMultiProbeComplete();
            ReviveMod.LOGGER.info("Veil benchmark world: PASS {}", report.shortResult());
            complete = true;
            restoreOptions(client);
        }
        return true;
    }

    private static void open(Minecraft client) throws IOException {
        Path gameDir = VeilPlatform.get().getGameDir().toAbsolutePath().normalize();
        Path marker = gameDir.resolve("logs/veil-benchmark-fixture.properties");
        Path base = client.getLevelSource().getBaseDir().toAbsolutePath().normalize();
        var selection = FixtureStorage.select(marker, base);
        save = selection.save();
        boolean existing = selection.existing();
        if (selection.incomplete() != null)
            ReviveMod.LOGGER.warn(
                    "Veil benchmark world: preserving incomplete fixture {}; marker now selects fresh fixture {}",
                    selection.incomplete(),
                    save);
        options = SavedOptions.capture(client);
        if (Boolean.getBoolean("veil.shadowThirdPersonProbe")) {
            client.options.setCameraType(net.minecraft.client.CameraType.THIRD_PERSON_BACK);
            client.options.entityShadows().set(false);
        }
        if (Boolean.getBoolean("veil.cloudMotionProbe")
                || Boolean.getBoolean("veil.shadowNoCloudsProbe"))
            client.options.cloudStatus().set(net.minecraft.client.CloudStatus.OFF);
        client.options.renderDistance().set(integerProperty("veil.benchmarkDistance", 16, 8, 32));
        client.options
                .simulationDistance()
                .set(integerProperty("veil.benchmarkSimulationDistance", 8, 5, 32));
        client.options.framerateLimit().set(integerProperty("veil.benchmarkFps", 260, 10, 260));
        client.options.enableVsync().set(false);
        client.options.inactivityFpsLimit().set(InactivityFpsLimit.MINIMIZED);
        client.options.pauseOnLostFocus = false;
        opened = true;
        ReviveMod.LOGGER.info(
                "Veil benchmark world: {} dedicated fixture {} with seed {}",
                existing ? "opening" : "creating",
                save,
                SEED);
        if (existing) {
            client.createWorldOpenFlows()
                    .openWorld(
                            save,
                            () -> {
                                throw fail(client, "host aborted opening the fixture", null);
                            });
        } else {
            var settings =
                    new LevelSettings(
                            save,
                            GameType.SPECTATOR,
                            new LevelSettings.DifficultySettings(Difficulty.PEACEFUL, false, true),
                            true,
                            WorldDataConfiguration.DEFAULT);
            client.createWorldOpenFlows()
                    .createFreshLevel(
                            save,
                            settings,
                            new WorldOptions(SEED, true, false),
                            WorldPresets::createNormalWorldDimensions,
                            client.gui.screen());
        }
        ReviveMod.LOGGER.info(
                "Veil benchmark world: host world-open call returned for {}; awaiting player and camera readiness",
                save);
    }

    static final class FixtureStorage {
        record Selection(String save, boolean existing, String incomplete) {}

        static Selection select(Path marker, Path base) throws IOException {
            base = base.toAbsolutePath().normalize();
            Files.createDirectories(base);
            byte[] oldMarker = null;
            String incomplete = null;
            if (Files.exists(marker, LinkOption.NOFOLLOW_LINKS)) {
                if (!Files.isRegularFile(marker, LinkOption.NOFOLLOW_LINKS)
                        || Files.size(marker) > 4096) {
                    throw new IOException("Fixture marker is not a bounded regular file");
                }
                oldMarker = Files.readAllBytes(marker);
                Properties fixture = new Properties();
                try (var input = new ByteArrayInputStream(oldMarker)) {
                    fixture.load(input);
                }
                String selected = fixture.getProperty("save", "");
                if (!"1".equals(fixture.getProperty("version"))
                        || !Long.toString(SEED).equals(fixture.getProperty("seed"))
                        || !selected.startsWith(PREFIX)) {
                    throw new IOException("Unrecognized benchmark fixture marker");
                }
                String id = selected.substring(PREFIX.length());
                if (!UUID.fromString(id).toString().equals(id))
                    throw new IOException("Noncanonical fixture identity");
                Path world = base.resolve(selected).normalize();
                if (!world.getParent().equals(base) || Files.isSymbolicLink(world)) {
                    throw new IOException("Fixture is outside the save directory");
                }
                if (Files.exists(world, LinkOption.NOFOLLOW_LINKS)) {
                    if (!Files.isDirectory(world, LinkOption.NOFOLLOW_LINKS)
                            || !world.toRealPath().getParent().equals(base.toRealPath())) {
                        throw new IOException("Fixture is not a safe save directory");
                    }
                    Path levelData = world.resolve("level.dat");
                    if (Files.exists(levelData, LinkOption.NOFOLLOW_LINKS)) {
                        if (!Files.isRegularFile(levelData, LinkOption.NOFOLLOW_LINKS)) {
                            throw new IOException("Fixture level.dat is not a regular file");
                        }
                        return new Selection(selected, true, null);
                    }
                }
                incomplete = selected;
            }
            String selected;
            do {
                selected = PREFIX + UUID.randomUUID();
            } while (Files.exists(base.resolve(selected), LinkOption.NOFOLLOW_LINKS));
            Properties fixture = new Properties();
            fixture.setProperty("version", "1");
            fixture.setProperty("save", selected);
            fixture.setProperty("seed", Long.toString(SEED));
            if (incomplete != null) fixture.setProperty("preservedIncomplete", incomplete);
            Files.createDirectories(marker.getParent());
            if (oldMarker == null) {
                try (var output =
                        Files.newOutputStream(
                                marker, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE)) {
                    fixture.store(output, null);
                }
            } else {
                Path temporary =
                        Files.createTempFile(marker.getParent(), "veil-benchmark-fixture-", ".tmp");
                try {
                    try (var output = Files.newOutputStream(temporary)) {
                        fixture.store(output, null);
                    }
                    if (!Files.isRegularFile(marker, LinkOption.NOFOLLOW_LINKS)
                            || !Arrays.equals(oldMarker, Files.readAllBytes(marker))) {
                        throw new IOException("Fixture marker changed during recovery");
                    }
                    Files.move(
                            temporary,
                            marker,
                            StandardCopyOption.ATOMIC_MOVE,
                            StandardCopyOption.REPLACE_EXISTING);
                } finally {
                    Files.deleteIfExists(temporary);
                }
            }
            return new Selection(selected, false, incomplete);
        }
    }

    private static void reportCameraWait(Minecraft client, long now) {
        if (now < nextWaitReport) return;
        nextWaitReport = now + 10_000_000_000L;
        ReviveMod.LOGGER.info(
                "Veil fixture camera waiting: actual=({}, {}, {}, {}, {}) expected=({}, {}, {}, {}, {}) screen={} overlay={}",
                client.player.getX(),
                client.player.getY(),
                client.player.getZ(),
                client.player.getYRot(),
                client.player.getXRot(),
                preparedCameraX,
                preparedCameraY,
                preparedCameraZ,
                preparedCameraYaw,
                preparedCameraPitch,
                client.gui.screen() == null ? "none" : client.gui.screen().getClass().getName(),
                client.gui.overlay() == null ? "none" : client.gui.overlay().getClass().getName());
    }

    private static void prepare(Minecraft client) {
        preparing = true;
        var server = client.getSingleplayerServer();
        UUID playerId = client.player.getUUID();
        server.execute(
                () -> {
                    try {
                        var player = server.getPlayerList().getPlayer(playerId);
                        if (player == null)
                            throw new IllegalStateException(
                                    "Fixture player disappeared during setup");
                        var level = server.overworld();
                        server.getGameRules().set(GameRules.ADVANCE_TIME, false, server);
                        server.getGameRules().set(GameRules.ADVANCE_WEATHER, false, server);
                        var sceneClock =
                                level.dimensionType()
                                        .defaultClock()
                                        .orElseThrow(
                                                () ->
                                                        new IllegalStateException(
                                                                "Benchmark dimension has no default clock"));
                        boolean shadowContact =
                                System.getProperty("veil.benchmarkScene", "plain")
                                        .equals("shadowcontact");
                        server.clockManager()
                                .setTotalTicks(sceneClock, shadowContact ? 4000L : 6000L);
                        server.clockManager().setPaused(sceneClock, true);
                        ReviveMod.LOGGER.info(
                                "Veil fixture clock: ticks={} paused=true",
                                server.clockManager().getTotalTicks(sceneClock));
                        level.resetWeatherCycle();
                        player.setGameMode(
                                Boolean.getBoolean("veil.shadowWalkProbe")
                                        ? GameType.SURVIVAL
                                        : GameType.SPECTATOR);
                        int cameraX = 32, cameraZ = 32;
                        if (shadowContact) {
                            cameraX = Integer.getInteger("veil.shadowFixtureX", 32);
                            cameraZ = Integer.getInteger("veil.shadowFixtureZ", 32);
                            if (Math.abs((long) cameraX) > 29_999_000L
                                    || Math.abs((long) cameraZ) > 29_999_000L)
                                throw new IllegalArgumentException(
                                        "Shadow fixture exceeds world bounds");
                        }
                        if (System.getProperty("veil.benchmarkScene", "plain").equals("forest")) {
                            var found =
                                    level.findClosestBiome3d(
                                            biome ->
                                                    biome.is(
                                                                    net.minecraft.world.level.biome
                                                                            .Biomes.DARK_FOREST)
                                                            || biome.is(
                                                                    net.minecraft.world.level.biome
                                                                            .Biomes.JUNGLE),
                                            new net.minecraft.core.BlockPos(32, 64, 32),
                                            6400,
                                            64,
                                            64);
                            if (found == null)
                                throw new IllegalStateException(
                                        "No dense forest biome found within fixture search radius");
                            cameraX = found.getFirst().getX();
                            cameraZ = found.getFirst().getZ();
                            ReviveMod.LOGGER.info(
                                    "Veil forest fixture: seed={} biome={} x={} z={}",
                                    SEED,
                                    found.getSecond().unwrapKey(),
                                    cameraX,
                                    cameraZ);
                        }
                        level.getChunk(cameraX >> 4, cameraZ >> 4);
                        if (System.getProperty("veil.benchmarkScene", "plain").equals("forest")) {
                            var cursor = new net.minecraft.core.BlockPos.MutableBlockPos();
                            int leaves = 0;
                            int baseX = cameraX & -16, baseZ = cameraZ & -16;
                            for (int x = baseX; x < baseX + 16; x++)
                                for (int z = baseZ; z < baseZ + 16; z++) {
                                    int top =
                                            level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                                    for (int scanY = Math.max(level.getMinY(), top - 40);
                                            scanY < top;
                                            scanY++) {
                                        if (level.getBlockState(cursor.set(x, scanY, z))
                                                .is(net.minecraft.tags.BlockTags.LEAVES)) leaves++;
                                    }
                                }
                            if (leaves == 0)
                                throw new IllegalStateException(
                                        "Forest fixture lacks generated leaf blocks");
                            ReviveMod.LOGGER.info(
                                    "Veil forest fixture verified: {} leaf blocks in camera chunk upper 40 blocks",
                                    leaves);
                        }
                        double y =
                                System.getProperty("veil.benchmarkScene", "plain").equals("forest")
                                        ? level.getHeight(
                                                        Heightmap.Types.MOTION_BLOCKING,
                                                        cameraX,
                                                        cameraZ)
                                                + 3.0
                                        : Math.max(
                                                88.0,
                                                level.getHeight(
                                                                Heightmap.Types
                                                                        .MOTION_BLOCKING_NO_LEAVES,
                                                                cameraX,
                                                                cameraZ)
                                                        + 18.0);
                        if (shadowContact)
                            y = VeilShadowContactFixture.prepare(level, cameraX, cameraZ);
                        boolean cornellRoom =
                                System.getProperty("veil.benchmarkScene", "plain")
                                        .equals("cornellroom");
                        if (cornellRoom)
                            y =
                                    VeilGlobalIlluminationFixture.prepareCornell(
                                            level, cameraX, cameraZ);
                        boolean giRoom =
                                System.getProperty("veil.benchmarkScene", "plain").equals("giroom");
                        if (giRoom)
                            y = VeilGlobalIlluminationFixture.prepare(level, cameraX, cameraZ);
                        boolean shadowWalk = Boolean.getBoolean("veil.shadowWalkProbe");
                        if (shadowWalk) y = 89.0;
                        boolean cloudMotion =
                                System.getProperty("veil.benchmarkScene", "plain")
                                        .equals("cloudmotion");
                        if (cloudMotion) y = 96.0;
                        if (System.getProperty("veil.benchmarkScene", "plain")
                                .equals("infrastructure")) {
                            int ground = (int) y - 8;
                            var cursor = new net.minecraft.core.BlockPos.MutableBlockPos();
                            for (int x = cameraX - 17; x <= cameraX; x++)
                                for (int z = cameraZ - 17; z <= cameraZ; z++) {
                                    level.setBlock(
                                            cursor.set(x, ground, z),
                                            net.minecraft.world.level.block.Blocks.BEDROCK
                                                    .defaultBlockState(),
                                            3);
                                    boolean border =
                                            x == cameraX - 17
                                                    || x == cameraX
                                                    || z == cameraZ - 17
                                                    || z == cameraZ;
                                    level.setBlock(
                                            cursor.set(x, ground + 1, z),
                                            (border
                                                            ? net.minecraft.world.level.block.Blocks
                                                                    .BEDROCK
                                                            : net.minecraft.world.level.block.Blocks
                                                                    .LAVA)
                                                    .defaultBlockState(),
                                            3);
                                }
                            var weather = level.getWeatherData();
                            weather.setClearWeatherTime(0);
                            weather.setRainTime(12000);
                            weather.setRaining(true);
                            weather.setThundering(false);
                        }
                        if (Boolean.getBoolean("veil.verifyModelProvenance")) {
                            int baseY = ((int) y & -16) + 1;
                            provenanceSection =
                                    net.minecraft.core.SectionPos.asLong(
                                            (cameraX - 12) >> 4, baseY >> 4, (cameraZ - 12) >> 4);
                            var cursor = new net.minecraft.core.BlockPos.MutableBlockPos();
                            for (int x = cameraX - 12; x < cameraX - 9; x++)
                                for (int z = cameraZ - 12; z < cameraZ - 9; z++)
                                    for (int h = 0; h < 3; h++)
                                        level.setBlock(
                                                cursor.set(x, baseY + h, z),
                                                net.minecraft.world.level.block.Blocks.PRISMARINE
                                                        .defaultBlockState(),
                                                3);
                            ReviveMod.LOGGER.info(
                                    "Veil model provenance fixture: 27 prismarine blocks at {}",
                                    baseY);
                            VeilChangedLightGpuProbe.prepare(
                                    level,
                                    new net.minecraft.core.BlockPos(
                                            cameraX - 18, baseY + 1, cameraZ - 11));
                        }
                        preparedCameraX =
                                cameraX + 0.5 - (shadowContact && !shadowWalk ? 16.0 : 0.0);
                        preparedCameraZ = cameraZ + 0.5;
                        preparedCameraY = y;
                        preparedCameraYaw = shadowWalk ? 90.0f : shadowContact ? 225.0f : 135.0f;
                        if (shadowWalk && Boolean.getBoolean("veil.shadowThirdPersonProbe"))
                            preparedCameraYaw = 270.0f;
                        preparedCameraPitch = shadowWalk ? 55.0f : cloudMotion ? -35.0f : 20.0f;
                        if (giRoom) {
                            preparedCameraYaw = 180.0f;
                            preparedCameraPitch = 15.0f;
                        }
                        if (cornellRoom) {
                            preparedCameraZ = cameraZ + 6.5;
                            preparedCameraYaw = 180.0f;
                            preparedCameraPitch = 0.0f;
                        }
                        if (!player.teleportTo(
                                level,
                                preparedCameraX,
                                y,
                                preparedCameraZ,
                                Set.of(),
                                preparedCameraYaw,
                                preparedCameraPitch,
                                true)) {
                            throw new IllegalStateException("Fixture camera teleport was rejected");
                        }
                        installAnimatedMeshProbe(level, player);
                        prepared = true;
                    } catch (RuntimeException failure) {
                        preparationFailure = failure;
                    }
                });
    }

    private static int integerProperty(String key, int fallback, int minimum, int maximum) {
        int value = Integer.parseInt(System.getProperty(key, Integer.toString(fallback)));
        if (value < minimum || value > maximum)
            throw new IllegalArgumentException(key + " is outside the benchmark bounds");
        return value;
    }

    private static void installAnimatedMeshProbe(
            net.minecraft.server.level.ServerLevel level,
            net.minecraft.server.level.ServerPlayer player) {
        if (!Boolean.getBoolean("veil.shaderWorldProbe")
                || !"shadowtrace".equals(System.getProperty("veil.shaderPack"))) return;
        UUID id = UUID.fromString("9d6f2102-318f-4dcb-84ce-86014edfbba1");
        var old = level.getEntityInAnyDimension(id);
        if (old != null) old.discard();
        var stand =
                net.minecraft.world.entity.EntityTypes.ARMOR_STAND.create(
                        level, net.minecraft.world.entity.EntitySpawnReason.COMMAND);
        if (stand == null)
            throw new IllegalStateException("Could not create animated shadow capture probe");

        var look = net.minecraft.world.phys.Vec3.directionFromRotation(20.0f, 135.0f);
        var target = player.getEyePosition().add(look.scale(6.0)).add(0.0, -1.0, 0.0);
        stand.setUUID(id);
        stand.setPos(target.x, target.y, target.z);
        stand.setNoGravity(true);
        stand.setYRot(45.0f);
        if (!level.addFreshEntity(stand))
            throw new IllegalStateException("Could not add animated shadow capture probe");
        ReviveMod.LOGGER.info("Veil shadow capture probe: spawned visible armor stand {}", id);
    }

    private static IllegalStateException fail(Minecraft client, String message, Throwable cause) {
        restoreOptions(client);
        ReviveMod.LOGGER.error("Veil benchmark world: FAIL {}", message, cause);
        return new IllegalStateException("Veil benchmark world: FAIL " + message, cause);
    }

    private static void tickPhysicalSkyProbe(Minecraft client, long elapsed) {
        if (skyProbeStep >= 6 || elapsed < (5L + skyProbeStep * 7L) * 1_000_000_000L) return;
        int phase = skyProbeStep / 2;
        boolean bobProbe = Boolean.getBoolean("veil.worldSpaceProbe");
        boolean rotationProbe = Boolean.getBoolean("veil.physicalSkyRotationProbe") && !bobProbe;
        if ((skyProbeStep & 1) == 0) {
            worldSpaceProbePhase = phase;
            String time =
                    rotationProbe || bobProbe
                            ? "12000"
                            : new String[] {"6000", "12000", "18000"}[phase];
            var server = client.getSingleplayerServer();
            server.execute(
                    () ->
                            server.getCommands()
                                    .performPrefixedCommand(
                                            server.createCommandSourceStack(), "time set " + time));
            client.player.setYRot(rotationProbe && phase == 1 ? 270.0f : 90.0f);
            client.player.setXRot(rotationProbe && phase == 2 ? -50.0f : -10.0f);
        } else {
            String name =
                    bobProbe
                            ? "bob-" + phase
                            : rotationProbe
                                    ? new String[] {"world-west", "world-east", "world-up"}[phase]
                                    : new String[] {"day", "sunset", "night"}[phase];
            Path directory = VeilPlatform.get().getGameDir().resolve("screenshots/physical-sky");
            try {
                Files.createDirectories(directory);
            } catch (IOException failure) {
                throw new RuntimeException(failure);
            }
            if (bobProbe) {
                var camera =
                        client.gameRenderer.gameRenderState().levelRenderState.cameraRenderState;
                var clip =
                        new org.joml.Matrix4f(worldSpaceProbeProjection)
                                .mul(camera.viewRotationMatrix);
                float[] values = new float[16];
                clip.get(values);
                try {
                    Files.writeString(
                            directory.resolve(name + "-matrix.txt"),
                            java.util.Arrays.toString(values));
                    Files.writeString(
                            directory.resolve(name + "-position.txt"),
                            "[" + camera.pos.x + ", " + camera.pos.y + ", " + camera.pos.z + "]");
                } catch (IOException failure) {
                    throw new RuntimeException(failure);
                }
            }
            net.minecraft.client.Screenshot.takeScreenshot(
                    client.gameRenderer.mainRenderTarget(),
                    image -> {
                        try {
                            image.writeToFile(directory.resolve(name + ".png"));
                            skyCaptures.incrementAndGet();
                        } catch (IOException failure) {
                            throw new RuntimeException(failure);
                        } finally {
                            image.close();
                        }
                    });
        }
        skyProbeStep++;
    }

    private static void installMeshProbe(Minecraft client) {
        String pack = System.getProperty("veil.shaderPack");
        if (meshProbe != null
                || !Boolean.getBoolean("veil.shaderWorldProbe")
                || !("meshtrace".equals(pack) || "shadowtrace".equals(pack))) return;
        var eye = client.player.getEyePosition();
        var center = eye.add(client.player.getLookAngle().scale(6.0));
        float x0 = (float) center.x - 1.0f, x1 = (float) center.x + 1.0f;
        float y0 = (float) center.y - 1.0f, y1 = (float) center.y + 1.0f;
        float z0 = (float) center.z - 1.0f, z1 = (float) center.z + 1.0f;
        float[] vertices = {
            x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0,
            x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1
        };
        int[] indices = {
            0, 2, 1, 0, 3, 2, 4, 5, 6, 4, 6, 7,
            0, 1, 5, 0, 5, 4, 3, 7, 6, 3, 6, 2,
            0, 4, 7, 0, 7, 3, 1, 2, 6, 1, 6, 5
        };
        meshProbe =
                VeilCreatorMeshes.register(
                        new VeilCreatorMeshes.Mesh(
                                0x5645494c4d455348L, 1, 0, vertices, null, indices));
        ReviveMod.LOGGER.info(
                "Veil creator mesh probe: registered exact indexed fixture with 8 vertices / 12 triangles");
    }

    static void finishGraphicsProbe() {
        if (!ENABLED) return;
        complete = true;
        restoreOptions(Minecraft.getInstance());
    }

    private static void restoreOptions(Minecraft client) {
        if (meshProbe != null) {
            meshProbe.close();
            meshProbe = null;
        }
        if (savedInput != null && client.player != null) client.player.input = savedInput;
        savedInput = null;
        if (mouseWasGrabbed && client.player != null && client.gui.screen() == null)
            client.mouseHandler.grabMouse();
        mouseWasGrabbed = false;
        SavedOptions saved = options;
        options = null;
        if (saved == null) return;
        client.options.renderDistance().set(saved.renderDistance());
        client.options.simulationDistance().set(saved.simulationDistance());
        client.options.framerateLimit().set(saved.fps());
        client.options.enableVsync().set(saved.vsync());
        client.options.inactivityFpsLimit().set(saved.inactivity());
        client.options.pauseOnLostFocus = saved.pauseOnLostFocus();
        client.options.cloudStatus().set(saved.cloudStatus());
        client.options.setCameraType(saved.cameraType());
        client.options.entityShadows().set(saved.entityShadows());
    }

    private record SavedOptions(
            int renderDistance,
            int simulationDistance,
            int fps,
            boolean vsync,
            InactivityFpsLimit inactivity,
            boolean pauseOnLostFocus,
            net.minecraft.client.CloudStatus cloudStatus,
            net.minecraft.client.CameraType cameraType,
            boolean entityShadows) {
        static SavedOptions capture(Minecraft client) {
            return new SavedOptions(
                    client.options.renderDistance().get(),
                    client.options.simulationDistance().get(),
                    client.options.framerateLimit().get(),
                    client.options.enableVsync().get(),
                    client.options.inactivityFpsLimit().get(),
                    client.options.pauseOnLostFocus,
                    client.options.cloudStatus().get(),
                    client.options.getCameraType(),
                    client.options.entityShadows().get());
        }
    }
}
