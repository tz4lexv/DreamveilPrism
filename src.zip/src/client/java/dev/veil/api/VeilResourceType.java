package dev.veil.api;

public enum VeilResourceType {
    BUFFER,
    TEXTURE_2D,
    TEXTURE_2D_ARRAY,
    TEXTURE_3D,
    CUBEMAP,
    CUBEMAP_ARRAY,
    TEXTURE_1D,
    TEXTURE_1D_ARRAY
}
