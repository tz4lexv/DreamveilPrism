package dev.veil.revive.client;

import dev.veil.revive.core.MortonSectionVisibilityForest;
import dev.veil.revive.core.WallClockCadence;
import dev.veil.revive.mixin.FrustumAccessor;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;

import org.joml.Matrix4f;

import java.util.List;

public final class VeilSectionVisibilityIndex {
    private static final long HASH_A = 0xcbf29ce484222325L;
    private static final long HASH_B = 0x9e3779b97f4a7c15L;
    private static final int MAX_ENTITY_SECTION_CELLS = 50;
    private static final long SIGNATURE_AUDIT_INTERVAL_NS = 2_000_000_000L;
    private static final WallClockCadence SIGNATURE_AUDIT_CADENCE = new WallClockCadence();

    private static volatile Snapshot published = Snapshot.EMPTY;
    private static Snapshot active = Snapshot.EMPTY;

    private static long observedViewLo;
    private static long observedViewHi;
    private static boolean observedViewValid;

    private static boolean collectTelemetry;
    private static long lastUpdateViewLo = Long.MIN_VALUE;
    private static long lastUpdateViewHi = Long.MIN_VALUE;
    private static boolean lastUpdateViewValid;

    private static long rebuilds;
    private static long reusedPublications;
    private static long activePasses;
    private static long fallbackPasses;
    private static long boxQueries;
    private static long boxRejects;
    private static long largeBoxFallbacks;

    private VeilSectionVisibilityIndex() {}

    public static void beginEntityExtraction(Frustum frustum) {
        if (!ReviveRuntime.optimizationsEnabled()
                || !VeilVideoConfig.on("renderer.entityCulling")
                || frustum == null) {
            active = Snapshot.EMPTY;
            return;
        }

        collectTelemetry =
                VeilDiagnostics.benchmarkActive() || ReviveRuntime.config().profilerEnabled();
        Matrix4f matrix = ((FrustumAccessor) frustum).revive$getMatrix();
        long currentLo = viewHashLo(matrix);
        long currentHi = viewHashHi(matrix);
        observedViewLo = currentLo;
        observedViewHi = currentHi;
        observedViewValid = true;

        Snapshot snapshot = published;
        boolean currentHostState =
                snapshot.visibilityRevision == VeilHostRevisions.visibility()
                        && snapshot.globalRevision == VeilHostRevisions.global();
        boolean sameView = snapshot.viewLo == currentLo && snapshot.viewHi == currentHi;
        if (snapshot.forest.sectionCount() != 0 && currentHostState && sameView) {
            active = snapshot;
            if (collectTelemetry) activePasses++;
        } else {
            active = Snapshot.EMPTY;
            if (collectTelemetry) fallbackPasses++;
        }
    }

    public static void endEntityExtraction() {
        active = Snapshot.EMPTY;
    }

    public static void update(List<SectionRenderDispatcher.RenderSection> visibleSections) {
        if (!ReviveRuntime.optimizationsEnabled()
                || !VeilVideoConfig.on("renderer.entityCulling")
                || visibleSections == null) return;

        Snapshot previous = published;
        long visibilityRevision = VeilHostRevisions.visibility();
        long globalRevision = VeilHostRevisions.global();
        boolean revisionStable =
                previous.visibilityRevision == visibilityRevision
                        && previous.globalRevision == globalRevision;
        boolean sizeStable = previous.visibleCount == visibleSections.size();
        boolean audit =
                revisionStable
                        && sizeStable
                        && SIGNATURE_AUDIT_CADENCE.due(
                                System.nanoTime(), SIGNATURE_AUDIT_INTERVAL_NS);

        long signature = previous.signature;
        boolean topologyStable = revisionStable && sizeStable;
        if (topologyStable && audit) {
            signature = signature(visibleSections);
            topologyStable = signature == previous.signature;
        }

        long viewLo = observedViewValid ? observedViewLo : Long.MIN_VALUE;
        long viewHi = observedViewValid ? observedViewHi : Long.MIN_VALUE;
        boolean viewStable =
                observedViewValid
                        && lastUpdateViewValid
                        && viewLo == lastUpdateViewLo
                        && viewHi == lastUpdateViewHi;
        lastUpdateViewLo = viewLo;
        lastUpdateViewHi = viewHi;
        lastUpdateViewValid = observedViewValid;

        if (topologyStable) {

            if (viewStable && (previous.viewLo != viewLo || previous.viewHi != viewHi)) {
                published =
                        new Snapshot(
                                previous.forest,
                                visibilityRevision,
                                globalRevision,
                                viewLo,
                                viewHi,
                                previous.visibleCount,
                                previous.signature);
            }
            if (collectTelemetry) reusedPublications++;
            return;
        }

        SIGNATURE_AUDIT_CADENCE.scheduleFrom(System.nanoTime(), SIGNATURE_AUDIT_INTERVAL_NS);
        MortonSectionVisibilityForest.Builder builder =
                MortonSectionVisibilityForest.builder(visibleSections.size());
        for (SectionRenderDispatcher.RenderSection section : visibleSections) {
            BlockPos origin = section.getRenderOrigin();
            builder.add(origin.getX() >> 4, origin.getY() >> 4, origin.getZ() >> 4);
        }

        if (!audit || signature == previous.signature) signature = signature(visibleSections);
        MortonSectionVisibilityForest forest = builder.build();
        published =
                new Snapshot(
                        forest,
                        visibilityRevision,
                        globalRevision,
                        viewStable ? viewLo : Long.MIN_VALUE,
                        viewStable ? viewHi : Long.MIN_VALUE,
                        visibleSections.size(),
                        signature);
        if (collectTelemetry) rebuilds++;
    }

    public static boolean isBoxVisible(AABB box) {
        Snapshot snapshot = active;
        if (snapshot == Snapshot.EMPTY || box == null) return true;
        if (!Double.isFinite(box.minX)
                || !Double.isFinite(box.minY)
                || !Double.isFinite(box.minZ)
                || !Double.isFinite(box.maxX)
                || !Double.isFinite(box.maxY)
                || !Double.isFinite(box.maxZ)) {
            return true;
        }

        int minX = sectionCoord(box.minX - 0.5D);
        int minY = sectionCoord(box.minY - 0.5D);
        int minZ = sectionCoord(box.minZ - 0.5D);
        int maxX = sectionCoord(box.maxX + 0.5D);
        int maxY = sectionCoord(box.maxY + 0.5D);
        int maxZ = sectionCoord(box.maxZ + 0.5D);

        long spanX = (long) maxX - minX + 1L;
        long spanY = (long) maxY - minY + 1L;
        long spanZ = (long) maxZ - minZ + 1L;
        if (spanX <= 0L || spanY <= 0L || spanZ <= 0L) return true;
        if (spanX > MAX_ENTITY_SECTION_CELLS
                || spanY > MAX_ENTITY_SECTION_CELLS
                || spanZ > MAX_ENTITY_SECTION_CELLS) {
            if (collectTelemetry) largeBoxFallbacks++;
            return true;
        }
        long cells = spanX * spanY * spanZ;
        if (cells > MAX_ENTITY_SECTION_CELLS) {
            if (collectTelemetry) largeBoxFallbacks++;
            return true;
        }

        if (collectTelemetry) boxQueries++;
        boolean visible = snapshot.forest.anyPresent(minX, minY, minZ, maxX, maxY, maxZ);
        if (!visible && collectTelemetry) boxRejects++;
        return visible;
    }

    public static void invalidate() {
        published = Snapshot.EMPTY;
        active = Snapshot.EMPTY;
        observedViewValid = false;
        lastUpdateViewValid = false;
        lastUpdateViewLo = Long.MIN_VALUE;
        lastUpdateViewHi = Long.MIN_VALUE;
        SIGNATURE_AUDIT_CADENCE.reset();
    }

    public static void resetTelemetry() {
        rebuilds = 0L;
        reusedPublications = 0L;
        activePasses = 0L;
        fallbackPasses = 0L;
        boxQueries = 0L;
        boxRejects = 0L;
        largeBoxFallbacks = 0L;
    }

    public static String telemetryLine() {
        Snapshot snapshot = published;
        return "hierarchical section index: visible="
                + snapshot.visibleCount
                + " trees="
                + snapshot.forest.treeCount()
                + " rebuilds="
                + rebuilds
                + " reuse="
                + reusedPublications
                + " active/fallback passes="
                + activePasses
                + "/"
                + fallbackPasses
                + " entity-box queries/rejects="
                + boxQueries
                + "/"
                + boxRejects
                + " large-box fallback="
                + largeBoxFallbacks;
    }

    private static int sectionCoord(double blockCoordinate) {
        return (int) Math.floor(blockCoordinate / 16.0D);
    }

    private static long signature(List<SectionRenderDispatcher.RenderSection> sections) {
        long h = HASH_A;
        for (SectionRenderDispatcher.RenderSection section : sections) {
            BlockPos origin = section.getRenderOrigin();
            h ^= origin.getX() >> 4;
            h *= 0x100000001b3L;
            h ^= origin.getY() >> 4;
            h *= 0x100000001b3L;
            h ^= origin.getZ() >> 4;
            h *= 0x100000001b3L;
        }
        return h;
    }

    private static long viewHashLo(Matrix4f m) {
        long h = HASH_A;
        h = mix(h, Float.floatToRawIntBits(m.m00()));
        h = mix(h, Float.floatToRawIntBits(m.m02()));
        h = mix(h, Float.floatToRawIntBits(m.m10()));
        h = mix(h, Float.floatToRawIntBits(m.m12()));
        h = mix(h, Float.floatToRawIntBits(m.m20()));
        h = mix(h, Float.floatToRawIntBits(m.m22()));
        h = mix(h, Float.floatToRawIntBits(m.m30()));
        h = mix(h, Float.floatToRawIntBits(m.m32()));
        return h;
    }

    private static long viewHashHi(Matrix4f m) {
        long h = HASH_B;
        h = mix(h, Float.floatToRawIntBits(m.m01()));
        h = mix(h, Float.floatToRawIntBits(m.m03()));
        h = mix(h, Float.floatToRawIntBits(m.m11()));
        h = mix(h, Float.floatToRawIntBits(m.m13()));
        h = mix(h, Float.floatToRawIntBits(m.m21()));
        h = mix(h, Float.floatToRawIntBits(m.m23()));
        h = mix(h, Float.floatToRawIntBits(m.m31()));
        h = mix(h, Float.floatToRawIntBits(m.m33()));
        return h;
    }

    private static long mix(long hash, int bits) {
        long x = hash ^ (bits & 0xffffffffL);
        x *= 0x100000001b3L;
        x ^= x >>> 32;
        return x;
    }

    private record Snapshot(
            MortonSectionVisibilityForest forest,
            long visibilityRevision,
            long globalRevision,
            long viewLo,
            long viewHi,
            int visibleCount,
            long signature) {
        private static final Snapshot EMPTY =
                new Snapshot(
                        MortonSectionVisibilityForest.empty(),
                        Long.MIN_VALUE,
                        Long.MIN_VALUE,
                        Long.MIN_VALUE,
                        Long.MIN_VALUE,
                        0,
                        0L);
    }
}
