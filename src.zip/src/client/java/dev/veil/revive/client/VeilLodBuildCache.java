package dev.veil.revive.client;

import dev.veil.revive.client.terrain.lod.ExactLodBuildCache;
import dev.veil.revive.core.PlanarTerrainLod;
import dev.veil.revive.platform.VeilPlatform;

import java.nio.ByteBuffer;

final class VeilLodBuildCache {
    private static final ExactLodBuildCache CACHE =
            new ExactLodBuildCache(
                    VeilPlatform.get().getGameDir(),
                    () -> VeilVideoConfig.flag("renderer.lodCache", true),
                    () -> VeilVideoConfig.flag("renderer.lightOnlyLod", true));

    private VeilLodBuildCache() {}

    static PlanarTerrainLod.Result build(ByteBuffer vertices, int vertexCount, boolean lightOnly) {
        return CACHE.build(vertices, vertexCount, lightOnly);
    }

    static String telemetry() {
        return CACHE.telemetry();
    }
}
