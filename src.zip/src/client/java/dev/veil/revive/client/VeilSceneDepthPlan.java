package dev.veil.revive.client;

import dev.veil.api.VeilFormat;

import java.util.LinkedHashSet;
import java.util.Set;

final class VeilSceneDepthPlan {
    private VeilSceneDepthPlan() {}

    static Set<String> select(VeilShaderPack.Prepared prepared) {
        var result = new LinkedHashSet<String>();
        var pack = prepared.pack();
        for (var pass : pack.passes()) {
            if (!pass.scenePass()
                    || pass.colors().size() != 1
                    || !pass.scene()
                            .categories()
                            .contains(dev.veil.api.VeilScenePass.Category.TERRAIN_OPAQUE)) continue;
            String color = pass.colors().getFirst().resource();
            var resource = pack.resources().get(color);
            if (resource == null
                    || resource.source() != VeilShaderPack.Source.OWNED
                    || resource.lifetime() != VeilShaderPack.Lifetime.TRANSIENT
                    || resource.format() != VeilFormat.RGBA8_UNORM
                    || color.equals(pack.present())) continue;
            boolean unused = true;
            boolean written = false;
            for (var graphPass : prepared.graph()) {
                for (var use : graphPass.uses()) {
                    if (!use.resource().equals(color)) continue;
                    if (use.access().reads() || !graphPass.name().equals(pass.name()))
                        unused = false;
                    if (use.access().writes()) written = true;
                }
            }
            if (unused && written) result.add(pass.name());
        }
        return Set.copyOf(result);
    }
}
