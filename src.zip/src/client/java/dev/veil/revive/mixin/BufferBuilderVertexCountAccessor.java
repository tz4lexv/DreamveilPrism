package dev.veil.revive.mixin;

import com.mojang.blaze3d.vertex.BufferBuilder;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BufferBuilder.class)
public interface BufferBuilderVertexCountAccessor {
    @Accessor("vertices")
    int veil$vertexCount();
}
