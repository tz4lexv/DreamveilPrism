package dev.veil.revive.mixin;

import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.feature.FeatureRenderDispatcher;
import net.minecraft.client.renderer.state.level.LevelRenderState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(LevelRenderer.class)
public interface LevelRendererSceneAccessor {
    @Accessor("chunkLayerSampler")
    GpuSampler veil$chunkLayerSampler();

    @Accessor("featureRenderDispatcher")
    FeatureRenderDispatcher veil$featureRenderDispatcher();

    @Invoker("submitEntities")
    void veil$submitEntities(
            PoseStack poseStack, LevelRenderState state, SubmitNodeCollector output);

    @Invoker("submitBlockEntities")
    void veil$submitBlockEntities(
            PoseStack poseStack, LevelRenderState state, SubmitNodeCollector output);
}
