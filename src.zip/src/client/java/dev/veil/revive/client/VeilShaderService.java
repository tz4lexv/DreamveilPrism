package dev.veil.revive.client;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

public final class VeilShaderService {
    private static final VeilShaderId BUNDLED_PACK_INDEX =
            VeilShaderId.parse("veil:shaderpacks/examples.index");

    private record Request(long revision, String selected, Map<String, String> settings) {
        private Request {
            settings = Map.copyOf(settings);
        }
    }

    private record Source(
            String selected,
            String namespace,
            Path externalPath,
            VeilShaderAssets assets,
            VeilShaderLibrary library) {}

    private static final VeilShaderMetrics METRICS = new VeilShaderMetrics();
    private static final AtomicBoolean STOPPED = new AtomicBoolean();
    private static final AtomicBoolean RELOAD = new AtomicBoolean();
    private static final AtomicLong REVISIONS = new AtomicLong();
    private static final AtomicReference<Request> REQUEST = new AtomicReference<>();
    private static final VeilHistoryState HISTORY = new VeilHistoryState();
    private static ScheduledExecutorService worker;
    private static VeilShaderReload<VeilShaderPack.Prepared, VeilShaderPackRuntime> reload;
    private static VeilPipelineCache<
                    VeilShaderPackRuntime.PipelineKey, VeilShaderPackRuntime.Pipeline>
            pipelines;
    private static volatile Map<String, VeilShaderPack.Setting> settings = Map.of();
    private static Source source;
    private static String observedSourceFingerprint = "";
    private static String watchDiagnostic = "";
    private static String lastDiagnostic = "";
    private static boolean initialized;
    private static boolean executionFailed;
    private static volatile int fluidGeometryReplacementMask;
    private static volatile boolean worldRayScene;
    private static boolean profiling = Boolean.getBoolean("veil.shaderProfile");
    private static String executionDiagnostic = "";
    private static long submittedRevision = -1;
    private static String submittedSelection = "";
    private static String publishedSelection = "";
    private static long startNanos;
    private static long previousNanos;
    private static boolean recorded;
    private static Path packRoot;
    private static Path configPath;

    private VeilShaderService() {}

    public static void beginFrame() {
        VeilGiConformanceProbe.prepareClient();
        if (STOPPED.get()) return;
        RenderSystem.assertOnRenderThread();
        var backend = VeilVulkanRuntime.backendState();
        if (backend == VeilVulkanRuntime.BackendState.PENDING) return;
        if (!initialized) {
            initialized = true;
            if (backend != VeilVulkanRuntime.BackendState.VULKAN) {
                ReviveMod.LOGGER.info(
                        "Veil shader pack DISABLED: Minecraft Vulkan backend required");
                return;
            }
            initialize();
        }
        if (reload == null) return;
        Request request = REQUEST.get();
        boolean requestedReload = RELOAD.getAndSet(false);
        if (request != null && (request.revision() != submittedRevision || requestedReload)) {
            submittedRevision = request.revision();
            submittedSelection = request.selected();
            if (request.selected().isEmpty()) {
                reload.close();
                reload = createReload();
                settings = Map.of();
                publishedSelection = "";
                executionFailed = false;
                setFluidGeometryReplacement(false, false, "shader pack disabled");
                setWorldRayScene(false, "shader pack disabled");
                VeilPbrAtlas.close();
                VeilEnvironmentHost.close();
                recorded = false;
                HISTORY.invalidate();
            } else {
                reload.request(() -> prepare(request));
            }
        }
        if (reload.publishAtFrameBoundary()) {
            if (!reload.active().usesPbrAtlas()) VeilPbrAtlas.close();
            settings = reload.active().settings();
            publishedSelection = submittedSelection;
            executionFailed = false;
            setFluidGeometryReplacement(
                    reload.active().usesFluidGeometryWater(),
                    reload.active().usesFluidGeometryLava(),
                    "shader pack published");
            VeilWorldRayScene.incremental(reload.active().usesIncrementalWorldRayScene());
            VeilWorldRayScene.accelerationRequested(reload.active().usesWorldRayAcceleration());
            setWorldRayScene(reload.active().usesWorldRayScene(), "shader pack published");
            recorded = false;
            HISTORY.invalidate();
            ReviveMod.LOGGER.info("Veil shader pack READY: {}", reload.active().status());
        }
        String diagnostic = reload.diagnostic();
        if (!lastDiagnostic.equals(diagnostic)) {
            lastDiagnostic = diagnostic;
            ReviveMod.LOGGER.info("Veil shader reload: {}", diagnostic);
        }
    }

    private static void initialize() {
        packRoot = Minecraft.getInstance().gameDirectory.toPath().resolve("shaderpacks");
        configPath =
                Minecraft.getInstance().gameDirectory.toPath().resolve("config/veil-shaders.json");
        pipelines = new VeilPipelineCache<>(64, METRICS);
        worker =
                Executors.newSingleThreadScheduledExecutor(
                        runnable -> {
                            Thread thread = new Thread(runnable, "Veil shader compiler");
                            thread.setDaemon(true);
                            return thread;
                        });
        reload = createReload();
        worker.execute(VeilShaderService::loadConfiguration);
        worker.scheduleWithFixedDelay(VeilShaderService::watch, 500, 500, TimeUnit.MILLISECONDS);
        startNanos = previousNanos = System.nanoTime();
    }

    private static VeilShaderReload<VeilShaderPack.Prepared, VeilShaderPackRuntime> createReload() {
        return new VeilShaderReload<>(
                worker,
                prepared -> {
                    var target = Minecraft.getInstance().gameRenderer.mainRenderTarget();
                    return new VeilShaderPackRuntime(
                            VeilVulkanRuntime.requireCurrent(),
                            prepared,
                            pipelines,
                            METRICS,
                            Math.max(1, target.width),
                            Math.max(1, target.height),
                            target.getColorTexture().getFormat());
                },
                METRICS);
    }

    private static void loadConfiguration() {
        var configuration =
                dev.veil.revive.client.shaderpack.reload.PackConfiguration.read(
                        configPath,
                        System.getProperty("veil.shaderPack"),
                        message -> ReviveMod.LOGGER.warn("Veil shader configuration: {}", message));
        String selected = configuration.selected();
        var values = new LinkedHashMap<>(configuration.settings());
        values.putAll(VeilShaderSceneProbe.overrides());
        values.putAll(VeilCreatorGraphicsProbe.overrides());
        values.putAll(VeilWorldVolumeProbe.overrides());
        values.putAll(VeilGlobalIlluminationProbe.overrides());
        values.putAll(VeilSceneCameraProbe.overrides());
        values.putAll(VeilShadowMotionProbe.overrides());
        REQUEST.compareAndSet(
                null, new Request(REVISIONS.incrementAndGet(), selected.trim(), values));
    }

    private static VeilShaderPack.Prepared prepare(Request request) throws IOException {
        if (source == null || !source.selected().equals(request.selected())) {
            String namespace;
            Path externalPath = null;
            VeilShaderAssets assets;
            if (bundledPacks().contains(request.selected())) {
                namespace = request.selected();
                assets = VeilShaderAssets.bundledPack(namespace, namespace);
            } else {
                namespace = "pack";
                externalPath = Path.of(request.selected());
                if (!externalPath.isAbsolute()) externalPath = packRoot.resolve(externalPath);
                externalPath = externalPath.toRealPath();
                assets = VeilShaderAssets.external(externalPath, namespace);
            }
            source =
                    new Source(
                            request.selected(),
                            namespace,
                            externalPath,
                            assets,
                            new VeilShaderLibrary(assets, METRICS, 128));
            observedSourceFingerprint = "";
        }
        var loaded =
                VeilShaderPackSource.load(
                        source.assets(), source.namespace(), source.selected(), request.settings());
        var prepared = loaded.pack().prepare(source.library());
        VeilShaderPackSource.verifyDescriptor(source.assets(), loaded);
        return prepared;
    }

    private static void watch() {
        if (STOPPED.get() || source == null || source.externalPath() == null) return;
        Request request = REQUEST.get();
        if (request == null || !request.selected().equals(source.selected())) return;
        try {
            String fingerprint = sourceFingerprint(source);
            if (!observedSourceFingerprint.isEmpty()
                    && !observedSourceFingerprint.equals(fingerprint)) RELOAD.set(true);
            observedSourceFingerprint = fingerprint;
            watchDiagnostic = "";
        } catch (IOException | RuntimeException failure) {
            String message = "Veil shader watch: " + failure.getMessage();
            if (!message.equals(watchDiagnostic)) {
                watchDiagnostic = message;
                ReviveMod.LOGGER.warn(message);
            }
        }
    }

    private static String sourceFingerprint(Source current) throws IOException {
        return dev.veil.revive.client.shaderpack.reload.PackSources.fingerprint(
                current.externalPath(), current.assets(), current.namespace());
    }

    public static void execute() {
        if (STOPPED.get()) return;
        VeilSceneRasterGpuProbe.tick();
        VeilVolumeSupportGpuProbe.timeout(executionFailed);
        VeilColorPipelineGpuProbe.timeout(executionFailed);
        VeilCreatorHostPerformanceProbe.timeout(executionFailed);
        VeilBasicShadowSlangGpuProbe.timeout(executionFailed);
        VeilGiConformanceProbe.timeout(executionFailed);
        var active = reload == null ? null : reload.active();
        VeilShaderRuntimeProbe.tick(active, executionFailed);
        VeilShaderSceneProbe.tick(active, executionFailed);
        VeilShadowSceneProbe.tick(active, executionFailed);
        VeilWorldVolumeProbe.checkTimeout(executionFailed);
        VeilShaderHistoryGpuProbe.checkTimeout(executionFailed);
        VeilWorldHistoryGpuProbe.checkTimeout(executionFailed);
        VeilGlobalIlluminationProbe.checkTimeout(executionFailed);
        VeilWorldRayGpuProbe.checkTimeout(executionFailed || (reload != null && reload.failed()));
        VeilSceneCameraProbe.checkTimeout(executionFailed);
        VeilShadowMotionProbe.checkTimeout(executionFailed);
        VeilSimulationTransferGpuProbe.checkTimeout(executionFailed);
        VeilSimulationSubresourceGpuProbe.checkTimeout(
                executionFailed || (reload != null && reload.failed()));
        if (active == null || active.requiresScene() || executionFailed) return;
        execute(active, false, null, 0.0f);
    }

    public static boolean usesSurfaceTransforms() {
        var active = reload == null ? null : reload.active();
        return active != null && active.usesSurfaceTransforms();
    }

    public static void executeScene() {
        if (STOPPED.get() || reload == null || reload.active() == null || executionFailed) return;
        var active = reload.active();
        if (!active.requiresScene()) return;
        var client = Minecraft.getInstance();
        var levelState = client.gameRenderer.gameRenderState().levelRenderState;
        var camera = levelState.cameraRenderState;
        float sunAngle =
                levelState.skyRenderState == null ? 0.0f : levelState.skyRenderState.sunAngle;
        if (client.level == null || !VeilCameraAbi.usable(camera)) {
            HISTORY.invalidate();
            return;
        }
        boolean valid =
                HISTORY.update(
                        client.level,
                        camera.pos.x,
                        camera.pos.y,
                        camera.pos.z,
                        camera.yRot,
                        camera.xRot,
                        System.nanoTime());
        valid &=
                HISTORY.projection(
                        camera.projectionMatrix.m00(),
                        camera.projectionMatrix.m11(),
                        camera.projectionMatrix.m22(),
                        camera.projectionMatrix.m32());
        if (!valid) active.invalidateHistory();
        VeilWorldHistoryGpuProbe.before(active, client.level, !valid);
        execute(active, true, camera, sunAngle);
    }

    private static void execute(
            VeilShaderPackRuntime active,
            boolean scene,
            net.minecraft.client.renderer.state.level.CameraRenderState camera,
            float sunAngle) {
        RenderSystem.assertOnRenderThread();
        var target = Minecraft.getInstance().gameRenderer.mainRenderTarget();
        long now = System.nanoTime();
        try {
            if (!VeilSimulationInitialCheckpointGpuProbe.before(active)) return;
            float seconds = (now - startNanos) / 1_000_000_000.0f;
            float delta = (now - previousNanos) / 1_000_000_000.0f;
            if (scene) {
                VeilGiConformanceProbe.beforeScene(active);
                if (active.usesAbi6SceneInputs()) VeilMaterialHost.prepareForShaderGraph();
                if (active.usesWorldRayScene()) VeilWorldRayScene.prepare();
                if (active.usesCreatorSceneData()) {
                    if (VeilCreatorHostPerformanceProbe.enabled())
                        VeilCreatorHostPerformanceProbe.begin(active);
                    try {
                        VeilCreatorSceneHost.prepare(sunAngle, active.creatorSceneRequirements());
                    } finally {
                        if (VeilCreatorHostPerformanceProbe.enabled())
                            VeilCreatorHostPerformanceProbe.end();
                    }
                }
                if (active.usesShadowLightData()) VeilShadowLightHost.prepare();
                if (active.usesCreatorMeshData()) {
                    CreatorMeshUvGpuProbe.prepare();
                    AutomaticMeshUvGpuProbe.prepare();
                    VeilCreatorMeshHost.prepare();
                }
                if (active.usesEnvironment()) VeilEnvironmentHost.prepare();
                if (active.usesNativeLighting()) VeilNativeLightingHost.prepare();
                if (active.usesPbrAtlas()) VeilPbrAtlas.prepare(active.pbrAtlasMask());
                PbrMipGpuProbe.prepare(active);
                VeilVolumeSupportGpuProbe.before(active);
                VeilColorPipelineGpuProbe.before(active);
                active.executeScene(target, camera, seconds, delta, sunAngle);
                VeilVolumeSupportGpuProbe.after(active);
                VeilColorPipelineGpuProbe.after(active);
                VeilCreatorHostPerformanceProbe.afterScene(active);
                VeilBasicShadowSlangGpuProbe.tick(active);
                VeilGiConformanceProbe.afterScene(active);
                PbrMipGpuProbe.tick(active);
                VeilWorldHistoryGpuProbe.after(active);
                VeilWorldVolumeProbe.tick(active);
                VeilGlobalIlluminationProbe.tick(active);
                VeilWorldRayGpuProbe.tick(active);
                VeilSceneCameraProbe.tick(active, camera);
                VeilShadowMotionProbe.tick(active, camera);
            } else {
                active.resize(Math.max(1, target.width), Math.max(1, target.height));
                VeilShaderHistoryGpuProbe.before(active);
                active.execute(seconds, delta);
                VeilShaderHistoryGpuProbe.after(active);
            }
            VeilSimulationTransferGpuProbe.tick(active);
            VeilSimulationSubresourceGpuProbe.tick(active);
            VeilSimulationInitialCheckpointGpuProbe.after(active);
            if (!recorded) {
                recorded = true;
                ReviveMod.LOGGER.info("Veil shader pack commands RECORDED: {}", status());
            }
        } catch (RuntimeException failure) {
            executionFailed = true;
            setFluidGeometryReplacement(false, false, "shader execution failure");
            setWorldRayScene(false, "shader execution failure");
            executionDiagnostic = failure.getClass().getSimpleName() + ": " + failure.getMessage();
            ReviveMod.LOGGER.error(
                    "Veil shader pack execution stopped: {}", failure.getMessage(), failure);
        } finally {
            if (scene) VeilSceneReplay.clear();
        }
        previousNanos = now;
    }

    public static boolean wantsAutomaticEntityMeshes() {
        if (reload == null) return false;
        VeilShaderPackRuntime active = reload.active();
        return active != null && active.usesCreatorMeshData();
    }

    private static void setFluidGeometryReplacement(boolean water, boolean lava, String reason) {
        int mask = (water ? 1 : 0) | (lava ? 2 : 0);
        int previous = fluidGeometryReplacementMask;
        fluidGeometryReplacementMask = mask;
        if (previous == mask) return;

        Minecraft client = Minecraft.getInstance();
        if (client.level != null && client.levelRenderer != null) {
            client.levelRenderer.invalidateCompiledGeometry(
                    client.level,
                    client.options,
                    client.gameRenderer.mainCamera(),
                    client.getBlockColors());
            VeilFluidGeometryHost.recordOwnershipRebuildRequest();
            ReviveMod.LOGGER.info(
                    "Veil Fluid Geometry ABI ownership changed: water_replacement={} lava_replacement={} reason={} - section rebuild requested automatically",
                    water,
                    lava,
                    reason);
        } else {
            ReviveMod.LOGGER.info(
                    "Veil Fluid Geometry ABI ownership changed: water_replacement={} lava_replacement={} reason={} - no active level to rebuild",
                    water,
                    lava,
                    reason);
        }
    }

    private static void setWorldRayScene(boolean enabled, String reason) {
        boolean previous = worldRayScene;
        worldRayScene = enabled;
        VeilWorldRayScene.requested(enabled);
        if (previous == enabled) return;
        Minecraft client = Minecraft.getInstance();
        if (client.level != null && client.levelRenderer != null) {
            client.levelRenderer.invalidateCompiledGeometry(
                    client.level,
                    client.options,
                    client.gameRenderer.mainCamera(),
                    client.getBlockColors());
            ReviveMod.LOGGER.info(
                    "Veil Minecraft ray world ownership changed: enabled={} reason={}",
                    enabled,
                    reason);
        }
    }

    public static void requestReload() {
        RELOAD.set(true);
    }

    /**
     * Optional host integration for creator-defined GPU fields. Call on the render thread after
     * this generation's passes have executed. The callback receives a compact CPU snapshot only
     * after the GPU copy completes. The creator decides when and how to persist it. This is not an
     * automatic shaderpack save system.
     */
    public static void captureSimulationField(
            String resource,
            java.util.function.Consumer<dev.veil.api.VeilSimulationFieldSnapshot> completed) {
        captureSimulationField(resource, 0, 0, completed);
    }

    public static void captureSimulationField(
            String resource,
            int mip,
            int layer,
            java.util.function.Consumer<dev.veil.api.VeilSimulationFieldSnapshot> completed) {
        RenderSystem.assertOnRenderThread();
        if (STOPPED.get() || reload == null || reload.active() == null || executionFailed)
            throw new IllegalStateException(
                    "Cannot capture creator field without an active shaderpack");
        reload.active().readSimulationField(resource, mip, layer, completed);
    }

    /**
     * Explicit host integration: capture several images together after this frame's producers. The
     * immutable result retains its original generation/frame even if reload occurs before
     * completion. Caller must scope persistence to its original world/pack identity. No disk I/O.
     */
    public static void captureSimulationCheckpoint(
            java.util.Map<String, dev.veil.api.VeilSimulationCheckpoint.Selection> fields,
            int maxStagingBytes,
            java.util.function.Consumer<dev.veil.api.VeilSimulationCheckpoint> completed) {
        RenderSystem.assertOnRenderThread();
        if (STOPPED.get() || reload == null || reload.active() == null || executionFailed)
            throw new IllegalStateException(
                    "Cannot capture checkpoint without an active shaderpack");
        reload.active().readSimulationCheckpoint(fields, maxStagingBytes, completed);
    }

    /** Reserve bounded persistence before allocating GPU staging; captured scope never changes. */
    public static java.util.concurrent.CompletableFuture<Void> saveSimulationCheckpoint(
            dev.veil.api.VeilSimulationCheckpointStore store,
            dev.veil.api.VeilSimulationCheckpointStore.Scope scope,
            java.util.Map<String, dev.veil.api.VeilSimulationCheckpoint.Selection> fields,
            int maxStagingBytes) {
        return saveSimulationCheckpoint(store, scope, fields, maxStagingBytes, java.util.Map.of());
    }

    /** CPU bytes must describe the same producer step as fields; capture before GPU retirement. */
    public static java.util.concurrent.CompletableFuture<Void> saveSimulationCheckpoint(
            dev.veil.api.VeilSimulationCheckpointStore store,
            dev.veil.api.VeilSimulationCheckpointStore.Scope scope,
            java.util.Map<String, dev.veil.api.VeilSimulationCheckpoint.Selection> fields,
            int maxStagingBytes,
            java.util.Map<String, dev.veil.api.VeilSimulationCheckpoint.CpuState> cpuState) {
        RenderSystem.assertOnRenderThread();
        return store.captureAndSaveAsync(
                scope,
                () -> {
                    if (STOPPED.get()
                            || reload == null
                            || reload.active() == null
                            || executionFailed)
                        throw new IllegalStateException(
                                "Cannot capture checkpoint without an active shaderpack");
                    return reload.active()
                            .readSimulationCheckpointAsync(fields, maxStagingBytes, cpuState);
                });
    }

    /** Queue already-loaded CPU data for upload after initialization and before the first pass. */
    public static java.util.concurrent.CompletableFuture<Void> queueInitialSimulationCheckpoint(
            dev.veil.api.VeilSimulationCheckpoint checkpoint) {
        RenderSystem.assertOnRenderThread();
        if (STOPPED.get() || reload == null || reload.active() == null || executionFailed)
            throw new IllegalStateException("Cannot restore without an active shaderpack");
        return reload.active().queueInitialSimulationCheckpoint(checkpoint);
    }

    /**
     * Host-side opt-in restoration for creator simulation data. Call on render thread after a frame
     * has established the image's render-graph state, and before a later pass consumes it. This
     * performs a GPU copy, not disk I/O.
     */
    public static void restoreSimulationField(
            String resource, dev.veil.api.VeilSimulationFieldSnapshot field) {
        restoreSimulationField(resource, 0, 0, field);
    }

    public static void restoreSimulationField(
            String resource, int mip, int layer, dev.veil.api.VeilSimulationFieldSnapshot field) {
        RenderSystem.assertOnRenderThread();
        if (STOPPED.get() || reload == null || reload.active() == null || executionFailed)
            throw new IllegalStateException(
                    "Cannot restore creator field without an active shaderpack");
        reload.active().restoreSimulationField(resource, mip, layer, field);
    }

    public static boolean profiling() {
        return profiling;
    }

    public static void profiling(boolean enabled) {
        profiling = enabled;
    }

    public static String performanceReport() {
        var active = reload == null ? null : reload.active();
        return active == null
                ? "No native shader pack active"
                : active.performanceReport()
                        + METRICS.telemetry()
                        + "\n"
                        + VeilPbrAtlas.telemetry()
                        + "\n"
                        + VeilFluidGeometryHost.telemetry()
                        + "\n"
                        + VeilAsyncEntityOcclusion.telemetry();
    }

    static boolean reloadRejected() {
        return reload != null && reload.failed();
    }

    public static void requirePerformanceSamples(long minimum) {
        var active = reload == null ? null : reload.active();
        if (active == null || executionFailed)
            throw new IllegalStateException("Native shader generation unavailable: " + status());
        active.requireProfileSamples(minimum);
    }

    public static void resetPerformanceSamples() {
        var active = reload == null ? null : reload.active();
        if (active != null) active.resetProfile();
    }

    public static String exportPerformanceReport() {
        if (worker == null || STOPPED.get())
            throw new IllegalStateException("Shader service unavailable");
        String report = performanceReport();
        Path destination =
                Minecraft.getInstance()
                        .gameDirectory
                        .toPath()
                        .resolve(
                                "logs/veil-shaders/profile-"
                                        + java.util.UUID.randomUUID()
                                        + ".txt");
        worker.execute(
                () -> {
                    try {
                        Files.createDirectories(destination.getParent());
                        Files.writeString(
                                destination, report, java.nio.file.StandardOpenOption.CREATE_NEW);
                        ReviveMod.LOGGER.info(
                                "Veil shader performance report saved: {}", destination);
                    } catch (IOException failure) {
                        ReviveMod.LOGGER.error(
                                "Veil shader report export failed: {}", failure.getMessage());
                    }
                });
        return "Shader report export queued: " + destination;
    }

    public static void select(String selected) {
        updateRequest(new Request(REVISIONS.incrementAndGet(), selected.trim(), Map.of()));
    }

    public static void setting(String name, String value) {
        settings(Map.of(name, value));
    }

    public static void settings(Map<String, String> changes) {
        Request request = REQUEST.get();
        if (request == null) throw new IllegalArgumentException("No selected shader pack");
        if (!publishedSelection.equals(request.selected())
                || request.revision() != submittedRevision
                || reload.isPending()) {
            throw new IllegalArgumentException(
                    "Wait for the selected shader pack transaction to finish");
        }
        var values = new LinkedHashMap<>(request.settings());
        for (var change : changes.entrySet()) {
            var definition = settings.get(change.getKey());
            if (definition == null)
                throw new IllegalArgumentException("Unknown shader setting " + change.getKey());
            new VeilShaderPack.Setting(definition.type(), change.getValue(), definition.options());
            values.put(change.getKey(), change.getValue());
        }
        if (changes.isEmpty()) return;
        updateRequest(new Request(REVISIONS.incrementAndGet(), request.selected(), values));
    }

    private static void updateRequest(Request request) {
        if (STOPPED.get()) throw new IllegalStateException("Shader service is stopped");
        REQUEST.set(request);
        if (worker != null)
            worker.execute(
                    () -> {
                        try {
                            dev.veil.revive.client.shaderpack.reload.PackConfiguration.save(
                                    configPath, request.selected(), request.settings());
                        } catch (IOException failure) {
                            ReviveMod.LOGGER.warn(
                                    "Veil shader configuration was not saved: {}",
                                    failure.getMessage());
                        }
                    });
    }

    public static List<String> availablePacks() throws IOException {
        return dev.veil.revive.client.shaderpack.reload.PackSources.available(
                packRoot, BUNDLED_PACK_INDEX);
    }

    static List<String> bundledPacks() throws IOException {
        return dev.veil.revive.client.shaderpack.reload.PackSources.bundled(BUNDLED_PACK_INDEX);
    }

    public static boolean replacesVanillaSky() {
        var active = reload == null ? null : reload.active();
        return active != null && active.replacesVanillaSky();
    }

    public static boolean replacesVanillaSun() {
        var active = reload == null ? null : reload.active();
        return active != null && active.replacesVanillaSun();
    }

    public static boolean replacesVanillaSunriseSunset() {
        var active = reload == null ? null : reload.active();
        return active != null && active.replacesVanillaSunriseSunset();
    }

    public static boolean fluidGeometryLavaReplacementEnabled() {
        return (fluidGeometryReplacementMask & 2) != 0;
    }

    public static boolean replacesWeather() {
        return !executionFailed
                && reload != null
                && reload.active() != null
                && reload.active().replacesVanillaWeather();
    }

    public static boolean fluidGeometryWaterReplacementEnabled() {
        return (fluidGeometryReplacementMask & 1) != 0;
    }

    public static boolean replacesVanillaWater() {
        var active = reload == null ? null : reload.active();
        return active != null && !executionFailed && active.replacesVanillaWater();
    }

    public static boolean opaqueSceneInputsRequested() {
        var active = reload == null ? null : reload.active();
        return active != null && !executionFailed && active.usesOpaqueSceneInputs();
    }

    public static boolean materialInputsRequested() {
        var active = reload == null ? null : reload.active();
        return active != null && !executionFailed && active.usesMaterialInputs();
    }

    public static boolean scenePackActive() {
        var active = reload == null ? null : reload.active();
        return active != null && !executionFailed && active.requiresScene();
    }

    static boolean sceneCategoryRequested(dev.veil.api.VeilScenePass.Category category) {
        var active = reload == null ? null : reload.active();
        return active != null && !executionFailed && active.requestsSceneCategory(category);
    }

    static boolean sceneCategoryRepeated(dev.veil.api.VeilScenePass.Category category) {
        var active = reload == null ? null : reload.active();
        return active != null && !executionFailed && active.repeatsSceneCategory(category);
    }

    public static String settings() {
        return settings.toString();
    }

    public static Map<String, VeilShaderPack.Setting> settingsSnapshot() {
        return settings;
    }

    public static String userStatus(boolean spanish) {
        if (initialized && reload == null)
            return spanish
                    ? "Se requiere el backend Vulkan de Minecraft"
                    : "Minecraft Vulkan backend required";
        Request request = REQUEST.get();
        if (request == null) return spanish ? "Cargando configuraciÃ³n" : "Loading configuration";
        if (request.selected().isEmpty())
            return spanish ? "Shaders desactivados" : "Shaders disabled";
        if (reload == null)
            return spanish
                    ? "Se requiere el backend Vulkan de Minecraft"
                    : "Minecraft Vulkan backend required";
        if (reload.isPending() || request.revision() != submittedRevision)
            return (spanish ? "Cargando: " : "Loading: ") + request.selected();
        if (reload.failed()) return reload.diagnostic();
        if (executionFailed) return executionDiagnostic;
        return reload.active() == null
                ? (spanish ? "NingÃºn pack activo" : "No active pack")
                : (spanish ? "Activo: " : "Active: ") + reload.active().name();
    }

    public static String status() {
        Request request = REQUEST.get();
        return "selected="
                + (request == null || request.selected().isEmpty() ? "OFF" : request.selected())
                + " "
                + (reload == null
                        ? "shader_pack=DISABLED"
                        : reload.diagnostic()
                                + " "
                                + (reload.active() == null
                                        ? "shader_pack=INACTIVE"
                                        : reload.active().status())
                                + " execution_stopped="
                                + executionFailed
                                + " sky_owner="
                                + replacesVanillaSky()
                                + " sun_owner="
                                + replacesVanillaSun()
                                + " sunset_owner="
                                + replacesVanillaSunriseSunset())
                + "\n"
                + METRICS.telemetry()
                + "\n"
                + VeilVulkanPipelineCache.telemetry()
                + "\n"
                + VeilPbrAtlas.telemetry()
                + "\n"
                + VeilFluidGeometryHost.telemetry()
                + "\n"
                + VeilAsyncEntityOcclusion.telemetry();
    }

    public static void close() {
        if (!STOPPED.compareAndSet(false, true)) return;
        HISTORY.invalidate();
        var cleanup = new dev.veil.revive.core.lifecycle.CloseSequence();
        cleanup.run(
                () -> {
                    if (worker != null) worker.shutdownNow();
                });
        cleanup.run(
                () -> {
                    if (reload != null) reload.close();
                });
        cleanup.run(VeilPbrAtlas::close);
        cleanup.run(VeilEnvironmentHost::close);
        cleanup.run(VeilNativeLightingHost::close);
        cleanup.run(
                () -> {
                    if (pipelines != null) pipelines.close();
                });
        fluidGeometryReplacementMask = 0;
        worldRayScene = false;
        cleanup.run(() -> VeilWorldRayScene.requested(false));
        cleanup.run(VeilWorldRayScene::close);
        cleanup.run(VeilCreatorSceneHost::close);
        cleanup.run(VeilEntityMeshCapture::close);
        cleanup.run(VeilShadowLightHost::close);
        cleanup.run(VeilCreatorMeshHost::close);
        cleanup.run(VeilFluidGeometryHost::close);
        cleanup.run(VeilMaterialHost::close);
        cleanup.finish();
    }
}
