package dev.veil.revive.client.terrain.meshing;

import com.mojang.blaze3d.vertex.QuadInstance;

import net.minecraft.client.model.geom.builders.UVPair;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.util.ARGB;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class BlockQuadEncoder {
    private BlockQuadEncoder() {}

    public static void putVertex(
            ByteBuffer output,
            int at,
            float x,
            float y,
            float z,
            int argb,
            float u,
            float v,
            int light) {
        int color = ARGB.toABGR(argb);
        output.putFloat(at, x);
        output.putFloat(at + 4, y);
        output.putFloat(at + 8, z);
        output.putInt(
                at + 12,
                output.order() == ByteOrder.LITTLE_ENDIAN ? color : Integer.reverseBytes(color));
        output.putFloat(at + 16, u);
        output.putFloat(at + 20, v);
        output.putShort(at + 24, (short) light);
        output.putShort(at + 26, (short) (light >>> 16));
    }

    public static void encode(
            ByteBuffer output, float x, float y, float z, BakedQuad quad, QuadInstance instance) {
        if (output.remaining() < 112) throw new IllegalArgumentException("Quad output too small");
        int at = output.position();
        int emission = quad.materialInfo().lightEmission();
        for (int corner = 0; corner < 4; corner++) {
            var position = quad.position(corner);
            long uv = quad.packedUV(corner);
            int light = instance.getLightCoordsWithEmission(corner, emission);
            putVertex(
                    output,
                    at,
                    position.x() + x,
                    position.y() + y,
                    position.z() + z,
                    instance.getColor(corner),
                    UVPair.unpackU(uv),
                    UVPair.unpackV(uv),
                    light);
            at += 28;
        }
    }
}
