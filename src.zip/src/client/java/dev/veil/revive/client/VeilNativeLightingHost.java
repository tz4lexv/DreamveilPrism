package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.state.LightmapRenderState;

import org.joml.Vector3fc;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public final class VeilNativeLightingHost {
    static final String HOST_ID = "minecraft:native_lighting";
    static final int CAPACITY = 128;
    static final int MAGIC = 0x564c4931;
    private static Object capturedWorld;
    private static Object capturedOwner;
    private static byte[] captured;
    private static byte[] uploaded;
    private static GpuBuffer buffer;
    private static final ByteBuffer snapshot =
            ByteBuffer.allocate(CAPACITY).order(ByteOrder.nativeOrder());
    private static final ByteBuffer uploadBytes =
            ByteBuffer.allocateDirect(CAPACITY).order(ByteOrder.nativeOrder());

    private VeilNativeLightingHost() {}

    public static void capture(Object owner, LightmapRenderState state) {
        RenderSystem.assertOnRenderThread();
        if (!state.needsUpdate) return;
        write(state, snapshot);
        capturedWorld = Minecraft.getInstance().level;
        capturedOwner = owner;
        captured = snapshot.array();
    }

    static byte[] encode(LightmapRenderState state) {
        ByteBuffer bytes = ByteBuffer.allocate(CAPACITY).order(ByteOrder.nativeOrder());
        write(state, bytes);
        return bytes.array();
    }

    private static void write(LightmapRenderState state, ByteBuffer bytes) {
        bytes.putInt(0, MAGIC).putInt(4, 1).putInt(8, CAPACITY).putInt(12, 1);
        put(bytes, 16, state.skyFactor);
        put(bytes, 20, state.blockFactor);
        put(bytes, 24, state.nightVisionEffectIntensity);
        put(bytes, 28, state.darknessEffectScale);
        put(bytes, 32, state.bossOverlayWorldDarkening);
        put(bytes, 36, state.brightness);
        vector(bytes, 48, state.blockLightTint);
        vector(bytes, 64, state.skyLightColor);
        vector(bytes, 80, state.ambientColor);
        vector(bytes, 96, state.nightVisionColor);
    }

    private static void vector(ByteBuffer bytes, int offset, Vector3fc value) {
        put(bytes, offset, value.x());
        put(bytes, offset + 4, value.y());
        put(bytes, offset + 8, value.z());
    }

    private static void put(ByteBuffer bytes, int offset, float value) {
        if (!Float.isFinite(value))
            throw new IllegalArgumentException("Non-finite native lighting parameter at " + offset);
        bytes.putFloat(offset, value);
    }

    static boolean ready() {
        var client = Minecraft.getInstance();
        return captured != null
                && client.level != null
                && capturedWorld == client.level
                && capturedOwner == client.gameRenderer.levelLightmap();
    }

    static void prepare() {
        RenderSystem.assertOnRenderThread();
        if (!ready())
            throw new IllegalStateException("Native lighting has no current-world snapshot");
        if (buffer == null)
            buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil native lighting parameters",
                                    VeilHzb.STORAGE_USAGE | GpuBuffer.USAGE_COPY_DST,
                                    CAPACITY);
        if (!Arrays.equals(captured, uploaded)) {
            uploadBytes.clear();
            uploadBytes.put(captured).flip();
            RenderSystem.getDevice()
                    .createCommandEncoder()
                    .writeToBuffer(buffer.slice(), uploadBytes);
            uploaded = captured.clone();
        }
    }

    static GpuBuffer buffer() {
        if (buffer == null || !ready())
            throw new IllegalStateException("Native lighting is not prepared");
        return buffer;
    }

    static void close() {
        if (buffer != null) buffer.close();
        buffer = null;
        uploaded = captured = null;
        capturedOwner = capturedWorld = null;
    }
}
