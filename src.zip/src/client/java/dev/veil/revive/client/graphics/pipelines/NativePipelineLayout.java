package dev.veil.revive.client.graphics.pipelines;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.revive.client.graphics.minecraft.DeferredGpuRetirement;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.client.graphics.minecraft.VulkanResult;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.KHRPushDescriptor;
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding;
import org.lwjgl.vulkan.VkDescriptorSetLayoutCreateInfo;
import org.lwjgl.vulkan.VkPipelineLayoutCreateInfo;
import org.lwjgl.vulkan.VkPushConstantRange;

import java.util.List;
import java.util.Objects;

public final class NativePipelineLayout implements AutoCloseable {
    public record DescriptorBinding(
            int binding, int descriptorType, int descriptorCount, int stageFlags) {
        public DescriptorBinding {
            if (binding < 0) throw new IllegalArgumentException("binding < 0");
            if (descriptorCount <= 0) throw new IllegalArgumentException("descriptorCount <= 0");
        }
    }

    public record PushConstantRange(int stageFlags, int offset, int size) {
        public PushConstantRange {
            if (offset < 0 || size <= 0 || (offset & 3) != 0 || (size & 3) != 0) {
                throw new IllegalArgumentException(
                        "Push constant offset/size must be positive 4-byte aligned values");
            }
        }
    }

    private final MinecraftVulkanContext runtime;
    private final DeferredGpuRetirement closeRequested = new DeferredGpuRetirement();
    private long descriptorSetLayout;
    private long pipelineLayout;

    private NativePipelineLayout(
            MinecraftVulkanContext runtime, long descriptorSetLayout, long pipelineLayout) {
        this.runtime = runtime;
        this.descriptorSetLayout = descriptorSetLayout;
        this.pipelineLayout = pipelineLayout;
    }

    public static NativePipelineLayout createPushDescriptorSet0(
            MinecraftVulkanContext runtime,
            List<DescriptorBinding> descriptorBindings,
            List<PushConstantRange> pushConstants) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        Objects.requireNonNull(runtime, "runtime");
        descriptorBindings = List.copyOf(descriptorBindings);
        pushConstants = List.copyOf(pushConstants);

        long descriptorLayout = VK_NULL_HANDLE;
        long pipelineLayout = VK_NULL_HANDLE;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var out = stack.mallocLong(1);
            var bindings = VkDescriptorSetLayoutBinding.calloc(descriptorBindings.size(), stack);
            for (int i = 0; i < descriptorBindings.size(); i++) {
                var binding = descriptorBindings.get(i);
                bindings.get(i)
                        .binding(binding.binding())
                        .descriptorType(binding.descriptorType())
                        .descriptorCount(binding.descriptorCount())
                        .stageFlags(binding.stageFlags());
            }
            int result =
                    vkCreateDescriptorSetLayout(
                            runtime.vkDevice(),
                            VkDescriptorSetLayoutCreateInfo.calloc(stack)
                                    .sType$Default()
                                    .flags(
                                            KHRPushDescriptor
                                                    .VK_DESCRIPTOR_SET_LAYOUT_CREATE_PUSH_DESCRIPTOR_BIT_KHR)
                                    .pBindings(bindings),
                            null,
                            out);
            VulkanResult.check(result, "vkCreateDescriptorSetLayout");
            descriptorLayout = out.get(0);

            var ranges = VkPushConstantRange.calloc(pushConstants.size(), stack);
            for (int i = 0; i < pushConstants.size(); i++) {
                var range = pushConstants.get(i);
                ranges.get(i)
                        .stageFlags(range.stageFlags())
                        .offset(range.offset())
                        .size(range.size());
            }
            result =
                    vkCreatePipelineLayout(
                            runtime.vkDevice(),
                            VkPipelineLayoutCreateInfo.calloc(stack)
                                    .sType$Default()
                                    .pSetLayouts(stack.longs(descriptorLayout))
                                    .pPushConstantRanges(ranges),
                            null,
                            out);
            VulkanResult.check(result, "vkCreatePipelineLayout");
            pipelineLayout = out.get(0);
            return new NativePipelineLayout(runtime, descriptorLayout, pipelineLayout);
        } catch (RuntimeException failure) {
            if (pipelineLayout != VK_NULL_HANDLE)
                vkDestroyPipelineLayout(runtime.vkDevice(), pipelineLayout, null);
            if (descriptorLayout != VK_NULL_HANDLE)
                vkDestroyDescriptorSetLayout(runtime.vkDevice(), descriptorLayout, null);
            throw failure;
        }
    }

    public static NativePipelineLayout createNoDescriptors(
            MinecraftVulkanContext runtime, List<PushConstantRange> pushConstants) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        Objects.requireNonNull(runtime, "runtime");
        pushConstants = List.copyOf(pushConstants);
        long pipelineLayout = VK_NULL_HANDLE;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var ranges = VkPushConstantRange.calloc(pushConstants.size(), stack);
            for (int i = 0; i < pushConstants.size(); i++) {
                var range = pushConstants.get(i);
                ranges.get(i)
                        .stageFlags(range.stageFlags())
                        .offset(range.offset())
                        .size(range.size());
            }
            var out = stack.mallocLong(1);
            int result =
                    vkCreatePipelineLayout(
                            runtime.vkDevice(),
                            VkPipelineLayoutCreateInfo.calloc(stack)
                                    .sType$Default()
                                    .pPushConstantRanges(ranges),
                            null,
                            out);
            VulkanResult.check(result, "vkCreatePipelineLayout(no descriptors)");
            pipelineLayout = out.get(0);
            return new NativePipelineLayout(runtime, VK_NULL_HANDLE, pipelineLayout);
        } catch (RuntimeException failure) {
            if (pipelineLayout != VK_NULL_HANDLE)
                vkDestroyPipelineLayout(runtime.vkDevice(), pipelineLayout, null);
            throw failure;
        }
    }

    public long handle() {
        if (closeRequested.closeRequested() || pipelineLayout == VK_NULL_HANDLE)
            throw new IllegalStateException("Pipeline layout is closed");
        return pipelineLayout;
    }

    public long descriptorSetLayout() {
        if (closeRequested.closeRequested())
            throw new IllegalStateException("Pipeline layout is closed");
        return descriptorSetLayout;
    }

    public void destroyNow() {
        closeRequested.markDestroyed();
        long oldPipeline = pipelineLayout;
        long oldDescriptor = descriptorSetLayout;
        pipelineLayout = VK_NULL_HANDLE;
        descriptorSetLayout = VK_NULL_HANDLE;
        if (oldPipeline != VK_NULL_HANDLE)
            vkDestroyPipelineLayout(runtime.vkDevice(), oldPipeline, null);
        if (oldDescriptor != VK_NULL_HANDLE)
            vkDestroyDescriptorSetLayout(runtime.vkDevice(), oldDescriptor, null);
    }

    @Override
    public void close() {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        closeRequested.defer(action -> runtime.deferDestroy(action::run), this::destroyNow);
    }
}
