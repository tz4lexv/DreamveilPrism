package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.client.terrain.residency.IndirectArenaOwner;

import java.nio.ByteBuffer;

final class VeilGpuArena {
    private static final IndirectArenaOwner<VeilIndirectTerrain.Batch> OWNER =
            new IndirectArenaOwner<>(
                    VeilGpuArena::budget,
                    VeilGpuArena::queryStorageAlignment,
                    bytes -> new VeilPersistentStagingBuffer("Veil persistent upload ring", bytes),
                    (heapBytes, alignment, staging) ->
                            new VeilManagedGpuArena<>(
                                    "Veil indirect arena",
                                    GpuBuffer.USAGE_INDIRECT_PARAMETERS
                                            | GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER
                                            | VeilHzb.STORAGE_USAGE,
                                    heapBytes,
                                    alignment,
                                    staging));

    private VeilGpuArena() {}

    static int storageAlignment() {
        return OWNER.storageAlignment();
    }

    static void stage(VeilIndirectTerrain.Batch batch, ByteBuffer data) {
        OWNER.stage(batch, data);
    }

    static void flush() {
        OWNER.flush();
    }

    static void remove(VeilIndirectTerrain.Batch batch) {
        OWNER.remove(batch);
    }

    static void reconfigure() {
        OWNER.close();
    }

    static String telemetry() {
        return OWNER.telemetry();
    }

    static void close() {
        OWNER.close();
    }

    private static IndirectArenaOwner.Budget budget() {
        boolean integrated =
                RenderSystem.getDevice().getDeviceInfo().type()
                        == com.mojang.blaze3d.systems.DeviceType.INTEGRATED;
        int heapMiB = VeilVideoConfig.number("renderer.gpuArenaMiB", integrated ? 16 : 32, 8, 128);
        int uploadMiB = VeilVideoConfig.number("renderer.uploadRingMiB", integrated ? 4 : 8, 2, 32);

        if (VeilMemoryMonitor.pressure() >= 0.90) {
            heapMiB = Math.min(heapMiB, integrated ? 16 : 24);
            uploadMiB = Math.min(uploadMiB, integrated ? 4 : 6);
        }
        return new IndirectArenaOwner.Budget(heapMiB << 20, uploadMiB << 20);
    }

    private static int queryStorageAlignment() {
        int storageAlignment;
        try (var stack = org.lwjgl.system.MemoryStack.stackPush()) {
            var properties = org.lwjgl.vulkan.VkPhysicalDeviceProperties.calloc(stack);
            org.lwjgl.vulkan.VK10.vkGetPhysicalDeviceProperties(
                    VeilVulkanRuntime.requireCurrent().vkDevice().getPhysicalDevice(), properties);
            storageAlignment =
                    Math.max(
                            Math.max(
                                    16,
                                    RenderSystem.getDevice()
                                            .getDeviceInfo()
                                            .limits()
                                            .minUniformOffsetAlignment()),
                            Math.toIntExact(
                                    Math.max(
                                            properties.limits().minStorageBufferOffsetAlignment(),
                                            properties.limits().minTexelBufferOffsetAlignment())));
        }
        return storageAlignment;
    }
}
