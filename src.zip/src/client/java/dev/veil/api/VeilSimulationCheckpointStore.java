package dev.veil.api;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Opt-in asynchronous checkpoint storage. One reservation spans GPU capture and disk work; no
 * further capture is admitted while it is outstanding. This class owns CPU data only, not Vulkan.
 * Constructing it does not create files or start a worker. Close drains admitted disk work without
 * waiting on the caller's thread. Cancellation does not prematurely release a GPU reservation.
 */
public final class VeilSimulationCheckpointStore implements AutoCloseable {
    private static final int MAGIC = 0x56474331;
    private static final int VERSION = 2;

    /**
     * Schema is author-defined; changing it rejects an existing file instead of reinterpreting it.
     */
    public record Scope(String world, String dimension, String pack, String state, int schema) {
        public Scope {
            checkKey(world);
            checkKey(dimension);
            checkKey(pack);
            checkKey(state);
            if (schema < 1) throw new IllegalArgumentException("Invalid checkpoint schema");
        }

        String worldKey() {
            return world.length() + ":" + world + dimension.length() + ":" + dimension;
        }

        private static void checkKey(String key) {
            Objects.requireNonNull(key, "scope key");
            if (key.isBlank()
                    || key.length() > 240
                    || key.codePoints().anyMatch(Character::isISOControl))
                throw new IllegalArgumentException("Invalid checkpoint scope key");
        }
    }

    private final VeilSimulationStateStore store;
    private final ThreadPoolExecutor worker;
    private final AtomicBoolean busy = new AtomicBoolean();
    private final AtomicBoolean closed = new AtomicBoolean();
    private final java.util.concurrent.atomic.AtomicReference<
                    VeilSimulationCheckpointAdmission.Reservation>
            admission = new java.util.concurrent.atomic.AtomicReference<>();

    public VeilSimulationCheckpointStore(Path root, int maxSnapshotBytes) {
        store = new VeilSimulationStateStore(root, maxSnapshotBytes);
        worker =
                new ThreadPoolExecutor(
                        1,
                        1,
                        0,
                        TimeUnit.MILLISECONDS,
                        new ArrayBlockingQueue<>(1),
                        job -> {
                            Thread thread = new Thread(job, "Veil simulation checkpoint I/O");
                            thread.setDaemon(true);
                            return thread;
                        },
                        new ThreadPoolExecutor.AbortPolicy());
    }

    public boolean busy() {
        return busy.get();
    }

    /** Capture completion includes deferred GPU failures; disk work starts only on success. */
    public CompletableFuture<Void> captureAndSaveAsync(
            Scope scope, Supplier<CompletableFuture<VeilSimulationCheckpoint>> capture) {
        Objects.requireNonNull(scope, "scope");
        Objects.requireNonNull(capture, "capture");
        var future = new CompletableFuture<Void>();
        if (!reserve(future)) return future;
        try {
            Objects.requireNonNull(capture.get(), "capture future")
                    .whenComplete(
                            (checkpoint, failure) -> {
                                if (failure != null) finish(future, null, failure);
                                else submitSave(scope, checkpoint, future);
                            });
        } catch (RuntimeException | Error failure) {
            finish(future, null, failure);
        }
        return future;
    }

    private void submitSave(
            Scope scope, VeilSimulationCheckpoint checkpoint, CompletableFuture<Void> future) {
        submit(
                future,
                () -> {
                    byte[] bytes = encode(scope, Objects.requireNonNull(checkpoint, "checkpoint"));
                    store.saveAtomic(scope.worldKey(), scope.pack(), scope.state(), bytes);
                    return null;
                });
    }

    /**
     * Capture is invoked on the caller; serialization and atomic disk publication run on worker.
     */
    public CompletableFuture<Void> captureAndSave(
            Scope scope, Consumer<Consumer<VeilSimulationCheckpoint>> capture) {
        Objects.requireNonNull(scope, "scope");
        Objects.requireNonNull(capture, "capture");
        var future = new CompletableFuture<Void>();
        if (!reserve(future)) return future;
        var delivered = new AtomicBoolean();
        try {
            capture.accept(
                    checkpoint -> {
                        if (!delivered.compareAndSet(false, true)) return;
                        submitSave(scope, checkpoint, future);
                    });
        } catch (RuntimeException | Error failure) {
            if (delivered.compareAndSet(false, true)) finish(future, null, failure);
            else throw failure;
        }
        return future;
    }

    /**
     * Load/decode/identity checks run off caller thread. Empty means absent; corruption rejects.
     */
    public CompletableFuture<Optional<VeilSimulationCheckpoint>> load(Scope scope) {
        Objects.requireNonNull(scope, "scope");
        var future = new CompletableFuture<Optional<VeilSimulationCheckpoint>>();
        if (reserve(future))
            submit(
                    future,
                    () -> {
                        var bytes = store.load(scope.worldKey(), scope.pack(), scope.state());
                        return bytes.isEmpty()
                                ? Optional.empty()
                                : Optional.of(decode(scope, bytes.get()));
                    });
        return future;
    }

    private boolean reserve(CompletableFuture<?> future) {
        if (closed.get() || !busy.compareAndSet(false, true)) {
            future.completeExceptionally(
                    new RejectedExecutionException("Checkpoint store closed or busy"));
            return false;
        }
        if (closed.get()) {
            busy.set(false);
            future.completeExceptionally(new RejectedExecutionException("Checkpoint store closed"));
            return false;
        }
        var reservation = VeilSimulationCheckpointAdmission.reserve(store.maxSnapshotBytes());
        if (reservation == null) {
            busy.set(false);
            future.completeExceptionally(
                    new RejectedExecutionException("Global checkpoint admission budget exceeded"));
            return false;
        }
        admission.set(reservation);
        if (closed.get()) {
            finish(future, null, new RejectedExecutionException("Checkpoint store closed"));
            return false;
        }
        return true;
    }

    private interface Work<T> {
        T run() throws IOException;
    }

    private <T> void submit(CompletableFuture<T> future, Work<T> work) {
        try {
            worker.execute(
                    () -> {
                        T result;
                        try {
                            result = work.run();
                        } catch (IOException | RuntimeException | Error failure) {
                            finish(future, null, failure);
                            return;
                        }
                        finish(future, result, null);
                    });
        } catch (RejectedExecutionException failure) {
            finish(future, null, failure);
        }
    }

    private <T> void finish(CompletableFuture<T> future, T result, Throwable failure) {
        var reservation = admission.getAndSet(null);
        if (reservation != null) reservation.close();
        busy.set(false);
        if (failure == null) future.complete(result);
        else future.completeExceptionally(failure);
    }

    @Override
    public void close() {
        closed.set(true);
        worker.shutdown();
    }

    private byte[] encode(Scope scope, VeilSimulationCheckpoint checkpoint) throws IOException {
        // Enforce the wire budget while writing, before a growable stream can exceed it.
        var bytes =
                new ByteArrayOutputStream() {
                    private void budget(int added) {
                        if ((long) size() + added > store.maxSnapshotBytes())
                            throw new IllegalArgumentException(
                                    "Checkpoint exceeds serialized budget");
                    }

                    @Override
                    public synchronized void write(int value) {
                        budget(1);
                        super.write(value);
                    }

                    @Override
                    public synchronized void write(byte[] data, int offset, int length) {
                        budget(length);
                        super.write(data, offset, length);
                    }
                };
        try (var output = new DataOutputStream(bytes)) {
            output.writeInt(MAGIC);
            output.writeInt(VERSION);
            output.writeUTF(scope.world());
            output.writeUTF(scope.dimension());
            output.writeUTF(scope.pack());
            output.writeUTF(scope.state());
            output.writeInt(scope.schema());
            output.writeLong(checkpoint.generation().getMostSignificantBits());
            output.writeLong(checkpoint.generation().getLeastSignificantBits());
            output.writeLong(checkpoint.frame());
            output.writeInt(checkpoint.fields().size());
            for (var entry : new java.util.TreeMap<>(checkpoint.fields()).entrySet()) {
                var field = entry.getValue();
                output.writeUTF(entry.getKey());
                output.writeUTF(field.selection().resource());
                output.writeInt(field.selection().mip());
                output.writeInt(field.selection().layer());
                output.writeUTF(field.format().name());
                byte[] payload = field.data().encode();
                output.writeInt(payload.length);
                output.write(payload);
            }
            output.writeInt(checkpoint.cpuState().size());
            for (var entry : new java.util.TreeMap<>(checkpoint.cpuState()).entrySet()) {
                output.writeUTF(entry.getKey());
                byte[] payload = entry.getValue().data();
                output.writeInt(payload.length);
                output.write(payload);
            }
        }
        // The existing bundle/store own outer encoding, checksum, and atomic file publication.
        byte[] encoded =
                new VeilSimulationBundle().putData("checkpoint", bytes.toByteArray()).encode();
        if (encoded.length > store.maxSnapshotBytes())
            throw new IllegalArgumentException("Checkpoint envelope exceeds serialized budget");
        return encoded;
    }

    private VeilSimulationCheckpoint decode(Scope expected, byte[] bytes) throws IOException {
        var bundle = VeilSimulationBundle.decode(bytes);
        if (!bundle.ids().equals(java.util.Set.of("checkpoint")))
            throw new IOException("Unexpected checkpoint entries");
        byte[] payload =
                bundle.data("checkpoint").orElseThrow(() -> new IOException("Missing checkpoint"));
        try (var input = new DataInputStream(new ByteArrayInputStream(payload))) {
            if (input.readInt() != MAGIC)
                throw new IOException("Unsupported GPU checkpoint encoding");
            int version = input.readInt();
            if (version != 1 && version != VERSION)
                throw new IOException("Unsupported GPU checkpoint version");
            var actual =
                    new Scope(
                            input.readUTF(),
                            input.readUTF(),
                            input.readUTF(),
                            input.readUTF(),
                            input.readInt());
            if (!expected.equals(actual))
                throw new IOException("Checkpoint identity/schema mismatch");
            var generation = new UUID(input.readLong(), input.readLong());
            long frame = input.readLong();
            int count = input.readInt();
            if (count < 1 || count > 128) throw new IOException("Invalid GPU checkpoint count");
            var fields = new LinkedHashMap<String, VeilSimulationCheckpoint.Field>();
            for (int index = 0; index < count; index++) {
                String id = input.readUTF();
                VeilSimulationCheckpoint.checkId(id);
                var selection =
                        new VeilSimulationCheckpoint.Selection(
                                input.readUTF(), input.readInt(), input.readInt());
                var format = VeilFormat.valueOf(input.readUTF());
                int length = input.readInt();
                if (length < 36 || length > input.available())
                    throw new IOException("Invalid GPU field length");
                var field =
                        new VeilSimulationCheckpoint.Field(
                                selection,
                                format,
                                VeilSimulationFieldSnapshot.decode(input.readNBytes(length)));
                if (fields.putIfAbsent(id, field) != null)
                    throw new IOException("Duplicate GPU field id");
            }
            var cpuState = new LinkedHashMap<String, VeilSimulationCheckpoint.CpuState>();
            if (version >= 2) {
                int cpuCount = input.readInt();
                if (cpuCount < 0 || cpuCount > 128)
                    throw new IOException("Invalid CPU checkpoint count");
                for (int index = 0; index < cpuCount; index++) {
                    String id = input.readUTF();
                    VeilSimulationCheckpoint.checkId(id);
                    int length = input.readInt();
                    if (length < 0 || length > input.available())
                        throw new IOException("Invalid CPU checkpoint length");
                    var state = new VeilSimulationCheckpoint.CpuState(input.readNBytes(length));
                    if (cpuState.putIfAbsent(id, state) != null)
                        throw new IOException("Duplicate CPU checkpoint id");
                }
            }
            if (input.available() != 0) throw new IOException("Trailing GPU checkpoint data");
            return new VeilSimulationCheckpoint(generation, frame, fields, cpuState);
        } catch (IllegalArgumentException failure) {
            throw new IOException("Invalid GPU checkpoint metadata", failure);
        }
    }
}
