package dev.veil.revive.client.shaderpack.preparation;

import static dev.veil.revive.client.shaderpack.preparation.BindingValidator.*;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.api.VeilFormat;
import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderInterface;
import dev.veil.revive.client.VeilShaderPack.ColorAttachment;
import dev.veil.revive.client.VeilShaderPack.DepthAttachment;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.Resource;
import dev.veil.revive.client.VeilShaderPack.StoreOp;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class AttachmentValidator {
    private final Map<String, Resource> resources;
    private final List<Pass> passes;
    private final String present;

    public AttachmentValidator(Map<String, Resource> resources, List<Pass> passes, String present) {
        this.resources = resources;
        this.passes = passes;
        this.present = present;
    }

    public void validateFragmentFormats(Pass pass, VeilShaderInterface shaderInterface) {
        var outputs = new LinkedHashMap<Integer, VeilShaderInterface.StageIo>();
        for (var output : shaderInterface.stageOutputs()) {
            if ((output.stageFlags() & VK_SHADER_STAGE_FRAGMENT_BIT) != 0)
                outputs.put(output.location(), output);
        }
        for (int location = 0; location < pass.colors().size(); location++) {
            var output = outputs.get(location);
            if (output == null) continue;
            VeilFormat format = resources.get(pass.colors().get(location).resource()).format();
            int expected =
                    switch (format.numericType()) {
                        case UINT -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_UINT32;
                        case SINT -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_INT32;
                        default -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_FP32;
                    };
            if (output.baseType() != expected
                    || output.bitWidth() != 32
                    || output.columns() != 1
                    || output.arrayElements() != 1) {
                throw new IllegalArgumentException(
                        "Pass "
                                + pass.name()
                                + " fragment output location="
                                + location
                                + " is incompatible with color format "
                                + format);
            }
        }
    }

    public void validateDiscardedAttachments(List<VeilRenderGraph.Pass> ordered) {
        var discarded = new LinkedHashMap<String, List<VeilRenderGraph.Subresource>>();
        var definitions = new LinkedHashMap<String, Pass>();
        passes.forEach(pass -> definitions.put(pass.name(), pass));
        for (var graphPass : ordered) {
            for (var use : graphPass.uses()) {
                List<VeilRenderGraph.Subresource> ranges =
                        discarded.getOrDefault(use.resource(), List.of());
                if (use.access().reads()
                        && ranges.stream().anyMatch(range -> range.overlaps(use.subresource()))) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + graphPass.name()
                                    + " reads attachment contents discarded by an earlier store=dont_care: "
                                    + use.resource());
                }
                if (use.access().writes() && !ranges.isEmpty()) {
                    var remaining = new ArrayList<VeilRenderGraph.Subresource>();
                    for (var range : ranges)
                        if (!use.subresource().covers(range)) remaining.add(range);
                    if (remaining.isEmpty()) discarded.remove(use.resource());
                    else discarded.put(use.resource(), List.copyOf(remaining));
                }
            }
            Pass definition = definitions.get(graphPass.name());
            if (definition == null) continue;
            for (ColorAttachment color : definition.colors()) {
                if (color.store() == StoreOp.DONT_CARE)
                    addDiscarded(
                            discarded,
                            color.resource(),
                            VeilRenderGraph.Subresource.image(color.mip(), 1, color.layer(), 1));
            }
            if (definition.depth() != null && definition.depth().store() == StoreOp.DONT_CARE) {
                DepthAttachment depth = definition.depth();
                addDiscarded(
                        discarded,
                        depth.resource(),
                        VeilRenderGraph.Subresource.image(depth.mip(), 1, depth.layer(), 1));
            }
        }
        if (present != null && !discarded.getOrDefault(present, List.of()).isEmpty()) {
            throw new IllegalArgumentException(
                    "Present reads attachment contents discarded by store=dont_care: " + present);
        }
    }

    private static void addDiscarded(
            Map<String, List<VeilRenderGraph.Subresource>> discarded,
            String resource,
            VeilRenderGraph.Subresource subresource) {
        var ranges = new ArrayList<>(discarded.getOrDefault(resource, List.of()));
        ranges.add(subresource);
        discarded.put(resource, ranges);
    }
}
