package dev.veil.revive.client.terrain;

public interface QueuedSectionTaskOrigin {
    void veil$setQueueIndexKey(long key);

    long veil$getQueueIndexKey();
}
