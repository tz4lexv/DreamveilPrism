package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.VK_OBJECT_TYPE_SHADER_MODULE;

import dev.veil.revive.client.graphics.pipelines.NativeShaderModule;

final class VeilShaderModule implements AutoCloseable {
    private final VeilSpirvBinary binary;
    private final NativeShaderModule resource;

    private VeilShaderModule(VeilSpirvBinary binary, NativeShaderModule resource) {
        this.binary = binary;
        this.resource = resource;
    }

    public static VeilShaderModule create(VeilVulkanRuntime runtime, VeilSpirvBinary binary) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        byte[] code = binary.unsafeCode();
        var resource =
                NativeShaderModule.create(
                        runtime,
                        code,
                        binary.sourceName(),
                        handle ->
                                VeilShaderDebugNames.name(
                                        runtime,
                                        VK_OBJECT_TYPE_SHADER_MODULE,
                                        handle,
                                        "Veil/Shader/"
                                                + binary.sourceName()
                                                + "/"
                                                + binary.contentHash()));
        return new VeilShaderModule(binary, resource);
    }

    public long handle() {
        return resource.handle();
    }

    public VeilSpirvBinary binary() {
        return binary;
    }

    void destroyNow() {
        resource.destroyNow();
    }

    @Override
    public void close() {
        resource.close();
    }
}
