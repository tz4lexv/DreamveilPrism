package dev.veil.revive.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

final class VeilToml {
    private static final int MAX_DEPTH = 32;
    private static final int MAX_ENTRIES = 8192;

    private final JsonObject root = new JsonObject();
    private JsonObject current = root;
    private int entries;

    private VeilToml() {}

    static JsonObject parse(String source) throws IOException {
        if (source.length() > VeilShaderAssets.MAX_SHADER_ASSET_BYTES)
            throw new IOException("pipeline.toml exceeds 4 MiB");
        return new VeilToml().document(source);
    }

    private JsonObject document(String source) throws IOException {
        String[] lines = source.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
        for (int line = 0; line < lines.length; line++) {
            String value = stripComment(lines[line]).trim();
            if (value.isEmpty()) continue;
            if (value.startsWith("[[")) {
                if (!value.endsWith("]]")) throw error(line, "Invalid array-table header");
                current = arrayTable(path(value.substring(2, value.length() - 2), line), line);
                continue;
            }
            if (value.startsWith("[")) {
                if (!value.endsWith("]")) throw error(line, "Invalid table header");
                current = table(path(value.substring(1, value.length() - 1), line), line);
                continue;
            }
            int equals = assignment(value);
            if (equals < 1) throw error(line, "Expected key = value");
            String key = value.substring(0, equals).trim();
            String expression = value.substring(equals + 1).trim();
            while (!balanced(expression)) {
                if (++line >= lines.length) throw error(line - 1, "Unterminated value");
                expression += "\n" + stripComment(lines[line]).trim();
            }
            put(current, path(key, line), new ValueParser(expression, line + 1).parse(), line);
        }
        return root;
    }

    private JsonObject table(List<String> path, int line) throws IOException {
        JsonObject object = root;
        for (String segment : path) object = childObject(object, segment, line);
        return object;
    }

    private JsonObject arrayTable(List<String> path, int line) throws IOException {
        JsonObject parent = root;
        for (int index = 0; index < path.size() - 1; index++)
            parent = childObject(parent, path.get(index), line);
        String name = path.getLast();
        JsonArray array;
        if (!parent.has(name)) {
            array = new JsonArray();
            parent.add(name, array);
        } else if (parent.get(name).isJsonArray()) {
            array = parent.getAsJsonArray(name);
        } else {
            throw error(line, "Array-table conflicts with " + name);
        }
        var object = new JsonObject();
        array.add(object);
        count(line);
        return object;
    }

    private JsonObject childObject(JsonObject parent, String name, int line) throws IOException {
        if (!parent.has(name)) {
            var child = new JsonObject();
            parent.add(name, child);
            count(line);
            return child;
        }
        JsonElement element = parent.get(name);
        if (element.isJsonObject()) return element.getAsJsonObject();
        if (element.isJsonArray()) {
            JsonArray array = element.getAsJsonArray();
            if (array.isEmpty() || !array.get(array.size() - 1).isJsonObject())
                throw error(line, "Table path has no active object: " + name);
            return array.get(array.size() - 1).getAsJsonObject();
        }
        throw error(line, "Table path conflicts with value " + name);
    }

    private void put(JsonObject target, List<String> path, JsonElement value, int line)
            throws IOException {
        JsonObject parent = target;
        for (int index = 0; index < path.size() - 1; index++)
            parent = childObject(parent, path.get(index), line);
        String key = path.getLast();
        if (parent.has(key)) throw error(line, "Duplicate key " + key);
        parent.add(key, value);
        count(line);
    }

    private void count(int line) throws IOException {
        if (++entries > MAX_ENTRIES) throw error(line, "Too many TOML entries");
    }

    private static int assignment(String line) {
        boolean quoted = false;
        boolean escaped = false;
        for (int index = 0; index < line.length(); index++) {
            char c = line.charAt(index);
            if (quoted) {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') quoted = false;
            } else if (c == '"') quoted = true;
            else if (c == '=') return index;
        }
        return -1;
    }

    private static List<String> path(String input, int line) throws IOException {
        var result = new ArrayList<String>();
        int start = 0;
        boolean quoted = false;
        boolean escaped = false;
        for (int index = 0; index <= input.length(); index++) {
            char c = index == input.length() ? '.' : input.charAt(index);
            if (quoted) {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') quoted = false;
            } else if (c == '"') quoted = true;
            else if (c == '.') {
                String segment = input.substring(start, index).trim();
                if (segment.startsWith("\"") && segment.endsWith("\"") && segment.length() >= 2) {
                    segment = new ValueParser(segment, line + 1).string();
                }
                if (!segment.matches("[A-Za-z0-9_-]+")) throw error(line, "Invalid key " + segment);
                result.add(segment);
                start = index + 1;
            }
        }
        if (quoted || result.isEmpty() || result.size() > MAX_DEPTH)
            throw error(line, "Invalid key path");
        return result;
    }

    private static boolean balanced(String input) throws IOException {
        int square = 0;
        int curly = 0;
        boolean quoted = false;
        boolean escaped = false;
        for (int index = 0; index < input.length(); index++) {
            char c = input.charAt(index);
            if (quoted) {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') quoted = false;
                continue;
            }
            if (c == '"') quoted = true;
            else if (c == '[') square++;
            else if (c == ']') square--;
            else if (c == '{') curly++;
            else if (c == '}') curly--;
            if (square < 0 || curly < 0) throw new IOException("Unbalanced pipeline.toml value");
        }
        return !quoted && square == 0 && curly == 0;
    }

    private static String stripComment(String line) {
        boolean quoted = false;
        boolean escaped = false;
        for (int index = 0; index < line.length(); index++) {
            char c = line.charAt(index);
            if (quoted) {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') quoted = false;
            } else if (c == '"') quoted = true;
            else if (c == '#') return line.substring(0, index);
        }
        return line;
    }

    private static IOException error(int zeroBasedLine, String message) {
        return new IOException("pipeline.toml:" + (zeroBasedLine + 1) + ": " + message);
    }

    private static final class ValueParser {
        private final String input;
        private final int line;
        private int position;
        private int depth;

        ValueParser(String input, int line) {
            this.input = input;
            this.line = line;
        }

        JsonElement parse() throws IOException {
            JsonElement value = value();
            whitespace();
            if (position != input.length()) throw failure("Unexpected trailing input");
            return value;
        }

        private JsonElement value() throws IOException {
            whitespace();
            if (position >= input.length()) throw failure("Missing value");
            char c = input.charAt(position);
            if (c == '"') return new JsonPrimitive(string());
            if (c == '[') return array();
            if (c == '{') return inlineTable();
            int start = position;
            while (position < input.length() && ",]} \t\r\n".indexOf(input.charAt(position)) < 0)
                position++;
            String token = input.substring(start, position).replace("_", "");
            if (token.equals("true") || token.equals("false"))
                return new JsonPrimitive(Boolean.parseBoolean(token));
            try {
                if (token.matches("[+-]?\\d+")) return new JsonPrimitive(new BigInteger(token));
                if (token.matches("[+-]?(?:\\d+\\.\\d*|\\d*\\.\\d+)(?:[eE][+-]?\\d+)?")
                        || token.matches("[+-]?\\d+[eE][+-]?\\d+"))
                    return new JsonPrimitive(new BigDecimal(token));
            } catch (NumberFormatException invalid) {
                throw failure("Invalid number " + token);
            }
            throw failure("Unsupported bare value " + token);
        }

        private JsonArray array() throws IOException {
            enter();
            position++;
            var result = new JsonArray();
            whitespace();
            if (consume(']')) {
                leave();
                return result;
            }
            while (true) {
                result.add(value());
                whitespace();
                if (consume(']')) {
                    leave();
                    return result;
                }
                if (!consume(',')) throw failure("Expected ',' or ']'");
                whitespace();
                if (consume(']')) {
                    leave();
                    return result;
                }
            }
        }

        private JsonObject inlineTable() throws IOException {
            enter();
            position++;
            var result = new JsonObject();
            whitespace();
            if (consume('}')) {
                leave();
                return result;
            }
            while (true) {
                String key = inlineKey();
                whitespace();
                if (!consume('=')) throw failure("Expected '=' in inline table");
                JsonElement value = value();
                if (result.has(key)) throw failure("Duplicate inline key " + key);
                result.add(key, value);
                whitespace();
                if (consume('}')) {
                    leave();
                    return result;
                }
                if (!consume(',')) throw failure("Expected ',' or '}'");
            }
        }

        private String inlineKey() throws IOException {
            whitespace();
            if (position < input.length() && input.charAt(position) == '"') return string();
            int start = position;
            while (position < input.length() && "=,{} \t\r\n".indexOf(input.charAt(position)) < 0)
                position++;
            String key = input.substring(start, position);
            if (!key.matches("[A-Za-z0-9_-]+")) throw failure("Invalid inline key " + key);
            return key;
        }

        String string() throws IOException {
            if (!consume('"')) throw failure("Expected string");
            var result = new StringBuilder();
            while (position < input.length()) {
                char c = input.charAt(position++);
                if (c == '"') return result.toString();
                if (c != '\\') {
                    result.append(c);
                    continue;
                }
                if (position >= input.length()) throw failure("Unterminated escape");
                char escape = input.charAt(position++);
                result.append(
                        switch (escape) {
                            case '"' -> '"';
                            case '\\' -> '\\';
                            case 'n' -> '\n';
                            case 'r' -> '\r';
                            case 't' -> '\t';
                            default -> throw failure("Unsupported escape \\" + escape);
                        });
            }
            throw failure("Unterminated string");
        }

        private void enter() throws IOException {
            if (++depth > MAX_DEPTH) throw failure("Value nesting exceeds " + MAX_DEPTH);
        }

        private void leave() {
            depth--;
        }

        private void whitespace() {
            while (position < input.length() && Character.isWhitespace(input.charAt(position)))
                position++;
        }

        private boolean consume(char expected) {
            if (position < input.length() && input.charAt(position) == expected) {
                position++;
                return true;
            }
            return false;
        }

        private IOException failure(String message) {
            return new IOException("pipeline.toml:" + line + ":" + (position + 1) + ": " + message);
        }
    }
}
