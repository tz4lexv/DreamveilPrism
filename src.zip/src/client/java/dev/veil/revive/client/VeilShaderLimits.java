package dev.veil.revive.client;

final class VeilShaderLimits {
    static final int MAX_BUFFER_BYTES = 1024 * 1024 * 1024;

    record Settings(
            int passes,
            int resources,
            int bufferMiB,
            int packMiB,
            int rayMiB,
            int rayRadius,
            int offscreenCompiles,
            int rebuildMs) {
        long bufferBytes() {
            return bufferMiB * 1024L * 1024;
        }

        long packBytes() {
            return packMiB * 1024L * 1024;
        }

        int rayBytes() {
            return rayMiB * 1024 * 1024;
        }
    }

    private static volatile Settings settings = new Settings(128, 256, 256, 512, 128, 128, 2, 100);

    private VeilShaderLimits() {}

    static Settings current() {
        return settings;
    }

    static void refreshConfig() {
        settings =
                new Settings(
                        VeilVideoConfig.number("shader.maxPasses", 128, 16, 4096),
                        VeilVideoConfig.number("shader.maxResources", 256, 32, 16384),
                        VeilVideoConfig.number("shader.bufferMiB", 256, 16, 1024),
                        VeilVideoConfig.number("shader.packMiB", 512, 128, 8192),
                        VeilVideoConfig.number("shader.rayMiB", 128, 8, 1024),
                        VeilVideoConfig.number("shader.rayRadius", 128, 16, 512),
                        VeilVideoConfig.number("shader.offscreenCompiles", 2, 0, 16),
                        VeilVideoConfig.number("shader.rebuildMs", 100, 50, 2000));
    }

    static int rayTriangleCapacity(long bufferBytes) {
        if (bufferBytes <= 192) return 0;
        return (int) Math.max(0, Math.min(VeilRayScene.MAX_TRIANGLES, (bufferBytes - 192) / 192))
                & ~1;
    }

    static int rayCapacityBytes(int triangles) {
        if (triangles < 0 || triangles > VeilRayScene.MAX_TRIANGLES)
            throw new IllegalArgumentException("Ray triangle capacity is not representable");
        return Math.toIntExact(Math.addExact(192L, Math.multiplyExact(triangles, 192L)));
    }
}
