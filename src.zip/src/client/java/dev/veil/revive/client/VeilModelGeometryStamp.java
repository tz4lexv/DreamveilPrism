package dev.veil.revive.client;

import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;

record VeilModelGeometryStamp(
        Object key, int hash, int visibleFaces, int lightingPath, int pipeline) {
    VeilModelGeometryStamp(Object key, int hash, int visibleFaces) {
        this(key, hash, visibleFaces, 0, 0);
    }

    private static final ThreadLocal<RandomSource> RANDOM =
            ThreadLocal.withInitial(() -> RandomSource.createThreadLocalInstance(0));

    VeilModelGeometryStamp {
        if (key == null || (visibleFaces & ~63) != 0)
            throw new IllegalArgumentException("Invalid model geometry stamp");
    }

    static VeilModelGeometryStamp capture(
            VeilSectionRenderAdapter adapter,
            RenderSectionRegion region,
            BlockPos position,
            BlockState state,
            BlockStateModel model) {
        return capture(adapter, region, position, state, model, 0);
    }

    static VeilModelGeometryStamp capture(
            VeilSectionRenderAdapter adapter,
            RenderSectionRegion region,
            BlockPos position,
            BlockState state,
            BlockStateModel model,
            int pipeline) {
        var random = RANDOM.get();
        random.setSeed(state.getSeed(position));
        var key = adapter.geometryKey(region, position, state, model, random);
        return key == null
                ? null
                : new VeilModelGeometryStamp(
                        key,
                        key.hashCode(),
                        adapter.visibleFaces(region, position, state),
                        adapter.lightingPath(region, position, state),
                        pipeline);
    }

    boolean matches(VeilModelGeometryStamp current) {
        return current != null
                && hash == key.hashCode()
                && current.hash == current.key.hashCode()
                && hash == current.hash
                && visibleFaces == current.visibleFaces
                && lightingPath == current.lightingPath
                && pipeline == current.pipeline
                && key.equals(current.key);
    }
}
