package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.api.VeilEnvironment;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.Identifier;

public final class PbrMipGpuProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment() && Boolean.getBoolean("veil.pbrMipProbe");
    private static Object world;
    private static VeilShaderPackRuntime generation;
    private static int seenFrames;
    private static int mipLevels;
    private static boolean failed;

    private PbrMipGpuProbe() {}

    static void prepare(VeilShaderPackRuntime active) {
        if (!ENABLED) return;
        int mask = PbrReloadGpuProbe.expectedMask(active);
        if (active.pbrAtlasMask() != mask
                || (VeilPbrAtlas.texture(false) != null) != ((mask & 1) != 0)
                || (VeilPbrAtlas.texture(true) != null) != ((mask & 2) != 0))
            throw new IllegalStateException("Unexpected PBR atlas allocation mask " + mask);
        var client = Minecraft.getInstance();
        if (Boolean.getBoolean("veil.int64Probe")
                && !dev.veil.api.VeilGraphicsCapabilities.shaderInt64())
            throw new IllegalStateException(
                    "Public Int64 capability differs from executable device feature");
        if (world != client.level || generation != active) {
            world = client.level;
            generation = active;
            seenFrames = 0;
            if (Boolean.getBoolean("veil.int64Probe"))
                ReviveMod.LOGGER.info("Veil public Int64 capability: PASS enabled=true");
            if (Boolean.getBoolean("veil.precisionProbe")) {
                var enabled = dev.veil.api.VeilGraphicsCapabilities.enabledDeviceFeatures();
                for (String feature :
                        java.util.List.of(
                                "shaderFloat16",
                                "shaderInt8",
                                "shaderInt16",
                                "storageBuffer16BitAccess",
                                "storageBuffer8BitAccess")) {
                    if (!enabled.contains(feature)
                            || !dev.veil.revive.client.graphics.minecraft.EnabledDeviceFeatures
                                    .enabledOnCurrentDevice(feature))
                        throw new IllegalStateException(
                                "Precision fixture requires enabled " + feature);
                }
                if (!VeilVulkanCapabilities.shaderFloat16()
                        || !VeilVulkanCapabilities.shaderInt8()
                        || !VeilVulkanCapabilities.shaderInt16()
                        || !VeilVulkanCapabilities.storageBuffer16()
                        || !VeilVulkanCapabilities.storageBuffer8())
                    throw new IllegalStateException(
                            "Precision getters differ from device snapshot");
                ReviveMod.LOGGER.info(
                        "Veil public precision capabilities: PASS FP16 INT8 INT16 STORAGE16 STORAGE8");
            }
        }
        var texture = client.getTextureManager().getTexture(TextureAtlas.LOCATION_BLOCKS);
        if (!(texture instanceof TextureAtlas atlas))
            throw new IllegalStateException("PBR probe atlas unavailable");
        var sprite = atlas.getSprite(Identifier.fromNamespaceAndPath("minecraft", "block/stone"));
        float[] channels = new float[VeilEnvironment.CUSTOM_CHANNELS];
        channels[0] = sprite.getX();
        channels[1] = sprite.getY();
        var selected = VeilPbrAtlas.texture((mask & 1) == 0);
        channels[2] =
                selected == null ? atlas.getTexture().getMipLevels() : selected.getMipLevels();
        mipLevels = (int) channels[2];
        channels[3] = client.level.getGameTime() & 1;
        channels[4] = AutomaticMeshUvGpuProbe.expectedEntity();
        if (channels[2] < 5)
            throw new IllegalStateException("PBR probe requires five populated mip levels");
        VeilEnvironment.setChannels(31, channels);
        VeilEnvironmentHost.prepare();
    }

    public static boolean verified(Object currentWorld) {
        return !ENABLED || (!failed && world == currentWorld && seenFrames == 3);
    }

    static VeilShaderPackRuntime generation() {
        return generation;
    }

    static void tick(VeilShaderPackRuntime active) {
        if (!ENABLED || failed || seenFrames == 3) return;
        if (!AutomaticMeshUvGpuProbe.ready()) return;
        Object capturedWorld = world;
        int capturedMask = PbrReloadGpuProbe.expectedMask(active);
        int capturedLevels = mipLevels;
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil PBR mip readback",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                4);
        try {
            active.readOutput(
                    "pbrMipProof",
                    readback,
                    () -> {
                        try (var mapped = readback.map(true, false)) {
                            if (world != capturedWorld || generation != active) return;
                            var bytes = mapped.data();
                            int frame = Byte.toUnsignedInt(bytes.get(2));
                            if (Byte.toUnsignedInt(bytes.get(0)) != 0
                                    || Byte.toUnsignedInt(bytes.get(1)) != 255
                                    || frame > 1
                                    || Byte.toUnsignedInt(bytes.get(3)) != 255)
                                throw new IllegalStateException("Invalid animated PBR mip pixel");
                            if (world == capturedWorld) {
                                seenFrames |= 1 << frame;
                                if (seenFrames == 3)
                                    ReviveMod.LOGGER.info(
                                            "Veil PBR mip GPU: PASS dimension={} levels={} animated_frames=2 mask={}",
                                            Minecraft.getInstance().level.dimension().identifier(),
                                            capturedLevels,
                                            capturedMask);
                            }
                        } catch (RuntimeException problem) {
                            failed = true;
                            ReviveMod.LOGGER.error(
                                    "Veil PBR mip GPU: FAIL ({})", problem.getMessage());
                            Minecraft.getInstance().stop();
                        } finally {
                            readback.close();
                        }
                    });
        } catch (RuntimeException | Error problem) {
            readback.close();
            throw problem;
        }
    }
}
