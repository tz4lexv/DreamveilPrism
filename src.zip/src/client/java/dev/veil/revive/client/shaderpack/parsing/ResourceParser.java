package dev.veil.revive.client.shaderpack.parsing;

import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.*;
import static dev.veil.revive.client.shaderpack.parsing.PipelineStateParser.sampler;
import static dev.veil.revive.client.shaderpack.parsing.SettingsExpressions.*;

import com.google.gson.JsonObject;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilResourceType;
import dev.veil.api.VeilResourceUsage;
import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderId;
import dev.veil.revive.client.VeilShaderPack.InitialContent;
import dev.veil.revive.client.VeilShaderPack.Lifetime;
import dev.veil.revive.client.VeilShaderPack.Resource;
import dev.veil.revive.client.VeilShaderPack.Sampler;
import dev.veil.revive.client.VeilShaderPack.Setting;
import dev.veil.revive.client.VeilShaderPack.Source;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public final class ResourceParser {
    private ResourceParser() {}

    public record HostDefinition(
            VeilRenderGraph.Kind kind, VeilResourceType type, Set<VeilResourceUsage> usages) {}

    public static Map<String, Resource> parseResources(
            JsonObject root,
            String namespace,
            int manifestAbi,
            Map<String, Setting> settings,
            java.util.function.Function<Source, String> legacyId,
            java.util.function.Function<String, HostDefinition> hosts) {
        var resources = new LinkedHashMap<String, Resource>();
        for (var entry : object(root, "resources").entrySet()) {
            String id = resourceName(entry.getKey());
            JsonObject item = entry.getValue().getAsJsonObject();
            fields(
                    item,
                    "type",
                    "bytes",
                    "format",
                    "width",
                    "height",
                    "widthSetting",
                    "heightSetting",
                    "depth",
                    "layers",
                    "mipLevels",
                    "scale",
                    "widthScale",
                    "heightScale",
                    "sizeFrom",
                    "samples",
                    "usage",
                    "source",
                    "host",
                    "history",
                    "historyCount",
                    "lifetime",
                    "asset",
                    "sampler",
                    "initial");
            if (item.has("source") && item.has("host"))
                throw new IllegalArgumentException(
                        "Resource " + id + " cannot declare both source and host");
            if (item.has("lifetime") && item.has("history"))
                throw new IllegalArgumentException(
                        "Resource " + id + " cannot declare both lifetime and legacy history");
            if (item.has("lifetime") && manifestAbi < 10)
                throw new IllegalArgumentException(
                        "Explicit resource lifetimes require Veil shader ABI 10+");
            Source sourceKind =
                    item.has("host")
                            ? Source.HOST
                            : item.has("source")
                                    ? switch (item.get("source").getAsString()) {
                                        case "scene_color" -> Source.SCENE_COLOR;
                                        case "scene_depth" -> Source.SCENE_DEPTH;
                                        case "scene_opaque_color" -> Source.SCENE_OPAQUE_COLOR;
                                        case "scene_opaque_depth" -> Source.SCENE_OPAQUE_DEPTH;
                                        case "scene_material_id" -> Source.SCENE_MATERIAL_ID;
                                        case "scene_material_depth" -> Source.SCENE_MATERIAL_DEPTH;
                                        default ->
                                                throw new IllegalArgumentException(
                                                        "Unsupported imported source "
                                                                + item.get("source"));
                                    }
                                    : Source.OWNED;
            String hostId =
                    sourceKind == Source.HOST
                            ? item.get("host").getAsString()
                            : sourceKind == Source.OWNED ? null : legacyId.apply(sourceKind);
            HostDefinition hostDefinition = hostId == null ? null : hosts.apply(hostId);
            if (sourceKind != Source.OWNED
                    && (item.has("format")
                            || item.has("width")
                            || item.has("height")
                            || item.has("widthSetting")
                            || item.has("heightSetting")
                            || item.has("depth")
                            || item.has("layers")
                            || item.has("mipLevels")
                            || item.has("scale")
                            || item.has("widthScale")
                            || item.has("heightScale")
                            || item.has("sizeFrom")
                            || item.has("samples")
                            || item.has("usage")
                            || item.has("bytes")
                            || item.has("history")
                            || item.has("historyCount")
                            || item.has("lifetime")
                            || item.has("asset")
                            || item.has("initial"))) {
                if (sourceKind == Source.SCENE_COLOR
                        || sourceKind == Source.SCENE_DEPTH
                        || sourceKind == Source.SCENE_OPAQUE_COLOR
                        || sourceKind == Source.SCENE_OPAQUE_DEPTH
                        || sourceKind == Source.SCENE_MATERIAL_ID
                        || sourceKind == Source.SCENE_MATERIAL_DEPTH) {
                    throw new IllegalArgumentException(
                            "Scene import must not declare owned resource fields: " + id);
                }
                if (sourceKind == Source.HOST)
                    throw new IllegalArgumentException(
                            "Host import must not declare owned resource fields: " + id);
                throw new IllegalArgumentException(
                        "Scene import must not declare owned resource fields: " + id);
            }
            String type;
            if (item.has("type")) type = item.get("type").getAsString();
            else if (sourceKind == Source.HOST)
                type = hostDefinition.kind() == VeilRenderGraph.Kind.IMAGE ? "image" : "buffer";
            else throw new IllegalArgumentException("Resource " + id + " requires a type");
            VeilRenderGraph.Kind kind;
            VeilResourceType resourceType;
            Set<VeilResourceUsage> usages;
            switch (type) {
                case "buffer" -> {
                    kind = VeilRenderGraph.Kind.BUFFER;
                    resourceType = VeilResourceType.BUFFER;
                    usages =
                            Set.of(
                                    VeilResourceUsage.STORAGE,
                                    VeilResourceUsage.TRANSFER_SOURCE,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "image" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.TEXTURE_2D;
                    usages =
                            sourceKind == Source.OWNED
                                    ? Set.of(
                                            VeilResourceUsage.COLOR_ATTACHMENT,
                                            VeilResourceUsage.SAMPLED,
                                            VeilResourceUsage.TRANSFER_SOURCE,
                                            VeilResourceUsage.TRANSFER_DESTINATION)
                                    : Set.of(VeilResourceUsage.SAMPLED);
                }
                case "texture1d", "texture1dArray", "storageImage1d", "storageImage1dArray" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType =
                            type.endsWith("Array")
                                    ? VeilResourceType.TEXTURE_1D_ARRAY
                                    : VeilResourceType.TEXTURE_1D;
                    usages =
                            type.startsWith("storage")
                                    ? Set.of(
                                            VeilResourceUsage.SAMPLED,
                                            VeilResourceUsage.STORAGE,
                                            VeilResourceUsage.TRANSFER_DESTINATION)
                                    : Set.of(
                                            VeilResourceUsage.SAMPLED,
                                            VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "texture2d" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.TEXTURE_2D;
                    usages =
                            Set.of(
                                    VeilResourceUsage.SAMPLED,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "texture2dArray" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.TEXTURE_2D_ARRAY;
                    usages =
                            Set.of(
                                    VeilResourceUsage.SAMPLED,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "image3d", "texture3d" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.TEXTURE_3D;
                    usages =
                            Set.of(
                                    VeilResourceUsage.SAMPLED,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "cubemap" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.CUBEMAP;
                    usages =
                            Set.of(
                                    VeilResourceUsage.SAMPLED,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "cubemapArray" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.CUBEMAP_ARRAY;
                    usages =
                            Set.of(
                                    VeilResourceUsage.SAMPLED,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "storageImage2d" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.TEXTURE_2D;
                    usages =
                            Set.of(
                                    VeilResourceUsage.SAMPLED,
                                    VeilResourceUsage.STORAGE,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "storageImage2dArray" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.TEXTURE_2D_ARRAY;
                    usages =
                            Set.of(
                                    VeilResourceUsage.SAMPLED,
                                    VeilResourceUsage.STORAGE,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                case "storageImage3d" -> {
                    kind = VeilRenderGraph.Kind.IMAGE;
                    resourceType = VeilResourceType.TEXTURE_3D;
                    usages =
                            Set.of(
                                    VeilResourceUsage.SAMPLED,
                                    VeilResourceUsage.STORAGE,
                                    VeilResourceUsage.TRANSFER_DESTINATION);
                }
                default ->
                        throw new IllegalArgumentException(
                                "Resource " + id + ": unsupported type " + type);
            }
            if (hostDefinition != null) {
                if (hostDefinition.kind() != kind)
                    throw new IllegalArgumentException(
                            "Host resource "
                                    + hostId
                                    + " requires type "
                                    + (hostDefinition.kind() == VeilRenderGraph.Kind.IMAGE
                                            ? "image"
                                            : "buffer"));
                resourceType = hostDefinition.type();
                usages = hostDefinition.usages();
            }
            if (kind == VeilRenderGraph.Kind.BUFFER
                            && (item.has("format")
                                    || item.has("width")
                                    || item.has("height")
                                    || item.has("widthSetting")
                                    || item.has("heightSetting")
                                    || item.has("depth")
                                    || item.has("layers")
                                    || item.has("mipLevels")
                                    || item.has("scale")
                                    || item.has("widthScale")
                                    || item.has("heightScale")
                                    || item.has("sizeFrom")
                                    || item.has("samples")
                                    || item.has("sampler"))
                    || kind == VeilRenderGraph.Kind.IMAGE && item.has("bytes")) {
                throw new IllegalArgumentException(
                        "Resource " + id + ": fields do not match type " + type);
            }
            if (sourceKind != Source.OWNED && !type.equals("image") && !type.equals("buffer")) {
                throw new IllegalArgumentException(
                        "Host imports use type image/buffer, not " + type + ": " + id);
            }
            if (item.has("usage")) {
                if (manifestAbi < 11)
                    throw new IllegalArgumentException(
                            "Explicit resource usage requires Veil shader ABI 11+");
                var parsedUsages = new LinkedHashSet<VeilResourceUsage>();
                item.getAsJsonArray("usage")
                        .forEach(value -> parsedUsages.add(resourceUsage(value.getAsString())));
                usages = Set.copyOf(parsedUsages);
            }
            if ((item.has("widthScale")
                            || item.has("heightScale")
                            || item.has("widthSetting")
                            || item.has("heightSetting")
                            || item.has("sizeFrom")
                            || item.has("samples")
                            || item.has("historyCount")
                            || item.has("initial")
                            || type.equals("cubemap")
                            || type.equals("cubemapArray")
                            || resourceType == VeilResourceType.TEXTURE_1D
                            || resourceType == VeilResourceType.TEXTURE_1D_ARRAY)
                    && manifestAbi < 11) {
                throw new IllegalArgumentException(
                        "Generic resource descriptors require Veil shader ABI 11+");
            }
            if (item.has("scale") && (item.has("widthScale") || item.has("heightScale"))) {
                throw new IllegalArgumentException(
                        "Legacy scale cannot be combined with widthScale/heightScale: " + id);
            }
            Sampler sampler =
                    item.has("sampler")
                            ? sampler(item.getAsJsonObject("sampler"))
                            : Sampler.DEFAULT;
            VeilShaderId assetId =
                    item.has("asset") ? asset(namespace, item.get("asset").getAsString()) : null;
            Lifetime lifetime =
                    item.has("lifetime")
                            ? switch (item.get("lifetime").getAsString()) {
                                case "transient" -> Lifetime.TRANSIENT;
                                case "persistent" -> Lifetime.PERSISTENT;
                                case "history" -> Lifetime.HISTORY;
                                default ->
                                        throw new IllegalArgumentException(
                                                "Unsupported resource lifetime "
                                                        + item.get("lifetime")
                                                        + " for "
                                                        + id);
                            }
                            : item.has("history") && item.get("history").getAsBoolean()
                                    ? Lifetime.HISTORY
                                    : Lifetime.TRANSIENT;
            if (sourceKind != Source.OWNED && lifetime != Lifetime.TRANSIENT) {
                throw new IllegalArgumentException(
                        "Host resource cannot declare creator lifetime: " + id);
            }
            int historyCount =
                    lifetime == Lifetime.HISTORY
                            ? integer(item, "historyCount", 2)
                            : integer(item, "historyCount", 1);
            VeilFormat format =
                    kind == VeilRenderGraph.Kind.IMAGE && sourceKind == Source.OWNED
                            ? VeilFormat.valueOf(item.get("format").getAsString())
                            : null;
            float legacyScale = item.has("scale") ? item.get("scale").getAsFloat() : 1;
            InitialContent initialization =
                    item.has("initial")
                            ? switch (item.get("initial").getAsString()) {
                                case "undefined" -> InitialContent.UNDEFINED;
                                case "zero" -> InitialContent.ZERO;
                                default ->
                                        throw new IllegalArgumentException(
                                                "Resource initial must be undefined or zero: "
                                                        + id);
                            }
                            : null;
            if (item.has("width") && item.has("widthSetting")
                    || item.has("height") && item.has("heightSetting")) {
                throw new IllegalArgumentException(
                        "Resource dimensions cannot combine literals and settings: " + id);
            }
            int resolvedWidth =
                    item.has("widthSetting")
                            ? positiveIntegerSetting(
                                    settings, item.get("widthSetting").getAsString())
                            : integer(item, "width", 0);
            int resolvedHeight =
                    item.has("heightSetting")
                            ? positiveIntegerSetting(
                                    settings, item.get("heightSetting").getAsString())
                            : integer(
                                    item,
                                    "height",
                                    resourceType == VeilResourceType.TEXTURE_1D
                                                    || resourceType
                                                            == VeilResourceType.TEXTURE_1D_ARRAY
                                            ? 1
                                            : 0);
            resources.put(
                    id,
                    new Resource(
                            id,
                            kind,
                            item.has("bytes")
                                    ? item.get("bytes").getAsBigDecimal().longValueExact()
                                    : 0,
                            format,
                            resolvedWidth,
                            resolvedHeight,
                            integer(item, "depth", 1),
                            integer(
                                    item,
                                    "layers",
                                    resourceType == VeilResourceType.CUBEMAP
                                                    || resourceType
                                                            == VeilResourceType.CUBEMAP_ARRAY
                                            ? 6
                                            : 1),
                            integer(item, "mipLevels", 1),
                            item.has("widthScale")
                                    ? item.get("widthScale").getAsFloat()
                                    : legacyScale,
                            item.has("heightScale")
                                    ? item.get("heightScale").getAsFloat()
                                    : resourceType == VeilResourceType.TEXTURE_1D
                                                    || resourceType
                                                            == VeilResourceType.TEXTURE_1D_ARRAY
                                            ? 1
                                            : legacyScale,
                            item.has("sizeFrom")
                                    ? resourceName(item.get("sizeFrom").getAsString())
                                    : null,
                            integer(item, "samples", 1),
                            sourceKind,
                            lifetime,
                            historyCount,
                            hostId,
                            resourceType,
                            usages,
                            assetId,
                            sampler,
                            initialization));
        }
        validateDimensionDependencies(resources);
        return resources;
    }

    private static VeilResourceUsage resourceUsage(String name) {
        return switch (name) {
            case "sampled" -> VeilResourceUsage.SAMPLED;
            case "storage" -> VeilResourceUsage.STORAGE;
            case "colorAttachment" -> VeilResourceUsage.COLOR_ATTACHMENT;
            case "depthAttachment" -> VeilResourceUsage.DEPTH_ATTACHMENT;
            case "transferSource" -> VeilResourceUsage.TRANSFER_SOURCE;
            case "transferDestination" -> VeilResourceUsage.TRANSFER_DESTINATION;
            case "uniform" -> VeilResourceUsage.UNIFORM;
            case "vertex" -> VeilResourceUsage.VERTEX;
            case "index" -> VeilResourceUsage.INDEX;
            case "indirect" -> VeilResourceUsage.INDIRECT;
            default -> throw new IllegalArgumentException("Unsupported resource usage: " + name);
        };
    }

    public static void validateDimensionDependencies(Map<String, Resource> resources) {
        for (Resource resource : resources.values()) {
            var visited = new LinkedHashSet<String>();
            Resource current = resource;
            while (current.sizeFrom() != null) {
                if (!visited.add(current.name()))
                    throw new IllegalArgumentException(
                            "Cyclic resource dimensions: " + resource.name());
                Resource next = resources.get(current.sizeFrom());
                if (next == null
                        || next.kind() != VeilRenderGraph.Kind.IMAGE
                        || next.hostImport()) {
                    throw new IllegalArgumentException(
                            "Derived dimensions require an owned image: " + current.sizeFrom());
                }
                current = next;
            }
        }
    }
}
