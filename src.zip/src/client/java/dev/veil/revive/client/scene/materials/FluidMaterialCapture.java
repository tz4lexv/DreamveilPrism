package dev.veil.revive.client.scene.materials;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.veil.revive.client.VeilMaterialIds;
import dev.veil.revive.client.VeilMaterialRange;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.material.FluidState;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public final class FluidMaterialCapture {
    private static final ThreadLocal<SectionCapture> SECTION = new ThreadLocal<>();
    private static final ThreadLocal<ArrayDeque<FluidCapture>> FLUID_STACK =
            ThreadLocal.withInitial(ArrayDeque::new);
    private static final ThreadLocal<ArrayDeque<FluidCapture>> FREE_CAPTURES =
            ThreadLocal.withInitial(ArrayDeque::new);
    private static final ChunkSectionLayer[] LAYERS = ChunkSectionLayer.values();
    private static final AtomicLong RESOLVED_GROUPS = new AtomicLong();
    private static final AtomicLong UNRESOLVED_GROUPS = new AtomicLong();

    private FluidMaterialCapture() {}

    public static void beginSectionCompile() {
        SECTION.set(new SectionCapture());
        FLUID_STACK.get().clear();
    }

    public static VeilMaterialRange[] endSectionCompile(SectionCompiler.Results results) {
        ArrayDeque<FluidCapture> stack = FLUID_STACK.get();
        while (!stack.isEmpty()) {
            FluidCapture fluid = stack.pop();
            finishFluid(fluid);
            recycle(fluid);
        }

        SectionCapture section = SECTION.get();
        SECTION.remove();
        if (section == null || results == null || section.pending.isEmpty()) {
            return new VeilMaterialRange[0];
        }
        return section.resolve(results);
    }

    public static void beginFluid(FluidState state) {
        if (SECTION.get() == null || state == null || state.isEmpty()) return;
        int materialId =
                state.is(FluidTags.WATER)
                        ? VeilMaterialIds.WATER
                        : state.is(FluidTags.LAVA)
                                ? VeilMaterialIds.LAVA
                                : VeilMaterialIds.OTHER_FLUID;
        beginMaterial(materialId);
    }

    public static void beginMaterial(int materialId) {
        if (SECTION.get() == null) return;
        if (materialId < 1 || materialId > 255)
            throw new IllegalArgumentException("Fluid material id");
        FluidCapture fluid = FREE_CAPTURES.get().pollFirst();
        if (fluid == null) fluid = new FluidCapture();
        fluid.reset(materialId);
        FLUID_STACK.get().push(fluid);
    }

    public static VertexConsumer wrapBuilder(ChunkSectionLayer layer, VertexConsumer consumer) {
        if (consumer == null || layer == null) return consumer;
        if (consumer instanceof CapturingVertexConsumer) return consumer;
        FluidCapture fluid = FLUID_STACK.get().peek();
        if (fluid == null) return consumer;
        LayerCapture capture = fluid.layers[layer.ordinal()];
        if (capture == null) fluid.layers[layer.ordinal()] = capture = new LayerCapture(layer);
        return new CapturingVertexConsumer(consumer, capture);
    }

    public static void endFluid() {
        ArrayDeque<FluidCapture> stack = FLUID_STACK.get();
        FluidCapture fluid = stack.poll();
        if (fluid == null) return;
        finishFluid(fluid);
        recycle(fluid);
    }

    private static void recycle(FluidCapture fluid) {
        fluid.reset(0);
        ArrayDeque<FluidCapture> free = FREE_CAPTURES.get();
        if (free.size() < 8) free.addFirst(fluid);
    }

    private static void finishFluid(FluidCapture fluid) {
        SectionCapture section = SECTION.get();
        if (section == null) return;
        for (LayerCapture capture : fluid.layers) {
            if (capture == null || capture.vertexCount == 0) continue;

            if ((capture.vertexCount & 3) != 0) {
                UNRESOLVED_GROUPS.incrementAndGet();
                continue;
            }
            section.pending.add(
                    new PendingGeometry(
                            capture.layer, fluid.materialId, capture.positions.toArray()));
        }
    }

    public static long resolvedGroups() {
        return RESOLVED_GROUPS.get();
    }

    public static long unresolvedGroups() {
        return UNRESOLVED_GROUPS.get();
    }

    private static final class SectionCapture {
        final List<PendingGeometry> pending = new ArrayList<>();

        VeilMaterialRange[] resolve(SectionCompiler.Results results) {
            ArrayList<VeilMaterialRange> ranges = new ArrayList<>();
            int[] cursors = new int[LAYERS.length];

            for (PendingGeometry geometry : pending) {
                var mesh = results.renderedLayers.get(geometry.layer);
                if (mesh == null || geometry.positions.length == 0) {
                    UNRESOLVED_GROUPS.incrementAndGet();
                    continue;
                }
                var drawState = mesh.drawState();

                if (!drawState.format().equals(DefaultVertexFormat.BLOCK)) {
                    UNRESOLVED_GROUPS.incrementAndGet();
                    continue;
                }

                ByteBuffer vertices =
                        mesh.vertexBuffer().duplicate().order(ByteOrder.nativeOrder());
                int stride = drawState.format().getVertexSize();
                int totalVertices = drawState.vertexCount();
                int expectedVertices = geometry.positions.length / 3;
                int layerIndex = geometry.layer.ordinal();
                int cursor = cursors[layerIndex];
                int firstVertex =
                        findSequence(vertices, stride, totalVertices, geometry.positions, cursor);
                if (firstVertex < 0 && cursor != 0) {

                    firstVertex =
                            findSequence(vertices, stride, totalVertices, geometry.positions, 0);
                }
                if (firstVertex < 0 || (firstVertex & 3) != 0 || (expectedVertices & 3) != 0) {
                    UNRESOLVED_GROUPS.incrementAndGet();
                    continue;
                }

                VeilMaterialRange range =
                        new VeilMaterialRange(
                                geometry.layer, firstVertex, expectedVertices, geometry.materialId);
                addMerged(ranges, range);
                cursors[layerIndex] = firstVertex + expectedVertices;
                RESOLVED_GROUPS.incrementAndGet();
            }
            return ranges.toArray(VeilMaterialRange[]::new);
        }

        private static void addMerged(
                ArrayList<VeilMaterialRange> ranges, VeilMaterialRange range) {
            int n = ranges.size();
            if (n != 0) {
                VeilMaterialRange previous = ranges.get(n - 1);
                if (previous.layer() == range.layer()
                        && previous.materialId() == range.materialId()
                        && previous.firstVertex() + previous.vertexCount() == range.firstVertex()) {
                    ranges.set(
                            n - 1,
                            new VeilMaterialRange(
                                    previous.layer(),
                                    previous.firstVertex(),
                                    previous.vertexCount() + range.vertexCount(),
                                    previous.materialId()));
                    return;
                }
            }
            ranges.add(range);
        }
    }

    private static int findSequence(
            ByteBuffer vertices, int stride, int totalVertices, float[] expected, int startVertex) {
        int count = expected.length / 3;
        if (count <= 0 || count > totalVertices) return -1;
        int start = Math.max(0, startVertex);

        start = (start + 3) & ~3;
        int last = totalVertices - count;
        for (int candidate = start; candidate <= last; candidate += 4) {
            if (!positionEquals(vertices, stride, candidate, expected, 0)) continue;
            boolean match = true;
            for (int i = 1; i < count; ++i) {
                if (!positionEquals(vertices, stride, candidate + i, expected, i * 3)) {
                    match = false;
                    break;
                }
            }
            if (match) return candidate;
        }
        return -1;
    }

    private static boolean positionEquals(
            ByteBuffer vertices, int stride, int vertex, float[] expected, int expectedOffset) {
        int base = vertex * stride;
        float x = vertices.getFloat(base);
        float y = vertices.getFloat(base + 4);
        float z = vertices.getFloat(base + 8);

        return Math.abs(x - expected[expectedOffset]) <= 1.0e-6f
                && Math.abs(y - expected[expectedOffset + 1]) <= 1.0e-6f
                && Math.abs(z - expected[expectedOffset + 2]) <= 1.0e-6f;
    }

    private static final class FluidCapture {
        int materialId;
        final LayerCapture[] layers = new LayerCapture[LAYERS.length];

        void reset(int materialId) {
            this.materialId = materialId;
            for (LayerCapture layer : layers) {
                if (layer == null) continue;
                layer.vertexCount = 0;
                layer.positions.reset();
            }
        }
    }

    private static final class LayerCapture {
        final ChunkSectionLayer layer;
        final FloatBuilder positions = new FloatBuilder();
        int vertexCount;

        LayerCapture(ChunkSectionLayer layer) {
            this.layer = layer;
        }

        void vertex(float x, float y, float z) {
            positions.add(x);
            positions.add(y);
            positions.add(z);
            vertexCount++;
        }
    }

    private record PendingGeometry(ChunkSectionLayer layer, int materialId, float[] positions) {}

    private static final class FloatBuilder {
        private float[] values = new float[96];
        private int size;

        void reset() {
            size = 0;
            if (values.length > 4096) values = new float[96];
        }

        void add(float value) {
            if (size == values.length) {
                float[] grown = new float[values.length << 1];
                System.arraycopy(values, 0, grown, 0, values.length);
                values = grown;
            }
            values[size++] = value;
        }

        float[] toArray() {
            float[] out = new float[size];
            System.arraycopy(values, 0, out, 0, size);
            return out;
        }
    }

    private static final class CapturingVertexConsumer implements VertexConsumer {
        private final VertexConsumer delegate;
        private final LayerCapture capture;

        CapturingVertexConsumer(VertexConsumer delegate, LayerCapture capture) {
            this.delegate = delegate;
            this.capture = capture;
        }

        @Override
        public VertexConsumer addVertex(float x, float y, float z) {
            capture.vertex(x, y, z);
            delegate.addVertex(x, y, z);
            return this;
        }

        @Override
        public void addVertex(
                float x,
                float y,
                float z,
                int color,
                float u,
                float v,
                int overlayCoords,
                int lightCoords,
                float nx,
                float ny,
                float nz) {
            capture.vertex(x, y, z);
            delegate.addVertex(x, y, z, color, u, v, overlayCoords, lightCoords, nx, ny, nz);
        }

        @Override
        public VertexConsumer setColor(int r, int g, int b, int a) {
            delegate.setColor(r, g, b, a);
            return this;
        }

        @Override
        public VertexConsumer setColor(int color) {
            delegate.setColor(color);
            return this;
        }

        @Override
        public VertexConsumer setUv(float u, float v) {
            delegate.setUv(u, v);
            return this;
        }

        @Override
        public VertexConsumer setUv1(int u, int v) {
            delegate.setUv1(u, v);
            return this;
        }

        @Override
        public VertexConsumer setUv2(int u, int v) {
            delegate.setUv2(u, v);
            return this;
        }

        @Override
        public VertexConsumer setNormal(float x, float y, float z) {
            delegate.setNormal(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer setLineWidth(float width) {
            delegate.setLineWidth(width);
            return this;
        }
    }
}
