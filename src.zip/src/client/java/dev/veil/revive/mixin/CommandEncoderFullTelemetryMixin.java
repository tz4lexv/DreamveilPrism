package dev.veil.revive.mixin;

import com.mojang.blaze3d.systems.CommandEncoder;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CommandEncoder.class)
public abstract class CommandEncoderFullTelemetryMixin {
    @Inject(method = "submit", at = @At("HEAD"), require = 0)
    private void veil$submitStart(CallbackInfo ci) {
        VeilFullFrameTelemetry.commandSubmitStart();
    }

    @Inject(method = "submit", at = @At("RETURN"), require = 0)
    private void veil$submitEnd(CallbackInfo ci) {
        VeilFullFrameTelemetry.commandSubmitEnd();
    }
}
