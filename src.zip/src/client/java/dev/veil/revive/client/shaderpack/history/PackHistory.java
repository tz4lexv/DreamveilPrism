package dev.veil.revive.client.shaderpack.history;

public final class PackHistory<C> {
    private final boolean available;
    private final int warmup;
    private boolean valid;
    private boolean cameraValid;
    private C previousCamera;
    private long completedFrames;
    private long resetFrame;

    public PackHistory(boolean available, int warmup) {
        this.available = available;
        this.warmup = warmup;
    }

    public void invalidate() {
        valid = false;
        cameraValid = false;
        resetFrame = completedFrames;
    }

    public void completeFrame(long completedFrames) {
        if (completedFrames < this.completedFrames) resetFrame = 0;
        this.completedFrames = completedFrames;
        valid = available && completedFrames - resetFrame >= warmup;
    }

    public void completeCamera(C camera) {
        previousCamera = camera;
        cameraValid = true;
    }

    public boolean valid() {
        return valid;
    }

    public boolean cameraValid() {
        return cameraValid;
    }

    public C previousCamera() {
        return previousCamera;
    }
}
