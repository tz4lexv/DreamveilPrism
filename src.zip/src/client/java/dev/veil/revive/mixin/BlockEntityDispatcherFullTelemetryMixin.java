package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityDispatcherFullTelemetryMixin {
    @Inject(method = "tryExtractRenderState", at = @At("HEAD"), require = 0)
    private void veil$extractStart(CallbackInfoReturnable<?> cir) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.BLOCK_ENTITY_EXTRACT);
    }

    @Inject(method = "tryExtractRenderState", at = @At("RETURN"), require = 0)
    private void veil$extractEnd(CallbackInfoReturnable<?> cir) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.BLOCK_ENTITY_EXTRACT);
        if (cir.getReturnValue() != null)
            VeilFullFrameTelemetry.addLoad(
                    VeilFullFrameTelemetry.LoadCounter.BLOCK_ENTITY_STATES, 1L);
    }

    @Inject(method = "submit", at = @At("HEAD"), require = 0)
    private void veil$submitStart(CallbackInfo ci) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.BLOCK_ENTITY_SUBMIT);
    }

    @Inject(method = "submit", at = @At("RETURN"), require = 0)
    private void veil$submitEnd(CallbackInfo ci) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.BLOCK_ENTITY_SUBMIT);
    }
}
