package dev.veil.revive.client;

import jdk.jfr.Category;
import jdk.jfr.Event;
import jdk.jfr.EventType;
import jdk.jfr.Name;
import jdk.jfr.StackTrace;

import java.util.IdentityHashMap;

public final class VeilGpuAllocationJfrProbe {
    public static final boolean ENABLED = Boolean.getBoolean("veil.gpuAllocationJfrEvents");
    private static final EventType TYPE =
            ENABLED ? EventType.getEventType(AllocationEvent.class) : null;
    private static final IdentityHashMap<Object, Arena> ARENAS =
            ENABLED ? new IdentityHashMap<>() : null;
    private static final int LIMIT =
            Math.max(1, Integer.getInteger("veil.gpuAllocationJfrLimit", 262144));
    private static long sequence, nextArena, nextAllocation;
    private static int live;
    private static boolean overflow;

    private VeilGpuAllocationJfrProbe() {}

    public static void allocated(
            Object arena,
            Object allocation,
            String route,
            long requested,
            long reserved,
            long offset,
            int alignment,
            int heap,
            long capacity) {
        if (ENABLED)
            allocation(
                    arena,
                    allocation,
                    route,
                    requested,
                    reserved,
                    offset,
                    alignment,
                    heap,
                    capacity);
    }

    private static synchronized void allocation(
            Object key,
            Object allocation,
            String route,
            long requested,
            long reserved,
            long offset,
            int alignment,
            int heap,
            long capacity) {
        if (!active()) return;
        var arena = ARENAS.get(key);
        if (arena == null) {
            if (ARENAS.size() >= 4096) {
                exhausted();
                return;
            }
            arena = new Arena(++nextArena, route);
            ARENAS.put(key, arena);
        }
        if (allocation == null) {
            emit("REJECT", arena, null, requested, 0, 0, alignment, heap, capacity, 0);
            return;
        }
        if (live >= LIMIT || arena.allocations.containsKey(allocation)) {
            exhausted();
            return;
        }
        var state =
                new Reservation(
                        ++nextAllocation, requested, reserved, offset, alignment, heap, capacity);
        arena.allocations.put(allocation, state);
        live++;
        emit("ALLOC", arena, state, requested, reserved, offset, alignment, heap, capacity, 0);
    }

    public static void freed(Object arena, Object allocation) {
        if (ENABLED) release(arena, allocation);
    }

    private static synchronized void release(Object key, Object allocation) {
        if (!active()) return;
        var arena = ARENAS.get(key);
        var state = arena == null ? null : arena.allocations.remove(allocation);
        if (state == null) {
            emit("UNKNOWN_FREE", arena, null, 0, 0, 0, 0, 0, 0, 0);
            return;
        }
        live--;
        emit(
                "FREE",
                arena,
                state,
                state.requested,
                state.reserved,
                state.offset,
                state.alignment,
                state.heap,
                state.capacity,
                System.nanoTime() - state.created);
    }

    public static void moved(Object arena, Object allocation, long offset, int heap) {
        if (ENABLED) relocation(arena, allocation, offset, heap);
    }

    private static synchronized void relocation(
            Object key, Object allocation, long offset, int heap) {
        if (!active()) return;
        var arena = ARENAS.get(key);
        var state = arena == null ? null : arena.allocations.get(allocation);
        if (state == null) {
            emit("UNKNOWN_MOVE", arena, null, 0, 0, offset, 0, heap, 0, 0);
            return;
        }
        state.offset = offset;
        state.heap = heap;
        emit(
                "MOVE",
                arena,
                state,
                state.requested,
                state.reserved,
                offset,
                state.alignment,
                heap,
                state.capacity,
                System.nanoTime() - state.created);
    }

    public static void closed(Object arena) {
        if (ENABLED) close(arena);
    }

    private static synchronized void close(Object key) {
        if (!active()) return;
        var arena = ARENAS.remove(key);
        if (arena == null) return;
        live -= arena.allocations.size();
        emit("CLOSE", arena, null, 0, 0, 0, 0, 0, 0, 0);
    }

    private static boolean active() {
        if (TYPE.isEnabled()) return !overflow;
        ARENAS.clear();
        live = 0;
        overflow = false;
        return false;
    }

    private static void exhausted() {
        overflow = true;
        emit("OVERFLOW", null, null, 0, 0, 0, 0, 0, 0, 0);
        ARENAS.clear();
        live = 0;
    }

    private static void emit(
            String action,
            Arena arena,
            Reservation state,
            long requested,
            long reserved,
            long offset,
            int alignment,
            int heap,
            long capacity,
            long lifetime) {
        var event = new AllocationEvent();
        event.sequence = ++sequence;
        event.action = action;
        event.route = arena == null ? "UNKNOWN" : arena.route;
        event.allocatorId = arena == null ? 0 : arena.id;
        event.allocationId = state == null ? 0 : state.id;
        event.requestedBytes = requested;
        event.reservedBytes = reserved;
        event.offsetBytes = offset;
        event.alignmentBytes = alignment;
        event.heapIndex = heap;
        event.heapCapacityBytes = capacity;
        event.lifetimeNanos = lifetime;
        event.logicalNanos = System.nanoTime();
        event.commit();
    }

    private static final class Arena {
        final long id;
        final String route;
        final IdentityHashMap<Object, Reservation> allocations = new IdentityHashMap<>();

        Arena(long id, String route) {
            this.id = id;
            this.route = route;
        }
    }

    private static final class Reservation {
        final long id, requested, reserved, capacity, created = System.nanoTime();
        final int alignment;
        long offset;
        int heap;

        Reservation(
                long id,
                long requested,
                long reserved,
                long offset,
                int alignment,
                int heap,
                long capacity) {
            this.id = id;
            this.requested = requested;
            this.reserved = reserved;
            this.offset = offset;
            this.alignment = alignment;
            this.heap = heap;
            this.capacity = capacity;
        }
    }

    @Name("dev.veil.GpuAllocation")
    @Category({"Veil", "Diagnostics"})
    @StackTrace(false)
    static final class AllocationEvent extends Event {
        public long sequence, allocatorId, allocationId, requestedBytes, reservedBytes, offsetBytes;
        public long heapCapacityBytes, lifetimeNanos, logicalNanos;
        public int alignmentBytes, heapIndex;
        public String action, route;
    }
}
