package dev.veil.revive.client;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.QuadInstance;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.resources.model.geometry.BakedQuad;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Consumer;

public final class VeilTerrainQuadWriter {
    private static final boolean REQUESTED = Boolean.getBoolean("veil.terrainQuadWriter");
    private static final boolean VERIFY =
            Boolean.getBoolean("veil.verifyTerrainQuadWriter")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final LongAdder EMITTED = new LongAdder(), VERIFIED = new LongAdder();
    private static final ThreadLocal<ByteBuffer> SCRATCH =
            ThreadLocal.withInitial(
                    () -> ByteBuffer.allocateDirect(112).order(ByteOrder.nativeOrder()));

    private VeilTerrainQuadWriter() {}

    static void requireComplete() {
        if (!REQUESTED) return;
        if (EMITTED.sum() == 0 || VERIFY && VERIFIED.sum() < 100000)
            throw new IllegalStateException(
                    "Terrain quad writer incomplete: emitted="
                            + EMITTED.sum()
                            + " verified="
                            + VERIFIED.sum());
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil terrain quad writer: PASS (emitted_vertices={} verified_vertices={})",
                EMITTED.sum(),
                VERIFIED.sum());
    }

    public static boolean emit(
            BufferBuilder target,
            float x,
            float y,
            float z,
            BakedQuad quad,
            QuadInstance instance) {
        var bytes = scratchFor(target);
        if (bytes == null) return false;
        encode(bytes, x, y, z, quad, instance);
        if (verifyingNeeded())
            verify(bytes, reference -> reference.putBlockBakedQuad(x, y, z, quad, instance));
        push(target, bytes);
        return true;
    }

    public static ByteBuffer scratchFor(VertexConsumer target) {
        if (!REQUESTED || !ReviveRuntime.optimizationsEnabled()) return null;
        var writer = VeilVertexBufferWriter.tryOf(target);
        return writer != null && writer.veil$canPush(DefaultVertexFormat.BLOCK)
                ? SCRATCH.get()
                : null;
    }

    public static boolean verifyingNeeded() {
        return VERIFY && VERIFIED.sum() < 100000;
    }

    public static void verify(ByteBuffer bytes, Consumer<BufferBuilder> writeReference) {
        try (var storage = new ByteBufferBuilder(112)) {
            var reference =
                    new BufferBuilder(storage, PrimitiveTopology.QUADS, DefaultVertexFormat.BLOCK);
            writeReference.accept(reference);
            try (var mesh = reference.buildOrThrow()) {
                if (mesh.drawState().vertexCount() != 4)
                    throw new IllegalStateException("Quad oracle vertex count changed");
                var expected = mesh.vertexBuffer();
                for (int b = 0; b < 112; b++)
                    if (bytes.get(b) != expected.get(b))
                        throw new IllegalStateException(
                                "Native terrain quad writer differs at byte " + b);
            }
        }
        VERIFIED.add(4);
    }

    public static void push(VertexConsumer target, ByteBuffer bytes) {
        var writer = VeilVertexBufferWriter.tryOf(target);
        if (writer == null) throw new IllegalStateException("Missing bulk quad target");
        writer.veil$push(MemoryUtil.memAddress(bytes), 4, DefaultVertexFormat.BLOCK);
        if (VERIFY || VeilTechniqueCounters.collecting()) EMITTED.add(4);
    }

    public static void putVertex(
            ByteBuffer output,
            int at,
            float x,
            float y,
            float z,
            int argb,
            float u,
            float v,
            int light) {
        dev.veil.revive.client.terrain.meshing.BlockQuadEncoder.putVertex(
                output, at, x, y, z, argb, u, v, light);
    }

    static void encode(
            ByteBuffer output, float x, float y, float z, BakedQuad quad, QuadInstance instance) {
        dev.veil.revive.client.terrain.meshing.BlockQuadEncoder.encode(
                output, x, y, z, quad, instance);
    }
}
