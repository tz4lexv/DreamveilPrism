package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.terrain.SparseUploadPlanner;

import net.minecraft.client.renderer.DynamicUniforms;
import net.minecraft.client.renderer.MappableRingBuffer;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.BitSet;
import java.util.IdentityHashMap;

final class VeilSectionTable {
    private static final int ENTRY_BYTES = 4 * Integer.BYTES;
    private static final int MIN_CAPACITY = 1024;
    static final GpuFormat FORMAT = GpuFormat.RGBA32_SINT;

    private static GpuBuffer buffer;
    private static MappableRingBuffer uploadRing;
    private static GpuBuffer uploadBuffer;
    private static GpuBufferSlice.MappedView uploadMapping;
    private static ByteBuffer uploadBytes;
    private static int capacity;
    private static boolean zeroCopy;
    private static boolean ownsDestination;
    private static int entries;
    private static boolean forceFullUpload;

    private static final int MAX_DIRTY_HISTORY = 128;
    private static final IdentityHashMap<GpuBuffer, Long> UMA_SLOT_GENERATIONS =
            new IdentityHashMap<>();
    private static final ArrayDeque<DirtySpan> UMA_DIRTY_HISTORY = new ArrayDeque<>();
    private static final BitSet UMA_DIRTY_BITS = new BitSet();
    private static long tableGeneration;

    private static long uploads;
    private static long fullUploads;
    private static long partialUploads;
    private static long skippedUploads;
    private static long bytesUploaded;
    private static long bytesAvoided;
    private static long dirtyEntriesUploaded;
    private static long umaReplayRanges;
    private static long umaFullCatchups;
    private static long deferredFrames;
    private static final BitSet COPY_DIRTY_BITS = new BitSet();
    private static final SparseUploadPlanner COPY_RANGES = new SparseUploadPlanner(8, 16);
    private static long sparseCopyRanges, sparseFallbacks, sparseBytesSaved;
    private static final boolean SPARSE_UPLOADS = Boolean.getBoolean("veil.sparseSectionUploads");

    private VeilSectionTable() {}

    static void deferUntilNeeded() {
        if (!forceFullUpload) forceFullUpload = true;
        if (VeilTechniqueCounters.collecting()) deferredFrames++;
    }

    static void update(VeilTerrainFrameData sections) {
        int logicalEntries = sections.count();
        int required = Math.max(1, logicalEntries);
        int previousEntries = entries;
        ensureCapacity(required);
        entries = logicalEntries;

        int dirtyFirst;
        int dirtyLast;
        if (forceFullUpload) {
            dirtyFirst = 0;
            dirtyLast = required - 1;
        } else if (sections.hasDirtyEntries()) {
            dirtyFirst = sections.dirtyFirst();
            dirtyLast = sections.dirtyLast();
        } else {
            dirtyFirst = required;
            dirtyLast = -1;
        }

        if (!forceFullUpload && logicalEntries > previousEntries) {
            int growFirst = Math.max(0, previousEntries);
            dirtyFirst = dirtyLast >= dirtyFirst ? Math.min(dirtyFirst, growFirst) : growFirst;
            dirtyLast = Math.max(dirtyLast, required - 1);
        }

        if (dirtyLast < dirtyFirst) {
            skippedUploads++;
            bytesAvoided += (long) required * ENTRY_BYTES;
            return;
        }

        if (zeroCopy) {

            if (uploadMapping == null) {
                uploadRing.rotate();
                remapUploadRing();
            }
            long generation = ++tableGeneration;
            recordDirtySpan(generation, dirtyFirst, dirtyLast, forceFullUpload);
            Long slotGeneration = UMA_SLOT_GENERATIONS.get(uploadBuffer);
            boolean full =
                    forceFullUpload || slotGeneration == null || !canReplayFrom(slotGeneration);
            long writtenEntries = 0L;

            if (!full) {
                UMA_DIRTY_BITS.clear();
                for (DirtySpan span : UMA_DIRTY_HISTORY) {
                    if (span.generation <= slotGeneration) continue;
                    if (span.full) {
                        full = true;
                        break;
                    }
                    int first = Math.max(0, span.first);
                    int last = Math.min(required - 1, span.last);
                    if (last >= first) UMA_DIRTY_BITS.set(first, last + 1);
                }
            }

            if (full) {
                writeRange(uploadBytes, sections, 0, required - 1);
                writtenEntries = required;
                fullUploads++;
                if (!forceFullUpload) umaFullCatchups++;
            } else {
                int first = UMA_DIRTY_BITS.nextSetBit(0);
                while (first >= 0 && first < required) {
                    int endExclusive = Math.min(required, UMA_DIRTY_BITS.nextClearBit(first));
                    writeRange(uploadBytes, sections, first, endExclusive - 1);
                    writtenEntries += endExclusive - first;
                    umaReplayRanges++;
                    first = UMA_DIRTY_BITS.nextSetBit(endExclusive);
                }
                partialUploads++;
            }

            uploadMapping.close();
            uploadMapping = null;
            uploadBytes = null;
            buffer = uploadBuffer;
            UMA_SLOT_GENERATIONS.put(buffer, generation);

            long bytes = writtenEntries * ENTRY_BYTES;
            bytesUploaded += bytes;
            dirtyEntriesUploaded += writtenEntries;
            bytesAvoided += Math.max(0L, (long) required * ENTRY_BYTES - bytes);
        } else if (!SPARSE_UPLOADS) {
            writeRange(uploadBytes, sections, dirtyFirst, dirtyLast);
            long offset = (long) dirtyFirst * ENTRY_BYTES;
            long bytes = (long) (dirtyLast - dirtyFirst + 1) * ENTRY_BYTES;
            RenderSystem.getDevice()
                    .createCommandEncoder()
                    .copyToBuffer(uploadBuffer.slice(offset, bytes), buffer.slice(offset, bytes));
            rotateUploadRing();
            bytesUploaded += bytes;
            dirtyEntriesUploaded += dirtyLast - dirtyFirst + 1L;
            if (dirtyFirst == 0 && dirtyLast == required - 1) fullUploads++;
            else partialUploads++;
            bytesAvoided += (long) required * ENTRY_BYTES - bytes;
        } else {
            COPY_DIRTY_BITS.clear();
            if (forceFullUpload) COPY_DIRTY_BITS.set(dirtyFirst, dirtyLast + 1);
            else {
                COPY_DIRTY_BITS.or(sections.dirtyEntries());
                if (logicalEntries > previousEntries)
                    COPY_DIRTY_BITS.set(Math.max(0, previousEntries), required);
            }
            COPY_RANGES.plan(COPY_DIRTY_BITS, required);
            var encoder = RenderSystem.getDevice().createCommandEncoder();
            for (int range = 0; range < COPY_RANGES.count(); range++) {
                int first = COPY_RANGES.first(range), last = COPY_RANGES.last(range);
                writeRange(uploadBytes, sections, first, last);
            }
            VeilBufferTransferBatch.copySectionTable(
                    encoder, uploadBuffer, buffer, COPY_RANGES, ENTRY_BYTES);
            long bytes = (long) COPY_RANGES.entries() * ENTRY_BYTES;
            sparseCopyRanges += COPY_RANGES.count();
            if (COPY_RANGES.fallback()) sparseFallbacks++;
            sparseBytesSaved += (long) (dirtyLast - dirtyFirst + 1) * ENTRY_BYTES - bytes;
            rotateUploadRing();

            bytesUploaded += bytes;
            dirtyEntriesUploaded += COPY_RANGES.entries();
            if (COPY_RANGES.entries() == required) fullUploads++;
            else partialUploads++;
            bytesAvoided += (long) required * ENTRY_BYTES - bytes;
        }

        forceFullUpload = false;
        uploads++;
    }

    private static void recordDirtySpan(long generation, int first, int last, boolean full) {
        UMA_DIRTY_HISTORY.addLast(new DirtySpan(generation, first, last, full));
        while (UMA_DIRTY_HISTORY.size() > MAX_DIRTY_HISTORY) UMA_DIRTY_HISTORY.removeFirst();
    }

    private static boolean canReplayFrom(long slotGeneration) {
        DirtySpan oldest = UMA_DIRTY_HISTORY.peekFirst();
        return oldest != null && slotGeneration >= oldest.generation - 1L;
    }

    private static void writeRange(
            ByteBuffer out, VeilTerrainFrameData sections, int first, int last) {
        int logicalEntries = sections.count();
        for (int i = first; i <= last; i++) {
            int dst = i * ENTRY_BYTES;
            if (i >= logicalEntries) {
                out.putInt(dst, 0);
                out.putInt(dst + 4, 0);
                out.putInt(dst + 8, 0);
                out.putInt(dst + 12, Float.floatToRawIntBits(1.0f));
            } else {
                out.putInt(dst, sections.x(i));
                out.putInt(dst + 4, sections.y(i));
                out.putInt(dst + 8, sections.z(i));
                out.putInt(dst + 12, Float.floatToRawIntBits(sections.visibility(i)));
            }
        }
    }

    static void writeEntries(
            ByteBuffer out, DynamicUniforms.ChunkSectionInfo[] sections, int required) {
        for (int i = 0; i < required; i++) {
            DynamicUniforms.ChunkSectionInfo info = i < sections.length ? sections[i] : null;
            int base = i * ENTRY_BYTES;
            if (info == null) {
                out.putInt(base, 0);
                out.putInt(base + 4, 0);
                out.putInt(base + 8, 0);
                out.putInt(base + 12, Float.floatToRawIntBits(1.0f));
            } else {
                out.putInt(base, info.x());
                out.putInt(base + 4, info.y());
                out.putInt(base + 8, info.z());
                out.putInt(base + 12, Float.floatToRawIntBits(info.visibility()));
            }
        }
    }

    private static void ensureCapacity(int required) {
        if (buffer != null && required <= capacity) return;
        int next = Math.max(MIN_CAPACITY, Integer.highestOneBit(required - 1) << 1);
        if (next <= 0) next = required;
        closeBuffers();
        int bytes = Math.multiplyExact(next, ENTRY_BYTES);
        var info = RenderSystem.getDevice().getDeviceInfo();
        zeroCopy =
                info.type() == com.mojang.blaze3d.systems.DeviceType.INTEGRATED
                        && info.features().persistentMapping();
        if (zeroCopy) {
            uploadRing =
                    new MappableRingBuffer(
                            () -> "Veil UMA zero-copy section table",
                            GpuBuffer.USAGE_MAP_WRITE
                                    | GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER
                                    | VeilHzb.STORAGE_USAGE,
                            bytes);
            ownsDestination = false;
        } else {
            buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil global section table",
                                    GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER
                                            | GpuBuffer.USAGE_COPY_DST
                                            | VeilHzb.STORAGE_USAGE,
                                    bytes);
            ownsDestination = true;
            uploadRing =
                    new MappableRingBuffer(
                            () -> "Veil section table upload ring",
                            GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                            bytes);
        }
        remapUploadRing();
        capacity = next;
        forceFullUpload = true;
    }

    static GpuBuffer buffer() {
        if (buffer == null)
            throw new IllegalStateException("Veil section table has not been uploaded");
        return buffer;
    }

    static GpuBufferSlice slice() {
        return buffer().slice(0, Math.max(1L, (long) entries * ENTRY_BYTES));
    }

    static int entries() {
        return entries;
    }

    private static void remapUploadRing() {
        uploadBuffer = uploadRing.currentBuffer();
        uploadMapping = uploadBuffer.map(false, true);
        uploadBytes = uploadMapping.data();
    }

    private static void rotateUploadRing() {
        uploadMapping.close();
        uploadMapping = null;
        uploadBytes = null;
        uploadRing.rotate();
        remapUploadRing();
    }

    private static void closeBuffers() {
        UMA_SLOT_GENERATIONS.clear();
        UMA_DIRTY_HISTORY.clear();
        UMA_DIRTY_BITS.clear();
        tableGeneration = 0L;
        if (uploadMapping != null) {
            uploadMapping.close();
            uploadMapping = null;
        }
        uploadBytes = null;
        uploadBuffer = null;
        if (ownsDestination && buffer != null) buffer.close();
        buffer = null;
        ownsDestination = false;
        if (uploadRing != null) {
            uploadRing.close();
            uploadRing = null;
        }
        zeroCopy = false;
        forceFullUpload = true;
    }

    static String telemetry() {
        return VeilBufferTransferBatch.telemetry()
                + "section_table_entries="
                + entries
                + "\nsection_table_capacity="
                + capacity
                + "\nsection_table_uploads_total="
                + uploads
                + "\nsection_table_full_uploads_total="
                + fullUploads
                + "\nsection_table_partial_uploads_total="
                + partialUploads
                + "\nsection_table_skipped_uploads_total="
                + skippedUploads
                + "\nsection_table_dirty_entries_uploaded_total="
                + dirtyEntriesUploaded
                + "\nsection_table_bytes_total="
                + bytesUploaded
                + "\nsection_table_bytes_avoided_total="
                + bytesAvoided
                + "\nsection_table_sparse_copy_ranges_total="
                + sparseCopyRanges
                + "\nsection_table_sparse_fallbacks_total="
                + sparseFallbacks
                + "\nsection_table_sparse_bytes_saved_total="
                + sparseBytesSaved
                + "\nsection_table_uma_replay_ranges_total="
                + umaReplayRanges
                + "\nsection_table_uma_full_catchups_total="
                + umaFullCatchups
                + "\nsection_table_deferred_host_frames_total="
                + deferredFrames
                + "\nsection_table_persistent_upload_ring="
                + (uploadRing != null)
                + "\nsection_table_uma_zero_copy="
                + zeroCopy
                + "\n";
    }

    static void close() {
        closeBuffers();
        capacity = entries = 0;
    }

    private record DirtySpan(long generation, int first, int last, boolean full) {}
}
