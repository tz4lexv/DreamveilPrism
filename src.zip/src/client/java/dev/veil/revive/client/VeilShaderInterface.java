package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public record VeilShaderInterface(
        List<Descriptor> descriptors,
        List<PushConstant> pushConstants,
        List<StageIo> stageInputs,
        List<StageIo> stageOutputs,
        List<SpecializationConstant> specializationConstants) {

    public record ImageType(
            int dimension,
            boolean arrayed,
            boolean multisampled,
            boolean depth,
            int sampledBaseType,
            int storageFormat) {}

    public record Descriptor(
            int set,
            int binding,
            int descriptorType,
            int descriptorCount,
            boolean runtimeArray,
            int stageFlags,
            String name,
            boolean readable,
            boolean writable,
            long minimumBufferSize,
            ImageType imageType) {
        public Descriptor(
                int set,
                int binding,
                int descriptorType,
                int descriptorCount,
                boolean runtimeArray,
                int stageFlags,
                String name) {
            this(
                    set,
                    binding,
                    descriptorType,
                    descriptorCount,
                    runtimeArray,
                    stageFlags,
                    name,
                    true,
                    descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_BUFFER
                            || descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE,
                    0,
                    null);
        }

        public Descriptor {
            if (set < 0) throw new IllegalArgumentException("set < 0");
            if (binding < 0) throw new IllegalArgumentException("binding < 0");
            if (descriptorCount <= 0) throw new IllegalArgumentException("descriptorCount <= 0");
            name = name == null ? "" : name;
        }
    }

    public record BlockMember(
            int offset,
            int baseType,
            int bitWidth,
            int vectorSize,
            int columns,
            int arrayElements) {}

    public record PushConstant(
            int offset, int size, int stageFlags, String name, List<BlockMember> members) {
        public PushConstant(int offset, int size, int stageFlags, String name) {
            this(offset, size, stageFlags, name, List.of());
        }

        public PushConstant {
            members = List.copyOf(members);
            if (offset < 0 || size <= 0 || (offset & 3) != 0 || (size & 3) != 0) {
                throw new IllegalArgumentException(
                        "Push constant offset/size must be positive 4-byte aligned values");
            }
            name = name == null ? "" : name;
        }
    }

    public record StageIo(
            int location,
            int component,
            int baseType,
            int bitWidth,
            int vectorSize,
            int columns,
            int arrayElements,
            int stageFlags,
            String name) {
        public StageIo {
            if (location < 0) throw new IllegalArgumentException("location < 0");
            if (component < 0 || component > 3)
                throw new IllegalArgumentException("component must be in [0,3]");
            if (bitWidth <= 0
                    || vectorSize <= 0
                    || vectorSize > 4
                    || columns <= 0
                    || arrayElements <= 0) {
                throw new IllegalArgumentException("Invalid reflected stage IO type");
            }
            name = name == null ? "" : name;
        }
    }

    public record SpecializationConstant(
            int spirvId, int constantId, int stageFlags, String name, int baseType, int bitWidth) {
        public SpecializationConstant(int spirvId, int constantId, int stageFlags, String name) {
            this(spirvId, constantId, stageFlags, name, 0, 0);
        }

        public SpecializationConstant {
            if (spirvId <= 0) throw new IllegalArgumentException("spirvId <= 0");
            if (constantId < 0) throw new IllegalArgumentException("constantId < 0");
            if (bitWidth < 0) throw new IllegalArgumentException("bitWidth < 0");
            name = name == null ? "" : name;
        }
    }

    public VeilShaderInterface {
        descriptors = List.copyOf(descriptors);
        pushConstants = List.copyOf(pushConstants);
        stageInputs = List.copyOf(stageInputs);
        stageOutputs = List.copyOf(stageOutputs);
        specializationConstants = List.copyOf(specializationConstants);
    }

    public static VeilShaderInterface empty() {
        return new VeilShaderInterface(List.of(), List.of(), List.of(), List.of(), List.of());
    }

    public static VeilShaderInterface merge(VeilShaderInterface... interfaces) {
        Objects.requireNonNull(interfaces, "interfaces");
        Map<Long, Descriptor> descriptors = new LinkedHashMap<>();
        Map<Long, PushConstant> pushConstants = new LinkedHashMap<>();
        Map<Long, SpecializationConstant> specs = new LinkedHashMap<>();
        List<StageIo> inputs = new ArrayList<>();
        List<StageIo> outputs = new ArrayList<>();

        for (VeilShaderInterface shader : interfaces) {
            Objects.requireNonNull(shader, "shader interface");
            for (Descriptor next : shader.descriptors) {
                long key = ((long) next.set << 32) | (next.binding & 0xffffffffL);
                Descriptor old = descriptors.get(key);
                if (old == null) {
                    descriptors.put(key, next);
                } else {
                    if (old.descriptorType != next.descriptorType
                            || old.descriptorCount != next.descriptorCount
                            || old.runtimeArray != next.runtimeArray
                            || !Objects.equals(old.imageType, next.imageType)) {
                        throw new IllegalArgumentException(
                                "SPIR-V descriptor ABI mismatch at set="
                                        + next.set
                                        + " binding="
                                        + next.binding);
                    }
                    descriptors.put(
                            key,
                            new Descriptor(
                                    next.set,
                                    next.binding,
                                    next.descriptorType,
                                    next.descriptorCount,
                                    next.runtimeArray,
                                    old.stageFlags | next.stageFlags,
                                    !old.name.isEmpty() ? old.name : next.name,
                                    old.readable || next.readable,
                                    old.writable || next.writable,
                                    Math.max(old.minimumBufferSize, next.minimumBufferSize),
                                    old.imageType));
                }
            }
            for (PushConstant next : shader.pushConstants) {
                long key = ((long) next.offset << 32) | (next.size & 0xffffffffL);
                PushConstant old = pushConstants.get(key);
                if (old == null) {
                    pushConstants.put(key, next);
                } else {
                    if (!old.members.equals(next.members))
                        throw new IllegalArgumentException(
                                "Push constant ABI mismatch across stages");
                    pushConstants.put(
                            key,
                            new PushConstant(
                                    next.offset,
                                    next.size,
                                    old.stageFlags | next.stageFlags,
                                    !old.name.isEmpty() ? old.name : next.name,
                                    old.members));
                }
            }
            for (SpecializationConstant next : shader.specializationConstants) {
                long key = ((long) next.stageFlags << 32) | (next.constantId & 0xffffffffL);
                SpecializationConstant old = specs.get(key);
                if (old == null) {
                    specs.put(key, next);
                } else if (!old.equals(next)) {
                    throw new IllegalArgumentException(
                            "Duplicate specialization constant ID="
                                    + next.constantId
                                    + " stage="
                                    + next.stageFlags);
                }
            }
            inputs.addAll(shader.stageInputs);
            outputs.addAll(shader.stageOutputs);
        }

        var descriptorList = new ArrayList<>(descriptors.values());
        descriptorList.sort(
                Comparator.comparingInt(Descriptor::set).thenComparingInt(Descriptor::binding));
        var pushList = new ArrayList<>(pushConstants.values());
        pushList.sort(
                Comparator.comparingInt(PushConstant::offset).thenComparingInt(PushConstant::size));
        var specList = new ArrayList<>(specs.values());
        specList.sort(
                Comparator.comparingInt(SpecializationConstant::stageFlags)
                        .thenComparingInt(SpecializationConstant::constantId));
        inputs.sort(
                Comparator.comparingInt(StageIo::stageFlags).thenComparingInt(StageIo::location));
        outputs.sort(
                Comparator.comparingInt(StageIo::stageFlags).thenComparingInt(StageIo::location));

        return new VeilShaderInterface(descriptorList, pushList, inputs, outputs, specList);
    }

    public VeilShaderInterface resolveRuntimeDescriptorArrays(Map<Integer, Integer> set0Counts) {
        Objects.requireNonNull(set0Counts, "set0Counts");
        var resolved = new ArrayList<Descriptor>(descriptors.size());
        for (Descriptor descriptor : descriptors) {
            if (!descriptor.runtimeArray()) {
                resolved.add(descriptor);
                continue;
            }
            if (descriptor.set() != 0) {
                throw new IllegalArgumentException(
                        "Runtime descriptor arrays are supported only in set 0");
            }
            Integer count = set0Counts.get(descriptor.binding());
            if (count == null || count < 1 || count > 32) {
                throw new IllegalArgumentException(
                        "Runtime descriptor binding "
                                + descriptor.binding()
                                + " requires a manifest bound within 1..32");
            }
            resolved.add(
                    new Descriptor(
                            descriptor.set(),
                            descriptor.binding(),
                            descriptor.descriptorType(),
                            count,
                            false,
                            descriptor.stageFlags(),
                            descriptor.name(),
                            descriptor.readable(),
                            descriptor.writable(),
                            descriptor.minimumBufferSize(),
                            descriptor.imageType()));
        }
        return new VeilShaderInterface(
                resolved, pushConstants, stageInputs, stageOutputs, specializationConstants);
    }

    public List<Descriptor> descriptorsForSet(int set) {
        return descriptors.stream().filter(binding -> binding.set == set).toList();
    }

    public void validateGraphicsStages() {
        validateGraphicsStages(Set.of(VeilShaderStage.VERTEX, VeilShaderStage.FRAGMENT));
    }

    public void validateGraphicsStages(Set<VeilShaderStage> stages) {
        validateStageLocations(stageInputs);
        validateStageLocations(stageOutputs);
        List<VeilShaderStage> chain =
                List.of(
                                VeilShaderStage.VERTEX,
                                VeilShaderStage.TESS_CONTROL,
                                VeilShaderStage.TESS_EVALUATION,
                                VeilShaderStage.GEOMETRY,
                                VeilShaderStage.FRAGMENT)
                        .stream()
                        .filter(stages::contains)
                        .toList();
        if (chain.size() < 2
                || chain.getFirst() != VeilShaderStage.VERTEX
                || chain.getLast() != VeilShaderStage.FRAGMENT) {
            throw new IllegalArgumentException(
                    "Graphics stage chain requires vertex and fragment endpoints");
        }
        for (StageIo input : stageInputs) {
            int consumerIndex = -1;
            for (int index = 1; index < chain.size(); index++) {
                if (chain.get(index).vkStageFlags() == input.stageFlags) {
                    consumerIndex = index;
                    break;
                }
            }
            if (consumerIndex < 1) continue;
            VeilShaderStage producerStage = chain.get(consumerIndex - 1);
            VeilShaderStage consumerStage = chain.get(consumerIndex);
            StageIo output =
                    stageOutputs.stream()
                            .filter(
                                    candidate ->
                                            candidate.stageFlags == producerStage.vkStageFlags()
                                                    && candidate.location == input.location
                                                    && candidate.component == input.component)
                            .findFirst()
                            .orElseThrow(
                                    () ->
                                            new IllegalArgumentException(
                                                    consumerStage
                                                            + " input '"
                                                            + input.name
                                                            + "' has no "
                                                            + producerStage
                                                            + " output at location="
                                                            + input.location
                                                            + " component="
                                                            + input.component));
            if (input.baseType != output.baseType
                    || input.bitWidth != output.bitWidth
                    || input.vectorSize != output.vectorSize
                    || input.columns != output.columns
                    || requiresEqualArraySize(consumerStage)
                            && input.arrayElements != output.arrayElements) {
                throw new IllegalArgumentException(
                        producerStage
                                + "/"
                                + consumerStage
                                + " interface mismatch at location="
                                + input.location
                                + " component="
                                + input.component
                                + ": output="
                                + output
                                + ", input="
                                + input);
            }
        }
    }

    private static boolean requiresEqualArraySize(VeilShaderStage consumer) {
        return consumer == VeilShaderStage.FRAGMENT;
    }

    private static void validateStageLocations(List<StageIo> variables) {
        Map<String, StageIo> occupied = new LinkedHashMap<>();
        for (StageIo variable : variables) {
            long components =
                    (long) variable.vectorSize * Math.max(1, (variable.bitWidth + 31) / 32);
            long locations = (variable.component + components + 3) / 4;
            long elements = (long) variable.columns * variable.arrayElements;
            if (locations * elements > 4096
                    || variable.location > Integer.MAX_VALUE - locations * elements) {
                throw new IllegalArgumentException(
                        "Stage interface location range is too large: " + variable.name);
            }
            for (long element = 0; element < elements; element++) {
                for (long component = 0; component < components; component++) {
                    long index = variable.component + component;
                    long location = variable.location + element * locations + index / 4;
                    String key = variable.stageFlags + ":" + location + ":" + index % 4;
                    StageIo previous = occupied.putIfAbsent(key, variable);
                    if (previous != null)
                        throw new IllegalArgumentException(
                                "Overlapping stage interface at "
                                        + key
                                        + ": "
                                        + previous.name
                                        + " and "
                                        + variable.name);
                }
            }
        }
    }
}
