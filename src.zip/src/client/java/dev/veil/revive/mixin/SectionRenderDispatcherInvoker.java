package dev.veil.revive.mixin;

import net.minecraft.TracingExecutor;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(SectionRenderDispatcher.class)
public interface SectionRenderDispatcherInvoker {
    @Accessor("cameraPosition")
    java.util.concurrent.atomic.AtomicReference<net.minecraft.world.phys.Vec3>
            veil$cameraPosition();

    @Invoker("runTask")
    void veil$runTask();

    @Accessor("executor")
    TracingExecutor veil$executor();
}
