package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.*;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanGpuSampler;
import com.mojang.blaze3d.vulkan.VulkanGpuTextureView;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkMemoryBarrier;

final class VeilSlangHzbProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment() && Boolean.getBoolean("veil.slangProbe");
    private static GpuBuffer reference, readback;
    private static GpuFence fence;
    private static VeilHzbPyramidCompute compute;
    private static int completed;
    private static long compared;
    private static int bytes;

    static boolean enabled() {
        return ENABLED;
    }

    static void compare(
            VeilVulkanRuntime runtime,
            VulkanGpuTextureView depth,
            VulkanGpuSampler sampler,
            GpuBufferSlice actual,
            int width,
            int height,
            int baseWidth,
            int baseHeight,
            int mipCount,
            int[] offsets) {
        if (!ENABLED || fence != null || completed >= 5) return;
        var device = RenderSystem.getDevice();
        bytes = Math.toIntExact(actual.length());
        reference =
                device.createBuffer(
                        () -> "Veil GLSL HZB parity",
                        VeilHzb.STORAGE_USAGE | GpuBuffer.USAGE_COPY_SRC,
                        bytes);
        readback =
                device.createBuffer(
                        () -> "Veil Slang HZB parity readback",
                        GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                        bytes * 2L);
        compute = new VeilHzbPyramidCompute(runtime, false);
        compute.build(
                depth,
                sampler,
                reference.slice(),
                width,
                height,
                baseWidth,
                baseHeight,
                mipCount,
                offsets);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var barrier =
                    VkMemoryBarrier.calloc(1, stack)
                            .sType$Default()
                            .srcAccessMask(VK_ACCESS_SHADER_WRITE_BIT)
                            .dstAccessMask(VK_ACCESS_TRANSFER_READ_BIT);
            vkCmdPipelineBarrier(
                    runtime.commandBuffer(),
                    VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                    VK_PIPELINE_STAGE_TRANSFER_BIT,
                    0,
                    barrier,
                    null,
                    null);
        }
        var encoder = device.createCommandEncoder();
        encoder.copyToBuffer(actual, readback.slice(0, bytes));
        encoder.copyToBuffer(reference.slice(), readback.slice(bytes, bytes));
        fence = encoder.createFence();
    }

    static void poll() {
        if (!ENABLED || fence == null || !fence.awaitCompletion(0)) return;
        try (var mapped = readback.map(true, false)) {
            var data = mapped.data();
            for (int offset = 0; offset < bytes; offset += 4) {
                if (data.getInt(offset) != data.getInt(bytes + offset))
                    throw new IllegalStateException(
                            "Slang HZB differs from GLSL at word " + offset / 4);
            }
            compared += bytes / 4;
            completed++;
            ReviveMod.LOGGER.info(
                    "Veil Slang HZB parity: frame={} words={} bit-exact", completed, bytes / 4);
            if (completed == 5)
                ReviveMod.LOGGER.info(
                        "Veil Slang HZB GPU probe: PASS ({} words, 5 frames, all mip levels bit-exact against GLSL)",
                        compared);
        } finally {
            fence.close();
            fence = null;
            reference.close();
            reference = null;
            readback.close();
            readback = null;
            compute.close();
            compute = null;
        }
    }

    static void requireComplete() {
        if (ENABLED && completed != 5)
            throw new IllegalStateException("Slang HZB probe incomplete: " + completed);
    }
}
