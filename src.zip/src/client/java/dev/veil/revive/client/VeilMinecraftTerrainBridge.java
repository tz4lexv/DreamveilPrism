package dev.veil.revive.client;

import dev.veil.revive.core.Aabb;
import dev.veil.revive.core.FarTerrainPlanner;
import dev.veil.revive.core.FarTerrainRepresentation;
import dev.veil.revive.core.ScreenSpaceErrorLod;
import dev.veil.revive.core.SectionRevisionTracker;
import dev.veil.revive.core.SurfaceStabilityScore;
import dev.veil.revive.core.WallClockCadence;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.core.SectionPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public final class VeilMinecraftTerrainBridge {
    private static final SectionRevisionTracker REVISIONS = new SectionRevisionTracker();
    private static final SectionRevisionTracker GEOMETRY_REVISIONS = new SectionRevisionTracker();

    private static final long FAR_DEBUG_REFRESH_INTERVAL_NS = 1_000_000_000L;
    private static final WallClockCadence FAR_DEBUG_REFRESH_CADENCE = new WallClockCadence();
    private static long lastAnalyzedVisibleSignature = Long.MIN_VALUE;
    private static long analysisRevision;
    private static long lastAnalyzedRevision = Long.MIN_VALUE;
    private static int lastVisibleCount = -1;
    private static double lastCamX = Double.NaN;
    private static double lastCamY = Double.NaN;
    private static double lastCamZ = Double.NaN;

    private static volatile Snapshot latest = Snapshot.EMPTY;

    private VeilMinecraftTerrainBridge() {}

    public static void onRendererUpdate(
            Camera camera, List<SectionRenderDispatcher.RenderSection> visibleSections) {

        if (!ReviveRuntime.optimizationsEnabled()) return;

        boolean explicitFarDiagnostics =
                ReviveRuntime.config().profilerEnabled() || VeilDiagnostics.detailedOverlay();
        if (!ReviveRuntime.config().farTerrainPlanning() || !explicitFarDiagnostics) return;

        VeilTechniqueCounters.farAnalysisRequest();
        boolean timing = true;
        long analysisStartNs = timing ? System.nanoTime() : 0L;

        Vec3 cameraPos = camera.position();

        boolean cameraMoved =
                !Double.isFinite(lastCamX)
                        || distanceSquared(
                                        cameraPos.x,
                                        cameraPos.y,
                                        cameraPos.z,
                                        lastCamX,
                                        lastCamY,
                                        lastCamZ)
                                >= 16.0;
        boolean topologyEvent = analysisRevision != lastAnalyzedRevision;
        boolean visibleCountChanged = visibleSections.size() != lastVisibleCount;
        boolean periodicDebugRefresh =
                FAR_DEBUG_REFRESH_CADENCE.due(System.nanoTime(), FAR_DEBUG_REFRESH_INTERVAL_NS);

        if (!cameraMoved && !topologyEvent && !visibleCountChanged && !periodicDebugRefresh) {
            VeilTechniqueCounters.farAnalysisCadenceSkip();
            if (timing) VeilTechniqueCounters.farAnalysisNanos(System.nanoTime() - analysisStartNs);
            return;
        }

        long signature = visibleSignature(visibleSections);
        lastAnalyzedVisibleSignature = signature;
        lastAnalyzedRevision = analysisRevision;
        lastVisibleCount = visibleSections.size();
        lastCamX = cameraPos.x;
        lastCamY = cameraPos.y;
        lastCamZ = cameraPos.z;

        Minecraft minecraft = Minecraft.getInstance();
        int viewportHeight = Math.max(1, minecraft.gameRenderer.mainRenderTarget().height);

        VeilTechniqueCounters.farAnalysisRun();

        double verticalFovRadians = Math.toRadians(minecraft.options.fov().get());

        int total = 0;
        int exact = 0;
        int simplified = 0;
        int voxel = 0;
        int vasc = 0;
        int translucentFallback = 0;
        int dirtyFallback = 0;

        FarTerrainPlanner planner = ReviveRuntime.veilKernel().farTerrainPlanner();
        SurfaceStabilityScore stability = ReviveRuntime.veilKernel().stability();

        List<ScreenSpaceErrorLod.Level> levels =
                List.of(
                        new ScreenSpaceErrorLod.Level(0, 0.0, 1),
                        new ScreenSpaceErrorLod.Level(1, 0.25, 2),
                        new ScreenSpaceErrorLod.Level(2, 1.0, 4),
                        new ScreenSpaceErrorLod.Level(3, 4.0, 8),
                        new ScreenSpaceErrorLod.Level(4, 8.0, 16));

        for (SectionRenderDispatcher.RenderSection section : visibleSections) {
            total++;
            AABB box = section.getBoundingBox();
            Aabb bounds = new Aabb(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ);
            double distance =
                    Math.max(0.001, bounds.distanceTo(cameraPos.x, cameraPos.y, cameraPos.z));

            boolean dirty = VeilSectionDirtyState.isUnsafe(section.getSectionNode());
            boolean translucent = section.hasTranslucentGeometry();

            double score =
                    stability.score(
                            new SurfaceStabilityScore.Input(
                                    0.0,
                                    0.0,
                                    translucent ? 1.0 : 0.0,
                                    1.0,
                                    dirty ? 0.0 : 1.0,
                                    dirty,
                                    translucent));

            FarTerrainPlanner.Plan plan =
                    planner.plan(
                            new FarTerrainPlanner.Input(
                                    distance, viewportHeight, verticalFovRadians, score),
                            levels);

            if (dirty) {
                dirtyFallback++;
                VeilFallbackTracker.record(VeilFallbackTracker.Reason.VASC_DIRTY);
                exact++;
                continue;
            }
            if (translucent) {
                translucentFallback++;
                VeilFallbackTracker.record(VeilFallbackTracker.Reason.VASC_TRANSLUCENT);
                exact++;
                continue;
            }

            FarTerrainRepresentation representation = plan.representation();
            if (representation == FarTerrainRepresentation.VASC_DEEP_SURFACE
                    && !ReviveRuntime.config().vascEnabled()) {
                representation =
                        plan.lod().voxelScale() >= 4
                                ? FarTerrainRepresentation.VOXEL_LOD
                                : FarTerrainRepresentation.SSE_SIMPLIFIED_MESH;
            }

            switch (representation) {
                case FULL_GEOMETRY -> exact++;
                case SSE_SIMPLIFIED_MESH -> simplified++;
                case VOXEL_LOD -> voxel++;
                case VASC_DEEP_SURFACE -> vasc++;
            }
        }

        latest =
                new Snapshot(
                        total,
                        exact,
                        simplified,
                        voxel,
                        vasc,
                        translucentFallback,
                        dirtyFallback,
                        signature);

        VeilTechniqueCounters.farSectionsAnalyzed(total);
        VeilTechniqueCounters.farExactCandidates(exact);
        VeilTechniqueCounters.farSseCandidates(simplified);
        VeilTechniqueCounters.farVoxelCandidates(voxel);
        VeilTechniqueCounters.farVascCandidates(vasc);
        VeilTechniqueCounters.farDirtyFallbacks(dirtyFallback);
        VeilTechniqueCounters.farTranslucentFallbacks(translucentFallback);
        if (timing) VeilTechniqueCounters.farAnalysisNanos(System.nanoTime() - analysisStartNs);
    }

    public static void onSectionDirty(int sectionX, int sectionY, int sectionZ) {
        VeilTechniqueCounters.sectionDirtyEvent();
        VeilLightingPipeline.recordSectionDirty();
        long node = SectionPos.asLong(sectionX, sectionY, sectionZ);
        REVISIONS.markDirty(node);
        boolean lightOnly = VeilLightingPipeline.inLightSectionUpdate();
        if (!lightOnly) {
            GEOMETRY_REVISIONS.markDirty(node);
        }
        if (ReviveRuntime.veilKernel() != null) {
            if (lightOnly) ReviveRuntime.veilKernel().lightUpdates().markLightDirty(node);
            else ReviveRuntime.veilKernel().lightUpdates().markGeometryDirty(node);
        }
        VeilSectionDirtyState.markDirty(node);

        int regionX = Math.floorDiv(sectionX, 32);
        int regionZ = Math.floorDiv(sectionZ, 32);
        if (!lightOnly && ReviveRuntime.veilKernel() != null) {
            ReviveRuntime.veilKernel().farLodStore().invalidateRegion(regionX, regionZ);
        }
    }

    public static void onSectionMeshUpdated(long sectionNode) {
        VeilTechniqueCounters.sectionMeshUpdateEvent();
        analysisRevision++;
        VeilSectionDirtyState.meshUpdated(sectionNode);
    }

    public static void invalidateAll() {
        VeilOriginalAttributeWork.invalidate();
        VeilTechniqueCounters.globalInvalidation();
        VeilHostRevisions.invalidateAll();
        REVISIONS.invalidateAll();
        GEOMETRY_REVISIONS.invalidateAll();
        if (ReviveRuntime.veilKernel() != null) ReviveRuntime.veilKernel().lightUpdates().clear();
        VeilSectionDirtyState.invalidateAll();
        VeilTerrainDrawBridge.invalidateAll();
        VeilSectionVisibilityIndex.invalidate();
        VeilRebuildBudget.resetSectionPredictors();
        VeilLightingPipeline.clearWorldState();
        FAR_DEBUG_REFRESH_CADENCE.reset();
        latest = Snapshot.EMPTY;
        analysisRevision++;
        lastAnalyzedRevision = Long.MIN_VALUE;
        lastAnalyzedVisibleSignature = Long.MIN_VALUE;
        lastVisibleCount = -1;
        lastCamX = lastCamY = lastCamZ = Double.NaN;
    }

    public static Snapshot latest() {
        return latest;
    }

    public static long sectionRevision(long sectionNode) {
        return REVISIONS.revision(sectionNode);
    }

    public static long geometrySectionRevision(long sectionNode) {
        return GEOMETRY_REVISIONS.revision(sectionNode);
    }

    private static long visibleSignature(List<SectionRenderDispatcher.RenderSection> sections) {
        long h = 0xcbf29ce484222325L;
        for (SectionRenderDispatcher.RenderSection section : sections) {
            h ^= section.getSectionNode();
            h *= 0x100000001b3L;
            h ^= System.identityHashCode(section.getSectionMesh());
            h *= 0x100000001b3L;
        }
        return h;
    }

    private static double distanceSquared(
            double ax, double ay, double az, double bx, double by, double bz) {
        double dx = ax - bx, dy = ay - by, dz = az - bz;
        return dx * dx + dy * dy + dz * dz;
    }

    public record Snapshot(
            int visibleSections,
            int exactSections,
            int sseSections,
            int voxelSections,
            int vascSections,
            int translucentFallbacks,
            int dirtyFallbacks,
            long visibleSignature) {

        static final Snapshot EMPTY = new Snapshot(0, 0, 0, 0, 0, 0, 0, 0L);
    }
}
