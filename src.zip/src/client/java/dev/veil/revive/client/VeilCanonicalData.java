package dev.veil.revive.client;

import java.nio.ByteBuffer;
import java.util.LinkedHashSet;
import java.util.concurrent.atomic.AtomicLong;

public final class VeilCanonicalData implements AutoCloseable {
    private static final long LIMIT = 64L << 20;
    private static final AtomicLong RETAINED = new AtomicLong();
    private static final AtomicLong EVICTED = new AtomicLong();
    private static final LinkedHashSet<VeilCanonicalData> RESIDENT = new LinkedHashSet<>();
    private byte[] bytes;
    private final int size;
    private boolean owner = true;
    private int readers = 1;

    private VeilCanonicalData(byte[] bytes) {
        this.bytes = bytes;
        size = bytes.length;
    }

    public static VeilCanonicalData capture(ByteBuffer input) {
        int size = input.remaining();
        if (size == 0 || size > 4 << 20 || size % 28 != 0) return null;
        if (!reserve(size)) return null;
        VeilCanonicalData data = null;
        try {
            byte[] copy = new byte[size];
            input.duplicate().get(copy);
            data = new VeilCanonicalData(copy);
            synchronized (RESIDENT) {
                RESIDENT.addLast(data);
            }
            return data;
        } catch (RuntimeException | Error failure) {
            if (data == null) RETAINED.addAndGet(-size);
            else data.retire();
            throw failure;
        }
    }

    public boolean acquire() {
        synchronized (this) {
            if (!owner || readers == 0) return false;
            readers++;
        }
        synchronized (RESIDENT) {
            if (RESIDENT.contains(this)) RESIDENT.addLast(this);
        }
        return true;
    }

    public synchronized ByteBuffer view() {
        if (bytes == null) throw new IllegalStateException("Canonical data retired");
        return ByteBuffer.wrap(bytes).asReadOnlyBuffer();
    }

    public int size() {
        return size;
    }

    public static long retainedBytes() {
        return RETAINED.get();
    }

    public static long evicted() {
        return EVICTED.get();
    }

    private static boolean reserve(int size) {
        for (int attempt = 0; attempt <= 32; attempt++) {
            while (true) {
                long used = RETAINED.get();
                if (size > LIMIT - used) break;
                if (RETAINED.compareAndSet(used, used + size)) return true;
            }
            if (attempt == 32) return false;
            VeilCanonicalData candidate;
            synchronized (RESIDENT) {
                if (RESIDENT.isEmpty()) return false;
                candidate = RESIDENT.removeFirst();
            }
            if (!candidate.evict())
                synchronized (candidate) {
                    if (candidate.owner)
                        synchronized (RESIDENT) {
                            RESIDENT.addLast(candidate);
                        }
                }
        }
        return false;
    }

    private synchronized boolean evict() {
        if (!owner) return true;
        if (readers != 1) return false;
        owner = false;
        readers = 0;
        releaseBytes();
        EVICTED.incrementAndGet();
        return true;
    }

    public void retire() {
        synchronized (this) {
            if (!owner) return;
            owner = false;
            if (--readers == 0) releaseBytes();
        }
        synchronized (RESIDENT) {
            RESIDENT.remove(this);
        }
    }

    private void releaseBytes() {
        bytes = null;
        RETAINED.addAndGet(-size);
    }

    @Override
    public synchronized void close() {
        if (readers <= (owner ? 1 : 0))
            throw new IllegalStateException("Missing canonical data lease");
        if (--readers == 0) releaseBytes();
    }
}
