package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderPassDescriptor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.terrain.ParametricTerrainQuads;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.resources.Identifier;

import org.joml.Vector4f;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.LinkedHashMap;

final class VeilParametricTerrainGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.parametricTerrainGpuProbe")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final int WIDTH = 512, HEIGHT = 256, SOURCE_LIMIT = 8 << 20;
    private static final LinkedHashMap<ParametricTerrainQuads.Result, byte[]> SOURCES =
            new LinkedHashMap<>();
    private static final RenderPipeline[] PIPELINES = new RenderPipeline[4];
    private static final GpuTexture[] targets = new GpuTexture[3];
    private static final GpuTextureView[] views = new GpuTextureView[3];
    private static final GpuBuffer[] readbacks = new GpuBuffer[3];
    private static GpuBuffer parameters, commands;
    private static GpuFence fence;
    private static byte[] expected;
    private static int sourceBytes, sourcePeak, expectedSlot;
    private static volatile long verifiedVertices;
    private static long captures, shortVertices, intVertices;
    private static final long[] layoutVertices = new long[4];
    private static volatile boolean offsetVerified, reported;
    private static boolean expectedOffset;
    private static IndexType expectedIndexType;

    private VeilParametricTerrainGpuProbe() {}

    static boolean enabled() {
        return ENABLED;
    }

    static synchronized void captureSource(byte[] source, ParametricTerrainQuads.Result data) {
        if (!ENABLED
                || reported
                || verifiedVertices >= 100000 && offsetVerified
                || data.quadCount() * 4 > WIDTH * HEIGHT
                || SOURCES.containsKey(data)) return;
        int charge = source.length + data.descriptors().length;
        if (charge > SOURCE_LIMIT) return;
        while (!SOURCES.isEmpty()
                && (sourceBytes + charge > SOURCE_LIMIT || SOURCES.size() >= 64)) {
            var iterator = SOURCES.entrySet().iterator();
            var first = iterator.next();
            sourceBytes -= first.getValue().length + first.getKey().descriptors().length;
            iterator.remove();
        }
        SOURCES.put(data, source.clone());
        sourceBytes += charge;
        sourcePeak = Math.max(sourcePeak, sourceBytes);
    }

    private static synchronized byte[] takeSource(ParametricTerrainQuads.Result data) {
        var source = SOURCES.remove(data);
        if (source != null) sourceBytes -= source.length + data.descriptors().length;
        return source;
    }

    static void capture(
            ParametricTerrainQuads.Result data,
            GpuBuffer words,
            int baseVertex,
            GpuBuffer indices,
            IndexType indexType) {
        if (!ENABLED || fence != null || verifiedVertices >= 100000 && offsetVerified) return;
        byte[] source = takeSource(data);
        if (source == null) return;
        expected = source;
        expectedSlot = data.layout().ordinal();
        expectedOffset = baseVertex != 0;
        expectedIndexType = indexType;
        try {
            VeilParametricRasterProbe.capture(
                    source, data.layout(), words, baseVertex, indices, indexType);
            start(data.layout(), words, baseVertex, indices, indexType);
        } catch (RuntimeException | Error failure) {
            closeGpu();
            throw failure;
        }
    }

    private static void start(
            ParametricTerrainQuads.Layout layout,
            GpuBuffer words,
            int baseVertex,
            GpuBuffer indices,
            IndexType indexType) {
        var device = RenderSystem.getDevice();
        var features = device.getDeviceInfo().features();
        if (!features.multiDrawDirectInterleaved() || !features.multiDrawIndirect())
            throw new IllegalStateException(
                    "Native parametric oracle requires direct multi and MDI");
        var builder =
                RenderPipeline.builder()
                        .withLocation(id("pipeline/parametric_native_oracle_" + expectedSlot))
                        .withVertexShader(id("core/terrain_parametric_native_probe"))
                        .withFragmentShader(id("core/terrain_attributes_probe"))
                        .withPrimitiveTopology(PrimitiveTopology.POINTS)
                        .withCull(false)
                        .withDepthStencilState(java.util.Optional.empty())
                        .withShaderDefine("VEIL_QUAD_WORDS", layout.stride() / 4)
                        .withBindGroupLayout(
                                BindGroupLayout.builder()
                                        .withUniform(
                                                "VeilQuadWords",
                                                UniformType.TEXEL_BUFFER,
                                                GpuFormat.R32_SINT)
                                        .withUniform(
                                                "VeilParametricProbe", UniformType.UNIFORM_BUFFER)
                                        .build());
        if (layout.flatColor()) builder.withShaderDefine("VEIL_QUAD_FLAT");
        if (layout.halfUv()) builder.withShaderDefine("VEIL_QUAD_HALF");
        var descriptor =
                RenderPassDescriptor.create(() -> "Veil native parametric attributes")
                        .withRenderArea(new RenderPass.RenderArea(0, 0, WIDTH, HEIGHT));
        for (int i = 0; i < 3; i++) {
            var format = i == 2 ? GpuFormat.RGBA8_UNORM : GpuFormat.RGBA32_FLOAT;
            builder.withColorTargetState(
                    i,
                    new ColorTargetState(
                            java.util.Optional.empty(), format, ColorTargetState.WRITE_ALL));
            targets[i] =
                    device.createTexture(
                            "Veil native parametric attributes " + i,
                            GpuTexture.USAGE_RENDER_ATTACHMENT | GpuTexture.USAGE_COPY_SRC,
                            format,
                            WIDTH,
                            HEIGHT,
                            1,
                            1);
            views[i] = device.createTextureView(targets[i]);
            descriptor.withColorAttachment(
                    views[i], java.util.Optional.of(new Vector4f(0, 0, 0, 0)));
            readbacks[i] =
                    device.createBuffer(
                            () -> "Veil native parametric readback",
                            GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                            (long) WIDTH * HEIGHT * format.blockSize() * 3);
        }
        if (PIPELINES[expectedSlot] == null) PIPELINES[expectedSlot] = builder.build();
        var pipeline = PIPELINES[expectedSlot];
        if (!device.precompilePipeline(pipeline).isValid())
            throw new IllegalStateException("Native parametric oracle unavailable");
        ByteBuffer range = ByteBuffer.allocateDirect(16).order(ByteOrder.LITTLE_ENDIAN);
        range.putInt(baseVertex).putInt(0).putInt(0).putInt(0).flip();
        parameters =
                device.createBuffer(
                        () -> "Veil native probe range", GpuBuffer.USAGE_UNIFORM, range);
        int indexCount = expected.length / 28 / 4 * 6;
        ByteBuffer indirect = ByteBuffer.allocateDirect(20).order(ByteOrder.LITTLE_ENDIAN);
        indirect.putInt(indexCount).putInt(1).putInt(0).putInt(baseVertex).putInt(0).flip();
        commands =
                device.createBuffer(
                        () -> "Veil native probe MDI",
                        GpuBuffer.USAGE_INDIRECT_PARAMETERS,
                        indirect);
        var multi = ByteBuffer.allocateDirect(12).order(ByteOrder.nativeOrder()).asIntBuffer();
        multi.put(0).put(indexCount).put(baseVertex).flip();
        var encoder = device.createCommandEncoder();
        for (int mode = 0; mode < 3; mode++) {
            try (var pass = encoder.createRenderPass(descriptor)) {
                pass.setPipeline(pipeline);
                pass.setUniform("VeilQuadWords", words);
                pass.setUniform("VeilParametricProbe", parameters);
                pass.setIndexBuffer(indices, indexType);
                switch (mode) {
                    case 0 -> pass.drawIndexed(indexCount, 1, 0, baseVertex, 0);
                    case 1 -> pass.multiDrawIndexed(multi, 1, 0, 1);
                    case 2 -> pass.drawIndexedIndirect(commands.slice(), 1);
                    default -> throw new AssertionError();
                }
            }
            for (int i = 0; i < 3; i++) {
                int block = i == 2 ? 4 : 16;
                encoder.copyTextureToBuffer(
                        targets[i],
                        readbacks[i],
                        (long) mode * WIDTH * HEIGHT * block,
                        () -> {},
                        0);
            }
        }
        fence = encoder.createFence();
    }

    static void tick() {
        VeilParametricRasterProbe.tick();
        if (!ENABLED || fence == null || !fence.awaitCompletion(0)) return;
        try {
            for (int mode = 0; mode < 3; mode++)
                VeilTerrainAttributeReadback.verify(
                        ByteBuffer.wrap(expected).order(ByteOrder.LITTLE_ENDIAN),
                        readbacks,
                        WIDTH,
                        HEIGHT,
                        mode,
                        "Native parametric mode=" + mode + " layout=" + expectedSlot);
            int count = expected.length / 28;
            verifiedVertices += count;
            layoutVertices[expectedSlot] += count;
            if (expectedIndexType == IndexType.SHORT) shortVertices += count;
            else intVertices += count;
            offsetVerified |= expectedOffset;
            captures++;
            if (verifiedVertices >= 100000 && offsetVerified) {
                reported = true;
                clearSources();
                ReviveMod.LOGGER.info(
                        "Veil parametric native GPU: PASS (vertices_per_mode={} direct=true direct_multi=true mdi=true actual_arena=true actual_shared_indices=true nonzero_base_vertex=true captures={} flat_half={} flat_float={} corner_half={} corner_float={} short={} int={} source_pool_peak={})",
                        verifiedVertices,
                        captures,
                        layoutVertices[0],
                        layoutVertices[1],
                        layoutVertices[2],
                        layoutVertices[3],
                        shortVertices,
                        intVertices,
                        sourcePeak);
            }
        } finally {
            closeGpu();
        }
    }

    static void requireComplete() {
        VeilParametricRasterProbe.requireComplete();
        if (ENABLED && !reported)
            throw new IllegalStateException(
                    "Native parametric GPU incomplete: vertices=" + verifiedVertices);
    }

    private static synchronized void clearSources() {
        SOURCES.clear();
        sourceBytes = 0;
    }

    private static void closeGpu() {
        if (fence != null) {
            fence.close();
            fence = null;
        }
        if (parameters != null) {
            parameters.close();
            parameters = null;
        }
        if (commands != null) {
            commands.close();
            commands = null;
        }
        for (int i = 0; i < 3; i++) {
            if (readbacks[i] != null) {
                readbacks[i].close();
                readbacks[i] = null;
            }
            if (views[i] != null) {
                views[i].close();
                views[i] = null;
            }
            if (targets[i] != null) {
                targets[i].close();
                targets[i] = null;
            }
        }
        expected = null;
    }

    static void close() {
        VeilParametricRasterProbe.close();
        closeGpu();
        clearSources();
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }
}
