package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilServerAiCounters;

import net.minecraft.client.server.IntegratedServer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.BooleanSupplier;

@Mixin(IntegratedServer.class)
public abstract class IntegratedServerTickTimingMixin {
    @Unique private long veil$serverTickStartNs;

    @Inject(method = "tickServer", at = @At("HEAD"), require = 1)
    private void veil$beginServerTick(BooleanSupplier haveTime, CallbackInfo ci) {
        veil$serverTickStartNs = VeilDiagnostics.benchmarkActive() ? System.nanoTime() : 0L;
    }

    @Inject(method = "tickServer", at = @At("RETURN"), require = 1)
    private void veil$endServerTick(BooleanSupplier haveTime, CallbackInfo ci) {
        long start = veil$serverTickStartNs;
        veil$serverTickStartNs = 0L;
        if (start != 0L && VeilDiagnostics.benchmarkActive()) {
            VeilServerAiCounters.serverTick(System.nanoTime() - start);
        }
    }
}
