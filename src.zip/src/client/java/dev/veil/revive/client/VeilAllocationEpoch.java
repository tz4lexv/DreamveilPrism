package dev.veil.revive.client;

import dev.veil.revive.core.terrain.IdentityChangeJournal;

public final class VeilAllocationEpoch {
    private static final IdentityChangeJournal<Object> CHANGES = new IdentityChangeJournal<>(4096);
    private static final ClassValue<Boolean> IDENTITY_KEYS =
            new ClassValue<>() {
                @Override
                protected Boolean computeValue(Class<?> type) {
                    try {
                        return type.getMethod("equals", Object.class).getDeclaringClass()
                                == Object.class;
                    } catch (ReflectiveOperationException | SecurityException failure) {
                        return false;
                    }
                }
            };

    private VeilAllocationEpoch() {}

    public static void changed() {
        CHANGES.changed(null);
    }

    public static void changed(Object owner) {
        CHANGES.changed(owner != null && IDENTITY_KEYS.get(owner.getClass()) ? owner : null);
    }

    static boolean affectsSince(long previous, java.util.function.Predicate<Object> relevant) {
        return CHANGES.affectsSince(previous, relevant);
    }

    static boolean visitSince(long previous, java.util.function.Consumer<Object> visitor) {
        return CHANGES.visitSince(previous, visitor);
    }

    public static long current() {
        return CHANGES.revision();
    }

    public static boolean unchangedSince(long previous, Object owner) {
        return !CHANGES.affectsSince(previous, changed -> changed == owner);
    }
}
