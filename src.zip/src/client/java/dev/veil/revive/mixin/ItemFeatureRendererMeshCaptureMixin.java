package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilEntityMeshCapture;

import net.minecraft.client.renderer.feature.ItemFeatureRenderer;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemFeatureRenderer.class)
public abstract class ItemFeatureRendererMeshCaptureMixin {
    @Inject(method = "prepareMainSubmit", at = @At("HEAD"), require = 1)
    private void veil$captureItemMesh(ItemFeatureRenderer.Submit submit, CallbackInfo ci) {
        VeilEntityMeshCapture.captureItem(submit.pose(), submit.quads());
    }
}
