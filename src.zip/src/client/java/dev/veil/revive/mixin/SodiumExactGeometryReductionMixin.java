package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilShaderGeometryReduction;
import dev.veil.revive.client.VeilShaderPackBridge;
import dev.veil.revive.client.VeilTechniqueCounters;
import dev.veil.revive.core.ExactQuadDeduplicator;

import net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.BlockRenderer;
import net.caffeinemc.mods.sodium.client.render.chunk.terrain.material.Material;
import net.caffeinemc.mods.sodium.client.render.model.EncodingFormat;
import net.caffeinemc.mods.sodium.client.render.model.MutableQuadViewImpl;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.state.BlockState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = BlockRenderer.class, priority = 900, remap = false)
public abstract class SodiumExactGeometryReductionMixin {
    @Unique private static final int VEIL_MAX_QUADS_PER_BLOCK = 96;

    @Unique
    private final ExactQuadDeduplicator veil$quadDedup =
            new ExactQuadDeduplicator(VEIL_MAX_QUADS_PER_BLOCK, EncodingFormat.TOTAL_STRIDE);

    @Unique private boolean veil$reduceThisBlock;
    @Unique private boolean veil$metrics;
    @Unique private boolean veil$foliage;
    @Unique private boolean veil$shaderPack;
    @Unique private boolean veil$capacityReported;
    @Unique private boolean veil$featureEnabled;
    @Unique private int veil$probeBlocksRemaining = 256;
    @Unique private int veil$cooldownBlocks;
    @Unique private long veil$windowQuads;
    @Unique private long veil$windowRemoved;

    @Inject(method = "renderModel", at = @At("HEAD"), require = 0)
    private void veil$beginExactReduction(
            BlockStateModel model,
            BlockState state,
            BlockPos pos,
            BlockPos origin,
            CallbackInfo ci) {
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.SHADER_GEOMETRY_REDUCTION);
        this.veil$quadDedup.reset();
        this.veil$featureEnabled = VeilShaderGeometryReduction.enabled();
        this.veil$shaderPack = this.veil$featureEnabled && VeilShaderPackBridge.shaderPackActive();
        if (this.veil$featureEnabled && this.veil$cooldownBlocks > 0) {
            this.veil$cooldownBlocks--;
            this.veil$reduceThisBlock = false;
            if (VeilTechniqueCounters.collecting())
                VeilShaderGeometryReduction.recordAutotuneSuppressedBlock();
        } else {
            this.veil$reduceThisBlock = this.veil$featureEnabled;
        }
        this.veil$metrics = this.veil$reduceThisBlock && VeilTechniqueCounters.collecting();
        this.veil$foliage = this.veil$reduceThisBlock && state.is(BlockTags.LEAVES);
        this.veil$capacityReported = false;
        if (this.veil$metrics) VeilShaderGeometryReduction.recordBlock();
    }

    @Inject(method = "bufferQuad", at = @At("HEAD"), cancellable = true, require = 0)
    private void veil$reduceExactPostLightingQuad(
            MutableQuadViewImpl quad, float[] brightnesses, Material material, CallbackInfo ci) {
        if (!this.veil$reduceThisBlock) return;
        if (this.veil$metrics) VeilShaderGeometryReduction.recordQuad();
        dev.veil.revive.client.VeilFullFrameTelemetry.addLoad(
                dev.veil.revive.client.VeilFullFrameTelemetry.LoadCounter.SHADER_GEOMETRY_QUADS,
                1L);

        if (material.pass.isTranslucent()) {
            if (this.veil$metrics) VeilShaderGeometryReduction.recordTranslucentSkip();
            return;
        }
        if (this.veil$metrics) VeilShaderGeometryReduction.recordOpaqueOrCutoutQuad();
        this.veil$windowQuads++;

        if (veil$isFiniteZeroArea(quad)) {
            this.veil$windowRemoved++;
            if (this.veil$metrics) VeilShaderGeometryReduction.recordDegenerate();
            dev.veil.revive.client.VeilFullFrameTelemetry.addLoad(
                    dev.veil.revive.client.VeilFullFrameTelemetry.LoadCounter
                            .SHADER_GEOMETRY_QUADS_REMOVED,
                    1L);
            ci.cancel();
            return;
        }

        if (brightnesses == null || brightnesses.length < 4 || quad.data == null) return;

        int result =
                this.veil$quadDedup.testAndRemember(
                        quad.data,
                        quad.baseIndex,
                        Float.floatToRawIntBits(brightnesses[0]),
                        Float.floatToRawIntBits(brightnesses[1]),
                        Float.floatToRawIntBits(brightnesses[2]),
                        Float.floatToRawIntBits(brightnesses[3]),
                        material.bits());

        if (result == ExactQuadDeduplicator.DUPLICATE) {
            this.veil$windowRemoved++;
            if (this.veil$metrics) {
                VeilShaderGeometryReduction.recordExactDuplicate(
                        this.veil$foliage, this.veil$shaderPack);
            }
            dev.veil.revive.client.VeilFullFrameTelemetry.addLoad(
                    dev.veil.revive.client.VeilFullFrameTelemetry.LoadCounter
                            .SHADER_GEOMETRY_QUADS_REMOVED,
                    1L);
            ci.cancel();
        } else if (result == ExactQuadDeduplicator.CAPACITY_EXHAUSTED
                && !this.veil$capacityReported) {
            this.veil$capacityReported = true;
            if (this.veil$metrics) VeilShaderGeometryReduction.recordCapacityFallback();
        }
    }

    @Inject(method = "renderModel", at = @At("RETURN"), require = 0)
    private void veil$finishExactReductionProbe(
            BlockStateModel model,
            BlockState state,
            BlockPos pos,
            BlockPos origin,
            CallbackInfo ci) {
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.SHADER_GEOMETRY_REDUCTION);
        if (!this.veil$featureEnabled || !this.veil$reduceThisBlock) return;
        if (--this.veil$probeBlocksRemaining > 0) return;

        boolean enoughSamples = this.veil$windowQuads >= 128;

        long multiplier = this.veil$shaderPack ? 200L : 100L;
        boolean profitable =
                !enoughSamples || this.veil$windowRemoved * multiplier >= this.veil$windowQuads;
        if (VeilTechniqueCounters.collecting())
            VeilShaderGeometryReduction.recordAutotuneProbeWindow();

        if (profitable) {
            if (VeilTechniqueCounters.collecting())
                VeilShaderGeometryReduction.recordAutotuneKeep();
            this.veil$probeBlocksRemaining = 512;
        } else {
            if (VeilTechniqueCounters.collecting())
                VeilShaderGeometryReduction.recordAutotuneDisable();
            this.veil$cooldownBlocks = this.veil$shaderPack ? 1024 : 2048;
            this.veil$probeBlocksRemaining = 128;
        }
        this.veil$windowQuads = 0L;
        this.veil$windowRemoved = 0L;
    }

    @Unique
    private static boolean veil$isFiniteZeroArea(MutableQuadViewImpl q) {
        float x0 = q.getX(0), y0 = q.getY(0), z0 = q.getZ(0);
        float x1 = q.getX(1), y1 = q.getY(1), z1 = q.getZ(1);
        float x2 = q.getX(2), y2 = q.getY(2), z2 = q.getZ(2);
        float x3 = q.getX(3), y3 = q.getY(3), z3 = q.getZ(3);
        if (!(Float.isFinite(x0)
                && Float.isFinite(y0)
                && Float.isFinite(z0)
                && Float.isFinite(x1)
                && Float.isFinite(y1)
                && Float.isFinite(z1)
                && Float.isFinite(x2)
                && Float.isFinite(y2)
                && Float.isFinite(z2)
                && Float.isFinite(x3)
                && Float.isFinite(y3)
                && Float.isFinite(z3))) return false;
        return veil$triangleAreaSquared(x0, y0, z0, x1, y1, z1, x2, y2, z2) <= 1.0e-24f
                && veil$triangleAreaSquared(x0, y0, z0, x2, y2, z2, x3, y3, z3) <= 1.0e-24f;
    }

    @Unique
    private static float veil$triangleAreaSquared(
            float ax,
            float ay,
            float az,
            float bx,
            float by,
            float bz,
            float cx,
            float cy,
            float cz) {
        float ux = bx - ax, uy = by - ay, uz = bz - az;
        float vx = cx - ax, vy = cy - ay, vz = cz - az;
        float x = uy * vz - uz * vy;
        float y = uz * vx - ux * vz;
        float z = ux * vy - uy * vx;
        return Math.fma(x, x, Math.fma(y, y, z * z));
    }
}
