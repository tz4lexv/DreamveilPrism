package dev.veil.api;

import java.util.Set;

public record VeilScenePass(Camera camera, Set<Category> categories, Raster raster) {
    public VeilScenePass(Camera camera, Set<Category> categories) {
        this(camera, categories, Raster.INHERIT);
    }

    public enum CullMode {
        NONE,
        FRONT,
        BACK,
        FRONT_AND_BACK
    }

    public enum FrontFace {
        COUNTER_CLOCKWISE,
        CLOCKWISE
    }

    public record Raster(
            Boolean depthBias,
            Float depthBiasConstant,
            Float depthBiasSlope,
            Float depthBiasClamp,
            Boolean depthClamp,
            CullMode cullMode,
            FrontFace frontFace) {
        public static final Raster INHERIT = new Raster(null, null, null, null, null, null, null);

        public Raster {
            if (depthBiasConstant != null && !Float.isFinite(depthBiasConstant)
                    || depthBiasSlope != null && !Float.isFinite(depthBiasSlope)
                    || depthBiasClamp != null && !Float.isFinite(depthBiasClamp)) {
                throw new IllegalArgumentException("Scene raster bias must be finite");
            }
        }

        public boolean inherits() {
            return equals(INHERIT);
        }
    }

    public enum Projection {
        ORTHOGRAPHIC,
        PERSPECTIVE
    }

    public enum Anchor {
        MAIN_CAMERA,
        WORLD_POSITION
    }

    public enum Direction {
        SUN,
        FIXED
    }

    public enum Category {
        TERRAIN_OPAQUE,
        TERRAIN_CUTOUT,
        ENTITIES,
        BLOCK_ENTITIES
    }

    public record Pose(
            double x,
            double y,
            double z,
            float forwardX,
            float forwardY,
            float forwardZ,
            float upX,
            float upY,
            float upZ) {
        public static final Pose DEFAULT = new Pose(0, 0, 0, 0, 0, -1, 0, 1, 0);

        public Pose {
            double direction = Math.hypot(forwardX, Math.hypot(forwardY, forwardZ));
            double up = Math.hypot(upX, Math.hypot(upY, upZ));
            double cross =
                    Math.hypot(
                            (double) forwardY * upZ - (double) forwardZ * upY,
                            Math.hypot(
                                    (double) forwardZ * upX - (double) forwardX * upZ,
                                    (double) forwardX * upY - (double) forwardY * upX));
            if (!Double.isFinite(x)
                    || !Double.isFinite(y)
                    || !Double.isFinite(z)
                    || !Double.isFinite(direction)
                    || !Double.isFinite(up)
                    || direction == 0
                    || up == 0
                    || cross <= direction * up * 1e-6)
                throw new IllegalArgumentException(
                        "Invalid custom camera pose: finite position and nonparallel forward/up required");
        }
    }

    public record Camera(
            Projection projection,
            Anchor anchor,
            Direction direction,
            float width,
            float height,
            float nearPlane,
            float farPlane,
            boolean stabilize,
            Pose pose,
            float verticalFov) {
        public Camera(
                Projection projection,
                Anchor anchor,
                Direction direction,
                float width,
                float height,
                float nearPlane,
                float farPlane,
                boolean stabilize) {
            this(
                    projection,
                    anchor,
                    direction,
                    width,
                    height,
                    nearPlane,
                    farPlane,
                    stabilize,
                    Pose.DEFAULT,
                    60.0f);
        }

        public Camera {
            if (projection == null
                    || anchor == null
                    || direction == null
                    || pose == null
                    || !Float.isFinite(verticalFov)
                    || verticalFov <= 0
                    || verticalFov >= 179
                    || !Float.isFinite(width)
                    || !Float.isFinite(height)
                    || !Float.isFinite(nearPlane)
                    || !Float.isFinite(farPlane)
                    || width <= 0.0f
                    || height <= 0.0f
                    || nearPlane < 0.0f
                    || farPlane <= nearPlane
                    || projection == Projection.PERSPECTIVE && (nearPlane == 0 || stabilize)) {
                throw new IllegalArgumentException("Invalid custom scene camera");
            }
        }
    }

    public VeilScenePass {
        raster = raster == null ? Raster.INHERIT : raster;
        if (camera == null || categories == null || categories.isEmpty()) {
            throw new IllegalArgumentException(
                    "Custom scene pass requires a camera and categories");
        }
        categories = Set.copyOf(categories);
    }
}
