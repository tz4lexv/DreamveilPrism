package dev.veil.revive.client;

import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

final class PreparedOriginalModels {
    private final long node;
    private final int[] ranges;
    private final VeilModelGeometryStamp[] stamps;
    private VeilOriginalQuadCapture.ModelInput[] inputs;

    private PreparedOriginalModels(long node, int[] ranges, VeilModelGeometryStamp[] stamps) {
        this.node = node;
        this.ranges = ranges;
        this.stamps = stamps;
    }

    static PreparedOriginalModels prepare(
            long node,
            List<VeilOriginalQuadCapture.Quad> quads,
            Function<VeilOriginalQuadCapture.Quad, VeilModelGeometryStamp> sample) {
        if (quads.isEmpty() || quads.size() > 4096) return null;
        int[] ranges = new int[4096];
        Arrays.fill(ranges, -1);
        var stamps = new VeilModelGeometryStamp[4096];
        for (int from = 0; from < quads.size(); ) {
            var first = quads.get(from);
            var position = BlockPos.of(first.position());
            if (section(position) != node || first.modelGeometry() == null) return null;
            int slot = slot(position);
            if (ranges[slot] != -1) return null;
            int to = VeilOriginalQuadCapture.blockEnd(quads, from);
            for (int i = from + 1; i < to; i++)
                if (quads.get(i).modelGeometry() != first.modelGeometry()) return null;
            var current = sample.apply(first);
            if (!first.modelGeometry().matches(current)) return null;
            ranges[slot] = from | to << 12;
            stamps[slot] = current;
            from = to;
        }
        return new PreparedOriginalModels(node, ranges, stamps);
    }

    static PreparedOriginalModels prepare(
            long node,
            List<VeilOriginalQuadCapture.Quad> quads,
            List<VeilOriginalQuadCapture.ModelInput> models,
            Function<VeilOriginalQuadCapture.Quad, VeilModelGeometryStamp> sample) {
        if (models.isEmpty() || models.size() > 4096 || quads.size() > 4096) return null;
        var result = new PreparedOriginalModels(node, null, new VeilModelGeometryStamp[4096]);
        result.inputs = new VeilOriginalQuadCapture.ModelInput[4096];
        int end = 0;
        for (var input : models) {
            var probe = input.probe();
            var position = BlockPos.of(probe.position());
            if (section(position) != node
                    || probe.modelGeometry() == null
                    || input.from() != end
                    || input.to() < end
                    || input.to() > quads.size()) return null;
            int slot = slot(position);
            if (result.inputs[slot] != null) return null;
            for (int i = input.from(); i < input.to(); i++) {
                var quad = quads.get(i);
                if (!VeilOriginalQuadCapture.sameBlock(probe, quad)
                        || quad.modelGeometry() != probe.modelGeometry()) return null;
            }
            var current = sample.apply(probe);
            if (!probe.modelGeometry().matches(current)) return null;
            result.inputs[slot] = input;
            result.stamps[slot] = current;
            end = input.to();
        }
        return end == quads.size() ? result : null;
    }

    VeilOriginalQuadCapture.ModelInput input(BlockPos position) {
        return section(position) == node ? inputs[slot(position)] : null;
    }

    int range(BlockPos position) {
        return section(position) == node ? ranges[slot(position)] : -1;
    }

    VeilModelGeometryStamp stamp(BlockPos position) {
        return stamps[slot(position)];
    }

    private static int slot(BlockPos position) {
        return (position.getX() & 15) | (position.getY() & 15) << 4 | (position.getZ() & 15) << 8;
    }

    private static long section(BlockPos position) {
        return SectionPos.asLong(position.getX() >> 4, position.getY() >> 4, position.getZ() >> 4);
    }
}
