package dev.veil.revive.client;

import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.state.BlockState;

public final class VeilLeafCulling {
    private record Settings(boolean enabled, int layers) {}

    private static volatile Settings settings = new Settings(false, 2);
    private static final ThreadLocal<BlockPos.MutableBlockPos> POSITION =
            ThreadLocal.withInitial(BlockPos.MutableBlockPos::new);

    private VeilLeafCulling() {}

    public static void refreshConfig() {
        settings =
                new Settings(
                        VeilVideoConfig.flag("renderer.leafCulling", false),
                        VeilVideoConfig.number("renderer.leafLayers", 2, 1, 4));
    }

    public static boolean hidesFace(
            BlockAndTintGetter level, BlockState state, Direction direction, BlockPos neighbor) {
        return hidesFace(level, state, direction, neighbor, false);
    }

    public static boolean hidesFaceFromOrigin(
            BlockAndTintGetter level, BlockState state, Direction direction, BlockPos origin) {
        return hidesFace(level, state, direction, origin, true);
    }

    private static boolean hidesFace(
            BlockAndTintGetter level,
            BlockState state,
            Direction direction,
            BlockPos start,
            boolean stepFromOrigin) {
        Settings current = settings;
        if (!current.enabled()
                || !ReviveRuntime.optimizationsEnabled()
                || !state.is(BlockTags.LEAVES)) return false;
        int layers = current.layers();
        BlockPos.MutableBlockPos position = POSITION.get().set(start);
        if (stepFromOrigin) position.move(direction);
        for (int i = 0; i < layers; i++) {
            if (!level.getBlockState(position).is(BlockTags.LEAVES)) return false;
            position.move(direction);
        }
        return true;
    }
}
