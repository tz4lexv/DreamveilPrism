package dev.veil.revive.client;

import com.mojang.blaze3d.platform.FramerateLimitTracker.FramerateThrottleReason;

import dev.veil.revive.ReviveMod;

import net.minecraft.client.Minecraft;

final class VeilCameraSweepContext {
    private static final FramerateThrottleReason[] REASONS = FramerateThrottleReason.values();
    private final long[] reasons = new long[REASONS.length];
    private long frames;
    private long iconified;
    private long unfocused;
    private long vsync;
    private long debugOverlays;
    private long charts;
    private long screens;
    private int optionMin = Integer.MAX_VALUE;
    private int optionMax = Integer.MIN_VALUE;
    private int effectiveMin = Integer.MAX_VALUE;
    private int effectiveMax = Integer.MIN_VALUE;
    private int widthMin = Integer.MAX_VALUE;
    private int widthMax = Integer.MIN_VALUE;
    private int heightMin = Integer.MAX_VALUE;
    private int heightMax = Integer.MIN_VALUE;

    void sample(Minecraft client) {
        var window = client.getWindow();
        var tracker = client.getFramerateLimitTracker();
        int option = client.options.framerateLimit().get();
        int effective = tracker.getFramerateLimit();
        reasons[tracker.getThrottleReason().ordinal()]++;
        frames++;
        if (window.isIconified()) iconified++;
        if (!window.isFocused()) unfocused++;
        if (client.options.enableVsync().get()) vsync++;
        var debug = client.getDebugOverlay();
        if (debug.showDebugScreen() || debug.showLightmapTexture()) debugOverlays++;
        if (debug.showProfilerChart() || debug.showNetworkCharts() || debug.showFpsCharts())
            charts++;
        if (client.gui.screen() != null || client.gui.overlay() != null) screens++;
        optionMin = Math.min(optionMin, option);
        optionMax = Math.max(optionMax, option);
        effectiveMin = Math.min(effectiveMin, effective);
        effectiveMax = Math.max(effectiveMax, effective);
        int width = window.getWidth();
        int height = window.getHeight();
        widthMin = Math.min(widthMin, width);
        widthMax = Math.max(widthMax, width);
        heightMin = Math.min(heightMin, height);
        heightMax = Math.max(heightMax, height);
    }

    void report(String phase) {
        ReviveMod.LOGGER.info(
                "Veil camera sweep context: {} frames={} iconified={} unfocused={} vsync={} option_min={} option_max={} effective_min={} effective_max={}",
                phase,
                frames,
                iconified,
                unfocused,
                vsync,
                frames == 0 ? 0 : optionMin,
                frames == 0 ? 0 : optionMax,
                frames == 0 ? 0 : effectiveMin,
                frames == 0 ? 0 : effectiveMax);
        ReviveMod.LOGGER.info(
                "Veil camera sweep viewport: {} frames={} width_min={} width_max={} height_min={} height_max={}",
                phase,
                frames,
                frames == 0 ? 0 : widthMin,
                frames == 0 ? 0 : widthMax,
                frames == 0 ? 0 : heightMin,
                frames == 0 ? 0 : heightMax);
        ReviveMod.LOGGER.info(
                "Veil camera sweep overlays: {} frames={} debug={} charts={} screens={}",
                phase,
                frames,
                debugOverlays,
                charts,
                screens);
        for (var reason : REASONS) {
            long count = reasons[reason.ordinal()];
            if (count > 0)
                ReviveMod.LOGGER.info(
                        "Veil camera sweep throttle: {} reason={} frames={}",
                        phase,
                        reason.name(),
                        count);
        }
    }
}
