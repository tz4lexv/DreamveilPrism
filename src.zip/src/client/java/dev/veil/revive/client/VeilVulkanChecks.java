package dev.veil.revive.client;

final class VeilVulkanChecks {
    private VeilVulkanChecks() {}

    static void check(int result, String operation) {
        dev.veil.revive.client.graphics.minecraft.VulkanResult.check(result, operation);
    }
}
