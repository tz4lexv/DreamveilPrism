package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;

public final class VeilCanonicalGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.verifyCanonicalSparseUploads")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static byte[] expected;
    private static int cpuBytes;
    private static boolean complete;

    private VeilCanonicalGpuProbe() {}

    public static void record(
            Object owner,
            VeilCanonicalData data,
            int uploadedBytes,
            GpuBuffer buffer,
            long offset,
            CommandEncoder encoder) {
        if (!ENABLED
                || complete
                || readback != null
                || uploadedBytes == 0
                || !(owner instanceof VeilMeshExtras extras)) return;
        var source = extras.veil$metadata().originalAttributeSnapshot();
        if (source == null || source.section() != VeilBenchmarkWorld.provenanceSection) return;
        expected = new byte[data.size()];
        data.view().get(expected);
        cpuBytes = uploadedBytes;
        readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil actual canonical sparse terrain readback",
                                GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                                expected.length);
        try {
            encoder.copyToBuffer(buffer.slice(offset, expected.length), readback.slice());
            fence = encoder.createFence();
        } catch (RuntimeException | Error failure) {
            readback.close();
            readback = null;
            expected = null;
            throw failure;
        }
    }

    static void tick() {
        if (fence == null || !fence.awaitCompletion(0)) return;
        try {
            try (var mapped = readback.map(true, false)) {
                for (int at = 0; at < expected.length; at++)
                    if (mapped.data().get(at) != expected[at])
                        throw new IllegalStateException(
                                "Canonical sparse actual GPU mismatch at " + at);
            }
            complete = true;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil canonical sparse GPU: PASS (verified_bytes={} cpu_attribute_bytes={} fresh_allocation=true)",
                    expected.length,
                    cpuBytes);
        } finally {
            fence.close();
            readback.close();
            fence = null;
            readback = null;
            expected = null;
        }
    }

    static void requireComplete() {
        if (ENABLED && !complete)
            throw new IllegalStateException("Canonical sparse actual terrain GPU not exercised");
    }
}
