package dev.veil.revive.client;

import java.util.concurrent.atomic.LongAdder;

public final class VeilShaderMetrics {
    final LongAdder compileTotal = new LongAdder();
    final LongAdder compileFailures = new LongAdder();
    final LongAdder compileNanos = new LongAdder();
    final LongAdder shaderHits = new LongAdder();
    final LongAdder shaderMisses = new LongAdder();
    final LongAdder reflectionTotal = new LongAdder();
    final LongAdder reflectionHits = new LongAdder();
    final LongAdder pipelineHits = new LongAdder();
    final LongAdder pipelineMisses = new LongAdder();
    final LongAdder pipelineCreations = new LongAdder();
    final LongAdder pipelineEvictions = new LongAdder();
    final LongAdder pipelinePinnedOverflows = new LongAdder();
    final LongAdder pipelineCreationNanos = new LongAdder();
    final LongAdder reloadSuccess = new LongAdder();
    final LongAdder reloadFailure = new LongAdder();
    final LongAdder passes = new LongAdder();
    final LongAdder barriers = new LongAdder();

    public String telemetry() {
        return "shader_compile_total="
                + compileTotal.sum()
                + " shader_compile_failures="
                + compileFailures.sum()
                + " shader_compile_ms="
                + compileNanos.sum() / 1_000_000
                + " shader_cache_hits="
                + shaderHits.sum()
                + " shader_cache_misses="
                + shaderMisses.sum()
                + " reflection_total="
                + reflectionTotal.sum()
                + " reflection_cache_hits="
                + reflectionHits.sum()
                + " pipeline_cache_hits="
                + pipelineHits.sum()
                + " pipeline_cache_misses="
                + pipelineMisses.sum()
                + " pipeline_create_total="
                + pipelineCreations.sum()
                + " pipeline_evictions="
                + pipelineEvictions.sum()
                + " pipeline_pinned_overflows="
                + pipelinePinnedOverflows.sum()
                + " pipeline_creation_cpu_ms="
                + pipelineCreationNanos.sum() / 1_000_000.0
                + " hot_reload_success="
                + reloadSuccess.sum()
                + " hot_reload_failure="
                + reloadFailure.sum()
                + " render_graph_passes="
                + passes.sum()
                + " render_graph_barriers="
                + barriers.sum();
    }
}
