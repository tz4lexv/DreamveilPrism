package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilServerAiCounters;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.pathfinder.Path;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

@Mixin(PathNavigation.class)
public abstract class PathNavigationTimingMixin {
    @Shadow @Final protected Mob mob;
    @Unique private long veil$navigationStartNs;
    @Unique private boolean veil$navigationVillager;
    @Unique private long veil$pathCreateStartNs;
    @Unique private boolean veil$pathCreateVillager;

    @Inject(method = "tick", at = @At("HEAD"), require = 1)
    private void veil$beginNavigation(CallbackInfo ci) {
        if (!VeilDiagnostics.benchmarkActive()) {
            veil$navigationStartNs = 0L;
            return;
        }
        veil$navigationVillager = mob instanceof Villager;
        veil$navigationStartNs = System.nanoTime();
    }

    @Inject(method = "tick", at = @At("RETURN"), require = 1)
    private void veil$endNavigation(CallbackInfo ci) {
        long start = veil$navigationStartNs;
        veil$navigationStartNs = 0L;
        if (start != 0L && VeilDiagnostics.benchmarkActive()) {
            VeilServerAiCounters.navigation(System.nanoTime() - start, veil$navigationVillager);
        }
    }

    @Inject(
            method = "createPath(Ljava/util/Set;IZIF)Lnet/minecraft/world/level/pathfinder/Path;",
            at = @At("HEAD"),
            require = 1)
    private void veil$beginPathCreate(
            Set<BlockPos> targets,
            int radiusOffset,
            boolean above,
            int reachRange,
            float maxPathLength,
            CallbackInfoReturnable<Path> cir) {
        if (!VeilDiagnostics.benchmarkActive()) {
            veil$pathCreateStartNs = 0L;
            return;
        }
        veil$pathCreateVillager = mob instanceof Villager;
        veil$pathCreateStartNs = System.nanoTime();
    }

    @Inject(
            method = "createPath(Ljava/util/Set;IZIF)Lnet/minecraft/world/level/pathfinder/Path;",
            at = @At("RETURN"),
            require = 1)
    private void veil$endPathCreate(
            Set<BlockPos> targets,
            int radiusOffset,
            boolean above,
            int reachRange,
            float maxPathLength,
            CallbackInfoReturnable<Path> cir) {
        long start = veil$pathCreateStartNs;
        veil$pathCreateStartNs = 0L;
        if (start != 0L && VeilDiagnostics.benchmarkActive()) {
            VeilServerAiCounters.pathCreate(System.nanoTime() - start, veil$pathCreateVillager);
        }
    }
}
