package dev.veil.revive.client.scene.materials;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.CompareOp;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.VeilMaterialRange;
import dev.veil.revive.mixin.RenderPassAccessor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.DynamicUniformStorage;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.resources.Identifier;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector4f;

import java.nio.ByteBuffer;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.BooleanSupplier;
import java.util.function.Function;

public final class MaterialSceneInputs {
    private static final int DRAW_UBO_BYTES = 80;
    private static final int MAX_DRAW_UNIFORMS = 16_384;
    private final Vector4f MATERIAL_ID_CLEAR = new Vector4f(0.0f, 0.0f, 0.0f, 0.0f);
    private RenderPipeline pipeline;
    private DynamicUniformStorage<MaterialDrawUniform> uniforms;
    private GpuTexture materialId;
    private GpuTextureView materialIdView;
    private GpuTexture materialDepth;
    private GpuTextureView materialDepthView;
    private GpuTexture opaqueColor;
    private GpuTextureView opaqueColorView;
    private GpuTexture opaqueDepth;
    private GpuTextureView opaqueDepthView;
    private int width;
    private int height;
    private GpuFormat colorFormat;
    private GpuFormat depthFormat;
    private final Matrix4f modelView = new Matrix4f();
    private boolean modelViewValid;
    private double capturedCameraX;
    private double capturedCameraY;
    private double capturedCameraZ;
    private boolean capturedThisFrame;
    private boolean materialReady;
    private boolean disabled;
    private boolean logged;
    private long snapshotFrames;
    private long classifiedRanges;
    private long classifiedVertices;
    private long failures;

    private final BooleanSupplier opaqueRequested;
    private final BooleanSupplier materialsRequested;
    private final Function<SectionMesh, VeilMaterialRange[]> materialRanges;

    public MaterialSceneInputs(
            BooleanSupplier opaqueRequested,
            BooleanSupplier materialsRequested,
            Function<SectionMesh, VeilMaterialRange[]> materialRanges) {
        this.opaqueRequested = java.util.Objects.requireNonNull(opaqueRequested);
        this.materialsRequested = java.util.Objects.requireNonNull(materialsRequested);
        this.materialRanges = java.util.Objects.requireNonNull(materialRanges);
    }

    public void beginFrame() {
        capturedThisFrame = false;
        materialReady = false;
        modelViewValid = false;
        capturedCameraX = capturedCameraY = capturedCameraZ = 0.0;
        if (uniforms != null) uniforms.endFrame();
    }

    public void captureModelView(Matrix4fc matrix) {
        if (matrix == null) return;
        Minecraft client = Minecraft.getInstance();
        if (client.gameRenderer == null || client.gameRenderer.mainCamera() == null) return;
        var camera = client.gameRenderer.mainCamera().position();
        if (!Double.isFinite(camera.x) || !Double.isFinite(camera.y) || !Double.isFinite(camera.z))
            return;
        modelView.set(matrix);
        capturedCameraX = camera.x;
        capturedCameraY = camera.y;
        capturedCameraZ = camera.z;
        modelViewValid = true;
    }

    public void beforeTerrainGroup(ChunkSectionLayerGroup group) {
        if (group != ChunkSectionLayerGroup.TRANSLUCENT || disabled || !requested()) return;
        RenderSystem.assertOnRenderThread();
        try {
            RenderTarget scene = Minecraft.getInstance().gameRenderer.mainRenderTarget();
            boolean needOpaque = opaqueRequested.getAsBoolean();
            boolean needMaterials = materialsRequested.getAsBoolean();
            snapshot(scene, needOpaque, needMaterials);
            if (needMaterials) rasterizeFluidMaterials();
            capturedThisFrame = true;
            snapshotFrames++;
        } catch (RuntimeException failure) {
            failures++;
            disabled = true;
            ReviveMod.LOGGER.error(
                    "Veil ABI 6 material host disabled after capture failure", failure);
        }
    }

    public void prepareForShaderGraph() {
        if (disabled || !requested() || capturedThisFrame) return;
        RenderSystem.assertOnRenderThread();
        try {
            RenderTarget scene = Minecraft.getInstance().gameRenderer.mainRenderTarget();
            boolean needOpaque = opaqueRequested.getAsBoolean();
            boolean needMaterials = materialsRequested.getAsBoolean();
            snapshot(scene, needOpaque, needMaterials);
            if (needMaterials) rasterizeFluidMaterials();
            capturedThisFrame = true;
            snapshotFrames++;
        } catch (RuntimeException failure) {
            failures++;
            disabled = true;
            throw failure;
        }
    }

    private boolean requested() {
        return opaqueRequested.getAsBoolean() || materialsRequested.getAsBoolean();
    }

    private void ensureResources(RenderTarget scene, boolean needOpaque, boolean needMaterials) {
        GpuTexture sceneColor = scene.getColorTexture();
        GpuTexture sceneDepth = scene.getDepthTexture();
        if (sceneColor == null)
            throw new IllegalStateException("ABI 6 requires a scene color attachment");
        if (sceneDepth == null)
            throw new IllegalStateException("ABI 6 requires a scene depth attachment");
        int requestedWidth = Math.max(1, scene.width);
        int requestedHeight = Math.max(1, scene.height);
        GpuFormat requestedColor = sceneColor.getFormat();
        GpuFormat requestedDepth = sceneDepth.getFormat();
        boolean incompatible =
                width != 0
                        && (width != requestedWidth
                                || height != requestedHeight
                                || colorFormat != requestedColor
                                || depthFormat != requestedDepth);
        if (incompatible) destroyImages();

        width = requestedWidth;
        height = requestedHeight;
        colorFormat = requestedColor;
        depthFormat = requestedDepth;
        var device = RenderSystem.getDevice();
        int usage =
                GpuTexture.USAGE_RENDER_ATTACHMENT
                        | GpuTexture.USAGE_TEXTURE_BINDING
                        | GpuTexture.USAGE_COPY_SRC
                        | GpuTexture.USAGE_COPY_DST;

        if (needOpaque && opaqueColor == null) {
            opaqueColor =
                    device.createTexture(
                            "Veil ABI6 opaque color", usage, colorFormat, width, height, 1, 1);
            opaqueColorView = device.createTextureView(opaqueColor);
            opaqueDepth =
                    device.createTexture(
                            "Veil ABI6 opaque depth", usage, depthFormat, width, height, 1, 1);
            opaqueDepthView = device.createTextureView(opaqueDepth);
        }
        if (needMaterials && materialId == null) {
            materialId =
                    device.createTexture(
                            "Veil ABI6 material id",
                            usage,
                            GpuFormat.R8_UNORM,
                            width,
                            height,
                            1,
                            1);
            materialIdView = device.createTextureView(materialId);
            materialDepth =
                    device.createTexture(
                            "Veil ABI6 material depth", usage, depthFormat, width, height, 1, 1);
            materialDepthView = device.createTextureView(materialDepth);
            initializePipeline();
        }
    }

    private void snapshot(RenderTarget scene, boolean needOpaque, boolean needMaterials) {
        ensureResources(scene, needOpaque, needMaterials);
        var encoder = RenderSystem.getDevice().createCommandEncoder();
        if (needOpaque) {
            encoder.copyTextureToTexture(
                    scene.getColorTexture(), opaqueColor, 0, 0, 0, 0, 0, width, height);
            encoder.copyTextureToTexture(
                    scene.getDepthTexture(), opaqueDepth, 0, 0, 0, 0, 0, width, height);
        }
        if (needMaterials) {

            encoder.copyTextureToTexture(
                    scene.getDepthTexture(), materialDepth, 0, 0, 0, 0, 0, width, height);
            encoder.clearColorTexture(materialId, MATERIAL_ID_CLEAR);
            materialReady = true;
        }
    }

    private void rasterizeFluidMaterials() {
        if (!modelViewValid) {

            materialReady = true;
            return;
        }
        Minecraft client = Minecraft.getInstance();
        if (client.level == null || client.levelRenderer == null) return;
        var renderer = client.levelRenderer;
        var visible = renderer.visibleSections();
        var dispatcher = renderer.sectionRenderDispatcher();
        if (visible == null || dispatcher == null || visible.isEmpty()) return;

        int maxIndexCount = 0;
        int drawRangeCount = 0;
        for (var section : visible) {
            SectionMesh mesh = section.getSectionMesh();
            VeilMaterialRange[] ranges = materialRanges.apply(mesh);
            if (ranges == null) continue;
            for (VeilMaterialRange range : ranges) {
                maxIndexCount =
                        Math.max(maxIndexCount, Math.multiplyExact(range.vertexCount() / 4, 6));
                drawRangeCount = Math.addExact(drawRangeCount, 1);
            }
        }
        if (maxIndexCount == 0) {
            materialReady = true;
            return;
        }
        if (drawRangeCount > MAX_DRAW_UNIFORMS) {
            throw new IllegalStateException(
                    "ABI 6 material range count exceeds draw-uniform capacity: "
                            + drawRangeCount
                            + " > "
                            + MAX_DRAW_UNIFORMS);
        }

        var auto = RenderSystem.getSequentialBuffer(PrimitiveTopology.QUADS);
        GpuBuffer indexBuffer = auto.getBuffer(maxIndexCount);
        IndexType indexType = auto.type();
        MaterialDrawUniform drawUniform = new MaterialDrawUniform();

        try (RenderPass pass =
                RenderSystem.getDevice()
                        .createCommandEncoder()
                        .createRenderPass(
                                () -> "Veil ABI6 material classification",
                                materialIdView,
                                Optional.empty(),
                                materialDepthView,
                                OptionalDouble.empty())) {
            RenderSystem.bindDefaultUniforms(pass);
            pass.setPipeline(pipeline);
            pass.setIndexBuffer(indexBuffer, indexType);
            var backend = ((RenderPassAccessor) (Object) pass).veil$backend();

            for (var section : visible) {
                SectionMesh mesh = section.getSectionMesh();
                VeilMaterialRange[] ranges = materialRanges.apply(mesh);
                if (ranges == null || ranges.length == 0) continue;
                var origin = section.getRenderOrigin();

                for (VeilMaterialRange range : ranges) {
                    var slice = dispatcher.getRenderSectionSlice(mesh, range.layer());
                    if (slice == null || slice.vertexBuffer() == null) continue;
                    int stride = range.layer().vertexFormat().getVertexSize();
                    int baseVertex =
                            Math.toIntExact(slice.vertexBufferOffset() / stride)
                                    + range.firstVertex();
                    int quadCount = range.vertexCount() / 4;
                    int indexCount = quadCount * 6;
                    if (indexCount <= 0) continue;

                    float relativeX = (float) (origin.getX() - capturedCameraX);
                    float relativeY = (float) (origin.getY() - capturedCameraY);
                    float relativeZ = (float) (origin.getZ() - capturedCameraZ);
                    drawUniform.set(modelView, relativeX, relativeY, relativeZ, range.materialId());
                    GpuBufferSlice ubo = uniforms.writeUniform(drawUniform);
                    pass.setUniform("VeilMaterialDraw", ubo);
                    pass.setVertexBuffer(0, slice.vertexBuffer().slice());
                    backend.drawIndexed(indexCount, 1, 0, baseVertex, 0);
                    classifiedRanges++;
                    classifiedVertices += range.vertexCount();
                }
            }
        }
        materialReady = true;
        if (!logged) {
            logged = true;
            ReviveMod.LOGGER.info(
                    "Veil shader ABI 6 material host ACTIVE: opaque snapshots + exact fluid material ranges");
        }
    }

    private void initializePipeline() {
        if (pipeline != null && uniforms != null) return;
        BindGroupLayout layout =
                BindGroupLayout.builder()
                        .withUniform("VeilMaterialDraw", UniformType.UNIFORM_BUFFER)
                        .build();
        pipeline =
                RenderPipelines.register(
                        RenderPipeline.builder(RenderPipelines.GENERIC_BLOCKS_SNIPPET)
                                .withLocation(id("pipeline/material_classification"))
                                .withVertexShader(id("core/material_classification"))
                                .withFragmentShader(id("core/material_classification"))
                                .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                                .withBindGroupLayout(layout)
                                .withDepthStencilState(
                                        new DepthStencilState(
                                                CompareOp.GREATER_THAN_OR_EQUAL, true, 0.0f, 0.0f))
                                .withColorTargetState(
                                        new ColorTargetState(
                                                Optional.empty(),
                                                GpuFormat.R8_UNORM,
                                                ColorTargetState.WRITE_RED))
                                .withCull(false)
                                .build());
        if (!RenderSystem.getDevice().precompilePipeline(pipeline).isValid()) {
            throw new IllegalStateException("Invalid Veil ABI 6 material classification pipeline");
        }
        uniforms =
                new DynamicUniformStorage<>(
                        "Veil ABI6 material draw constants", DRAW_UBO_BYTES, MAX_DRAW_UNIFORMS);
    }

    private Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }

    public boolean readyOpaque() {
        return !disabled && capturedThisFrame && opaqueColor != null && opaqueDepth != null;
    }

    public boolean readyMaterials() {
        return !disabled && materialReady && materialId != null && materialDepth != null;
    }

    public GpuTexture opaqueColorTexture() {
        requireOpaque();
        return opaqueColor;
    }

    public GpuTextureView opaqueColorView() {
        requireOpaque();
        return opaqueColorView;
    }

    public GpuTexture opaqueDepthTexture() {
        requireOpaque();
        return opaqueDepth;
    }

    public GpuTextureView opaqueDepthView() {
        requireOpaque();
        return opaqueDepthView;
    }

    public GpuTexture materialIdTexture() {
        requireMaterials();
        return materialId;
    }

    public GpuTextureView materialIdView() {
        requireMaterials();
        return materialIdView;
    }

    public GpuTexture materialDepthTexture() {
        requireMaterials();
        return materialDepth;
    }

    public GpuTextureView materialDepthView() {
        requireMaterials();
        return materialDepthView;
    }

    private void requireOpaque() {
        if (!readyOpaque())
            throw new IllegalStateException("ABI 6 opaque scene snapshot is unavailable");
    }

    private void requireMaterials() {
        if (!readyMaterials())
            throw new IllegalStateException("ABI 6 material classification is unavailable");
    }

    public String telemetry() {
        return "material_host_requested="
                + requested()
                + "\nmaterial_host_ready_opaque="
                + readyOpaque()
                + "\nmaterial_host_ready_materials="
                + readyMaterials()
                + "\nmaterial_host_snapshot_frames_total="
                + snapshotFrames
                + "\nmaterial_host_ranges_total="
                + classifiedRanges
                + "\nmaterial_host_vertices_total="
                + classifiedVertices
                + "\nmaterial_capture_resolved_groups_total="
                + FluidMaterialCapture.resolvedGroups()
                + "\nmaterial_capture_unresolved_groups_total="
                + FluidMaterialCapture.unresolvedGroups()
                + "\nmaterial_host_failures_total="
                + failures
                + "\nmaterial_host_disabled="
                + disabled
                + "\n";
    }

    private void destroyImages() {
        if (materialIdView != null) {
            materialIdView.close();
            materialIdView = null;
        }
        if (materialId != null) {
            materialId.close();
            materialId = null;
        }
        if (materialDepthView != null) {
            materialDepthView.close();
            materialDepthView = null;
        }
        if (materialDepth != null) {
            materialDepth.close();
            materialDepth = null;
        }
        if (opaqueColorView != null) {
            opaqueColorView.close();
            opaqueColorView = null;
        }
        if (opaqueColor != null) {
            opaqueColor.close();
            opaqueColor = null;
        }
        if (opaqueDepthView != null) {
            opaqueDepthView.close();
            opaqueDepthView = null;
        }
        if (opaqueDepth != null) {
            opaqueDepth.close();
            opaqueDepth = null;
        }
        width = height = 0;
        colorFormat = depthFormat = null;
    }

    public void close() {
        destroyImages();
        if (uniforms != null) {
            uniforms.close();
            uniforms = null;
        }
        pipeline = null;
        capturedThisFrame = false;
        materialReady = false;
        modelViewValid = false;
        disabled = false;
        logged = false;
    }

    private static final class MaterialDrawUniform implements DynamicUniformStorage.DynamicUniform {
        private final Matrix4f modelView = new Matrix4f();
        private float x, y, z;
        private int materialId;

        void set(Matrix4fc matrix, float x, float y, float z, int materialId) {
            this.modelView.set(matrix);
            this.x = x;
            this.y = y;
            this.z = z;
            this.materialId = materialId;
        }

        @Override
        public void write(ByteBuffer out) {
            int start = out.position();
            modelView.get(start, out);
            out.position(start + 64);
            out.putFloat(x).putFloat(y).putFloat(z).putFloat((float) materialId);
        }
    }
}
