package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.StagingBuffer;
import com.mojang.blaze3d.vertex.TlsfAllocator;
import com.mojang.blaze3d.vertex.UberGpuBuffer;

import dev.veil.revive.core.terrain.AttributeUploadPlan;

import java.util.ArrayList;

public final class VeilCanonicalPendingUpload implements AutoCloseable {
    public final Object source;
    public final TlsfAllocator.Allocation allocation;
    public final long epoch;
    public final UberGpuBuffer.UploadCallback<Object> callback;
    public final AttributeUploadPlan plan;
    public final VeilCanonicalData data;
    public final ArrayList<StagingBuffer.BufferHandle> handles = new ArrayList<>();
    private int reserved;
    public boolean fallback;

    public VeilCanonicalPendingUpload(
            Object source,
            TlsfAllocator.Allocation allocation,
            long epoch,
            UberGpuBuffer.UploadCallback<Object> callback,
            AttributeUploadPlan plan,
            VeilCanonicalData data) {
        this.source = source;
        this.allocation = allocation;
        this.epoch = epoch;
        this.callback = callback;
        this.plan = plan;
        this.data = data;
        reserved = plan.payloadBytes();
    }

    public void releasePatches() {
        for (var handle : handles) handle.close();
        handles.clear();
        VeilCanonicalSparseUploads.release(reserved);
        reserved = 0;
    }

    @Override
    public void close() {
        releasePatches();
        data.close();
    }
}
