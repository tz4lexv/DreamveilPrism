package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.StagingBuffer;

import dev.veil.revive.client.terrain.residency.ManagedGpuArena;

import java.util.function.Consumer;

final class VeilManagedGpuArena<T> extends ManagedGpuArena<T> {
    @Override
    public void maintain() {
        if (!VeilCpuZoneJfrProbe.enabled()) {
            super.maintain();
            return;
        }
        long start = System.nanoTime();
        try {
            super.maintain();
        } finally {
            VeilCpuZoneJfrProbe.record("ARENA_MAINTENANCE", start, System.nanoTime());
        }
    }

    VeilManagedGpuArena(
            String name, int usage, int heapBytes, int alignment, StagingBuffer staging) {
        super(name, usage, heapBytes, alignment, staging, ReviveRuntime::maintenanceBudgetNanos);
    }

    VeilManagedGpuArena(
            String name,
            int usage,
            int heapBytes,
            int alignment,
            StagingBuffer staging,
            int maxArenas) {
        super(
                name,
                usage,
                heapBytes,
                alignment,
                staging,
                maxArenas,
                ReviveRuntime::maintenanceBudgetNanos);
    }

    VeilManagedGpuArena(
            String name,
            int usage,
            int heapBytes,
            int alignment,
            StagingBuffer staging,
            int maxArenas,
            Consumer<RelocationStage> checkpoint) {
        super(
                name,
                usage,
                heapBytes,
                alignment,
                staging,
                maxArenas,
                checkpoint,
                ReviveRuntime::maintenanceBudgetNanos);
    }
}
