package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderPassDescriptor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;

import dev.veil.revive.core.terrain.ParametricTerrainQuads;

import net.minecraft.resources.Identifier;

import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Optional;
import java.util.OptionalDouble;

final class VeilParametricRasterProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.parametricRasterProbe")
                    && Boolean.getBoolean("veil.parametricTerrainGpuProbe")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final int SIZE = 128, CASES = 18;
    private static final GpuFormat[] FORMATS = {
        GpuFormat.RGBA8_UNORM, GpuFormat.RGBA32_FLOAT, GpuFormat.D32_FLOAT
    };
    private static final GpuTexture[] targets = new GpuTexture[3];
    private static final GpuTextureView[] views = new GpuTextureView[3];
    private static final GpuBuffer[] readbacks = new GpuBuffer[3];
    private static final ArrayList<GpuBuffer> owned = new ArrayList<>();
    private static final RenderPipeline[] packedPipelines = new RenderPipeline[4];
    private static RenderPipeline referencePipeline;
    private static GpuFence fence;
    private static int pendingVertices;
    private static long verifiedVertices, captures, coveredPixels;
    private static boolean offsetVerified;
    private static int pendingBase;

    private VeilParametricRasterProbe() {}

    static void capture(
            byte[] source,
            ParametricTerrainQuads.Layout layout,
            GpuBuffer words,
            int baseVertex,
            GpuBuffer sharedIndices,
            IndexType indexType) {
        if (!ENABLED || fence != null || verifiedVertices >= 100000 && offsetVerified) return;
        if (source.length == 0 || source.length % 112 != 0 || source.length > 8 << 20)
            throw new IllegalArgumentException("Invalid raster source");
        pendingVertices = source.length / 28;
        pendingBase = baseVertex;
        try {
            start(source, layout, words, baseVertex, sharedIndices, indexType);
        } catch (RuntimeException | Error failure) {
            closeGpu();
            throw failure;
        }
    }

    private static RenderPipeline pipeline(ParametricTerrainQuads.Layout layout) {
        int slot = layout == null ? -1 : layout.ordinal();
        var bindings =
                BindGroupLayout.builder()
                        .withUniform("VeilRasterProbe", UniformType.UNIFORM_BUFFER);
        if (layout != null)
            bindings.withUniform("VeilQuadWords", UniformType.TEXEL_BUFFER, GpuFormat.R32_SINT);
        var builder =
                RenderPipeline.builder()
                        .withLocation(id("pipeline/raster_probe_" + slot))
                        .withVertexShader(
                                id(
                                        "core/terrain_raster_"
                                                + (layout == null ? "reference" : "parametric")))
                        .withFragmentShader(id("core/terrain_raster_probe"))
                        .withPrimitiveTopology(PrimitiveTopology.TRIANGLES)
                        .withCull(true)
                        .withDepthStencilState(DepthStencilState.DEFAULT)
                        .withBindGroupLayout(bindings.build());
        if (layout == null) builder.withVertexBinding(0, DefaultVertexFormat.BLOCK);
        else {
            builder.withShaderDefine("VEIL_QUAD_WORDS", layout.stride() / 4);
            if (layout.flatColor()) builder.withShaderDefine("VEIL_QUAD_FLAT");
            if (layout.halfUv()) builder.withShaderDefine("VEIL_QUAD_HALF");
        }
        for (int i = 0; i < 2; i++)
            builder.withColorTargetState(
                    i,
                    new ColorTargetState(Optional.empty(), FORMATS[i], ColorTargetState.WRITE_ALL));
        var result = builder.build();
        if (!RenderSystem.getDevice().precompilePipeline(result).isValid())
            throw new IllegalStateException("Raster probe pipeline invalid: " + slot);
        return result;
    }

    private static GpuBuffer upload(String label, int usage, ByteBuffer bytes) {
        var result = RenderSystem.getDevice().createBuffer(() -> label, usage, bytes);
        owned.add(result);
        return result;
    }

    private static void start(
            byte[] source,
            ParametricTerrainQuads.Layout layout,
            GpuBuffer words,
            int baseVertex,
            GpuBuffer sharedIndices,
            IndexType indexType) {
        var device = RenderSystem.getDevice();
        if (referencePipeline == null) referencePipeline = pipeline(null);
        int slot = layout.ordinal();
        if (packedPipelines[slot] == null) packedPipelines[slot] = pipeline(layout);
        var vertices = MemoryUtil.memCalloc(source.length + 112);
        GpuBuffer nativeVertices;
        try {
            vertices.position(112).put(source).position(0);
            nativeVertices =
                    upload("Veil raster native vertices", GpuBuffer.USAGE_VERTEX, vertices);
        } finally {
            MemoryUtil.memFree(vertices);
        }
        int indexCount = pendingVertices / 4 * 6;
        var indices = MemoryUtil.memCalloc((indexCount + 6) * 4);
        GpuBuffer nativeIndices;
        try {
            indices.position(24);
            for (int q = 0; q < pendingVertices / 4; q++) {
                int v = q * 4;
                indices.putInt(v).putInt(v + 1).putInt(v + 2).putInt(v + 2).putInt(v + 3).putInt(v);
            }
            indices.flip();
            nativeIndices =
                    upload("Veil raster independent indices", GpuBuffer.USAGE_INDEX, indices);
        } finally {
            MemoryUtil.memFree(indices);
        }
        for (int i = 0; i < 3; i++) {
            targets[i] =
                    device.createTexture(
                            "Veil raster attachment " + i,
                            GpuTexture.USAGE_RENDER_ATTACHMENT | GpuTexture.USAGE_COPY_SRC,
                            FORMATS[i],
                            SIZE,
                            SIZE,
                            1,
                            1);
            views[i] = device.createTextureView(targets[i]);
            readbacks[i] =
                    device.createBuffer(
                            () -> "Veil raster image comparison",
                            GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                            (long) SIZE * SIZE * FORMATS[i].blockSize() * CASES * 2);
        }
        var sourceBytes = ByteBuffer.wrap(source).order(ByteOrder.LITTLE_ENDIAN);
        float[] min = {Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY};
        float[] max = {Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY};
        for (int v = 0; v < pendingVertices; v++)
            for (int a = 0; a < 3; a++) {
                float value = sourceBytes.getFloat(v * 28 + a * 4);
                min[a] = Math.min(min[a], value);
                max[a] = Math.max(max[a], value);
            }
        float x = (min[0] + max[0]) * .5f, y = (min[1] + max[1]) * .5f, z = (min[2] + max[2]) * .5f;
        var encoder = device.createCommandEncoder();
        for (int view = 0; view < 6; view++) {
            float dx = view / 2 == 0 ? (view % 2 == 0 ? 40 : -40) : 0;
            float dy = view / 2 == 1 ? (view % 2 == 0 ? 40 : -40) : 0;
            float dz = view / 2 == 2 ? (view % 2 == 0 ? 40 : -40) : 0;
            var matrix =
                    new Matrix4f()
                            .ortho(-24, 24, -24, 24, 96, .1f, true)
                            .lookAt(
                                    x + dx,
                                    y + dy,
                                    z + dz,
                                    x,
                                    y,
                                    z,
                                    0,
                                    dy == 0 ? 1 : 0,
                                    dy == 0 ? 0 : 1);
            var uniform = MemoryUtil.memAlloc(64);
            GpuBuffer parameters;
            try {
                matrix.get(0, uniform);
                parameters = upload("Veil raster view", GpuBuffer.USAGE_UNIFORM, uniform);
            } finally {
                MemoryUtil.memFree(uniform);
            }
            for (int mode = 0; mode < 3; mode++)
                for (int route = 0; route < 2; route++) {
                    boolean packed = route == 1;
                    int first = packed ? 0 : 6, base = packed ? baseVertex : 4;
                    var descriptor =
                            RenderPassDescriptor.create(() -> "Veil triangle raster oracle")
                                    .withRenderArea(new RenderPass.RenderArea(0, 0, SIZE, SIZE))
                                    .withColorAttachment(
                                            views[0], Optional.of(new Vector4f(0, 0, 0, 0)))
                                    .withColorAttachment(
                                            views[1], Optional.of(new Vector4f(0, 0, 0, 0)))
                                    .withDepthAttachment(views[2], OptionalDouble.of(0));
                    GpuBuffer commands = null;
                    if (mode == 2) {
                        var indirect = MemoryUtil.memAlloc(20);
                        try {
                            indirect.putInt(indexCount)
                                    .putInt(1)
                                    .putInt(first)
                                    .putInt(base)
                                    .putInt(0)
                                    .flip();
                            commands =
                                    upload(
                                            "Veil raster MDI",
                                            GpuBuffer.USAGE_INDIRECT_PARAMETERS,
                                            indirect);
                        } finally {
                            MemoryUtil.memFree(indirect);
                        }
                    }
                    try (var pass = encoder.createRenderPass(descriptor)) {
                        pass.setPipeline(packed ? packedPipelines[slot] : referencePipeline);
                        pass.setUniform("VeilRasterProbe", parameters);
                        if (packed) pass.setUniform("VeilQuadWords", words);
                        else pass.setVertexBuffer(0, nativeVertices.slice());
                        pass.setIndexBuffer(
                                packed ? sharedIndices : nativeIndices,
                                packed ? indexType : IndexType.INT);
                        switch (mode) {
                            case 0 -> pass.drawIndexed(indexCount, 1, first, base, 0);
                            case 1 -> {
                                var multi = MemoryUtil.memAlloc(12);
                                try {
                                    multi.asIntBuffer().put(first).put(indexCount).put(base).flip();
                                    pass.multiDrawIndexed(multi.asIntBuffer(), 1, 0, 1);
                                } finally {
                                    MemoryUtil.memFree(multi);
                                }
                            }
                            case 2 -> pass.drawIndexedIndirect(commands.slice(), 1);
                            default -> throw new AssertionError();
                        }
                    }
                    int capture = (view * 3 + mode) * 2 + route;
                    for (int i = 0; i < 3; i++)
                        encoder.copyTextureToBuffer(
                                targets[i],
                                readbacks[i],
                                (long) capture * SIZE * SIZE * FORMATS[i].blockSize(),
                                () -> {},
                                0);
                }
        }
        fence = encoder.createFence();
    }

    static void tick() {
        if (!ENABLED || fence == null || !fence.awaitCompletion(0)) return;
        long coverage = 0;
        try {
            for (int channel = 0; channel < 3; channel++)
                try (var mapped = readbacks[channel].map(true, false)) {
                    var bytes = mapped.data();
                    int imageBytes = SIZE * SIZE * FORMATS[channel].blockSize();
                    for (int image = 0; image < CASES; image++) {
                        int a = image * imageBytes * 2, b = a + imageBytes;
                        int direct = (image - image % 3) * imageBytes * 2;
                        for (int i = 0; i < imageBytes; i++)
                            if (bytes.get(a + i) != bytes.get(direct + i))
                                throw new IllegalStateException(
                                        "Raster draw-mode mismatch channel="
                                                + channel
                                                + " view="
                                                + image / 3
                                                + " mode="
                                                + image % 3
                                                + " byte="
                                                + i);
                        for (int i = 0; i < imageBytes; i++)
                            if (bytes.get(a + i) != bytes.get(b + i))
                                throw new IllegalStateException(
                                        "Parametric raster mismatch channel="
                                                + channel
                                                + " view="
                                                + image / 3
                                                + " mode="
                                                + image % 3
                                                + " byte="
                                                + i);
                        if (channel == 2)
                            for (int i = 0; i < imageBytes; i += 4)
                                if (bytes.order(ByteOrder.LITTLE_ENDIAN).getFloat(a + i) > 0)
                                    coverage++;
                    }
                }
            if (coverage == 0) throw new IllegalStateException("Empty triangle raster oracle");
            verifiedVertices += pendingVertices;
            offsetVerified |= pendingBase != 0;
            captures++;
            coveredPixels += coverage;
        } finally {
            closeGpu();
        }
    }

    static void requireComplete() {
        if (!ENABLED) return;
        tick();
        if (verifiedVertices < 100000 || !offsetVerified || fence != null)
            throw new IllegalStateException(
                    "Parametric raster incomplete vertices=" + verifiedVertices);
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil parametric raster: PASS (native_vertices={} captures={} depth_pixels={} six_views=true three_draw_modes=true exact_color_uv_light_depth=true)",
                verifiedVertices,
                captures,
                coveredPixels);
    }

    private static void closeGpu() {
        if (fence != null) fence.close();
        fence = null;
        for (GpuBuffer buffer : owned) buffer.close();
        owned.clear();
        for (int i = 0; i < 3; i++) {
            if (readbacks[i] != null) readbacks[i].close();
            if (views[i] != null) views[i].close();
            if (targets[i] != null) targets[i].close();
            readbacks[i] = null;
            views[i] = null;
            targets[i] = null;
        }
    }

    static void close() {
        closeGpu();
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }
}
