package dev.veil.revive.client;

import dev.veil.revive.core.terrain.IdentityChangeJournal;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;

public final class VeilSectionChanges {
    private static final IdentityChangeJournal<SectionRenderDispatcher.RenderSection> CHANGES =
            new IdentityChangeJournal<>(4096);
    private static final Set<String> INFRASTRUCTURE =
            Set.of("minecraft", "java", "veil", "fabricloader", "mixinextras", "neoforge");
    private static final Set<String> PROVIDERS = new HashSet<>();
    private static final Set<String> FABRIC_API_0157 =
            Set.of(
                    "fabric-api",
                    "fabric-api-base",
                    "fabric-api-lookup-api-v1",
                    "fabric-biome-api-v1",
                    "fabric-block-api-v1",
                    "fabric-block-getter-api-v2",
                    "fabric-client-gametest-api-v1",
                    "fabric-command-api-v2",
                    "fabric-content-registries-v0",
                    "fabric-convention-tags-v2",
                    "fabric-crash-report-info-v1",
                    "fabric-creative-tab-api-v1",
                    "fabric-data-attachment-api-v1",
                    "fabric-data-generation-api-v1",
                    "fabric-debug-api-v1",
                    "fabric-dimensions-v1",
                    "fabric-entity-events-v1",
                    "fabric-events-interaction-v0",
                    "fabric-game-rule-api-v1",
                    "fabric-gametest-api-v1",
                    "fabric-item-api-v1",
                    "fabric-key-mapping-api-v1",
                    "fabric-lifecycle-events-v1",
                    "fabric-loot-api-v3",
                    "fabric-menu-api-v1",
                    "fabric-message-api-v1",
                    "fabric-model-loading-api-v1",
                    "fabric-networking-api-v1",
                    "fabric-object-builder-api-v1",
                    "fabric-particles-v1",
                    "fabric-permission-api-v1",
                    "fabric-recipe-api-v1",
                    "fabric-registry-sync-v0",
                    "fabric-renderer-api-v1",
                    "fabric-renderer-indigo",
                    "fabric-rendering-fluids-v1",
                    "fabric-rendering-v1",
                    "fabric-resource-conditions-api-v1",
                    "fabric-resource-loader-v0",
                    "fabric-resource-loader-v1",
                    "fabric-screen-api-v1",
                    "fabric-serialization-api-v1",
                    "fabric-sound-api-v1",
                    "fabric-tag-api-v1",
                    "fabric-transfer-api-v1",
                    "fabric-transitive-access-wideners-v1");
    private static Set<String> loaded;
    private static boolean supported;
    private static boolean supportDirty = true;
    private static boolean notificationFailure;

    private VeilSectionChanges() {}

    public static synchronized void registerNotificationProvider(String modId) {
        if (modId == null || modId.isBlank()) throw new IllegalArgumentException("Missing mod ID");
        if (PROVIDERS.add(modId)) {
            supportDirty = true;
            changed(null);
        }
    }

    public static void changed(SectionRenderDispatcher.RenderSection section) {
        CHANGES.changed(section);
    }

    static synchronized boolean notificationsSupported() {
        if (notificationFailure) return false;
        if (loaded == null) loaded = VeilPlatform.get().loadedModIds();
        if (supportDirty) {
            var providers = new HashSet<>(PROVIDERS);
            if ("0.157.0+26.2".equals(VeilPlatform.get().modVersion("fabric-api")))
                providers.addAll(FABRIC_API_0157);
            supported = covered(loaded, providers);
            supportDirty = false;
        }
        return supported;
    }

    static synchronized void rejectNotificationCoverage() {
        if (notificationFailure) return;
        notificationFailure = true;
        changed(null);
        dev.veil.revive.ReviveMod.LOGGER.warn(
                "Veil section mutation notifications disagreed with live state; using full resident owner validation for this session");
    }

    static boolean covered(Set<String> loadedMods, Set<String> providers) {
        if (loadedMods.isEmpty()) return false;
        for (String mod : loadedMods)
            if (!INFRASTRUCTURE.contains(mod) && !providers.contains(mod)) return false;
        return true;
    }

    static long current() {
        return CHANGES.revision();
    }

    static boolean visitSince(
            long previous, Consumer<SectionRenderDispatcher.RenderSection> visitor) {
        return CHANGES.visitSince(previous, visitor);
    }
}
