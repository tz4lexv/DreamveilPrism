package dev.veil.api;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

/** Optional renderer declaration for values sampled from Minecraft scene color. */
public final class VeilSceneColor {
    public enum Transfer {
        UNKNOWN,
        LINEAR,
        SRGB
    }

    public enum Primaries {
        UNKNOWN,
        SRGB_REC709_D65
    }

    public record Description(
            Transfer transfer,
            Primaries primaries,
            boolean sceneReferred,
            float preExposure,
            float exposureEv100,
            boolean exposureKnown) {
        public static final Description UNKNOWN =
                new Description(Transfer.UNKNOWN, Primaries.UNKNOWN, false, 0, 0, false);

        public Description {
            Objects.requireNonNull(transfer);
            Objects.requireNonNull(primaries);
            if (!Float.isFinite(preExposure)
                    || !Float.isFinite(exposureEv100)
                    || preExposure < 0
                    || exposureKnown && preExposure <= 0)
                throw new IllegalArgumentException("Invalid scene color exposure");
        }
    }

    @FunctionalInterface
    public interface Provider {
        Description describe();
    }

    public interface Registration extends AutoCloseable {
        @Override
        void close();
    }

    private record Slot(Provider provider) {}

    private static final AtomicReference<Slot> PROVIDER = new AtomicReference<>();

    private VeilSceneColor() {}

    public static Registration register(Provider provider) {
        Slot slot = new Slot(Objects.requireNonNull(provider));
        if (!PROVIDER.compareAndSet(null, slot))
            throw new IllegalStateException("Scene color provider already registered");
        return () -> PROVIDER.compareAndSet(slot, null);
    }

    public static Description description() {
        Slot slot = PROVIDER.get();
        return slot == null
                ? Description.UNKNOWN
                : Objects.requireNonNull(slot.provider().describe());
    }
}
