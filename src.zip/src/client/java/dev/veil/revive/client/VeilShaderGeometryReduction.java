package dev.veil.revive.client;

import dev.veil.revive.platform.VeilPlatform;

import java.util.concurrent.atomic.LongAdder;
import java.util.regex.Pattern;

public final class VeilShaderGeometryReduction {
    private static final boolean SODIUM_LOADED = VeilPlatform.get().isModLoaded("sodium");
    private static final String SODIUM_VERSION = detectSodiumVersion();
    private static final boolean SODIUM_LAYOUT_COMPATIBLE = compatibleVersion(SODIUM_VERSION);

    private static final LongAdder blocks = new LongAdder();
    private static final LongAdder quads = new LongAdder();
    private static final LongAdder opaqueOrCutoutQuads = new LongAdder();
    private static final LongAdder translucentSkipped = new LongAdder();
    private static final LongAdder exactDuplicatesRemoved = new LongAdder();
    private static final LongAdder degenerateRemoved = new LongAdder();
    private static final LongAdder foliageDuplicatesRemoved = new LongAdder();
    private static final LongAdder shaderPackDuplicatesRemoved = new LongAdder();
    private static final LongAdder capacityFallbacks = new LongAdder();
    private static final LongAdder autotuneSuppressedBlocks = new LongAdder();
    private static final LongAdder autotuneProbeWindows = new LongAdder();
    private static final LongAdder autotuneDisableEvents = new LongAdder();
    private static final LongAdder autotuneKeepEvents = new LongAdder();

    private VeilShaderGeometryReduction() {}

    public static boolean sodiumLayoutCompatible() {
        return SODIUM_LOADED && SODIUM_LAYOUT_COMPATIBLE;
    }

    public static String sodiumVersion() {
        return SODIUM_VERSION;
    }

    public static boolean enabled() {
        return sodiumLayoutCompatible()
                && ReviveRuntime.optimizationsEnabled()
                && VeilVideoConfig.flag("renderer.shaderGeometryReduction", true);
    }

    public static void recordBlock() {
        blocks.increment();
    }

    public static void recordQuad() {
        quads.increment();
    }

    public static void recordOpaqueOrCutoutQuad() {
        opaqueOrCutoutQuads.increment();
    }

    public static void recordTranslucentSkip() {
        translucentSkipped.increment();
    }

    public static void recordCapacityFallback() {
        capacityFallbacks.increment();
    }

    public static void recordExactDuplicate(boolean foliage, boolean shaderPackActive) {
        exactDuplicatesRemoved.increment();
        if (foliage) foliageDuplicatesRemoved.increment();
        if (shaderPackActive) shaderPackDuplicatesRemoved.increment();
    }

    public static void recordDegenerate() {
        degenerateRemoved.increment();
    }

    public static void recordAutotuneSuppressedBlock() {
        autotuneSuppressedBlocks.increment();
    }

    public static void recordAutotuneProbeWindow() {
        autotuneProbeWindows.increment();
    }

    public static void recordAutotuneDisable() {
        autotuneDisableEvents.increment();
    }

    public static void recordAutotuneKeep() {
        autotuneKeepEvents.increment();
    }

    public static String telemetry() {
        long duplicate = exactDuplicatesRemoved.sum();
        long degenerate = degenerateRemoved.sum();
        long removed = duplicate + degenerate;
        return "shader_geometry_sodium_loaded="
                + SODIUM_LOADED
                + "\nshader_geometry_sodium_version="
                + SODIUM_VERSION
                + "\nshader_geometry_layout_compatible="
                + SODIUM_LAYOUT_COMPATIBLE
                + "\nshader_geometry_enabled="
                + enabled()
                + "\nshader_geometry_blocks_total="
                + blocks.sum()
                + "\nshader_geometry_quads_total="
                + quads.sum()
                + "\nshader_geometry_opaque_cutout_quads_total="
                + opaqueOrCutoutQuads.sum()
                + "\nshader_geometry_translucent_skipped_total="
                + translucentSkipped.sum()
                + "\nshader_geometry_exact_duplicates_removed_total="
                + duplicate
                + "\nshader_geometry_degenerate_removed_total="
                + degenerate
                + "\nshader_geometry_foliage_duplicates_removed_total="
                + foliageDuplicatesRemoved.sum()
                + "\nshader_geometry_shader_pack_duplicates_removed_total="
                + shaderPackDuplicatesRemoved.sum()
                + "\nshader_geometry_vertices_avoided_total="
                + (removed * 4L)
                + "\nshader_geometry_triangles_avoided_total="
                + (removed * 2L)
                + "\nshader_geometry_capacity_fallbacks_total="
                + capacityFallbacks.sum()
                + "\nshader_geometry_autotune_suppressed_blocks_total="
                + autotuneSuppressedBlocks.sum()
                + "\nshader_geometry_autotune_probe_windows_total="
                + autotuneProbeWindows.sum()
                + "\nshader_geometry_autotune_disable_events_total="
                + autotuneDisableEvents.sum()
                + "\nshader_geometry_autotune_keep_events_total="
                + autotuneKeepEvents.sum();
    }

    private static String detectSodiumVersion() {
        return VeilPlatform.get().modVersion("sodium");
    }

    private static boolean compatibleVersion(String version) {
        return VersionGate.compatible(version);
    }

    static final class VersionGate {
        private static final Pattern SUPPORTED =
                Pattern.compile("0\\.9\\.[12](?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?");

        private VersionGate() {}

        static boolean compatible(String version) {
            return version != null && SUPPORTED.matcher(version).matches();
        }
    }
}
