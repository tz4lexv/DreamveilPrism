package dev.veil.revive.client;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilSceneColor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** ABI21: sampled-source semantics and actual presentation attachment encoding. */
public final class VeilColorPipeline {
    public static final String HOST_ID = "minecraft:color_pipeline";
    public static final int SIZE = 64, MAGIC = 0x56434c31;

    private VeilColorPipeline() {}

    public static void write(
            ByteBuffer target,
            VeilFormat source,
            VeilFormat destination,
            int sourceVk,
            int destinationVk,
            VeilShaderPack.PresentEncoding encoding,
            VeilSceneColor.Description description) {
        if (target.remaining() < SIZE || !source.color() || !destination.color())
            throw new IllegalArgumentException("Invalid color pipeline buffer/format");
        var transfer = description.transfer();
        if (source.srgb()) {
            if (transfer == VeilSceneColor.Transfer.SRGB)
                throw new IllegalArgumentException("sRGB image sampling already decodes to linear");
            transfer = VeilSceneColor.Transfer.LINEAR;
        }
        ByteBuffer b = target.slice().order(ByteOrder.nativeOrder());
        b.putInt(0, MAGIC).putInt(4, 1).putInt(8, sourceVk).putInt(12, destinationVk);
        int range =
                switch (source.numericType()) {
                    case FLOAT -> 2;
                    case UNORM, SNORM, SRGB -> 1;
                    default -> 0;
                };
        int flags = (description.sceneReferred() ? 1 : 0) | (description.exposureKnown() ? 2 : 0);
        b.putInt(16, transfer.ordinal())
                .putInt(20, description.primaries().ordinal())
                .putInt(24, range)
                .putInt(28, flags);
        b.putInt(32, destination.srgb() ? 1 : 0)
                .putInt(36, encoding.ordinal())
                .putInt(40, 0)
                .putInt(44, 0);
        b.putFloat(48, description.exposureKnown() ? description.preExposure() : 0)
                .putFloat(52, description.exposureKnown() ? description.exposureEv100() : 0)
                .putFloat(56, 0)
                .putFloat(60, 0);
    }
}
