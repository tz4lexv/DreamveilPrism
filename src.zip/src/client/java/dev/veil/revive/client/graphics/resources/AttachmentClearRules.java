package dev.veil.revive.client.graphics.resources;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilTransfer;

import java.util.Objects;

/** The typed VkClearColorValue union must match the render target's numeric format. */
public final class AttachmentClearRules {
    private AttachmentClearRules() {}

    /** Minecraft's scene replay clear is floating-point only (Vector4f RenderPass). */
    public static void validateSceneColorTarget(VeilFormat format) {
        validate(format, VeilTransfer.ClearColorType.FLOAT);
    }

    public static void validate(VeilFormat format, VeilTransfer.ClearColorType colorType) {
        Objects.requireNonNull(format, "format");
        Objects.requireNonNull(colorType, "colorType");
        if (!format.color()) {
            throw new IllegalArgumentException(
                    "Graphics color attachment cannot use a depth/stencil format: " + format);
        }
        VeilTransfer.ClearColorType expected =
                switch (format.numericType()) {
                    case UINT -> VeilTransfer.ClearColorType.UINT;
                    case SINT -> VeilTransfer.ClearColorType.SINT;
                    default -> VeilTransfer.ClearColorType.FLOAT;
                };
        if (expected != colorType) {
            throw new IllegalArgumentException(
                    "Graphics color attachment "
                            + format
                            + " requires "
                            + expected
                            + " clear components, got "
                            + colorType);
        }
    }
}
