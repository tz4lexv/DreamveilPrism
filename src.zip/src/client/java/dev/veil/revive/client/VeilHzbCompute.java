package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK12.*;
import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderSystem;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.KHRSynchronization2;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDependencyInfo;
import org.lwjgl.vulkan.VkMemoryBarrier;
import org.lwjgl.vulkan.VkMemoryBarrier2;

import java.io.IOException;
import java.nio.IntBuffer;
import java.util.List;

final class VeilHzbCompute implements AutoCloseable {
    private static final int MAX_MIPS = VeilHzbPyramidCompute.MAX_MIPS;
    private static final int PUSH_WORDS = 6 + MAX_MIPS;

    private final VeilVulkanRuntime runtime;
    private final VeilComputePipeline pipeline;

    VeilHzbCompute(VeilVulkanRuntime runtime) {
        this(runtime, !Boolean.getBoolean("veil.hzbGlsl"));
    }

    VeilHzbCompute(VeilVulkanRuntime runtime, boolean slang) {
        this(runtime, slang, slang && supportsWave(runtime));
    }

    static boolean supportsWave(VeilVulkanRuntime runtime) {
        var limits = VeilShaderDeviceLimits.capture(runtime);
        int operations =
                org.lwjgl.vulkan.VK11.VK_SUBGROUP_FEATURE_BASIC_BIT
                        | org.lwjgl.vulkan.VK11.VK_SUBGROUP_FEATURE_BALLOT_BIT;
        return (limits.subgroupStages() & VK_SHADER_STAGE_COMPUTE_BIT) != 0
                && (limits.subgroupOperations() & operations) == operations;
    }

    VeilHzbCompute(VeilVulkanRuntime runtime, boolean slang, boolean wave) {
        this.runtime = runtime;
        try {
            var spirv = VeilInternalShaders.hzbCull(slang, wave);
            VeilShaderInterface reflected = VeilSpirvReflection.reflect(spirv);
            validateReflectedAbi(reflected);
            VeilShaderDeviceLimits.capture(runtime).validateShaderFeatures(spirv);
            pipeline = VeilComputePipeline.createReflected(runtime, spirv, reflected);
        } catch (IOException | RuntimeException failure) {
            throw new IllegalStateException("HZB compute initialization failed", failure);
        }
    }

    static void validateReflectedAbi(VeilShaderInterface shader) {
        if (shader.descriptors().size() != 10) {
            throw new IllegalStateException(
                    "HZB reflected descriptor count mismatch: " + shader.descriptors().size());
        }
        for (int binding = 0; binding < 10; binding++) {
            final int expectedBinding = binding;
            var descriptor =
                    shader.descriptors().stream()
                            .filter(value -> value.set() == 0 && value.binding() == expectedBinding)
                            .findFirst()
                            .orElseThrow(
                                    () ->
                                            new IllegalStateException(
                                                    "HZB reflection missing set=0 binding="
                                                            + expectedBinding));
            int expectedType =
                    binding == 2 || binding == 3 || binding == 8
                            ? VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
                            : VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
            if (descriptor.descriptorType() != expectedType || descriptor.descriptorCount() != 1) {
                throw new IllegalStateException(
                        "HZB reflected descriptor ABI mismatch at binding=" + binding);
            }
        }
        if (shader.pushConstants().size() != 1
                || shader.pushConstants().getFirst().offset() != 0
                || shader.pushConstants().getFirst().size() != PUSH_WORDS * Integer.BYTES) {
            throw new IllegalStateException(
                    "HZB reflected push-constant ABI mismatch: " + shader.pushConstants());
        }
    }

    void dispatchBatches(
            List<VeilIndirectTerrain.PreparedBatch> batches,
            GpuBufferSlice sections,
            GpuBufferSlice hzb,
            int mode,
            int flags,
            int baseWidth,
            int baseHeight,
            int mipCount,
            int[] mipOffsets) {
        if (batches.isEmpty()) return;

        VkCommandBuffer cmd = runtime.commandBuffer();

        for (var prepared : batches) {
            GpuBufferSlice counterBuffer = prepared.batch().counter();
            vkCmdFillBuffer(
                    cmd,
                    ((com.mojang.blaze3d.vulkan.VulkanGpuBuffer) counterBuffer.buffer()).vkBuffer(),
                    counterBuffer.offset(),
                    counterBuffer.length(),
                    0);
        }
        try (MemoryStack stack = MemoryStack.stackPush()) {
            barrier(
                    cmd,
                    stack,
                    VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                    VK_ACCESS_2_TRANSFER_WRITE_BIT,
                    VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                    VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT);
        }

        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline.handle());
        pushCommonDescriptors(cmd, sections, batches.get(0).uniform(), hzb);

        for (var prepared : batches) {
            var batch = prepared.batch();
            pushBatchDescriptors(
                    cmd,
                    batch.commands(),
                    batch.bounds(),
                    batch.compacted(),
                    batch.counter(),
                    batch.regionBounds());
            int batchFlags = flags | (batch.regionShift << 8);
            pushConstants(
                    cmd,
                    batch.sectionIndices().length,
                    mode,
                    batchFlags,
                    baseWidth,
                    baseHeight,
                    mipCount,
                    mipOffsets);
            vkCmdDispatch(cmd, (batch.sectionIndices().length + 63) / 64, 1, 1);
        }

        try (MemoryStack stack = MemoryStack.stackPush()) {
            barrier(
                    cmd,
                    stack,
                    VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                    VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                    VK_PIPELINE_STAGE_2_DRAW_INDIRECT_BIT,
                    VK_ACCESS_2_INDIRECT_COMMAND_READ_BIT);
        }
        VeilSlangCullProbe.compare(
                runtime,
                batches.getFirst(),
                sections,
                hzb,
                baseWidth,
                baseHeight,
                mipCount,
                mipOffsets);
    }

    void dispatchProbe(
            VeilIndirectTerrain.PreparedBatch prepared,
            GpuBufferSlice sections,
            GpuBufferSlice hzb,
            GpuBufferSlice compacted,
            GpuBufferSlice counter,
            int mode,
            int width,
            int height,
            int mipCount,
            int[] mipOffsets) {
        var cmd = runtime.commandBuffer();
        vkCmdFillBuffer(
                cmd,
                ((com.mojang.blaze3d.vulkan.VulkanGpuBuffer) counter.buffer()).vkBuffer(),
                counter.offset(),
                counter.length(),
                0);
        try (var stack = MemoryStack.stackPush()) {
            barrier(
                    cmd,
                    stack,
                    VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                    VK_ACCESS_2_TRANSFER_WRITE_BIT,
                    VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                    VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT);
        }
        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline.handle());
        pushCommonDescriptors(cmd, sections, prepared.uniform(), hzb);
        var batch = prepared.batch();
        pushBatchDescriptors(
                cmd, batch.commands(), batch.bounds(), compacted, counter, batch.regionBounds());
        pushConstants(
                cmd,
                batch.sectionIndices().length,
                mode,
                3 | (batch.regionShift << 8),
                width,
                height,
                mipCount,
                mipOffsets);
        vkCmdDispatch(cmd, (batch.sectionIndices().length + 63) / 64, 1, 1);
        prepareCountReadback();
    }

    private void pushCommonDescriptors(
            VkCommandBuffer cmd,
            GpuBufferSlice sections,
            GpuBufferSlice frame,
            GpuBufferSlice hzb) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            VeilResourceBindings.allocate(stack, 5)
                    .buffer(1, sections, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
                    .buffer(
                            2,
                            RenderSystem.getProjectionMatrixBuffer(),
                            VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER)
                    .buffer(
                            3,
                            RenderSystem.getGlobalSettingsUniform().slice(),
                            VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER)
                    .buffer(4, hzb, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
                    .buffer(8, frame, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER)
                    .push(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline.layout(), 0);
        }
    }

    private void pushConstants(
            VkCommandBuffer cmd,
            int count,
            int mode,
            int flags,
            int baseWidth,
            int baseHeight,
            int mipCount,
            int[] mipOffsets) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer data = stack.mallocInt(PUSH_WORDS);
            data.put(0, count);
            data.put(1, mode);
            data.put(2, mipCount);
            data.put(3, baseWidth);
            data.put(4, baseHeight);
            data.put(5, flags);
            for (int i = 0; i < MAX_MIPS; i++)
                data.put(6 + i, i < mipOffsets.length ? mipOffsets[i] : 0);
            vkCmdPushConstants(cmd, pipeline.layout(), VK_SHADER_STAGE_COMPUTE_BIT, 0, data);
        }
    }

    private void pushBatchDescriptors(
            VkCommandBuffer cmd,
            GpuBufferSlice commands,
            GpuBufferSlice bounds,
            GpuBufferSlice compacted,
            GpuBufferSlice countBuffer,
            GpuBufferSlice regionBounds) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            VeilResourceBindings.allocate(stack, 5)
                    .buffer(0, commands, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
                    .buffer(5, bounds, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
                    .buffer(6, compacted, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
                    .buffer(7, countBuffer, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
                    .buffer(9, regionBounds, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
                    .push(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline.layout(), 0);
        }
    }

    private static void barrier(
            VkCommandBuffer cmd,
            MemoryStack stack,
            long srcStage,
            long srcAccess,
            long dstStage,
            long dstAccess) {
        if (VeilVulkanCapabilities.synchronization2()) {
            var memory =
                    VkMemoryBarrier2.calloc(1, stack)
                            .sType$Default()
                            .srcStageMask(srcStage)
                            .srcAccessMask(srcAccess)
                            .dstStageMask(dstStage)
                            .dstAccessMask(dstAccess);
            var dependency = VkDependencyInfo.calloc(stack).sType$Default().pMemoryBarriers(memory);
            KHRSynchronization2.vkCmdPipelineBarrier2KHR(cmd, dependency);
            return;
        }

        int legacySrcStage;
        int legacyDstStage;
        int legacySrcAccess;
        int legacyDstAccess;
        if (srcStage == VK_PIPELINE_STAGE_2_TRANSFER_BIT) {
            legacySrcStage = VK10.VK_PIPELINE_STAGE_TRANSFER_BIT;
            legacySrcAccess = VK10.VK_ACCESS_TRANSFER_WRITE_BIT;
        } else {
            legacySrcStage = VK10.VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT;
            legacySrcAccess = VK10.VK_ACCESS_SHADER_WRITE_BIT;
        }
        if (dstStage == VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT) {
            legacyDstStage = VK10.VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT;
            legacyDstAccess = VK10.VK_ACCESS_SHADER_READ_BIT | VK10.VK_ACCESS_SHADER_WRITE_BIT;
        } else if (dstStage == VK_PIPELINE_STAGE_2_DRAW_INDIRECT_BIT) {
            legacyDstStage = VK10.VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT;
            legacyDstAccess = VK10.VK_ACCESS_INDIRECT_COMMAND_READ_BIT;
        } else {
            legacyDstStage = VK10.VK_PIPELINE_STAGE_TRANSFER_BIT;
            legacyDstAccess = VK10.VK_ACCESS_TRANSFER_READ_BIT;
        }
        var memory =
                VkMemoryBarrier.calloc(1, stack)
                        .sType$Default()
                        .srcAccessMask(legacySrcAccess)
                        .dstAccessMask(legacyDstAccess);
        VK10.vkCmdPipelineBarrier(cmd, legacySrcStage, legacyDstStage, 0, memory, null, null);
    }

    void prepareCountReadback() {
        VkCommandBuffer cmd = runtime.commandBuffer();
        try (MemoryStack stack = MemoryStack.stackPush()) {
            barrier(
                    cmd,
                    stack,
                    VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                    VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                    VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                    VK_ACCESS_2_TRANSFER_READ_BIT);
        }
    }

    @Override
    public void close() {
        pipeline.close();
    }
}
