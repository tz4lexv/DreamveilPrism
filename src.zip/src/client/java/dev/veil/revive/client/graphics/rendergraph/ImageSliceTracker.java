package dev.veil.revive.client.graphics.rendergraph;

import dev.veil.revive.client.VeilRenderGraph.Barrier;
import dev.veil.revive.client.VeilRenderGraph.Layout;
import dev.veil.revive.client.VeilRenderGraph.State;
import dev.veil.revive.client.VeilRenderGraph.Subresource;
import dev.veil.revive.client.VeilRenderGraph.Use;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;

/**
 * Keeps Vulkan image-layout state on disjoint mip/layer rectangles. A partial write must not
 * overwrite the state of adjacent mips/layers, and a later whole-image transition must retain each
 * rectangle's actual oldLayout (never a synthetic union of incompatible layouts).
 */
final class ImageSliceTracker {
    private record Rect(int mip, int mipEnd, int layer, int layerEnd) {
        Rect {
            if (mip < 0 || mipEnd <= mip || layer < 0 || layerEnd <= layer)
                throw new IllegalArgumentException("Invalid image rectangle");
        }

        boolean contains(Rect other) {
            return mip <= other.mip
                    && mipEnd >= other.mipEnd
                    && layer <= other.layer
                    && layerEnd >= other.layerEnd;
        }

        boolean intersects(Rect other) {
            return mip < other.mipEnd
                    && other.mip < mipEnd
                    && layer < other.layerEnd
                    && other.layer < layerEnd;
        }

        Subresource subresource(boolean unbounded) {
            if (unbounded
                    && mip == 0
                    && mipEnd == Integer.MAX_VALUE
                    && layer == 0
                    && layerEnd == Integer.MAX_VALUE) return Subresource.WHOLE;
            return Subresource.image(mip, mipEnd - mip, layer, layerEnd - layer);
        }
    }

    private record Tile(Rect rect, State state, State pendingWrite, State visibleRead) {}

    private record Transition(Rect rect, State from, State to) {}

    private record RegionUse(Rect rect, State state, boolean reads) {}

    private final Rect domain;
    private final boolean unbounded;
    private List<Tile> tiles;

    ImageSliceTracker(Subresource range, State initial) {
        Objects.requireNonNull(range, "range");
        Objects.requireNonNull(initial, "initial");
        if (range.bufferRange() || initial.layout() == Layout.NONE)
            throw new IllegalArgumentException("Image tracker requires an image layout and range");
        unbounded = range.whole();
        domain =
                unbounded ? new Rect(0, Integer.MAX_VALUE, 0, Integer.MAX_VALUE) : rectangle(range);
        tiles = List.of(new Tile(domain, initial, initial.write() ? initial : null, null));
    }

    State current() {
        State combined = null;
        for (Tile tile : tiles)
            combined = combined == null ? tile.state : combined.union(tile.state);
        return combined;
    }

    List<dev.veil.revive.client.VeilRenderGraph.ImageState> snapshot() {
        if (unbounded)
            throw new IllegalStateException("Image snapshot requires an allocation extent");
        return tiles.stream()
                .map(
                        tile -> {
                            State source =
                                    tile.pendingWrite == null
                                            ? tile.state
                                            : new State(
                                                    tile.state.stages()
                                                            | tile.pendingWrite.stages(),
                                                    tile.state.access()
                                                            | tile.pendingWrite.access(),
                                                    true,
                                                    tile.state.layout());
                            return new dev.veil.revive.client.VeilRenderGraph.ImageState(
                                    tile.rect.subresource(false), source);
                        })
                .toList();
    }

    List<Barrier> before(String resource, List<Use> uses) {
        var regions = new ArrayList<RegionUse>();
        for (Use use : uses) {
            Rect region = use.subresource().whole() ? domain : rectangle(use.subresource());
            if (!domain.contains(region))
                throw new IllegalArgumentException(
                        "Image use exceeds allocated subresources: "
                                + resource
                                + " "
                                + use.subresource());
            regions.add(new RegionUse(region, State.of(use.access()), use.access().reads()));
        }
        return apply(resource, regions, null, null);
    }

    /** Return externally-owned images only from modified tiles, preserving each source layout. */
    List<Barrier> release(String resource, State initial, State target) {
        if (target == null) return List.of();
        return apply(resource, List.of(), initial, target);
    }

    private List<Barrier> apply(
            String resource, List<RegionUse> uses, State externalInitial, State externalTarget) {
        if (uses.isEmpty() && externalTarget == null) return List.of();
        var mipCuts = new TreeSet<Integer>();
        var layerCuts = new TreeSet<Integer>();
        for (Tile tile : tiles) addCuts(mipCuts, layerCuts, tile.rect);
        for (RegionUse use : uses) addCuts(mipCuts, layerCuts, use.rect);
        var mipCoords = new ArrayList<>(mipCuts);
        var layerCoords = new ArrayList<>(layerCuts);
        var nextTiles = new ArrayList<Tile>();
        var transitions = new ArrayList<Transition>();
        for (int mip = 0; mip < mipCoords.size() - 1; mip++) {
            for (int layer = 0; layer < layerCoords.size() - 1; layer++) {
                Rect cell =
                        new Rect(
                                mipCoords.get(mip),
                                mipCoords.get(mip + 1),
                                layerCoords.get(layer),
                                layerCoords.get(layer + 1));
                if (!domain.contains(cell)) continue;
                Tile previous = null;
                for (Tile tile : tiles) {
                    if (tile.rect.contains(cell)) {
                        previous = tile;
                        break;
                    }
                }
                if (previous == null)
                    throw new IllegalStateException(
                            "Lost image state for " + resource + ": " + cell);
                State requested = null;
                boolean reads = false;
                for (RegionUse use : uses) {
                    if (!use.rect.intersects(cell)) continue;
                    requested = requested == null ? use.state : requested.union(use.state);
                    reads |= use.reads;
                }
                if (externalTarget != null
                        && !previous.state.equals(externalInitial)
                        && !previous.state.equals(externalTarget)) {
                    requested = externalTarget;
                    reads = false;
                }
                if (requested == null) {
                    nextTiles.add(
                            previous.rect.equals(cell)
                                    ? previous
                                    : new Tile(
                                            cell,
                                            previous.state,
                                            previous.pendingWrite,
                                            previous.visibleRead));
                    continue;
                }
                boolean layoutChange =
                        previous.state.layout() != requested.layout()
                                && previous.state.layout() != Layout.NONE
                                && requested.layout() != Layout.NONE;
                State visible = previous.visibleRead;
                boolean uncoveredRead =
                        reads
                                && (visible == null
                                        || (visible.stages() & requested.stages())
                                                != requested.stages()
                                        || (visible.access() & requested.access())
                                                != requested.access());
                if (layoutChange
                        || requested.write()
                        || (previous.pendingWrite != null && uncoveredRead)) {
                    State from =
                            previous.pendingWrite == null
                                    ? previous.state
                                    : new State(
                                            previous.state.stages()
                                                    | previous.pendingWrite.stages(),
                                            previous.state.access()
                                                    | previous.pendingWrite.access(),
                                            true,
                                            previous.state.layout());
                    transitions.add(new Transition(cell, from, requested));
                }
                State write = previous.pendingWrite;
                // Visibility recorded for a previous image layout cannot be carried across
                // a layout transition. Otherwise union() may synthesize GENERAL again.
                State read = layoutChange ? null : previous.visibleRead;
                if (requested.write()) {
                    write = requested;
                    read = null;
                } else if (reads) {
                    read = read == null ? requested : read.union(requested);
                    requested = read;
                }
                nextTiles.add(new Tile(cell, requested, write, read));
            }
        }
        tiles = combineTiles(nextTiles);
        var result = new ArrayList<Barrier>();
        for (Transition transition : combineTransitions(transitions))
            result.add(
                    new Barrier(
                            resource,
                            transition.rect.subresource(unbounded),
                            transition.from,
                            transition.to));
        return List.copyOf(result);
    }

    private static void addCuts(TreeSet<Integer> mips, TreeSet<Integer> layers, Rect rect) {
        mips.add(rect.mip);
        mips.add(rect.mipEnd);
        layers.add(rect.layer);
        layers.add(rect.layerEnd);
    }

    private static Rect rectangle(Subresource value) {
        if (value.whole() || value.bufferRange())
            throw new IllegalArgumentException("Expected finite image subresource");
        return new Rect(
                value.baseMip(),
                value.baseMip() + value.levelCount(),
                value.baseLayer(),
                value.baseLayer() + value.layerCount());
    }

    private static List<Tile> combineTiles(List<Tile> source) {
        var tiles = new ArrayList<>(source);
        boolean merged;
        do {
            merged = false;
            outer:
            for (int i = 0; i < tiles.size(); i++) {
                for (int j = i + 1; j < tiles.size(); j++) {
                    Tile a = tiles.get(i), b = tiles.get(j);
                    if (!a.state.equals(b.state)
                            || !Objects.equals(a.pendingWrite, b.pendingWrite)
                            || !Objects.equals(a.visibleRead, b.visibleRead)) continue;
                    Rect both = merge(a.rect, b.rect);
                    if (both == null) continue;
                    tiles.set(i, new Tile(both, a.state, a.pendingWrite, a.visibleRead));
                    tiles.remove(j);
                    merged = true;
                    break outer;
                }
            }
        } while (merged);
        return List.copyOf(tiles);
    }

    private static List<Transition> combineTransitions(List<Transition> source) {
        var transitions = new ArrayList<>(source);
        boolean merged;
        do {
            merged = false;
            outer:
            for (int i = 0; i < transitions.size(); i++) {
                for (int j = i + 1; j < transitions.size(); j++) {
                    Transition a = transitions.get(i), b = transitions.get(j);
                    if (!a.from.equals(b.from) || !a.to.equals(b.to)) continue;
                    Rect both = merge(a.rect, b.rect);
                    if (both == null) continue;
                    transitions.set(i, new Transition(both, a.from, a.to));
                    transitions.remove(j);
                    merged = true;
                    break outer;
                }
            }
        } while (merged);
        return List.copyOf(transitions);
    }

    private static Rect merge(Rect a, Rect b) {
        if (a.mip == b.mip
                && a.mipEnd == b.mipEnd
                && (a.layerEnd == b.layer || b.layerEnd == a.layer))
            return new Rect(
                    a.mip, a.mipEnd, Math.min(a.layer, b.layer), Math.max(a.layerEnd, b.layerEnd));
        if (a.layer == b.layer
                && a.layerEnd == b.layerEnd
                && (a.mipEnd == b.mip || b.mipEnd == a.mip))
            return new Rect(
                    Math.min(a.mip, b.mip), Math.max(a.mipEnd, b.mipEnd), a.layer, a.layerEnd);
        return null;
    }
}
