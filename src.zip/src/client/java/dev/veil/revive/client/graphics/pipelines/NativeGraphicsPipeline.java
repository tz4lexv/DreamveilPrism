package dev.veil.revive.client.graphics.pipelines;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.api.VeilVertexLayout;
import dev.veil.revive.client.graphics.minecraft.DeferredGpuRetirement;
import dev.veil.revive.client.graphics.minecraft.EnabledRasterFeatures;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.client.graphics.minecraft.VulkanFormats;
import dev.veil.revive.client.graphics.minecraft.VulkanResult;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkFormatProperties;
import org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;
import org.lwjgl.vulkan.VkPipelineColorBlendAttachmentState;
import org.lwjgl.vulkan.VkPipelineColorBlendStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineDepthStencilStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineDynamicStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineInputAssemblyStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineMultisampleStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineRasterizationStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineRenderingCreateInfoKHR;
import org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo;
import org.lwjgl.vulkan.VkPipelineTessellationStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineVertexInputStateCreateInfo;
import org.lwjgl.vulkan.VkPipelineViewportStateCreateInfo;
import org.lwjgl.vulkan.VkVertexInputAttributeDescription;
import org.lwjgl.vulkan.VkVertexInputBindingDescription;

import java.util.function.BooleanSupplier;
import java.util.function.LongSupplier;

public final class NativeGraphicsPipeline implements AutoCloseable {
    private final MinecraftVulkanContext runtime;
    private final LongSupplier layout;
    private final Runnable releaseDependencies;
    private final DeferredGpuRetirement closeRequested = new DeferredGpuRetirement();
    private long pipeline;

    private NativeGraphicsPipeline(
            MinecraftVulkanContext runtime,
            LongSupplier layout,
            Runnable releaseDependencies,
            long pipeline) {
        this.runtime = runtime;
        this.layout = layout;
        this.releaseDependencies = releaseDependencies;
        this.pipeline = pipeline;
    }

    public static NativeGraphicsPipeline create(
            MinecraftVulkanContext runtime,
            VkPipelineShaderStageCreateInfo.Buffer stages,
            LongSupplier layout,
            int[] colorFormats,
            int depthFormat,
            boolean stencil,
            int sampleCount,
            GraphicsPipelineState pipelineState,
            VeilVertexLayout vertexLayout,
            boolean tessellationEnabled,
            LongSupplier pipelineCache,
            Runnable releaseDependencies) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        long pipeline = VK_NULL_HANDLE;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var vertexInput = VkPipelineVertexInputStateCreateInfo.calloc(stack).sType$Default();
            if (pipelineState.fluidGeometry()) {
                var bindings = VkVertexInputBindingDescription.calloc(1, stack);
                bindings.get(0).binding(0).stride(32).inputRate(VK_VERTEX_INPUT_RATE_VERTEX);
                var attributes = VkVertexInputAttributeDescription.calloc(2, stack);
                attributes
                        .get(0)
                        .location(0)
                        .binding(0)
                        .format(VK_FORMAT_R32G32B32_SFLOAT)
                        .offset(0);
                attributes
                        .get(1)
                        .location(1)
                        .binding(0)
                        .format(VK_FORMAT_R32G32B32A32_SINT)
                        .offset(16);
                vertexInput
                        .pVertexBindingDescriptions(bindings)
                        .pVertexAttributeDescriptions(attributes);
            } else if (!vertexLayout.bindings().isEmpty()) {
                var bindings =
                        VkVertexInputBindingDescription.calloc(
                                vertexLayout.bindings().size(), stack);
                for (int index = 0; index < vertexLayout.bindings().size(); index++) {
                    var binding = vertexLayout.bindings().get(index);
                    bindings.get(index)
                            .binding(binding.binding())
                            .stride(binding.stride())
                            .inputRate(
                                    binding.inputRate() == VeilVertexLayout.InputRate.INSTANCE
                                            ? VK_VERTEX_INPUT_RATE_INSTANCE
                                            : VK_VERTEX_INPUT_RATE_VERTEX);
                }
                var attributes =
                        VkVertexInputAttributeDescription.calloc(
                                vertexLayout.attributes().size(), stack);
                for (int index = 0; index < vertexLayout.attributes().size(); index++) {
                    var attribute = vertexLayout.attributes().get(index);
                    attributes
                            .get(index)
                            .location(attribute.location())
                            .binding(attribute.binding())
                            .format(VulkanFormats.vk(attribute.format()))
                            .offset(attribute.offset());
                }
                vertexInput
                        .pVertexBindingDescriptions(bindings)
                        .pVertexAttributeDescriptions(attributes);
            }
            var assembly =
                    VkPipelineInputAssemblyStateCreateInfo.calloc(stack)
                            .sType$Default()
                            .topology(pipelineState.topology())
                            .primitiveRestartEnable(pipelineState.primitiveRestart());
            VkPipelineTessellationStateCreateInfo tessellation = null;
            if (tessellationEnabled) {
                tessellation =
                        VkPipelineTessellationStateCreateInfo.calloc(stack)
                                .sType$Default()
                                .patchControlPoints(pipelineState.patchControlPoints());
            }
            var rasterState = pipelineState.raster();
            var raster =
                    VkPipelineRasterizationStateCreateInfo.calloc(stack)
                            .sType$Default()
                            .depthClampEnable(rasterState.depthClamp())
                            .rasterizerDiscardEnable(rasterState.rasterizerDiscard())
                            .polygonMode(rasterState.polygonMode())
                            .cullMode(rasterState.cullMode())
                            .frontFace(rasterState.frontFace())
                            .depthBiasEnable(rasterState.depthBias())
                            .depthBiasConstantFactor(rasterState.depthBiasConstant())
                            .depthBiasClamp(rasterState.depthBiasClamp())
                            .depthBiasSlopeFactor(rasterState.depthBiasSlope())
                            .lineWidth(rasterState.lineWidth());
            var multisample =
                    VkPipelineMultisampleStateCreateInfo.calloc(stack)
                            .sType$Default()
                            .rasterizationSamples(sampleCount)
                            .sampleShadingEnable(false);
            var depth =
                    VkPipelineDepthStencilStateCreateInfo.calloc(stack)
                            .sType$Default()
                            .depthTestEnable(pipelineState.depth().test())
                            .depthWriteEnable(pipelineState.depth().write())
                            .depthCompareOp(pipelineState.depth().compare())
                            .depthBoundsTestEnable(false)
                            .stencilTestEnable(pipelineState.stencil().enabled());
            if (pipelineState.stencil().enabled()) {
                stencil(depth.front(), pipelineState.stencil().front());
                stencil(depth.back(), pipelineState.stencil().back());
            }
            var colors = pipelineState.colors();
            var attachments = VkPipelineColorBlendAttachmentState.calloc(colors.size(), stack);
            for (int index = 0; index < colors.size(); index++) {
                var color = colors.get(index);
                var blendState = color;
                attachments
                        .get(index)
                        .blendEnable(blendState.enabled())
                        .srcColorBlendFactor(blendState.srcColor())
                        .dstColorBlendFactor(blendState.dstColor())
                        .colorBlendOp(blendState.colorOp())
                        .srcAlphaBlendFactor(blendState.srcAlpha())
                        .dstAlphaBlendFactor(blendState.dstAlpha())
                        .alphaBlendOp(blendState.alphaOp())
                        .colorWriteMask(color.writeMask());
            }
            var blend =
                    VkPipelineColorBlendStateCreateInfo.calloc(stack)
                            .sType$Default()
                            .pAttachments(attachments);
            var viewport =
                    VkPipelineViewportStateCreateInfo.calloc(stack)
                            .sType$Default()
                            .viewportCount(1)
                            .scissorCount(1);
            var dynamics =
                    VkPipelineDynamicStateCreateInfo.calloc(stack)
                            .sType$Default()
                            .pDynamicStates(
                                    stack.ints(
                                            VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR));
            var rendering =
                    VkPipelineRenderingCreateInfoKHR.calloc(stack)
                            .sType$Default()
                            .depthAttachmentFormat(depthFormat)
                            .stencilAttachmentFormat(stencil ? depthFormat : VK_FORMAT_UNDEFINED);
            if (colorFormats.length != 0)
                rendering.pColorAttachmentFormats(stack.ints(colorFormats));
            var info =
                    VkGraphicsPipelineCreateInfo.calloc(1, stack)
                            .sType$Default()
                            .pStages(stages)
                            .pVertexInputState(vertexInput)
                            .pInputAssemblyState(assembly)
                            .pRasterizationState(raster)
                            .pMultisampleState(multisample)
                            .pDepthStencilState(depth)
                            .pColorBlendState(blend)
                            .pViewportState(viewport)
                            .pDynamicState(dynamics)
                            .layout(layout.getAsLong())
                            .pNext(rendering);
            if (tessellation != null) info.pTessellationState(tessellation);
            var out = stack.callocLong(1);
            int result =
                    vkCreateGraphicsPipelines(
                            runtime.vkDevice(), pipelineCache.getAsLong(), info, null, out);
            pipeline = out.get(0);
            VulkanResult.check(result, "vkCreateGraphicsPipelines(Veil creator graphics)");
            return new NativeGraphicsPipeline(runtime, layout, releaseDependencies, pipeline);
        } catch (RuntimeException failure) {
            if (pipeline != VK_NULL_HANDLE) vkDestroyPipeline(runtime.vkDevice(), pipeline, null);
            throw failure;
        }
    }

    public static void validateFeatures(
            MinecraftVulkanContext runtime,
            GraphicsPipelineState state,
            VeilVertexLayout vertexLayout,
            int[] colorFormats,
            int stageFlags,
            MemoryStack stack,
            BooleanSupplier independentBlend) {
        if (((stageFlags & VK_SHADER_STAGE_GEOMETRY_BIT) != 0)
                && !EnabledRasterFeatures.enabled(
                        runtime.vkDevice(), EnabledRasterFeatures.Feature.GEOMETRY)) {
            throw new IllegalArgumentException("Graphics pipeline requires enabled geometryShader");
        }
        if (((stageFlags & VK_SHADER_STAGE_TESSELLATION_CONTROL_BIT) != 0)
                && !EnabledRasterFeatures.enabled(
                        runtime.vkDevice(), EnabledRasterFeatures.Feature.TESSELLATION)) {
            throw new IllegalArgumentException(
                    "Graphics pipeline requires enabled tessellationShader");
        }
        if (((stageFlags & VK_SHADER_STAGE_TESSELLATION_CONTROL_BIT) != 0)) {
            var properties = VkPhysicalDeviceProperties.calloc(stack);
            vkGetPhysicalDeviceProperties(runtime.vkDevice().getPhysicalDevice(), properties);
            if (state.patchControlPoints() > properties.limits().maxTessellationPatchSize()) {
                throw new IllegalArgumentException(
                        "patchControlPoints exceeds the live device limit: requested="
                                + state.patchControlPoints()
                                + " limit="
                                + properties.limits().maxTessellationPatchSize());
            }
        }
        GraphicsPipelineDeviceRules.validatePrimitiveRestart(
                state.primitiveRestart(),
                state.topology() == VK_PRIMITIVE_TOPOLOGY_LINE_STRIP
                        || state.topology() == VK_PRIMITIVE_TOPOLOGY_TRIANGLE_STRIP);
        var raster = state.raster();
        if (raster.polygonMode() != VK_POLYGON_MODE_FILL
                && !EnabledRasterFeatures.enabled(
                        runtime.vkDevice(), EnabledRasterFeatures.Feature.NON_SOLID)) {
            throw new IllegalArgumentException("Graphics pipeline requires fillModeNonSolid");
        }
        if (raster.depthClamp()
                && !EnabledRasterFeatures.enabled(
                        runtime.vkDevice(), EnabledRasterFeatures.Feature.DEPTH_CLAMP)) {
            throw new IllegalArgumentException("Graphics pipeline requires depthClamp");
        }
        if (raster.depthBiasClamp() != 0
                && !EnabledRasterFeatures.enabled(
                        runtime.vkDevice(), EnabledRasterFeatures.Feature.BIAS_CLAMP)) {
            throw new IllegalArgumentException("Graphics pipeline requires depthBiasClamp");
        }
        boolean wideLines =
                EnabledRasterFeatures.enabled(
                        runtime.vkDevice(), EnabledRasterFeatures.Feature.WIDE_LINES);
        var deviceProperties = VkPhysicalDeviceProperties.calloc(stack);
        vkGetPhysicalDeviceProperties(runtime.vkDevice().getPhysicalDevice(), deviceProperties);
        GraphicsPipelineDeviceRules.validateLineWidth(
                raster.lineWidth(),
                wideLines,
                deviceProperties.limits().lineWidthRange(0),
                deviceProperties.limits().lineWidthRange(1));
        var colors = state.colors();
        GraphicsPipelineDeviceRules.validateAttachmentCount(colorFormats.length, colors.size());
        for (int index = 0; index < colors.size(); index++) {
            if (!colors.get(index).enabled()) continue;
            var properties = VkFormatProperties.calloc(stack);
            vkGetPhysicalDeviceFormatProperties(
                    runtime.vkDevice().getPhysicalDevice(), colorFormats[index], properties);
            GraphicsPipelineDeviceRules.validateColorBlend(
                    index,
                    true,
                    (properties.optimalTilingFeatures()
                                    & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BLEND_BIT)
                            != 0);
        }
        if (!independentBlend.getAsBoolean() && colors.size() > 1) {
            var first = colors.getFirst();
            for (int index = 1; index < colors.size(); index++) {
                var color = colors.get(index);
                if (!color.equals(first)) {
                    throw new IllegalArgumentException(
                            "Graphics pipeline requires independentBlend for different MRT blend or write-mask state");
                }
            }
        }
        for (var attribute : vertexLayout.attributes()) {
            var properties = VkFormatProperties.calloc(stack);
            vkGetPhysicalDeviceFormatProperties(
                    runtime.vkDevice().getPhysicalDevice(),
                    VulkanFormats.vk(attribute.format()),
                    properties);
            if ((properties.bufferFeatures() & VK_FORMAT_FEATURE_VERTEX_BUFFER_BIT) == 0) {
                throw new IllegalArgumentException(
                        "Vertex format is unsupported by the live device: " + attribute.format());
            }
        }
    }

    private static void stencil(
            org.lwjgl.vulkan.VkStencilOpState target, GraphicsPipelineState.StencilFace state) {
        target.failOp(state.fail())
                .passOp(state.pass())
                .depthFailOp(state.depthFail())
                .compareOp(state.compare())
                .compareMask(state.compareMask())
                .writeMask(state.writeMask())
                .reference(state.reference());
    }

    public long handle() {
        if (closeRequested.closeRequested() || pipeline == VK_NULL_HANDLE)
            throw new IllegalStateException("Graphics pipeline is closed");
        return pipeline;
    }

    public long layout() {
        if (closeRequested.closeRequested())
            throw new IllegalStateException("Graphics pipeline is closed");
        return layout.getAsLong();
    }

    public void destroyNow() {
        closeRequested.markDestroyed();
        long old = pipeline;
        pipeline = VK_NULL_HANDLE;
        if (old != VK_NULL_HANDLE) vkDestroyPipeline(runtime.vkDevice(), old, null);
        releaseDependencies.run();
    }

    @Override
    public void close() {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        closeRequested.defer(action -> runtime.deferDestroy(action::run), this::destroyNow);
    }
}
