package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;

public interface VeilVertexBufferWriter {
    static VeilVertexBufferWriter tryOf(VertexConsumer consumer) {
        return consumer instanceof VeilVertexBufferWriter writer ? writer : null;
    }

    boolean veil$canPush(VertexFormat sourceFormat);

    int veil$vertexCount();

    void veil$push(long src, int count, VertexFormat sourceFormat);
}
