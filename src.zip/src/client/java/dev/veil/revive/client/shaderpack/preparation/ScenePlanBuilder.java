package dev.veil.revive.client.shaderpack.preparation;

import static dev.veil.revive.client.shaderpack.preparation.BindingValidator.*;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderPack.ColorAttachment;
import dev.veil.revive.client.VeilShaderPack.DepthAttachment;
import dev.veil.revive.client.VeilShaderPack.LoadOp;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.Resource;
import dev.veil.revive.client.VeilShaderPack.Source;
import dev.veil.revive.client.VeilShaderPack.StoreOp;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ScenePlanBuilder {
    private final Map<String, Resource> resources;

    public ScenePlanBuilder(Map<String, Resource> resources) {
        this.resources = resources;
    }

    public VeilRenderGraph.Pass prepare(Pass pass) {
        var uses = new LinkedHashMap<String, VeilRenderGraph.Access>();
        var graphUses = new ArrayList<VeilRenderGraph.Use>();
        if (pass.colors().size() != 1)
            throw new IllegalArgumentException(
                    "Custom scene pass requires exactly one color attachment: " + pass.name());
        ColorAttachment color = pass.colors().getFirst();
        Resource colorTarget = resources.get(color.resource());
        if (colorTarget == null
                || colorTarget.source() != Source.OWNED
                || !colorTarget.renderTarget()
                || !colorTarget.image2d()
                || colorTarget.samples() != 1
                || color.mip() != 0
                || color.layer() != 0) {
            throw new IllegalArgumentException(
                    "Custom scene pass requires an owned single-sample 2D color target: "
                            + pass.name());
        }
        // Vanilla RenderPass and VeilSceneReplay use floating-point clears; they do not
        // support integer attachment clear payloads, even if custom graphics passes do.
        dev.veil.revive.client.graphics.resources.AttachmentClearRules.validateSceneColorTarget(
                colorTarget.format());
        if (color.load() != LoadOp.CLEAR || color.store() != StoreOp.STORE) {
            throw new IllegalArgumentException(
                    "Custom scene color target requires clear/store operations: " + pass.name());
        }
        DepthAttachment depth = pass.depth();
        Resource depthTarget = resources.get(depth.resource());
        if (depthTarget == null
                || depthTarget.source() != Source.OWNED
                || !depthTarget.depthTarget()
                || !depthTarget.image2d()
                || depthTarget.samples() != 1
                || depth.mip() != 0
                || depth.layer() != 0
                || depth.load() != LoadOp.CLEAR
                || depth.store() != StoreOp.STORE
                || !depth.write()) {
            throw new IllegalArgumentException(
                    "Custom scene pass requires an owned writable single-sample 2D depth target: "
                            + pass.name());
        }
        if (colorTarget.resolvedWidth(1, resources) != depthTarget.resolvedWidth(1, resources)
                || colorTarget.resolvedHeight(1, resources)
                        != depthTarget.resolvedHeight(1, resources)) {
            throw new IllegalArgumentException(
                    "Custom scene attachments must have equal dimensions: " + pass.name());
        }
        uses.put(colorTarget.name(), VeilRenderGraph.Access.SCENE_COLOR_WRITE);
        uses.put(depthTarget.name(), VeilRenderGraph.Access.SCENE_DEPTH_WRITE);
        graphUses.add(
                new VeilRenderGraph.Use(
                        colorTarget.name(),
                        VeilRenderGraph.Access.SCENE_COLOR_WRITE,
                        VeilRenderGraph.Subresource.image(0, 1, 0, 1)));
        graphUses.add(
                new VeilRenderGraph.Use(
                        depthTarget.name(),
                        VeilRenderGraph.Access.SCENE_DEPTH_WRITE,
                        VeilRenderGraph.Subresource.image(0, 1, 0, 1)));
        return new VeilRenderGraph.Pass(pass.name(), uses, graphUses, pass.after());
    }
}
