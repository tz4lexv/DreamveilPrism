package dev.veil.revive.client.scene.materials;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.mixin.PbrAnimatedTextureAccessor;
import dev.veil.revive.mixin.PbrAtlasAccessor;
import dev.veil.revive.mixin.PbrFrameInfoAccessor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.function.LongSupplier;

public final class PbrAtlasInputs {
    private record Frame(int current, int next, float blend) {}

    private static final Frame INITIAL_FRAME = new Frame(0, 0, 0);

    private final Map<Identifier, Frame> FRAMES = new HashMap<>();
    private final Map<Identifier, SpriteMaps> MAPS = new HashMap<>();
    private GpuTexture base, normal, specular;
    private GpuTextureView normalView, specularView;
    private long revision, preparedRevision = -1, retainedBytes;

    private static final class SpriteMaps implements AutoCloseable {
        final TextureAtlasSprite sprite;
        NativeImage normal, specular;
        Frame uploaded;

        SpriteMaps(TextureAtlasSprite sprite) {
            this.sprite = sprite;
        }

        public void close() {
            if (normal != null) normal.close();
            if (specular != null) specular.close();
        }
    }

    private final LongSupplier budgetBytes;

    public PbrAtlasInputs(LongSupplier budgetBytes) {
        this.budgetBytes = java.util.Objects.requireNonNull(budgetBytes);
    }

    public void invalidate(TextureAtlas atlas) {
        if (TextureAtlas.LOCATION_BLOCKS.equals(atlas.location())) {
            revision++;
        }
    }

    public void animationFrame(Identifier name, Object animation, int frame, int subFrame) {
        if (name == null || !(animation instanceof PbrAnimatedTextureAccessor info)) return;
        var frames = info.veil$pbrFrames();
        if (frames.isEmpty()) return;
        var current = (PbrFrameInfoAccessor) frames.get(Math.floorMod(frame, frames.size()));
        var next = (PbrFrameInfoAccessor) frames.get(Math.floorMod(frame + 1, frames.size()));
        float blend =
                info.veil$pbrInterpolate()
                        ? Math.clamp(subFrame / (float) Math.max(1, current.veil$pbrTime()), 0, 1)
                        : 0;
        var previous = FRAMES.get(name);
        if (previous == null
                || previous.current() != current.veil$pbrIndex()
                || previous.next() != next.veil$pbrIndex()
                || previous.blend() != blend)
            FRAMES.put(name, new Frame(current.veil$pbrIndex(), next.veil$pbrIndex(), blend));
    }

    public void prepare() {
        prepare(true, true);
    }

    public void prepare(boolean wantNormal, boolean wantSpecular) {
        RenderSystem.assertOnRenderThread();
        if (!wantNormal && !wantSpecular) {
            close();
            return;
        }
        var texture =
                Minecraft.getInstance()
                        .getTextureManager()
                        .getTexture(TextureAtlas.LOCATION_BLOCKS);
        if (!(texture instanceof TextureAtlas atlas))
            throw new IllegalStateException("Block atlas is unavailable");
        if (base != atlas.getTexture()
                || preparedRevision != revision
                || (normal != null) != wantNormal
                || (specular != null) != wantSpecular) rebuild(atlas, wantNormal, wantSpecular);
        CommandEncoder encoder = null;
        for (var entry : MAPS.entrySet()) {
            var maps = entry.getValue();
            var frame = FRAMES.getOrDefault(entry.getKey(), INITIAL_FRAME);
            if (frame.equals(maps.uploaded)) continue;
            if (encoder == null) encoder = RenderSystem.getDevice().createCommandEncoder();
            if (maps.normal != null) {
                try (var tile = tile(maps.sprite, maps.normal, frame, false)) {
                    upload(encoder, normal, tile, maps.sprite.getX(), maps.sprite.getY(), false);
                }
            }
            if (maps.specular != null) {
                try (var tile = tile(maps.sprite, maps.specular, frame, true)) {
                    upload(encoder, specular, tile, maps.sprite.getX(), maps.sprite.getY(), true);
                }
            }
            maps.uploaded = frame;
        }
    }

    private void rebuild(TextureAtlas atlas, boolean wantNormal, boolean wantSpecular) {
        release();
        int width = atlas.getTexture().getWidth(0), height = atlas.getTexture().getHeight(0);
        int mipLevels = PbrMipRules.levels(atlas.getTexture().getMipLevels(), width, height);
        for (var sprite : ((PbrAtlasAccessor) atlas).veil$pbrSprites().values())
            mipLevels =
                    PbrMipRules.spriteLevels(
                            mipLevels,
                            sprite.getX(),
                            sprite.getY(),
                            sprite.contents().width(),
                            sprite.contents().height());
        long atlasBytes =
                PbrMipRules.atlasBytes(width, height, mipLevels, wantNormal, wantSpecular);
        if (atlasBytes > budgetBytes.getAsLong())
            throw new IllegalArgumentException("PBR atlases exceed shader memory budget");
        retainedBytes = atlasBytes;
        try (var normals = wantNormal ? new NativeImage(width, height, false) : null;
                var specs = wantSpecular ? new NativeImage(width, height, false) : null) {
            if (normals != null) normals.fillRect(0, 0, width, height, 0xff8080ff);
            if (specs != null) specs.fillRect(0, 0, width, height, 0xff000a00);
            for (var entry : ((PbrAtlasAccessor) atlas).veil$pbrSprites().entrySet()) {
                var sprite = entry.getValue();
                var maps = new SpriteMaps(sprite);
                MAPS.put(entry.getKey(), maps);
                maps.normal = wantNormal ? load(sprite, "_n") : null;
                maps.specular = wantSpecular ? load(sprite, "_s") : null;
                var frame = FRAMES.getOrDefault(entry.getKey(), INITIAL_FRAME);
                if (maps.normal != null) paste(normals, sprite, maps.normal, frame, false);
                if (maps.specular != null) paste(specs, sprite, maps.specular, frame, true);
                maps.uploaded = frame;
                if (!sprite.isAnimated()) {
                    if (maps.normal != null)
                        retainedBytes -=
                                (long) maps.normal.getWidth() * maps.normal.getHeight() * 4;
                    if (maps.specular != null)
                        retainedBytes -=
                                (long) maps.specular.getWidth() * maps.specular.getHeight() * 4;
                    maps.close();
                    maps.normal = maps.specular = null;
                }
                if (maps.normal == null && maps.specular == null) MAPS.remove(entry.getKey());
            }
            var device = RenderSystem.getDevice();
            int usage = GpuTexture.USAGE_TEXTURE_BINDING | GpuTexture.USAGE_COPY_DST;
            if (wantNormal)
                normal =
                        device.createTexture(
                                "Veil LabPBR normal atlas",
                                usage,
                                GpuFormat.RGBA8_UNORM,
                                width,
                                height,
                                1,
                                mipLevels);
            if (wantSpecular)
                specular =
                        device.createTexture(
                                "Veil LabPBR specular atlas",
                                usage,
                                GpuFormat.RGBA8_UNORM,
                                width,
                                height,
                                1,
                                mipLevels);
            if (normal != null) normalView = device.createTextureView(normal);
            if (specular != null) specularView = device.createTextureView(specular);
            var encoder = device.createCommandEncoder();
            if (normal != null) upload(encoder, normal, normals, 0, 0, false);
            if (specular != null) upload(encoder, specular, specs, 0, 0, true);
            base = atlas.getTexture();
            preparedRevision = revision;
        } catch (RuntimeException | Error error) {
            release();
            throw error;
        }
    }

    private NativeImage load(TextureAtlasSprite sprite, String suffix) {
        var name = sprite.contents().name();
        var path =
                Identifier.fromNamespaceAndPath(
                        name.getNamespace(), "textures/" + name.getPath() + suffix + ".png");
        var resource = Minecraft.getInstance().getResourceManager().getResource(path);
        if (resource.isEmpty()) return null;
        NativeImage image = null;
        try (var input = new java.io.BufferedInputStream(resource.get().open())) {
            input.mark(24);
            byte[] header = input.readNBytes(24);
            input.reset();
            if (header.length != 24) throw new IOException("Truncated PNG header");
            var png = java.nio.ByteBuffer.wrap(header).order(java.nio.ByteOrder.BIG_ENDIAN);
            if (png.getLong(0) != 0x89504e470d0a1a0aL || png.getInt(12) != 0x49484452)
                throw new IOException("PBR maps must be PNG images");
            long width = Integer.toUnsignedLong(png.getInt(16)),
                    height = Integer.toUnsignedLong(png.getInt(20));
            long available = budgetBytes.getAsLong() - retainedBytes;
            if (width == 0
                    || height == 0
                    || width > available / 4
                    || height > available / (width * 4))
                throw new IllegalArgumentException(
                        "PBR image dimensions exceed shader memory budget");
            image = NativeImage.read(input);
            int w = sprite.contents().width(), h = sprite.contents().height();
            if (image.getWidth() % w != 0
                    || image.getHeight() % h != 0
                    || !sprite.isAnimated() && (image.getWidth() != w || image.getHeight() != h))
                throw new IOException("PBR frame dimensions must be multiples of the base sprite");
            long bytes = (long) image.getWidth() * image.getHeight() * 4;
            if (retainedBytes > budgetBytes.getAsLong() - bytes)
                throw new IllegalArgumentException("Animated PBR maps exceed shader memory budget");
            retainedBytes += bytes;
            return image;
        } catch (IOException error) {
            if (image != null) image.close();
            ReviveMod.LOGGER.warn("Invalid PBR map {}: {}", path, error.getMessage());
            return null;
        } catch (RuntimeException | Error error) {
            if (image != null) image.close();
            throw error;
        }
    }

    private static void upload(
            CommandEncoder encoder,
            GpuTexture texture,
            NativeImage source,
            int x,
            int y,
            boolean specular) {
        NativeImage current = source;
        try {
            for (int mip = 0; mip < texture.getMipLevels(); mip++) {
                encoder.writeToTexture(texture, current, mip, 0, x >> mip, y >> mip);
                if (mip + 1 == texture.getMipLevels()) break;
                var next =
                        new NativeImage(
                                Math.max(1, current.getWidth() >> 1),
                                Math.max(1, current.getHeight() >> 1),
                                false);
                try {
                    for (int row = 0; row < next.getHeight(); row++)
                        for (int column = 0; column < next.getWidth(); column++)
                            next.setPixel(
                                    column,
                                    row,
                                    PbrPixels.downsample(
                                            current.getPixel(column * 2, row * 2),
                                            current.getPixel(column * 2 + 1, row * 2),
                                            current.getPixel(column * 2, row * 2 + 1),
                                            current.getPixel(column * 2 + 1, row * 2 + 1),
                                            specular));
                } catch (RuntimeException | Error error) {
                    next.close();
                    throw error;
                }
                if (current != source) current.close();
                current = next;
            }
        } finally {
            if (current != source) current.close();
        }
    }

    private void paste(
            NativeImage atlas,
            TextureAtlasSprite sprite,
            NativeImage source,
            Frame frame,
            boolean spec) {
        try (var tile = tile(sprite, source, frame, spec)) {
            for (int y = 0; y < tile.getHeight(); y++)
                for (int x = 0; x < tile.getWidth(); x++)
                    atlas.setPixel(sprite.getX() + x, sprite.getY() + y, tile.getPixel(x, y));
        }
    }

    private NativeImage tile(
            TextureAtlasSprite sprite, NativeImage source, Frame frame, boolean spec) {
        int width = sprite.contents().width(), height = sprite.contents().height();
        int columns = source.getWidth() / width, count = columns * (source.getHeight() / height);
        int current = frame.current() < count ? frame.current() : 0,
                next = frame.next() < count ? frame.next() : current;
        var tile = new NativeImage(width, height, false);
        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++) {
                int a =
                        source.getPixel(
                                current % columns * width + x, current / columns * height + y);
                int b = source.getPixel(next % columns * width + x, next / columns * height + y);
                tile.setPixel(x, y, PbrPixels.interpolate(a, b, frame.blend(), spec));
            }
        return tile;
    }

    public boolean ready() {
        return normal != null && specular != null;
    }

    public GpuTexture texture(boolean spec) {
        return spec ? specular : normal;
    }

    public GpuTextureView view(boolean spec) {
        return spec ? specularView : normalView;
    }

    public String telemetry() {
        return "pbr_atlas_ready="
                + (normal != null || specular != null)
                + "\npbr_normal_atlas_allocated="
                + (normal != null)
                + "\npbr_specular_atlas_allocated="
                + (specular != null)
                + "\npbr_atlas_retained_bytes="
                + retainedBytes
                + "\npbr_atlas_mip_levels="
                + (normal != null
                        ? normal.getMipLevels()
                        : specular != null ? specular.getMipLevels() : 0);
    }

    public void close() {
        release();
        FRAMES.clear();
    }

    private void release() {
        MAPS.values().forEach(SpriteMaps::close);
        MAPS.clear();
        if (normalView != null) normalView.close();
        if (specularView != null) specularView.close();
        if (normal != null) normal.close();
        if (specular != null) specular.close();
        normalView = specularView = null;
        normal = specular = base = null;
        retainedBytes = 0;
        preparedRevision = -1;
    }
}
