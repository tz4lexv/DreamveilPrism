package dev.veil.revive.client;

import com.google.gson.GsonBuilder;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.api.VeilCreatorScene;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.lang.management.ManagementFactory;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.util.*;

final class VeilCreatorHostPerformanceProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.creatorHostPerformanceProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final int SAMPLES = 240;
    private static final boolean ALL_FIRST = Boolean.getBoolean("veil.creatorHostProfileAllFirst");
    private static final int WARMUP = Integer.getInteger("veil.creatorHostProfileWarmup", 120);
    private static final int INITIAL_WARMUP =
            Integer.getInteger("veil.creatorHostProfileInitialWarmup", WARMUP);
    private static final List<VeilCreatorScene.Registration> REGISTRATIONS =
            ENABLED ? new ArrayList<>() : List.of();
    private static final List<Map<String, Object>> RESULTS =
            ENABLED ? new ArrayList<>() : List.of();
    private static final long[] TIMES = ENABLED ? new long[SAMPLES] : null,
            ALLOCATIONS = ENABLED ? new long[SAMPLES] : null,
            INTERVALS = ENABLED ? new long[SAMPLES] : null;
    private static final com.sun.management.ThreadMXBean MEMORY =
            ENABLED ? (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean() : null;
    private static int stage, frames, samples;
    private static long started, cpuStart, allocationStart, previousFrameStart, frameInterval;
    private static boolean complete, registered, pending, changing, armed;
    private static VeilShaderPackRuntime previous;

    static boolean enabled() {
        return ENABLED;
    }

    static void timeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 240_000_000_000L)
            fail(new IllegalStateException("Creator host profiling timed out or execution failed"));
    }

    static void begin(VeilShaderPackRuntime active) {
        armed = false;
        if (!ENABLED || complete || pending || !VeilBenchmarkWorld.terrainReady()) return;
        if (changing && active == previous) return;
        changing = false;
        if (!registered) {
            registered = true;
            if (!MEMORY.isThreadAllocatedMemorySupported())
                throw new IllegalStateException("Thread allocation measurement unavailable");
            MEMORY.setThreadAllocatedMemoryEnabled(true);
            for (int i = 0; i < 512; i++)
                REGISTRATIONS.add(
                        VeilCreatorScene.registerMaterial(
                                new VeilCreatorScene.Material(
                                        i + 10000, .8f, .7f, .6f, 1, 0, 0, 0, .5f, 0, 1.5f, 0, 1, 0,
                                        0, 0, 0, 0)));
        }
        frames++;
        long now = System.nanoTime();
        frameInterval = previousFrameStart == 0 ? 0 : now - previousFrameStart;
        previousFrameStart = now;
        if (frames <= (stage == 0 ? INITIAL_WARMUP : WARMUP)) return;
        allocationStart = MEMORY.getThreadAllocatedBytes(Thread.currentThread().threadId());
        cpuStart = System.nanoTime();
        armed = true;
    }

    static void end() {
        if (!armed) return;
        long end = System.nanoTime();
        TIMES[samples] = end - cpuStart;
        ALLOCATIONS[samples] =
                MEMORY.getThreadAllocatedBytes(Thread.currentThread().threadId()) - allocationStart;
        INTERVALS[samples] = frameInterval;
        samples++;
        armed = false;
    }

    static void afterScene(VeilShaderPackRuntime active) {
        if (!ENABLED || complete || pending || samples < SAMPLES) return;
        pending = true;
        var buffer =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Creator host profiling proof",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                16);
        try {
            active.readOutput(
                    "proof",
                    buffer,
                    () -> {
                        try (var mapped = buffer.map(true, false)) {
                            var bytes = mapped.data().order(ByteOrder.nativeOrder());
                            float lights = bytes.getFloat(0),
                                    instances = bytes.getFloat(4),
                                    materials = bytes.getFloat(8);
                            if (lights < 2
                                    || (requiresAll() && materials != 518)
                                    || bytes.getFloat(12) != 1)
                                throw new IllegalStateException(
                                        "Creator resource header not observed on GPU");
                            Map<String, Object> result = new LinkedHashMap<>();
                            result.put("stage", stage);
                            result.put(
                                    "requested_resources",
                                    requiresAll() ? "lights_instances_materials" : "lights_only");
                            result.put("samples", samples);
                            result.put("registered_materials", 512);
                            result.put("cpu_prepare_ns", TIMES.clone());
                            result.put("thread_allocated_bytes", ALLOCATIONS.clone());
                            result.put("frame_intervals_ns", INTERVALS.clone());
                            result.put("cpu_prepare_p50_ns", percentile(TIMES, .50));
                            result.put("cpu_prepare_p95_ns", percentile(TIMES, .95));
                            result.put("cpu_prepare_p99_ns", percentile(TIMES, .99));
                            result.put("allocated_bytes_p50", percentile(ALLOCATIONS, .50));
                            result.put("gpu_header", new float[] {lights, instances, materials});
                            RESULTS.add(result);
                            ReviveMod.LOGGER.info(
                                    "Creator host profile stage={} resources={} cpu_p50_ns={} alloc_p50={}",
                                    stage,
                                    result.get("requested_resources"),
                                    result.get("cpu_prepare_p50_ns"),
                                    result.get("allocated_bytes_p50"));
                            if (stage == 5) {
                                var path =
                                        VeilPlatform.get()
                                                .getGameDir()
                                                .resolve("logs/creator-host-profile.json");
                                Files.writeString(
                                        path,
                                        new GsonBuilder()
                                                .setPrettyPrinting()
                                                .create()
                                                .toJson(RESULTS));
                                complete = true;
                                REGISTRATIONS.forEach(VeilCreatorScene.Registration::close);
                                REGISTRATIONS.clear();
                                ReviveMod.LOGGER.info(
                                        "Veil creator host profile: PASS stages=6 GPU headers verified; timings are host preparation, not an optimization result");
                                Minecraft.getInstance().stop();
                            } else {
                                stage++;
                                frames = 0;
                                samples = 0;
                                pending = false;
                                changing = true;
                                previous = active;
                                previousFrameStart = 0;
                                VeilShaderService.select(
                                        requiresAll() ? "creatorhostall" : "creatorhostlights");
                            }
                        } catch (Exception error) {
                            fail(error);
                        } finally {
                            buffer.close();
                        }
                    });
        } catch (Exception error) {
            buffer.close();
            fail(error);
        }
    }

    private static boolean requiresAll() {
        return (stage % 2 == 0) == ALL_FIRST;
    }

    private static long percentile(long[] values, double quantile) {
        long[] sorted = values.clone();
        Arrays.sort(sorted);
        return sorted[(int) Math.ceil(sorted.length * quantile) - 1];
    }

    private static void fail(Throwable failure) {
        complete = true;
        REGISTRATIONS.forEach(VeilCreatorScene.Registration::close);
        REGISTRATIONS.clear();
        ReviveMod.LOGGER.error("Veil creator host profile: FAIL", failure);
        Minecraft.getInstance().stop();
    }
}
