package dev.veil.revive.client.terrain.indirect;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

import org.lwjgl.system.MemoryUtil;

public class TerrainBatchStorage implements AutoCloseable {
    public final ChunkSectionLayer layer;
    public final java.nio.IntBuffer directCommands;
    private boolean closed;
    public final GpuBuffer vertices, indices;
    public final GpuBufferSlice vertexSlice;
    public final IndexType indexType;
    public final int[] sectionIndices, indexCounts, firstIndices, baseVertices;
    public final boolean lod;
    public final int commandsOffset,
            boundsOffset,
            regionBoundsOffset,
            regionCount,
            regionShift,
            compactedOffset,
            countOffset,
            allocationSize;
    private GpuBufferSlice commands, compacted, count, counter, bounds, regionBounds;

    public TerrainBatchStorage(
            ChunkSectionLayer layer,
            GpuBuffer vertices,
            GpuBuffer indices,
            IndexType indexType,
            int[] sectionIndices,
            boolean lod,
            int draws,
            int regionShift,
            int alignment) {
        this.layer = layer;
        this.directCommands = MemoryUtil.memAllocInt(draws * 3);
        this.vertices = vertices;
        this.indices = indices;
        this.vertexSlice = vertices.slice();
        this.indexType = indexType;
        this.sectionIndices = sectionIndices;
        this.indexCounts = new int[draws];
        this.firstIndices = new int[draws];
        this.baseVertices = new int[draws];
        this.lod = lod;
        this.regionShift = regionShift;
        commandsOffset = 0;
        boundsOffset = align(commandsOffset + draws * 20, alignment);
        int regionSpan = 1 << regionShift;
        regionCount = (draws + regionSpan - 1) / regionSpan;
        regionBoundsOffset = align(boundsOffset + draws * 32, alignment);
        compactedOffset = align(regionBoundsOffset + regionCount * 32, alignment);
        countOffset = align(compactedOffset + draws * 20, alignment);
        allocationSize = align(countOffset + 16, alignment);
    }

    private static int align(int n, int a) {
        return (n + a - 1) & -a;
    }

    public final void bind(GpuBuffer gpu, long base) {
        commands = gpu.slice(base + commandsOffset, (long) sectionIndices.length * 20);
        bounds = gpu.slice(base + boundsOffset, (long) sectionIndices.length * 32);
        regionBounds = gpu.slice(base + regionBoundsOffset, (long) regionCount * 32);
        compacted = gpu.slice(base + compactedOffset, (long) sectionIndices.length * 20);
        counter = gpu.slice(base + countOffset, 16);
        count = counter.slice(0, 4);
    }

    public final void unbind() {
        commands = compacted = count = counter = bounds = regionBounds = null;
    }

    public final GpuBufferSlice commands() {
        return commands;
    }

    public final GpuBufferSlice bounds() {
        return bounds;
    }

    public final GpuBufferSlice regionBounds() {
        return regionBounds;
    }

    public final GpuBufferSlice compacted() {
        return compacted;
    }

    public final GpuBufferSlice count() {
        return count;
    }

    public final GpuBufferSlice counter() {
        return counter;
    }

    public final GpuBuffer vertices() {
        return vertices;
    }

    public final GpuBuffer indices() {
        return indices;
    }

    public final IndexType indexType() {
        return indexType;
    }

    public final int[] sectionIndices() {
        return sectionIndices;
    }

    public final boolean lod() {
        return lod;
    }

    @Override
    public final void close() {
        if (!closed) MemoryUtil.memFree(directCommands);
        closed = true;
    }
}
