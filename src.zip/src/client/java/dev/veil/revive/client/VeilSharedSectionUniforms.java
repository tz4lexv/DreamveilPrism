package dev.veil.revive.client;

import net.minecraft.client.renderer.DynamicUniforms;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;

import java.util.ArrayList;

public final class VeilSharedSectionUniforms {
    private static final int SLOT_COUNT = 8;

    private final FrameSlot[] slots = new FrameSlot[SLOT_COUNT];
    private int slotIndex = -1;
    private FrameSlot current;
    private boolean metrics;
    private long matrixCopies, matrixCopiesAvoided, recordsReused, recordsCreated;

    public VeilSharedSectionUniforms() {
        for (int i = 0; i < slots.length; i++) slots[i] = new FrameSlot();
    }

    public void begin(Matrix4fc source) {
        metrics = VeilTechniqueCounters.collecting();
        slotIndex = (slotIndex + 1) % slots.length;
        current = slots[slotIndex];
        current.count = 0;
        if (!current.cameraValid || !current.camera.equals(source)) {
            current.camera.set(source);
            current.cameraValid = true;
            if (metrics) matrixCopies++;
        } else {
            if (metrics) matrixCopiesAvoided++;
        }
    }

    public int add(int x, int y, int z, float visibility, int atlasWidth, int atlasHeight) {
        if (current == null) throw new IllegalStateException("begin() must be called before add()");
        int index = current.count++;
        if (index > 0 && metrics) matrixCopiesAvoided++;
        DynamicUniforms.ChunkSectionInfo old =
                index < current.records.size() ? current.records.get(index) : null;
        if (old != null
                && old.modelView() == current.camera
                && old.x() == x
                && old.y() == y
                && old.z() == z
                && Float.floatToIntBits(old.visibility()) == Float.floatToIntBits(visibility)
                && old.textureAtlasWidth() == atlasWidth
                && old.textureAtlasHeight() == atlasHeight) {
            if (metrics) recordsReused++;
        } else {
            var next =
                    new DynamicUniforms.ChunkSectionInfo(
                            current.camera, x, y, z, visibility, atlasWidth, atlasHeight);
            if (old == null) current.records.add(next);
            else current.records.set(index, next);
            if (metrics) recordsCreated++;
        }
        return index;
    }

    public DynamicUniforms.ChunkSectionInfo[] finish() {
        if (current == null) return new DynamicUniforms.ChunkSectionInfo[0];
        if (current.records.size() > current.count) {
            current.records.subList(current.count, current.records.size()).clear();
        }
        if (current.upload.length != current.count) {
            current.upload = new DynamicUniforms.ChunkSectionInfo[current.count];
        }
        for (int i = 0; i < current.count; i++) current.upload[i] = current.records.get(i);
        return current.upload;
    }

    public void clear() {
        for (FrameSlot slot : slots) slot.clear();
        slotIndex = -1;
        current = null;
    }

    public Snapshot snapshot() {
        return new Snapshot(matrixCopies, matrixCopiesAvoided, recordsReused, recordsCreated);
    }

    private static final class FrameSlot {
        final ArrayList<DynamicUniforms.ChunkSectionInfo> records = new ArrayList<>();
        DynamicUniforms.ChunkSectionInfo[] upload = new DynamicUniforms.ChunkSectionInfo[0];
        final Matrix4f camera = new Matrix4f();
        boolean cameraValid;
        int count;

        void clear() {
            records.clear();
            upload = new DynamicUniforms.ChunkSectionInfo[0];
            camera.identity();
            cameraValid = false;
            count = 0;
        }
    }

    public record Snapshot(
            long matrixCopies, long matrixCopiesAvoided, long recordsReused, long recordsCreated) {
        public Snapshot minus(Snapshot before) {
            return new Snapshot(
                    matrixCopies - before.matrixCopies,
                    matrixCopiesAvoided - before.matrixCopiesAvoided,
                    recordsReused - before.recordsReused,
                    recordsCreated - before.recordsCreated);
        }

        public Snapshot plus(Snapshot other) {
            return new Snapshot(
                    matrixCopies + other.matrixCopies,
                    matrixCopiesAvoided + other.matrixCopiesAvoided,
                    recordsReused + other.recordsReused,
                    recordsCreated + other.recordsCreated);
        }
    }
}
