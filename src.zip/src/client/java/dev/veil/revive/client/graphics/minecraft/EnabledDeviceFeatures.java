package dev.veil.revive.client.graphics.minecraft;

import com.mojang.blaze3d.vulkan.VulkanBackend;
import com.mojang.blaze3d.vulkan.init.VulkanFeature;

import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkPhysicalDeviceFeatures;
import org.lwjgl.vulkan.VkPhysicalDeviceFeatures2;
import org.lwjgl.vulkan.VkPhysicalDeviceVulkan12Features;

import java.lang.ref.WeakReference;
import java.util.Set;

public final class EnabledDeviceFeatures {
    public static final VulkanFeature SHADER_INT64 =
            new VulkanFeature(
                    VulkanBackend.VK10_FEATURES_STRUCT,
                    "shaderInt64",
                    VkPhysicalDeviceFeatures.SHADERINT64);
    public static final VulkanFeature BUFFER_INT64_ATOMICS =
            new VulkanFeature(
                    VulkanBackend.VK12_FEATURES_STRUCT,
                    "shaderBufferInt64Atomics",
                    VkPhysicalDeviceVulkan12Features.SHADERBUFFERINT64ATOMICS);
    public static final VulkanFeature SHARED_INT64_ATOMICS =
            new VulkanFeature(
                    VulkanBackend.VK12_FEATURES_STRUCT,
                    "shaderSharedInt64Atomics",
                    VkPhysicalDeviceVulkan12Features.SHADERSHAREDINT64ATOMICS);

    private record Snapshot(
            WeakReference<VkDevice> device, Set<VulkanFeature> features, Set<String> names) {}

    private static volatile Snapshot snapshot;

    private EnabledDeviceFeatures() {}

    public static void requestInt64IfSupported(
            VkPhysicalDeviceFeatures2 supported, Set<VulkanFeature> requested) {
        if (SHADER_INT64.get(supported)) requested.add(SHADER_INT64);
    }

    public static void requestInt64AtomicsIfSupported(
            VkPhysicalDeviceFeatures2 supported, Set<VulkanFeature> requested) {
        // Atomic pointer types also require Int64 arithmetic. Never infer one storage
        // class from the other, or enable atomics without its scalar type.
        if (!SHADER_INT64.get(supported)) return;
        if (BUFFER_INT64_ATOMICS.get(supported)) {
            requested.add(SHADER_INT64);
            requested.add(BUFFER_INT64_ATOMICS);
        }
        if (SHARED_INT64_ATOMICS.get(supported)) {
            requested.add(SHADER_INT64);
            requested.add(SHARED_INT64_ATOMICS);
        }
    }

    public static void record(VkDevice device, Set<VulkanFeature> enabled) {
        snapshot =
                new Snapshot(
                        new WeakReference<>(device), Set.copyOf(enabled), selectedNames(enabled));
    }

    public static Set<String> selectedNames(Set<VulkanFeature> enabled) {
        var names = new java.util.HashSet<String>();
        for (VulkanFeature feature : enabled) names.add(feature.name());
        return Set.copyOf(names);
    }

    public static boolean enabled(VkDevice device, String name) {
        Snapshot current = snapshot;
        return device != null
                && current != null
                && current.device().get() == device
                && current.names().contains(name);
    }

    public static boolean enabledOnCurrentDevice(String name) {
        var device = MinecraftVulkanContext.currentDeviceOrNull();
        return device != null && enabled(device.vkDevice(), name);
    }

    public static Set<String> publicNames(VkDevice device) {
        Snapshot current = snapshot;
        return device != null && current != null && current.device().get() == device
                ? current.names()
                : Set.of();
    }

    public static boolean enabled(VkDevice device, VulkanFeature feature) {
        Snapshot current = snapshot;
        return device != null
                && current != null
                && current.device().get() == device
                && current.features().contains(feature);
    }

    public static boolean enabledOnCurrentDevice(VulkanFeature feature) {
        var device = MinecraftVulkanContext.currentDeviceOrNull();
        return device != null && enabled(device.vkDevice(), feature);
    }
}
