package dev.veil.revive.client.graphics.resources;

import dev.veil.api.VeilTransfer;
import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderPack.Resource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class TransferWriteOrdering {
    private record Write(String resource, VeilRenderGraph.Subresource range) {}

    private TransferWriteOrdering() {}

    public static boolean[] plan(List<VeilTransfer> operations, Map<String, Resource> resources) {
        boolean[] barriers = new boolean[operations.size()];
        var pending = new ArrayList<Write>();
        for (int index = 0; index < operations.size(); index++) {
            VeilTransfer operation = operations.get(index);
            VeilRenderGraph.Subresource range;
            switch (operation.kind()) {
                case BUFFER_COPY, BUFFER_FILL ->
                        range =
                                VeilRenderGraph.Subresource.buffer(
                                        operation.destinationOffset(), operation.size());
                case IMAGE_TO_BUFFER -> {
                    Resource source = resources.get(operation.source());
                    var region = operation.sourceRegion();
                    var layout = operation.bufferLayout();
                    long bytes =
                            (layout == null ? new VeilTransfer.BufferLayout(0, 0) : layout)
                                    .requiredBytes(
                                            region.width(),
                                            region.height(),
                                            source.image3d() ? region.depth() : region.layerCount(),
                                            source.format().bytesPerTexel());
                    range =
                            VeilRenderGraph.Subresource.buffer(
                                    operation.destinationOffset(), bytes);
                }
                default -> {
                    var region = operation.destinationRegion();
                    range =
                            VeilRenderGraph.Subresource.image(
                                    region.mip(), 1, region.baseLayer(), region.layerCount());
                }
            }
            var current = new Write(operation.destination(), range);
            for (Write previous : pending) {
                if (previous.resource().equals(current.resource())
                        && previous.range().overlaps(current.range())) {
                    barriers[index] = true;
                    pending.clear();
                    break;
                }
            }
            pending.add(current);
        }
        return barriers;
    }
}
