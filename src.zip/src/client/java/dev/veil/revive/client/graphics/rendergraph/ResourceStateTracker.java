package dev.veil.revive.client.graphics.rendergraph;

import dev.veil.revive.client.VeilRenderGraph.Barrier;
import dev.veil.revive.client.VeilRenderGraph.Kind;
import dev.veil.revive.client.VeilRenderGraph.Layout;
import dev.veil.revive.client.VeilRenderGraph.Pass;
import dev.veil.revive.client.VeilRenderGraph.State;
import dev.veil.revive.client.VeilRenderGraph.Subresource;
import dev.veil.revive.client.VeilRenderGraph.Use;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Explicit image and buffer resources use precise disjoint trackers. The older implicit
 * resource-state path remains for callers that construct a Tracker without initialize().
 */
public final class ResourceStateTracker {
    private record SliceState(Subresource subresource, State state) {}

    private final Map<String, ImageSliceTracker> images = new LinkedHashMap<>();
    private final Map<String, BufferSliceTracker> buffers = new LinkedHashMap<>();
    private final Map<String, List<SliceState>> states = new LinkedHashMap<>();
    private final Map<String, List<SliceState>> pendingWrites = new LinkedHashMap<>();
    private final Map<String, Map<Subresource, State>> visibleReads = new LinkedHashMap<>();

    public void initialize(String resource, State state) {
        initialize(resource, Subresource.WHOLE, state);
    }

    public void initialize(String resource, Subresource subresource, State state) {
        initialize(
                resource,
                subresource,
                state,
                state.layout() == Layout.NONE ? Kind.BUFFER : Kind.IMAGE);
    }

    public void initialize(String resource, Subresource subresource, State state, Kind kind) {
        if (kind == Kind.IMAGE) {
            images.put(resource, new ImageSliceTracker(subresource, state));
            buffers.remove(resource);
        } else {
            images.remove(resource);
            buffers.put(resource, new BufferSliceTracker(subresource, state));
        }
        states.remove(resource);
        pendingWrites.remove(resource);
        visibleReads.remove(resource);
    }

    public State current(String resource) {
        ImageSliceTracker image = images.get(resource);
        if (image != null) return image.current();
        BufferSliceTracker buffer = buffers.get(resource);
        if (buffer != null) return buffer.current();
        State result = null;
        for (SliceState state : states.getOrDefault(resource, List.of())) {
            result = result == null ? state.state() : result.union(state.state());
        }
        return result;
    }

    private record UseKey(String resource, Subresource subresource) {}

    public List<dev.veil.revive.client.VeilRenderGraph.ImageState> imageStates(String resource) {
        ImageSliceTracker image = images.get(resource);
        return image == null ? List.of() : image.snapshot();
    }

    private record CombinedUse(State state, boolean reads) {
        CombinedUse combine(CombinedUse other) {
            return new CombinedUse(state.union(other.state), reads || other.reads);
        }
    }

    public List<Barrier> before(Pass pass) {
        var imageUses = new LinkedHashMap<String, List<Use>>();
        for (Use use : pass.uses()) {
            if (images.containsKey(use.resource()))
                imageUses.computeIfAbsent(use.resource(), ignored -> new ArrayList<>()).add(use);
        }
        var imageBarriers = new ArrayList<Barrier>();
        for (var entry : imageUses.entrySet())
            imageBarriers.addAll(
                    images.get(entry.getKey()).before(entry.getKey(), entry.getValue()));
        var bufferUses = new LinkedHashMap<String, List<Use>>();
        for (Use use : pass.uses()) {
            if (buffers.containsKey(use.resource()))
                bufferUses.computeIfAbsent(use.resource(), ignored -> new ArrayList<>()).add(use);
        }
        for (var entry : bufferUses.entrySet())
            imageBarriers.addAll(
                    buffers.get(entry.getKey()).before(entry.getKey(), entry.getValue()));
        // Barriers are recorded before the pass. A shared range must be transitioned once
        // into a combined state, rather than pretending the first use already executed.
        var combined = new LinkedHashMap<UseKey, CombinedUse>();
        for (Use use : pass.uses()) {
            var key = new UseKey(use.resource(), use.subresource());
            var next = new CombinedUse(State.of(use.access()), use.access().reads());
            combined.merge(key, next, CombinedUse::combine);
        }
        var barriers = new ArrayList<Barrier>();
        for (var combinedEntry : combined.entrySet()) {
            String resource = combinedEntry.getKey().resource();
            if (images.containsKey(resource) || buffers.containsKey(resource)) continue;
            Subresource slice = combinedEntry.getKey().subresource();
            State next = combinedEntry.getValue().state();
            boolean reads = combinedEntry.getValue().reads();
            State previous = overlappingState(resource, slice);
            State pendingWrite = overlappingState(pendingWrites, resource, slice);
            State visible = visibleReads.getOrDefault(resource, Map.of()).get(slice);
            boolean uncoveredRead =
                    reads
                            && (visible == null
                                    || (visible.stages() & next.stages()) != next.stages()
                                    || (visible.access() & next.access()) != next.access());
            boolean layoutChange =
                    previous != null
                            && previous.layout() != next.layout()
                            && previous.layout() != Layout.NONE
                            && next.layout() != Layout.NONE;
            if (previous != null
                    && (layoutChange || next.write() || pendingWrite != null && uncoveredRead)) {
                State source =
                        pendingWrite == null
                                ? previous
                                : new State(
                                        previous.stages() | pendingWrite.stages(),
                                        previous.access() | pendingWrite.access(),
                                        true,
                                        previous.layout());
                barriers.add(new Barrier(resource, slice, source, next));
            }

            if (next.write()) {
                visibleReads
                        .computeIfAbsent(resource, ignored -> new LinkedHashMap<>())
                        .entrySet()
                        .removeIf(entry -> slice.overlaps(entry.getKey()));
                var writes = pendingWrites.computeIfAbsent(resource, ignored -> new ArrayList<>());
                if (slice.whole()) writes.clear();
                else writes.removeIf(entry -> slice.covers(entry.subresource()));
                writes.add(new SliceState(slice, next));
            } else if (reads) {
                var readStates =
                        visibleReads.computeIfAbsent(resource, ignored -> new LinkedHashMap<>());
                State priorVisible = readStates.get(slice);
                next = priorVisible == null ? next : priorVisible.union(next);
                readStates.put(slice, next);
            }

            var resourceStates = states.computeIfAbsent(resource, ignored -> new ArrayList<>());

            if (slice.whole()) {
                resourceStates.clear();
            } else {
                Subresource finalSlice = slice;
                resourceStates.removeIf(entry -> finalSlice.covers(entry.subresource()));
            }
            resourceStates.add(new SliceState(slice, next));
        }
        imageBarriers.addAll(barriers);
        return List.copyOf(imageBarriers);
    }

    /** Transitions modified imported-image regions back to the host's release state. */
    public List<Barrier> release(String resource, State initial, State target) {
        ImageSliceTracker image = images.get(resource);
        if (image != null) return image.release(resource, initial, target);
        BufferSliceTracker buffer = buffers.get(resource);
        return buffer == null ? List.of() : buffer.release(resource, initial, target);
    }

    private State overlappingState(String resource, Subresource slice) {
        return overlappingState(states, resource, slice);
    }

    private static State overlappingState(
            Map<String, List<SliceState>> source, String resource, Subresource slice) {
        State result = null;
        List<SliceState> resourceStates = source.get(resource);
        if (resourceStates == null) return null;

        boolean byteRanges =
                slice.bufferRange()
                        || resourceStates.stream()
                                .anyMatch(value -> value.subresource().bufferRange());
        for (int i = resourceStates.size() - 1; !byteRanges && i >= 0; i--) {
            SliceState candidate = resourceStates.get(i);
            if (candidate.subresource().equals(slice)) return candidate.state();
        }
        for (SliceState candidate : resourceStates) {
            if (!slice.overlaps(candidate.subresource())) continue;
            result = result == null ? candidate.state() : result.union(candidate.state());
        }
        return result;
    }
}
