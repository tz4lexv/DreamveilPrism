package dev.veil.revive.client.graphics.resources;

import static org.lwjgl.vulkan.KHRSynchronization2.vkCmdPipelineBarrier2KHR;
import static org.lwjgl.vulkan.VK10.*;
import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.revive.core.terrain.SparseUploadPlanner;
import dev.veil.revive.mixin.CommandEncoderBackendAccessor;
import dev.veil.revive.mixin.VulkanEncoderAccessor;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkBufferCopy;
import org.lwjgl.vulkan.VkDependencyInfo;
import org.lwjgl.vulkan.VkMemoryBarrier2;

import java.util.function.BooleanSupplier;

public final class RangeTransferRecorder {
    private final boolean requested, sectionDependencies;
    private final int storageUsage;
    private final BooleanSupplier optimizations;
    private static final long SECTION_STAGES =
            VK_PIPELINE_STAGE_2_VERTEX_SHADER_BIT
                    | VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT
                    | VK_PIPELINE_STAGE_2_TRANSFER_BIT;
    private static final long SECTION_ACCESS =
            VK_ACCESS_2_SHADER_READ_BIT
                    | VK_ACCESS_2_TRANSFER_READ_BIT
                    | VK_ACCESS_2_TRANSFER_WRITE_BIT;
    private long batches, rangesCopied, nativeRanges, sectionBatches, broadBatches;

    public RangeTransferRecorder(
            boolean requested,
            boolean sectionDependencies,
            int storageUsage,
            BooleanSupplier optimizations) {
        this.requested = requested;
        this.sectionDependencies = sectionDependencies;
        this.storageUsage = storageUsage;
        this.optimizations = java.util.Objects.requireNonNull(optimizations);
    }

    public static boolean eligible(
            SparseUploadPlanner ranges, int stride, long sourceSize, long targetSize) {
        if (stride <= 0 || (stride & 3) != 0 || ranges.count() < 3 || ranges.count() > 64)
            return false;
        int previousLast = -1;
        for (int i = 0; i < ranges.count(); i++) {
            int first = ranges.first(i), last = ranges.last(i);
            if (first <= previousLast || last < first) return false;
            long end = ((long) last + 1) * stride;
            if (end > sourceSize || end > targetSize) return false;
            previousLast = last;
        }
        return true;
    }

    public void copy(
            CommandEncoder encoder,
            GpuBuffer source,
            GpuBuffer target,
            SparseUploadPlanner ranges,
            int stride) {
        copy(encoder, source, target, ranges, stride, false);
    }

    public boolean sectionTableContract(int sourceUsage, int targetUsage) {
        int sourceAllowed = GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC;
        int targetAllowed =
                GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER
                        | storageUsage
                        | GpuBuffer.USAGE_COPY_DST
                        | GpuBuffer.USAGE_COPY_SRC;
        return sourceUsage == sourceAllowed
                && (targetUsage & ~targetAllowed) == 0
                && (targetUsage & GpuBuffer.USAGE_COPY_DST) != 0
                && (targetUsage & GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER) != 0;
    }

    public void copySectionTable(
            CommandEncoder encoder,
            GpuBuffer source,
            GpuBuffer target,
            SparseUploadPlanner ranges,
            int stride) {
        copy(encoder, source, target, ranges, stride, true);
    }

    private void copy(
            CommandEncoder encoder,
            GpuBuffer source,
            GpuBuffer target,
            SparseUploadPlanner ranges,
            int stride,
            boolean sectionTable) {
        if (!requested
                || !optimizations.getAsBoolean()
                || source.isClosed()
                || target.isClosed()
                || (source.usage() & GpuBuffer.USAGE_COPY_SRC) == 0
                || (target.usage() & GpuBuffer.USAGE_COPY_DST) == 0
                || !(encoder instanceof CommandEncoderBackendAccessor wrapper)
                || wrapper.veil$isInRenderPass()
                || !(wrapper.veil$backend() instanceof VulkanEncoderAccessor access)
                || !(source instanceof VulkanGpuBuffer src)
                || !(target instanceof VulkanGpuBuffer dst)
                || src.vkBuffer() == dst.vkBuffer()
                || !eligible(ranges, stride, source.size(), target.size())) {
            for (int i = 0; i < ranges.count(); i++) {
                long offset = (long) ranges.first(i) * stride;
                long bytes = ((long) ranges.last(i) - ranges.first(i) + 1) * stride;
                encoder.copyToBuffer(source.slice(offset, bytes), target.slice(offset, bytes));
                nativeRanges++;
            }
            return;
        }
        boolean explicit =
                sectionTable
                        && sectionDependencies
                        && sectionTableContract(source.usage(), target.usage());
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var copies = VkBufferCopy.calloc(ranges.count(), stack);
            for (int i = 0; i < ranges.count(); i++) {
                long offset = (long) ranges.first(i) * stride;
                copies.get(i)
                        .srcOffset(offset)
                        .dstOffset(offset)
                        .size(((long) ranges.last(i) - ranges.first(i) + 1) * stride);
            }
            var barrier = VkMemoryBarrier2.calloc(1, stack);
            var dependency =
                    VkDependencyInfo.calloc(stack).sType$Default().pMemoryBarriers(barrier);
            barrier.get(0)
                    .sType$Default()
                    .srcStageMask(
                            explicit
                                    ? SECTION_STAGES | VK_PIPELINE_STAGE_2_HOST_BIT
                                    : VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT)
                    .srcAccessMask(
                            explicit
                                    ? SECTION_ACCESS | VK_ACCESS_2_HOST_WRITE_BIT
                                    : VK_ACCESS_2_MEMORY_READ_BIT | VK_ACCESS_2_MEMORY_WRITE_BIT)
                    .dstStageMask(VK_PIPELINE_STAGE_2_TRANSFER_BIT)
                    .dstAccessMask(VK_ACCESS_2_TRANSFER_READ_BIT | VK_ACCESS_2_TRANSFER_WRITE_BIT);
            var command = access.veil$commandBuffer();
            vkCmdPipelineBarrier2KHR(command, dependency);
            vkCmdCopyBuffer(command, src.vkBuffer(), dst.vkBuffer(), copies);
            barrier.get(0)
                    .srcStageMask(VK_PIPELINE_STAGE_2_TRANSFER_BIT)
                    .srcAccessMask(VK_ACCESS_2_TRANSFER_WRITE_BIT)
                    .dstStageMask(explicit ? SECTION_STAGES : VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT)
                    .dstAccessMask(
                            explicit
                                    ? SECTION_ACCESS
                                    : VK_ACCESS_2_MEMORY_READ_BIT | VK_ACCESS_2_MEMORY_WRITE_BIT);
            vkCmdPipelineBarrier2KHR(command, dependency);
        }
        batches++;
        if (explicit) sectionBatches++;
        else broadBatches++;
        rangesCopied += ranges.count();
    }

    public long batches() {
        return batches;
    }

    public long nativeRanges() {
        return nativeRanges;
    }

    public long sectionBatches() {
        return sectionBatches;
    }

    public String telemetry() {
        return "transfer_batches_total="
                + batches
                + "\ntransfer_batch_ranges_total="
                + rangesCopied
                + "\ntransfer_batch_barriers_total="
                + batches * 2
                + "\ntransfer_native_ranges_total="
                + nativeRanges
                + "\ntransfer_section_dependencies_requested="
                + sectionDependencies
                + "\ntransfer_section_dependency_batches_total="
                + sectionBatches
                + "\ntransfer_broad_dependency_batches_total="
                + broadBatches
                + "\n";
    }
}
