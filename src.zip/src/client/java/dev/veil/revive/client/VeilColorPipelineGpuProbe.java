package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.api.*;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.nio.*;
import java.nio.file.*;
import java.util.*;

/** Numeric SDR color-chain conformance; never modifies a creator pack. */
final class VeilColorPipelineGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.colorPipelineProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final List<String> RESULTS = new ArrayList<>();
    private static int stage, frames;
    private static boolean complete, pending, ready, changed;
    private static long started;
    private static VeilShaderPackRuntime previous;
    private static VeilSceneColor.Registration registration;
    private static final float[][] COLORS = {
        {0, 0, 0},
        {.00001f, .00001f, .00001f},
        {.0031308f, .0031308f, .0031308f},
        {.018f, .018f, .018f},
        {.18f, .18f, .18f},
        {1, 1, 1},
        {2, 2, 2},
        {4, 4, 4},
        {16, 16, 16},
        {64, 64, 64},
        {256, 256, 256},
        {1024, 1024, 1024},
        {4, .18f, .01f},
        {.02f, 4, .2f},
        {.01f, .1f, 16},
        {1, 1, 1}
    };

    static boolean enabled() {
        return ENABLED;
    }

    static void timeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 240_000_000_000L)
            fail(new IllegalStateException("Color probe timeout/runtime failure"));
    }

    static void before(VeilShaderPackRuntime active) {
        ready = false;
        if (!ENABLED || complete || pending || !VeilBenchmarkWorld.terrainReady()) return;
        try {
            if (stage > 0 && !changed) {
                changed = true;
                previous = active;
                frames = 0;
                if (stage == 1) {
                    registration =
                            VeilSceneColor.register(
                                    () ->
                                            new VeilSceneColor.Description(
                                                    VeilSceneColor.Transfer.LINEAR,
                                                    VeilSceneColor.Primaries.SRGB_REC709_D65,
                                                    true,
                                                    4,
                                                    2,
                                                    true));
                    VeilShaderService.settings(Map.of("EV", "1", "HALF", "true"));
                } else if (stage == 2)
                    VeilShaderService.settings(Map.of("EV", "-2", "HALF", "false", "ACES", "true"));
                else if (stage == 3)
                    VeilShaderService.settings(Map.of("EV", "0", "ACES", "false", "AUTO", "true"));
                else if (stage == 4) VeilShaderService.select("colordisplay");
                else if (stage == 5) VeilShaderService.select("colorsrgb");
                else if (stage == 6) VeilShaderService.select("colorlegacy");
                else {
                    Minecraft.getInstance().getWindow().setWindowed(800, 450);
                    VeilShaderService.select("colorlinear");
                }
                return;
            }
            if (changed && active == previous) return;
            if (stage == 7
                    && (Minecraft.getInstance().gameRenderer.mainRenderTarget().width != 800
                            || Minecraft.getInstance().gameRenderer.mainRenderTarget().height
                                    != 450)) return;
            frames++;
            ready = true;
        } catch (Exception e) {
            fail(e);
        }
    }

    static void after(VeilShaderPackRuntime active) {
        if (!ENABLED || complete || pending || !ready || frames < (stage == 3 ? 64 : 8)) return;
        pending = true;
        var target = Minecraft.getInstance().gameRenderer.mainRenderTarget();
        int width = target.width, height = target.height;
        String[] names = {
            "hdr32",
            "hdr16",
            "exposure",
            "proof",
            "slangProof",
            "linear",
            "srgb",
            "fixedSrgb",
            "presented"
        };
        int[] sizes = {
            32 * 8 * 16,
            32 * 8 * 8,
            16,
            21 * 16,
            16,
            32 * 8 * 16,
            32 * 8 * 4,
            32 * 8 * 4,
            width * height * 4
        };
        byte[][] data = new byte[names.length][];
        for (int i = 0; i < names.length; i++) {
            int slot = i;
            var buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil color conformance",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    sizes[i]);
            Runnable done =
                    () -> {
                        try (var map = buffer.map(true, false)) {
                            data[slot] = new byte[sizes[slot]];
                            map.data().get(data[slot]);
                            if (Arrays.stream(data).allMatch(Objects::nonNull)) {
                                verify(data, width, height);
                                RESULTS.add(
                                        "stage="
                                                + stage
                                                + " frames="
                                                + frames
                                                + " viewport="
                                                + width
                                                + "x"
                                                + height
                                                + " PASS");
                                if (stage == 7) {
                                    Path path =
                                            VeilPlatform.get()
                                                    .getGameDir()
                                                    .resolve("logs/color-pipeline-proof.txt");
                                    Files.write(path, RESULTS);
                                    complete = true;
                                    if (registration != null) registration.close();
                                    ReviveMod.LOGGER.info(
                                            "Veil color pipeline GPU: PASS stages={} HDR32 HDR16 exposure histogram GLSL Slang sRGB legacy resize",
                                            RESULTS.size());
                                    Minecraft.getInstance().stop();
                                } else {
                                    stage++;
                                    frames = 0;
                                    changed = false;
                                    pending = false;
                                    ready = false;
                                }
                            }
                        } catch (Exception e) {
                            fail(e);
                        } finally {
                            buffer.close();
                        }
                    };
            try {
                if (i == 8) active.readPresented(buffer, done);
                else active.readOutput(names[i], buffer, done);
            } catch (Exception e) {
                buffer.close();
                fail(e);
                return;
            }
        }
    }

    private static ByteBuffer bytes(byte[] b) {
        return ByteBuffer.wrap(b).order(ByteOrder.nativeOrder());
    }

    private static void near(double actual, double expected, double tolerance, String label) {
        if (!Double.isFinite(actual) || Math.abs(actual - expected) > tolerance)
            throw new IllegalStateException(
                    label + " stage=" + stage + " actual=" + actual + " expected=" + expected);
    }

    private static double encode(double v) {
        return v <= .0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - .055;
    }

    private static double tone(double v) {
        return stage == 2
                ? Math.max(0, Math.min(1, (v * (2.51 * v + .03)) / (v * (2.43 * v + .59) + .14)))
                : v / (1 + v);
    }

    private static void verify(byte[][] data, int width, int height) {
        var hdr = bytes(data[0]);
        var half = bytes(data[1]);
        var exposure = bytes(data[2]);
        var proof = bytes(data[3]);
        var slang = bytes(data[4]);
        var linear = bytes(data[5]);
        double logSum = 0;
        int[] bins = new int[16];
        for (int x = 0; x < 32; x++) {
            var c = COLORS[x % 16];
            double lum = c[0] * .2126 + c[1] * .7152 + c[2] * .0722;
            logSum += Math.log(Math.max(lum, .00001)) / Math.log(2);
            int bin =
                    Math.max(
                            0,
                            Math.min(
                                    15,
                                    (int)
                                            ((Math.log(Math.max(lum, 1e-20)) / Math.log(2) + 16)
                                                    / 32
                                                    * 16)));
            bins[bin]++;
            for (int k = 0; k < 3; k++) {
                near(hdr.getFloat(x * 16 + k * 4), c[k], 1e-6, "HDR32");
                near(
                        Float.float16ToFloat(half.getShort(x * 8 + k * 2)),
                        c[k],
                        Math.max(1e-7, c[k] * .001),
                        "HDR16");
            }
        }
        double mean = Math.pow(2, logSum / 32),
                gain = stage == 1 ? 2 : stage == 2 ? .25 : stage == 3 ? .18 / mean : 1;
        near(exposure.getFloat(0), gain, 1e-4, "exposure gain");
        near(exposure.getFloat(4), mean, 1e-4, "geometric mean");
        for (int i = 0; i < 16; i++) near(proof.getFloat(i * 16), bins[i], 0, "histogram");
        near(proof.getFloat(16 * 16), (float) VeilColorPipeline.MAGIC, 0, "metadata header");
        near(proof.getFloat(19 * 16), stage == 0 ? 0 : 4, 0, "pre-exposure metadata");
        double[] math = {
            encode(.18), Math.pow((.5 + .055) / 1.055, 2.4), 4, 1 + 3 * (1 - Math.exp(-2))
        };
        for (int k = 0; k < 4; k++) {
            near(proof.getFloat(20 * 16 + k * 4), math[k], 2e-5, "GLSL math");
            near(slang.getFloat(k * 4), math[k], 2e-5, "Slang math");
        }
        for (int x = 0; x < 32; x++)
            for (int k = 0; k < 3; k++) {
                double v = COLORS[x % 16][k];
                if (stage == 1) v = Float.float16ToFloat(half.getShort(x * 8 + k * 2));
                double expected = tone(v * gain);
                if (stage == 4) expected = encode(expected);
                near(linear.getFloat(x * 16 + k * 4), expected, 2e-4, "author tone curve");
                near(
                        Byte.toUnsignedInt(data[7][x * 4 + k]) / 255.,
                        encode(tone(v * gain)),
                        .006,
                        "present into sRGB attachment");
                near(
                        Byte.toUnsignedInt(data[6][x * 4 + k]) / 255.,
                        encode(expected),
                        .006,
                        "sRGB attachment encoding");
            }
        for (int x = 0; x < 32; x++) {
            int pixelX = (int) ((x + .5) * width / 32);
            int offset = ((height / 2) * width + pixelX) * 4;
            for (int k = 0; k < 3; k++) {
                double v = COLORS[x % 16][k];
                if (stage == 1) v = Float.float16ToFloat(half.getShort(x * 8 + k * 2));
                double expected = tone(v * gain);
                if (stage != 6) expected = encode(expected);
                near(
                        Byte.toUnsignedInt(data[8][offset + k]) / 255.,
                        expected,
                        .012,
                        "present transfer");
            }
        }
    }

    private static void fail(Throwable error) {
        complete = true;
        if (registration != null) registration.close();
        ReviveMod.LOGGER.error("Veil color pipeline GPU: FAIL stage=" + stage, error);
        Minecraft.getInstance().stop();
    }
}
