package dev.veil.revive.client.shaderpack.preparation;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.revive.client.VeilShaderPack;
import dev.veil.revive.client.graphics.resources.ImageAllocationPlan;
import dev.veil.revive.client.graphics.resources.SamplerParameters;

import java.util.Map;

public final class ImageResourceInputs {
    private ImageResourceInputs() {}

    public static ImageAllocationPlan plan(
            VeilShaderPack.Resource resource,
            Map<String, VeilShaderPack.Resource> resources,
            int viewportWidth,
            int viewportHeight) {
        if (!resource.nativeImage()) {
            throw new IllegalArgumentException(
                    "Native image allocation requires texture/storage resource: "
                            + resource.name());
        }
        int width = resource.resolvedWidth(viewportWidth, resources);
        int height = resource.resolvedHeight(viewportHeight, resources);
        int depth = resource.resolvedDepth();
        if (resource.sampled()) {
            var sample = resource.sampler();
            boolean clampToBorder =
                    sample.u() == VeilShaderPack.SampleAddress.CLAMP_TO_BORDER
                            || sample.v() == VeilShaderPack.SampleAddress.CLAMP_TO_BORDER
                            || sample.w() == VeilShaderPack.SampleAddress.CLAMP_TO_BORDER;
            boolean integerBorder =
                    switch (sample.border()) {
                        case INT_TRANSPARENT_BLACK, INT_OPAQUE_BLACK, INT_OPAQUE_WHITE -> true;
                        default -> false;
                    };
            dev.veil.revive.client.graphics.resources.SamplerBorderRules.validate(
                    resource.format(), clampToBorder, integerBorder);
            dev.veil.revive.client.graphics.resources.SamplerLodRules.ownedMaxLod(
                    sample.minLod(), sample.maxLod(), resource.mipLevels());
        }
        return new ImageAllocationPlan(
                resource.name(),
                resource.format(),
                width,
                height,
                depth,
                resource.layers(),
                resource.mipLevels(),
                resource.samples(),
                resource.nativeImage(),
                resource.image3d(),
                resource.cubemap(),
                resource.image2dArray(),
                resource.sampled(),
                resource.storageImage(),
                resource.renderTarget(),
                resource.depthTarget(),
                resource.usages(),
                resource.sampled() ? sampler(resource.sampler()) : null,
                resource.cubeArray(),
                resource.image1d(),
                resource.image1dArray());
    }

    public static SamplerParameters sampler(VeilShaderPack.Sampler sampler) {
        return new SamplerParameters(
                filterValue(sampler.min()),
                filterValue(sampler.mag()),
                mipmapValue(sampler.mip()),
                addressValue(sampler.u()),
                addressValue(sampler.v()),
                addressValue(sampler.w()),
                sampler.compare() != null,
                sampler.compare() == null ? VK_COMPARE_OP_ALWAYS : compareValue(sampler.compare()),
                borderValue(sampler.border()),
                sampler.minLod(),
                sampler.maxLod(),
                sampler.lodBias());
    }

    private static int borderValue(VeilShaderPack.SampleBorder border) {
        return switch (border) {
            case FLOAT_TRANSPARENT_BLACK -> VK_BORDER_COLOR_FLOAT_TRANSPARENT_BLACK;
            case FLOAT_OPAQUE_BLACK -> VK_BORDER_COLOR_FLOAT_OPAQUE_BLACK;
            case FLOAT_OPAQUE_WHITE -> VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE;
            case INT_TRANSPARENT_BLACK -> VK_BORDER_COLOR_INT_TRANSPARENT_BLACK;
            case INT_OPAQUE_BLACK -> VK_BORDER_COLOR_INT_OPAQUE_BLACK;
            case INT_OPAQUE_WHITE -> VK_BORDER_COLOR_INT_OPAQUE_WHITE;
        };
    }

    private static int compareValue(VeilShaderPack.CompareOp compare) {
        return switch (compare) {
            case NEVER -> VK_COMPARE_OP_NEVER;
            case LESS -> VK_COMPARE_OP_LESS;
            case EQUAL -> VK_COMPARE_OP_EQUAL;
            case LESS_OR_EQUAL -> VK_COMPARE_OP_LESS_OR_EQUAL;
            case GREATER -> VK_COMPARE_OP_GREATER;
            case NOT_EQUAL -> VK_COMPARE_OP_NOT_EQUAL;
            case GREATER_OR_EQUAL -> VK_COMPARE_OP_GREATER_OR_EQUAL;
            case ALWAYS -> VK_COMPARE_OP_ALWAYS;
        };
    }

    public static int filterValue(VeilShaderPack.SampleFilter filter) {
        return filter == VeilShaderPack.SampleFilter.LINEAR ? VK_FILTER_LINEAR : VK_FILTER_NEAREST;
    }

    public static int mipmapValue(VeilShaderPack.SampleFilter filter) {
        return filter == VeilShaderPack.SampleFilter.LINEAR
                ? VK_SAMPLER_MIPMAP_MODE_LINEAR
                : VK_SAMPLER_MIPMAP_MODE_NEAREST;
    }

    public static int addressValue(VeilShaderPack.SampleAddress mode) {
        return switch (mode) {
            case CLAMP_TO_EDGE -> VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
            case REPEAT -> VK_SAMPLER_ADDRESS_MODE_REPEAT;
            case MIRRORED_REPEAT -> VK_SAMPLER_ADDRESS_MODE_MIRRORED_REPEAT;
            case CLAMP_TO_BORDER -> VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_BORDER;
        };
    }
}
