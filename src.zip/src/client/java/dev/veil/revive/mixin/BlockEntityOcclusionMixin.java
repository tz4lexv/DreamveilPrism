package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilAsyncEntityOcclusion;

import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.phys.AABB;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityOcclusionMixin {
    @Inject(method = "tryExtractRenderState", at = @At("HEAD"), cancellable = true, require = 1)
    private void veil$skipHiddenContainer(
            BlockEntity entity,
            float partialTick,
            net.minecraft.client.renderer.feature.ModelFeatureRenderer.CrumblingOverlay overlay,
            boolean renderOutline,
            CallbackInfoReturnable<?> ci) {
        if (renderOutline
                || !(entity instanceof ChestBlockEntity
                        || entity instanceof EnderChestBlockEntity
                        || entity instanceof ShulkerBoxBlockEntity)) return;
        var renderer = ((BlockEntityRenderDispatcher) (Object) this).getRenderer(entity);
        if (renderer == null
                || renderer.shouldRenderOffScreen()
                || !renderer.getClass()
                        .getName()
                        .startsWith("net.minecraft.client.renderer.blockentity.")) return;
        var pos = entity.getBlockPos();
        AABB bounds =
                new AABB(
                        pos.getX() - 1,
                        pos.getY() - 1,
                        pos.getZ() - 1,
                        pos.getX() + 2,
                        pos.getY() + 2,
                        pos.getZ() + 2);
        if (VeilAsyncEntityOcclusion.isOccluded(entity, bounds)) ci.setReturnValue(null);
    }
}
