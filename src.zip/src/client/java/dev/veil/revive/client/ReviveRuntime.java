package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.*;

import java.nio.ByteBuffer;

public final class ReviveRuntime {
    private static final Object LIFECYCLE_LOCK = new Object();
    private static final ReviveConfig DEFAULT_CONFIG = ReviveConfig.defaults();
    private static final ReviveStats.Snapshot EMPTY_STATS = new ReviveStats().snapshot();
    private static volatile RuntimeState state;
    private static volatile boolean graphicsBackendReported;

    private ReviveRuntime() {}

    public static void initialize() {
        final RuntimeState created;
        synchronized (LIFECYCLE_LOCK) {
            if (state != null) return;
            ReviveConfig config = ReviveConfigStore.loadOrCreate();
            created = new RuntimeState(config);
            state = created;
            graphicsBackendReported = false;
        }

        ReviveConfig config = created.config;
        VeilRendererInfo.logStartup(config.profile().name());
        ReviveMod.LOGGER.info(
                "Veil {} initialized: profile={}, workers={}, faithfulVisualPolicy=true",
                VeilRendererInfo.VEIL_VERSION,
                config.profile(),
                config.workerThreads());
        ReviveMod.LOGGER.info(
                "FAITHFUL culling guard: enabled={}, confirmations={}, visibleGrace={}, boundsInflation={} blocks",
                config.faithfulCulling(),
                config.occlusionConfirmations(),
                config.visibleGraceGenerations(),
                config.cullBoundsInflation());
        VeilVulkanRuntime.BackendState startupBackend = VeilVulkanRuntime.backendState();
        ReviveMod.LOGGER.info(
                "Veil Vulkan path: {}",
                switch (startupBackend) {
                    case VULKAN ->
                            "GPU command compaction, two-level HZB, DrawIndirectCount, persistent staging and TLSF suballocation enabled";
                    case PENDING -> "PENDING - Minecraft graphics device is not initialized yet";
                    case OTHER -> "DISABLED - Minecraft is not using Vulkan";
                });

        long active =
                VeilTechniqueRegistry.all().stream()
                        .filter(
                                t ->
                                        t.stage()
                                                == VeilTechniqueRegistry.Stage
                                                        .MINECRAFT_BRIDGE_ACTIVE)
                        .count();
        long analysis =
                VeilTechniqueRegistry.all().stream()
                        .filter(t -> t.stage() == VeilTechniqueRegistry.Stage.ANALYSIS_ONLY)
                        .count();
        long coreReady =
                VeilTechniqueRegistry.all().stream()
                        .filter(t -> t.stage() == VeilTechniqueRegistry.Stage.CORE_READY)
                        .count();
        long gated =
                VeilTechniqueRegistry.all().stream()
                        .filter(
                                t ->
                                        t.stage()
                                                        == VeilTechniqueRegistry.Stage
                                                                .GPU_BACKEND_REQUIRED
                                                || t.stage()
                                                        == VeilTechniqueRegistry.Stage
                                                                .MINECRAFT_BRIDGE_REQUIRED)
                        .count();
        ReviveMod.LOGGER.info(
                "Veil techniques: {} runtime-active, {} analysis-only, {} core-ready, {} gated",
                active,
                analysis,
                coreReady,
                gated);
        ReviveMod.LOGGER.info(
                "Veil far field: SSE={}px, VASC={}px, silhouette={}px, deepLayers={}, subpixel={}px",
                config.screenSpaceErrorPixels(),
                config.vascErrorPixels(),
                config.vascSilhouetteErrorPixels(),
                config.vascDepthLayers(),
                config.subpixelCollapsePixels());
        ReviveMod.LOGGER.info(
                "Veil Minecraft 26.2 bridge: terrain draw-packet cache={}, exact Vulkan bind elision={}",
                config.staticDrawPacketCache() ? "ACTIVE" : "OFF",
                switch (startupBackend) {
                    case VULKAN -> "ACTIVE";
                    case PENDING -> "PENDING";
                    case OTHER -> "DISABLED";
                });
        ReviveMod.LOGGER.info(
                "Veil standalone GPU status: {}",
                switch (startupBackend) {
                    case VULKAN ->
                            "HZB=ACTIVE, GPU-driven compaction=ACTIVE, true MDI count draws=ACTIVE on Vulkan";
                    case PENDING -> "PENDING - waiting for Minecraft VulkanDevice";
                    case OTHER -> "Vulkan-only GPU techniques DISABLED";
                });
    }

    public static void onClientTick() {
        RuntimeState s = state;
        if (s == null || !s.config.enabled()) return;
        reportGraphicsBackendWhenReady();
        s.liveTelemetryRequested = VeilVideoConfig.flag("profiling.liveTelemetry", false);
        VeilTechniqueCounters.setCollecting(instrumentationActive(s));
        VeilVisibilityBudget.beginClientTick();
        s.animatedTextures.publishFrame();
        VeilMemoryMonitor.update();
        VeilVulkanCapabilities.refreshEnabledExtensions();
        long target =
                Math.min(s.config.recyclerBudgetBytes(), s.memoryBudget.veilCacheTargetBytes());
        if (s.byteBufferRecycler.cachedBytes() > target) s.byteBufferRecycler.trimTo(target);
    }

    private static void reportGraphicsBackendWhenReady() {
        VeilVulkanRuntime.BackendState backendState = VeilVulkanRuntime.backendState();
        if (backendState == VeilVulkanRuntime.BackendState.PENDING) return;
        synchronized (LIFECYCLE_LOCK) {
            if (graphicsBackendReported) return;
            graphicsBackendReported = true;
        }
        if (backendState == VeilVulkanRuntime.BackendState.VULKAN) {
            ReviveMod.LOGGER.info(
                    "Veil Vulkan backend READY: Minecraft VulkanDevice acquired; native shader runtime may initialize");
        } else {
            var device = com.mojang.blaze3d.systems.RenderSystem.tryGetDevice();
            String backend = device == null ? "unavailable" : device.getDeviceInfo().backendName();
            ReviveMod.LOGGER.warn(
                    "Veil Vulkan backend unavailable: Minecraft selected {}; Vulkan-only GPU techniques remain disabled",
                    backend);
        }
    }

    public static void onClientFrameStart() {
        RuntimeState s = state;
        VeilShaderService.beginFrame();
        if (s == null || !s.config.enabled()) return;
        s.clientFrameStartNs =
                net.minecraft.client.Minecraft.getInstance().level == null ? 0L : System.nanoTime();

        VeilFullFrameTelemetry.beginClientFrame();
        VeilShaderPackBridge.beginClientFrame();
        VeilLightingPipeline.beginClientFrame();
        VeilLatencyController.beforeClientFrame();
    }

    public static void onClientFrameEnd() {
        VeilShaderService.execute();
        RuntimeState s = state;
        if (s == null || !s.config.enabled()) return;
        if (s.clientFrameStartNs != 0L) {
            s.frameBudget.recordFrame((System.nanoTime() - s.clientFrameStartNs) / 1_000_000.0);
        }
        s.clientFrameStartNs = 0L;
        VeilFullFrameTelemetry.endClientFrame();
    }

    public static void onWorldRenderStart() {
        VeilArenaGpuProbe.tick();
        VeilAttributePatchGpuProbe.tick();
        VeilSparseAttributeGpuProbe.tick();
        VeilChangedLightGpuProbe.tick();
        VeilCanonicalGpuProbe.tick();
        VeilCanonicalArenaGpuProbe.tick();
        VeilBufferTransferGpuProbe.tick();
        VeilRegularPackedGpuProbe.tick();
        VeilParametricQuadsGpuProbe.tick();
        VeilParametricTerrainGpuProbe.tick();
        RuntimeState s = state;
        if (s == null || !s.config.enabled()) return;
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.WORLD_RENDER);
        VeilLatencyController.beforeWorldRender();
        VeilLightingPipeline.beginWorldFrame();
        VeilEntityModelFastPath.beginWorldFrame();
        s.frameInstrumentationActive = instrumentationActive(s);
        VeilTechniqueCounters.setCollecting(s.frameInstrumentationActive);
        if (s.frameInstrumentationActive) VeilDiagnostics.onFrameStart();

        VeilGpuProfiler.beginFrame();
        VeilGpuProfiler.begin(VeilGpuProfiler.Pass.WORLD_RENDER);
        s.frameStartNs = s.frameInstrumentationActive ? System.nanoTime() : 0L;
    }

    public static void onWorldRenderEnd() {
        RuntimeState s = state;
        if (s == null || !s.config.enabled()) return;
        VeilGpuProfiler.end(VeilGpuProfiler.Pass.WORLD_RENDER);
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.WORLD_RENDER);
        if (s.frameStartNs != 0L) {
            double ms = (System.nanoTime() - s.frameStartNs) / 1_000_000.0;
            if (s.frameInstrumentationActive) {
                s.stats.frame(ms);
                VeilDiagnostics.onFrameEnd(ms);
            }
        } else if (s.frameInstrumentationActive) {

            VeilDiagnostics.onFrameEnd(0.0);
        }
        s.frameStartNs = 0L;
        s.frameInstrumentationActive = false;
        VeilEntityModelFastPath.endWorldFrame();
        VeilLatencyController.afterWorldRender();
        VeilGraphicsSmokePass.runOnce();
    }

    public static void onTerrainUploadStart() {
        RuntimeState s = state;
        if (s != null && profiling(s)) s.terrainUploadStartNs = System.nanoTime();
    }

    public static void onTerrainUploadEnd() {
        RuntimeState s = state;
        if (s == null || !profiling(s) || s.terrainUploadStartNs == 0L) return;
        s.stats.terrainUpload((System.nanoTime() - s.terrainUploadStartNs) / 1_000_000.0);
        s.terrainUploadStartNs = 0L;
    }

    public static void onOcclusionUpdateStart() {
        RuntimeState s = state;
        if (s != null && profiling(s)) s.occlusionStartNs = System.nanoTime();
    }

    public static void onOcclusionUpdateEnd() {
        RuntimeState s = state;
        if (s == null || !profiling(s) || s.occlusionStartNs == 0L) return;
        s.stats.occlusionUpdate((System.nanoTime() - s.occlusionStartNs) / 1_000_000.0);
        s.occlusionStartNs = 0L;
    }

    public static long maintenanceBudgetNanos() {
        RuntimeState s = state;
        return s == null ? 0L : s.frameBudget.maintenanceBudgetNanos();
    }

    public static double framePressure() {
        RuntimeState s = state;
        return s == null ? 1.0 : s.frameBudget.pressure();
    }

    public static double targetFrameMs() {
        RuntimeState s = state;
        return s == null ? 16.6667 : s.frameBudget.targetMs();
    }

    public static boolean enabled() {
        RuntimeState s = state;
        return s != null && s.config.enabled();
    }

    public static boolean profiling() {
        RuntimeState s = state;
        return s != null && profiling(s);
    }

    private static boolean profiling(RuntimeState s) {
        return s.config.enabled()
                && (s.config.profilerEnabled()
                        || VeilDiagnostics.detailedOverlay()
                        || VeilDiagnostics.benchmarkActive());
    }

    public static boolean instrumentationActive() {
        RuntimeState s = state;
        return s != null && instrumentationActive(s);
    }

    private static boolean instrumentationActive(RuntimeState s) {
        return s.config.enabled()
                && (s.config.profilerEnabled()
                        || VeilDiagnostics.detailedOverlay()
                        || VeilDiagnostics.benchmarkActive()
                        || VeilSubmissionBenchmark.active()
                        || VeilVisualValidation.active()
                        || VeilCameraSweepProbe.enabled()
                        || dev.veil.revive.client.diagnostics.TerrainWorldLifecycleProbe.enabled()
                        || (VeilShadowMotionProbe.enabled()
                                && Boolean.getBoolean("veil.benchmarkWorld")
                                && Boolean.getBoolean("veil.shadowTerrainBuilderProbe"))
                        || s.liveTelemetryRequested);
    }

    public static boolean optimizationsEnabled() {
        return enabled() && VeilVideoConfig.on("renderer.enabled") && !VeilDiagnostics.bypassed();
    }

    public static ReviveConfig config() {
        RuntimeState s = state;
        return s == null ? DEFAULT_CONFIG : s.config;
    }

    public static ChunkRebuildCoordinator chunkCoordinator() {
        RuntimeState s = state;
        return s == null ? null : s.chunkCoordinator();
    }

    public static AsyncVisibilityEngine visibilityEngine() {
        RuntimeState s = state;
        return s == null ? null : s.visibilityEngine;
    }

    public static AnimatedTextureUsageTracker animatedTextures() {
        RuntimeState s = state;
        return s == null ? null : s.animatedTextures;
    }

    public static BufferRecycler<ByteBuffer> byteBufferRecycler() {
        RuntimeState s = state;
        return s == null ? null : s.byteBufferRecycler;
    }

    public static MemoryBudgetPolicy memoryBudget() {
        RuntimeState s = state;
        return s == null ? null : s.memoryBudget;
    }

    public static VeilRendererKernel veilKernel() {
        RuntimeState s = state;
        return s == null ? null : s.veilKernel;
    }

    public static ReviveStats.Snapshot stats() {
        RuntimeState s = state;
        return s == null ? EMPTY_STATS : s.stats.snapshot();
    }

    public static void close() {
        final RuntimeState closing;
        synchronized (LIFECYCLE_LOCK) {
            closing = state;
            if (closing == null) {
                VeilShaderService.close();
                if (VeilVulkanRuntime.isCurrentBackend()) VeilVulkanPipelineCache.close();
                return;
            }

            state = null;
            graphicsBackendReported = false;
        }

        try {
            VeilShaderService.close();
            VeilGraphicsSmokePass.close();

            if (VeilVulkanRuntime.isCurrentBackend()) VeilVulkanPipelineCache.close();
            VeilLatencyController.close();
            VeilLiveTelemetry.close();
            VeilFullFrameTelemetry.close();
            VeilSectionDirtyState.clearAll();
            VeilSectionResidencyGuard.clear();
            VeilLightingPipeline.clearWorldState();
            VeilTerrainDrawBridge.invalidateAll();
        } finally {

            closing.close();
        }
        ReviveMod.LOGGER.info("Veil stopped");
    }

    private static final class RuntimeState implements AutoCloseable {
        final ReviveConfig config;
        final FrameBudgetController frameBudget;
        private ChunkRebuildCoordinator chunkCoordinator;
        private boolean closed;
        final AsyncVisibilityEngine visibilityEngine;
        final BufferRecycler<ByteBuffer> byteBufferRecycler;
        final MemoryBudgetPolicy memoryBudget;
        final VeilRendererKernel veilKernel;
        final AnimatedTextureUsageTracker animatedTextures = new AnimatedTextureUsageTracker();
        final ReviveStats stats = new ReviveStats();

        long frameStartNs;
        long clientFrameStartNs;
        boolean frameInstrumentationActive;
        volatile boolean liveTelemetryRequested;
        long terrainUploadStartNs;
        long occlusionStartNs;

        RuntimeState(ReviveConfig config) {
            this.config = config;
            this.frameBudget =
                    new FrameBudgetController(config.targetFrameMs(), config.maintenanceBudgetMs());
            if (config.workerThreads() < 1) throw new IllegalArgumentException("workerCount < 1");
            this.visibilityEngine =
                    new AsyncVisibilityEngine(config.workerThreads(), config.faithfulCullPolicy());
            this.byteBufferRecycler =
                    new BufferRecycler<>(
                            config.recyclerBudgetBytes(),
                            size -> ByteBuffer.allocateDirect(size),
                            ByteBuffer::capacity);
            this.memoryBudget = new MemoryBudgetPolicy(config.veilOwnedGpuBudgetBytes());
            this.veilKernel = new VeilRendererKernel(config);
        }

        synchronized ChunkRebuildCoordinator chunkCoordinator() {
            if (!closed && chunkCoordinator == null)
                chunkCoordinator =
                        new ChunkRebuildCoordinator(
                                config.workerThreads(), config.maxQueuedTasks());
            return chunkCoordinator;
        }

        @Override
        public void close() {
            final ChunkRebuildCoordinator coordinator;
            synchronized (this) {
                if (closed) return;
                closed = true;
                coordinator = chunkCoordinator;
            }
            try {
                if (coordinator != null) coordinator.close();
            } finally {
                try {
                    visibilityEngine.close();
                } finally {
                    byteBufferRecycler.trimTo(0L);
                }
            }
        }
    }
}
