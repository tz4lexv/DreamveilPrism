package dev.veil.revive.client;

import dev.veil.revive.core.terrain.SectionStateSnapshot;

import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.block.state.BlockState;

import java.util.concurrent.atomic.LongAdder;

public final class VeilSectionStateSnapshot {
    private static final boolean REQUESTED = Boolean.getBoolean("veil.sectionStateSnapshot");
    private static final boolean VERIFY =
            Boolean.getBoolean("veil.verifySectionStateSnapshot")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final ThreadLocal<Scope> SCOPES = new ThreadLocal<>();
    private static final java.util.concurrent.Semaphore CAPACITY =
            new java.util.concurrent.Semaphore(64);
    private static final java.util.concurrent.ConcurrentLinkedQueue<Scope> POOL =
            new java.util.concurrent.ConcurrentLinkedQueue<>();
    private static final LongAdder CAPTURED = new LongAdder(),
            HITS = new LongAdder(),
            VERIFIED = new LongAdder();

    private VeilSectionStateSnapshot() {}

    public static boolean begin(SectionPos section, RenderSectionRegion region) {
        if (!REQUESTED || !ReviveRuntime.optimizationsEnabled()) return false;
        var position = new BlockPos.MutableBlockPos();
        SectionStateSnapshot.Reader<BlockState> reader =
                (x, y, z) -> {
                    if (x == section.minBlockX() - 1)
                        dev.veil.revive.core.terrain.CompileCancellationScope.check();
                    return region.getBlockState(position.set(x, y, z));
                };
        var scope = SCOPES.get();
        if (scope == null) {
            if (!CAPACITY.tryAcquire()) return false;
            try {
                scope = POOL.poll();
                if (scope == null) scope = new Scope();
                SCOPES.set(scope);
            } catch (RuntimeException | Error failure) {
                CAPACITY.release();
                throw failure;
            }
        }
        scope.depth++;
        try {
            scope.snapshot.begin(
                    region, section.minBlockX(), section.minBlockY(), section.minBlockZ(), reader);
        } catch (RuntimeException | Error failure) {
            end();
            throw failure;
        }
        if (VERIFY || VeilTechniqueCounters.collecting()) CAPTURED.increment();
        return true;
    }

    public static void end() {
        var scope = SCOPES.get();
        if (scope == null) throw new IllegalStateException("Missing section snapshot scope");
        scope.snapshot.end();
        if (--scope.depth != 0) return;
        SCOPES.remove();
        POOL.offer(scope);
        CAPACITY.release();
    }

    public static BlockState get(RenderSectionRegion region, BlockPos position) {
        var scope = SCOPES.get();
        if (scope == null) return null;
        var value = scope.snapshot.get(region, position.getX(), position.getY(), position.getZ());
        if (value != null && (VERIFY || VeilTechniqueCounters.collecting())) HITS.increment();
        return value;
    }

    public static boolean verifyingNeeded() {
        return VERIFY && VERIFIED.sum() < 100000;
    }

    public static void verify(BlockState cached, BlockState original) {
        if (cached != original)
            throw new IllegalStateException("Section state snapshot differs from region");
        VERIFIED.increment();
    }

    static void requireComplete() {
        if (!REQUESTED) return;
        if (CAPTURED.sum() == 0 || HITS.sum() == 0 || VERIFY && VERIFIED.sum() < 100000)
            throw new IllegalStateException(
                    "Section state snapshot incomplete: captured="
                            + CAPTURED.sum()
                            + " hits="
                            + HITS.sum()
                            + " verified="
                            + VERIFIED.sum());
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil section state snapshot: PASS (captured={} hits={} verified={})",
                CAPTURED.sum(),
                HITS.sum(),
                VERIFIED.sum());
    }

    private static final class Scope {
        final SectionStateSnapshot<BlockState> snapshot = new SectionStateSnapshot<>();
        int depth;
    }
}
