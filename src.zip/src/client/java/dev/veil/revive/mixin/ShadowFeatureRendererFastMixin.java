package dev.veil.revive.mixin;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.veil.revive.client.VeilEntityModelFastPath;
import dev.veil.revive.client.VeilVertexBufferWriter;

import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.feature.ShadowFeatureRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.world.phys.AABB;

import org.joml.Matrix4fc;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ShadowFeatureRenderer.class)
public abstract class ShadowFeatureRendererFastMixin {
    @Unique private static final int VEIL$ENTITY_STRIDE = 36;
    @Unique private static final int VEIL$VERTICES_PER_PIECE = 4;

    @Unique
    private static final int VEIL$PIECE_BYTES = VEIL$ENTITY_STRIDE * VEIL$VERTICES_PER_PIECE;

    @Unique private static final int VEIL$PIECES_PER_BATCH = 16;
    @Unique private static final int VEIL$BATCH_BYTES = VEIL$PIECE_BYTES * VEIL$PIECES_PER_BATCH;
    @Unique private static final int VEIL$UP_NORMAL = 0x00007F00;

    @Inject(method = "prepare", at = @At("HEAD"), cancellable = true, require = 0)
    private static void veil$fastPrepare(
            ShadowFeatureRenderer.Submit submit, VertexConsumer consumer, CallbackInfo ci) {
        if (!VeilEntityModelFastPath.shadowEnabled()) {
            return;
        }

        VeilVertexBufferWriter writer = VeilVertexBufferWriter.tryOf(consumer);
        if (writer == null
                || DefaultVertexFormat.ENTITY.getVertexSize() != VEIL$ENTITY_STRIDE
                || !writer.veil$canPush(DefaultVertexFormat.ENTITY)) {
            VeilEntityModelFastPath.recordShadowFallback();
            return;
        }

        Matrix4fc pose = submit.pose();
        float radius = submit.radius();
        if (!(radius > 0.0F) || !Float.isFinite(radius)) {
            VeilEntityModelFastPath.recordShadowFallback();
            return;
        }

        try (MemoryStack stack = MemoryStack.stackPush()) {

            long vertices = stack.nmalloc(4, VEIL$BATCH_BYTES);
            int batchPieces = 0;
            int renderedPieces = 0;

            for (int i = 0, size = submit.pieces().size(); i < size; i++) {
                EntityRenderState.ShadowPiece piece = submit.pieces().get(i);
                float alpha = piece.alpha();

                if (!(alpha >= 0.0F)) {
                    continue;
                }
                if (alpha > 1.0F) {
                    alpha = 1.0F;
                }

                AABB bounds = piece.shapeBelow().bounds();
                float minX = (float) (piece.relativeX() + bounds.minX);
                float maxX = (float) (piece.relativeX() + bounds.maxX);
                float minY = (float) (piece.relativeY() + bounds.minY);
                float minZ = (float) (piece.relativeZ() + bounds.minZ);
                float maxZ = (float) (piece.relativeZ() + bounds.maxZ);

                float sizeScale = 0.5F / radius;
                float u1 = (-minX * sizeScale) + 0.5F;
                float u2 = (-maxX * sizeScale) + 0.5F;
                float v1 = (-minZ * sizeScale) + 0.5F;
                float v2 = (-maxZ * sizeScale) + 0.5F;

                int alphaByte = ((int) (alpha * 255.0F)) & 0xFF;
                int colorAbgr = (alphaByte << 24) | 0x00FFFFFF;

                long ptr = vertices + (long) batchPieces * VEIL$PIECE_BYTES;
                veil$writeVertex(ptr, pose, minX, minY, minZ, u1, v1, colorAbgr);
                ptr += VEIL$ENTITY_STRIDE;
                veil$writeVertex(ptr, pose, minX, minY, maxZ, u1, v2, colorAbgr);
                ptr += VEIL$ENTITY_STRIDE;
                veil$writeVertex(ptr, pose, maxX, minY, maxZ, u2, v2, colorAbgr);
                ptr += VEIL$ENTITY_STRIDE;
                veil$writeVertex(ptr, pose, maxX, minY, minZ, u2, v1, colorAbgr);

                batchPieces++;
                renderedPieces++;

                if (batchPieces == VEIL$PIECES_PER_BATCH) {

                    writer.veil$push(
                            vertices,
                            batchPieces * VEIL$VERTICES_PER_PIECE,
                            DefaultVertexFormat.ENTITY);
                    batchPieces = 0;
                }
            }

            if (batchPieces != 0) {
                writer.veil$push(
                        vertices,
                        batchPieces * VEIL$VERTICES_PER_PIECE,
                        DefaultVertexFormat.ENTITY);
            }

            VeilEntityModelFastPath.recordShadow(renderedPieces);
            ci.cancel();
        }
    }

    @Unique
    private static void veil$writeVertex(
            long ptr, Matrix4fc pose, float x, float y, float z, float u, float v, int colorAbgr) {
        float tx = (pose.m00() * x) + ((pose.m10() * y) + ((pose.m20() * z) + pose.m30()));
        float ty = (pose.m01() * x) + ((pose.m11() * y) + ((pose.m21() * z) + pose.m31()));
        float tz = (pose.m02() * x) + ((pose.m12() * y) + ((pose.m22() * z) + pose.m32()));

        MemoryUtil.memPutFloat(ptr, tx);
        MemoryUtil.memPutFloat(ptr + 4L, ty);
        MemoryUtil.memPutFloat(ptr + 8L, tz);
        MemoryUtil.memPutInt(ptr + 12L, colorAbgr);
        MemoryUtil.memPutFloat(ptr + 16L, u);
        MemoryUtil.memPutFloat(ptr + 20L, v);

        MemoryUtil.memPutInt(ptr + 24L, OverlayTexture.NO_OVERLAY);
        MemoryUtil.memPutInt(ptr + 28L, LightCoordsUtil.FULL_BRIGHT);
        MemoryUtil.memPutInt(ptr + 32L, VEIL$UP_NORMAL);
    }
}
