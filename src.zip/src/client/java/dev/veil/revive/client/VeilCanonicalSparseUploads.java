package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.UberGpuBuffer;

import dev.veil.revive.core.terrain.AttributeUploadPlan;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicLong;

public final class VeilCanonicalSparseUploads {
    public static final boolean REQUESTED = Boolean.getBoolean("veil.canonicalSparseUploads");
    private static final AtomicLong PENDING = new AtomicLong();
    private static final AtomicLong COPIES = new AtomicLong(),
            GPU_BYTES = new AtomicLong(),
            CPU_BYTES = new AtomicLong(),
            FALLBACK = new AtomicLong();

    private VeilCanonicalSparseUploads() {}

    public static boolean enabled() {
        return REQUESTED && ReviveRuntime.optimizationsEnabled();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static VeilCanonicalGpuArena.Admission stage(
            UberGpuBuffer<?> arena,
            SectionMesh before,
            SectionMesh after,
            ChunkSectionLayer layer,
            UberGpuBuffer.UploadCallback<?> callback,
            ByteBuffer input) {
        if (!enabled()
                || layer == ChunkSectionLayer.TRANSLUCENT
                || before == after
                || !(before instanceof VeilMeshExtras a)
                || !(after instanceof VeilMeshExtras b)
                || a.veil$metadata() == null
                || b.veil$metadata() == null) return VeilCanonicalGpuArena.Admission.UNSUPPORTED;
        var oldData = a.veil$metadata().canonicalData(layer);
        var data = b.veil$metadata().canonicalData(layer);
        if (oldData == null || data == null || !oldData.acquire())
            return VeilCanonicalGpuArena.Admission.UNSUPPORTED;
        try {
            if (!data.acquire()) return VeilCanonicalGpuArena.Admission.UNSUPPORTED;
            try {
                if (oldData.size() != data.size() || !data.view().equals(input.duplicate()))
                    return VeilCanonicalGpuArena.Admission.UNSUPPORTED;
                var plan = AttributeUploadPlan.canonical(oldData.view(), data.view(), 4, 32);
                if (plan == null) return VeilCanonicalGpuArena.Admission.UNSUPPORTED;
                return ((VeilCanonicalGpuArena) arena)
                        .veil$stageCanonical(
                                before, after, (UberGpuBuffer.UploadCallback) callback, plan, data);
            } finally {
                data.close();
            }
        } finally {
            oldData.close();
        }
    }

    public static boolean reserve(int bytes) {
        long used;
        do {
            used = PENDING.get();
            if (bytes > (16L << 20) - used) return false;
        } while (!PENDING.compareAndSet(used, used + bytes));
        return true;
    }

    public static void release(int bytes) {
        PENDING.addAndGet(-bytes);
    }

    static long pendingBytes() {
        return PENDING.get();
    }

    public static void copied(int gpuBytes, int cpuBytes) {
        COPIES.incrementAndGet();
        GPU_BYTES.addAndGet(gpuBytes);
        CPU_BYTES.addAndGet(cpuBytes);
    }

    public static void fallback() {
        FALLBACK.incrementAndGet();
    }

    public static void requireComplete() {
        if (!Boolean.getBoolean("veil.verifyCanonicalSparseUploads")) return;
        if (COPIES.get() == 0 || CPU_BYTES.get() == 0 || CPU_BYTES.get() >= GPU_BYTES.get())
            throw new IllegalStateException(
                    "Canonical sparse client not exercised: copies="
                            + COPIES.get()
                            + " cpu_bytes="
                            + CPU_BYTES.get()
                            + " gpu_bytes="
                            + GPU_BYTES.get()
                            + " retained="
                            + VeilCanonicalData.retainedBytes()
                            + " evicted="
                            + VeilCanonicalData.evicted());
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil canonical sparse client: PASS (copies={} gpu_copy_bytes={} cpu_attribute_bytes={} fallback={} retained_cpu_bytes={} pending_attribute_bytes={})",
                COPIES.get(),
                GPU_BYTES.get(),
                CPU_BYTES.get(),
                FALLBACK.get(),
                VeilCanonicalData.retainedBytes(),
                PENDING.get());
    }
}
