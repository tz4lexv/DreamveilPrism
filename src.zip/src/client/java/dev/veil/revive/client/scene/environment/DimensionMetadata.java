package dev.veil.revive.client.scene.environment;

import java.nio.charset.StandardCharsets;

public record DimensionMetadata(int kind, int identifierHash) {
    public static DimensionMetadata of(String identifier) {
        if (identifier == null) return new DimensionMetadata(0, 0);
        int kind =
                switch (identifier) {
                    case "minecraft:overworld" -> 1;
                    case "minecraft:the_nether" -> 2;
                    case "minecraft:the_end" -> 3;
                    default -> 4;
                };
        int hash = 0x811c9dc5;
        for (byte value : identifier.getBytes(StandardCharsets.UTF_8))
            hash = (hash ^ Byte.toUnsignedInt(value)) * 0x01000193;
        return new DimensionMetadata(kind, hash);
    }
}
