package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import dev.veil.revive.client.VeilSceneTerrainSelection;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererSceneTerrainMixin {
    @WrapOperation(
            method = "prepareChunkRenders",
            at =
                    @At(
                            value = "FIELD",
                            target =
                                    "Lnet/minecraft/client/renderer/LevelRenderer;visibleSections:Lit/unimi/dsi/fastutil/objects/ObjectArrayList;"),
            require = 1)
    private ObjectArrayList<SectionRenderDispatcher.RenderSection> veil$sceneSections(
            LevelRenderer renderer,
            Operation<ObjectArrayList<SectionRenderDispatcher.RenderSection>> original) {
        return VeilSceneTerrainSelection.sections(renderer, original.call(renderer));
    }

    @WrapOperation(
            method = "prepareChunkRenders",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/renderer/chunk/SectionRenderDispatcher$RenderSection;getVisibility(J)F"),
            require = 1)
    private float veil$sceneVisibility(
            SectionRenderDispatcher.RenderSection section, long millis, Operation<Float> original) {
        return VeilSceneTerrainSelection.active((LevelRenderer) (Object) this)
                ? 1.0f
                : original.call(section, millis);
    }
}
