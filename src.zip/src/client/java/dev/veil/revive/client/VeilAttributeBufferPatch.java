package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.terrain.AttributeUploadPlan;

import org.lwjgl.system.MemoryUtil;

final class VeilAttributeBufferPatch {
    private VeilAttributeBufferPatch() {}

    static GpuBuffer createReplacement(GpuBufferSlice original, AttributeUploadPlan plan) {
        if (original.buffer().isClosed()
                || original.length() != plan.bufferBytes()
                || (original.buffer().usage() & GpuBuffer.USAGE_COPY_SRC) == 0
                || plan.rangeCount() == 0
                || plan.payloadBytes() > 4 << 20)
            throw new IllegalArgumentException("Attribute replacement source/budget");
        var device = RenderSystem.getDevice();
        var scratch = MemoryUtil.memAlloc(plan.payloadBytes());
        GpuBuffer destination = null;
        try {
            destination =
                    device.createBuffer(
                            () -> "Veil local attribute replacement",
                            GpuBuffer.USAGE_VERTEX
                                    | GpuBuffer.USAGE_COPY_SRC
                                    | GpuBuffer.USAGE_COPY_DST,
                            plan.bufferBytes());
            var encoder = device.createCommandEncoder();
            encoder.copyToBuffer(original, destination.slice());
            for (int range = 0; range < plan.rangeCount(); range++) {
                scratch.clear().limit(plan.size(range));
                scratch.put(plan.payload(range)).flip();
                encoder.writeToBuffer(
                        destination.slice(plan.offset(range), plan.size(range)), scratch);
            }
            return destination;
        } catch (RuntimeException | Error failure) {
            if (destination != null)
                try {
                    destination.close();
                } catch (RuntimeException | Error cleanup) {
                    failure.addSuppressed(cleanup);
                }
            throw failure;
        } finally {
            MemoryUtil.memFree(scratch);
        }
    }
}
