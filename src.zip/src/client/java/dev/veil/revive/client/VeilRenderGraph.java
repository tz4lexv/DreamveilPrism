package dev.veil.revive.client;

import static org.lwjgl.vulkan.KHRRayTracingPipeline.VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR;
import static org.lwjgl.vulkan.VK13.*;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class VeilRenderGraph {
    public enum Kind {
        BUFFER,
        IMAGE
    }

    public enum Layout {
        NONE,
        UNDEFINED,
        GENERAL,
        SHADER_READ_ONLY,
        COLOR_ATTACHMENT,
        DEPTH_READ_ONLY,
        DEPTH_ATTACHMENT,
        TRANSFER_SOURCE,
        TRANSFER_DESTINATION
    }

    public enum Access {
        COMPUTE_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT,
                Layout.NONE),
        COMPUTE_WRITE(
                Kind.BUFFER,
                false,
                true,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.NONE),
        COMPUTE_READ_WRITE(
                Kind.BUFFER,
                true,
                true,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.NONE),
        FRAGMENT_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT,
                Layout.NONE),
        FRAGMENT_WRITE(
                Kind.BUFFER,
                false,
                true,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.NONE),
        FRAGMENT_READ_WRITE(
                Kind.BUFFER,
                true,
                true,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.NONE),
        RAY_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT,
                Layout.NONE),
        RAY_WRITE(
                Kind.BUFFER,
                false,
                true,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.NONE),
        RAY_READ_WRITE(
                Kind.BUFFER,
                true,
                true,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.NONE),
        VERTEX_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_VERTEX_INPUT_BIT,
                VK_ACCESS_2_VERTEX_ATTRIBUTE_READ_BIT,
                Layout.NONE),
        INDEX_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_VERTEX_INPUT_BIT,
                VK_ACCESS_2_INDEX_READ_BIT,
                Layout.NONE),
        INDIRECT_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_DRAW_INDIRECT_BIT,
                VK_ACCESS_2_INDIRECT_COMMAND_READ_BIT,
                Layout.NONE),
        BUFFER_TRANSFER_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_TRANSFER_READ_BIT,
                Layout.NONE),
        BUFFER_TRANSFER_WRITE(
                Kind.BUFFER,
                false,
                true,
                VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_TRANSFER_WRITE_BIT,
                Layout.NONE),
        COMPUTE_SAMPLE(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_SHADER_SAMPLED_READ_BIT,
                Layout.SHADER_READ_ONLY),
        FRAGMENT_SAMPLE(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_SAMPLED_READ_BIT,
                Layout.SHADER_READ_ONLY),
        RAY_SAMPLE(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_SHADER_SAMPLED_READ_BIT,
                Layout.SHADER_READ_ONLY),
        COMPUTE_SAMPLE_GENERAL(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_SHADER_SAMPLED_READ_BIT,
                Layout.GENERAL),
        FRAGMENT_SAMPLE_GENERAL(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_SAMPLED_READ_BIT,
                Layout.GENERAL),
        RAY_SAMPLE_GENERAL(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_SHADER_SAMPLED_READ_BIT,
                Layout.GENERAL),
        COMPUTE_IMAGE_READ(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT,
                Layout.GENERAL),
        COMPUTE_IMAGE_WRITE(
                Kind.IMAGE,
                false,
                true,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.GENERAL),
        COMPUTE_IMAGE_READ_WRITE(
                Kind.IMAGE,
                true,
                true,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.GENERAL),
        FRAGMENT_IMAGE_READ(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT,
                Layout.GENERAL),
        FRAGMENT_IMAGE_WRITE(
                Kind.IMAGE,
                false,
                true,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.GENERAL),
        FRAGMENT_IMAGE_READ_WRITE(
                Kind.IMAGE,
                true,
                true,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.GENERAL),
        RAY_IMAGE_READ(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT,
                Layout.GENERAL),
        RAY_IMAGE_WRITE(
                Kind.IMAGE,
                false,
                true,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.GENERAL),
        RAY_IMAGE_READ_WRITE(
                Kind.IMAGE,
                true,
                true,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.GENERAL),
        DEPTH_READ(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT,
                VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_READ_BIT,
                Layout.DEPTH_READ_ONLY),
        DEPTH_WRITE(
                Kind.IMAGE,
                false,
                true,
                VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT,
                VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
                Layout.DEPTH_ATTACHMENT),
        SCENE_DEPTH_WRITE(
                Kind.IMAGE,
                false,
                true,
                VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT,
                VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
                Layout.GENERAL),
        DEPTH_READ_WRITE(
                Kind.IMAGE,
                true,
                true,
                VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT,
                VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_READ_BIT
                        | VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
                Layout.DEPTH_ATTACHMENT),
        COLOR_READ_WRITE(
                Kind.IMAGE,
                true,
                true,
                VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT,
                VK_ACCESS_2_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT,
                Layout.COLOR_ATTACHMENT),
        COLOR_WRITE(
                Kind.IMAGE,
                false,
                true,
                VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT,
                VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT,
                Layout.COLOR_ATTACHMENT),
        SCENE_COLOR_WRITE(
                Kind.IMAGE,
                false,
                true,
                VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT,
                VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT,
                Layout.GENERAL),
        TRANSFER_READ(
                Kind.IMAGE,
                true,
                false,
                VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_TRANSFER_READ_BIT,
                Layout.TRANSFER_SOURCE),
        TRANSFER_WRITE(
                Kind.IMAGE,
                false,
                true,
                VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_TRANSFER_WRITE_BIT,
                Layout.TRANSFER_DESTINATION),
        COMPUTE_UNIFORM_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT,
                VK_ACCESS_2_UNIFORM_READ_BIT,
                Layout.NONE),
        FRAGMENT_UNIFORM_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_UNIFORM_READ_BIT,
                Layout.NONE),
        GRAPHICS_UNIFORM_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_ALL_GRAPHICS_BIT,
                VK_ACCESS_2_UNIFORM_READ_BIT,
                Layout.NONE),
        RAY_UNIFORM_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
                VK_ACCESS_2_UNIFORM_READ_BIT,
                Layout.NONE),
        GRAPHICS_BUFFER_READ(
                Kind.BUFFER,
                true,
                false,
                VK_PIPELINE_STAGE_2_ALL_GRAPHICS_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT,
                Layout.NONE),
        GRAPHICS_BUFFER_WRITE(
                Kind.BUFFER,
                false,
                true,
                VK_PIPELINE_STAGE_2_ALL_GRAPHICS_BIT,
                VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.NONE),
        GRAPHICS_BUFFER_READ_WRITE(
                Kind.BUFFER,
                true,
                true,
                VK_PIPELINE_STAGE_2_ALL_GRAPHICS_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                Layout.NONE);

        private final Kind kind;
        private final boolean read;
        private final boolean write;
        private final long stages;
        private final long mask;
        private final Layout layout;

        Access(Kind kind, boolean read, boolean write, long stages, long mask, Layout layout) {
            this.kind = kind;
            this.read = read;
            this.write = write;
            this.stages = stages;
            this.mask = mask;
            this.layout = layout;
        }

        public Kind kind() {
            return kind;
        }

        public boolean reads() {
            return read;
        }

        public boolean writes() {
            return write;
        }

        public long stages() {
            return stages;
        }

        public long mask() {
            return mask;
        }

        public Layout layout() {
            return layout;
        }
    }

    public record Subresource(
            int baseMip,
            int levelCount,
            int baseLayer,
            int layerCount,
            long byteOffset,
            long byteCount) {
        public Subresource(int baseMip, int levelCount, int baseLayer, int layerCount) {
            this(baseMip, levelCount, baseLayer, layerCount, 0, 0);
        }

        public static final Subresource WHOLE = new Subresource(-1, -1, -1, -1);

        public Subresource {
            boolean whole =
                    baseMip == -1 && levelCount == -1 && baseLayer == -1 && layerCount == -1;
            boolean buffer =
                    baseMip == -2 && levelCount == -2 && baseLayer == -2 && layerCount == -2;
            if (buffer
                    ? byteOffset < 0 || byteCount < 1 || byteCount > Long.MAX_VALUE - byteOffset
                    : byteOffset != 0
                            || byteCount != 0
                            || !whole
                                    && (baseMip < 0
                                            || levelCount < 1
                                            || baseLayer < 0
                                            || layerCount < 1
                                            || levelCount > Integer.MAX_VALUE - baseMip
                                            || layerCount > Integer.MAX_VALUE - baseLayer)) {
                throw new IllegalArgumentException("Invalid subresource range");
            }
        }

        public static Subresource image(
                int baseMip, int levelCount, int baseLayer, int layerCount) {
            return new Subresource(baseMip, levelCount, baseLayer, layerCount);
        }

        public boolean whole() {
            return baseMip == -1;
        }

        public static Subresource buffer(long offset, long bytes) {
            return new Subresource(-2, -2, -2, -2, offset, bytes);
        }

        public boolean bufferRange() {
            return byteCount > 0;
        }

        public boolean overlaps(Subresource other) {
            Objects.requireNonNull(other, "other");
            if (whole() || other.whole()) return true;
            if (bufferRange() || other.bufferRange())
                return bufferRange()
                        && other.bufferRange()
                        && byteOffset < other.byteOffset + other.byteCount
                        && other.byteOffset < byteOffset + byteCount;
            return overlaps(baseMip, levelCount, other.baseMip, other.levelCount)
                    && overlaps(baseLayer, layerCount, other.baseLayer, other.layerCount);
        }

        public boolean covers(Subresource other) {
            Objects.requireNonNull(other, "other");
            if (whole()) return true;
            if (other.whole()) return false;
            if (bufferRange() || other.bufferRange())
                return bufferRange()
                        && other.bufferRange()
                        && byteOffset <= other.byteOffset
                        && byteOffset + byteCount >= other.byteOffset + other.byteCount;
            return baseMip <= other.baseMip
                    && baseMip + levelCount >= other.baseMip + other.levelCount
                    && baseLayer <= other.baseLayer
                    && baseLayer + layerCount >= other.baseLayer + other.layerCount;
        }

        private static boolean overlaps(int aBase, int aCount, int bBase, int bCount) {
            return aBase < bBase + bCount && bBase < aBase + aCount;
        }
    }

    public record Use(String resource, Access access, Subresource subresource) {
        public Use {
            if (resource == null || resource.isBlank())
                throw new IllegalArgumentException("Use resource is blank");
            Objects.requireNonNull(access, "access");
            subresource = subresource == null ? Subresource.WHOLE : subresource;
            if (access.kind() == Kind.BUFFER && !subresource.whole() && !subresource.bufferRange()
                    || access.kind() == Kind.IMAGE && subresource.bufferRange()) {
                throw new IllegalArgumentException(
                        "Buffer graph uses cannot select image subresources: " + resource);
            }
        }

        public static Use whole(String resource, Access access) {
            return new Use(resource, access, Subresource.WHOLE);
        }
    }

    public record Pass(
            String name, Map<String, Access> resources, List<Use> uses, Set<String> after) {
        public Pass {
            if (name == null || name.isBlank())
                throw new IllegalArgumentException("Pass name is blank");
            resources = Map.copyOf(resources);
            uses = List.copyOf(uses);
            dev.veil.revive.client.graphics.rendergraph.GraphPassUseRules.validate(name, uses);
            after = Set.copyOf(after);
        }

        public Pass(String name, Map<String, Access> resources, Set<String> after) {
            this(
                    name,
                    resources,
                    resources.entrySet().stream()
                            .map(entry -> Use.whole(entry.getKey(), entry.getValue()))
                            .toList(),
                    after);
        }
    }

    public record State(long stages, long access, boolean write, Layout layout) {
        public State(long stages, long access, boolean write) {
            this(stages, access, write, Layout.NONE);
        }

        public static State of(Access access) {
            return new State(access.stages(), access.mask(), access.writes(), access.layout());
        }

        public State union(State other) {
            if (other == null) return this;
            Layout merged =
                    layout == other.layout
                            ? layout
                            : layout == Layout.NONE
                                    ? other.layout
                                    : other.layout == Layout.NONE ? layout : Layout.GENERAL;
            return new State(
                    stages | other.stages, access | other.access, write || other.write, merged);
        }
    }

    public record ImageState(Subresource subresource, State state) {
        public ImageState {
            Objects.requireNonNull(subresource, "subresource");
            Objects.requireNonNull(state, "state");
            if (subresource.whole() || subresource.bufferRange() || state.layout() == Layout.NONE)
                throw new IllegalArgumentException("Image state requires a finite image range");
        }
    }

    public record Barrier(
            String resource, Subresource subresource, State source, State destination) {
        public Barrier {
            subresource = subresource == null ? Subresource.WHOLE : subresource;
        }

        public Barrier(String resource, State source, State destination) {
            this(resource, Subresource.WHOLE, source, destination);
        }
    }

    public static final class Tracker {
        private final dev.veil.revive.client.graphics.rendergraph.ResourceStateTracker tracker =
                new dev.veil.revive.client.graphics.rendergraph.ResourceStateTracker();

        public void initialize(String resource, State state) {
            tracker.initialize(resource, state);
        }

        public void initialize(String resource, Subresource subresource, State state) {
            tracker.initialize(resource, subresource, state);
        }

        public void initialize(String resource, Subresource subresource, State state, Kind kind) {
            tracker.initialize(resource, subresource, state, kind);
        }

        public State current(String resource) {
            return tracker.current(resource);
        }

        public List<ImageState> imageStates(String resource) {
            return tracker.imageStates(resource);
        }

        public List<Barrier> release(String resource, State initial, State target) {
            return tracker.release(resource, initial, target);
        }

        public List<Barrier> before(Pass pass) {
            return tracker.before(pass);
        }
    }

    private VeilRenderGraph() {}

    public static List<Pass> compile(Map<String, Kind> resources, List<Pass> passes) {
        return dev.veil.revive.client.graphics.rendergraph.GraphCompiler.compile(resources, passes);
    }

    public static List<Pass> compile(
            Map<String, Kind> resources, List<Pass> passes, Set<String> imported) {
        return dev.veil.revive.client.graphics.rendergraph.GraphCompiler.compile(
                resources, passes, imported);
    }

    public static List<Pass> compile(
            Map<String, Kind> resources,
            List<Pass> passes,
            Set<String> initialized,
            Set<String> readOnly) {
        return dev.veil.revive.client.graphics.rendergraph.GraphCompiler.compile(
                resources, passes, initialized, readOnly);
    }
}
