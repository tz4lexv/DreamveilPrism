package dev.veil.revive.client;

import static org.lwjgl.util.spvc.Spvc.*;

import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.VkSpecializationInfo;
import org.lwjgl.vulkan.VkSpecializationMapEntry;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

public record VeilSpecializationValues(Map<Integer, Value> values) {
    private static final VeilSpecializationValues EMPTY = new VeilSpecializationValues(Map.of());

    public record Value(int baseType, int bits) {
        public Value {
            if (baseType != SPVC_BASETYPE_BOOLEAN
                    && baseType != SPVC_BASETYPE_INT32
                    && baseType != SPVC_BASETYPE_UINT32
                    && baseType != SPVC_BASETYPE_FP32) {
                throw new IllegalArgumentException(
                        "Specialization values support bool, int32, uint32 and float32 only");
            }
            if (baseType == SPVC_BASETYPE_BOOLEAN && bits != 0 && bits != 1) {
                throw new IllegalArgumentException("Boolean specialization value must be 0 or 1");
            }
        }

        public static Value bool(boolean value) {
            return new Value(SPVC_BASETYPE_BOOLEAN, value ? 1 : 0);
        }

        public static Value integer(int value) {
            return new Value(SPVC_BASETYPE_INT32, value);
        }

        public static Value unsignedInteger(int bits) {
            return new Value(SPVC_BASETYPE_UINT32, bits);
        }

        public static Value floating(float value) {
            return new Value(SPVC_BASETYPE_FP32, Float.floatToRawIntBits(value));
        }
    }

    public VeilSpecializationValues {
        Objects.requireNonNull(values, "values");
        TreeMap<Integer, Value> sorted = new TreeMap<>();
        values.forEach(
                (id, value) -> {
                    if (id == null || id < 0)
                        throw new IllegalArgumentException("Specialization ID must be nonnegative");
                    sorted.put(id, Objects.requireNonNull(value, "specialization value"));
                });
        values = Collections.unmodifiableMap(sorted);
    }

    public static VeilSpecializationValues empty() {
        return EMPTY;
    }

    public static VeilSpecializationValues of(Map<Integer, Value> values) {
        return values.isEmpty() ? EMPTY : new VeilSpecializationValues(values);
    }

    public void validate(VeilShaderInterface shaderInterface, VeilShaderStage stage) {
        Objects.requireNonNull(shaderInterface, "shaderInterface");
        Objects.requireNonNull(stage, "stage");
        for (var entry : values.entrySet()) {
            var constant =
                    shaderInterface.specializationConstants().stream()
                            .filter(
                                    candidate ->
                                            candidate.constantId() == entry.getKey()
                                                    && (candidate.stageFlags()
                                                                    & stage.vkStageFlags())
                                                            != 0)
                            .findFirst()
                            .orElseThrow(
                                    () ->
                                            new IllegalArgumentException(
                                                    "Unknown specialization constant ID="
                                                            + entry.getKey()
                                                            + " stage="
                                                            + stage));
            Value value = entry.getValue();
            if (constant.baseType() != value.baseType()
                    || value.baseType() != SPVC_BASETYPE_BOOLEAN && constant.bitWidth() != 32) {
                throw new IllegalArgumentException(
                        "Specialization type mismatch at ID="
                                + entry.getKey()
                                + " stage="
                                + stage
                                + ": expected baseType="
                                + constant.baseType()
                                + " bits="
                                + constant.bitWidth()
                                + ", supplied baseType="
                                + value.baseType());
            }
        }
    }

    NativeData nativeData() {
        return new NativeData(values);
    }

    static final class NativeData implements AutoCloseable {
        private VkSpecializationInfo info;
        private VkSpecializationMapEntry.Buffer entries;
        private ByteBuffer data;

        private NativeData(Map<Integer, Value> values) {
            if (values.isEmpty()) return;
            try {
                entries = VkSpecializationMapEntry.calloc(values.size());
                data =
                        MemoryUtil.memAlloc(Math.multiplyExact(values.size(), Integer.BYTES))
                                .order(ByteOrder.nativeOrder());
                int index = 0;
                for (var entry : values.entrySet()) {
                    entries.get(index)
                            .constantID(entry.getKey())
                            .offset(index * Integer.BYTES)
                            .size(Integer.BYTES);
                    data.putInt(entry.getValue().bits());
                    index++;
                }
                data.flip();
                info = VkSpecializationInfo.calloc().pMapEntries(entries).pData(data);
            } catch (RuntimeException | Error failure) {
                close();
                throw failure;
            }
        }

        VkSpecializationInfo info() {
            return info;
        }

        @Override
        public void close() {
            if (info != null) {
                info.free();
                info = null;
            }
            if (entries != null) {
                entries.free();
                entries = null;
            }
            if (data != null) {
                MemoryUtil.memFree(data);
                data = null;
            }
        }
    }
}
