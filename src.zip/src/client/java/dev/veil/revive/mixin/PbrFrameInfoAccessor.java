package dev.veil.revive.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(targets = "net.minecraft.client.renderer.texture.SpriteContents$FrameInfo")
public interface PbrFrameInfoAccessor {
    @Accessor("index")
    int veil$pbrIndex();

    @Accessor("time")
    int veil$pbrTime();
}
