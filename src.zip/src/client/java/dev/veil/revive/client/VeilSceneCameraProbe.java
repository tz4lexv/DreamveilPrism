package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.state.level.CameraRenderState;

import java.nio.ByteOrder;
import java.nio.file.Files;
import java.util.Map;

final class VeilSceneCameraProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.sceneCameraProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static boolean pending, complete;
    private static long started, ready;
    private static int phase;
    private static float[] baseline;
    private static double mainX, mainY, mainZ;
    private static VeilShaderPackRuntime previous;

    private VeilSceneCameraProbe() {}

    static Map<String, String> overrides() {
        return ENABLED ? Map.of("fov", "60.0") : Map.of();
    }

    static void checkTimeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 240_000_000_000L)
            fail(new IllegalStateException("Execution failed or timed out"));
    }

    static void tick(VeilShaderPackRuntime active, CameraRenderState camera) {
        if (!ENABLED || complete || pending || !VeilBenchmarkWorld.terrainReady()) return;
        long now = System.nanoTime();
        if (ready == 0) ready = now;
        if (now - ready < (phase == 0 ? 30_000_000_000L : 3_000_000_000L)
                || phase == 3 && active == previous) return;
        try {
            if (phase == 0) {
                mainX = camera.pos.x;
                mainY = camera.pos.y;
                mainZ = camera.pos.z;
            } else if (phase == 2
                    && Math.sqrt(
                                    Math.pow(camera.pos.x - mainX, 2)
                                            + Math.pow(camera.pos.y - mainY, 2)
                                            + Math.pow(camera.pos.z - mainZ, 2))
                            < 0.2) {
                throw new IllegalStateException("Main camera did not move for fixed-camera test");
            }
            var view = active.output("viewDepth");
            int width = view.getWidth(0), height = view.getHeight(0);
            long size = (long) width * height * 4;
            if (size > 4 * 1024 * 1024)
                throw new IllegalStateException("Camera readback exceeds budget");
            var buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil fixed camera depth probe",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    size);
            pending = true;
            try {
                active.readDepthOutput(
                        "viewDepth",
                        buffer,
                        () -> {
                            try (var mapped = buffer.map(true, false)) {
                                float[] depth = new float[width * height];
                                mapped.data()
                                        .order(ByteOrder.nativeOrder())
                                        .asFloatBuffer()
                                        .get(depth);
                                verify(active, depth, width, height);
                            } catch (Exception failure) {
                                fail(failure);
                            } finally {
                                pending = false;
                                buffer.close();
                                if (complete) Minecraft.getInstance().stop();
                            }
                        });
            } catch (RuntimeException failure) {
                buffer.close();
                throw failure;
            }
        } catch (RuntimeException failure) {
            fail(failure);
        }
    }

    private static void verify(VeilShaderPackRuntime active, float[] depth, int width, int height)
            throws java.io.IOException {
        int geometry = 0, changed = 0;
        double error = 0;
        for (int i = 0; i < depth.length; i++) {
            if (!Float.isFinite(depth[i]) || depth[i] < 0 || depth[i] > 1)
                throw new IllegalStateException("Invalid perspective depth");
            if (depth[i] > 0) geometry++;
            if (baseline != null) {
                double difference = Math.abs(depth[i] - baseline[i]);
                if (difference > 0.0001) changed++;
                error += difference;
            }
        }
        if (geometry < 100 || geometry == depth.length)
            throw new IllegalStateException("Perspective scene coverage insufficient: " + geometry);
        if (phase == 2 && (changed > depth.length / 1000 || error / depth.length > 0.000001))
            throw new IllegalStateException(
                    "Fixed world depth moved with main camera: changed="
                            + changed
                            + " meanError="
                            + error / depth.length);
        if (phase == 3 && changed < 100)
            throw new IllegalStateException("Creator FOV setting did not change projection");
        var directory = VeilPlatform.get().getGameDir().resolve("logs/scene-camera");
        Files.createDirectories(directory);
        Files.writeString(
                directory.resolve("phase-" + phase + ".json"),
                "{\"geometry_pixels\":"
                        + geometry
                        + ",\"changed_pixels\":"
                        + changed
                        + ",\"mean_depth_error\":"
                        + error / depth.length
                        + ",\"width\":"
                        + width
                        + ",\"height\":"
                        + height
                        + "}");
        var image =
                new java.awt.image.BufferedImage(
                        width, height, java.awt.image.BufferedImage.TYPE_INT_RGB);
        for (int i = 0; i < depth.length; i++) {
            int value = Math.min(255, Math.round(depth[i] * 10000));
            image.setRGB(i % width, i / width, value * 0x010101);
        }
        javax.imageio.ImageIO.write(
                image, "png", directory.resolve("phase-" + phase + "-depth.png").toFile());
        ReviveMod.LOGGER.info(
                "Veil scene camera GPU probe: phase={} geometry={} changed={} meanError={}",
                phase,
                geometry,
                changed,
                error / depth.length);
        if (phase == 1) {
            baseline = depth;
            var player = Minecraft.getInstance().player;
            player.setPos(player.getX() + 0.25, player.getY(), player.getZ() + 0.125);
            player.setDeltaMovement(net.minecraft.world.phys.Vec3.ZERO);
        } else if (phase == 2) {
            previous = active;
            VeilShaderService.setting("fov", "80.0");
        } else if (phase == 3) {
            complete = true;
            ReviveMod.LOGGER.info(
                    "Veil scene camera GPU probe: PASS (native perspective terrain, fixed world camera after main camera translation, transactional creator FOV)");
        }
        if (phase == 0) baseline = depth;
        phase++;
        ready = System.nanoTime();
    }

    private static void fail(Exception failure) {
        complete = true;
        ReviveMod.LOGGER.error("Veil scene camera GPU probe: FAIL", failure);
        Minecraft.getInstance().stop();
    }
}
