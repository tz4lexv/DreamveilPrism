package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;

import dev.veil.revive.mixin.RenderPassAccessor;

final class VeilIndirectCount {
    private VeilIndirectCount() {}

    static void draw(
            RenderPass pass, GpuBufferSlice commands, GpuBufferSlice count, int maximumDraws) {
        var backend = ((RenderPassAccessor) (Object) pass).veil$backend();
        dev.veil.revive.client.terrain.indirect.IndexedTerrainCommands.indirectCount(
                backend, commands, count, maximumDraws);
    }
}
