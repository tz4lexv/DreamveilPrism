package dev.veil.api;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;

/**
 * One atomic CPU checkpoint for a creator-defined simulation's clock, fields and opaque state. The
 * bundle is encoded as one bounded VSS1 snapshot, so a crash cannot commit only some fields of a
 * single checkpoint. It is not a Vulkan readback/upload or a weather model.
 *
 * <p>Callers coordinate their own simulation steps and prepare any GPU transfers separately.
 */
public final class VeilSimulationBundle {
    private static final int MAGIC = 0x56534231; // VSB1
    private static final int VERSION = 1;
    private static final int HEADER_BYTES = Integer.BYTES * 3;
    private static final int ENTRY_HEADER_BYTES = Integer.BYTES * 3;
    private static final int MAX_ENTRIES = 128;
    private static final int MAX_NAME_BYTES = 256;

    private enum Kind {
        DATA(1),
        FIELD(2),
        CLOCK(3);

        final int wireId;

        Kind(int wireId) {
            this.wireId = wireId;
        }

        static Kind decode(int id) throws IOException {
            for (Kind kind : values()) if (kind.wireId == id) return kind;
            throw new IOException("Unsupported simulation bundle entry kind: " + id);
        }
    }

    private record Entry(Kind kind, byte[] bytes) {
        Entry {
            Objects.requireNonNull(kind, "kind");
            bytes = Objects.requireNonNull(bytes, "bytes").clone();
        }
    }

    private final TreeMap<String, Entry> entries = new TreeMap<>();

    /** Adds or replaces arbitrary creator-defined CPU bytes, without assigning any semantics. */
    public VeilSimulationBundle putData(String id, byte[] bytes) {
        put(id, Kind.DATA, bytes);
        return this;
    }

    public VeilSimulationBundle putField(String id, VeilSimulationFieldSnapshot field) {
        Objects.requireNonNull(field, "field");
        put(id, Kind.FIELD, field.encode());
        return this;
    }

    public VeilSimulationBundle putClock(String id, VeilSimulationClock clock) {
        Objects.requireNonNull(clock, "clock");
        put(id, Kind.CLOCK, clock.snapshotBytes());
        return this;
    }

    public boolean contains(String id) {
        checkName(id);
        return entries.containsKey(id);
    }

    public Set<String> ids() {
        return Set.copyOf(entries.keySet());
    }

    public Optional<byte[]> data(String id) throws IOException {
        Entry entry = find(id, Kind.DATA);
        return entry == null ? Optional.empty() : Optional.of(entry.bytes.clone());
    }

    public Optional<VeilSimulationFieldSnapshot> field(String id) throws IOException {
        Entry entry = find(id, Kind.FIELD);
        return entry == null
                ? Optional.empty()
                : Optional.of(VeilSimulationFieldSnapshot.decode(entry.bytes));
    }

    /** The target clock remains unchanged if the stored parameters or payload are invalid. */
    public boolean restoreClock(String id, VeilSimulationClock clock) throws IOException {
        Objects.requireNonNull(clock, "clock");
        Entry entry = find(id, Kind.CLOCK);
        if (entry == null) return false;
        clock.restoreBytes(entry.bytes);
        return true;
    }

    /**
     * Save the whole bundle in one atomic file. The caller must capture its CPU state consistently;
     * no GPU synchronization or disk I/O scheduling is performed here.
     */
    public void save(VeilSimulationStateStore store, String worldId, String packId, String stateId)
            throws IOException {
        Objects.requireNonNull(store, "store");
        byte[] serialized = encode();
        if (serialized.length > store.maxSnapshotBytes())
            throw new IllegalArgumentException("Simulation bundle exceeds configured budget");
        store.saveAtomic(worldId, packId, stateId, serialized);
    }

    public static Optional<VeilSimulationBundle> load(
            VeilSimulationStateStore store, String worldId, String packId, String stateId)
            throws IOException {
        Objects.requireNonNull(store, "store");
        var bytes = store.load(worldId, packId, stateId);
        if (bytes.isEmpty()) return Optional.empty();
        return Optional.of(decode(bytes.get()));
    }

    /** Deterministic, bounded little-endian encoding independent of field names or meaning. */
    public byte[] encode() {
        long length = HEADER_BYTES;
        for (var entry : entries.entrySet()) {
            byte[] name = checkName(entry.getKey());
            length += ENTRY_HEADER_BYTES + name.length + (long) entry.getValue().bytes.length;
            if (length > VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES)
                throw new IllegalArgumentException(
                        "Simulation bundle exceeds maximum snapshot size");
        }
        ByteBuffer output = ByteBuffer.allocate((int) length).order(ByteOrder.LITTLE_ENDIAN);
        output.putInt(MAGIC).putInt(VERSION).putInt(entries.size());
        for (var item : entries.entrySet()) {
            byte[] name = checkName(item.getKey());
            Entry entry = item.getValue();
            output.putInt(name.length).putInt(entry.kind.wireId).putInt(entry.bytes.length);
            output.put(name).put(entry.bytes);
        }
        return output.array();
    }

    /** Strict decoding: no unknown kinds, duplicate IDs, malformed UTF-8 or trailing bytes. */
    public static VeilSimulationBundle decode(byte[] bytes) throws IOException {
        Objects.requireNonNull(bytes, "bytes");
        if (bytes.length < HEADER_BYTES
                || bytes.length > VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES)
            throw new IOException("Invalid simulation bundle size");
        ByteBuffer input = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        if (input.getInt() != MAGIC || input.getInt() != VERSION)
            throw new IOException("Unsupported simulation bundle format");
        int count = input.getInt();
        if (count < 0 || count > MAX_ENTRIES)
            throw new IOException("Invalid simulation bundle entry count");
        var bundle = new VeilSimulationBundle();
        for (int index = 0; index < count; index++) {
            if (input.remaining() < ENTRY_HEADER_BYTES)
                throw new IOException("Truncated simulation bundle entry header");
            int nameLength = input.getInt();
            Kind kind = Kind.decode(input.getInt());
            int payloadLength = input.getInt();
            if (nameLength < 1
                    || nameLength > MAX_NAME_BYTES
                    || payloadLength < 0
                    || (long) nameLength + payloadLength > input.remaining())
                throw new IOException("Invalid simulation bundle entry lengths");
            byte[] rawName = new byte[nameLength];
            input.get(rawName);
            String name;
            try {
                name =
                        StandardCharsets.UTF_8
                                .newDecoder()
                                .onMalformedInput(CodingErrorAction.REPORT)
                                .onUnmappableCharacter(CodingErrorAction.REPORT)
                                .decode(ByteBuffer.wrap(rawName))
                                .toString();
            } catch (CharacterCodingException malformed) {
                throw new IOException("Malformed simulation bundle entry name", malformed);
            }
            try {
                if (!Arrays.equals(checkName(name), rawName))
                    throw new IOException("Noncanonical simulation bundle entry name");
            } catch (IllegalArgumentException invalid) {
                throw new IOException("Invalid simulation bundle entry name", invalid);
            }
            if (bundle.entries.containsKey(name))
                throw new IOException("Duplicate simulation bundle entry name");
            byte[] payload = new byte[payloadLength];
            input.get(payload);
            // Validate all typed data before exposing any entry from the decoded bundle.
            if (kind == Kind.FIELD) VeilSimulationFieldSnapshot.decode(payload);
            if (kind == Kind.CLOCK) validateClockEncoding(payload);
            bundle.entries.put(name, new Entry(kind, payload));
        }
        if (input.hasRemaining()) throw new IOException("Trailing simulation bundle bytes");
        return bundle;
    }

    private static void validateClockEncoding(byte[] payload) throws IOException {
        // Field-independent parameters are checked by the destination clock on restore.
        if (payload.length != Integer.BYTES * 3 + Double.BYTES * 2 + Long.BYTES)
            throw new IOException("Invalid bundled clock length");
        ByteBuffer encoded = ByteBuffer.wrap(payload).order(ByteOrder.LITTLE_ENDIAN);
        int magic = encoded.getInt();
        int version = encoded.getInt();
        double step = encoded.getDouble();
        int budget = encoded.getInt();
        double remainder = encoded.getDouble();
        long ticks = encoded.getLong();
        if (magic != 0x56534331
                || version != 1
                || !Double.isFinite(step)
                || step <= 0
                || step > 3600
                || budget < 1
                || budget > 1024
                || !Double.isFinite(remainder)
                || remainder < 0
                || remainder >= step
                || ticks < 0) throw new IOException("Invalid bundled clock metadata");
    }

    private void put(String id, Kind kind, byte[] value) {
        checkName(id);
        Objects.requireNonNull(value, "value");
        if (!entries.containsKey(id) && entries.size() == MAX_ENTRIES)
            throw new IllegalArgumentException("Too many simulation bundle entries");
        entries.put(id, new Entry(kind, value));
    }

    private Entry find(String id, Kind kind) throws IOException {
        checkName(id);
        Entry entry = entries.get(id);
        if (entry != null && entry.kind != kind)
            throw new IOException("Simulation bundle entry has a different type: " + id);
        return entry;
    }

    private static byte[] checkName(String name) {
        Objects.requireNonNull(name, "entry name");
        byte[] utf8 = name.getBytes(StandardCharsets.UTF_8);
        if (name.isBlank()
                || utf8.length > MAX_NAME_BYTES
                || name.codePoints().anyMatch(Character::isISOControl))
            throw new IllegalArgumentException("Invalid simulation bundle entry name");
        return utf8;
    }
}
