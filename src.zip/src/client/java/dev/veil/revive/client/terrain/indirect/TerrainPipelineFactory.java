package dev.veil.revive.client.terrain.indirect;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.shaders.UniformType;

import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.resources.Identifier;

import java.util.EnumMap;
import java.util.Map;

public final class TerrainPipelineFactory {
    private TerrainPipelineFactory() {}

    public record Pipelines(
            Map<ChunkSectionLayer, RenderPipeline> normal,
            Map<ChunkSectionLayer, RenderPipeline> direct,
            RenderPipeline lod,
            RenderPipeline directLod,
            RenderPipeline[][] packed) {}

    public static Pipelines create() {
        var normal = new EnumMap<ChunkSectionLayer, RenderPipeline>(ChunkSectionLayer.class);
        var directPipelines =
                new EnumMap<ChunkSectionLayer, RenderPipeline>(ChunkSectionLayer.class);
        RenderPipeline lod = null, directLod = null;
        RenderPipeline[][] packed = new RenderPipeline[2][2];
        BindGroupLayout layout =
                BindGroupLayout.builder()
                        .withUniform("VeilFrame", UniformType.UNIFORM_BUFFER)
                        .withUniform(
                                "VeilSections", UniformType.TEXEL_BUFFER, GpuFormat.RGBA32_SINT)
                        .build();
        BindGroupLayout directLayout =
                BindGroupLayout.builder()
                        .withUniform("VeilFrame", UniformType.UNIFORM_BUFFER)
                        .withUniform(
                                "VeilSections", UniformType.TEXEL_BUFFER, GpuFormat.RGBA32_SINT)
                        .withUniform(
                                "VeilDrawCommands", UniformType.TEXEL_BUFFER, GpuFormat.R32_SINT)
                        .build();
        for (ChunkSectionLayer layer : ChunkSectionLayer.values()) {
            for (boolean direct : new boolean[] {false, true}) {
                var builder =
                        RenderPipeline.builder(RenderPipelines.GENERIC_BLOCKS_SNIPPET)
                                .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                                .withBindGroupLayout(direct ? directLayout : layout)
                                .withVertexShader(
                                        Identifier.fromNamespaceAndPath(
                                                "veil",
                                                "core/terrain_indirect" + (direct ? "_multi" : "")))
                                .withFragmentShader(
                                        Identifier.fromNamespaceAndPath(
                                                "veil", "core/terrain_indirect"))
                                .withLocation(
                                        Identifier.fromNamespaceAndPath(
                                                "veil",
                                                "pipeline/indirect_"
                                                        + layer.label()
                                                        + (direct ? "_multi" : "")))
                                .withColorTargetState(layer.pipeline().getColorTargetStates()[0]);
                if (layer == ChunkSectionLayer.CUTOUT)
                    builder.withShaderDefine("ALPHA_CUTOUT", 0.5f);
                if (layer == ChunkSectionLayer.TRANSLUCENT)
                    builder.withShaderDefine("ALPHA_CUTOUT", 0.1f);
                if (direct) builder.withShaderDefine("VEIL_DIRECT_MULTI");
                (direct ? directPipelines : normal)
                        .put(
                                layer,
                                direct
                                        ? builder.build()
                                        : RenderPipelines.register(builder.build()));
            }
        }
        var lodFormat =
                com.mojang.blaze3d.vertex.VertexFormat.builder(0)
                        .addAttribute("Position", com.mojang.blaze3d.GpuFormat.RGBA16_UINT)
                        .addAttribute("Color", com.mojang.blaze3d.GpuFormat.RGBA8_UNORM)
                        .addAttribute("UV0", com.mojang.blaze3d.GpuFormat.RG32_FLOAT)
                        .addAttribute("UV2", com.mojang.blaze3d.GpuFormat.RG16_SINT)
                        .addAttribute("VeilTile", com.mojang.blaze3d.GpuFormat.RGBA16_UINT)
                        .build();
        for (boolean direct : new boolean[] {false, true}) {
            var builder =
                    RenderPipeline.builder(RenderPipelines.GENERIC_BLOCKS_SNIPPET)
                            .withLocation(
                                    Identifier.fromNamespaceAndPath(
                                            "veil",
                                            "pipeline/terrain_lod" + (direct ? "_multi" : "")))
                            .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                            .withBindGroupLayout(direct ? directLayout : layout)
                            .withVertexBinding(0, lodFormat)
                            .withVertexShader(
                                    Identifier.fromNamespaceAndPath(
                                            "veil", "core/terrain_lod" + (direct ? "_multi" : "")))
                            .withFragmentShader(
                                    Identifier.fromNamespaceAndPath("veil", "core/terrain_lod"));
            if (direct) {
                builder.withShaderDefine("VEIL_DIRECT_MULTI");
                directLod = builder.build();
            } else lod = RenderPipelines.register(builder.build());
        }
        initializePackedPipelines(packed);
        return new Pipelines(normal, directPipelines, lod, directLod, packed);
    }

    private static void initializePackedPipelines(RenderPipeline[][] packed) {
        for (int format = 0; format < 2; format++) {
            int stride = format == 0 ? 16 : 20;
            var vertexFormat =
                    com.mojang.blaze3d.vertex.VertexFormat.builder(0)
                            .addAttribute("Position", GpuFormat.R32_UINT)
                            .addAttribute("Color", GpuFormat.RGBA8_UNORM)
                            .addAttribute(
                                    "UV0",
                                    format == 0 ? GpuFormat.RG16_FLOAT : GpuFormat.RG32_FLOAT)
                            .addAttribute("VeilLightTile", GpuFormat.R32_UINT)
                            .build();
            for (int direct = 0; direct < 2; direct++) {
                var layout =
                        BindGroupLayout.builder()
                                .withUniform("VeilFrame", UniformType.UNIFORM_BUFFER)
                                .withUniform(
                                        "VeilSections",
                                        UniformType.TEXEL_BUFFER,
                                        GpuFormat.RGBA32_SINT)
                                .withUniform(
                                        "VeilTiles",
                                        UniformType.TEXEL_BUFFER,
                                        GpuFormat.RGBA16_UINT);
                if (direct == 1)
                    layout.withUniform(
                            "VeilDrawCommands", UniformType.TEXEL_BUFFER, GpuFormat.R32_SINT);
                var builder =
                        RenderPipeline.builder(RenderPipelines.GENERIC_BLOCKS_SNIPPET)
                                .withLocation(
                                        Identifier.fromNamespaceAndPath(
                                                "veil",
                                                "pipeline/terrain_packed" + stride + "_" + direct))
                                .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                                .withBindGroupLayout(layout.build())
                                .withVertexBinding(0, vertexFormat)
                                .withVertexShader(
                                        Identifier.fromNamespaceAndPath(
                                                "veil",
                                                "core/terrain_packed"
                                                        + (direct == 1 ? "_multi" : "")))
                                .withFragmentShader(
                                        Identifier.fromNamespaceAndPath(
                                                "veil", "core/terrain_lod"));
                if (direct == 1) builder.withShaderDefine("VEIL_DIRECT_MULTI");
                packed[format][direct] =
                        direct == 1 ? builder.build() : RenderPipelines.register(builder.build());
            }
        }
    }
}
