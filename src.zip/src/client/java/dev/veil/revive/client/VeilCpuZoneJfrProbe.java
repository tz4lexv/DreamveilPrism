package dev.veil.revive.client;

import jdk.jfr.Category;
import jdk.jfr.Event;
import jdk.jfr.EventType;
import jdk.jfr.Label;
import jdk.jfr.Name;
import jdk.jfr.StackTrace;

final class VeilCpuZoneJfrProbe {
    private static final boolean ENABLED = Boolean.getBoolean("veil.cpuZoneJfrEvents");
    private static final long THRESHOLD_NS =
            Math.max(1L, Long.getLong("veil.cpuZoneJfrThresholdNanos", 1_000_000L));
    private static final EventType TYPE = ENABLED ? EventType.getEventType(ZoneTiming.class) : null;

    private VeilCpuZoneJfrProbe() {}

    static boolean enabled() {
        return ENABLED && TYPE.isEnabled();
    }

    static void record(String zone, long startNanos, long endNanos) {
        if (!ENABLED || endNanos - startNanos < THRESHOLD_NS || !TYPE.isEnabled()) return;
        ZoneTiming event = new ZoneTiming();
        event.zone = zone;
        event.startNanos = startNanos;
        event.endNanos = endNanos;
        event.thresholdNanos = THRESHOLD_NS;
        event.commit();
    }

    @Name("dev.veil.CpuZoneTiming")
    @Label("Veil slow CPU zone")
    @Category({"Veil", "Diagnostics"})
    @StackTrace(false)
    static final class ZoneTiming extends Event {
        public String zone;
        public long startNanos;
        public long endNanos;
        public long thresholdNanos;
    }
}
