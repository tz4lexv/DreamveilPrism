package dev.veil.revive.client;

final class VeilTelemetryCsv {
    private VeilTelemetryCsv() {}

    static final class Session {
        private final java.nio.file.Path base;
        private java.nio.file.Path current;
        private String header;
        private int part;

        Session(java.nio.file.Path base) {
            this.base = base;
        }

        java.nio.file.Path append(String nextHeader, String row) throws java.io.IOException {
            if (!nextHeader.equals(header)) {
                int nextPart = header == null ? 0 : part + 1;
                String name = base.getFileName().toString();
                var destination =
                        nextPart == 0
                                ? base
                                : base.resolveSibling(
                                        name.substring(0, name.length() - 4)
                                                + "-part"
                                                + nextPart
                                                + ".csv");
                java.nio.file.Files.writeString(
                        destination,
                        nextHeader + row,
                        java.nio.charset.StandardCharsets.UTF_8,
                        java.nio.file.StandardOpenOption.CREATE_NEW,
                        java.nio.file.StandardOpenOption.WRITE);
                current = destination;
                header = nextHeader;
                part = nextPart;
            } else {
                java.nio.file.Files.writeString(
                        current,
                        row,
                        java.nio.charset.StandardCharsets.UTF_8,
                        java.nio.file.StandardOpenOption.APPEND,
                        java.nio.file.StandardOpenOption.WRITE);
            }
            return current;
        }
    }

    static String columns(String text, boolean names) {
        var usedNames = names ? new java.util.HashSet<String>() : null;
        return text.lines()
                .filter(line -> line.indexOf('=') > 0)
                .map(
                        line ->
                                names
                                        ? line.substring(0, line.indexOf('='))
                                        : line.substring(line.indexOf('=') + 1))
                .map(
                        value -> {
                            if (!names) return value;
                            String unique = value;
                            int occurrence = 1;
                            while (!usedNames.add(unique)) unique = value + "__" + ++occurrence;
                            return unique;
                        })
                .map(
                        value ->
                                value.indexOf(',') >= 0 || value.indexOf('"') >= 0
                                        ? "\"" + value.replace("\"", "\"\"") + "\""
                                        : value)
                .collect(java.util.stream.Collectors.joining(","));
    }
}
