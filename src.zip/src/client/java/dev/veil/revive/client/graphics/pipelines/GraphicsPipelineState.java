package dev.veil.revive.client.graphics.pipelines;

import java.util.List;

public record GraphicsPipelineState(
        int topology,
        int patchControlPoints,
        boolean fluidGeometry,
        Raster raster,
        Depth depth,
        Stencil stencil,
        List<ColorBlend> colors,
        boolean primitiveRestart) {
    /** Preserve the existing constructor and its default behavior. */
    public GraphicsPipelineState(
            int topology,
            int patchControlPoints,
            boolean fluidGeometry,
            Raster raster,
            Depth depth,
            Stencil stencil,
            List<ColorBlend> colors) {
        this(topology, patchControlPoints, fluidGeometry, raster, depth, stencil, colors, false);
    }

    public GraphicsPipelineState {
        colors = List.copyOf(colors);
    }

    public record Raster(
            boolean depthClamp,
            boolean rasterizerDiscard,
            int polygonMode,
            int cullMode,
            int frontFace,
            boolean depthBias,
            float depthBiasConstant,
            float depthBiasClamp,
            float depthBiasSlope,
            float lineWidth) {}

    public record Depth(boolean test, boolean write, int compare) {}

    public record Stencil(boolean enabled, StencilFace front, StencilFace back) {}

    public record StencilFace(
            int fail,
            int pass,
            int depthFail,
            int compare,
            int compareMask,
            int writeMask,
            int reference) {}

    public record ColorBlend(
            boolean enabled,
            int srcColor,
            int dstColor,
            int colorOp,
            int srcAlpha,
            int dstAlpha,
            int alphaOp,
            int writeMask) {}
}
