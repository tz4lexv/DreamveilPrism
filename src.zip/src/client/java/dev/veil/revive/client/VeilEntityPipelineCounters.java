package dev.veil.revive.client;

import net.minecraft.client.Minecraft;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

public final class VeilEntityPipelineCounters {
    private static final LongAdder VISIBILITY_CHECKS = new LongAdder();
    private static final LongAdder EXACT_DISTANCE_REJECTS = new LongAdder();
    private static final LongAdder SECTION_VISIBILITY_REJECTS = new LongAdder();

    private static final LongAdder EXTRACT_VISIBLE_CALLS = new LongAdder();
    private static final LongAdder EXTRACT_VISIBLE_NS = new LongAdder();
    private static final LongAdder EXTRACT_VISIBLE_ALLOC_BYTES = new LongAdder();

    private static final LongAdder DISPATCH_EXTRACT_CALLS = new LongAdder();
    private static final LongAdder DISPATCH_EXTRACT_NS = new LongAdder();

    private static final LongAdder DISPATCH_SUBMIT_CALLS = new LongAdder();
    private static final LongAdder DISPATCH_SUBMIT_NS = new LongAdder();

    private static final LongAdder SERVER_TICK_SAMPLES = new LongAdder();
    private static final LongAdder SERVER_TICK_AVG_NS_TOTAL = new LongAdder();
    private static final AtomicLong SERVER_TICK_AVG_NS_MAX = new AtomicLong();

    private VeilEntityPipelineCounters() {}

    public static void visibilityCheck() {
        VISIBILITY_CHECKS.increment();
    }

    public static void exactDistanceReject() {
        EXACT_DISTANCE_REJECTS.increment();
    }

    public static void sectionVisibilityReject() {
        SECTION_VISIBILITY_REJECTS.increment();
    }

    public static void extractVisible(long elapsedNs, long allocatedBytes) {
        EXTRACT_VISIBLE_CALLS.increment();
        add(EXTRACT_VISIBLE_NS, elapsedNs);
        add(EXTRACT_VISIBLE_ALLOC_BYTES, allocatedBytes);
    }

    public static void dispatchExtract(long elapsedNs) {
        DISPATCH_EXTRACT_CALLS.increment();
        add(DISPATCH_EXTRACT_NS, elapsedNs);
    }

    public static void dispatchSubmit(long elapsedNs) {
        DISPATCH_SUBMIT_CALLS.increment();
        add(DISPATCH_SUBMIT_NS, elapsedNs);
    }

    public static void sampleIntegratedServer(Minecraft client) {
        var server = client.getSingleplayerServer();
        if (server == null) return;
        long ns = Math.max(0L, server.getAverageTickTimeNanos());
        SERVER_TICK_SAMPLES.increment();
        add(SERVER_TICK_AVG_NS_TOTAL, ns);
        max(SERVER_TICK_AVG_NS_MAX, ns);
    }

    public static void reset() {
        VISIBILITY_CHECKS.reset();
        EXACT_DISTANCE_REJECTS.reset();
        SECTION_VISIBILITY_REJECTS.reset();
        EXTRACT_VISIBLE_CALLS.reset();
        EXTRACT_VISIBLE_NS.reset();
        EXTRACT_VISIBLE_ALLOC_BYTES.reset();
        DISPATCH_EXTRACT_CALLS.reset();
        DISPATCH_EXTRACT_NS.reset();
        DISPATCH_SUBMIT_CALLS.reset();
        DISPATCH_SUBMIT_NS.reset();
        SERVER_TICK_SAMPLES.reset();
        SERVER_TICK_AVG_NS_TOTAL.reset();
        SERVER_TICK_AVG_NS_MAX.set(0L);
    }

    public static Snapshot snapshot() {
        return new Snapshot(
                VISIBILITY_CHECKS.sum(),
                EXACT_DISTANCE_REJECTS.sum(),
                SECTION_VISIBILITY_REJECTS.sum(),
                EXTRACT_VISIBLE_CALLS.sum(),
                EXTRACT_VISIBLE_NS.sum(),
                EXTRACT_VISIBLE_ALLOC_BYTES.sum(),
                DISPATCH_EXTRACT_CALLS.sum(),
                DISPATCH_EXTRACT_NS.sum(),
                DISPATCH_SUBMIT_CALLS.sum(),
                DISPATCH_SUBMIT_NS.sum(),
                SERVER_TICK_SAMPLES.sum(),
                SERVER_TICK_AVG_NS_TOTAL.sum(),
                SERVER_TICK_AVG_NS_MAX.get());
    }

    private static void add(LongAdder adder, long value) {
        if (value > 0L) adder.add(value);
    }

    private static void max(AtomicLong target, long value) {
        long current = target.get();
        while (value > current && !target.compareAndSet(current, value)) current = target.get();
    }

    public record Snapshot(
            long visibilityChecks,
            long exactDistanceRejects,
            long sectionVisibilityRejects,
            long extractVisibleCalls,
            long extractVisibleNs,
            long extractVisibleAllocatedBytes,
            long dispatchExtractCalls,
            long dispatchExtractNs,
            long dispatchSubmitCalls,
            long dispatchSubmitNs,
            long serverTickSamples,
            long serverTickAverageNsTotal,
            long serverTickAverageNsMax) {

        public Snapshot minus(Snapshot before) {
            return new Snapshot(
                    visibilityChecks - before.visibilityChecks,
                    exactDistanceRejects - before.exactDistanceRejects,
                    sectionVisibilityRejects - before.sectionVisibilityRejects,
                    extractVisibleCalls - before.extractVisibleCalls,
                    extractVisibleNs - before.extractVisibleNs,
                    extractVisibleAllocatedBytes - before.extractVisibleAllocatedBytes,
                    dispatchExtractCalls - before.dispatchExtractCalls,
                    dispatchExtractNs - before.dispatchExtractNs,
                    dispatchSubmitCalls - before.dispatchSubmitCalls,
                    dispatchSubmitNs - before.dispatchSubmitNs,
                    serverTickSamples - before.serverTickSamples,
                    serverTickAverageNsTotal - before.serverTickAverageNsTotal,
                    Math.max(serverTickAverageNsMax, before.serverTickAverageNsMax));
        }

        public Snapshot plus(Snapshot other) {
            return new Snapshot(
                    visibilityChecks + other.visibilityChecks,
                    exactDistanceRejects + other.exactDistanceRejects,
                    sectionVisibilityRejects + other.sectionVisibilityRejects,
                    extractVisibleCalls + other.extractVisibleCalls,
                    extractVisibleNs + other.extractVisibleNs,
                    extractVisibleAllocatedBytes + other.extractVisibleAllocatedBytes,
                    dispatchExtractCalls + other.dispatchExtractCalls,
                    dispatchExtractNs + other.dispatchExtractNs,
                    dispatchSubmitCalls + other.dispatchSubmitCalls,
                    dispatchSubmitNs + other.dispatchSubmitNs,
                    serverTickSamples + other.serverTickSamples,
                    serverTickAverageNsTotal + other.serverTickAverageNsTotal,
                    Math.max(serverTickAverageNsMax, other.serverTickAverageNsMax));
        }

        public long rejectedBeforeExtraction() {
            return Math.max(0L, visibilityChecks - dispatchExtractCalls);
        }

        public double entitiesExtractedPerFrame() {
            return extractVisibleCalls == 0L
                    ? 0.0
                    : (double) dispatchExtractCalls / extractVisibleCalls;
        }

        public double visibleLoopMsPerFrame() {
            return extractVisibleCalls == 0L
                    ? 0.0
                    : (extractVisibleNs / 1_000_000.0) / extractVisibleCalls;
        }

        public double dispatcherExtractMsPerFrame() {
            return extractVisibleCalls == 0L
                    ? 0.0
                    : (dispatchExtractNs / 1_000_000.0) / extractVisibleCalls;
        }

        public double dispatcherSubmitMsPerFrame() {
            return extractVisibleCalls == 0L
                    ? 0.0
                    : (dispatchSubmitNs / 1_000_000.0) / extractVisibleCalls;
        }

        public double dispatcherExtractUsPerEntity() {
            return dispatchExtractCalls == 0L
                    ? 0.0
                    : (dispatchExtractNs / 1_000.0) / dispatchExtractCalls;
        }

        public double dispatcherSubmitUsPerEntity() {
            return dispatchSubmitCalls == 0L
                    ? 0.0
                    : (dispatchSubmitNs / 1_000.0) / dispatchSubmitCalls;
        }

        public double allocatedKiBPerFrame() {
            return extractVisibleCalls == 0L
                    ? 0.0
                    : (extractVisibleAllocatedBytes / 1024.0) / extractVisibleCalls;
        }

        public double allocatedBytesPerExtractedEntity() {
            return dispatchExtractCalls == 0L
                    ? 0.0
                    : (double) extractVisibleAllocatedBytes / dispatchExtractCalls;
        }

        public double serverTickAverageMs() {
            return serverTickSamples == 0L
                    ? 0.0
                    : (serverTickAverageNsTotal / 1_000_000.0) / serverTickSamples;
        }

        public double serverTickMaxSampledAverageMs() {
            return serverTickAverageNsMax / 1_000_000.0;
        }
    }
}
