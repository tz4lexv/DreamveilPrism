package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.DeviceType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.vulkan.VulkanGpuSampler;
import com.mojang.blaze3d.vulkan.VulkanGpuTextureView;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.AdaptiveTechniqueGate;
import dev.veil.revive.core.WallClockCadence;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.OptionalDouble;

public final class VeilHzb {

    public static final int STORAGE_USAGE = 1 << 20;

    private static RenderPipeline depthOnly;
    private static VeilHzbCompute compute;
    private static VeilHzbPyramidCompute pyramidCompute;
    private static GpuBuffer pyramidBuffer;
    private static boolean ready, logged;
    private static int width, height, pyramidWidth, pyramidHeight, mipCount;
    private static final int[] MIP_OFFSETS = new int[VeilHzbPyramidCompute.MAX_MIPS];
    private static long pyramidWords;

    private static final int FLAG_STATS = 1;
    private static final int FLAG_FRUSTUM = 2;
    private static final int VISIBILITY_ONLY_MODE = 2;
    private static final int COUNTER_STRIDE_BYTES = 16;

    private static long frames,
            worldFrames,
            queries,
            regionQueries,
            gpuDispatches,
            gpuDispatchGroups,
            hzbBuildDispatches,
            cpuDirectSmallBatches,
            sampledHidden,
            sampledDraws,
            visibilitySampledDraws,
            sampledFinalVisible,
            frustumRegionQueries,
            frustumSectionQueries,
            frustumOnlyFrames,
            frustumOnlyDispatches,
            visibilityDirectFrames,
            sampledFrustumRegionRejected,
            sampledFrustumSectionRejected,
            sampledHzbRejected;
    private static double rejectionEma;
    private static double lastRejection;

    private static final long FRUSTUM_PROBE_INTERVAL_FRAMES = 60L;
    private static final long FRUSTUM_PROBE_MIN_NS = 1_000_000_000L;
    private static final long FRUSTUM_PROBE_PHASE_FRAMES = 15L;
    private static final int FRUSTUM_MIN_SAMPLED_DRAWS = 1024;
    private static final double FRUSTUM_SCALABLE_TERRAIN_FRACTION = 0.35;
    private static final double FRUSTUM_MIN_REJECTION_INTEGRATED = 0.20;
    private static final double FRUSTUM_MIN_REJECTION_DISCRETE = 0.08;
    private static final double FRUSTUM_DISABLE_RATIO = 0.90;
    private static final double FRUSTUM_ENABLE_RATIO = 1.15;
    private static final int FRUSTUM_DISABLE_STREAK = 3;
    private static final int FRUSTUM_ENABLE_STREAK = 2;
    private static final AdaptiveTechniqueGate FRUSTUM_GATE =
            new AdaptiveTechniqueGate(
                    new AdaptiveTechniqueGate.Config(
                            FRUSTUM_DISABLE_RATIO, FRUSTUM_ENABLE_RATIO,
                            FRUSTUM_DISABLE_STREAK, FRUSTUM_ENABLE_STREAK,
                            FRUSTUM_PROBE_INTERVAL_FRAMES, FRUSTUM_PROBE_PHASE_FRAMES));
    private static boolean frustumProbeThisFrame;
    private static long frustumSampledDraws, frustumBelowFloorFastSuppresses;
    private static double frustumLastRejection,
            frustumRejectionEma,
            frustumEstimatedSavedMs,
            frustumMeasuredCostMs,
            frustumBenefitRatio;
    private static boolean frustumLogged;

    private static final long AUTO_PROBE_INTERVAL_FRAMES = 30L;
    private static final long AUTO_PROBE_MIN_NS = 500_000_000L;
    private static final long STATS_SAMPLE_INTERVAL_NS = 1_000_000_000L;
    private static final long AUTOTUNE_TIMING_INTERVAL_NS = 125_000_000L;
    private static final WallClockCadence STATS_SAMPLE_CADENCE = new WallClockCadence();
    private static final WallClockCadence AUTO_NO_TARGET_PROBE_CADENCE = new WallClockCadence();
    private static final WallClockCadence AUTOTUNE_TIMING_CADENCE = new WallClockCadence();
    private static final int AUTO_MIN_SAMPLED_DRAWS = 512;
    private static final double AUTO_SCALABLE_TERRAIN_FRACTION = 0.70;
    private static final double AUTO_DISABLE_RATIO = 0.90;
    private static final double AUTO_ENABLE_RATIO = 1.10;
    private static final int AUTO_DISABLE_STREAK = 3;
    private static final int AUTO_ENABLE_STREAK = 2;
    private static final AdaptiveTechniqueGate HZB_GATE =
            new AdaptiveTechniqueGate(
                    new AdaptiveTechniqueGate.Config(
                            AUTO_DISABLE_RATIO, AUTO_ENABLE_RATIO,
                            AUTO_DISABLE_STREAK, AUTO_ENABLE_STREAK,
                            AUTO_PROBE_INTERVAL_FRAMES, 0L));
    private static boolean autoProbeThisFrame;
    private static long autoDecisionFrame = Long.MIN_VALUE;
    private static boolean autoDecisionValid, autoDecisionBuildHzb, autoDecisionFrustumActive;
    private static long autoZeroRejectionFastSuppresses,
            autoNoTargetDiscoveries,
            autoNoTargetFastSkips,
            autoNoTargetProbeFrames;
    private static long autoSampleGeneration, autoObservedSampleGeneration;
    private static boolean autoNoTargetSuppressed;
    private static double autoEstimatedSavedMs, autoMeasuredCostMs, autoBenefitRatio;
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static int readbackCount, readbackExpected;
    private static boolean readbackHzbActive, readbackFrustumActive;
    private static long readbackResizes;
    private static final ArrayList<VeilIndirectTerrain.PreparedBatch> DISPATCH_SCRATCH =
            new ArrayList<>();

    private VeilHzb() {}

    public static void initializePipelines() {
        if (depthOnly != null) return;
        depthOnly =
                RenderPipelines.register(
                        RenderPipeline.builder(RenderPipelines.GENERIC_BLOCKS_SNIPPET)
                                .withLocation(id("pipeline/hzb_occluders"))
                                .withVertexShader(id("core/terrain_indirect"))
                                .withFragmentShader(id("core/depth_only"))
                                .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                                .withBindGroupLayout(
                                        BindGroupLayout.builder()
                                                .withUniform(
                                                        "VeilFrame",
                                                        com.mojang.blaze3d.shaders.UniformType
                                                                .UNIFORM_BUFFER)
                                                .withUniform(
                                                        "VeilSections",
                                                        com.mojang.blaze3d.shaders.UniformType
                                                                .TEXEL_BUFFER,
                                                        GpuFormat.RGBA32_SINT)
                                                .build())
                                .withColorTargetState(
                                        new ColorTargetState(
                                                Optional.empty(),
                                                GpuFormat.RGBA8_UNORM,
                                                ColorTargetState.WRITE_NONE))
                                .build());
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }

    public static void beginFrame() {
        VeilSlangHzbProbe.poll();
        VeilSlangCullProbe.poll();
        ready = false;
        worldFrames++;
        autoDecisionValid = false;
        autoDecisionFrame = Long.MIN_VALUE;
        if (fence != null && fence.awaitCompletion(0)) {
            long bytes = (long) readbackCount * COUNTER_STRIDE_BYTES;
            try (var view = readback.slice(0, bytes).map(true, false)) {
                long visible = 0;
                long frustumRegionHidden = 0;
                long frustumSectionHidden = 0;
                long hzbHidden = 0;
                for (int i = 0; i < readbackCount; i++) {
                    int base = i * COUNTER_STRIDE_BYTES;
                    visible += Integer.toUnsignedLong(view.data().getInt(base));
                    frustumRegionHidden += Integer.toUnsignedLong(view.data().getInt(base + 4));
                    frustumSectionHidden += Integer.toUnsignedLong(view.data().getInt(base + 8));
                    hzbHidden += Integer.toUnsignedLong(view.data().getInt(base + 12));
                }

                visibilitySampledDraws += readbackExpected;
                sampledFinalVisible += visible;

                if (readbackHzbActive) {
                    sampledDraws += readbackExpected;
                    sampledHidden += hzbHidden;
                    sampledHzbRejected += hzbHidden;
                    lastRejection =
                            readbackExpected == 0
                                    ? 0.0
                                    : (double) hzbHidden / (double) readbackExpected;
                    rejectionEma =
                            rejectionEma == 0.0
                                    ? lastRejection
                                    : rejectionEma * 0.80 + lastRejection * 0.20;
                    autoSampleGeneration++;
                }

                long frustumHidden = frustumRegionHidden + frustumSectionHidden;
                if (readbackFrustumActive && readbackExpected > 0) {
                    sampledFrustumRegionRejected += frustumRegionHidden;
                    sampledFrustumSectionRejected += frustumSectionHidden;
                    frustumSampledDraws += readbackExpected;
                    frustumLastRejection = (double) frustumHidden / (double) readbackExpected;
                    frustumRejectionEma =
                            frustumRejectionEma == 0.0
                                    ? frustumLastRejection
                                    : frustumRejectionEma * 0.80 + frustumLastRejection * 0.20;

                    if (!readbackHzbActive) updateFrustumAutotune(frustumLastRejection);
                }

                if (readbackHzbActive && !logged && hzbHidden > 0) {
                    logged = true;
                    ReviveMod.LOGGER.info(
                            "Veil HZB + indirect compaction ACTIVE: {} of {} sampled commands removed by HZB",
                            hzbHidden,
                            readbackExpected);
                }
                if (readbackFrustumActive && !frustumLogged && frustumHidden > 0) {
                    frustumLogged = true;
                    ReviveMod.LOGGER.info(
                            "Veil hierarchical frustum ACTIVE: {} of {} sampled commands rejected before HZB",
                            frustumHidden,
                            readbackExpected);
                }
            }
            fence.close();
            fence = null;
        }
    }

    public static boolean autoNeedsCustomOpaquePath() {
        if (VeilSubmissionControl.effectiveMode() != VeilSubmissionControl.Mode.AUTO) return true;
        if (autoDecisionValid && autoDecisionFrame == worldFrames) {
            return autoDecisionBuildHzb || autoDecisionFrustumActive;
        }
        if (!VeilVideoConfig.on("renderer.compaction")) {
            visibilityDirectFrames++;
            autoDecisionFrame = worldFrames;
            autoDecisionValid = true;
            autoDecisionBuildHzb = false;
            autoDecisionFrustumActive = false;
            return false;
        }

        if (autoNoTargetSuppressed) {
            boolean probe = AUTO_NO_TARGET_PROBE_CADENCE.due(System.nanoTime(), AUTO_PROBE_MIN_NS);
            if (!probe) {
                visibilityDirectFrames++;
                autoNoTargetFastSkips++;
                autoDecisionFrame = worldFrames;
                autoDecisionValid = true;
                autoDecisionBuildHzb = false;
                autoDecisionFrustumActive = false;
                return false;
            }
            autoNoTargetProbeFrames++;
        }

        boolean hzbEnabled = VeilVideoConfig.on("renderer.hzb");
        boolean hierarchicalRequested =
                VeilVideoConfig.on("renderer.hierarchical")
                        && ReviveRuntime.config().hierarchicalFrustumCulling();
        if (!hzbEnabled && !hierarchicalRequested) {
            visibilityDirectFrames++;
            autoDecisionFrame = worldFrames;
            autoDecisionValid = true;
            autoDecisionBuildHzb = false;
            autoDecisionFrustumActive = false;
            return false;
        }

        boolean buildHzb = hzbEnabled && shouldBuildHzb();
        boolean frustumActive = hierarchicalRequested && (buildHzb || shouldUseFrustumHierarchy());

        autoDecisionFrame = worldFrames;
        autoDecisionValid = true;
        autoDecisionBuildHzb = buildHzb;
        autoDecisionFrustumActive = frustumActive;
        if (!buildHzb && !frustumActive) visibilityDirectFrames++;
        return buildHzb || frustumActive;
    }

    static boolean autotuneTimingNeededNextFrame() {
        long next = worldFrames + 1L;
        if (!VeilVideoConfig.on("renderer.hzbAutotune")) return false;
        long nowNanos = System.nanoTime();
        if (autoNoTargetSuppressed) return AUTO_NO_TARGET_PROBE_CADENCE.ready(nowNanos);
        if (!HZB_GATE.suppressed() || !FRUSTUM_GATE.suppressed()) {
            return AUTOTUNE_TIMING_CADENCE.due(nowNanos, AUTOTUNE_TIMING_INTERVAL_NS);
        }
        return HZB_GATE.wouldProbe(next, nowNanos, AUTO_PROBE_MIN_NS)
                || FRUSTUM_GATE.wouldProbe(next, nowNanos, FRUSTUM_PROBE_MIN_NS);
    }

    public static void process(
            ChunkSectionLayerGroup group,
            List<VeilIndirectTerrain.LayerBatches> layers,
            GpuSampler atlasSampler) {
        boolean opaqueGroup = group == ChunkSectionLayerGroup.OPAQUE;
        var device = RenderSystem.getDevice();
        VeilSubmissionControl.Mode submissionMode = VeilSubmissionControl.effectiveMode();

        if (opaqueGroup && residentVisibilityCompactionEnabled()) {
            VeilResidentVisibilityProbe.poll();
            DISPATCH_SCRATCH.clear();
            for (var layer : layers) {
                for (var prepared : layer.batches()) {
                    prepared.compacted = false;
                    var batch = prepared.batch();
                    boolean inactive = false;
                    for (int i = 0; i < batch.sectionIndices.length && !inactive; i++)
                        inactive = batch.directCommands.get(i * 3 + 1) == 0;
                    if (inactive) DISPATCH_SCRATCH.add(prepared);
                }
            }
            if (!DISPATCH_SCRATCH.isEmpty()) {
                var target = group.outputTarget();
                ensure(
                        target.getColorTextureView().getWidth(0),
                        target.getColorTextureView().getHeight(0));
                dispatchAll(DISPATCH_SCRATCH, VISIBILITY_ONLY_MODE, 0);
                for (var prepared : DISPATCH_SCRATCH)
                    VeilResidentVisibilityProbe.capture(prepared.batch(), compute);
            }
            return;
        }

        if (submissionMode == VeilSubmissionControl.Mode.DIRECT_DRAWS
                || submissionMode == VeilSubmissionControl.Mode.DIRECT_MDI
                || submissionMode == VeilSubmissionControl.Mode.DIRECT_MULTIDRAW) {
            for (var layer : layers) for (var batch : layer.batches()) batch.compacted = false;
            if (opaqueGroup) visibilityDirectFrames++;
            return;
        }

        boolean forceFrustum = submissionMode == VeilSubmissionControl.Mode.FRUSTUM_MDI;
        boolean compact = forceFrustum || VeilVideoConfig.on("renderer.compaction");
        boolean hzbEnabled =
                submissionMode == VeilSubmissionControl.Mode.AUTO
                        && VeilVideoConfig.on("renderer.hzb");
        boolean hierarchicalRequested =
                forceFrustum
                        || (submissionMode == VeilSubmissionControl.Mode.AUTO
                                && VeilVideoConfig.on("renderer.hierarchical")
                                && ReviveRuntime.config().hierarchicalFrustumCulling());
        if (!compact || (!hzbEnabled && !hierarchicalRequested)) return;

        var target = group.outputTarget();

        boolean buildHzb;
        boolean frustumActive;
        if (opaqueGroup
                && submissionMode == VeilSubmissionControl.Mode.AUTO
                && autoDecisionValid
                && autoDecisionFrame == worldFrames) {
            buildHzb = hzbEnabled && autoDecisionBuildHzb;
            frustumActive = hierarchicalRequested && autoDecisionFrustumActive;
        } else {
            buildHzb = opaqueGroup && hzbEnabled && shouldBuildHzb();

            frustumActive =
                    opaqueGroup
                            && hierarchicalRequested
                            && (forceFrustum || buildHzb || shouldUseFrustumHierarchy());
        }

        if (opaqueGroup
                && submissionMode == VeilSubmissionControl.Mode.AUTO
                && (buildHzb || frustumActive)) {
            boolean hasOccluder = false;
            boolean hasHzbTarget = false;
            boolean hasFrustumTarget = false;
            for (var layer : layers) {
                if (layer.layer() == ChunkSectionLayer.TRANSLUCENT) continue;
                for (var prepared : layer.batches()) {
                    var batch = prepared.batch();
                    if (!batch.lod() && worthwhileOccluder(batch)) hasOccluder = true;
                    if (buildHzb && worthwhile(batch)) hasHzbTarget = true;
                    if (frustumActive && worthwhileFrustum(batch)) hasFrustumTarget = true;
                }
            }

            boolean hzbViable = buildHzb && hasOccluder && hasHzbTarget;
            boolean frustumViable = frustumActive && hasFrustumTarget;
            buildHzb = hzbViable;
            frustumActive = frustumViable;
            autoDecisionBuildHzb = buildHzb;
            autoDecisionFrustumActive = frustumActive;

            if (!buildHzb && !frustumActive) {
                if (!autoNoTargetSuppressed) {
                    autoNoTargetDiscoveries++;
                    AUTO_NO_TARGET_PROBE_CADENCE.scheduleFrom(System.nanoTime(), AUTO_PROBE_MIN_NS);
                }
                autoNoTargetSuppressed = true;
                for (var layer : layers)
                    for (var prepared : layer.batches()) prepared.compacted = false;
                visibilityDirectFrames++;
                return;
            }
            autoNoTargetSuppressed = false;
            AUTO_NO_TARGET_PROBE_CADENCE.reset();
        }

        ensure(target.getColorTextureView().getWidth(0), target.getColorTextureView().getHeight(0));
        boolean hzbProfileActive = false;

        if (buildHzb) {
            DISPATCH_SCRATCH.clear();
            for (var layer : layers)
                if (layer.layer() == ChunkSectionLayer.SOLID) {
                    for (var batch : layer.batches()) {
                        if (!batch.batch().lod() && worthwhileOccluder(batch.batch()))
                            DISPATCH_SCRATCH.add(batch);
                    }
                }

            if (!DISPATCH_SCRATCH.isEmpty()) {
                VeilGpuProfiler.begin(VeilGpuProfiler.Pass.HZB);
                hzbProfileActive = true;
                dispatchAll(DISPATCH_SCRATCH, 0, 0);

                var hzbEncoder = device.createCommandEncoder();
                try (RenderPass pass =
                        hzbEncoder.createRenderPass(
                                () -> "Veil current-frame occluder depth",
                                target.getColorTextureView(),
                                Optional.empty(),
                                target.getDepthTextureView(),
                                OptionalDouble.empty())) {
                    RenderSystem.bindDefaultUniforms(pass);
                    pass.bindTexture("Sampler0", VeilIndirectTerrain.texture(), atlasSampler);
                    pass.bindTexture(
                            "Sampler2",
                            Minecraft.getInstance().gameRenderer.lightmap(),
                            RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
                    pass.setPipeline(depthOnly);
                    pass.setUniform("VeilSections", VeilSectionTable.buffer());
                    pass.setUniform("VeilFrame", DISPATCH_SCRATCH.getFirst().uniform());
                    for (var batch : DISPATCH_SCRATCH) {
                        pass.setPipeline(
                                VeilRegularTerrainPipelines.depth(
                                        batch.batch().vertices, depthOnly));
                        VeilIndirectTerrain.drawDepthBatch(pass, batch);
                    }
                }

                VulkanGpuSampler depthSampler =
                        (VulkanGpuSampler)
                                RenderSystem.getSamplerCache().getClampToEdge(FilterMode.NEAREST);
                VeilGpuProfiler.begin(VeilGpuProfiler.Pass.HZB_BUILD);
                hzbBuildDispatches +=
                        pyramidCompute.build(
                                (VulkanGpuTextureView) target.getDepthTextureView(),
                                depthSampler,
                                pyramidBuffer.slice(),
                                width,
                                height,
                                pyramidWidth,
                                pyramidHeight,
                                mipCount,
                                MIP_OFFSETS);
                VeilGpuProfiler.end(VeilGpuProfiler.Pass.HZB_BUILD);
                ready = true;
                frames++;
            }
        }

        boolean sampleThisFrame =
                opaqueGroup
                        && fence == null
                        && (autoProbeThisFrame
                                || frustumProbeThisFrame
                                || STATS_SAMPLE_CADENCE.due(
                                        System.nanoTime(), STATS_SAMPLE_INTERVAL_NS));
        int flags = (sampleThisFrame ? FLAG_STATS : 0) | (frustumActive ? FLAG_FRUSTUM : 0);

        DISPATCH_SCRATCH.clear();
        int finalMode =
                forceFrustum
                        ? 4
                        : (ready
                                ? (VeilVideoConfig.on("renderer.hierarchical") ? 1 : 3)
                                : (frustumActive ? 4 : -1));
        if (opaqueGroup && finalMode < 0) visibilityDirectFrames++;
        for (var layer : layers)
            for (var batch : layer.batches()) {
                boolean opaqueLayer = layer.layer() != ChunkSectionLayer.TRANSLUCENT;
                boolean canCull = opaqueLayer && finalMode >= 0;
                boolean worthwhileCull =
                        canCull
                                && (ready
                                        ? worthwhile(batch.batch())
                                        : worthwhileFrustum(batch.batch()));
                if (!canCull || !worthwhileCull) {
                    batch.compacted = false;
                    if (canCull && !worthwhileCull) cpuDirectSmallBatches++;
                } else {
                    DISPATCH_SCRATCH.add(batch);
                }
            }
        VeilGpuProfiler.Pass cullPass =
                finalMode == 4
                        ? VeilGpuProfiler.Pass.FRUSTUM_CULL
                        : (ready && finalMode >= 0 ? VeilGpuProfiler.Pass.HZB_CULL : null);
        if (cullPass != null && !DISPATCH_SCRATCH.isEmpty()) VeilGpuProfiler.begin(cullPass);
        dispatchAll(DISPATCH_SCRATCH, finalMode, flags);
        if (cullPass != null && !DISPATCH_SCRATCH.isEmpty()) VeilGpuProfiler.end(cullPass);
        if (finalMode == 4 && !DISPATCH_SCRATCH.isEmpty()) {
            frustumOnlyFrames++;
            frustumOnlyDispatches += DISPATCH_SCRATCH.size();
        }

        if (sampleThisFrame) sample(layers, ready, frustumActive);
        if (hzbProfileActive) VeilGpuProfiler.end(VeilGpuProfiler.Pass.HZB);
    }

    static boolean residentVisibilityCompactionEnabled() {
        return Boolean.getBoolean("veil.residentTerrainCommands")
                && !"false"
                        .equalsIgnoreCase(System.getProperty("veil.residentVisibilityCompaction"));
    }

    private static void dispatchAll(
            List<VeilIndirectTerrain.PreparedBatch> batches, int mode, int flags) {
        if (batches.isEmpty() || mode < 0) return;
        compute.dispatchBatches(
                batches,
                VeilSectionTable.slice(),
                pyramidBuffer.slice(),
                mode,
                flags,
                pyramidWidth,
                pyramidHeight,
                mipCount,
                MIP_OFFSETS);
        gpuDispatchGroups++;
        gpuDispatches += batches.size();
        boolean frustum = (flags & FLAG_FRUSTUM) != 0;
        for (var prepared : batches) {
            var batch = prepared.batch();
            prepared.compacted = true;
            if (mode == 1 || mode == 3) {
                queries += batch.sectionIndices().length;
                if (mode == 1) regionQueries += batch.regionCount;
            }
            if (frustum && (mode == 1 || mode == 3 || mode == 4)) {
                frustumSectionQueries += batch.sectionIndices().length;
                if (mode == 1 || mode == 4) frustumRegionQueries += batch.regionCount;
            }
        }
    }

    private static boolean worthwhileFrustum(VeilIndirectTerrain.Batch batch) {
        boolean integrated =
                RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED;
        return batch.sectionIndices().length >= (integrated ? 64 : 32);
    }

    private static boolean shouldUseFrustumHierarchy() {
        frustumProbeThisFrame = false;
        if (!VeilVideoConfig.on("renderer.hzbAutotune")) {
            FRUSTUM_GATE.forceEnabled();
            return true;
        }

        if (frustumSampledDraws < FRUSTUM_MIN_SAMPLED_DRAWS) return true;

        boolean integrated =
                RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED;
        double minimumRejection =
                integrated ? FRUSTUM_MIN_REJECTION_INTEGRATED : FRUSTUM_MIN_REJECTION_DISCRETE;
        if (!FRUSTUM_GATE.suppressed() && frustumRejectionEma < minimumRejection) {

            if (FRUSTUM_GATE.suppressImmediately() == AdaptiveTechniqueGate.Transition.DISABLED) {
                frustumBelowFloorFastSuppresses++;
            }
        }
        if (!FRUSTUM_GATE.suppressed()) {
            updateFrustumProfitabilityModel();
            return true;
        }

        AdaptiveTechniqueGate.RunDecision decision =
                FRUSTUM_GATE.runDecision(worldFrames, System.nanoTime(), FRUSTUM_PROBE_MIN_NS);
        frustumProbeThisFrame = decision.probe();
        return decision.execute();
    }

    private static void updateFrustumProfitabilityModel() {
        double costMs = VeilGpuProfiler.emaMs(VeilGpuProfiler.Pass.FRUSTUM_CULL);
        double terrainMs = VeilGpuProfiler.emaMs(VeilGpuProfiler.Pass.TERRAIN_OPAQUE);
        if (frustumRejectionEma <= 0.0 || costMs <= 0.0 || terrainMs <= 0.0) return;

        double rejection = Math.clamp(frustumRejectionEma, 0.0, 0.90);
        boolean integrated =
                RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED;
        double minimumRejection =
                integrated ? FRUSTUM_MIN_REJECTION_INTEGRATED : FRUSTUM_MIN_REJECTION_DISCRETE;
        frustumMeasuredCostMs = costMs;
        if (rejection < minimumRejection) {

            frustumEstimatedSavedMs = 0.0;
            frustumBenefitRatio = 0.0;
            return;
        }

        double directTerrainMs =
                FRUSTUM_GATE.suppressed() ? terrainMs : terrainMs / Math.max(0.25, 1.0 - rejection);
        frustumEstimatedSavedMs = directTerrainMs * rejection * FRUSTUM_SCALABLE_TERRAIN_FRACTION;
        frustumBenefitRatio = frustumEstimatedSavedMs / Math.max(0.01, frustumMeasuredCostMs);
    }

    private static void updateFrustumAutotune(double rejection) {
        if (!VeilVideoConfig.on("renderer.hierarchical")
                || !ReviveRuntime.config().hierarchicalFrustumCulling()) {
            FRUSTUM_GATE.forceEnabled();
            return;
        }
        if (frustumSampledDraws < FRUSTUM_MIN_SAMPLED_DRAWS) return;

        updateFrustumProfitabilityModel();
        if (frustumMeasuredCostMs <= 0.0) return;
        FRUSTUM_GATE.observe(frustumBenefitRatio);
    }

    private static boolean worthwhileOccluder(VeilIndirectTerrain.Batch batch) {
        boolean integrated =
                RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED;
        return batch.sectionIndices().length >= (integrated ? 8 : 4);
    }

    private static boolean worthwhile(VeilIndirectTerrain.Batch batch) {
        boolean integrated =
                RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED;
        int minimum;
        double hzbMs = VeilGpuProfiler.emaMs(VeilGpuProfiler.Pass.HZB);
        if (rejectionEma > 0.55) minimum = integrated ? 8 : 4;
        else if (rejectionEma > 0.25) minimum = integrated ? 16 : 8;
        else if (rejectionEma > 0.10) minimum = integrated ? 32 : 16;
        else if (hzbMs > 0.20) minimum = integrated ? 128 : 64;
        else minimum = integrated ? 48 : 24;
        return batch.sectionIndices().length >= minimum;
    }

    private static boolean shouldBuildHzb() {
        autoProbeThisFrame = false;
        if (!VeilVideoConfig.on("renderer.hzbAutotune")) {
            HZB_GATE.forceEnabled();
            return true;
        }

        double hzbMs = VeilGpuProfiler.emaMs(VeilGpuProfiler.Pass.HZB);
        double terrainMs = VeilGpuProfiler.emaMs(VeilGpuProfiler.Pass.TERRAIN_OPAQUE);
        if (sampledDraws < AUTO_MIN_SAMPLED_DRAWS) return true;

        boolean freshSample = autoObservedSampleGeneration != autoSampleGeneration;

        if (rejectionEma <= 0.0) {
            autoEstimatedSavedMs = 0.0;
            autoMeasuredCostMs = Math.max(0.0, hzbMs);
            autoBenefitRatio = 0.0;
            if (freshSample) {
                autoObservedSampleGeneration = autoSampleGeneration;
                if (HZB_GATE.suppressImmediately() == AdaptiveTechniqueGate.Transition.DISABLED) {
                    autoZeroRejectionFastSuppresses++;
                }
            }
            AdaptiveTechniqueGate.RunDecision decision =
                    HZB_GATE.runDecision(worldFrames, System.nanoTime(), AUTO_PROBE_MIN_NS);
            autoProbeThisFrame = decision.probe();
            return decision.execute();
        }

        if (hzbMs <= 0.0 || terrainMs <= 0.0) {
            if (!HZB_GATE.suppressed()) return true;
            AdaptiveTechniqueGate.RunDecision decision =
                    HZB_GATE.runDecision(worldFrames, System.nanoTime(), AUTO_PROBE_MIN_NS);
            autoProbeThisFrame = decision.probe();
            return decision.execute();
        }

        double rejection = Math.clamp(rejectionEma, 0.0, 0.90);

        double uncullledTerrainMs =
                HZB_GATE.suppressed() ? terrainMs : terrainMs / Math.max(0.25, 1.0 - rejection);
        autoEstimatedSavedMs = uncullledTerrainMs * rejection * AUTO_SCALABLE_TERRAIN_FRACTION;
        autoMeasuredCostMs = hzbMs;
        autoBenefitRatio = autoEstimatedSavedMs / Math.max(0.01, autoMeasuredCostMs);

        if (freshSample) {
            autoObservedSampleGeneration = autoSampleGeneration;
            AdaptiveTechniqueGate.Transition transition = HZB_GATE.observe(autoBenefitRatio);
            if (transition == AdaptiveTechniqueGate.Transition.DISABLED) return false;
            if (transition == AdaptiveTechniqueGate.Transition.ENABLED) return true;
        }

        AdaptiveTechniqueGate.RunDecision decision =
                HZB_GATE.runDecision(worldFrames, System.nanoTime(), AUTO_PROBE_MIN_NS);
        autoProbeThisFrame = decision.probe();
        return decision.execute();
    }

    private static void ensure(int w, int h) {
        var device = RenderSystem.getDevice();
        initializePipelines();
        if (compute == null) {
            if (!device.precompilePipeline(depthOnly).isValid()) {
                throw new IllegalStateException("HZB occluder graphics shader compilation failed");
            }
            VeilVulkanRuntime vkRuntime = VeilVulkanRuntime.requireCurrent();
            compute = new VeilHzbCompute(vkRuntime);
            pyramidCompute = new VeilHzbPyramidCompute(vkRuntime);
            ReviveMod.LOGGER.info(
                    "Veil V50 native Vulkan runtime ACTIVE: Minecraft VkDevice + reflected SPIR-V compute pipelines");
        }
        if (pyramidBuffer != null && w == width && h == height) return;

        releasePyramid();
        width = w;
        height = h;
        pyramidWidth = Math.max(1, (w + 1) / 2);
        pyramidHeight = Math.max(1, (h + 1) / 2);

        mipCount = 1;
        int mw = pyramidWidth;
        int mh = pyramidHeight;
        while (mw > 1 || mh > 1) {
            mw = Math.max(1, (mw + 1) / 2);
            mh = Math.max(1, (mh + 1) / 2);
            mipCount++;
        }
        if (mipCount > VeilHzbPyramidCompute.MAX_MIPS) {
            throw new IllegalStateException(
                    "HZB requires " + mipCount + " mips; max=" + VeilHzbPyramidCompute.MAX_MIPS);
        }

        long words = 0;
        mw = pyramidWidth;
        mh = pyramidHeight;
        for (int i = 0; i < mipCount; i++) {
            if (words > Integer.MAX_VALUE)
                throw new IllegalStateException("HZB buffer offset overflow");
            MIP_OFFSETS[i] = (int) words;
            words += (long) mw * mh;
            mw = Math.max(1, (mw + 1) / 2);
            mh = Math.max(1, (mh + 1) / 2);
        }
        for (int i = mipCount; i < MIP_OFFSETS.length; i++) MIP_OFFSETS[i] = 0;
        pyramidWords = words;
        pyramidBuffer =
                device.createBuffer(
                        () -> "Veil compute HZB",
                        STORAGE_USAGE
                                | (VeilSlangHzbProbe.enabled() ? GpuBuffer.USAGE_COPY_SRC : 0),
                        words * Integer.BYTES);
    }

    private static void sample(
            List<VeilIndirectTerrain.LayerBatches> layers,
            boolean hzbActive,
            boolean frustumActive) {
        int count = 0, expected = 0;
        for (var layer : layers)
            for (var batch : layer.batches())
                if (batch.compacted) {
                    count++;
                    expected += batch.batch().sectionIndices().length;
                }
        if (count == 0) return;

        long requiredBytes = (long) count * COUNTER_STRIDE_BYTES;
        if (readback == null || readback.size() < requiredBytes) {
            if (readback != null) readback.close();
            long capacity =
                    Math.max(256L, Long.highestOneBit(Math.max(1L, requiredBytes - 1L)) << 1);
            if (capacity < requiredBytes) capacity = requiredBytes;
            readback =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil visibility-counter persistent readback",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    capacity);
            readbackResizes++;
        }
        var encoder = RenderSystem.getDevice().createCommandEncoder();
        compute.prepareCountReadback();
        int offset = 0;
        for (var layer : layers)
            for (var batch : layer.batches())
                if (batch.compacted) {
                    var src = batch.batch().counter();
                    encoder.copyToBuffer(src, readback.slice(offset, COUNTER_STRIDE_BYTES));
                    offset += COUNTER_STRIDE_BYTES;
                }
        readbackCount = count;
        readbackExpected = expected;
        readbackHzbActive = hzbActive;
        readbackFrustumActive = frustumActive;
        fence = encoder.createFence();
    }

    private static void releasePyramid() {
        if (pyramidBuffer != null) {
            pyramidBuffer.close();
            pyramidBuffer = null;
        }
        pyramidWidth = pyramidHeight = mipCount = 0;
        pyramidWords = 0;
    }

    public static void close() {
        releasePyramid();
        ready = false;
        DISPATCH_SCRATCH.clear();
        if (pyramidCompute != null) {
            pyramidCompute.close();
            pyramidCompute = null;
        }
        if (compute != null) {
            compute.close();
            compute = null;
        }
        if (fence != null) {
            fence.close();
            fence = null;
        }
        if (readback != null) {
            readback.close();
            readback = null;
        }
        autoDecisionValid = false;
        autoDecisionFrame = Long.MIN_VALUE;
        autoDecisionBuildHzb = false;
        autoDecisionFrustumActive = false;
        autoNoTargetSuppressed = false;
        autoSampleGeneration = 0L;
        autoObservedSampleGeneration = 0L;
        HZB_GATE.reset();
        FRUSTUM_GATE.reset();
        STATS_SAMPLE_CADENCE.reset();
        AUTO_NO_TARGET_PROBE_CADENCE.reset();
        AUTOTUNE_TIMING_CADENCE.reset();
    }

    public static String telemetry() {
        AdaptiveTechniqueGate.Snapshot frustumGate = FRUSTUM_GATE.snapshot();
        AdaptiveTechniqueGate.Snapshot hzbGate = HZB_GATE.snapshot();
        return "hzb_frames_total="
                + frames
                + "\nhzb_region_queries_total="
                + regionQueries
                + "\nhzb_section_queries_total="
                + queries
                + "\nfrustum_region_queries_total="
                + frustumRegionQueries
                + "\nfrustum_section_queries_total="
                + frustumSectionQueries
                + "\nfrustum_only_frames_total="
                + frustumOnlyFrames
                + "\nfrustum_only_dispatches_total="
                + frustumOnlyDispatches
                + "\nvisibility_direct_frames_total="
                + visibilityDirectFrames
                + "\nhzb_build_dispatches_total="
                + hzbBuildDispatches
                + "\ngpu_cull_dispatches_total="
                + gpuDispatches
                + "\ngpu_cull_encoder_groups_total="
                + gpuDispatchGroups
                + "\ngpu_direct_small_batches_total="
                + cpuDirectSmallBatches
                + "\nvisibility_sampled_draws="
                + visibilitySampledDraws
                + "\nhzb_sampled_draws="
                + sampledDraws
                + "\nhzb_sampled_hidden="
                + sampledHidden
                + "\nhzb_sampled_visible="
                + Math.max(0, sampledDraws - sampledHidden)
                + "\nvisibility_sampled_final_visible="
                + sampledFinalVisible
                + "\nfrustum_sampled_region_rejected="
                + sampledFrustumRegionRejected
                + "\nfrustum_sampled_section_rejected="
                + sampledFrustumSectionRejected
                + "\nhzb_sampled_cause_rejected="
                + sampledHzbRejected
                + "\nfrustum_last_rejection="
                + String.format(Locale.ROOT, "%.4f", frustumLastRejection)
                + "\nfrustum_rejection_ema="
                + String.format(Locale.ROOT, "%.4f", frustumRejectionEma)
                + "\nfrustum_autotune_suppressed="
                + frustumGate.suppressed()
                + "\nfrustum_autotune_skipped_frames="
                + frustumGate.skippedFrames()
                + "\nfrustum_autotune_probe_frames="
                + frustumGate.probeFrames()
                + "\nfrustum_autotune_disable_events="
                + frustumGate.disableEvents()
                + "\nfrustum_autotune_enable_events="
                + frustumGate.enableEvents()
                + "\nfrustum_autotune_below_floor_fast_suppresses="
                + frustumBelowFloorFastSuppresses
                + "\nfrustum_autotune_estimated_saved_ms="
                + String.format(Locale.ROOT, "%.4f", frustumEstimatedSavedMs)
                + "\nfrustum_autotune_measured_cost_ms="
                + String.format(Locale.ROOT, "%.4f", frustumMeasuredCostMs)
                + "\nfrustum_autotune_benefit_ratio="
                + String.format(Locale.ROOT, "%.4f", frustumBenefitRatio)
                + "\nfrustum_autotune_min_rejection="
                + String.format(
                        Locale.ROOT,
                        "%.4f",
                        RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED
                                ? FRUSTUM_MIN_REJECTION_INTEGRATED
                                : FRUSTUM_MIN_REJECTION_DISCRETE)
                + "\nfrustum_autotune_probe_phase="
                + FRUSTUM_PROBE_PHASE_FRAMES
                + "\nhzb_last_rejection="
                + String.format(Locale.ROOT, "%.4f", lastRejection)
                + "\nhzb_rejection_ema="
                + String.format(Locale.ROOT, "%.4f", rejectionEma)
                + "\nhzb_autotune_skipped_frames="
                + hzbGate.skippedFrames()
                + "\nhzb_autotune_suppressed="
                + hzbGate.suppressed()
                + "\nhzb_autotune_probe_frames="
                + hzbGate.probeFrames()
                + "\nhzb_autotune_disable_events="
                + hzbGate.disableEvents()
                + "\nhzb_autotune_enable_events="
                + hzbGate.enableEvents()
                + "\nhzb_autotune_zero_rejection_fast_suppresses="
                + autoZeroRejectionFastSuppresses
                + "\nhzb_no_target_suppressed="
                + autoNoTargetSuppressed
                + "\nhzb_no_target_discoveries_total="
                + autoNoTargetDiscoveries
                + "\nhzb_no_target_fast_skips_total="
                + autoNoTargetFastSkips
                + "\nhzb_no_target_probe_frames_total="
                + autoNoTargetProbeFrames
                + "\nhzb_autotune_estimated_saved_ms="
                + String.format(Locale.ROOT, "%.4f", autoEstimatedSavedMs)
                + "\nhzb_autotune_measured_cost_ms="
                + String.format(Locale.ROOT, "%.4f", autoMeasuredCostMs)
                + "\nhzb_autotune_benefit_ratio="
                + String.format(Locale.ROOT, "%.4f", autoBenefitRatio)
                + "\nhzb_readback_capacity_bytes="
                + (readback == null ? 0 : readback.size())
                + "\nhzb_readback_resizes_total="
                + readbackResizes
                + "\nhzb_viewport="
                + width
                + "x"
                + height
                + "\nhzb_base="
                + pyramidWidth
                + "x"
                + pyramidHeight
                + "\nhzb_levels="
                + mipCount
                + "\nhzb_storage_bytes="
                + (pyramidWords * Integer.BYTES)
                + "\n";
    }
}
