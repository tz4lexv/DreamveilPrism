package dev.veil.revive.client;

import com.mojang.blaze3d.systems.GpuQueryPool;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.WallClockCadence;
import dev.veil.revive.mixin.VulkanQueryPoolInvoker;

import java.util.Arrays;
import java.util.OptionalLong;

final class VeilGpuProfiler {
    enum Pass {
        UPLOAD("upload"),
        HZB("hzb"),
        HZB_BUILD("hzb_build"),
        FRUSTUM_CULL("frustum_cull"),
        HZB_CULL("hzb_cull"),
        WORLD_RENDER("world_render"),
        HOST_TERRAIN_OPAQUE("host_terrain_opaque"),
        AUTO_LOD_HOST_PROBE("auto_lod_host_probe"),
        AUTO_LOD_CUSTOM_PROBE("auto_lod_custom_probe"),
        TERRAIN_OPAQUE("terrain_opaque"),
        TERRAIN_TRANSLUCENT("terrain_translucent"),
        OPAQUE_DIRECT_DRAWS("opaque_direct_draws"),
        OPAQUE_DIRECT_MDI("opaque_direct_mdi"),
        OPAQUE_FRUSTUM_MDI("opaque_frustum_mdi");
        final String key;

        Pass(String key) {
            this.key = key;
        }
    }

    private static final int SLOT_COUNT = 4;
    private static final int QUERIES_PER_PASS = 2;
    private static final int QUERIES_PER_SLOT = Pass.values().length * QUERIES_PER_PASS;
    private static final long AUTO_PROFILE_INTERVAL_NS = 500_000_000L;
    private static final WallClockCadence AUTO_PROFILE_CADENCE = new WallClockCadence();
    private static GpuQueryPool pool;
    private static final boolean[] pending = new boolean[SLOT_COUNT];
    private static final boolean[] ready = new boolean[SLOT_COUNT];
    private static final boolean[][] started = new boolean[SLOT_COUNT][Pass.values().length];
    private static final boolean[][] ended = new boolean[SLOT_COUNT][Pass.values().length];
    private static final double[] lastMs = new double[Pass.values().length];
    private static final double[] emaMs = new double[Pass.values().length];
    private static final double[] totalMs = new double[Pass.values().length];
    private static final long[] passSamples = new long[Pass.values().length];
    private static int currentSlot = -1;
    private static long profiledFrames;
    private static long autoProfiledFrames;
    private static long continuousProfiledFrames;
    private static long samples;
    private static long skippedFrames;

    private VeilGpuProfiler() {}

    static void beginFrame() {
        if (!isVulkan()) {
            currentSlot = -1;
            return;
        }

        boolean lodAutotuneTiming = VeilAutoLodGpuAutotune.timingNeededNextFrame();
        VeilAutoLodGpuAutotune.onGpuFrameStart();
        boolean benchmark = VeilDiagnostics.benchmarkActive() || VeilSubmissionBenchmark.active();
        boolean continuous =
                VeilVideoConfig.flag("profiling.gpu", false)
                        || ReviveRuntime.config().profilerEnabled()
                        || VeilDiagnostics.detailedOverlay();
        boolean automatic =
                VeilHzb.autotuneTimingNeededNextFrame()
                        || lodAutotuneTiming
                        || AUTO_PROFILE_CADENCE.due(System.nanoTime(), AUTO_PROFILE_INTERVAL_NS);
        if (!benchmark && !continuous && !automatic) {
            currentSlot = -1;
            return;
        }

        ensure();
        for (int i = 0; i < SLOT_COUNT; i++) if (pending[i]) poll(i);
        int candidate = (int) (profiledFrames++ % SLOT_COUNT);
        if (pending[candidate]) {
            currentSlot = -1;
            skippedFrames++;
            return;
        }
        if (benchmark || continuous) continuousProfiledFrames++;
        else autoProfiledFrames++;
        currentSlot = candidate;
        Arrays.fill(started[candidate], false);
        Arrays.fill(ended[candidate], false);
        ready[candidate] = false;
        var runtime = VeilVulkanRuntime.requireCurrent();
        org.lwjgl.vulkan.VK10.vkCmdResetQueryPool(
                runtime.commandBuffer(),
                ((VulkanQueryPoolInvoker) pool).veil$queryPool(),
                candidate * QUERIES_PER_SLOT,
                QUERIES_PER_SLOT);
    }

    static void begin(Pass pass) {
        if (currentSlot < 0 || started[currentSlot][pass.ordinal()]) return;
        int query = query(currentSlot, pass, 0);
        writeTimestamp(query);
        started[currentSlot][pass.ordinal()] = true;
        pending[currentSlot] = true;
    }

    static void end(Pass pass) {
        if (currentSlot < 0
                || !started[currentSlot][pass.ordinal()]
                || ended[currentSlot][pass.ordinal()]) return;
        int query = query(currentSlot, pass, 1);
        writeTimestamp(query);
        ended[currentSlot][pass.ordinal()] = true;
        if (pass == Pass.WORLD_RENDER) {
            int slot = currentSlot;
            GpuQueryPool submittedPool = pool;
            VeilVulkanRuntime.requireCurrent()
                    .deferDestroy(
                            () -> {
                                if (pool == submittedPool) ready[slot] = true;
                            });
        }
    }

    private static void writeTimestamp(int query) {
        org.lwjgl.vulkan.KHRSynchronization2.vkCmdWriteTimestamp2KHR(
                VeilVulkanRuntime.requireCurrent().commandBuffer(),
                org.lwjgl.vulkan.VK13.VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                ((VulkanQueryPoolInvoker) pool).veil$queryPool(),
                query);
    }

    private static void poll(int slot) {
        if (!ready[slot]) return;
        boolean hasAny = false;
        for (Pass pass : Pass.values()) {
            if (!started[slot][pass.ordinal()] || !ended[slot][pass.ordinal()]) continue;
            OptionalLong start = pool.getValue(query(slot, pass, 0));
            OptionalLong end = pool.getValue(query(slot, pass, 1));
            if (start.isEmpty() || end.isEmpty()) return;
            long delta = end.getAsLong() - start.getAsLong();
            double ms =
                    Math.max(
                            0.0,
                            delta
                                    * RenderSystem.getDevice().getDeviceInfo().timestampPeriod()
                                    / 1_000_000.0);
            lastMs[pass.ordinal()] = ms;
            double old = emaMs[pass.ordinal()];
            emaMs[pass.ordinal()] = old == 0.0 ? ms : old * 0.90 + ms * 0.10;
            totalMs[pass.ordinal()] += ms;
            passSamples[pass.ordinal()]++;
            hasAny = true;
        }
        if (hasAny) samples++;
        pending[slot] = false;
    }

    private static int query(int slot, Pass pass, int endpoint) {
        return slot * QUERIES_PER_SLOT + pass.ordinal() * QUERIES_PER_PASS + endpoint;
    }

    private static void ensure() {
        if (pool == null)
            pool = RenderSystem.getDevice().createTimestampQueryPool(SLOT_COUNT * QUERIES_PER_SLOT);
    }

    static double emaMs(Pass pass) {
        return emaMs[pass.ordinal()];
    }

    static double lastMs(Pass pass) {
        return lastMs[pass.ordinal()];
    }

    static PassTotals totals(Pass pass) {
        return new PassTotals(totalMs[pass.ordinal()], passSamples[pass.ordinal()]);
    }

    static Snapshot snapshot() {
        return new Snapshot(totalMs.clone(), passSamples.clone());
    }

    record Snapshot(double[] totalMs, long[] samples) {
        static Snapshot empty() {
            return new Snapshot(new double[Pass.values().length], new long[Pass.values().length]);
        }

        Snapshot deltaTo(Snapshot end) {
            double[] ms = new double[Pass.values().length];
            long[] count = new long[Pass.values().length];
            for (Pass pass : Pass.values()) {
                int i = pass.ordinal();
                ms[i] = Math.max(0.0, end.totalMs[i] - totalMs[i]);
                count[i] = Math.max(0L, end.samples[i] - samples[i]);
            }
            return new Snapshot(ms, count);
        }

        Snapshot plus(Snapshot other) {
            double[] ms = new double[Pass.values().length];
            long[] count = new long[Pass.values().length];
            for (Pass pass : Pass.values()) {
                int i = pass.ordinal();
                ms[i] = totalMs[i] + other.totalMs[i];
                count[i] = samples[i] + other.samples[i];
            }
            return new Snapshot(ms, count);
        }

        double averageMs(Pass pass) {
            int i = pass.ordinal();
            return samples[i] <= 0L ? 0.0 : totalMs[i] / samples[i];
        }

        double totalMs(Pass pass) {
            return totalMs[pass.ordinal()];
        }

        long samples(Pass pass) {
            return samples[pass.ordinal()];
        }
    }

    record PassTotals(double totalMs, long samples) {
        PassTotals deltaTo(PassTotals end) {
            return new PassTotals(end.totalMs - totalMs, end.samples - samples);
        }

        double averageMs() {
            return samples <= 0L ? 0.0 : totalMs / samples;
        }
    }

    static double trackedLastMs() {
        double total = 0.0;
        for (Pass pass : Pass.values()) if (!diagnosticSubpass(pass)) total += lastMs(pass);
        return total;
    }

    static double trackedEmaMs() {
        double total = 0.0;
        for (Pass pass : Pass.values()) if (!diagnosticSubpass(pass)) total += emaMs(pass);
        return total;
    }

    private static boolean diagnosticSubpass(Pass pass) {
        return pass == Pass.WORLD_RENDER
                || pass == Pass.HOST_TERRAIN_OPAQUE
                || pass == Pass.AUTO_LOD_HOST_PROBE
                || pass == Pass.AUTO_LOD_CUSTOM_PROBE
                || pass == Pass.HZB_BUILD
                || pass == Pass.FRUSTUM_CULL
                || pass == Pass.HZB_CULL
                || pass == Pass.OPAQUE_DIRECT_DRAWS
                || pass == Pass.OPAQUE_DIRECT_MDI
                || pass == Pass.OPAQUE_FRUSTUM_MDI;
    }

    static String telemetry() {
        StringBuilder out = new StringBuilder(256);
        out.append("gpu_timestamp_samples=").append(samples).append('\n');
        out.append("gpu_timestamp_profiled_frames_total=").append(profiledFrames).append('\n');
        out.append("gpu_timestamp_auto_profiled_frames_total=")
                .append(autoProfiledFrames)
                .append('\n');
        out.append("gpu_timestamp_continuous_profiled_frames_total=")
                .append(continuousProfiledFrames)
                .append('\n');
        out.append("gpu_timestamp_continuous_configured=")
                .append(VeilVideoConfig.flag("profiling.gpu", false))
                .append('\n');
        out.append("gpu_timestamp_skipped_frames=").append(skippedFrames).append('\n');
        out.append("gpu_veil_tracked_ms=")
                .append(String.format(java.util.Locale.ROOT, "%.4f", trackedLastMs()))
                .append('\n');
        out.append("gpu_veil_tracked_ema_ms=")
                .append(String.format(java.util.Locale.ROOT, "%.4f", trackedEmaMs()))
                .append('\n');
        for (Pass pass : Pass.values()) {
            out.append("gpu_")
                    .append(pass.key)
                    .append("_ms=")
                    .append(String.format(java.util.Locale.ROOT, "%.4f", lastMs(pass)))
                    .append('\n');
            out.append("gpu_")
                    .append(pass.key)
                    .append("_ema_ms=")
                    .append(String.format(java.util.Locale.ROOT, "%.4f", emaMs(pass)))
                    .append('\n');
        }
        return out.toString();
    }

    static void close() {
        if (pool != null) {
            pool.close();
            pool = null;
        }
        Arrays.fill(pending, false);
        Arrays.fill(ready, false);
        currentSlot = -1;
        AUTO_PROFILE_CADENCE.reset();
    }

    private static boolean isVulkan() {
        return RenderSystem.getDevice().getDeviceInfo().backendName().equalsIgnoreCase("Vulkan");
    }
}
