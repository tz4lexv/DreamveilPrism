package dev.veil.revive.client;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;

final class VeilSlangSources {
    record Snapshot(
            Map<VeilShaderId, byte[]> files, Map<VeilShaderId, String> dependencies, String hash) {
        Snapshot {
            files = Map.copyOf(files);
            dependencies = Map.copyOf(dependencies);
        }
    }

    private static final Pattern INCLUDE = Pattern.compile("(?m)^\\s*#\\s*include\\s+([^\\r\\n]+)");
    private static final Pattern IMPORT = Pattern.compile("\\bimport\\s+([^;]+);");
    private static final Pattern TEXT_INCLUDE = Pattern.compile("\\b__include\\s+([^;]+);");
    private static final long MAX_SOURCES_BYTES = 64L * 1024 * 1024;

    static Snapshot capture(VeilShaderAssets assets, VeilShaderId source) throws IOException {
        var files = new TreeMap<VeilShaderId, byte[]>();
        List<String> entries;
        try {
            entries = assets.entries(source.namespace());
        } catch (IOException unavailable) {
            entries = List.of(source.path());
        }
        long capturedBytes = 0;
        for (String entry : entries) {
            if (entry.endsWith(".slang")
                    || entry.endsWith(".slangh")
                    || entry.endsWith(".h")
                    || entry.endsWith(".glsl")) {
                var id = new VeilShaderId(source.namespace(), entry);
                byte[] bytes = assets.read(id);
                if (bytes.length > VeilShaderAssets.MAX_SHADER_ASSET_BYTES)
                    throw new IOException("Slang source exceeds 4 MiB: " + id);
                capturedBytes = add(files, id, bytes, capturedBytes);
            }
        }
        if (!files.containsKey(source))
            capturedBytes = add(files, source, assets.read(source), capturedBytes);
        var index = VeilShaderId.parse("veil:slang/sdk-index.txt");
        byte[] indexBytes = assets.read(index);
        capturedBytes = add(files, index, indexBytes, capturedBytes);
        for (String name : new String(indexBytes, StandardCharsets.UTF_8).lines().toList()) {
            if (name.isBlank()) continue;
            var id = new VeilShaderId("veil", "slang/" + name.trim());
            capturedBytes = add(files, id, assets.read(id), capturedBytes);
        }
        var dependencies = new LinkedHashMap<VeilShaderId, String>();
        files.forEach((id, bytes) -> dependencies.put(id, VeilShaderAssets.hash(bytes)));
        var pending = new java.util.ArrayDeque<VeilShaderId>();
        for (var id : files.keySet()) if (id.path().endsWith(".slang")) pending.add(id);
        pending.add(source);
        var checked = new java.util.HashSet<VeilShaderId>();
        while (!pending.isEmpty()) {
            var id = pending.removeFirst();
            if (!checked.add(id)) continue;
            String code = new String(files.get(id), StandardCharsets.UTF_8);
            String directives = code.replaceAll("(?s)/\\*.*?\\*/|(?m)//[^\\r\\n]*", "");
            var imports = IMPORT.matcher(directives);
            while (imports.find()) {
                String name = imports.group(1).trim();
                if (name.startsWith("\"") && name.endsWith("\""))
                    name = name.substring(1, name.length() - 1);
                if (!name.matches("[A-Za-z_][A-Za-z0-9_]*(?:\\.[A-Za-z_][A-Za-z0-9_]*)*"))
                    throw new IOException(
                            "Slang imports must name modules inside the shader pack or Veil SDK: "
                                    + id);
            }
            var textual = TEXT_INCLUDE.matcher(directives);
            while (textual.find()) pending.add(validateInclude(files, id, textual.group(1).trim()));
            var includes = INCLUDE.matcher(directives);
            while (includes.find())
                pending.add(validateInclude(files, id, includes.group(1).trim()));
        }
        String signature = dependencies.toString();
        return new Snapshot(
                files,
                dependencies,
                VeilShaderAssets.hash(signature.getBytes(StandardCharsets.UTF_8)));
    }

    private static long add(
            Map<VeilShaderId, byte[]> files, VeilShaderId id, byte[] bytes, long total)
            throws IOException {
        if (bytes.length > VeilShaderAssets.MAX_SHADER_ASSET_BYTES)
            throw new IOException("Slang source exceeds 4 MiB: " + id);
        byte[] old = files.get(id);
        long next = total + bytes.length - (old == null ? 0 : old.length);
        if (next > MAX_SOURCES_BYTES) throw new IOException("Slang sources exceed 64 MiB");
        files.put(id, bytes);
        return next;
    }

    private static VeilShaderId validateInclude(
            Map<VeilShaderId, byte[]> files, VeilShaderId source, String value) throws IOException {
        int end =
                value.startsWith("\"")
                        ? value.indexOf('"', 1)
                        : value.startsWith("<") ? value.indexOf('>', 1) : -1;
        if (end < 1)
            throw new IOException("Slang includes must use literal relative paths: " + source);
        VeilShaderId target;
        try {
            target = source.relative(value.substring(1, end));
        } catch (IllegalArgumentException invalid) {
            throw new IOException("Invalid Slang include in " + source, invalid);
        }
        if (!files.containsKey(target))
            throw new IOException(
                    "Slang include is outside the captured shader sources: " + target);
        return target;
    }
}
