package dev.veil.revive.client.shaderpack.parsing;

import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import dev.veil.revive.client.VeilShaderPack.Setting;

import java.util.Map;

final class PipelineSettingInputs {
    private static final Map<String, String> RASTER_TYPES =
            Map.ofEntries(
                    Map.entry("polygonMode", "enum"), Map.entry("cullMode", "enum"),
                    Map.entry("frontFace", "enum"), Map.entry("depthClamp", "bool"),
                    Map.entry("rasterizerDiscard", "bool"), Map.entry("depthBias", "bool"),
                    Map.entry("depthBiasConstant", "float"), Map.entry("depthBiasSlope", "float"),
                    Map.entry("depthBiasClamp", "float"), Map.entry("lineWidth", "float"));

    private PipelineSettingInputs() {}

    static JsonObject resolve(JsonObject source, Map<String, Setting> settings) {
        JsonObject result = source.deepCopy();
        resolveFields(
                result,
                settings,
                Map.of(
                        "topology",
                        "enum",
                        "patchControlPoints",
                        "int",
                        "primitiveRestart",
                        "bool"));
        if (result.has("raster"))
            resolveFields(result.getAsJsonObject("raster"), settings, RASTER_TYPES);
        return result;
    }

    private static void resolveFields(
            JsonObject object, Map<String, Setting> settings, Map<String, String> types) {
        for (var field : types.entrySet()) {
            var element = object.get(field.getKey());
            if (element == null || !element.isJsonObject()) continue;
            JsonObject reference = element.getAsJsonObject();
            ManifestJson.fields(reference, "setting");
            if (!reference.has("setting")
                    || !reference.get("setting").isJsonPrimitive()
                    || !reference.getAsJsonPrimitive("setting").isString()) {
                throw new IllegalArgumentException(
                        "Pipeline " + field.getKey() + " requires a setting name");
            }
            String name = reference.get("setting").getAsString();
            Setting setting = settings.get(name);
            if (setting == null)
                throw new IllegalArgumentException("Unknown pipeline setting " + name);
            String expected = field.getValue();
            if (!setting.type().equals(expected)
                    && !(expected.equals("float") && setting.type().equals("int"))) {
                throw new IllegalArgumentException(
                        "Pipeline "
                                + field.getKey()
                                + " requires a "
                                + expected
                                + " setting: "
                                + name);
            }
            JsonPrimitive value =
                    switch (expected) {
                        case "float" -> new JsonPrimitive(Float.parseFloat(setting.value()));
                        case "int" -> new JsonPrimitive(Integer.parseInt(setting.value()));
                        case "bool" -> new JsonPrimitive(Boolean.parseBoolean(setting.value()));
                        case "enum" -> new JsonPrimitive(setting.value());
                        default -> throw new IllegalStateException(expected);
                    };
            object.add(field.getKey(), value);
        }
    }
}
