package dev.veil.revive.client.graphics.synchronization;

import dev.veil.revive.client.VeilRenderGraph;

import java.util.ArrayList;
import java.util.List;

/** Temporary transfers return each copied subresource to its actual graph layout. */
public record ImageTransferTransitions(
        List<VeilRenderGraph.Barrier> acquire, List<VeilRenderGraph.Barrier> restore) {
    public ImageTransferTransitions {
        acquire = List.copyOf(acquire);
        restore = List.copyOf(restore);
    }

    public static ImageTransferTransitions plan(
            String resource,
            List<VeilRenderGraph.ImageState> states,
            VeilRenderGraph.Subresource copied,
            VeilRenderGraph.State transfer) {
        if (copied.whole() || copied.bufferRange())
            throw new IllegalArgumentException("Transfer requires a finite image range");
        if (transfer.layout() != VeilRenderGraph.Layout.TRANSFER_SOURCE
                && transfer.layout() != VeilRenderGraph.Layout.TRANSFER_DESTINATION)
            throw new IllegalArgumentException("Transfer requires a transfer layout");
        var acquire = new ArrayList<VeilRenderGraph.Barrier>();
        var restore = new ArrayList<VeilRenderGraph.Barrier>();
        long covered = 0;
        for (var entry : states) {
            var range = entry.subresource();
            int mip = Math.max(range.baseMip(), copied.baseMip());
            int mipEnd =
                    Math.min(
                            range.baseMip() + range.levelCount(),
                            copied.baseMip() + copied.levelCount());
            int layer = Math.max(range.baseLayer(), copied.baseLayer());
            int layerEnd =
                    Math.min(
                            range.baseLayer() + range.layerCount(),
                            copied.baseLayer() + copied.layerCount());
            if (mipEnd <= mip || layerEnd <= layer) continue;
            var selected =
                    VeilRenderGraph.Subresource.image(mip, mipEnd - mip, layer, layerEnd - layer);
            if (entry.state().layout() == VeilRenderGraph.Layout.UNDEFINED)
                throw new IllegalStateException(
                        "Transfer cannot restore undefined layout: " + resource);
            if (acquire.stream().anyMatch(barrier -> barrier.subresource().overlaps(selected)))
                throw new IllegalStateException("Overlapping image state snapshot: " + resource);
            covered += (long) (mipEnd - mip) * (layerEnd - layer);
            acquire.add(new VeilRenderGraph.Barrier(resource, selected, entry.state(), transfer));
            restore.add(new VeilRenderGraph.Barrier(resource, selected, transfer, entry.state()));
        }
        if (covered != (long) copied.levelCount() * copied.layerCount())
            throw new IllegalStateException("Incomplete image state snapshot: " + resource);
        return new ImageTransferTransitions(acquire, restore);
    }
}
