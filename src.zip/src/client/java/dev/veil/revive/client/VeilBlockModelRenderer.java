package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.QuadInstance;

import dev.veil.revive.core.terrain.CompileCancellationScope;

import it.unimi.dsi.fastutil.ints.IntList;

import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.BlockQuadOutput;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.LongAdder;

public final class VeilBlockModelRenderer {
    private static final Direction[] DIRECTIONS = Direction.values();
    private static final LongAdder BLOCKS = new LongAdder(), QUADS = new LongAdder();
    private static final LongAdder NATIVE_CONTEXTS = new LongAdder();
    private static final LongAdder NATIVE_LIGHTING_CONTEXTS = new LongAdder();
    private final Access access;
    private final VeilModelTintCache tints;
    private final boolean ambientOcclusion;
    private final RandomSource random = RandomSource.createThreadLocalInstance(0L);
    private final List<BlockStateModelPart> parts = new ArrayList<>();
    private final BlockPos.MutableBlockPos neighbor = new BlockPos.MutableBlockPos();
    private final QuadInstance attributes = new QuadInstance();
    private final byte[] faces = new byte[6];

    public VeilBlockModelRenderer(boolean ambientOcclusion, BlockColors colors, Access access) {
        this.ambientOcclusion = ambientOcclusion;
        this.tints = new VeilModelTintCache(colors, access::dynamicTints);
        this.access = access;
    }

    public void render(
            BlockQuadOutput output,
            BlockAndTintGetter world,
            BlockPos position,
            BlockState state,
            BlockStateModel model,
            int x,
            int y,
            int z) {
        random.setSeed(state.getSeed(position));
        Arrays.fill(faces, (byte) 0);
        try {
            access.collect(model, world, position, state, random, parts);
            if (parts.isEmpty()) return;
            access.begin(state, world, position);
            var offset = state.getOffset(position);
            float ox = x + (float) offset.x, oy = y + (float) offset.y, oz = z + (float) offset.z;
            boolean smooth =
                    ambientOcclusion
                            && access.ambientPath(parts.getFirst(), state, world, position);
            long emitted = 0;
            for (var part : parts) {
                CompileCancellationScope.check();
                boolean partSmooth = smooth && access.ambientPart(part, state, world, position);
                for (int group = 0; group <= DIRECTIONS.length; group++) {
                    Direction face = group == DIRECTIONS.length ? null : DIRECTIONS[group];
                    if (face != null && faces[group] == 2) continue;
                    var quads = part.getQuads(face);
                    if (quads.isEmpty()) continue;
                    int light = -1;
                    if (face != null) {
                        neighbor.setWithOffset(position, face);
                        if (faces[group] == 0)
                            faces[group] =
                                    (byte)
                                            (access.visible(world, position, state, face, neighbor)
                                                    ? 1
                                                    : 2);
                        if (faces[group] == 2) continue;
                        if (!partSmooth) light = access.light(state, world, neighbor);
                    }
                    for (var quad : quads) {
                        if (VeilOriginalQuadCapture.REQUESTED && VeilOriginalQuadCapture.active())
                            VeilOriginalQuadCapture.record(
                                    position,
                                    state,
                                    model,
                                    ox,
                                    oy,
                                    oz,
                                    face,
                                    partSmooth && access.ambientQuad(quad),
                                    face != null && !partSmooth,
                                    () -> access.copyOriginal(quad));
                        if (partSmooth && access.ambientQuad(quad))
                            access.smooth(world, state, position, quad, attributes);
                        else
                            access.flat(
                                    world,
                                    state,
                                    position,
                                    partSmooth ? -1 : light,
                                    quad,
                                    attributes);
                        int tint = quad.materialInfo().tintIndex();
                        if (tint != -1)
                            attributes.multiplyColor(tints.color(world, state, position, tint));
                        output.put(ox, oy, oz, quad, attributes);
                        emitted++;
                    }
                }
            }
            record(emitted);
        } finally {
            parts.clear();
            tints.clear();
        }
    }

    public boolean replay(
            BlockQuadOutput output,
            BlockAndTintGetter world,
            VeilOriginalQuadCapture.Quad original) {
        return replayBlock(output, world, List.of(original), 0, 1);
    }

    public boolean replayBlock(
            BlockQuadOutput output,
            BlockAndTintGetter world,
            List<VeilOriginalQuadCapture.Quad> quads,
            int from,
            int to) {
        java.util.Objects.checkFromToIndex(from, to, quads.size());
        if (from == to) return true;
        var first = quads.get(from);
        for (int i = from; i < to; i++)
            if (!VeilOriginalQuadCapture.sameBlock(first, quads.get(i))
                    || access.originalQuad(quads.get(i).geometry()) == null) return false;
        CompileCancellationScope.check();
        var position = BlockPos.of(first.position());
        try {
            access.begin(first.state(), world, position);
            for (int i = from; i < to; i++) {
                CompileCancellationScope.check();
                var original = quads.get(i);
                var quad = access.originalQuad(original.geometry());
                if (original.ambient())
                    access.smooth(world, first.state(), position, quad, attributes);
                else {
                    int light = -1;
                    if (original.neighborLight()) {
                        neighbor.setWithOffset(position, original.cullFace());
                        light = access.light(first.state(), world, neighbor);
                    }
                    access.flat(world, first.state(), position, light, quad, attributes);
                }
                int tint = quad.materialInfo().tintIndex();
                if (tint != -1)
                    attributes.multiplyColor(tints.color(world, first.state(), position, tint));
                output.put(first.x(), first.y(), first.z(), quad, attributes);
            }
            return true;
        } finally {
            tints.clear();
        }
    }

    public static void record(long quads) {
        if (VeilTechniqueCounters.collecting()) {
            BLOCKS.increment();
            QUADS.add(quads);
        }
    }

    private static final java.util.concurrent.atomic.LongAdder
            LIGHTING_CREATED = new java.util.concurrent.atomic.LongAdder(),
            LIGHTING_REUSED = new java.util.concurrent.atomic.LongAdder(),
            LIGHTING_NESTED = new java.util.concurrent.atomic.LongAdder();

    public record LightingLeases(long created, long reused, long nested) {
        public LightingLeases minus(LightingLeases before) {
            return new LightingLeases(
                    created - before.created, reused - before.reused, nested - before.nested);
        }
    }

    public static LightingLeases lightingLeases() {
        return new LightingLeases(
                LIGHTING_CREATED.sum(), LIGHTING_REUSED.sum(), LIGHTING_NESTED.sum());
    }

    public static void recordLightingLease(boolean reused, boolean nested) {
        if (!VeilTechniqueCounters.collecting()) return;
        if (reused) LIGHTING_REUSED.increment();
        else LIGHTING_CREATED.increment();
        if (nested) LIGHTING_NESTED.increment();
    }

    public static void recordNativeContext() {
        if (VeilTechniqueCounters.collecting()) NATIVE_CONTEXTS.increment();
    }

    public static void recordNativeLightingContext() {
        if (VeilTechniqueCounters.collecting()) NATIVE_LIGHTING_CONTEXTS.increment();
    }

    static void requireComplete() {
        VeilOriginalQuadReplay.requireComplete();
        VeilOriginalQuadCapture.requireComplete();
        if (Boolean.getBoolean("veil.reuseLightingContexts")
                && Boolean.getBoolean("veil.ownModelRenderer")) {
            if (LIGHTING_REUSED.sum() == 0)
                throw new IllegalStateException("Lighting contexts not reused");
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil lighting leases: PASS (created={} reused={} nested={})",
                    LIGHTING_CREATED.sum(),
                    LIGHTING_REUSED.sum(),
                    LIGHTING_NESTED.sum());
        }
        if (!Boolean.getBoolean("veil.ownModelRenderer")) return;
        if (BLOCKS.sum() == 0
                && dev.veil.revive.platform.VeilPlatform.get().loaderName().equals("Fabric")) {
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil own model renderer: PLATFORM FALLBACK (Fabric emission API retained)");
            return;
        }
        if (BLOCKS.sum() == 0 || QUADS.sum() == 0)
            throw new IllegalStateException("Own model renderer not connected");
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil own model renderer: PASS (blocks={} quads={})", BLOCKS.sum(), QUADS.sum());
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil own model session contexts: native={}", NATIVE_CONTEXTS.sum());
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil own model lighting contexts: native={}", NATIVE_LIGHTING_CONTEXTS.sum());
    }

    public interface Access {
        void collect(
                BlockStateModel model,
                BlockAndTintGetter world,
                BlockPos position,
                BlockState state,
                RandomSource random,
                List<BlockStateModelPart> parts);

        void begin(BlockState state, BlockAndTintGetter world, BlockPos position);

        boolean ambientPath(
                BlockStateModelPart first,
                BlockState state,
                BlockAndTintGetter world,
                BlockPos position);

        boolean ambientPart(
                BlockStateModelPart part,
                BlockState state,
                BlockAndTintGetter world,
                BlockPos position);

        boolean ambientQuad(BakedQuad quad);

        boolean visible(
                BlockAndTintGetter world,
                BlockPos position,
                BlockState state,
                Direction direction,
                BlockPos neighbor);

        int light(BlockState state, BlockAndTintGetter world, BlockPos position);

        void smooth(
                BlockAndTintGetter world,
                BlockState state,
                BlockPos position,
                BakedQuad quad,
                QuadInstance attributes);

        void flat(
                BlockAndTintGetter world,
                BlockState state,
                BlockPos position,
                int light,
                BakedQuad quad,
                QuadInstance attributes);

        default BakedQuad originalQuad(VeilOriginalQuadCapture.Geometry geometry) {
            return null;
        }

        default VeilOriginalQuadCapture.Geometry copyOriginal(BakedQuad quad) {
            throw new UnsupportedOperationException(
                    "Original quad capture unsupported by platform");
        }

        default void dynamicTints(
                BlockState state, BlockAndTintGetter world, BlockPos position, IntList values) {}
    }
}
