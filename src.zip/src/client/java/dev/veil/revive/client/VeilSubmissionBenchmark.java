package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;

final class VeilSubmissionBenchmark {
    private static final long GLOBAL_WARMUP_NS = 5_000_000_000L;
    private static final long BLOCK_WARMUP_NS = 2_000_000_000L;
    private static final long MEASURE_NS = 5_000_000_000L;

    private static Run run;
    private static long ordinal;

    private VeilSubmissionBenchmark() {}

    static boolean active() {
        return run != null;
    }

    static void start(Minecraft client) {
        if (run != null) {
            message(client, "Veil submission benchmark is already running.");
            return;
        }
        if (VeilDiagnostics.benchmarkActive()) {
            message(client, "Cancel the F9 proof benchmark first.");
            return;
        }
        if (VeilVisualValidation.active()) {
            message(client, "Visual validation is running; wait for it to finish first.");
            return;
        }
        if (client.player == null) {
            message(client, "Enter a world before starting the submission benchmark.");
            return;
        }
        boolean reverse = (ordinal++ & 1L) != 0L;
        run = new Run(client, VeilDiagnostics.bypassed(), reverse);
        run.begin(client);
    }

    static void cancel(Minecraft client) {
        if (run == null) {
            message(client, "No Veil submission benchmark is running.");
            return;
        }
        run.cancel(client, "cancelled by user");
        run = null;
    }

    static void onFrameStart(long nowNs) {
        if (run != null) run.onFrameStart(nowNs);
    }

    static void onWorldRenderEnd(double renderMs) {
        if (run != null) run.onWorldRenderEnd(renderMs);
    }

    static void onClientTick(Minecraft client) {
        Run current = run;
        if (current == null) return;
        current.tick(client);
        if (current.finished) run = null;
    }

    static String status() {
        return run == null ? "submission benchmark idle" : run.status();
    }

    private enum Mode {
        BYPASS,
        DIRECT_DRAWS,
        DIRECT_MDI,
        FRUSTUM_MDI;

        VeilSubmissionControl.Mode submissionMode() {
            return switch (this) {
                case DIRECT_DRAWS -> VeilSubmissionControl.Mode.DIRECT_DRAWS;
                case DIRECT_MDI -> VeilSubmissionControl.Mode.DIRECT_MDI;
                case FRUSTUM_MDI -> VeilSubmissionControl.Mode.FRUSTUM_MDI;
                case BYPASS -> VeilSubmissionControl.Mode.AUTO;
            };
        }

        VeilGpuProfiler.Pass profilerPass() {
            return switch (this) {
                case DIRECT_DRAWS -> VeilGpuProfiler.Pass.OPAQUE_DIRECT_DRAWS;
                case DIRECT_MDI -> VeilGpuProfiler.Pass.OPAQUE_DIRECT_MDI;
                case FRUSTUM_MDI -> VeilGpuProfiler.Pass.OPAQUE_FRUSTUM_MDI;
                case BYPASS -> VeilGpuProfiler.Pass.HOST_TERRAIN_OPAQUE;
            };
        }
    }

    private enum Phase {
        GLOBAL_WARMUP,
        BLOCK_WARMUP,
        MEASURE
    }

    private static final class Run {
        private final boolean restoreBypass;
        private final CameraStamp origin;
        private final Mode[] order;
        private final ArrayList<Block> completed = new ArrayList<>(8);
        private Phase phase = Phase.GLOBAL_WARMUP;
        private int index;
        private long phaseStartNs;
        private long lastFrameStartNs;
        private Accumulator active;
        private boolean finished;

        Run(Minecraft client, boolean restoreBypass, boolean reverse) {
            this.restoreBypass = restoreBypass;
            this.origin = CameraStamp.capture(client);
            this.order =
                    !reverse
                            ? new Mode[] {
                                Mode.BYPASS, Mode.DIRECT_DRAWS, Mode.DIRECT_MDI, Mode.FRUSTUM_MDI,
                                Mode.FRUSTUM_MDI, Mode.DIRECT_MDI, Mode.DIRECT_DRAWS, Mode.BYPASS
                            }
                            : new Mode[] {
                                Mode.FRUSTUM_MDI, Mode.DIRECT_MDI, Mode.DIRECT_DRAWS, Mode.BYPASS,
                                Mode.BYPASS, Mode.DIRECT_DRAWS, Mode.DIRECT_MDI, Mode.FRUSTUM_MDI
                            };
        }

        void begin(Minecraft client) {
            VeilLatencyController.resetCounters();
            apply(client, order[0]);
            phaseStartNs = System.nanoTime();
            message(
                    client,
                    "Veil submission benchmark started: BYPASS / DIRECT_DRAWS / DIRECT_MDI / FRUSTUM_MDI. Keep camera/player still for ~61 seconds.");
        }

        void onFrameStart(long nowNs) {
            if (phase != Phase.MEASURE || active == null) {
                lastFrameStartNs = 0L;
                return;
            }
            if (lastFrameStartNs != 0L) active.frames.add((nowNs - lastFrameStartNs) / 1_000_000.0);
            lastFrameStartNs = nowNs;
        }

        void onWorldRenderEnd(double renderMs) {
            if (phase == Phase.MEASURE && active != null) active.world.add(renderMs);
        }

        void tick(Minecraft client) {
            if (!origin.matches(client)) {
                cancel(client, "camera/player moved; result would not be controlled");
                return;
            }
            long elapsed = System.nanoTime() - phaseStartNs;
            switch (phase) {
                case GLOBAL_WARMUP -> {
                    if (elapsed >= GLOBAL_WARMUP_NS) beginWarmup(client);
                }
                case BLOCK_WARMUP -> {
                    if (elapsed >= BLOCK_WARMUP_NS) beginMeasure();
                }
                case MEASURE -> {
                    if (elapsed >= MEASURE_NS) finishMeasure(client);
                }
            }
        }

        private void apply(Minecraft client, Mode mode) {
            if (mode == Mode.BYPASS) {
                VeilSubmissionControl.clearBenchmarkOverride();
                VeilDiagnostics.setBypassed(true, client, false);
            } else {
                VeilDiagnostics.setBypassed(false, client, false);
                VeilSubmissionControl.setBenchmarkOverride(mode.submissionMode());
            }
        }

        private void beginWarmup(Minecraft client) {
            apply(client, order[index]);
            phase = Phase.BLOCK_WARMUP;
            phaseStartNs = System.nanoTime();
            lastFrameStartNs = 0L;
        }

        private void beginMeasure() {
            VeilTechniqueCounters.reset();
            VeilTerrainDrawBridge.resetCounters();
            Mode mode = order[index];
            active = new Accumulator(index + 1, mode);
            VeilGpuProfiler.Pass pass = mode.profilerPass();
            if (pass != null) active.gpuStart = VeilGpuProfiler.totals(pass);
            active.gpuWorldStart = VeilGpuProfiler.totals(VeilGpuProfiler.Pass.WORLD_RENDER);
            phase = Phase.MEASURE;
            phaseStartNs = System.nanoTime();
            lastFrameStartNs = 0L;
        }

        private void finishMeasure(Minecraft client) {
            Mode mode = order[index];
            VeilGpuProfiler.Pass pass = mode.profilerPass();
            VeilGpuProfiler.PassTotals gpu =
                    pass == null || active.gpuStart == null
                            ? new VeilGpuProfiler.PassTotals(0.0, 0L)
                            : active.gpuStart.deltaTo(VeilGpuProfiler.totals(pass));
            VeilGpuProfiler.PassTotals gpuWorld =
                    active.gpuWorldStart.deltaTo(
                            VeilGpuProfiler.totals(VeilGpuProfiler.Pass.WORLD_RENDER));
            VeilTechniqueCounters.Snapshot tech = VeilTechniqueCounters.snapshot();
            completed.add(
                    active.finish(
                            gpu,
                            gpuWorld,
                            tech.averageVisibleSections(),
                            tech.maxVisibleSections()));
            active = null;
            lastFrameStartNs = 0L;
            index++;
            if (index >= order.length) {
                finish(client);
                return;
            }
            beginWarmup(client);
        }

        private void finish(Minecraft client) {
            restore(client);
            finished = true;
            Report report = Report.create(completed);
            Path saved = save(report);
            message(
                    client,
                    "Veil submission benchmark complete: "
                            + report.shortResult()
                            + (saved == null ? "" : " | " + saved.getFileName()));
        }

        void cancel(Minecraft client, String reason) {
            restore(client);
            finished = true;
            message(client, "Veil submission benchmark " + reason + ".");
        }

        private void restore(Minecraft client) {
            VeilSubmissionControl.clearBenchmarkOverride();
            VeilDiagnostics.setBypassed(restoreBypass, client, false);
        }

        String status() {
            long duration =
                    switch (phase) {
                        case GLOBAL_WARMUP -> GLOBAL_WARMUP_NS;
                        case BLOCK_WARMUP -> BLOCK_WARMUP_NS;
                        case MEASURE -> MEASURE_NS;
                    };
            double remaining =
                    Math.max(
                            0.0, (duration - (System.nanoTime() - phaseStartNs)) / 1_000_000_000.0);
            return "submission block "
                    + (index + 1)
                    + "/8 "
                    + order[index]
                    + " "
                    + phase.name().toLowerCase(Locale.ROOT)
                    + String.format(Locale.ROOT, " %.1fs", remaining);
        }
    }

    private static final class Accumulator {
        final int ordinal;
        final Mode mode;
        final ArrayList<Double> frames = new ArrayList<>();
        final ArrayList<Double> world = new ArrayList<>();
        VeilGpuProfiler.PassTotals gpuStart;
        VeilGpuProfiler.PassTotals gpuWorldStart;

        Accumulator(int ordinal, Mode mode) {
            this.ordinal = ordinal;
            this.mode = mode;
        }

        Block finish(
                VeilGpuProfiler.PassTotals gpu,
                VeilGpuProfiler.PassTotals gpuWorld,
                double visibleAvg,
                long visibleMax) {
            return new Block(
                    ordinal,
                    mode,
                    Stats.of(frames),
                    Stats.of(world),
                    gpu.averageMs(),
                    gpu.samples(),
                    gpuWorld.averageMs(),
                    gpuWorld.samples(),
                    visibleAvg,
                    visibleMax);
        }
    }

    private record Block(
            int ordinal,
            Mode mode,
            Stats frame,
            Stats world,
            double gpuOpaqueMs,
            long gpuSamples,
            double gpuWorldMs,
            long gpuWorldSamples,
            double visibleAvg,
            long visibleMax) {}

    private record Stats(int count, double avg, double p50, double p95, double p99, double max) {
        static Stats of(List<Double> values) {
            if (values.isEmpty()) return new Stats(0, 0, 0, 0, 0, 0);
            double[] a = new double[values.size()];
            double sum = 0.0;
            for (int i = 0; i < a.length; i++) {
                a[i] = values.get(i);
                sum += a[i];
            }
            Arrays.sort(a);
            return new Stats(
                    a.length,
                    sum / a.length,
                    pct(a, .50),
                    pct(a, .95),
                    pct(a, .99),
                    a[a.length - 1]);
        }

        private static double pct(double[] a, double q) {
            double x = (a.length - 1) * q;
            int lo = (int) Math.floor(x), hi = (int) Math.ceil(x);
            if (lo == hi) return a[lo];
            double f = x - lo;
            return a[lo] * (1.0 - f) + a[hi] * f;
        }
    }

    private record Aggregate(
            Mode mode,
            Stats frame,
            Stats world,
            double gpuOpaqueMs,
            long gpuSamples,
            double gpuWorldMs,
            long gpuWorldSamples) {}

    private record Report(List<Block> blocks, EnumMap<Mode, Aggregate> aggregates) {
        static Report create(List<Block> blocks) {
            EnumMap<Mode, Aggregate> map = new EnumMap<>(Mode.class);
            for (Mode mode : Mode.values()) {
                ArrayList<Double> frameSamples = new ArrayList<>();
                ArrayList<Double> worldSamples = new ArrayList<>();
                double weightedGpu = 0.0;
                long gpuN = 0L;
                double weightedGpuWorld = 0.0;
                long gpuWorldN = 0L;
                for (Block b : blocks)
                    if (b.mode == mode) {

                        for (int i = 0; i < b.frame.count; i++) frameSamples.add(b.frame.avg);
                        for (int i = 0; i < b.world.count; i++) worldSamples.add(b.world.avg);
                        weightedGpu += b.gpuOpaqueMs * b.gpuSamples;
                        gpuN += b.gpuSamples;
                        weightedGpuWorld += b.gpuWorldMs * b.gpuWorldSamples;
                        gpuWorldN += b.gpuWorldSamples;
                    }
                Stats f = Stats.of(frameSamples), w = Stats.of(worldSamples);
                map.put(
                        mode,
                        new Aggregate(
                                mode,
                                f,
                                w,
                                gpuN == 0 ? 0.0 : weightedGpu / gpuN,
                                gpuN,
                                gpuWorldN == 0 ? 0.0 : weightedGpuWorld / gpuWorldN,
                                gpuWorldN));
            }
            return new Report(List.copyOf(blocks), map);
        }

        String shortResult() {
            Aggregate b = aggregates.get(Mode.BYPASS);
            Aggregate d = aggregates.get(Mode.DIRECT_DRAWS);
            Aggregate m = aggregates.get(Mode.DIRECT_MDI);
            Aggregate f = aggregates.get(Mode.FRUSTUM_MDI);
            return String.format(
                    Locale.ROOT,
                    "GPU opaque host %.3f ms | direct-draw %.3f ms | direct-MDI %.3f ms | frustum-MDI %.3f ms",
                    b.gpuOpaqueMs,
                    d.gpuOpaqueMs,
                    m.gpuOpaqueMs,
                    f.gpuOpaqueMs);
        }

        String text() {
            StringBuilder out = new StringBuilder(8192);
            out.append("========== VEIL SUBMISSION PATH BENCHMARK ==========\n");
            out.append("Veil: ")
                    .append(VeilRendererInfo.VEIL_VERSION)
                    .append("\nPackage revision: ")
                    .append(VeilRendererInfo.PACKAGE_REVISION)
                    .append("\nMinecraft target: 26.2 / Fabric\n");
            out.append(
                    "Purpose: compare Minecraft host opaque against the same Veil topology/pipeline across CPU direct draws, direct MDI and frustum-compacted MDI.\n");
            out.append("Warmup: 5 s global + 2 s per block; measurement: 5 s x 8 blocks\n");
            out.append("Camera guard: position <= 0.25 blocks, yaw/pitch <= 0.5 degrees\n");
            out.append(
                    "Benchmark latency policy: low-latency fence pacing is suspended for ALL modes\n\n");
            for (Block b : blocks) {
                out.append("BLOCK ").append(b.ordinal).append(" — ").append(b.mode).append('\n');
                out.append(
                        String.format(
                                Locale.ROOT,
                                "frame ms: avg %.3f | P50 %.3f | P95 %.3f | P99 %.3f | max %.3f | FPS %.2f%n",
                                b.frame.avg,
                                b.frame.p50,
                                b.frame.p95,
                                b.frame.p99,
                                b.frame.max,
                                b.frame.avg > 0 ? 1000.0 / b.frame.avg : 0.0));
                out.append(
                        String.format(
                                Locale.ROOT,
                                "world CPU ms: avg %.3f | P50 %.3f | P95 %.3f | P99 %.3f | max %.3f%n",
                                b.world.avg,
                                b.world.p50,
                                b.world.p95,
                                b.world.p99,
                                b.world.max));
                out.append(
                        String.format(
                                Locale.ROOT,
                                "GPU opaque submission ms: avg %.4f | timestamp samples %d%n",
                                b.gpuOpaqueMs,
                                b.gpuSamples));
                out.append(
                        String.format(
                                Locale.ROOT,
                                "GPU world-render span ms: avg %.4f | timestamp samples %d%n",
                                b.gpuWorldMs,
                                b.gpuWorldSamples));
                out.append(
                        String.format(
                                Locale.ROOT,
                                "visible sections avg/max: %.2f / %d%n%n",
                                b.visibleAvg,
                                b.visibleMax));
            }
            out.append("--- AGGREGATE BY SUBMISSION MODE ---\n");
            for (Mode mode : Mode.values()) {
                Aggregate a = aggregates.get(mode);
                out.append(
                        String.format(
                                Locale.ROOT,
                                "%-14s frame %.3f ms (~%.2f FPS) | world CPU %.3f ms | GPU opaque %.4f ms (%d) | GPU world %.4f ms (%d)%n",
                                mode,
                                a.frame.avg,
                                a.frame.avg > 0 ? 1000.0 / a.frame.avg : 0.0,
                                a.world.avg,
                                a.gpuOpaqueMs,
                                a.gpuSamples,
                                a.gpuWorldMs,
                                a.gpuWorldSamples));
            }
            Aggregate b = aggregates.get(Mode.BYPASS),
                    d = aggregates.get(Mode.DIRECT_DRAWS),
                    m = aggregates.get(Mode.DIRECT_MDI),
                    f = aggregates.get(Mode.FRUSTUM_MDI);
            out.append("\n--- DECISION SIGNALS ---\n");
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Veil direct-draw GPU delta vs Minecraft host opaque: %+.4f ms%n",
                            d.gpuOpaqueMs - b.gpuOpaqueMs));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "direct-MDI GPU delta vs direct-draw: %+.4f ms%n",
                            m.gpuOpaqueMs - d.gpuOpaqueMs));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "frustum-MDI GPU delta vs direct-MDI: %+.4f ms%n",
                            f.gpuOpaqueMs - m.gpuOpaqueMs));
            out.append(
                    "Interpretation: host-vs-direct isolates Veil pipeline/layout cost; direct-vs-MDI isolates indirect fetch/submission cost; frustum-vs-direct-MDI isolates compaction/culling benefit.\n");
            out.append("\n--- SESSION TELEMETRY ---\n")
                    .append(VeilIndirectTerrain.telemetry())
                    .append(VeilHzb.telemetry())
                    .append(VeilLightingPipeline.telemetry())
                    .append('\n')
                    .append(VeilLatencyController.telemetry());
            out.append("=====================================================\n");
            return out.toString();
        }
    }

    private record CameraStamp(double x, double y, double z, float yaw, float pitch) {
        static CameraStamp capture(Minecraft c) {
            return new CameraStamp(
                    c.player.getX(),
                    c.player.getY(),
                    c.player.getZ(),
                    c.player.getYRot(),
                    c.player.getXRot());
        }

        boolean matches(Minecraft c) {
            if (c.player == null) return false;
            double dx = c.player.getX() - x, dy = c.player.getY() - y, dz = c.player.getZ() - z;
            float dyaw = Math.abs(wrap(c.player.getYRot() - yaw)),
                    dpitch = Math.abs(c.player.getXRot() - pitch);
            return dx * dx + dy * dy + dz * dz <= 0.0625 && dyaw <= 0.5f && dpitch <= 0.5f;
        }

        private static float wrap(float d) {
            float x = d % 360.0f;
            if (x >= 180) x -= 360;
            if (x < -180) x += 360;
            return x;
        }
    }

    private static Path save(Report report) {
        Path dir = VeilPlatform.get().getGameDir().resolve("logs").resolve("veil-benchmarks");
        try {
            Files.createDirectories(dir);
            String stamp =
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
            Path file = dir.resolve("veil-submission-proof-" + stamp + ".txt");
            Files.writeString(file, report.text(), StandardCharsets.UTF_8);
            return file;
        } catch (IOException e) {
            ReviveMod.LOGGER.warn("Could not save Veil submission benchmark", e);
            return null;
        }
    }

    private static void message(Minecraft client, String text) {
        if (client != null && client.player != null)
            client.player.sendSystemMessage(Component.literal(text));
        ReviveMod.LOGGER.info(text);
    }
}
