package dev.veil.revive.client;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class VeilFrameAbi {
    public static final int VERSION = 1;
    public static final int SIZE = 32;
    public static final int FRAME_OFFSET = 0;
    public static final int TIME_OFFSET = 16;

    private VeilFrameAbi() {}

    public static int versionForPack(int packVersion) {
        if (packVersion < 1 || packVersion > VeilShaderPack.MAX_ABI_VERSION)
            throw new IllegalArgumentException("Unsupported pack ABI " + packVersion);
        return Math.min(packVersion, 4);
    }

    public static ByteBuffer write(
            ByteBuffer target, long frame, int width, int height, float seconds, float delta) {
        return write(target, VERSION, frame, width, height, seconds, delta, false, 0.0f);
    }

    public static ByteBuffer write(
            ByteBuffer target,
            int version,
            long frame,
            int width,
            int height,
            float seconds,
            float delta,
            boolean historyValid) {
        return write(target, version, frame, width, height, seconds, delta, historyValid, 0.0f);
    }

    public static ByteBuffer write(
            ByteBuffer target,
            int version,
            long frame,
            int width,
            int height,
            float seconds,
            float delta,
            boolean historyValid,
            float sunAngle) {
        if (version < 1 || version > 4)
            throw new IllegalArgumentException("Unsupported FrameData version " + version);
        if (target.remaining() < SIZE)
            throw new IllegalArgumentException("FrameData requires 32 bytes");
        if (width <= 0
                || height <= 0
                || !Float.isFinite(seconds)
                || !Float.isFinite(delta)
                || delta < 0
                || !Float.isFinite(sunAngle)) {
            throw new IllegalArgumentException("Invalid FrameData values");
        }
        int base = target.position();
        ByteBuffer bytes = target.slice().order(ByteOrder.nativeOrder());
        bytes.putInt(0, version).putInt(4, (int) frame).putInt(8, width).putInt(12, height);
        bytes.putFloat(16, seconds)
                .putFloat(20, delta)
                .putFloat(24, version >= 2 && historyValid ? 1 : 0)
                .putFloat(28, version >= 3 ? sunAngle : 0.0f);
        target.limit(base + SIZE);
        return target;
    }

    public static void validate(VeilShaderInterface shader) {
        for (var push : shader.pushConstants()) {
            if (push.offset() != 0 || push.size() != SIZE) {
                throw new IllegalArgumentException(
                        "Creator FrameData requires push constants at offset=0 size=32; actual="
                                + push);
            }
            var expected =
                    java.util.List.of(
                            new VeilShaderInterface.BlockMember(
                                    0, org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_UINT32, 32, 4, 1, 1),
                            new VeilShaderInterface.BlockMember(
                                    16, org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_FP32, 32, 4, 1, 1));
            if (!push.members().equals(expected))
                throw new IllegalArgumentException(
                        "Creator FrameData requires uvec4@0, vec4@16; actual=" + push.members());
        }
    }
}
