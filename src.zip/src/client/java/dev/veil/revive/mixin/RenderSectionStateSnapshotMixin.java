package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import dev.veil.revive.client.VeilSectionStateSnapshot;

import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

import org.spongepowered.asm.mixin.Mixin;

@Mixin(RenderSectionRegion.class)
public abstract class RenderSectionStateSnapshotMixin {
    @WrapMethod(method = "getBlockState")
    private BlockState veil$readCapturedState(BlockPos position, Operation<BlockState> original) {
        var value = VeilSectionStateSnapshot.get((RenderSectionRegion) (Object) this, position);
        if (value == null) return original.call(position);
        if (VeilSectionStateSnapshot.verifyingNeeded())
            VeilSectionStateSnapshot.verify(value, original.call(position));
        return value;
    }
}
