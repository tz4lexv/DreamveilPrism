package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.VeilPublicationLockJfrProbe;
import dev.veil.revive.client.VeilPublicationLockTimingAccess;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.locks.ReentrantLock;

@Mixin(SectionRenderDispatcher.class)
public abstract class PublicationLockTimingMixin implements VeilPublicationLockTimingAccess {
    @Unique
    private final VeilPublicationLockJfrProbe veil$publicationTiming =
            new VeilPublicationLockJfrProbe();

    @Inject(method = "<init>", at = @At("RETURN"), require = 1)
    private void veil$timingActive(CallbackInfo callback) {
        ReviveMod.LOGGER.info(
                "Veil publication lock timing ACTIVE: dispatcher={}", veil$publicationTiming.id());
    }

    @Override
    public VeilPublicationLockJfrProbe veil$publicationLockTiming() {
        return veil$publicationTiming;
    }

    @WrapOperation(
            method = {"lock", "dispose"},
            at =
                    @At(
                            value = "INVOKE",
                            target = "Ljava/util/concurrent/locks/ReentrantLock;lock()V"),
            require = 2)
    private void veil$acquire(ReentrantLock lock, Operation<Void> original) {
        veil$publicationTiming.beforeLock();
        original.call(lock);
        veil$publicationTiming.afterLock();
    }

    @WrapOperation(
            method = {"unlock", "dispose"},
            at =
                    @At(
                            value = "INVOKE",
                            target = "Ljava/util/concurrent/locks/ReentrantLock;unlock()V"),
            require = 3)
    private void veil$release(ReentrantLock lock, Operation<Void> original) {
        veil$publicationTiming.beforeUnlock();
        original.call(lock);
        veil$publicationTiming.afterUnlock();
    }
}
