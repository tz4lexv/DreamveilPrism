package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.veil.revive.client.VeilTerrainQuadWriter;

import net.fabricmc.fabric.api.client.renderer.v1.mesh.QuadView;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;

@Pseudo
@Mixin(targets = "net.fabricmc.fabric.impl.client.indigo.renderer.mesh.QuadViewImpl", remap = false)
public abstract class FabricTerrainQuadWriterMixin {
    @WrapMethod(method = "buffer(ILcom/mojang/blaze3d/vertex/VertexConsumer;)V")
    private void veil$writeFabricQuad(
            int overlay, VertexConsumer target, Operation<Void> original) {
        var bytes = VeilTerrainQuadWriter.scratchFor(target);
        if (bytes == null) {
            original.call(overlay, target);
            return;
        }
        var quad = (QuadView) (Object) this;
        for (int corner = 0; corner < 4; corner++)
            VeilTerrainQuadWriter.putVertex(
                    bytes,
                    corner * 28,
                    quad.x(corner),
                    quad.y(corner),
                    quad.z(corner),
                    quad.color(corner),
                    quad.u(corner),
                    quad.v(corner),
                    quad.lightmap(corner));
        if (VeilTerrainQuadWriter.verifyingNeeded())
            VeilTerrainQuadWriter.verify(bytes, reference -> original.call(overlay, reference));
        VeilTerrainQuadWriter.push(target, bytes);
    }
}
