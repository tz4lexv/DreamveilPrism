package dev.veil.revive.client;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.VertexSorting;

import dev.veil.revive.mixin.SectionCompilerStateAccessor;

import net.minecraft.client.renderer.SectionBufferBuilderPack;
import net.minecraft.client.renderer.block.BlockModelLighter;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.core.SectionPos;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Function;

public final class VeilOriginalQuadReplay {
    private static final boolean VERIFY =
            Boolean.getBoolean("veil.verifyOriginalQuadReplay")
                    && VeilOriginalQuadCapture.REQUESTED
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final Semaphore ORACLE = new Semaphore(1);
    private static final LongAdder SECTIONS = new LongAdder(),
            VERTICES = new LongAdder(),
            CHANGED = new LongAdder(),
            RETIRED_READERS = new LongAdder(),
            BLOCK_GROUPS = new LongAdder(),
            MULTI_QUAD_BLOCKS = new LongAdder();

    private VeilOriginalQuadReplay() {}

    static void verify(
            SectionCompilerStateAccessor state,
            SectionPos section,
            RenderSectionRegion region,
            VertexSorting sorting,
            SectionCompiler.Results actual,
            Function<SectionBufferBuilderPack, SectionCompiler.Results> nativeCompile) {
        if (!VERIFY || VERTICES.sum() >= 100000) return;
        var snapshot = ((VeilSectionCompileExtras) (Object) actual).veil$originalQuads();
        if (snapshot == null
                || !snapshot.modelsOnly()
                || !snapshot.attributesCurrent()
                || !ORACLE.tryAcquire()) return;
        try (var lease = snapshot.acquire(section.asLong())) {
            if (lease == null) return;
            try (var referenceBuffers = new SectionBufferBuilderPack()) {
                var reference = nativeCompile.apply(referenceBuffers);
                try (var firstBuffers = new SectionBufferBuilderPack();
                        var secondBuffers = new SectionBufferBuilderPack()) {
                    var first = replay(state, region, sorting, firstBuffers, lease);
                    try {
                        var second = replay(state, region, sorting, secondBuffers, lease);
                        try {
                            if (!snapshot.attributesCurrent() || !lease.current()) {
                                CHANGED.increment();
                                return;
                            }
                            compare(reference, first);
                            compare(actual, first);
                            compare(first, second);
                            long vertices = 0;
                            for (var mesh : first.renderedLayers.values())
                                vertices += mesh.drawState().vertexCount();
                            var originals = lease.quads();
                            long groups = 0, multiple = 0;
                            for (int from = 0; from < originals.size(); ) {
                                int to = VeilOriginalQuadCapture.blockEnd(originals, from);
                                groups++;
                                if (to - from > 1) multiple++;
                                from = to;
                            }
                            BLOCK_GROUPS.add(groups);
                            MULTI_QUAD_BLOCKS.add(multiple);
                            VERTICES.add(vertices);
                            SECTIONS.increment();
                            var detached = snapshot.duplicateForRetirementProbe();
                            if (detached != null)
                                try (detached;
                                        var reader = detached.acquire(section.asLong())) {
                                    if (reader == null) return;
                                    int held = reader.quads().size();
                                    detached.close();
                                    if (reader.current()
                                            || detached.acquire(section.asLong()) != null
                                            || reader.quads().size() != held
                                            || !lease.current())
                                        throw new IllegalStateException(
                                                "Original replay retirement broke active reader");
                                    RETIRED_READERS.increment();
                                }
                        } finally {
                            second.release();
                        }
                    } finally {
                        first.release();
                    }
                } finally {
                    reference.release();
                }
            }
        } finally {
            ORACLE.release();
        }
    }

    private static final LongAdder PREVIOUS_VERTICES = new LongAdder(),
            PREVIOUS_MATCHED = new LongAdder(),
            PREVIOUS_FALLBACK = new LongAdder(),
            PREVIOUS_STALE = new LongAdder();

    static void verifyPrevious(
            SectionCompilerStateAccessor state,
            RenderSectionRegion region,
            VertexSorting sorting,
            SectionCompiler.Results actual) {
        if (!VeilOriginalAttributeWork.VERIFY || PREVIOUS_VERTICES.sum() >= 100000) return;
        var work = VeilOriginalAttributeWork.current();
        var lease = work == null ? null : work.input();
        if (lease == null || !ORACLE.tryAcquire()) return;
        try (var buffers = new SectionBufferBuilderPack()) {
            var originals = lease.quads();
            for (int from = 0; from < originals.size(); ) {
                var first = originals.get(from);
                var position = net.minecraft.core.BlockPos.of(first.position());
                var block = region.getBlockState(position);
                if (first.modelGeometry() == null
                        || first.state() != block
                        || first.model() != state.veil$blockModels().get(block)
                        || !first.modelGeometry()
                                .matches(
                                        VeilModelGeometryStamp.capture(
                                                VeilSectionRenderAdapter.get(),
                                                region,
                                                position,
                                                block,
                                                first.model(),
                                                VeilOwnSectionCompiler.pipeline(state)))) {
                    PREVIOUS_FALLBACK.increment();
                    return;
                }
                from = VeilOriginalQuadCapture.blockEnd(originals, from);
            }
            var previous = replay(state, region, sorting, buffers, lease);
            try {
                if (!work.current()) {
                    PREVIOUS_STALE.increment();
                    return;
                }
                boolean equal =
                        actual.renderedLayers.keySet().equals(previous.renderedLayers.keySet());
                long vertices = 0;
                if (equal)
                    for (var entry : actual.renderedLayers.entrySet()) {
                        var a = entry.getValue();
                        var b = previous.renderedLayers.get(entry.getKey());
                        equal &=
                                a.drawState().equals(b.drawState())
                                        && same(a.vertexBuffer(), b.vertexBuffer())
                                        && same(a.indexBuffer(), b.indexBuffer());
                        vertices += a.drawState().vertexCount();
                    }
                if (equal) {
                    PREVIOUS_MATCHED.increment();
                    PREVIOUS_VERTICES.add(vertices);
                } else PREVIOUS_FALLBACK.increment();
            } finally {
                previous.release();
            }
        } finally {
            ORACLE.release();
        }
    }

    private static SectionCompiler.Results replay(
            SectionCompilerStateAccessor state,
            RenderSectionRegion region,
            VertexSorting sorting,
            SectionBufferBuilderPack buffers,
            VeilOriginalQuadCapture.Lease lease) {
        var result = new SectionCompiler.Results();
        var layers = ChunkSectionLayer.values();
        var started = new BufferBuilder[layers.length];
        Function<ChunkSectionLayer, BufferBuilder> builder =
                layer -> {
                    int index = layer.ordinal();
                    if (started[index] == null)
                        started[index] =
                                new BufferBuilder(
                                        buffers.buffer(layer),
                                        PrimitiveTopology.QUADS,
                                        layer.vertexFormat());
                    return started[index];
                };
        BlockModelLighter.enableCaching();
        try (var renderer =
                        VeilSectionRenderAdapter.get()
                                .open(
                                        state.veil$ambientOcclusion(),
                                        state.veil$cutoutLeaves(),
                                        state.veil$blockColors(),
                                        state.veil$fluidModels(),
                                        builder,
                                        List.of());
                var ignored = VeilOriginalQuadCapture.suspend()) {
            var originals = lease.quads();
            for (int from = 0; from < originals.size(); ) {
                int to = VeilOriginalQuadCapture.blockEnd(originals, from);
                dev.veil.revive.core.terrain.CompileCancellationScope.check();
                if (!renderer.replayBlock(region, originals, from, to))
                    throw new IllegalStateException(
                            "Original block unsupported by replay platform");
                from = to;
            }
            for (var layer : layers) {
                var pending = started[layer.ordinal()];
                if (pending == null) continue;
                var mesh = pending.build();
                if (mesh == null) continue;
                result.renderedLayers.put(layer, mesh);
                if (layer == ChunkSectionLayer.TRANSLUCENT)
                    result.transparencyState = mesh.sortQuads(buffers.buffer(layer), sorting);
            }
            return result;
        } catch (RuntimeException | Error failure) {
            try {
                result.release();
            } catch (RuntimeException | Error cleanup) {
                failure.addSuppressed(cleanup);
            }
            throw failure;
        } finally {
            BlockModelLighter.clearCache();
        }
    }

    private static void compare(SectionCompiler.Results expected, SectionCompiler.Results actual) {
        if (!expected.renderedLayers.keySet().equals(actual.renderedLayers.keySet()))
            throw new IllegalStateException("Original replay layers differ");
        for (var layer : expected.renderedLayers.keySet()) {
            var a = expected.renderedLayers.get(layer);
            var b = actual.renderedLayers.get(layer);
            if (!a.drawState().equals(b.drawState())
                    || !same(a.vertexBuffer(), b.vertexBuffer())
                    || !same(a.indexBuffer(), b.indexBuffer()))
                throw new IllegalStateException(
                        "Original replay mesh differs from native or repeated replay: " + layer);
        }
    }

    private static boolean same(ByteBuffer a, ByteBuffer b) {
        return a == null ? b == null : b != null && a.duplicate().equals(b.duplicate());
    }

    static void requireComplete() {
        if (VeilOriginalAttributeWork.VERIFY) {
            if (PREVIOUS_MATCHED.sum() == 0
                    || PREVIOUS_VERTICES.sum() < 64
                    || VeilOriginalAttributeWork.forcedNotifications() == 0)
                throw new IllegalStateException("Previous installed attribute input not exercised");
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil previous attribute replay: PASS (matched={} vertices={} fallback={} stale={} forced_notifications={})",
                    PREVIOUS_MATCHED.sum(),
                    PREVIOUS_VERTICES.sum(),
                    PREVIOUS_FALLBACK.sum(),
                    PREVIOUS_STALE.sum(),
                    VeilOriginalAttributeWork.forcedNotifications());
        }
        if (!VERIFY) return;
        VeilMeshMetadata.requireAttributeProvenance();
        VeilPackedAttributeProbe.requireComplete();
        if (VERTICES.sum() < 100000 || RETIRED_READERS.sum() == 0 || MULTI_QUAD_BLOCKS.sum() == 0)
            throw new IllegalStateException(
                    "Original quad replay native coverage insufficient: " + VERTICES.sum());
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil original quad replay: PASS (verified_sections={} verified_vertices={} changed={} retired_readers={} block_groups={} multi_quad_blocks={})",
                SECTIONS.sum(),
                VERTICES.sum(),
                CHANGED.sum(),
                RETIRED_READERS.sum(),
                BLOCK_GROUPS.sum(),
                MULTI_QUAD_BLOCKS.sum());
    }
}
