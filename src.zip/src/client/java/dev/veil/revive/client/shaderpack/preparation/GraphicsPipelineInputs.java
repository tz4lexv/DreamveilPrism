package dev.veil.revive.client.shaderpack.preparation;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.revive.client.VeilShaderPack;
import dev.veil.revive.client.graphics.pipelines.GraphicsPipelineState;

import java.util.ArrayList;
import java.util.List;

public final class GraphicsPipelineInputs {
    private GraphicsPipelineInputs() {}

    public static GraphicsPipelineState from(
            VeilShaderPack.PipelineState state,
            VeilShaderPack.Geometry geometry,
            List<VeilShaderPack.ColorAttachment> colors,
            VeilShaderPack.DepthAttachment depth) {
        var raster = state.raster();
        var mappedRaster =
                new GraphicsPipelineState.Raster(
                        raster.depthClamp(),
                        raster.rasterizerDiscard(),
                        polygonMode(raster.polygonMode()),
                        cullMode(raster.cullMode()),
                        raster.frontFace() == VeilShaderPack.FrontFace.CLOCKWISE
                                ? VK_FRONT_FACE_CLOCKWISE
                                : VK_FRONT_FACE_COUNTER_CLOCKWISE,
                        raster.depthBias(),
                        raster.depthBiasConstant(),
                        raster.depthBiasClamp(),
                        raster.depthBiasSlope(),
                        raster.lineWidth());
        var mappedDepth =
                new GraphicsPipelineState.Depth(
                        depth != null && depth.test(),
                        depth != null && depth.write(),
                        depth == null ? VK_COMPARE_OP_ALWAYS : compare(depth.compare()));
        var stencil = state.stencil();
        var mappedStencil =
                new GraphicsPipelineState.Stencil(
                        stencil.enabled(), face(stencil.front()), face(stencil.back()));
        var mappedColors = new ArrayList<GraphicsPipelineState.ColorBlend>(colors.size());
        for (var color : colors) {
            var blend = color.blend();
            mappedColors.add(
                    new GraphicsPipelineState.ColorBlend(
                            blend.enabled(),
                            blendFactor(blend.srcColor()),
                            blendFactor(blend.dstColor()),
                            blendOp(blend.colorOp()),
                            blendFactor(blend.srcAlpha()),
                            blendFactor(blend.dstAlpha()),
                            blendOp(blend.alphaOp()),
                            colorMask(color.writeMask())));
        }
        return new GraphicsPipelineState(
                topology(state.topology()),
                state.patchControlPoints(),
                geometry.fluid(),
                mappedRaster,
                mappedDepth,
                mappedStencil,
                mappedColors,
                state.primitiveRestart());
    }

    private static GraphicsPipelineState.StencilFace face(VeilShaderPack.StencilFace face) {
        return new GraphicsPipelineState.StencilFace(
                stencilOp(face.fail()),
                stencilOp(face.pass()),
                stencilOp(face.depthFail()),
                compare(face.compare()),
                face.compareMask(),
                face.writeMask(),
                face.reference());
    }

    private static int topology(VeilShaderPack.Topology value) {
        return switch (value) {
            case POINT_LIST -> VK_PRIMITIVE_TOPOLOGY_POINT_LIST;
            case LINE_LIST -> VK_PRIMITIVE_TOPOLOGY_LINE_LIST;
            case LINE_STRIP -> VK_PRIMITIVE_TOPOLOGY_LINE_STRIP;
            case TRIANGLE_LIST -> VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
            case TRIANGLE_STRIP -> VK_PRIMITIVE_TOPOLOGY_TRIANGLE_STRIP;
            case PATCH_LIST -> VK_PRIMITIVE_TOPOLOGY_PATCH_LIST;
        };
    }

    private static int polygonMode(VeilShaderPack.PolygonMode value) {
        return switch (value) {
            case FILL -> VK_POLYGON_MODE_FILL;
            case LINE -> VK_POLYGON_MODE_LINE;
            case POINT -> VK_POLYGON_MODE_POINT;
        };
    }

    private static int cullMode(VeilShaderPack.CullMode value) {
        return switch (value) {
            case NONE -> VK_CULL_MODE_NONE;
            case FRONT -> VK_CULL_MODE_FRONT_BIT;
            case BACK -> VK_CULL_MODE_BACK_BIT;
            case FRONT_AND_BACK -> VK_CULL_MODE_FRONT_AND_BACK;
        };
    }

    private static int stencilOp(VeilShaderPack.StencilOp value) {
        return switch (value) {
            case KEEP -> VK_STENCIL_OP_KEEP;
            case ZERO -> VK_STENCIL_OP_ZERO;
            case REPLACE -> VK_STENCIL_OP_REPLACE;
            case INCREMENT_CLAMP -> VK_STENCIL_OP_INCREMENT_AND_CLAMP;
            case DECREMENT_CLAMP -> VK_STENCIL_OP_DECREMENT_AND_CLAMP;
            case INVERT -> VK_STENCIL_OP_INVERT;
            case INCREMENT_WRAP -> VK_STENCIL_OP_INCREMENT_AND_WRAP;
            case DECREMENT_WRAP -> VK_STENCIL_OP_DECREMENT_AND_WRAP;
        };
    }

    private static int colorMask(java.util.Set<VeilShaderPack.ColorChannel> channels) {
        int mask = 0;
        if (channels.contains(VeilShaderPack.ColorChannel.R)) mask |= VK_COLOR_COMPONENT_R_BIT;
        if (channels.contains(VeilShaderPack.ColorChannel.G)) mask |= VK_COLOR_COMPONENT_G_BIT;
        if (channels.contains(VeilShaderPack.ColorChannel.B)) mask |= VK_COLOR_COMPONENT_B_BIT;
        if (channels.contains(VeilShaderPack.ColorChannel.A)) mask |= VK_COLOR_COMPONENT_A_BIT;
        return mask;
    }

    private static int compare(VeilShaderPack.CompareOp value) {
        return switch (value) {
            case NEVER -> VK_COMPARE_OP_NEVER;
            case LESS -> VK_COMPARE_OP_LESS;
            case EQUAL -> VK_COMPARE_OP_EQUAL;
            case LESS_OR_EQUAL -> VK_COMPARE_OP_LESS_OR_EQUAL;
            case GREATER -> VK_COMPARE_OP_GREATER;
            case NOT_EQUAL -> VK_COMPARE_OP_NOT_EQUAL;
            case GREATER_OR_EQUAL -> VK_COMPARE_OP_GREATER_OR_EQUAL;
            case ALWAYS -> VK_COMPARE_OP_ALWAYS;
        };
    }

    private static int blendFactor(VeilShaderPack.BlendFactor value) {
        return switch (value) {
            case ZERO -> VK_BLEND_FACTOR_ZERO;
            case ONE -> VK_BLEND_FACTOR_ONE;
            case SRC_COLOR -> VK_BLEND_FACTOR_SRC_COLOR;
            case ONE_MINUS_SRC_COLOR -> VK_BLEND_FACTOR_ONE_MINUS_SRC_COLOR;
            case DST_COLOR -> VK_BLEND_FACTOR_DST_COLOR;
            case ONE_MINUS_DST_COLOR -> VK_BLEND_FACTOR_ONE_MINUS_DST_COLOR;
            case SRC_ALPHA -> VK_BLEND_FACTOR_SRC_ALPHA;
            case ONE_MINUS_SRC_ALPHA -> VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
            case DST_ALPHA -> VK_BLEND_FACTOR_DST_ALPHA;
            case ONE_MINUS_DST_ALPHA -> VK_BLEND_FACTOR_ONE_MINUS_DST_ALPHA;
        };
    }

    private static int blendOp(VeilShaderPack.BlendOp value) {
        return switch (value) {
            case ADD -> VK_BLEND_OP_ADD;
            case SUBTRACT -> VK_BLEND_OP_SUBTRACT;
            case REVERSE_SUBTRACT -> VK_BLEND_OP_REVERSE_SUBTRACT;
            case MIN -> VK_BLEND_OP_MIN;
            case MAX -> VK_BLEND_OP_MAX;
        };
    }
}
