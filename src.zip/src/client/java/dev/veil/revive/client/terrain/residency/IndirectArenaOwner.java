package dev.veil.revive.client.terrain.residency;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.StagingBuffer;

import dev.veil.revive.client.terrain.indirect.TerrainBatchStorage;

import java.nio.ByteBuffer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public final class IndirectArenaOwner<T extends TerrainBatchStorage> implements AutoCloseable {

    private final Supplier<Budget> budgets;
    private final IntSupplier alignmentQuery;
    private final IntFunction<StagingBuffer> stagingFactory;
    private final ArenaFactory<T> arenaFactory;

    public IndirectArenaOwner(
            Supplier<Budget> budgets,
            IntSupplier alignmentQuery,
            IntFunction<StagingBuffer> stagingFactory,
            ArenaFactory<T> arenaFactory) {
        this.budgets = budgets;
        this.alignmentQuery = alignmentQuery;
        this.stagingFactory = stagingFactory;
        this.arenaFactory = arenaFactory;
    }

    public record Budget(int heapBytes, int uploadBytes) {}

    @FunctionalInterface
    public interface ArenaFactory<T> {
        ManagedGpuArena<T> create(int heapBytes, int alignment, StagingBuffer staging);
    }

    private StagingBuffer staging;
    private ManagedGpuArena<T> arena;
    private boolean pending;
    private long uploadedBytes;
    private long batches;
    private long flushes;
    private long allocationRetries;
    private long allocationFailures;
    private int storageAlignment;

    public int storageAlignment() {
        if (storageAlignment == 0) {
            storageAlignment = alignmentQuery.getAsInt();
        }
        return storageAlignment;
    }

    public void stage(T batch, ByteBuffer data) {
        ensure();
        int bytes = data.remaining();
        if (!arena.addAllocation(batch, this::bind, data)) {
            allocationRetries++;
            flush();
            if (!arena.addAllocation(batch, this::bind, data)) {
                allocationFailures++;
                throw new IllegalStateException(
                        "Veil staging/arena path cannot accept an indirect batch of "
                                + bytes
                                + " bytes");
            }
        }
        pending = true;
        uploadedBytes += bytes;
        batches++;
    }

    private void bind(T batch) {
        var allocation = arena.getAllocation(batch);
        if (allocation == null)
            throw new IllegalStateException("Missing Veil GPU arena allocation");
        batch.bind(arena.getGpuBuffer(allocation), allocation.offset());
    }

    public void flush() {
        if (arena == null) return;
        if (!pending) {
            arena.maintain();
            return;
        }
        try (var upload = staging.startUploading(RenderSystem.getDevice().createCommandEncoder())) {
            arena.uploadStagedAllocations(RenderSystem.getDevice(), upload);
        }
        pending = false;
        flushes++;
        arena.maintain();
    }

    public void remove(T batch) {
        if (arena != null) arena.removeAllocation(batch);
        batch.unbind();
    }

    private void ensure() {
        if (arena != null) return;
        Budget budget = budgets.get();
        staging = stagingFactory.apply(budget.uploadBytes());
        arena = arenaFactory.create(budget.heapBytes(), storageAlignment(), staging);
    }

    public String telemetry() {
        return (arena == null ? "" : arena.telemetry())
                + "gpu_arena_uploaded_bytes_total="
                + uploadedBytes
                + "\ngpu_arena_batches_total="
                + batches
                + "\nupload_batch_submissions_total="
                + flushes
                + "\ngpu_arena_allocation_retries_total="
                + allocationRetries
                + "\ngpu_arena_allocation_failures_total="
                + allocationFailures
                + "\npersistent_upload_ring="
                + (staging != null)
                + "\n";
    }

    @Override
    public void close() {
        if (arena != null) {
            arena.close();
            arena = null;
        }
        if (staging != null) {
            staging.close();
            staging = null;
        }
        pending = false;
        storageAlignment = 0;
    }
}
