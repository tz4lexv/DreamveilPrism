package dev.veil.revive.client.ui;

import dev.veil.revive.client.VeilAsyncEntityOcclusion;
import dev.veil.revive.client.VeilIndirectTerrain;
import dev.veil.revive.client.VeilShaderService;
import dev.veil.revive.client.VeilTerrainDrawBridge;
import dev.veil.revive.client.VeilVideoConfig;
import dev.veil.revive.mixin.VeilOptionAccessor;

import net.minecraft.client.*;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.narration.*;
import net.minecraft.client.gui.screens.*;
import net.minecraft.client.input.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;

import java.util.*;
import java.util.function.*;

public class VeilSettingsScreen extends Screen {
    public static final String COFFEE_URL = "https://ko-fi.com/tz4lexv";
    private static final int ACCENT = 0xff98ede0, WHITE = 0xffedf1f5, MUTED = 0xffa8b4bd;
    private final Screen parent;
    private final BooleanSupplier raySceneRequested;
    private final boolean spanish;
    private final String[] tabs;
    private final List<Setting> settings = new ArrayList<>();
    private final List<Row> rows = new ArrayList<>();
    private int tab, scroll, top, bottom, column;
    private EditBox search;
    private String query = "", status = "";
    private FlatButton apply, undo;
    private VeilShaderPanel shaders;

    public VeilSettingsScreen(Screen parent, BooleanSupplier raySceneRequested) {
        super(Component.literal(title()));
        this.parent = parent;
        this.raySceneRequested = raySceneRequested;
        spanish =
                Minecraft.getInstance()
                        .getLanguageManager()
                        .getSelected()
                        .toLowerCase(Locale.ROOT)
                        .startsWith("es_");
        tabs =
                spanish
                        ? new String[] {
                            "General",
                            "Calidad",
                            "Rendimiento",
                            "Avanzado",
                            "Animaciones",
                            "Partículas",
                            "Detalles",
                            "Extras",
                            "Shaders"
                        }
                        : new String[] {
                            "General",
                            "Quality",
                            "Performance",
                            "Advanced",
                            "Animations",
                            "Particles",
                            "Details",
                            "Extras",
                            "Shaders"
                        };
        catalog(Minecraft.getInstance().options);
    }

    private static String title() {
        return Minecraft.getInstance()
                        .getLanguageManager()
                        .getSelected()
                        .toLowerCase(Locale.ROOT)
                        .startsWith("es_")
                ? "Veil · Ajustes de vídeo"
                : "Veil · Video Settings";
    }

    private String tr(String es, String en) {
        return spanish ? es : en;
    }

    private void nativeOption(int tab, OptionInstance<?> option, String description) {
        setting(tab, option, null, description);
    }

    @SuppressWarnings("unchecked")
    private void nativeOption(int tab, OptionInstance<?> option, String title, String description) {
        settings.add(new Setting(tab, (OptionInstance<Object>) option, null, title, description));
    }

    @SuppressWarnings("unchecked")
    private void setting(int tab, OptionInstance<?> option, String key, String description) {
        settings.add(new Setting(tab, (OptionInstance<Object>) option, key, description));
    }

    private void toggle(int tab, String key, String title, String description) {
        toggle(tab, key, title, true, description);
    }

    private void toggle(int tab, String key, String title, boolean fallback, String description) {
        var option = OptionInstance.createBoolean(title, VeilVideoConfig.flag(key, fallback));
        setting(tab, option, key, description);
    }

    private void integer(
            int tab, String key, String title, int fallback, int min, int max, String description) {
        var option =
                new OptionInstance<Integer>(
                        title,
                        OptionInstance.noTooltip(),
                        (c, v) -> Component.literal(title + ": " + v),
                        new OptionInstance.IntRange(min, max),
                        VeilVideoConfig.number(key, fallback, min, max),
                        OptionInstance.NO_ACTION);
        setting(tab, option, key, description);
    }

    private void catalog(Options o) {
        nativeOption(
                0,
                o.renderDistance(),
                tr(
                        "Distancia de terreno cargado y dibujado. Más chunks cuestan CPU, memoria y GPU. La fusión exacta de Veil reduce quads compatibles del terreno ya cargado.",
                        "Distance of loaded and rendered terrain. More chunks use CPU, memory and GPU. Veil exact merging reduces compatible quads in already-loaded terrain."));
        nativeOption(
                0,
                o.simulationDistance(),
                tr(
                        "Distancia de simulación de entidades y bloques. Reducirla modifica hasta dónde se actualiza el mundo, no la resolución.",
                        "Entity and block simulation distance. Reducing it changes how far the world is updated, not its resolution."));
        nativeOption(
                0,
                o.gamma(),
                tr(
                        "Brillo del juego. No cambia la resolución ni la distancia.",
                        "Game brightness. It does not change resolution or render distance."));
        nativeOption(
                0,
                o.fov(),
                tr(
                        "Campo de visión. Un ángulo mayor muestra más terreno en pantalla.",
                        "Field of view. A wider angle shows more terrain on screen."));
        nativeOption(
                0,
                o.guiScale(),
                tr(
                        "Tamaño de la interfaz. Se reorganiza al aplicar el cambio.",
                        "Interface size. The screen is rearranged when the change is applied."));
        nativeOption(
                0,
                o.fullscreen(),
                tr("Activa la pantalla completa al aplicar.", "Enables fullscreen when applied."));
        nativeOption(
                0,
                o.exclusiveFullscreen(),
                tr(
                        "Modo de pantalla completa exclusiva. Su comportamiento depende del sistema y del backend.",
                        "Exclusive fullscreen mode. Its behavior depends on the system and graphics backend."));
        var window = Minecraft.getInstance().getWindow();
        var monitor = window.findBestMonitor();
        if (monitor != null) {
            int value =
                    window.getPreferredFullscreenVideoMode().map(monitor::indexOfMode).orElse(-1);
            String fullscreenResolution =
                    tr("Resolución en pantalla completa", "Fullscreen Resolution");
            nativeOption(
                    0,
                    new OptionInstance<Integer>(
                            fullscreenResolution,
                            OptionInstance.noTooltip(),
                            (c, v) ->
                                    Component.literal(
                                            v == -1
                                                    ? tr("Actual", "Current")
                                                    : monitor.mode(v).toString()),
                            new OptionInstance.IntRange(-1, monitor.modeCount() - 1),
                            value,
                            v ->
                                    window.setPreferredFullscreenVideoMode(
                                            v == -1
                                                    ? Optional.empty()
                                                    : Optional.of(monitor.mode(v)))),
                    tr(
                            "Selecciona un modo del monitor para pantalla completa. No se cambia automáticamente para ganar FPS.",
                            "Selects a monitor mode for fullscreen. Veil never changes it automatically to gain FPS."));
        }
        nativeOption(
                0,
                o.enableVsync(),
                tr(
                        "Sincroniza los fotogramas con el monitor. Puede limitar los FPS y evitar cortes en la imagen.",
                        "Synchronizes frames with the monitor. It can limit FPS and prevent screen tearing."));
        nativeOption(
                0,
                o.framerateLimit(),
                tr(
                        "Límite de FPS. Un límite razonable puede reducir consumo y dejar margen para cargar chunks.",
                        "FPS limit. A reasonable limit can reduce power use and leave headroom for chunk loading."));
        nativeOption(
                0,
                o.inactivityFpsLimit(),
                tr(
                        "Comportamiento del límite de FPS al estar inactivo o con la ventana en segundo plano.",
                        "FPS limit behavior while idle or when the window is in the background."));
        nativeOption(
                0,
                o.bobView(),
                tr("Balanceo de la cámara al caminar.", "Camera bobbing while walking."));
        nativeOption(
                1,
                o.ambientOcclusion(),
                tr(
                        "Iluminación suave en los bordes de los bloques. Desactivarla cambia el aspecto del mundo.",
                        "Soft lighting around block edges. Disabling it changes the appearance of the world."));
        nativeOption(
                1,
                o.cloudStatus(),
                tr("Calidad y visibilidad de las nubes.", "Cloud quality and visibility."));
        nativeOption(
                1,
                o.cutoutLeaves(),
                tr(
                        "Aspecto de las hojas. Cambiarlo reconstruye el terreno mediante Minecraft.",
                        "Leaf appearance. Changing it makes Minecraft rebuild terrain."));
        nativeOption(
                1,
                o.improvedTransparency(),
                tr(
                        "Transparencia mejorada. Puede aumentar el coste de renderizado. Se respeta la comprobación de compatibilidad gráfica de Minecraft.",
                        "Improved transparency. It can increase rendering cost. Minecraft's graphics compatibility check is respected."));
        nativeOption(
                1,
                o.biomeBlendRadius(),
                tr(
                        "Suavizado del color entre biomas. Más radio implica más trabajo al reconstruir el terreno.",
                        "Color blending between biomes. A larger radius requires more work while rebuilding terrain."));
        nativeOption(
                1,
                o.entityDistanceScaling(),
                tr(
                        "Distancia a la que se ven entidades. Reducirla hace desaparecer entidades lejanas.",
                        "Distance at which entities remain visible. Reducing it hides distant entities."));
        nativeOption(
                1,
                o.entityShadows(),
                tr("Sombras vanilla de entidades", "Vanilla entity shadows"),
                tr(
                        "Activa las sombras vanilla bajo las entidades. Las sombras del shader se controlan desde sus propios ajustes.",
                        "Enables vanilla shadows below entities. Shader shadows use their own settings."));
        nativeOption(
                1,
                o.mipmapLevels(),
                tr(
                        "Mips de texturas lejanas. Se recargan las texturas al aplicar un cambio.",
                        "Mip levels for distant textures. Textures reload when this setting is applied."));
        nativeOption(
                1,
                o.textureFiltering(),
                tr(
                        "Método de filtrado de texturas. Conserva los métodos soportados por Minecraft.",
                        "Texture filtering method. Minecraft's supported methods remain available."));
        nativeOption(
                1,
                o.maxAnisotropyBit(),
                tr(
                        "Nivel anisotrópico; solo tiene efecto cuando el filtrado anisotrópico está seleccionado.",
                        "Anisotropic level; it only applies when anisotropic filtering is selected."));
        toggle(
                2,
                "renderer.enabled",
                tr("Optimizaciones de Veil", "Veil Optimizations"),
                tr(
                        "Interruptor general de las optimizaciones. No cambia tus preferencias visuales de partículas o cielo.",
                        "Master switch for Veil optimizations. It does not change your particle or sky preferences."));
        toggle(
                2,
                "renderer.shaderPackEfficiency",
                tr("Eficiencia con shader packs", "Shader Pack Efficiency"),
                tr(
                        "Cuando los shaders superan el presupuesto del frame, modera recompilaciones y ráfagas de luz. Con margen disponible conserva el ritmo normal. La protección de compatibilidad permanece activa aunque apagues esta opción.",
                        "When shaders exceed the frame budget, moderates recompiles and light bursts. Normal throughput is retained when frame headroom is available. Compatibility protection remains active even if this option is disabled."));
        toggle(
                2,
                "renderer.shaderGeometryReduction",
                tr("Reducción geométrica exacta", "Exact Geometry Reduction"),
                tr(
                        "Elimina antes del chunk buffer quads opacos/cutout byte-idénticos y geometría de área cero dentro del mismo bloque, después de tint, AO y luz. No fusiona bloques distintos ni transparencia, por lo que conserva blockId, midBlock, tangentes, lightmap y materiales usados por shader packs. Se activa automáticamente cuando el renderizador instalado es compatible.",
                        "Removes byte-identical opaque/cutout quads and zero-area geometry inside the same block before the chunk buffer, after tint, AO, and lighting. It never merges different blocks or translucent geometry, preserving blockId, midBlock, tangents, lightmap, and materials used by shader packs. Activates automatically when the installed renderer is compatible."));
        toggle(
                2,
                "renderer.mdi",
                "Multi-Draw Indirect (MDI)",
                tr(
                        "Agrupa dibujos de terreno en Vulkan. HZB y el LOD actual necesitan esta ruta. Requiere capacidades compatibles de la GPU.",
                        "Batches terrain draws in Vulkan. HZB and the current LOD path require it. Compatible GPU features are required."));
        toggle(
                2,
                "renderer.hzb",
                tr("Oclusión HZB en GPU", "GPU HZB Occlusion"),
                tr(
                        "Descarta mallas ocultas usando profundidad del fotograma actual. Requiere MDI. Su coste puede no compensar en escenas abiertas.",
                        "Rejects hidden meshes using current-frame depth. Requires MDI. Its cost may outweigh the benefit in open scenes."));
        toggle(
                2,
                "renderer.compaction",
                tr("Compactación indirecta GPU", "GPU Indirect Compaction"),
                tr(
                        "Escribe únicamente comandos visibles y usa DrawIndirectCount. Reduce el trabajo del driver sin cambiar la imagen.",
                        "Writes only visible commands and uses DrawIndirectCount. Reduces driver work without changing the image."));
        toggle(
                2,
                "renderer.hierarchical",
                tr("Frustum + HZB jerárquico", "Hierarchical Frustum + HZB"),
                tr(
                        "Descarta primero AABB de regiones contra el frustum y después usa HZB; baja a sección solo cuando la región sobrevive. El autotune evita duplicar trabajo si el Octree de Minecraft ya filtró todo.",
                        "Rejects region AABBs against the frustum before HZB and descends to sections only when the region survives. Autotune avoids duplicate work when Minecraft's Octree already filtered everything."));
        toggle(
                2,
                "renderer.entityCulling",
                tr("Culling jerárquico de entidades", "Hierarchical Entity Culling"),
                tr(
                        "Rechaza primero por distancia exacta y, cuando la vista es estable, reutiliza el árbol Morton de secciones visibles para evitar extraer y enviar entidades completamente fuera del conjunto visible. Glowing, nametags, pasajeros, cajas grandes y vistas cambiantes conservan el path de Minecraft.",
                        "Rejects by exact distance first and, while the view is stable, reuses the visible-section Morton tree to avoid extracting and submitting entities completely outside the visible set. Glowing entities, nametags, passengers, large boxes, and changing views retain Minecraft's path."));
        toggle(
                2,
                "renderer.asyncEntityOcclusion",
                tr("Oclusión asíncrona de entidades", "Async Entity Occlusion"),
                tr(
                        "Evita extraer mobs y contenedores tapados completamente por paredes opacas. Los cálculos usan un hilo secundario; cambios de bloques o movimiento invalidan los resultados. No cambia la simulación.",
                        "Skips extraction of mobs and containers fully covered by opaque walls. Calculations run on a worker; block changes and movement invalidate results. Simulation is unchanged."));
        toggle(
                1,
                "renderer.leafCulling",
                tr("Eliminar caras profundas de hojas", "Cull Deep Leaf Faces"),
                false,
                tr(
                        "Reduce caras dentro del follaje conservando las capas exteriores elegidas. Puede cambiar su transparencia. Desactivado conserva la imagen original; al cambiar se reconstruye el terreno.",
                        "Reduces faces inside foliage while preserving the selected outer layers. This may change transparency. Disabled preserves the original image; changing it rebuilds terrain."));
        integer(
                1,
                "renderer.leafLayers",
                tr("Capas exteriores de hojas", "Outer Leaf Layers"),
                2,
                1,
                4,
                tr(
                        "Capas que conserva el culling de hojas. Dos equilibra densidad y geometría; cuatro conserva más follaje.",
                        "Layers retained by leaf culling. Two balances density and geometry; four preserves more foliage."));
        toggle(
                2,
                "renderer.entityModelFastPath",
                tr("Transformaciones rápidas de modelos", "Fast Entity Model Transforms"),
                tr(
                        "Aplica translation, rotación ZYX y escala de ModelPart directamente sobre las matrices de pose/normal, evitando trabajo intermedio por parte. No cambia animaciones, huesos ni geometría.",
                        "Applies ModelPart translation, ZYX rotation, and scale directly to the pose/normal matrices, avoiding intermediate work per part. Animations, bones, and geometry are unchanged."));
        toggle(
                2,
                "renderer.entityCubeFastPath",
                tr("Cubos de entidades rápidos", "Fast Entity Cubes"),
                tr(
                        "Reutiliza las 8 esquinas únicas de cada cubo de ModelPart en lugar de transformar hasta 24 vértices repetidos. Conserva VertexConsumer, UV, color, luz, overlay y normales; cubos planos y subclases personalizadas usan el path de Minecraft.",
                        "Reuses the 8 unique corners of each ModelPart cube instead of transforming up to 24 repeated vertices. VertexConsumer, UVs, color, light, overlay, and normals are preserved; planar cubes and custom subclasses keep Minecraft's path."));
        toggle(
                2,
                "renderer.entityShadowFastPath",
                tr("Sombras de entidades rápidas", "Fast Entity Shadows"),
                tr(
                        "Cuando el consumer de sombras es un BufferBuilder directo, ensambla los cuatro vértices ENTITY de cada ShadowPiece en memoria temporal y los copia en bloque. Consumers personalizados o formatos incompatibles conservan el path de Minecraft.",
                        "When the shadow consumer is a direct BufferBuilder, assembles all four ENTITY vertices for each ShadowPiece in temporary memory and copies them in bulk. Custom consumers or incompatible formats keep Minecraft's path."));
        toggle(
                2,
                "renderer.lightPipeline",
                tr("Pipeline de iluminación vanilla barato", "Cheap Vanilla Lighting Pipeline"),
                tr(
                        "Mantiene las reglas vanilla de block light y sky light, pero Veil limita ráfagas de trabajo cliente, deduplica estados idénticos del lightmap y habilita caches exactos de sombras. No añade GI ni cambia la resolución.",
                        "Keeps vanilla block-light and sky-light rules while Veil bounds client lighting bursts, deduplicates identical lightmap states, and enables exact shadow caches. It adds no GI and does not change render resolution."));
        toggle(
                2,
                "renderer.lightUpdateBudget",
                tr("Presupuesto adaptativo de luz", "Adaptive Light Update Budget"),
                tr(
                        "Evita que una cola grande de actualizaciones de luz se vacíe completa en un solo frame. Conserva orden FIFO y progreso mínimo, y aumenta el presupuesto cuando crece el backlog.",
                        "Prevents a large client light-update queue from draining completely in one frame. FIFO order and minimum progress are preserved, while the budget rises with backlog."));

        toggle(
                2,
                "renderer.lightCompileCache",
                tr("Cache de luz durante meshing", "Meshing Light Coordinate Cache"),
                tr(
                        "Memoriza las coordenadas block/sky light exactas sólo durante una compilación de section. Las caras vecinas suelen consultar las mismas posiciones; el cache se borra al terminar el compile y nunca reutiliza luz entre rebuilds.",
                        "Memoizes exact packed block/sky-light coordinates only for the duration of one section compile. Neighboring faces often query the same positions; the cache is cleared when the compile ends and never reuses lighting across rebuilds."));
        toggle(
                2,
                "renderer.shadowReceiverCache",
                tr("Cache de receptores de sombra", "Shadow Receiver Cache"),
                tr(
                        "Reutiliza shape, colisión y elegibilidad del bloque que recibe la sombra mientras su revisión de section no cambie. La geometría se invalida por revisión y el brillo se reutiliza entre frames hasta que cambie la luz o el oscurecimiento del cielo; alpha sigue siendo vanilla y dinámico.",
                        "Reuses the receiving block's shape, collision, and eligibility while its section revision is unchanged. Geometry is revision-keyed and brightness is reused across frames until lighting or sky darkening changes; alpha remains vanilla and dynamic."));
        toggle(
                2,
                "renderer.lightmapCache",
                tr("Deduplicar lightmap idéntico", "Deduplicate Identical Lightmap"),
                tr(
                        "Omite únicamente renders del lightmap cuyo estado completo sea bit-a-bit idéntico al último estado renderizado. Si cambia cualquier factor vanilla, se renderiza normalmente.",
                        "Skips only lightmap renders whose complete state is bit-for-bit identical to the last rendered state. Any vanilla factor change renders normally."));
        toggle(
                2,
                "simulation.aiLod",
                tr("Cadencia de IA lejana (agresivo)", "Far AI Cadence (Aggressive)"),
                false,
                tr(
                        "Opcional: mantiene Brain.tick completo hasta 48 bloques, lo ejecuta a 10 Hz entre 48–96 y a 5 Hz más lejos. Sólo afecta aldeanos y puede cambiar su tiempo de reacción lejano; física, render y movimiento no se omiten.",
                        "Optional: keeps full Brain.tick within 48 blocks, runs it at 10 Hz from 48–96, and 5 Hz farther away. Villagers only; distant reaction timing can change. Physics, rendering, and movement are not skipped."));
        toggle(
                2,
                "renderer.rebuildCoalescing",
                tr("Fusionar rebuilds obsoletos", "Coalesce Obsolete Rebuilds"),
                tr(
                        "Impide que una compilación cancelada publique o suba un estado anterior de la sección.",
                        "Prevents a cancelled compile from publishing or uploading an older section state."));
        toggle(
                2,
                "renderer.rebuildBudget",
                tr("Presupuesto adaptativo de rebuilds", "Adaptive Rebuild Budget"),
                true,
                tr(
                        "Limita compiles nuevos y recompilaciones usando coste CPU, bytes de malla y presión del frame aprendidos. Siempre deja progresar trabajo y prioriza de forma acotada las secciones cercanas o visibles.",
                        "Budgets first compiles and recompiles using learned CPU cost, mesh bytes, and frame pressure. It always guarantees progress and gives bounded priority to near or visible sections."));
        toggle(
                2,
                "renderer.lod",
                tr("Reducción exacta de geometría", "Exact Geometry Reduction"),
                tr(
                        "Fusiona agresivamente caras coplanares compatibles sin cambiar la silueta ni estirar texturas. V38 admite caras sub-bloque y gradientes afines exactos de color/AO; cambios de lightmap siguen siendo una barrera de seguridad. Vulkan conserva el mesh original cuando la sustitución no compensa.",
                        "Aggressively merges compatible coplanar faces without changing silhouettes or stretching textures. V38 supports sub-block faces and exact affine color/AO gradients; lightmap changes remain a safety barrier. Vulkan keeps the original mesh when replacement does not pay off."));
        toggle(
                2,
                "renderer.lodCache",
                tr("Caché de geometría exacta", "Exact Geometry Cache"),
                tr(
                        "Reutiliza mallas fusionadas idénticas en memoria y disco. La escritura se realiza en segundo plano.",
                        "Reuses identical merged meshes in memory and on disk. Writes run in the background."));
        toggle(
                2,
                "renderer.lightOnlyLod",
                tr("Reutilizar LOD al cambiar solo la luz", "Reuse LOD on Light-only Updates"),
                tr(
                        "Si la geometría es idéntica y ambos canales de luz cambian uniformemente, actualiza solo los atributos de luz del LOD. En cualquier otro caso reconstruye la malla.",
                        "When geometry matches and both light channels change uniformly, updates only LOD light attributes. Other changes rebuild the mesh."));
        toggle(
                2,
                "renderer.directionalBuckets",
                tr("Descartar caras LOD opuestas", "Cull Opposite LOD Faces"),
                tr(
                        "Agrupa caras de mallas grandes y evita enviar al GPU las que miran lejos de la cámara. Conserva las caras no clasificadas y un margen para evitar huecos al moverse.",
                        "Groups faces in large meshes and skips GPU draws facing away from the camera. Unclassified faces and a movement guard remain visible."));
        toggle(
                2,
                "renderer.voxelCellCulling",
                tr("Celdas lejanas para HZB", "Far Voxel Cells for HZB"),
                tr(
                        "Divide mallas LOD lejanas y grandes en celdas de 8 bloques para descartar por oclusión partes ocultas. Conserva exactamente los vértices y texturas; requiere HZB activo.",
                        "Splits large far LOD meshes into 8-block cells so HZB can reject hidden parts. Vertices and textures stay exact; requires HZB."));
        toggle(
                2,
                "renderer.faceCache",
                tr("Reutilizar visibilidad de caras", "Reuse Face Visibility"),
                tr(
                        "Memoriza decisiones exactas de caras durante la construcción de cada sección. No desactiva la oclusión original de Minecraft.",
                        "Caches exact face decisions while building each section. Minecraft's original occlusion remains enabled."));
        toggle(
                2,
                "renderer.binds",
                tr("Reutilizar enlaces Vulkan", "Reuse Vulkan Bindings"),
                tr(
                        "Evita repetir enlaces idénticos de vértices e índices dentro del mismo pase.",
                        "Avoids repeating identical vertex and index bindings in the same pass."));
        toggle(
                2,
                "renderer.uniforms",
                tr("Reutilizar uniformes y pipelines", "Reuse Uniforms and Pipelines"),
                tr(
                        "Evita enlaces de uniformes y pipelines idénticos dentro del mismo pase de Vulkan.",
                        "Avoids identical uniform and pipeline bindings in the same Vulkan pass."));
        toggle(
                2,
                "renderer.hzbAutotune",
                tr("Autotune visibilidad", "Visibility Autotuning"),
                tr(
                        "Compara el coste GPU real de HZB y del frustum/compaction contra el ahorro estimado. Puede bajar hasta MDI directo cuando el culling cuesta más que dibujar, con histéresis y probes periódicos.",
                        "Compares measured GPU cost of HZB and frustum/compaction against estimated savings. It can fall back to direct MDI when culling costs more than drawing, with hysteresis and periodic probes."));
        integer(
                2,
                "renderer.mdiBatchSize",
                tr("Tamaño máximo MDI", "Maximum MDI Batch Size"),
                defaultMdiBatchSize(),
                256,
                4096,
                tr(
                        "Límite máximo de secciones por lote indirecto. Veil usa una tabla global de secciones, por lo que puede superar el antiguo límite de 512.",
                        "Maximum sections per indirect batch. Veil uses a global section table, so it can exceed the old 512 limit."));
        integer(
                3,
                "renderer.gpuArenaMiB",
                tr("Arena GPU de Veil (MiB)", "Veil GPU Arena (MiB)"),
                defaultGpuArenaMiB(),
                8,
                128,
                tr(
                        "Memoria subasignada para comandos, bounds y compactación. El valor predeterminado es menor en iGPU/UMA.",
                        "Suballocated memory for commands, bounds and compaction. The default is smaller on iGPU/UMA."));
        integer(
                3,
                "renderer.uploadRingMiB",
                tr("Anillo de subida (MiB)", "Upload Ring (MiB)"),
                defaultUploadRingMiB(),
                2,
                32,
                tr(
                        "Staging mapeado y reutilizable. Un anillo mayor reduce flushes durante ráfagas, a costa de memoria temporal.",
                        "Persistently mapped reusable staging. A larger ring reduces flushes during bursts at the cost of temporary memory."));
        integer(
                3,
                "renderer.shadowReceiverCacheEntries",
                tr("Entradas cache de sombra", "Shadow Receiver Cache Entries"),
                65536,
                4096,
                262144,
                tr(
                        "Límite por hilo para receptores de sombra vanilla cacheados. El cache se invalida por revisión de section y se limpia al exceder este límite.",
                        "Per-thread limit for cached vanilla shadow receivers. Entries are revision-keyed and the cache is cleared when this limit is exceeded."));
        toggle(
                2,
                "profiling.fullFrame",
                tr("Telemetría completa ligera", "Light Full-Frame Telemetry"),
                false,
                tr(
                        "Mide de forma muestreada CPU, render passes, draws, carga de geometría, uploads y GPU sin esperar al dispositivo. F9 activa automáticamente un modo de captura más detallado aunque esta opción esté apagada.",
                        "Samples CPU, render passes, draws, geometry load, uploads, and GPU work without waiting for the device. F9 automatically enables a more detailed capture mode even when this option is off."));
        toggle(
                2,
                "profiling.gpu",
                tr("Timestamps GPU continuos", "Continuous GPU Timestamps"),
                false,
                tr(
                        "Fuerza timestamps GPU en cada frame para diagnóstico detallado. Con esta opción apagada, Veil sólo toma muestras dispersas cuando el autotune las necesita, reduciendo overhead a FPS altos.",
                        "Forces GPU timestamps every frame for detailed diagnostics. When disabled, Veil only takes sparse samples when autotuning needs them, reducing overhead at high FPS."));
        toggle(
                3,
                "profiling.deepTelemetry",
                tr("Telemetría profunda (diagnóstico)", "Deep Telemetry (Diagnostics)"),
                false,
                tr(
                        "Perfila cada frame y activa atribución de allocations por thread/section. Úsala sólo para capturas cortas porque añade más overhead que el modo ligero o F9.",
                        "Profiles every frame and enables per-thread/section allocation attribution. Use only for short captures because it adds more overhead than light mode or F9."));
        toggle(
                3,
                "latency.lowLatency",
                tr("Baja latencia / 1 frame adelantado", "Low Latency / 1 Frame Ahead"),
                false,
                tr(
                        "Opcional: limita el render-ahead a un frame esperando la fence anterior. Reduce input lag, pero puede recortar de forma visible el techo de FPS; Veil V24 prioriza throughput y lo deja apagado por defecto.",
                        "Optional: limits render-ahead to one frame by waiting for the previous fence. It reduces input lag but can noticeably reduce peak FPS; Veil V24 prioritizes throughput and leaves it off by default."));
        nativeOption(
                2,
                o.prioritizeChunkUpdates(),
                tr(
                        "Prioridad de actualización de chunks administrada por Minecraft. Afecta al equilibrio entre aparición del terreno y fluidez.",
                        "Minecraft-managed chunk update priority. It changes the balance between terrain appearing quickly and smooth frame pacing."));
        nativeOption(
                3,
                o.preferredGraphicsBackend(),
                tr(
                        "Backend gráfico preferido. Requiere reiniciar Minecraft. Un argumento de arranque que fuerce Vulkan tiene prioridad.",
                        "Preferred graphics backend. Requires restarting Minecraft. A launch argument that forces Vulkan takes priority."));
        integer(
                3,
                "lod.distance",
                tr("Inicio base de reducción (bloques)", "Base Geometry Reduction Start (blocks)"),
                48,
                0,
                512,
                tr(
                        "Distancia base para reducciones pequeñas. V38 activa reducciones fuertes mucho antes, incluso cerca de la cámara, porque siguen siendo geométricamente exactas; el autotune evita forzar una ruta GPU más lenta.",
                        "Base distance for small reductions. V38 enables strong reductions much earlier, even near the camera, because they remain geometrically exact; autotuning avoids forcing a slower GPU path."));
        integer(
                3,
                "lod.uploadKiB",
                tr("Subida de malla fusionada (KiB/frame)", "Merged Mesh Upload (KiB/frame)"),
                512,
                64,
                2048,
                tr(
                        "Presupuesto de subida para reemplazos fusionados. Si se agota, se mantiene la malla original hasta poder subir la versión exacta reducida.",
                        "Upload budget for merged replacements. If exhausted, the original mesh remains until the exact reduced version can be uploaded."));
        integer(
                3,
                "shader.maxPasses",
                tr("Pases máximos del pack", "Maximum Pack Passes"),
                128,
                16,
                4096,
                tr(
                        "Presupuesto de complejidad del grafo de shaders.",
                        "Shader graph complexity budget."));
        integer(
                3,
                "shader.maxResources",
                tr("Recursos máximos del pack", "Maximum Pack Resources"),
                256,
                32,
                16384,
                tr(
                        "Presupuesto de recursos declarados por el pack.",
                        "Budget for resources declared by the pack."));
        integer(
                3,
                "shader.bufferMiB",
                tr("Buffer máximo de shaders (MiB)", "Maximum Shader Buffer (MiB)"),
                256,
                16,
                1024,
                tr(
                        "Tamaño por buffer; la GPU puede imponer un máximo menor.",
                        "Per-buffer size; the GPU may impose a lower maximum."));
        integer(
                3,
                "shader.packMiB",
                tr("Memoria del pack (MiB)", "Pack Memory (MiB)"),
                512,
                128,
                8192,
                tr(
                        "Presupuesto de imágenes, buffers e historial del pack.",
                        "Budget for pack images, buffers and history."));
        integer(
                3,
                "shader.rayMiB",
                tr("Geometría trazable (MiB)", "Ray Geometry (MiB)"),
                128,
                8,
                1024,
                tr(
                        "Presupuesto del terreno para rayos y sombras. Más memoria permite incluir más triángulos.",
                        "Terrain budget for rays and shadows. More memory allows more triangles."));
        integer(
                3,
                "shader.rayRadius",
                tr("Radio trazable (bloques)", "Ray Radius (blocks)"),
                128,
                16,
                512,
                tr(
                        "Incluye secciones residentes fuera de pantalla dentro de este radio. Requiere chunks cargados.",
                        "Includes resident offscreen sections within this radius. Requires loaded chunks."));
        integer(
                3,
                "shader.offscreenCompiles",
                tr("Secciones fuera de pantalla por ciclo", "Offscreen Sections per Cycle"),
                2,
                0,
                16,
                tr(
                        "Compila terreno para sombras cuando la cola normal está libre. Cero desactiva este trabajo.",
                        "Compiles terrain for shadows when the normal queue is free. Zero disables this work."));
        integer(
                3,
                "shader.rebuildMs",
                tr("Intervalo de escena trazable (ms)", "Ray Scene Interval (ms)"),
                100,
                50,
                2000,
                tr(
                        "Intervalo mínimo entre capturas; la construcción se realiza en un hilo secundario.",
                        "Minimum capture interval; construction runs on a background thread."));
        nativeOption(
                3,
                o.chunkSectionFadeInTime(),
                tr(
                        "Duración de la aparición gradual de las secciones nuevas.",
                        "Duration of the fade-in animation for new sections."));
        toggle(
                4,
                "animation.all",
                tr("Animaciones de texturas", "Texture Animations"),
                tr(
                        "Congela las texturas animadas y omite sus actualizaciones del atlas. No afecta a movimiento de entidades ni a la simulación.",
                        "Freezes animated textures and skips their atlas updates. Entity movement and simulation are unaffected."));
        toggle(
                4,
                "animation.visibleOnly",
                tr("Animar sólo texturas usadas", "Animate Only Used Textures"),
                tr(
                        "Omite subidas de fotogramas de sprites animados que no fueron usados por terreno visible, partículas, GUI o render inmediato. Todos los fotogramas se precargan una vez antes de activar el ahorro.",
                        "Skips animation-frame uploads for sprites not used by visible terrain, particles, GUI, or immediate rendering. Every frame is uploaded once before on-demand gating begins."));
        String[][] animations = {
            {"water", "Agua", "Water"},
            {"lava", "Lava", "Lava"},
            {"fire", "Fuego", "Fire"},
            {"portal", "Portales", "Portals"},
            {"sculk", "Sculk", "Sculk"},
            {"other", "Otras texturas animadas", "Other Animated Textures"}
        };
        for (var a : animations)
            toggle(
                    4,
                    "animation." + a[0],
                    tr(a[1], a[2]),
                    tr(
                            "Activa la animación de esta categoría de texturas. Al desactivarla permanece el último fotograma cargado. La categoría se identifica por el nombre del recurso.",
                            "Enables animation for this texture category. When disabled, the last loaded frame remains visible. The resource name determines its category."));
        nativeOption(
                4,
                o.glintSpeed(),
                tr(
                        "Velocidad del brillo de objetos encantados.",
                        "Speed of the enchanted item glint."));
        nativeOption(
                4,
                o.glintStrength(),
                tr(
                        "Intensidad del brillo de objetos encantados.",
                        "Strength of the enchanted item glint."));
        toggle(
                5,
                "particle.all",
                tr("Todas las partículas", "All Particles"),
                tr(
                        "Impide añadir nuevas partículas. Las que ya existen terminan su duración normal. No cambia la simulación ni los sonidos.",
                        "Prevents new particles from being added. Existing particles finish their normal lifetime. Simulation and sounds are unaffected."));
        toggle(
                5,
                "particle.adaptive",
                tr("Presupuesto adaptativo lejano", "Adaptive Far Particle Budget"),
                tr(
                        "Conserva partículas cercanas y críticas; reduce progresivamente únicamente ráfagas lejanas cuando superan el presupuesto de FPS.",
                        "Preserves nearby and critical particles; progressively reduces only distant bursts when they exceed the FPS budget."));
        nativeOption(
                5,
                o.particles(),
                tr(
                        "Densidad global de partículas de Minecraft; se combina con los filtros por tipo de Veil.",
                        "Minecraft's global particle density; combines with Veil's per-type filters."));
        BuiltInRegistries.PARTICLE_TYPE.keySet().stream()
                .sorted(Comparator.comparing(Object::toString))
                .forEach(
                        id ->
                                toggle(
                                        5,
                                        "particle." + id,
                                        spanish
                                                ? id.getPath().replace('_', ' ')
                                                : humanize(id.getPath()),
                                        tr(
                                                "Filtro de nuevas partículas: "
                                                        + id
                                                        + ". Se conservan las existentes hasta que expiren.",
                                                "New particle filter: "
                                                        + id
                                                        + ". Existing particles remain until they expire.")));
        String[][] details = {
            {"sky", "Fondo del cielo", "Sky Background"},
            {"sun", "Sol", "Sun"},
            {"moon", "Luna", "Moon"},
            {"stars", "Estrellas", "Stars"},
            {"sunset", "Amanecer y atardecer", "Sunrise and Sunset"},
            {"weather", "Lluvia y nieve", "Rain and Snow"}
        };
        for (var d : details)
            toggle(
                    6,
                    "detail." + d[0],
                    tr(d[1], d[2]),
                    tr(
                            "Activa el dibujo de este detalle. Desactivarlo cambia la imagen; no altera el tiempo, el clima del servidor ni sus sonidos.",
                            "Enables this visual detail. Disabling it changes the image; it does not alter time, server weather or sounds."));
        nativeOption(
                6,
                o.cloudRange(),
                tr("Extensión de las nubes dibujadas.", "Distance covered by rendered clouds."));
        nativeOption(
                6,
                o.weatherRadius(),
                tr("Radio de dibujo de precipitación.", "Rendering radius for precipitation."));
        nativeOption(
                6,
                o.vignette(),
                tr(
                        "Oscurecimiento de los bordes de la pantalla.",
                        "Darkening around the screen edges."));
        nativeOption(
                6,
                o.hideLightningFlash(),
                tr(
                        "Oculta los destellos visuales de relámpagos.",
                        "Hides visual lightning flashes."));
        nativeOption(
                7,
                o.screenEffectScale(),
                tr(
                        "Intensidad de distorsiones de pantalla.",
                        "Strength of screen distortion effects."));
        nativeOption(
                7,
                o.fovEffectScale(),
                tr(
                        "Intensidad de cambios del campo de visión por efectos del juego.",
                        "Strength of field-of-view changes caused by gameplay effects."));
        nativeOption(
                7,
                o.darknessEffectScale(),
                tr("Intensidad del efecto de oscuridad.", "Strength of the darkness effect."));
        nativeOption(
                7,
                o.damageTiltStrength(),
                tr("Inclinación de cámara al recibir daño.", "Camera tilt when taking damage."));
        nativeOption(
                7,
                o.showAutosaveIndicator(),
                tr("Indicador visual de guardado automático.", "Visual autosave indicator."));
        nativeOption(
                7,
                o.attackIndicator(),
                tr(
                        "Ubicación del indicador de recarga del ataque.",
                        "Location of the attack cooldown indicator."));
        nativeOption(
                7,
                o.menuBackgroundBlurriness(),
                tr(
                        "Desenfoque del mundo detrás de los menús de Minecraft. Los ajustes de Veil dejan visible el fondo.",
                        "Blur behind Minecraft menus. Veil settings keep the background visible."));
        nativeOption(
                7,
                o.notificationDisplayTime(),
                tr("Duración de las notificaciones.", "Duration of notifications."));
    }

    private static boolean integratedGpu() {
        try {
            return com.mojang.blaze3d.systems.RenderSystem.getDevice().getDeviceInfo().type()
                    == com.mojang.blaze3d.systems.DeviceType.INTEGRATED;
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    private static int defaultMdiBatchSize() {
        return integratedGpu() ? 1024 : 2048;
    }

    private static int defaultGpuArenaMiB() {
        return integratedGpu() ? 16 : 32;
    }

    private static int defaultUploadRingMiB() {
        return integratedGpu() ? 4 : 8;
    }

    private static String humanize(String path) {
        var result = new StringBuilder(path.length());
        boolean upper = true;
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '_') {
                result.append(' ');
                upper = true;
            } else {
                result.append(upper ? Character.toUpperCase(c) : c);
                upper = false;
            }
        }
        return result.toString();
    }

    @Override
    protected void init() {
        layout();
    }

    private void layout() {
        clearWidgets();
        rows.clear();
        addRenderableWidget(
                new FlatButton(
                        Math.max(66, width - 151),
                        7,
                        119,
                        tr("Invítame a un café", "Buy me a coffee"),
                        () -> ConfirmLinkScreen.confirmLinkNow(this, COFFEE_URL)));
        addRenderableWidget(new FlatButton(width - 26, 7, 18, "×", this::onClose));
        int x = 8, y = 33;
        for (int i = 0; i < tabs.length; i++) {
            int w = font.width(tabs[i]) + 16;
            if (x + w > width - 8) {
                x = 8;
                y += 23;
            }
            final int selected = i;
            var button =
                    new FlatButton(
                            x,
                            y,
                            w,
                            tabs[i],
                            () -> {
                                tab = selected;
                                scroll = 0;
                                query = "";
                                layout();
                            });
            button.selected = i == tab;
            addRenderableWidget(button);
            x += w + 4;
        }
        int searchY = y + 27;
        column = width >= 560 ? Math.min(350, (width - 24) / 2) : width - 16;
        search =
                new EditBox(
                        font,
                        8,
                        searchY,
                        column,
                        18,
                        Component.literal(tr("Buscar ajustes", "Search settings")));
        search.setHint(Component.literal(tr("Buscar en ", "Search ") + tabs[tab] + "…"));
        search.setValue(query);
        search.setResponder(
                value -> {
                    query = value;
                    scroll = 0;
                    rebuildRows();
                });
        addRenderableWidget(search);
        top = searchY + 25;
        bottom = height - 46;
        rebuildRows();
        undo =
                addRenderableWidget(
                        new FlatButton(
                                Math.max(8, width - 260),
                                height - 28,
                                82,
                                tr("Deshacer", "Undo"),
                                () -> {
                                    settings.forEach(Setting::reset);
                                    status = tr("Cambios descartados", "Changes discarded");
                                    layout();
                                }));
        apply =
                addRenderableWidget(
                        new FlatButton(
                                Math.max(96, width - 173),
                                height - 28,
                                82,
                                tr("Aplicar", "Apply"),
                                this::applyChanges));
        addRenderableWidget(
                new FlatButton(
                        Math.max(184, width - 86),
                        height - 28,
                        78,
                        tr("Hecho", "Done"),
                        () -> {
                            if (applyChanges()) minecraft.gui.setScreen(parent);
                        }));
    }

    private List<Setting> filtered() {
        return settings.stream()
                .filter(
                        s ->
                                s.tab == tab
                                        && s.title
                                                .toLowerCase(Locale.ROOT)
                                                .contains(query.toLowerCase(Locale.ROOT)))
                .toList();
    }

    private void rebuildRows() {
        for (Row row : rows) removeWidget(row);
        rows.clear();
        if (shaders != null) {
            shaders.clear();
            if (tab != 8) shaders.deactivate();
        }
        if (tab == 8) {
            if (shaders == null) shaders = new VeilShaderPanel(this, font, spanish);
            shaders.build(top, bottom, column, query);
            return;
        }
        var list = filtered();
        int capacity = Math.max(1, (bottom - top) / 23);
        scroll = Math.clamp(scroll, 0, Math.max(0, list.size() - capacity));
        for (int i = scroll; i < Math.min(list.size(), scroll + capacity); i++)
            rows.add(addRenderableWidget(new Row(8, top + (i - scroll) * 23, column, list.get(i))));
    }

    private boolean dirty() {
        return settings.stream().anyMatch(Setting::dirty);
    }

    protected final void checkDevelopmentSettings() {
        var before = VeilVideoConfig.snapshot();
        for (var s : settings) {
            Object original = s.option.get();
            s.move(1);
            if (!Objects.equals(original, s.option.get())
                    || !before.equals(VeilVideoConfig.snapshot()))
                throw new AssertionError("Draft mutated live setting: " + s.title);
            s.reset();
            if (s.dirty()) throw new AssertionError("Undo failed: " + s.title);
        }
        if (!COFFEE_URL.equals("https://ko-fi.com/tz4lexv")) throw new AssertionError("Coffee URL");
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil video UI smoke PASS: {} real controls, isolated drafts, undo and coffee URL",
                settings.size());
    }

    protected final void selectDevelopmentTab(int index) {
        tab = index;
        scroll = 0;
        query = "";
        layout();
    }

    private boolean applyChanges() {
        if (!dirty()) return true;
        Map<String, String> next = new HashMap<>(VeilVideoConfig.snapshot());
        var changes = settings.stream().filter(Setting::dirty).toList();
        for (var s : changes) if (s.key != null) next.put(s.key, s.draft.toString());
        try {
            VeilVideoConfig.save(next);
        } catch (java.io.IOException e) {
            status = tr("No se pudo guardar: ", "Could not save: ") + e.getMessage();
            return false;
        }
        var o = minecraft.options;
        int oldMip = o.mipmapLevels().get(), oldAniso = o.maxAnisotropyBit().get();
        var oldFilter = o.textureFiltering().get();
        for (var s : changes) s.commit();
        if (o.improvedTransparency().get() && minecraft.getGpuWarnlistManager().willShowWarning()) {
            o.improvedTransparency().set(false);
            status =
                    tr(
                            "Transparencia mejorada no aplicada: advertencia de compatibilidad de la GPU.",
                            "Improved transparency was not applied because of a GPU compatibility warning.");
        } else status = tr("Ajustes guardados", "Settings saved");
        o.save();
        minecraft.getWindow().changeFullscreenVideoMode();
        if (oldMip != o.mipmapLevels().get()
                || oldAniso != o.maxAnisotropyBit().get()
                || oldFilter != o.textureFiltering().get()) {
            minecraft.updateMaxMipLevel(o.mipmapLevels().get());
            minecraft.delayTextureReload();
        }
        VeilIndirectTerrain.settingsChanged();
        VeilTerrainDrawBridge.invalidateAll();
        if (changes.stream()
                .anyMatch(
                        s ->
                                "renderer.leafCulling".equals(s.key)
                                        || "renderer.leafLayers".equals(s.key)))
            if (minecraft.level != null) minecraft.levelExtractor.allChanged();
        if (changes.stream().anyMatch(s -> s.key != null && s.key.startsWith("shader."))) {
            VeilShaderService.requestReload();
            if (raySceneRequested.getAsBoolean() && minecraft.level != null)
                minecraft.levelRenderer.invalidateCompiledGeometry(
                        minecraft.level,
                        minecraft.options,
                        minecraft.gameRenderer.mainCamera(),
                        minecraft.getBlockColors());
        }
        VeilAsyncEntityOcclusion.invalidate();
        settings.forEach(Setting::refresh);
        layout();
        return true;
    }

    @Override
    public void onClose() {
        if (shaders != null) shaders.deactivate();
        if (!dirty()) {
            minecraft.gui.setScreen(parent);
            return;
        }
        minecraft.gui.setScreen(
                new ConfirmScreen(
                        discard -> {
                            if (discard) minecraft.gui.setScreen(parent);
                            else minecraft.gui.setScreen(this);
                        },
                        Component.literal(tr("Cambios sin aplicar", "Unapplied Changes")),
                        Component.literal(
                                tr(
                                        "¿Descartar los cambios de vídeo?",
                                        "Discard the video setting changes?")),
                        Component.literal(tr("Descartar", "Discard")),
                        Component.literal(tr("Seguir editando", "Keep Editing"))));
    }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        if (y >= top && y <= bottom && x <= column + 12) {
            if (tab == 8) {
                shaders.scrolled(sy);
                return true;
            }
            scroll -= (int) Math.signum(sy) * 3;
            rebuildRows();
            return true;
        }
        return super.mouseScrolled(x, y, sx, sy);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        g.fill(0, 0, width, 28, 0x70000000);
        g.fill(0, height - 33, width, height, 0x70000000);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        g.text(font, "VEIL", 10, 12, ACCENT);
        undo.active = apply.active = dirty();
        super.extractRenderState(g, mx, my, a);
        if (dirty()) g.text(font, tr("• Sin aplicar", "• Unapplied"), 8, height - 40, ACCENT);
        else
            g.text(
                    font,
                    font.plainSubstrByWidth(
                            tab == 8
                                    ? shaders.status()
                                    : status.isEmpty()
                                            ? tr("Vídeo · ", "Video · ") + tabs[tab]
                                            : status,
                            width - 16),
                    8,
                    height - 40,
                    MUTED);
        if (tab == 8) shaders.render(g);
        var hovered = rows.stream().filter(r -> r.isHoveredOrFocused()).findFirst();
        if (width >= 560) {
            int x = column + 20, w = width - x - 8;
            g.fill(x, top, x + w, top + Math.min(155, bottom - top), 0xc010171f);
            g.fill(x, top, x + 2, top + 24, ACCENT);
            g.text(
                    font,
                    hovered.map(r -> font.plainSubstrByWidth(r.setting.title, w - 18))
                            .orElse(tr("Ajustes de Veil", "Veil Settings")),
                    x + 10,
                    top + 9,
                    WHITE);
            String description =
                    hovered.map(r -> r.setting.description)
                            .orElse(
                                    tab == 8
                                            ? shaders.description()
                                            : tr(
                                                    "Selecciona un ajuste para ver qué cambia.\n\nF8: comparar Veil\nF9: medir rendimiento\n\nLOD, HZB y MDI necesitan Vulkan. Los detalles visuales se mantienen hasta que tú los cambies.",
                                                    "Select a setting to see what it changes.\n\nF8: compare Veil\nF9: measure performance\n\nLOD, HZB and MDI require Vulkan. Visual details remain enabled until you change them."));
            g.textWithWordWrap(
                    font, Component.literal(description), x + 10, top + 28, w - 20, MUTED);
            if (minecraft.options.isRestartRequiredToApplyVideoSettings())
                g.textWithWordWrap(
                        font,
                        Component.literal(
                                tr(
                                        "Reinicia Minecraft para aplicar el backend o los cambios de pantalla que lo requieran.",
                                        "Restart Minecraft to apply graphics backend or display changes that require it.")),
                        x + 10,
                        top + 117,
                        w - 20,
                        0xffffd88a);
        } else
            hovered.ifPresent(
                    r ->
                            g.setTooltipForNextFrame(
                                    font, Component.literal(r.setting.description), mx, my));
        int total = filtered().size(), cap = Math.max(1, (bottom - top) / 23);
        if (total > cap) {
            int h = Math.max(12, (bottom - top) * cap / total),
                    y = top + (bottom - top - h) * scroll / (total - cap);
            g.fill(column + 10, top, column + 12, bottom, 0x60404c58);
            g.fill(column + 10, y, column + 12, y + h, ACCENT);
        }
    }

    void addShaderWidget(AbstractWidget widget) {
        addRenderableWidget(widget);
    }

    void removeShaderWidget(AbstractWidget widget) {
        removeWidget(widget);
    }

    AbstractWidget shaderButton(int x, int y, int w, String title, Runnable action) {
        return new FlatButton(x, y, w, title, action);
    }

    @Override
    public void removed() {
        if (shaders != null) shaders.deactivate();
    }

    @Override
    public void tick() {
        if (tab == 8 && shaders != null) shaders.tick();
    }

    private final class Row extends AbstractWidget {
        final Setting setting;

        Row(int x, int y, int w, Setting setting) {
            super(x, y, w, 21, Component.literal(setting.title));
            this.setting = setting;
        }

        private void move(int direction) {
            setting.move(direction);
            setMessage(Component.literal(setting.title + ": " + setting.display()));
        }

        @Override
        public void onClick(MouseButtonEvent e, boolean twice) {
            if (setting.slider() != null && e.x() > getX() + width * 0.58) position(e.x());
            else move(1);
        }

        private void position(double x) {
            var slider = setting.slider();
            if (slider != null)
                setting.draft =
                        slider.fromSliderValue(
                                Math.clamp((x - getX() - width * 0.58) / (width * 0.42 - 8), 0, 1));
        }

        @Override
        protected void onDrag(MouseButtonEvent e, double dx, double dy) {
            position(e.x());
        }

        @Override
        public boolean keyPressed(KeyEvent e) {
            if (e.isSelection() || e.isRight()) {
                move(1);
                return true;
            }
            if (e.isLeft()) {
                move(-1);
                return true;
            }
            return super.keyPressed(e);
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput out) {
            out.add(
                    NarratedElementType.TITLE,
                    Component.literal(setting.title + ": " + setting.display()));
        }

        @Override
        protected void extractWidgetRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
            int x = getX(), y = getY();
            g.fill(x, y, x + width, y + height, isHoveredOrFocused() ? 0xe0142029 : 0xa010171f);
            if (isHoveredOrFocused()) g.fill(x, y, x + 2, y + height, ACCENT);
            String value = setting.display();
            int valueWidth =
                    setting.draft instanceof Boolean ? 12 : Math.min(width / 2, font.width(value));
            g.text(
                    font,
                    font.plainSubstrByWidth(
                            setting.title + (setting.dirty() ? " *" : ""), width - valueWidth - 22),
                    x + 7,
                    y + 6,
                    WHITE);
            if (setting.draft instanceof Boolean on) {
                int bx = x + width - 17;
                g.fill(bx, y + 6, bx + 10, y + 16, ACCENT);
                g.fill(bx + 1, y + 7, bx + 9, y + 15, 0xff17232b);
                if (on) g.fill(bx + 3, y + 9, bx + 7, y + 13, ACCENT);
            } else {
                String text = font.plainSubstrByWidth(value, valueWidth);
                g.text(font, text, x + width - 7 - font.width(text), y + 6, ACCENT);
            }
            var slider = setting.slider();
            if (slider != null && isHoveredOrFocused()) {
                int start = x + (int) (width * .58), end = x + width - 8;
                g.fill(start, y + 18, end, y + 19, MUTED);
                int thumb = start + (int) ((end - start) * slider.toSliderValue(setting.draft));
                g.fill(thumb - 1, y + 16, thumb + 2, y + 21, ACCENT);
            }
        }
    }

    private final class FlatButton extends AbstractButton {
        final Runnable action;
        boolean selected;

        FlatButton(int x, int y, int w, String title, Runnable action) {
            super(x, y, w, 20, Component.literal(title));
            this.action = action;
        }

        @Override
        public void onPress(InputWithModifiers input) {
            action.run();
        }

        @Override
        protected void extractContents(GuiGraphicsExtractor g, int mx, int my, float a) {
            g.fill(
                    getX(),
                    getY(),
                    getX() + width,
                    getY() + height,
                    isHoveredOrFocused() ? 0xe0283943 : 0xc0111921);
            if (selected) g.fill(getX(), getY() + 18, getX() + width, getY() + 20, ACCENT);
            g.centeredText(
                    font,
                    getMessage(),
                    getX() + width / 2,
                    getY() + 6,
                    active ? WHITE : 0xff66717a);
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput out) {
            out.add(NarratedElementType.TITLE, getMessage());
        }
    }

    private static final class Setting {
        final int tab;
        final OptionInstance<Object> option;
        final String key, title, description;
        Object saved, draft;

        Setting(int tab, OptionInstance<Object> option, String key, String description) {
            this(tab, option, key, option.toString(), description);
        }

        Setting(
                int tab,
                OptionInstance<Object> option,
                String key,
                String title,
                String description) {
            this.tab = tab;
            this.option = option;
            this.key = key;
            this.description = description;
            this.title = title;
            refresh();
        }

        void refresh() {
            saved = draft = option.get();
        }

        boolean dirty() {
            return !Objects.equals(saved, draft);
        }

        void reset() {
            draft = saved;
        }

        String display() {
            String value =
                    ((VeilOptionAccessor) (Object) option)
                            .veil$formatter()
                            .apply(draft)
                            .getString();
            String prefix = option.toString() + ": ";
            return value.startsWith(prefix) ? value.substring(prefix.length()) : value;
        }

        OptionInstance.SliderableValueSet<Object> slider() {
            return option.values() instanceof OptionInstance.SliderableValueSet<Object> s
                            && !(option.values()
                                            instanceof
                                            OptionInstance.SliderableOrCyclableValueSet<Object> c
                                    && c.createCycleButton())
                    ? s
                    : null;
        }

        void move(int d) {
            if (option.values() instanceof OptionInstance.CycleableValueSet<Object> cycle) {
                var list = cycle.valueListSupplier().getSelectedList();
                if (!list.isEmpty())
                    draft = list.get(Math.floorMod(list.indexOf(draft) + d, list.size()));
            } else if (slider() != null) {
                var s = slider();
                draft = (d > 0 ? s.next(draft) : s.previous(draft)).orElse(draft);
            }
        }

        void commit() {
            option.set(draft);
            saved = option.get();
            draft = saved;
        }
    }
}
