package dev.veil.revive.client.graphics.resources;

import static org.lwjgl.util.vma.Vma.*;
import static org.lwjgl.vulkan.VK10.*;
import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.revive.client.graphics.minecraft.DeferredGpuRetirement;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.client.graphics.minecraft.VulkanFormats;
import dev.veil.revive.client.graphics.minecraft.VulkanResult;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.vma.VmaAllocationCreateInfo;
import org.lwjgl.vulkan.KHRSynchronization2;
import org.lwjgl.vulkan.VkBufferImageCopy;
import org.lwjgl.vulkan.VkClearColorValue;
import org.lwjgl.vulkan.VkClearDepthStencilValue;
import org.lwjgl.vulkan.VkDependencyInfo;
import org.lwjgl.vulkan.VkImageCreateInfo;
import org.lwjgl.vulkan.VkImageMemoryBarrier2;
import org.lwjgl.vulkan.VkImageViewCreateInfo;
import org.lwjgl.vulkan.VkSamplerCreateInfo;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public final class NativeImageResource implements AutoCloseable {
    private final MinecraftVulkanContext runtime;
    private final DeferredGpuRetirement closeRequested = new DeferredGpuRetirement();
    private final int width;
    private final int height;
    private final int depth;
    private final int layers;
    private final int mipLevels;
    private final int vkFormat;
    private final int viewType;
    private final int aspect;
    private final boolean sampled;
    private final Map<ViewKey, Long> subresourceViews = new LinkedHashMap<>();
    private long image;
    private long allocation;
    private long view;
    private long sampler;

    private NativeImageResource(
            MinecraftVulkanContext runtime,
            int width,
            int height,
            int depth,
            int layers,
            int mipLevels,
            int vkFormat,
            int viewType,
            int aspect,
            boolean sampled,
            long image,
            long allocation,
            long view,
            long sampler) {
        this.runtime = runtime;
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.layers = layers;
        this.mipLevels = mipLevels;
        this.vkFormat = vkFormat;
        this.viewType = viewType;
        this.aspect = aspect;
        this.sampled = sampled;
        this.image = image;
        this.allocation = allocation;
        this.view = view;
        this.sampler = sampler;
    }

    public static NativeImageResource create(
            MinecraftVulkanContext runtime,
            ImageAllocationPlan resource,
            Supplier<byte[]> assetBytes,
            String label) {
        RenderSystem.assertOnRenderThread();
        if (!resource.nativeImage()) {
            throw new IllegalArgumentException(
                    "Native image allocation requires texture/storage resource: "
                            + resource.name());
        }
        int width = resource.width();
        int height = resource.height();
        int depth = resource.depth();
        int layers = resource.layers();
        int mipLevels = resource.mipLevels();
        int vkFormat = VulkanFormats.vk(resource.format());
        if (resource.cubeArray()
                && !dev.veil.revive.client.graphics.minecraft.EnabledRasterFeatures.enabled(
                        runtime.vkDevice(),
                        dev.veil.revive.client.graphics.minecraft.EnabledRasterFeatures.Feature
                                .IMAGE_CUBE_ARRAY))
            throw new IllegalArgumentException(
                    "Image "
                            + resource.name()
                            + ": imageCubeArray is not enabled on the Minecraft Vulkan device");
        validateCapabilities(runtime, resource, width, height, depth, layers, vkFormat);

        try (MemoryStack stack = MemoryStack.stackPush()) {
            int usage = ImageCapabilities.usage(resource);
            var imageInfo =
                    VkImageCreateInfo.calloc(stack)
                            .sType$Default()
                            .flags(resource.cubemap() ? VK_IMAGE_CREATE_CUBE_COMPATIBLE_BIT : 0)
                            .imageType(
                                    resource.image1d()
                                            ? VK_IMAGE_TYPE_1D
                                            : resource.image3d()
                                                    ? VK_IMAGE_TYPE_3D
                                                    : VK_IMAGE_TYPE_2D)
                            .format(vkFormat)
                            .mipLevels(mipLevels)
                            .arrayLayers(layers)
                            .samples(sampleCount(resource.samples()))
                            .tiling(VK_IMAGE_TILING_OPTIMAL)
                            .usage(usage)
                            .sharingMode(VK_SHARING_MODE_EXCLUSIVE)
                            .initialLayout(VK_IMAGE_LAYOUT_UNDEFINED);
            imageInfo.extent().set(width, height, depth);
            var allocationInfo =
                    VmaAllocationCreateInfo.calloc(stack)
                            .usage(VMA_MEMORY_USAGE_AUTO_PREFER_DEVICE);
            var pImage = stack.mallocLong(1);
            var pAllocation = stack.mallocPointer(1);
            VulkanResult.check(
                    vmaCreateImage(
                            runtime.vma(), imageInfo, allocationInfo, pImage, pAllocation, null),
                    "vmaCreateImage(" + resource.name() + ")");

            long image = pImage.get(0);
            long allocation = pAllocation.get(0);
            int viewType =
                    resource.image1d()
                            ? (resource.image1dArray()
                                    ? VK_IMAGE_VIEW_TYPE_1D_ARRAY
                                    : VK_IMAGE_VIEW_TYPE_1D)
                            : resource.image3d()
                                    ? VK_IMAGE_VIEW_TYPE_3D
                                    : resource.cubemap()
                                            ? resource.cubeArray()
                                                    ? VK_IMAGE_VIEW_TYPE_CUBE_ARRAY
                                                    : VK_IMAGE_VIEW_TYPE_CUBE
                                            : resource.image2dArray()
                                                    ? VK_IMAGE_VIEW_TYPE_2D_ARRAY
                                                    : VK_IMAGE_VIEW_TYPE_2D;
            int aspect =
                    resource.format().depth()
                            ? VK_IMAGE_ASPECT_DEPTH_BIT
                            : VK_IMAGE_ASPECT_COLOR_BIT;
            if (resource.format().stencil()) aspect |= VK_IMAGE_ASPECT_STENCIL_BIT;
            long view = VK_NULL_HANDLE;
            long sampler = VK_NULL_HANDLE;
            try {
                if (resource.sampled()
                        || resource.storageImage()
                        || resource.renderTarget()
                        || resource.depthTarget()) {
                    var pView = stack.mallocLong(1);
                    var viewInfo =
                            VkImageViewCreateInfo.calloc(stack)
                                    .sType$Default()
                                    .image(image)
                                    .viewType(viewType)
                                    .format(vkFormat);
                    viewInfo.subresourceRange()
                            .aspectMask(aspect)
                            .baseMipLevel(0)
                            .levelCount(mipLevels)
                            .baseArrayLayer(0)
                            .layerCount(layers);
                    VulkanResult.check(
                            vkCreateImageView(runtime.vkDevice(), viewInfo, null, pView),
                            "vkCreateImageView(" + resource.name() + ")");
                    view = pView.get(0);
                }

                if (resource.sampled()) {
                    var properties = org.lwjgl.vulkan.VkPhysicalDeviceProperties.calloc(stack);
                    vkGetPhysicalDeviceProperties(
                            runtime.vkDevice().getPhysicalDevice(), properties);
                    SamplerLodRules.validateDeviceBias(
                            resource.sampler().lodBias(), properties.limits().maxSamplerLodBias());
                    float maxLod =
                            SamplerLodRules.ownedMaxLod(
                                    resource.sampler().minLod(),
                                    resource.sampler().maxLod(),
                                    mipLevels);
                    var pSampler = stack.mallocLong(1);
                    var samplerInfo =
                            VkSamplerCreateInfo.calloc(stack)
                                    .sType$Default()
                                    .magFilter(resource.sampler().mag())
                                    .minFilter(resource.sampler().min())
                                    .mipmapMode(resource.sampler().mip())
                                    .addressModeU(resource.sampler().u())
                                    .addressModeV(resource.sampler().v())
                                    .addressModeW(resource.sampler().w())
                                    .mipLodBias(resource.sampler().lodBias())
                                    .anisotropyEnable(false)
                                    .maxAnisotropy(1.0f)
                                    .compareEnable(resource.sampler().compareEnable())
                                    .compareOp(resource.sampler().compareOp())
                                    .minLod(resource.sampler().minLod())
                                    .maxLod(maxLod)
                                    .borderColor(resource.sampler().borderColor())
                                    .unnormalizedCoordinates(false);
                    VulkanResult.check(
                            vkCreateSampler(runtime.vkDevice(), samplerInfo, null, pSampler),
                            "vkCreateSampler(" + resource.name() + ")");
                    sampler = pSampler.get(0);
                }

                NativeImageResource result =
                        new NativeImageResource(
                                runtime,
                                width,
                                height,
                                depth,
                                layers,
                                mipLevels,
                                vkFormat,
                                viewType,
                                aspect,
                                resource.sampled(),
                                image,
                                allocation,
                                view,
                                sampler);
                if (assetBytes != null)
                    result.upload(assetBytes.get(), label, resource.format().bytesPerTexel());
                return result;
            } catch (RuntimeException failure) {
                if (sampler != VK_NULL_HANDLE) vkDestroySampler(runtime.vkDevice(), sampler, null);
                if (view != VK_NULL_HANDLE) vkDestroyImageView(runtime.vkDevice(), view, null);
                vmaDestroyImage(runtime.vma(), image, allocation);
                throw failure;
            }
        }
    }

    private static void validateCapabilities(
            MinecraftVulkanContext runtime,
            ImageAllocationPlan resource,
            int width,
            int height,
            int depth,
            int layers,
            int vkFormat) {
        dev.veil.revive.client.graphics.resources.ImageCapabilities.validate(
                runtime.vkDevice().getPhysicalDevice(),
                resource,
                width,
                height,
                depth,
                layers,
                vkFormat);
    }

    private void upload(byte[] bytes, String label, int bytesPerTexel) {
        GpuBuffer staging =
                runtime.device()
                        .createBuffer(
                                () -> label + "/staging",
                                GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                                bytes.length);
        try {
            try (var mapping = staging.map(false, true)) {
                mapping.data().put(bytes);
            }
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var toTransfer = VkImageMemoryBarrier2.calloc(1, stack);
                var barrier =
                        toTransfer
                                .get(0)
                                .sType$Default()
                                .srcStageMask(VK_PIPELINE_STAGE_2_TOP_OF_PIPE_BIT)
                                .srcAccessMask(0)
                                .dstStageMask(VK_PIPELINE_STAGE_2_TRANSFER_BIT)
                                .dstAccessMask(VK_ACCESS_2_TRANSFER_WRITE_BIT)
                                .oldLayout(VK_IMAGE_LAYOUT_UNDEFINED)
                                .newLayout(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL)
                                .srcQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                                .dstQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                                .image(image);
                barrier.subresourceRange()
                        .aspectMask(aspect)
                        .baseMipLevel(0)
                        .levelCount(mipLevels)
                        .baseArrayLayer(0)
                        .layerCount(layers);
                KHRSynchronization2.vkCmdPipelineBarrier2KHR(
                        runtime.commandBuffer(),
                        VkDependencyInfo.calloc(stack)
                                .sType$Default()
                                .pImageMemoryBarriers(toTransfer));

                var copy = VkBufferImageCopy.calloc(mipLevels, stack);
                long offset = 0;
                for (int level = 0; level < mipLevels; level++) {
                    int mipWidth = Math.max(1, width >> level);
                    int mipHeight = Math.max(1, height >> level);
                    int mipDepth = depth > 1 ? Math.max(1, depth >> level) : 1;
                    var region = copy.get(level);
                    region.bufferOffset(offset).bufferRowLength(0).bufferImageHeight(0);
                    region.imageSubresource()
                            .aspectMask(aspect)
                            .mipLevel(level)
                            .baseArrayLayer(0)
                            .layerCount(layers);
                    region.imageOffset().set(0, 0, 0);
                    region.imageExtent().set(mipWidth, mipHeight, mipDepth);
                    long slices = depth > 1 ? mipDepth : layers;
                    offset =
                            Math.addExact(
                                    offset,
                                    Math.multiplyExact(
                                            Math.multiplyExact((long) mipWidth, mipHeight),
                                            Math.multiplyExact(slices, (long) bytesPerTexel)));
                }
                if (offset != bytes.length) {
                    throw new IllegalArgumentException(
                            "Image upload mip chain size mismatch: expected="
                                    + offset
                                    + " actual="
                                    + bytes.length);
                }
                vkCmdCopyBufferToImage(
                        runtime.commandBuffer(),
                        ((VulkanGpuBuffer) staging).vkBuffer(),
                        image,
                        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                        copy);

                var toShader = VkImageMemoryBarrier2.calloc(1, stack);
                barrier =
                        toShader.get(0)
                                .sType$Default()
                                .srcStageMask(VK_PIPELINE_STAGE_2_TRANSFER_BIT)
                                .srcAccessMask(VK_ACCESS_2_TRANSFER_WRITE_BIT)
                                .dstStageMask(
                                        VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT
                                                | VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT)
                                .dstAccessMask(
                                        sampled
                                                ? VK_ACCESS_2_SHADER_SAMPLED_READ_BIT
                                                : VK_ACCESS_2_SHADER_STORAGE_READ_BIT
                                                        | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT)
                                .oldLayout(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL)
                                .newLayout(
                                        sampled
                                                ? VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL
                                                : VK_IMAGE_LAYOUT_GENERAL)
                                .srcQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                                .dstQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                                .image(image);
                barrier.subresourceRange()
                        .aspectMask(aspect)
                        .baseMipLevel(0)
                        .levelCount(mipLevels)
                        .baseArrayLayer(0)
                        .layerCount(layers);
                KHRSynchronization2.vkCmdPipelineBarrier2KHR(
                        runtime.commandBuffer(),
                        VkDependencyInfo.calloc(stack)
                                .sType$Default()
                                .pImageMemoryBarriers(toShader));
            }
        } finally {
            staging.close();
        }
    }

    public void clearZero() {
        RenderSystem.assertOnRenderThread();
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var barriers = VkImageMemoryBarrier2.calloc(1, stack);
            var barrier =
                    barriers.get(0)
                            .sType$Default()
                            .srcStageMask(VK_PIPELINE_STAGE_2_TOP_OF_PIPE_BIT)
                            .srcAccessMask(0)
                            .dstStageMask(VK_PIPELINE_STAGE_2_TRANSFER_BIT)
                            .dstAccessMask(VK_ACCESS_2_TRANSFER_WRITE_BIT)
                            .oldLayout(VK_IMAGE_LAYOUT_UNDEFINED)
                            .newLayout(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL)
                            .srcQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                            .dstQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                            .image(image);
            barrier.subresourceRange()
                    .aspectMask(aspect)
                    .baseMipLevel(0)
                    .levelCount(mipLevels)
                    .baseArrayLayer(0)
                    .layerCount(layers);
            KHRSynchronization2.vkCmdPipelineBarrier2KHR(
                    runtime.commandBuffer(),
                    VkDependencyInfo.calloc(stack).sType$Default().pImageMemoryBarriers(barriers));

            var range = org.lwjgl.vulkan.VkImageSubresourceRange.calloc(1, stack);
            range.get(0)
                    .aspectMask(aspect)
                    .baseMipLevel(0)
                    .levelCount(mipLevels)
                    .baseArrayLayer(0)
                    .layerCount(layers);
            if ((aspect & VK_IMAGE_ASPECT_COLOR_BIT) != 0) {
                VkClearColorValue clear = VkClearColorValue.calloc(stack);
                clear.float32(0, 0.0f).float32(1, 0.0f).float32(2, 0.0f).float32(3, 0.0f);
                vkCmdClearColorImage(
                        runtime.commandBuffer(),
                        image,
                        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                        clear,
                        range);
            } else {
                VkClearDepthStencilValue clear =
                        VkClearDepthStencilValue.calloc(stack).depth(0.0f).stencil(0);
                vkCmdClearDepthStencilImage(
                        runtime.commandBuffer(),
                        image,
                        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                        clear,
                        range);
            }
        }
    }

    private record ViewKey(int mip, int baseLayer, int layerCount, int type, int aspect) {}

    public long view(int mip, int baseLayer, int layerCount) {
        RenderSystem.assertOnRenderThread();
        if (closeRequested.closeRequested() || image == VK_NULL_HANDLE)
            throw new IllegalStateException("Native image is closed");
        if (view == VK_NULL_HANDLE)
            throw new IllegalStateException("Transfer-only image has no shader or attachment view");
        int resolvedLayers = layerCount == 0 ? layers - baseLayer : layerCount;
        int levelCount = mip < 0 ? mipLevels : 1;
        int baseMip = mip < 0 ? 0 : mip;
        if (baseMip < 0
                || baseMip >= mipLevels
                || baseLayer < 0
                || resolvedLayers < 1
                || (long) baseLayer + resolvedLayers > layers) {
            throw new IllegalArgumentException("Invalid native image subresource view");
        }
        int shaderAspect =
                (aspect & VK_IMAGE_ASPECT_DEPTH_BIT) != 0 ? VK_IMAGE_ASPECT_DEPTH_BIT : aspect;
        if (viewType == VK_IMAGE_VIEW_TYPE_CUBE && resolvedLayers != 6
                || viewType == VK_IMAGE_VIEW_TYPE_CUBE_ARRAY && resolvedLayers % 6 != 0)
            throw new IllegalArgumentException("Invalid cube image view layer count");
        if (baseMip == 0
                && levelCount == mipLevels
                && baseLayer == 0
                && resolvedLayers == layers
                && shaderAspect == aspect) return view;
        ViewKey key = new ViewKey(mip, baseLayer, resolvedLayers, viewType, shaderAspect);
        Long cached = subresourceViews.get(key);
        if (cached != null) return cached;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var out = stack.mallocLong(1);
            var info =
                    VkImageViewCreateInfo.calloc(stack)
                            .sType$Default()
                            .image(image)
                            .viewType(viewType)
                            .format(vkFormat);
            info.subresourceRange()
                    .aspectMask(shaderAspect)
                    .baseMipLevel(baseMip)
                    .levelCount(levelCount)
                    .baseArrayLayer(baseLayer)
                    .layerCount(resolvedLayers);
            VulkanResult.check(
                    vkCreateImageView(runtime.vkDevice(), info, null, out),
                    "vkCreateImageView(subresource)");
            long created = out.get(0);
            subresourceViews.put(key, created);
            return created;
        }
    }

    public long attachmentView(int mip, int layer) {
        RenderSystem.assertOnRenderThread();
        if (closeRequested.closeRequested() || image == VK_NULL_HANDLE)
            throw new IllegalStateException("Native image is closed");
        if (mip < 0 || mip >= mipLevels || layer < 0 || layer >= layers || depth != 1) {
            throw new IllegalArgumentException("Invalid native attachment subresource");
        }
        int attachmentType =
                viewType == VK_IMAGE_VIEW_TYPE_1D || viewType == VK_IMAGE_VIEW_TYPE_1D_ARRAY
                        ? VK_IMAGE_VIEW_TYPE_1D
                        : VK_IMAGE_VIEW_TYPE_2D;
        if (viewType == attachmentType && mip == 0 && layer == 0) return view;
        ViewKey key = new ViewKey(mip, layer, 1, attachmentType, aspect);
        Long cached = subresourceViews.get(key);
        if (cached != null) return cached;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var out = stack.mallocLong(1);
            var info =
                    VkImageViewCreateInfo.calloc(stack)
                            .sType$Default()
                            .image(image)
                            .viewType(attachmentType)
                            .format(vkFormat);
            info.subresourceRange()
                    .aspectMask(aspect)
                    .baseMipLevel(mip)
                    .levelCount(1)
                    .baseArrayLayer(layer)
                    .layerCount(1);
            VulkanResult.check(
                    vkCreateImageView(runtime.vkDevice(), info, null, out),
                    "vkCreateImageView(attachment)");
            long created = out.get(0);
            subresourceViews.put(key, created);
            return created;
        }
    }

    public long image() {
        return image;
    }

    public long view() {
        return view;
    }

    public long sampler() {
        return sampler;
    }

    public int format() {
        return vkFormat;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    public int depth() {
        return depth;
    }

    public int layers() {
        return layers;
    }

    public int mipLevels() {
        return mipLevels;
    }

    public int aspect() {
        return aspect;
    }

    private void destroyNow() {
        long oldSampler = sampler;
        long oldView = view;
        long oldImage = image;
        long oldAllocation = allocation;
        sampler = VK_NULL_HANDLE;
        view = VK_NULL_HANDLE;
        image = VK_NULL_HANDLE;
        allocation = VK_NULL_HANDLE;
        if (oldSampler != VK_NULL_HANDLE) vkDestroySampler(runtime.vkDevice(), oldSampler, null);
        subresourceViews
                .values()
                .forEach(handle -> vkDestroyImageView(runtime.vkDevice(), handle, null));
        subresourceViews.clear();
        if (oldView != VK_NULL_HANDLE) vkDestroyImageView(runtime.vkDevice(), oldView, null);
        if (oldImage != VK_NULL_HANDLE) vmaDestroyImage(runtime.vma(), oldImage, oldAllocation);
    }

    @Override
    public void close() {
        RenderSystem.assertOnRenderThread();
        closeRequested.defer(action -> runtime.deferDestroy(action::run), this::destroyNow);
    }

    public static int sampleCount(int samples) {
        return dev.veil.revive.client.graphics.resources.ImageCapabilities.sampleCount(samples);
    }
}
