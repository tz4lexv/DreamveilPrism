package dev.veil.revive.client;

import static org.lwjgl.util.spvc.Spv.*;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;

/** Storage-specific device requirements, independent of resource names and shader language. */
record VeilInt64AtomicRequirements(boolean declared, boolean buffers, boolean shared) {
    private record Pointer(int storage, int element) {}

    static VeilInt64AtomicRequirements inspect(VeilSpirvBinary binary) {
        var words =
                ByteBuffer.wrap(binary.unsafeCode()).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer();
        boolean declared = false;
        for (int offset = 5; offset < words.limit(); ) {
            int count = words.get(offset) >>> 16, op = words.get(offset) & 65535;
            if (op == SpvOpCapability
                    && count >= 2
                    && words.get(offset + 1) == SpvCapabilityInt64Atomics) {
                declared = true;
                break;
            }
            offset += count;
        }
        if (!declared) return new VeilInt64AtomicRequirements(false, false, false);
        var widths = new HashMap<Integer, Integer>();
        var pointers = new HashMap<Integer, Pointer>();
        var values = new HashMap<Integer, Integer>();
        boolean buffers = false, shared = false;
        for (int offset = 5; offset < words.limit(); ) {
            int count = words.get(offset) >>> 16, op = words.get(offset) & 65535;
            if (op == SpvOpTypeInt && count >= 4)
                widths.put(words.get(offset + 1), words.get(offset + 2));
            if (op == SpvOpTypePointer && count >= 4)
                pointers.put(
                        words.get(offset + 1),
                        new Pointer(words.get(offset + 2), words.get(offset + 3)));
            // Every supported producer has Result Type / Result Id in these positions.
            // Do not interpret decorations, literal operands or type declarations as SSA values.
            if (count >= 3
                    && switch (op) {
                        case SpvOpVariable,
                                SpvOpAccessChain,
                                SpvOpInBoundsAccessChain,
                                SpvOpPtrAccessChain,
                                SpvOpInBoundsPtrAccessChain,
                                SpvOpCopyObject,
                                SpvOpPhi,
                                SpvOpSelect,
                                SpvOpFunctionParameter,
                                SpvOpFunctionCall,
                                SpvOpLoad,
                                SpvOpBitcast,
                                SpvOpConvertUToPtr,
                                SpvOpUndef,
                                SpvOpConstantNull,
                                SpvOpImageTexelPointer ->
                                true;
                        default -> false;
                    }) values.put(words.get(offset + 2), words.get(offset + 1));
            offset += count;
        }
        for (int offset = 5; offset < words.limit(); ) {
            int count = words.get(offset) >>> 16, op = words.get(offset) & 65535;
            if (op >= SpvOpAtomicLoad && op <= SpvOpAtomicXor) {
                int operand = op == SpvOpAtomicStore ? 1 : 3;
                if (count <= operand) throw invalid(binary, "truncated atomic instruction");
                Integer type = values.get(words.get(offset + operand));
                Pointer pointer = type == null ? null : pointers.get(type);
                if (pointer == null)
                    throw invalid(binary, "atomic pointer type cannot be resolved");
                if (widths.getOrDefault(pointer.element(), 0) == 64) {
                    switch (pointer.storage()) {
                        case SpvStorageClassUniform, SpvStorageClassStorageBuffer -> buffers = true;
                        case SpvStorageClassWorkgroup -> shared = true;
                        default ->
                                throw invalid(
                                        binary,
                                        "unsupported Int64 atomic storage class "
                                                + pointer.storage());
                    }
                }
            }
            offset += count;
        }
        return new VeilInt64AtomicRequirements(true, buffers, shared);
    }

    void validateEnabled(String source, boolean bufferEnabled, boolean sharedEnabled) {
        if ((buffers && !bufferEnabled)
                || (shared && !sharedEnabled)
                || (declared && !bufferEnabled && !sharedEnabled))
            throw new IllegalStateException(
                    source
                            + ": Int64 atomics require enabled storage-specific Vulkan features"
                            + " (buffers="
                            + buffers
                            + ", shared="
                            + shared
                            + ")");
    }

    private static IllegalArgumentException invalid(VeilSpirvBinary binary, String message) {
        return new IllegalArgumentException(binary.sourceName() + ": " + message);
    }
}
