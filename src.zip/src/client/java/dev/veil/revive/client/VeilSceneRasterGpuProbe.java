package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.CompareOp;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.api.VeilScenePass;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.graphics.minecraft.*;
import dev.veil.revive.mixin.VulkanScenePipelineAccessor;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

import org.joml.Vector4f;

import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

final class VeilSceneRasterGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.sceneRasterProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final int SIZE = 32, BYTES = SIZE * SIZE * 4;
    private static final List<Case> CASES = new ArrayList<>();
    private static GpuTexture color, depth;
    private static GpuTextureView colorView, depthView;
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static boolean started, complete;
    private static long start;

    private record Case(
            String name,
            VeilScenePass.Raster raster,
            boolean sloped,
            boolean outside,
            boolean receiver,
            int expected) {}

    private VeilSceneRasterGpuProbe() {}

    static boolean enabled() {
        return ENABLED;
    }

    static void tick() {
        if (!ENABLED || complete) return;
        try {
            if (!started) {
                if (Minecraft.getInstance().level == null
                        || VeilVulkanRuntime.currentDeviceOrNull() == null
                        || Boolean.getBoolean("veil.benchmarkWorld")
                                && !VeilBenchmarkWorld.terrainReady()) return;
                started = true;
                start = System.nanoTime();
                record();
            } else if (fence != null && fence.awaitCompletion(0)) {
                try (var mapped = readback.map(true, false)) {
                    verify(mapped.data());
                }
                complete = true;
                ReviveMod.LOGGER.info(
                        "Veil scene raster GPU: PASS cases={} scope_restore=true cache_retired=true",
                        CASES.size());
                close();
                Minecraft.getInstance().stop();
            } else if (System.nanoTime() - start > 120_000_000_000L)
                throw new IllegalStateException("Scene raster GPU timeout");
        } catch (Exception | LinkageError failure) {
            complete = true;
            ReviveMod.LOGGER.error("Veil scene raster GPU: FAIL", failure);
            try {
                close();
            } finally {
                Minecraft.getInstance().stop();
            }
        }
    }

    private static VeilScenePass.Raster raster(
            Boolean enable,
            Float constant,
            Float slope,
            Float clamp,
            Boolean depthClamp,
            VeilScenePass.CullMode cull,
            VeilScenePass.FrontFace front) {
        return new VeilScenePass.Raster(enable, constant, slope, clamp, depthClamp, cull, front);
    }

    private static RenderPipeline pipeline(
            String name, boolean sloped, boolean outside, boolean receiver) {
        return RenderPipeline.builder()
                .withLocation(id("pipeline/scene_raster_probe_" + name))
                .withVertexShader(id("core/scene_raster_probe"))
                .withFragmentShader(id("core/scene_raster_probe"))
                .withShaderDefine("VEIL_PROBE_SLOPE", sloped ? 0.5f : 0f)
                .withShaderDefine("VEIL_PROBE_OFFSET", outside ? 1.2f : (receiver ? 0.5001f : 0.5f))
                .withShaderDefine("VEIL_PROBE_GREEN", receiver ? 1 : 0)
                .withCull(false)
                .withPrimitiveTopology(PrimitiveTopology.TRIANGLES)
                .withDepthStencilState(
                        new DepthStencilState(
                                outside ? CompareOp.ALWAYS_PASS : CompareOp.LESS_THAN, !receiver))
                .withColorTargetState(
                        new ColorTargetState(
                                Optional.empty(),
                                GpuFormat.RGBA8_UNORM,
                                ColorTargetState.WRITE_ALL))
                .build();
    }

    private static void record() {
        var runtime = VeilVulkanRuntime.currentOrNull();
        CASES.add(new Case("baseline", VeilScenePass.Raster.INHERIT, false, false, true, 0));
        CASES.add(
                new Case(
                        "constant",
                        raster(true, 4096f, null, null, null, null, null),
                        false,
                        false,
                        true,
                        1));
        CASES.add(
                new Case(
                        "slope",
                        raster(true, null, 1f, null, null, null, null),
                        true,
                        false,
                        true,
                        1));
        CASES.add(
                new Case(
                        "disabled",
                        raster(false, 4096f, null, null, null, null, null),
                        false,
                        false,
                        true,
                        0));
        if (EnabledRasterFeatures.enabled(
                runtime.vkDevice(), EnabledRasterFeatures.Feature.BIAS_CLAMP))
            CASES.add(
                    new Case(
                            "biasClamp",
                            raster(true, 4096f, null, 0.000001f, null, null, null),
                            false,
                            false,
                            true,
                            0));
        CASES.add(
                new Case(
                        "none",
                        raster(null, null, null, null, null, VeilScenePass.CullMode.NONE, null),
                        false,
                        false,
                        false,
                        0));
        CASES.add(
                new Case(
                        "front",
                        raster(null, null, null, null, null, VeilScenePass.CullMode.FRONT, null),
                        false,
                        false,
                        false,
                        -1));
        CASES.add(
                new Case(
                        "back",
                        raster(null, null, null, null, null, VeilScenePass.CullMode.BACK, null),
                        false,
                        false,
                        false,
                        -1));
        CASES.add(
                new Case(
                        "clockwise",
                        raster(
                                null,
                                null,
                                null,
                                null,
                                null,
                                VeilScenePass.CullMode.BACK,
                                VeilScenePass.FrontFace.CLOCKWISE),
                        false,
                        false,
                        false,
                        -1));
        CASES.add(
                new Case(
                        "counterClockwise",
                        raster(
                                null,
                                null,
                                null,
                                null,
                                null,
                                VeilScenePass.CullMode.BACK,
                                VeilScenePass.FrontFace.COUNTER_CLOCKWISE),
                        false,
                        false,
                        false,
                        -1));
        CASES.add(
                new Case(
                        "both",
                        raster(
                                null,
                                null,
                                null,
                                null,
                                null,
                                VeilScenePass.CullMode.FRONT_AND_BACK,
                                null),
                        false,
                        false,
                        false,
                        2));
        CASES.add(
                new Case(
                        "clip",
                        raster(null, null, null, null, false, null, null),
                        false,
                        true,
                        false,
                        2));
        if (EnabledRasterFeatures.enabled(
                runtime.vkDevice(), EnabledRasterFeatures.Feature.DEPTH_CLAMP))
            CASES.add(
                    new Case(
                            "depthClamp",
                            raster(null, null, null, null, true, null, null),
                            false,
                            true,
                            false,
                            0));
        CASES.add(new Case("restored", VeilScenePass.Raster.INHERIT, false, false, false, 0));
        var device = RenderSystem.getDevice();
        color =
                device.createTexture(
                        "scene raster probe color",
                        GpuTexture.USAGE_RENDER_ATTACHMENT | GpuTexture.USAGE_COPY_SRC,
                        GpuFormat.RGBA8_UNORM,
                        SIZE,
                        SIZE,
                        1,
                        1);
        depth =
                device.createTexture(
                        "scene raster probe depth",
                        GpuTexture.USAGE_RENDER_ATTACHMENT,
                        GpuFormat.D32_FLOAT,
                        SIZE,
                        SIZE,
                        1,
                        1);
        colorView = device.createTextureView(color);
        depthView = device.createTextureView(depth);
        readback =
                device.createBuffer(
                        () -> "scene raster probe readback",
                        GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                        (long) BYTES * CASES.size());
        var encoder = device.createCommandEncoder();
        Set<RenderPipeline> generated = Collections.newSetFromMap(new IdentityHashMap<>());
        var owner = new SceneRasterPipelines(runtime);
        Map<String, RenderPipeline> originals = new HashMap<>();
        try {
            for (int index = 0; index < CASES.size(); index++) {
                Case item = CASES.get(index);
                String key = item.sloped() + "/" + item.outside();
                RenderPipeline base =
                        originals.computeIfAbsent(
                                key,
                                unused ->
                                        pipeline(
                                                "base_" + originals.size(),
                                                item.sloped(),
                                                item.outside(),
                                                false));
                try (var scope = owner.begin(item.raster());
                        var pass =
                                encoder.createRenderPass(
                                        () -> "scene raster probe " + item.name(),
                                        colorView,
                                        Optional.of(new Vector4f(0, 0, 0, 1)),
                                        depthView,
                                        OptionalDouble.of(1.0))) {
                    RenderPipeline mapped = SceneRasterScope.resolve(base);
                    if (mapped != base) generated.add(mapped);
                    if (SceneRasterScope.resolve(base) != mapped)
                        throw new IllegalStateException("Variant cache did not reuse pipeline");
                    pass.setPipeline(base);
                    pass.draw(3, 1, 0, 0);
                }
                if (SceneRasterScope.active() || SceneRasterScope.resolve(base) != base)
                    throw new IllegalStateException("Raster scope escaped replay");
                if (item.receiver()) {
                    RenderPipeline receiver =
                            pipeline("receiver_" + index, item.sloped(), false, true);
                    try (var pass =
                            encoder.createRenderPass(
                                    () -> "scene raster receiver",
                                    colorView,
                                    Optional.empty(),
                                    depthView,
                                    OptionalDouble.empty())) {
                        pass.setPipeline(receiver);
                        pass.draw(3, 1, 0, 0);
                    }
                }
                encoder.copyTextureToBuffer(color, readback, (long) index * BYTES, () -> {}, 0);
            }
            fence = encoder.createFence();
        } finally {
            owner.close();
        }
        var cache = ((VulkanScenePipelineAccessor) runtime.device()).veil$scenePipelineCache();
        for (RenderPipeline variant : generated)
            if (cache.containsKey(variant))
                throw new IllegalStateException("Scene pipeline retained after owner close");
    }

    private static int value(ByteBuffer data, int index) {
        int offset = index * BYTES + (SIZE / 2 * SIZE + SIZE / 2) * 4;
        return Byte.toUnsignedInt(data.get(offset + 1)) > 128
                ? 1
                : Byte.toUnsignedInt(data.get(offset)) > 128 ? 0 : 2;
    }

    private static void verify(ByteBuffer data) throws Exception {
        Map<String, Integer> values = new LinkedHashMap<>();
        for (int i = 0; i < CASES.size(); i++) {
            Case item = CASES.get(i);
            int observed = value(data, i);
            values.put(item.name(), observed);
            if (item.expected() >= 0 && observed != item.expected())
                throw new IllegalStateException(
                        item.name() + " expected " + item.expected() + " observed " + observed);
        }
        if (Objects.equals(values.get("front"), values.get("back"))
                || Objects.equals(values.get("clockwise"), values.get("counterClockwise")))
            throw new IllegalStateException("Culling/winding did not change coverage");
        Path output = VeilPlatform.get().getGameDir().resolve("logs/scene-raster-probe.txt");
        Files.createDirectories(output.getParent());
        Files.writeString(output, values.toString() + "\n");
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }

    private static void close() {
        if (fence != null) fence.close();
        fence = null;
        if (readback != null) readback.close();
        readback = null;
        if (colorView != null) colorView.close();
        colorView = null;
        if (depthView != null) depthView.close();
        depthView = null;
        if (color != null) color.close();
        color = null;
        if (depth != null) depth.close();
        depth = null;
    }
}
