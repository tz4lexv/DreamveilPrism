package dev.veil.revive.client.scene.environment;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.api.VeilEnvironment;

import net.minecraft.client.Minecraft;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class EnvironmentInputs {
    public static final int CAPACITY = 128;
    private static GpuBuffer buffer;
    private static Object world;
    private static long previousTick;
    private static float wetness;
    private static DimensionMetadata dimension = DimensionMetadata.of(null);
    private static final ByteBuffer bytes =
            ByteBuffer.allocateDirect(CAPACITY).order(ByteOrder.nativeOrder());

    private EnvironmentInputs() {}

    public static void prepare(int storageUsage) {
        RenderSystem.assertOnRenderThread();
        var client = Minecraft.getInstance();
        var level = client.level;
        long tick = level == null ? 0 : level.getGameTime();
        if (world != level) {
            // Creator-supplied channels belong to the preceding world. A producer may explicitly
            // restore/re-publish them after this transition; never leak world A into world B.
            if (world != null) VeilEnvironment.resetCustom();
            world = level;
            dimension =
                    DimensionMetadata.of(
                            level == null ? null : level.dimension().identifier().toString());
            previousTick = tick;
            wetness = 0;
        }
        float partial = client.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        float rain = level == null ? 0 : level.getRainLevel(partial);
        float thunder = level == null ? 0 : level.getThunderLevel(partial);
        float seconds = Math.clamp((tick - previousTick) / 20f, 0, 1);
        wetness = Math.clamp(wetness + (rain > .01f ? rain * .15f : -.01f) * seconds, 0, 1);
        previousTick = tick;
        var wind = VeilEnvironment.wind();
        bytes.clear();
        for (int i = 0; i < CAPACITY; i += 8) bytes.putLong(i, 0);
        bytes.putInt(0, 0x56454e31).putInt(4, 1).putInt(8, CAPACITY);
        bytes.putInt(12, dimension.kind()).putInt(44, dimension.identifierHash());
        bytes.putFloat(16, rain).putFloat(20, thunder).putFloat(24, wetness).putFloat(28, partial);
        bytes.putFloat(32, wind.x())
                .putFloat(36, wind.z())
                .putFloat(40, (float) Math.hypot(wind.x(), wind.z()));
        bytes.putInt(48, (int) tick).putInt(52, (int) (tick >>> 32));
        bytes.putFloat(56, (tick % 24000) / 24000f);
        // VENV1 reserved region, now an optional generic scalar channel bank.
        // Bitmask distinguishes an explicitly supplied zero from an absent channel.
        VeilEnvironment.Channels channels = VeilEnvironment.channels();
        bytes.putInt(60, channels.mask());
        for (int channel = 0; channel < VeilEnvironment.CUSTOM_CHANNELS; channel++)
            bytes.putFloat(64 + channel * Float.BYTES, channels.value(channel));
        if (buffer == null)
            buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil environment",
                                    storageUsage | GpuBuffer.USAGE_COPY_DST,
                                    CAPACITY);
        RenderSystem.getDevice().createCommandEncoder().writeToBuffer(buffer.slice(), bytes);
    }

    public static float rain() {
        return bytes.getFloat(16);
    }

    public static GpuBuffer buffer() {
        if (buffer == null) throw new IllegalStateException("Environment is not prepared");
        return buffer;
    }

    public static void close() {
        if (buffer != null) buffer.close();
        buffer = null;
        world = null;
        dimension = DimensionMetadata.of(null);
        wetness = 0;
        // The environmental channels must not survive a client/world teardown by accident.
        VeilEnvironment.resetCustom();
    }
}
