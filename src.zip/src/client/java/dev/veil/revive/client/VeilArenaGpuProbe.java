package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import java.nio.ByteBuffer;

final class VeilArenaGpuProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment() && Boolean.getBoolean("veil.arenaProbe");
    private static VeilPersistentStagingBuffer staging;
    private static VeilManagedGpuArena<Object> arena;
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static boolean started, complete;
    private static int recyclingSteps;
    private static final java.util.List<FailureProof> failureProofs = new java.util.ArrayList<>();

    static void requireComplete() {
        if (ENABLED && !complete) throw new IllegalStateException("arena GPU probe incomplete");
    }

    static void tick() {
        if (!ENABLED || complete) return;
        if (!started) {
            started = true;
            verifyAdmission();
            verifyRelocationFailures();
            staging = new VeilPersistentStagingBuffer("Veil arena probe staging", 4096);
            arena =
                    new VeilManagedGpuArena<>(
                            "Veil arena probe", GpuBuffer.USAGE_VERTEX, 8192, 16, staging);
            Object a = new Object(), b = new Object(), c = new Object();
            var callbackOwners = new java.util.IdentityHashMap<Object, Boolean>();
            java.util.function.Consumer<Object> callback = owner -> callbackOwners.put(owner, true);
            for (int i = 0; i < 3; i++) {
                int size = i == 0 ? 64 : 256;
                ByteBuffer bytes = ByteBuffer.allocateDirect(size);
                for (int j = 0; j < size; j++) bytes.put((byte) (i + 1));
                bytes.flip();
                if (!arena.addAllocation(i == 0 ? a : i == 1 ? b : c, callback, bytes))
                    throw new IllegalStateException("arena GPU probe admission failed");
            }
            var device = RenderSystem.getDevice();
            try (var uploader = staging.startUploading(device.createCommandEncoder())) {
                arena.uploadStagedAllocations(device, uploader);
            }
            callbackOwners.clear();
            Object replacementOwner = new Object();
            arena.rekeyAllocation(b, replacementOwner);
            if (arena.getAllocation(b) != null || arena.getAllocation(replacementOwner) == null)
                throw new IllegalStateException("arena rekey did not preserve allocation");
            b = replacementOwner;
            arena.removeAllocation(a);
            arena.defragment(512);
            if (callbackOwners.size() != 2
                    || !callbackOwners.containsKey(b)
                    || !callbackOwners.containsKey(c))
                throw new IllegalStateException("relocation callback used stale owner key");
            if (Boolean.getBoolean("veil.boundedArenaDefrag")
                    && (!arena.telemetry().contains("arena_defrag_inspected_total=2\n")
                            || !arena.telemetry().contains("arena_defrag_bounded=true\n")))
                throw new IllegalStateException("bounded arena planner route not exercised");
            ReviveMod.LOGGER.info(
                    "Veil arena defrag route: {}", arena.telemetry().replace('\n', ' '));
            if (arena.getAllocation(b).offset() != 0 || arena.getAllocation(c).offset() != 256)
                throw new IllegalStateException("arena GPU relocation did not compact");
            if (Boolean.getBoolean("veil.reuseEmptyDefragPlans")
                    && !Boolean.getBoolean("veil.boundedArenaDefrag")) {
                arena.defragment(512);
                arena.defragment(512);
                if (!arena.telemetry().contains("arena_defrag_empty_plan_skips_total=1\n")
                        || callbackOwners.size() != 2)
                    throw new IllegalStateException(
                            "Empty plan reuse changed relocation callbacks");
                ReviveMod.LOGGER.info(
                        "Veil empty defrag plan reuse: PASS (same layout/budget skipped, callbacks unchanged)");
            }
            var before = arena.getAllocation(b);
            long capacity = arena.capacityRevision();
            int[] prepared = {0};
            if (arena.tryRestageAllocation(
                                    b,
                                    1024,
                                    () -> {
                                        prepared[0]++;
                                        return ByteBuffer.allocateDirect(1024);
                                    })
                            != VeilManagedGpuArena.Admission.CAPACITY
                    || prepared[0] != 0)
                throw new IllegalStateException("Oversize restage prepared payload");
            var replacement = ByteBuffer.allocateDirect(128);
            for (int i = 0; i < 128; i++) replacement.put((byte) 7);
            replacement.flip();
            if (arena.tryRestageAllocation(b, 128, () -> replacement)
                            != VeilManagedGpuArena.Admission.ADDED
                    || arena.getAllocation(b) != null)
                throw new IllegalStateException("Pending restage was published early");
            try (var uploader = staging.startUploading(device.createCommandEncoder())) {
                arena.uploadStagedAllocations(device, uploader);
            }
            if (!arena.getAllocation(b).equals(before) || arena.capacityRevision() != capacity)
                throw new IllegalStateException("Restage changed allocation identity or capacity");
            readback =
                    device.createBuffer(
                            () -> "Veil arena probe readback",
                            GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                            512);
            var encoder = device.createCommandEncoder();
            encoder.copyToBuffer(
                    arena.getGpuBuffer(arena.getAllocation(b)).slice(0, 512), readback.slice());
            fence = encoder.createFence();
        } else if (recyclingSteps < 12) {
            Object temporary = new Object();
            if (!arena.addAllocation(temporary, null, ByteBuffer.allocateDirect(1024)))
                throw new IllegalStateException("staging ring failed to recycle handles");
            try (var uploader =
                    staging.startUploading(RenderSystem.getDevice().createCommandEncoder())) {
                arena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
            }
            arena.removeAllocation(temporary);
            recyclingSteps++;
        } else if (fence != null && fence.awaitCompletion(0)) {
            for (var proof : failureProofs) if (!proof.fence().awaitCompletion(0)) return;
            for (var proof : failureProofs) {
                try (var mapping = proof.readback().map(true, false)) {
                    for (int i = 0; i < 1024; i++) {
                        byte expected = (byte) (i % 512 < 256 ? 2 : 3);
                        if (mapping.data().get(i) != expected)
                            throw new IllegalStateException(
                                    "failed transfer changed GPU bytes at " + i);
                    }
                }
                proof.fence().close();
                proof.readback().close();
                proof.arena().close();
                proof.staging().close();
            }
            failureProofs.clear();
            ReviveMod.LOGGER.info(
                    "Veil arena transfer recovery: PASS (4 checkpoints, 4096 GPU bytes preserved before/after recovery, metadata/callbacks unchanged on failure)");
            try (var mapping = readback.map(true, false)) {
                for (int i = 0; i < 512; i++) {
                    if (mapping.data().get(i) != (byte) (i < 128 ? 7 : i < 256 ? 2 : 3))
                        throw new IllegalStateException("GPU defrag corrupted byte " + i);
                }
            }
            fence.close();
            readback.close();
            arena.close();
            staging.close();
            complete = true;
            ReviveMod.LOGGER.info(
                    "Veil arena GPU probe: PASS (two live relocations, reserved allocation restage, 512 bytes preserved)");
        }
    }

    private record FailureProof(
            VeilManagedGpuArena<Object> arena,
            VeilPersistentStagingBuffer staging,
            GpuBuffer readback,
            GpuFence fence) {}

    private static void verifyRelocationFailures() {
        var device = RenderSystem.getDevice();
        for (var selected : VeilManagedGpuArena.RelocationStage.values()) {
            var temporaryStaging =
                    new VeilPersistentStagingBuffer("Veil transfer failure staging", 4096);
            boolean[] inject = {true};
            var failure = new IllegalStateException("injected arena transfer failure");
            var temporaryArena =
                    new VeilManagedGpuArena<Object>(
                            "Veil transfer failure probe",
                            GpuBuffer.USAGE_VERTEX,
                            8192,
                            16,
                            temporaryStaging,
                            1,
                            stage -> {
                                if (inject[0] && stage == selected) throw failure;
                            });
            Object a = new Object(), b = new Object(), c = new Object();
            int[] callbacks = {0};
            for (int index = 0; index < 3; index++) {
                int size = index == 0 ? 64 : 256;
                var bytes = ByteBuffer.allocateDirect(size);
                for (int i = 0; i < size; i++) bytes.put((byte) (index + 1));
                bytes.flip();
                if (!temporaryArena.addAllocation(
                        index == 0 ? a : index == 1 ? b : c, owner -> callbacks[0]++, bytes))
                    throw new IllegalStateException("failure fixture admission failed");
            }
            try (var uploader = temporaryStaging.startUploading(device.createCommandEncoder())) {
                temporaryArena.uploadStagedAllocations(device, uploader);
            }
            callbacks[0] = 0;
            temporaryArena.removeAllocation(a);
            var beforeB = temporaryArena.getAllocation(b);
            var beforeC = temporaryArena.getAllocation(c);
            long revision = temporaryArena.capacityRevision();
            try {
                temporaryArena.defragment(512);
                throw new IllegalStateException("injected transfer failure not reached");
            } catch (IllegalStateException actual) {
                if (actual != failure) throw actual;
            }
            if (!beforeB.equals(temporaryArena.getAllocation(b))
                    || !beforeC.equals(temporaryArena.getAllocation(c))
                    || temporaryArena.capacityRevision() != revision
                    || callbacks[0] != 0)
                throw new IllegalStateException("failed transfer published metadata or callback");
            var result =
                    device.createBuffer(
                            () -> "Veil transfer recovery readback",
                            GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                            1024);
            var encoder = device.createCommandEncoder();
            var buffer = temporaryArena.getGpuBuffer(beforeB);
            encoder.copyToBuffer(buffer.slice(beforeB.offset(), 512), result.slice(0, 512));
            inject[0] = false;
            temporaryArena.defragment(512);
            if (temporaryArena.getAllocation(b).offset() != 0
                    || temporaryArena.getAllocation(c).offset() != 256
                    || callbacks[0] != 2)
                throw new IllegalStateException("failed transfer did not recover");
            encoder.copyToBuffer(buffer.slice(0, 512), result.slice(512, 512));
            failureProofs.add(
                    new FailureProof(
                            temporaryArena, temporaryStaging, result, encoder.createFence()));
        }
    }

    private static void verifyAdmission() {
        try (var admissionStaging =
                        new VeilPersistentStagingBuffer("Veil admission staging", 4096);
                var admissionArena =
                        new VeilManagedGpuArena<Object>(
                                "Veil admission probe",
                                GpuBuffer.USAGE_VERTEX,
                                256,
                                16,
                                admissionStaging)) {
            Object[] owners = new Object[8];
            int[] prepared = {0};
            java.util.function.Supplier<ByteBuffer> producer =
                    () -> {
                        prepared[0]++;
                        return ByteBuffer.allocateDirect(256);
                    };
            for (int i = 0; i < owners.length; i++) {
                owners[i] = new Object();
                if (admissionArena.tryAddAllocation(owners[i], null, 256, producer)
                        != VeilManagedGpuArena.Admission.ADDED)
                    throw new IllegalStateException("Arena saturation setup failed");
            }
            long revision = admissionArena.capacityRevision();
            for (int i = 0; i < 1000; i++) {
                if (admissionArena.tryAddAllocation(new Object(), null, 256, producer)
                        != VeilManagedGpuArena.Admission.CAPACITY)
                    throw new IllegalStateException("Full arena admitted an allocation");
            }
            if (prepared[0] != 8 || admissionArena.capacityRevision() != revision)
                throw new IllegalStateException("Full arena prepared rejected payloads");
            admissionArena.removeAllocation(owners[0]);
            if (admissionArena.capacityRevision() <= revision)
                throw new IllegalStateException("Arena release did not signal capacity");
            var replacement = new Object();
            if (admissionArena.tryAddAllocation(replacement, null, 256, producer)
                            != VeilManagedGpuArena.Admission.ADDED
                    || prepared[0] != 9)
                throw new IllegalStateException("Arena admission did not recover after release");
            try (var uploader =
                    admissionStaging.startUploading(
                            RenderSystem.getDevice().createCommandEncoder())) {
                admissionArena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
            }
            if (admissionArena.getAllocation(replacement) == null)
                throw new IllegalStateException("Replacement arena allocation was not uploaded");
        }
        ReviveMod.LOGGER.info(
                "Veil arena admission probe: PASS (1000 full-arena attempts prepare zero payloads, release and replacement upload recover)");
    }
}
