package dev.veil.revive.client.shaderpack.parsing;

import static dev.veil.revive.client.shaderpack.parsing.CommandParser.*;
import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.*;
import static dev.veil.revive.client.shaderpack.parsing.PipelineStateParser.*;
import static dev.veil.revive.client.shaderpack.parsing.ProgramParser.stage;
import static dev.veil.revive.client.shaderpack.parsing.SceneCameraParser.*;
import static dev.veil.revive.client.shaderpack.parsing.SettingsExpressions.*;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import dev.veil.api.VeilDraw;
import dev.veil.api.VeilScenePass;
import dev.veil.api.VeilTransfer;
import dev.veil.api.VeilVertexLayout;
import dev.veil.revive.client.VeilShaderPack.Binding;
import dev.veil.revive.client.VeilShaderPack.BindingAccess;
import dev.veil.revive.client.VeilShaderPack.BlendState;
import dev.veil.revive.client.VeilShaderPack.ClearColor;
import dev.veil.revive.client.VeilShaderPack.ColorAttachment;
import dev.veil.revive.client.VeilShaderPack.ColorChannel;
import dev.veil.revive.client.VeilShaderPack.CompareOp;
import dev.veil.revive.client.VeilShaderPack.DepthAttachment;
import dev.veil.revive.client.VeilShaderPack.Dispatch;
import dev.veil.revive.client.VeilShaderPack.Geometry;
import dev.veil.revive.client.VeilShaderPack.LoadOp;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.PipelineState;
import dev.veil.revive.client.VeilShaderPack.Setting;
import dev.veil.revive.client.VeilShaderPack.StoreOp;
import dev.veil.revive.client.VeilShaderPack.Trace;
import dev.veil.revive.client.VeilShaderStage;
import dev.veil.revive.client.VeilSpecializationValues;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class PassParser {
    private PassParser() {}

    public record ParsedPasses(List<Pass> passes, boolean disabled) {}

    public static ParsedPasses parsePasses(
            JsonObject root, String namespace, int manifestAbi, Map<String, Setting> settings) {
        var passes = new ArrayList<Pass>();
        boolean disabledPasses = false;
        for (JsonElement element : root.getAsJsonArray("passes")) {
            JsonObject item = element.getAsJsonObject();
            fields(
                    item,
                    "name",
                    "program",
                    "type",
                    "bindings",
                    "target",
                    "depth",
                    "colors",
                    "depthAttachment",
                    "geometry",
                    "pipeline",
                    "dispatch",
                    "frameData",
                    "cameraData",
                    "sceneProjectionData",
                    "specialization",
                    "after",
                    "enabled",
                    "vertexLayout",
                    "draws",
                    "transfers",
                    "scene",
                    "sceneCamera",
                    "trace",
                    "maxRecursionDepth");
            if (item.has("enabled")) {
                JsonElement condition = item.get("enabled");
                boolean enabled;
                if (condition.isJsonObject()) {
                    var selection = condition.getAsJsonObject();
                    fields(selection, "setting", "equals");
                    Setting setting = settings.get(selection.get("setting").getAsString());
                    JsonElement expected = selection.get("equals");
                    if (setting != null && setting.type().equals("bool")) {
                        if (expected == null
                                || !expected.isJsonPrimitive()
                                || !expected.getAsJsonPrimitive().isBoolean())
                            throw new IllegalArgumentException(
                                    "Pass bool selector requires a boolean equals value");
                        enabled = Boolean.parseBoolean(setting.value()) == expected.getAsBoolean();
                    } else {
                        if (setting == null
                                || expected == null
                                || !expected.isJsonPrimitive()
                                || !expected.getAsJsonPrimitive().isString()
                                || !setting.type().equals("enum")
                                || !setting.options().contains(expected.getAsString())) {
                            throw new IllegalArgumentException(
                                    "Pass enabled selector requires a declared enum option");
                        }
                        enabled = setting.value().equals(selection.get("equals").getAsString());
                    }
                } else if (condition.isJsonPrimitive()
                        && condition.getAsJsonPrimitive().isBoolean())
                    enabled = condition.getAsBoolean();
                else if (condition.isJsonPrimitive() && condition.getAsJsonPrimitive().isString()) {
                    Setting setting = settings.get(condition.getAsString());
                    if (setting == null || !setting.type().equals("bool"))
                        throw new IllegalArgumentException(
                                "Pass enabled requires a declared bool setting: " + condition);
                    enabled = Boolean.parseBoolean(setting.value());
                } else
                    throw new IllegalArgumentException(
                            "Pass enabled requires a bool, bool setting name or enum selector");
                if (!enabled) {
                    disabledPasses = true;
                    continue;
                }
            }
            String type = item.get("type").getAsString();
            if (!type.equals("compute")
                    && !type.equals("graphics")
                    && !type.equals("raytrace")
                    && !type.equals("transfer")
                    && !type.equals("scene"))
                throw new IllegalArgumentException("Unsupported pass type " + type);
            boolean compute = type.equals("compute");
            boolean raytrace = type.equals("raytrace");
            boolean transfer = type.equals("transfer");
            boolean scenePass = type.equals("scene");
            boolean graphics = type.equals("graphics");
            if (raytrace && manifestAbi < 12)
                throw new IllegalArgumentException("Raytrace passes require Veil shader ABI 12+");
            if ((scenePass || item.has("sceneCamera")) && manifestAbi < 11) {
                throw new IllegalArgumentException(
                        "Custom scene passes require Veil shader ABI 11+");
            }
            if ((item.has("vertexLayout") || item.has("draws") || item.has("transfers") || transfer)
                    && manifestAbi < 11) {
                throw new IllegalArgumentException(
                        "Graphics commands and transfer passes require Veil shader ABI 11+");
            }
            var bindings = new LinkedHashMap<Integer, Binding>();
            for (var binding : object(item, "bindings").entrySet()) {
                JsonObject value = binding.getValue().getAsJsonObject();
                fields(
                        value,
                        "resource",
                        "resources",
                        "access",
                        "previous",
                        "historyOffset",
                        "mip",
                        "baseLayer",
                        "layerCount",
                        "offset",
                        "range");
                if ((value.has("offset") || value.has("range")) && manifestAbi < 11)
                    throw new IllegalArgumentException(
                            "Buffer binding offsets/ranges require ABI 11+");
                if (value.has("range") && longInteger(value, "range", 0) <= 0)
                    throw new IllegalArgumentException("Buffer binding range must be positive");
                if (value.has("resource") == value.has("resources")) {
                    throw new IllegalArgumentException(
                            "Binding must declare exactly one of resource/resources");
                }
                String accessName = value.get("access").getAsString();
                BindingAccess access =
                        switch (accessName) {
                            case "read" -> BindingAccess.READ;
                            case "write" -> BindingAccess.WRITE;
                            case "readwrite" -> BindingAccess.READ_WRITE;
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported binding access " + accessName);
                        };
                List<String> bindingResources;
                if (value.has("resource")) {
                    bindingResources = List.of(resourceName(value.get("resource").getAsString()));
                } else {
                    var parsedResources = new ArrayList<String>();
                    value.getAsJsonArray("resources")
                            .forEach(
                                    elementValue ->
                                            parsedResources.add(
                                                    resourceName(elementValue.getAsString())));
                    bindingResources = List.copyOf(parsedResources);
                }
                if (value.has("previous") && value.has("historyOffset")) {
                    throw new IllegalArgumentException(
                            "Binding cannot combine previous and historyOffset");
                }
                if (value.has("historyOffset") && manifestAbi < 11) {
                    throw new IllegalArgumentException(
                            "Binding historyOffset requires Veil shader ABI 11+");
                }
                int historyOffset =
                        value.has("historyOffset")
                                ? integer(value, "historyOffset", 0)
                                : value.has("previous") && value.get("previous").getAsBoolean()
                                        ? 1
                                        : 0;
                int index = Integer.parseInt(binding.getKey());
                if (index < 0
                        || bindings.putIfAbsent(
                                        index,
                                        new Binding(
                                                bindingResources,
                                                access,
                                                historyOffset,
                                                integer(value, "mip", -1),
                                                integer(value, "baseLayer", 0),
                                                integer(value, "layerCount", 0),
                                                longInteger(value, "offset", 0),
                                                longInteger(value, "range", 0)))
                                != null) {
                    throw new IllegalArgumentException("Invalid or duplicate binding " + index);
                }
            }
            var specs =
                    new EnumMap<VeilShaderStage, VeilSpecializationValues>(VeilShaderStage.class);
            for (var stage : object(item, "specialization").entrySet()) {
                var values = new LinkedHashMap<Integer, VeilSpecializationValues.Value>();
                for (var value : stage.getValue().getAsJsonObject().entrySet()) {
                    Setting setting = settings.get(value.getValue().getAsString());
                    if (setting == null)
                        throw new IllegalArgumentException(
                                "Unknown shader setting " + value.getValue());
                    int index = Integer.parseInt(value.getKey());
                    if (values.putIfAbsent(index, setting.specialization()) != null)
                        throw new IllegalArgumentException("Duplicate specialization ID " + index);
                }
                specs.put(stage(stage.getKey()), VeilSpecializationValues.of(values));
            }
            Dispatch dispatch = null;
            if (compute) {
                JsonElement dispatchElement = item.get("dispatch");
                if (dispatchElement == null)
                    throw new IllegalArgumentException("Compute pass requires dispatch");
                if (dispatchElement.isJsonArray()) {
                    var groups = dispatchElement.getAsJsonArray();
                    if (groups.size() != 3)
                        throw new IllegalArgumentException(
                                "Compute dispatch requires three group counts");
                    dispatch =
                            Dispatch.fixed(
                                    groups.get(0).getAsBigDecimal().intValueExact(),
                                    groups.get(1).getAsBigDecimal().intValueExact(),
                                    groups.get(2).getAsBigDecimal().intValueExact());
                } else if (dispatchElement.isJsonObject()) {
                    JsonObject dispatchObject = dispatchElement.getAsJsonObject();
                    fields(dispatchObject, "resource", "mip", "localSize", "indirect", "offset");
                    if (dispatchObject.has("indirect")) {
                        if (dispatchObject.has("resource")
                                || dispatchObject.has("mip")
                                || dispatchObject.has("localSize")) {
                            throw new IllegalArgumentException(
                                    "Indirect dispatch cannot also declare resource/mip/localSize");
                        }
                        dispatch =
                                Dispatch.indirect(
                                        resourceName(dispatchObject.get("indirect").getAsString()),
                                        dispatchObject.has("offset")
                                                ? dispatchObject
                                                        .get("offset")
                                                        .getAsBigDecimal()
                                                        .longValueExact()
                                                : 0L);
                    } else {
                        if (!dispatchObject.has("resource") || dispatchObject.has("offset")) {
                            throw new IllegalArgumentException(
                                    "Resource dispatch requires resource/localSize; indirect dispatch uses indirect/offset");
                        }
                        String dispatchResource =
                                resourceName(dispatchObject.get("resource").getAsString());
                        var localSize = dispatchObject.getAsJsonArray("localSize");
                        if (localSize == null || localSize.size() != 3) {
                            throw new IllegalArgumentException(
                                    "Resource dispatch requires localSize [x,y,z]");
                        }
                        dispatch =
                                Dispatch.resource(
                                        dispatchResource,
                                        integer(dispatchObject, "mip", 0),
                                        localSize.get(0).getAsBigDecimal().intValueExact(),
                                        localSize.get(1).getAsBigDecimal().intValueExact(),
                                        localSize.get(2).getAsBigDecimal().intValueExact());
                    }
                } else {
                    throw new IllegalArgumentException(
                            "Compute dispatch must be [x,y,z], {resource,localSize} or {indirect,offset}");
                }
                if (item.has("target") || item.has("colors") || item.has("depthAttachment")) {
                    throw new IllegalArgumentException("Compute pass cannot have attachments");
                }
            } else if (item.has("dispatch")) {
                throw new IllegalArgumentException("Only compute passes may declare dispatch");
            }
            Trace trace = null;
            if (raytrace) {
                JsonElement traceElement = item.get("trace");
                if (traceElement == null)
                    throw new IllegalArgumentException("Raytrace pass requires trace");
                if (traceElement.isJsonArray()) {
                    JsonArray dimensions = traceElement.getAsJsonArray();
                    if (dimensions.size() != 3)
                        throw new IllegalArgumentException(
                                "Ray trace dimensions require [width,height,depth]");
                    trace =
                            Trace.fixed(
                                    dimensions.get(0).getAsBigDecimal().intValueExact(),
                                    dimensions.get(1).getAsBigDecimal().intValueExact(),
                                    dimensions.get(2).getAsBigDecimal().intValueExact());
                } else if (traceElement.isJsonObject()) {
                    JsonObject traceObject = traceElement.getAsJsonObject();
                    fields(traceObject, "resource", "mip");
                    if (!traceObject.has("resource"))
                        throw new IllegalArgumentException("Resource ray trace requires resource");
                    trace =
                            Trace.resource(
                                    resourceName(traceObject.get("resource").getAsString()),
                                    integer(traceObject, "mip", 0));
                } else
                    throw new IllegalArgumentException(
                            "Ray trace must be [width,height,depth] or {resource,mip}");
            } else if (item.has("trace") || item.has("maxRecursionDepth")) {
                throw new IllegalArgumentException(
                        "Only raytrace passes may declare trace or maxRecursionDepth");
            }
            Geometry geometry = Geometry.FULLSCREEN;
            if (graphics && item.has("geometry")) {
                geometry =
                        switch (item.get("geometry").getAsString()) {
                            case "fullscreen" -> Geometry.FULLSCREEN;
                            case "custom" -> Geometry.CUSTOM;
                            case "fluid_water" -> Geometry.FLUID_WATER;
                            case "fluid_water_physical" -> Geometry.FLUID_WATER_PHYSICAL;
                            case "fluid_lava" -> Geometry.FLUID_LAVA;
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported graphics geometry "
                                                    + item.get("geometry"));
                        };
            }
            if (graphics && item.has("draws") && !item.has("geometry")) geometry = Geometry.CUSTOM;
            if (compute && (item.has("geometry") || item.has("depth"))) {
                throw new IllegalArgumentException("Compute pass cannot declare geometry/depth");
            }
            if (compute && item.has("pipeline"))
                throw new IllegalArgumentException(
                        "Compute pass cannot declare graphics pipeline state");
            if (raytrace
                    && (item.has("target")
                            || item.has("depth")
                            || item.has("colors")
                            || item.has("depthAttachment")
                            || item.has("geometry")
                            || item.has("pipeline")
                            || item.has("vertexLayout")
                            || item.has("draws")
                            || item.has("transfers")
                            || item.has("scene")
                            || item.has("sceneCamera"))) {
                throw new IllegalArgumentException(
                        "Raytrace pass cannot declare graphics, transfer or scene fields");
            }
            if (item.has("colors") && item.has("target"))
                throw new IllegalArgumentException(
                        "Graphics pass cannot combine target and colors");
            if (item.has("depthAttachment") && item.has("depth"))
                throw new IllegalArgumentException(
                        "Graphics pass cannot combine depth and depthAttachment");
            if ((item.has("colors") || item.has("depthAttachment")) && manifestAbi < 11) {
                throw new IllegalArgumentException(
                        "Generic graphics attachments require Veil shader ABI 11+");
            }
            if (item.has("pipeline") && manifestAbi < 11) {
                throw new IllegalArgumentException(
                        "Graphics pipeline state requires Veil shader ABI 11+");
            }
            if (transfer
                    && (item.has("program")
                            || item.has("bindings")
                            || item.has("target")
                            || item.has("depth")
                            || item.has("colors")
                            || item.has("depthAttachment")
                            || item.has("geometry")
                            || item.has("pipeline")
                            || item.has("frameData")
                            || item.has("cameraData")
                            || item.has("sceneProjectionData")
                            || item.has("specialization")
                            || item.has("vertexLayout")
                            || item.has("draws"))) {
                throw new IllegalArgumentException(
                        "Transfer pass cannot declare graphics or compute fields");
            }
            if (scenePass
                    && (!item.has("scene")
                            || item.has("program")
                            || item.has("bindings")
                            || item.has("target")
                            || item.has("depth")
                            || item.has("geometry")
                            || item.has("pipeline")
                            || item.has("dispatch")
                            || item.has("frameData")
                            || item.has("cameraData")
                            || item.has("sceneProjectionData")
                            || item.has("specialization")
                            || item.has("vertexLayout")
                            || item.has("draws")
                            || item.has("transfers")
                            || item.has("sceneCamera"))) {
                throw new IllegalArgumentException(
                        "Custom scene pass requires scene, colors and depthAttachment only");
            }
            if (!transfer && !scenePass && !item.has("program"))
                throw new IllegalArgumentException("Graphics/compute pass requires program");
            if (transfer && !item.has("transfers"))
                throw new IllegalArgumentException("Transfer pass requires transfers");
            var colors = new ArrayList<ColorAttachment>();
            if ((graphics || scenePass) && item.has("colors")) {
                for (JsonElement colorElement : item.getAsJsonArray("colors"))
                    colors.add(colorAttachment(colorElement.getAsJsonObject()));
            } else if (graphics && item.has("target")) {
                LoadOp load = geometry.fluid() ? LoadOp.LOAD : LoadOp.CLEAR;
                colors.add(
                        new ColorAttachment(
                                resourceName(item.get("target").getAsString()),
                                0,
                                0,
                                load,
                                StoreOp.STORE,
                                load == LoadOp.CLEAR ? new ClearColor(0, 0, 0, 1) : null,
                                BlendState.DISABLED,
                                Set.of(
                                        ColorChannel.R,
                                        ColorChannel.G,
                                        ColorChannel.B,
                                        ColorChannel.A)));
            }
            DepthAttachment depthAttachment = null;
            if ((graphics || scenePass) && item.has("depthAttachment")) {
                depthAttachment = depthAttachment(item.getAsJsonObject("depthAttachment"));
            } else if (graphics && item.has("depth")) {
                depthAttachment =
                        new DepthAttachment(
                                resourceName(item.get("depth").getAsString()),
                                0,
                                0,
                                LoadOp.LOAD,
                                StoreOp.STORE,
                                1.0f,
                                0,
                                true,
                                false,
                                CompareOp.GREATER_OR_EQUAL);
            }
            VeilVertexLayout vertexLayout =
                    item.has("vertexLayout")
                            ? vertexLayout(item.getAsJsonObject("vertexLayout"))
                            : VeilVertexLayout.EMPTY;
            List<VeilDraw> draws =
                    item.has("draws") ? draws(item.getAsJsonArray("draws")) : List.of();
            List<VeilTransfer> transfers =
                    item.has("transfers") ? transfers(item.getAsJsonArray("transfers")) : List.of();
            VeilScenePass scene =
                    scenePass ? scenePass(item.getAsJsonObject("scene"), settings) : null;
            passes.add(
                    new Pass(
                            resourceName(item.get("name").getAsString()),
                            transfer || scenePass
                                    ? null
                                    : asset(namespace, item.get("program").getAsString()),
                            compute,
                            raytrace,
                            transfer,
                            scene,
                            bindings,
                            colors,
                            depthAttachment,
                            geometry,
                            dispatch,
                            trace,
                            item.has("maxRecursionDepth")
                                    ? integer(item, "maxRecursionDepth", 1)
                                    : 1,
                            item.has("frameData") && item.get("frameData").getAsBoolean(),
                            item.has("cameraData") && item.get("cameraData").getAsBoolean(),
                            item.has("sceneProjectionData")
                                    && item.get("sceneProjectionData").getAsBoolean(),
                            item.has("sceneCamera")
                                    ? resourceName(item.get("sceneCamera").getAsString())
                                    : null,
                            specs,
                            Set.copyOf(strings(item, "after")),
                            item.has("pipeline")
                                    ? pipelineState(item.getAsJsonObject("pipeline"), settings)
                                    : PipelineState.DEFAULT,
                            vertexLayout,
                            draws,
                            transfers));
        }
        return new ParsedPasses(passes, disabledPasses);
    }
}
