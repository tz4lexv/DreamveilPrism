package dev.veil.revive.client;

import dev.veil.api.VeilScenePass;

final class VeilSceneCameraMath {
    private VeilSceneCameraMath() {}

    static VeilSceneCameraAbi.Snapshot create(
            VeilScenePass.Camera camera,
            VeilCameraAbi.Snapshot main,
            float sunAngle,
            int width,
            int height,
            boolean zeroToOne) {
        return dev.veil.revive.client.scene.inputs.SceneCameraMath.create(
                camera, main, sunAngle, width, height, zeroToOne);
    }
}
