package dev.veil.revive.client;

import static org.lwjgl.vulkan.KHRRayTracingPipeline.VK_PIPELINE_BIND_POINT_RAY_TRACING_KHR;
import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;
import com.mojang.blaze3d.vulkan.VulkanGpuSampler;
import com.mojang.blaze3d.vulkan.VulkanGpuTexture;
import com.mojang.blaze3d.vulkan.VulkanGpuTextureView;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilResourceUsage;
import dev.veil.api.VeilScenePass;
import dev.veil.api.VeilVertexLayout;
import dev.veil.revive.client.shaderpack.history.PackHistory;
import dev.veil.revive.client.shaderpack.runtime.CreatorSceneRequirements;
import dev.veil.revive.client.shaderpack.runtime.DrawPassExecutor;
import dev.veil.revive.client.shaderpack.runtime.GraphicsPassExecutor;
import dev.veil.revive.client.shaderpack.runtime.GraphicsPassExecutor.AttachmentView;
import dev.veil.revive.client.shaderpack.runtime.PackHostRequirements;
import dev.veil.revive.client.shaderpack.runtime.PackResourceSet;
import dev.veil.revive.client.shaderpack.runtime.TransferCapabilities;
import dev.veil.revive.client.shaderpack.runtime.TransferPassExecutor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.state.level.CameraRenderState;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.KHRDynamicRendering;
import org.lwjgl.vulkan.VkBufferCopy;
import org.lwjgl.vulkan.VkBufferImageCopy;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;
import org.lwjgl.vulkan.VkRect2D;
import org.lwjgl.vulkan.VkRenderingAttachmentInfo;
import org.lwjgl.vulkan.VkRenderingInfo;
import org.lwjgl.vulkan.VkViewport;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

final class VeilShaderPackRuntime implements VeilShaderReload.Generation {
    private java.util.UUID simulationGeneration;
    private dev.veil.api.VeilSimulationCheckpoint initialCheckpoint;
    private java.util.concurrent.CompletableFuture<Void> initialCheckpointCompletion;

    /** CPU data must be loaded before the generation's first execution; no disk work in render. */
    java.util.concurrent.CompletableFuture<Void> queueInitialSimulationCheckpoint(
            dev.veil.api.VeilSimulationCheckpoint checkpoint) {
        RenderSystem.assertOnRenderThread();
        java.util.Objects.requireNonNull(checkpoint, "checkpoint");
        if (closed || frames != 0 || resources.initialized || initialCheckpoint != null)
            throw new IllegalStateException(
                    "Initial checkpoint must precede the first graph execution");
        validateSimulationCheckpoint(checkpoint, graphPlan.initialImageStates());
        initialCheckpoint = checkpoint;
        initialCheckpointCompletion = new java.util.concurrent.CompletableFuture<>();
        return initialCheckpointCompletion;
    }

    private void validateSimulationCheckpoint(
            dev.veil.api.VeilSimulationCheckpoint checkpoint,
            Map<String, List<VeilRenderGraph.ImageState>> states) {
        for (var field : checkpoint.fields().values()) {
            var selection = field.selection();
            var declaration = prepared.pack().resources().get(selection.resource());
            if (declaration == null || declaration.format() != field.format())
                throw new IllegalArgumentException(
                        "Checkpoint original format mismatch: " + selection.resource());
            simulationRestoreLayout(
                    selection.resource(), selection.mip(), selection.layer(), field.data());
            String physical = graphPlan.physical(selection.resource(), phase);
            dev.veil.revive.client.graphics.synchronization.ImageTransferTransitions.plan(
                    physical,
                    states.getOrDefault(physical, List.of()),
                    VeilRenderGraph.Subresource.image(selection.mip(), 1, selection.layer(), 1),
                    VeilRenderGraph.State.of(VeilRenderGraph.Access.TRANSFER_WRITE));
        }
    }

    private void applyInitialSimulationCheckpoint() {
        if (initialCheckpoint == null) return;
        var checkpoint = initialCheckpoint;
        var completion = initialCheckpointCompletion;
        initialCheckpoint = null;
        initialCheckpointCompletion = null;
        var states = graphPlan.initialImageStates();
        try {
            // Revalidate after resize/initialization, before recording the first upload.
            validateSimulationCheckpoint(checkpoint, states);
        } catch (RuntimeException failure) {
            completion.completeExceptionally(failure);
            return;
        }
        try {
            for (var field : checkpoint.fields().values()) {
                var selection = field.selection();
                String physical = graphPlan.physical(selection.resource(), phase);
                restoreSimulationField(
                        selection.resource(),
                        selection.mip(),
                        selection.layer(),
                        field.data(),
                        states.get(physical));
            }
            runtime.deferDestroy(() -> completion.complete(null));
        } catch (RuntimeException | Error failure) {
            completion.completeExceptionally(failure);
            throw failure;
        }
    }

    private record SimulationRead(
            String id,
            dev.veil.api.VeilSimulationCheckpoint.Selection selection,
            String physical,
            VeilNativeImage image,
            dev.veil.api.VeilSimulationGpuField.Plan layout,
            List<VeilRenderGraph.ImageState> states,
            int offset) {}

    /** One opt-in, bounded staging allocation; all selections validated before recording copies. */
    void readSimulationCheckpoint(
            Map<String, dev.veil.api.VeilSimulationCheckpoint.Selection> selections,
            int maxBytes,
            java.util.function.Consumer<dev.veil.api.VeilSimulationCheckpoint> completed) {
        readSimulationCheckpoint(
                selections,
                maxBytes,
                Map.of(),
                completed,
                failure -> {
                    if (failure instanceof Error error) throw error;
                    throw (RuntimeException) failure;
                });
    }

    java.util.concurrent.CompletableFuture<dev.veil.api.VeilSimulationCheckpoint>
            readSimulationCheckpointAsync(
                    Map<String, dev.veil.api.VeilSimulationCheckpoint.Selection> selections,
                    int maxBytes) {
        return readSimulationCheckpointAsync(selections, maxBytes, Map.of());
    }

    java.util.concurrent.CompletableFuture<dev.veil.api.VeilSimulationCheckpoint>
            readSimulationCheckpointAsync(
                    Map<String, dev.veil.api.VeilSimulationCheckpoint.Selection> selections,
                    int maxBytes,
                    Map<String, dev.veil.api.VeilSimulationCheckpoint.CpuState> cpuState) {
        var result =
                new java.util.concurrent.CompletableFuture<dev.veil.api.VeilSimulationCheckpoint>();
        try {
            readSimulationCheckpoint(
                    selections,
                    maxBytes,
                    cpuState,
                    result::complete,
                    result::completeExceptionally);
        } catch (RuntimeException | Error failure) {
            result.completeExceptionally(failure);
        }
        // Caller cancellation must not stand in for actual GPU retirement.
        return result.copy();
    }

    private void readSimulationCheckpoint(
            Map<String, dev.veil.api.VeilSimulationCheckpoint.Selection> selections,
            int maxBytes,
            Map<String, dev.veil.api.VeilSimulationCheckpoint.CpuState> cpuState,
            java.util.function.Consumer<dev.veil.api.VeilSimulationCheckpoint> completed,
            java.util.function.Consumer<Throwable> failed) {
        RenderSystem.assertOnRenderThread();
        java.util.Objects.requireNonNull(completed, "completed");
        var requested = Map.copyOf(selections);
        var capturedCpu = Map.copyOf(cpuState);
        if (capturedCpu.size() > 128)
            throw new IllegalArgumentException("Too many CPU checkpoint entries");
        long cpuBytes = 0;
        for (var entry : capturedCpu.entrySet()) {
            dev.veil.api.VeilSimulationCheckpoint.checkId(entry.getKey());
            cpuBytes += entry.getValue().size();
        }
        if (closed || !resources.initialized || lastPlan == null || frames < 1)
            throw new IllegalStateException("Checkpoint requires an active completed graph frame");
        if (requested.isEmpty()
                || requested.size() > 128
                || maxBytes < 1
                || maxBytes > dev.veil.api.VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES)
            throw new IllegalArgumentException("Invalid checkpoint count or staging budget");
        var reads = new ArrayList<SimulationRead>();
        long bytes = 0;
        for (var item : requested.entrySet()) {
            dev.veil.api.VeilSimulationCheckpoint.checkId(item.getKey());
            var selection = item.getValue();
            var definition = prepared.pack().resources().get(selection.resource());
            if (definition == null
                    || definition.kind() != VeilRenderGraph.Kind.IMAGE
                    || definition.samples() != 1
                    || !definition.usages().contains(VeilResourceUsage.TRANSFER_SOURCE))
                throw new IllegalArgumentException(
                        "Checkpoint needs a single-sample transfer-source image: "
                                + selection.resource());
            String physical = graphPlan.physical(selection.resource(), phase);
            var image = resources.nativeImages.get(physical);
            if (image == null || selection.layer() >= image.layers())
                throw new IllegalArgumentException(
                        "Checkpoint image/layer is unavailable: " + selection.resource());
            var layout =
                    dev.veil.api.VeilSimulationGpuField.plan(
                            definition.format(),
                            image.width(),
                            image.height(),
                            definition.image3d() ? image.depth() : 1,
                            selection.mip(),
                            image.mipLevels());
            if (!definition.image3d() && image.depth() != 1)
                throw new IllegalArgumentException("Checkpoint image depth mismatch");
            int alignment = Math.max(4, layout.format().bytesPerTexel());
            bytes = (bytes + alignment - 1) & -(long) alignment;
            int offset = Math.toIntExact(bytes);
            bytes += layout.bytes();
            if (bytes > maxBytes
                    || bytes + cpuBytes
                            > dev.veil.api.VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES)
                throw new IllegalArgumentException("Checkpoint staging budget exceeded");
            reads.add(
                    new SimulationRead(
                            item.getKey(),
                            selection,
                            physical,
                            image,
                            layout,
                            transferImageStates(physical),
                            offset));
        }
        if (simulationGeneration == null) simulationGeneration = java.util.UUID.randomUUID();
        var generation = simulationGeneration;
        long capturedFrame = frames;
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil joint simulation checkpoint",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                bytes);
        try {
            for (var read : reads) {
                var transition =
                        dev.veil.revive.client.graphics.synchronization.ImageTransferTransitions
                                .plan(
                                        read.physical(),
                                        read.states(),
                                        VeilRenderGraph.Subresource.image(
                                                read.selection().mip(),
                                                1,
                                                read.selection().layer(),
                                                1),
                                        VeilRenderGraph.State.of(
                                                VeilRenderGraph.Access.TRANSFER_READ));
                barriers(transition.acquire());
                try (var stack = MemoryStack.stackPush()) {
                    var copy =
                            VkBufferImageCopy.calloc(1, stack)
                                    .bufferOffset(read.offset())
                                    .bufferRowLength(0)
                                    .bufferImageHeight(0);
                    copy.imageSubresource()
                            .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                            .mipLevel(read.selection().mip())
                            .baseArrayLayer(read.selection().layer())
                            .layerCount(1);
                    copy.imageOffset().set(0, 0, 0);
                    copy.imageExtent()
                            .set(
                                    read.layout().width(),
                                    read.layout().height(),
                                    read.layout().depth());
                    vkCmdCopyImageToBuffer(
                            runtime.commandBuffer(),
                            read.image().image(),
                            VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                            ((VulkanGpuBuffer) readback).vkBuffer(),
                            copy);
                }
                barriers(transition.restore());
            }
            runtime.deferDestroy(
                    () -> {
                        dev.veil.api.VeilSimulationCheckpoint checkpoint;
                        try {
                            var fields =
                                    new LinkedHashMap<
                                            String, dev.veil.api.VeilSimulationCheckpoint.Field>();
                            try {
                                try (var mapped = readback.map(true, false)) {
                                    for (var read : reads) {
                                        var view = mapped.data().duplicate();
                                        view.position(read.offset())
                                                .limit(read.offset() + read.layout().bytes());
                                        fields.put(
                                                read.id(),
                                                new dev.veil.api.VeilSimulationCheckpoint.Field(
                                                        read.selection(),
                                                        read.layout().format(),
                                                        read.layout().capture(view.slice())));
                                    }
                                }
                            } finally {
                                readback.close();
                            }
                            checkpoint =
                                    new dev.veil.api.VeilSimulationCheckpoint(
                                            generation, capturedFrame, fields, capturedCpu);
                        } catch (RuntimeException | Error failure) {
                            failed.accept(failure);
                            return;
                        }
                        completed.accept(checkpoint);
                    });
        } catch (RuntimeException | Error failure) {
            readback.close();
            throw failure;
        }
    }

    public record PipelineKey(
            Map<VeilShaderStage, String> binaries,
            VeilShaderInterface layout,
            List<VeilFormat> colorFormats,
            VeilFormat depthFormat,
            int samples,
            VeilShaderPack.Geometry geometry,
            List<VeilShaderPack.ColorAttachment> colors,
            VeilShaderPack.DepthAttachment depth,
            VeilShaderPack.PipelineState pipelineState,
            VeilVertexLayout vertexLayout,
            Map<VeilShaderStage, VeilSpecializationValues> specialization,
            int maxRecursionDepth) {
        public PipelineKey {
            binaries = Map.copyOf(binaries);
            colorFormats = List.copyOf(colorFormats);
            colors = List.copyOf(colors);
            vertexLayout = vertexLayout == null ? VeilVertexLayout.EMPTY : vertexLayout;
            specialization = Map.copyOf(specialization);
        }

        public PipelineKey(
                Map<VeilShaderStage, String> binaries,
                VeilShaderInterface layout,
                List<VeilFormat> colorFormats,
                VeilFormat depthFormat,
                int samples,
                VeilShaderPack.Geometry geometry,
                List<VeilShaderPack.ColorAttachment> colors,
                VeilShaderPack.DepthAttachment depth,
                VeilShaderPack.PipelineState pipelineState,
                VeilVertexLayout vertexLayout,
                Map<VeilShaderStage, VeilSpecializationValues> specialization) {
            this(
                    binaries,
                    layout,
                    colorFormats,
                    depthFormat,
                    samples,
                    geometry,
                    colors,
                    depth,
                    pipelineState,
                    vertexLayout,
                    specialization,
                    1);
        }

        public PipelineKey(
                Map<VeilShaderStage, String> binaries,
                VeilShaderInterface layout,
                List<VeilFormat> colorFormats,
                VeilFormat depthFormat,
                int samples,
                VeilShaderPack.Geometry geometry,
                List<VeilShaderPack.ColorAttachment> colors,
                VeilShaderPack.DepthAttachment depth,
                VeilShaderPack.PipelineState pipelineState,
                Map<VeilShaderStage, VeilSpecializationValues> specialization) {
            this(
                    binaries,
                    layout,
                    colorFormats,
                    depthFormat,
                    samples,
                    geometry,
                    colors,
                    depth,
                    pipelineState,
                    VeilVertexLayout.EMPTY,
                    specialization,
                    1);
        }
    }

    public static final class Pipeline implements VeilShaderReload.Generation {
        private final VeilComputePipeline compute;
        private final VeilGraphicsPipeline graphics;
        private final VeilRayTracingPipeline ray;

        private Pipeline(
                VeilComputePipeline compute,
                VeilGraphicsPipeline graphics,
                VeilRayTracingPipeline ray) {
            this.compute = compute;
            this.graphics = graphics;
            this.ray = ray;
        }

        long handle() {
            return compute != null
                    ? compute.handle()
                    : ray != null ? ray.handle() : graphics.handle();
        }

        long layout() {
            return compute != null
                    ? compute.layout()
                    : ray != null ? ray.layout() : graphics.layout();
        }

        @Override
        public void close() {
            if (compute != null) compute.close();
            if (graphics != null) graphics.close();
            if (ray != null) ray.close();
        }
    }

    private record RecordedPass(
            VeilShaderPack.Pass definition,
            VeilShaderProgram program,
            VeilShaderInterface layoutInterface,
            VeilRenderGraph.Pass graph,
            VeilPipelineCache<PipelineKey, Pipeline>.Lease pipeline,
            Map<Integer, Integer> descriptorTypes,
            String label)
            implements VeilShaderPerformanceReport.PassInfo {}

    private record RetainedImage(String key, GpuTexture image, GpuTextureView view) {}

    private final VeilVulkanRuntime runtime;
    private final VeilShaderPack.Prepared prepared;
    private final VeilShaderMetrics metrics;
    private final List<RecordedPass> passes = new ArrayList<>();
    private final VeilShaderGraphPlan graphPlan;
    private final Set<String> depthOnlySceneTerrain;
    private final VeilShaderDeviceLimits limits;
    private final dev.veil.revive.client.graphics.resources.BufferBindingLimits bufferBindingLimits;
    private final VeilShaderPassProfiler profiler;
    private VeilPipelineCache<PipelineKey, Pipeline>.Lease presenter;
    private GpuFormat presentFormat;
    private long phase;
    private final PackHistory<VeilCameraAbi.Snapshot> history;
    private final MappableRingBuffer cameraRing;
    private final MappableRingBuffer surfaceRing;
    private final MappableRingBuffer colorPipelineRing;
    private final java.util.Set<dev.veil.api.VeilSurfaceGuides.Channel> surfaceGuideChannels;
    private VeilSurfaceTransforms.Snapshot surfaceCurrent, surfacePrevious;
    private final Map<String, MappableRingBuffer> sceneCameraRings = new LinkedHashMap<>();
    private final Map<String, MappableRingBuffer> sceneProjectionRings = new LinkedHashMap<>();
    private final Map<String, GpuBufferSlice> sceneCameraSlices = new LinkedHashMap<>();
    private final Map<String, GpuBufferSlice> sceneProjectionSlices = new LinkedHashMap<>();
    private final Map<String, VeilSceneCameraAbi.Snapshot> sceneCameras = new LinkedHashMap<>();
    private final Set<String> sceneAttachments = new LinkedHashSet<>();
    private final Set<Integer> validatedComparisonFormats = new LinkedHashSet<>();
    private GpuBufferSlice cameraSlice;
    private GpuBufferSlice worldProjectionSlice;
    private final boolean worldProjectionRequired;
    private final PackHostRequirements hostRequirements;
    private final CreatorSceneRequirements creatorSceneRequirements;
    private final dev.veil.revive.client.graphics.minecraft.SceneRasterPipelines
            sceneRasterPipelines;
    private VeilCameraAbi.Snapshot currentCamera;
    private boolean cameraReported;
    private VeilShaderGraphPlan.Frame lastPlan;
    private PackResourceSet<VeilRayQueryScene, VeilNativeImage, VeilSampler> resources;
    private final GraphicsPassExecutor<RecordedPass> graphicsExecutor =
            new GraphicsPassExecutor<>(
                    RecordedPass::definition,
                    this::attachmentView,
                    this::attachmentFormat,
                    this::bind,
                    this::renderGeometry);
    private final DrawPassExecutor drawExecutor = new DrawPassExecutor(this::lookupBuffer);
    private final dev.veil.revive.client.shaderpack.runtime.ComputePassExecutor<RecordedPass>
            computeExecutor =
                    new dev.veil.revive.client.shaderpack.runtime.ComputePassExecutor<>(
                            RecordedPass::definition, this::lookupBuffer, this::bind);
    private TransferPassExecutor transferExecutor;
    private final dev.veil.revive.client.graphics.synchronization.BarrierRecorder<VeilNativeImage>
            barrierRecorder =
                    new dev.veil.revive.client.graphics.synchronization.BarrierRecorder<>(
                            VeilNativeImage::image,
                            VeilNativeImage::aspect,
                            VeilNativeImage::mipLevels,
                            VeilNativeImage::layers);
    private int width;
    private int height;
    private boolean closed;
    private long frames;

    public VeilShaderPackRuntime(
            VeilVulkanRuntime runtime,
            VeilShaderPack.Prepared prepared,
            VeilPipelineCache<PipelineKey, Pipeline> cache,
            VeilShaderMetrics metrics,
            int width,
            int height) {
        this(runtime, prepared, cache, metrics, width, height, GpuFormat.RGBA8_UNORM);
    }

    public VeilShaderPackRuntime(
            VeilVulkanRuntime runtime,
            VeilShaderPack.Prepared prepared,
            VeilPipelineCache<PipelineKey, Pipeline> cache,
            VeilShaderMetrics metrics,
            int width,
            int height,
            GpuFormat presentFormat) {
        RenderSystem.assertOnRenderThread();
        this.runtime = runtime;
        this.prepared = prepared;
        this.hostRequirements = PackHostRequirements.from(prepared.pack());
        this.creatorSceneRequirements = CreatorSceneRequirements.from(prepared.pack());
        this.sceneRasterPipelines =
                new dev.veil.revive.client.graphics.minecraft.SceneRasterPipelines(runtime);
        for (var pass : prepared.pack().passes()) {
            if (pass.scene() != null) sceneRasterPipelines.validate(pass.scene().raster());
        }
        this.metrics = metrics;
        TransferCapabilities.validate(runtime.vkDevice().getPhysicalDevice(), prepared.pack());
        this.worldProjectionRequired =
                prepared.pack().passes().stream()
                        .anyMatch(VeilShaderPack.Pass::sceneProjectionData);
        this.graphPlan = new VeilShaderGraphPlan(prepared);
        this.depthOnlySceneTerrain = VeilSceneDepthPlan.select(prepared);
        this.limits = VeilShaderDeviceLimits.capture(runtime);
        this.bufferBindingLimits =
                dev.veil.revive.client.graphics.resources.BufferBindingLimits.capture(
                        runtime.vkDevice().getPhysicalDevice());
        this.profiler =
                new VeilShaderPassProfiler(
                        prepared.graph().size() + (prepared.pack().present() == null ? 0 : 1),
                        limits.timestampPeriod(),
                        limits.timestampBits());
        this.history =
                new PackHistory<>(
                        prepared.pack().resources().values().stream()
                                .anyMatch(VeilShaderPack.Resource::history),
                        prepared.pack().resources().values().stream()
                                        .mapToInt(VeilShaderPack.Resource::historyCount)
                                        .max()
                                        .orElse(1)
                                - 1);
        this.presentFormat = presentFormat;
        if (!runtime.vkDevice().getCapabilities().VK_KHR_synchronization2
                || !runtime.vkDevice().getCapabilities().VK_KHR_dynamic_rendering
                || !runtime.vkDevice().getCapabilities().VK_KHR_push_descriptor) {
            throw new IllegalStateException(
                    "Veil shader packs require Minecraft's enabled synchronization2, dynamic rendering and push descriptor paths");
        }
        if (prepared.pack().resources().values().stream()
                        .anyMatch(VeilShaderPack.Resource::requiresExtendedStorageFormats)
                && !VeilVulkanCapabilities.shaderStorageImageExtendedFormats()) {
            throw new IllegalStateException(
                    "Shader pack requires extended storage-image formats, but shaderStorageImageExtendedFormats is not enabled on this Vulkan device");
        }
        this.colorPipelineRing =
                prepared.pack().resources().values().stream()
                                .anyMatch(r -> VeilColorPipeline.HOST_ID.equals(r.hostId()))
                        ? new MappableRingBuffer(
                                () -> "Veil color pipeline metadata",
                                GpuBuffer.USAGE_MAP_WRITE | VeilHzb.STORAGE_USAGE,
                                VeilColorPipeline.SIZE)
                        : null;
        this.surfaceGuideChannels = VeilSurfaceGuideFrame.requested(prepared.pack());
        this.surfaceRing =
                prepared.pack().resources().values().stream()
                                .anyMatch(
                                        resource ->
                                                VeilSurfaceTransforms.HOST_ID.equals(
                                                                resource.hostId())
                                                        || VeilSurfaceGuideFrame.isHost(
                                                                resource.hostId()))
                        ? new MappableRingBuffer(
                                () -> "Veil exact surface transforms",
                                GpuBuffer.USAGE_MAP_WRITE | VeilHzb.STORAGE_USAGE,
                                VeilSurfaceTransforms.SIZE)
                        : null;
        this.cameraRing =
                prepared.pack().passes().stream().anyMatch(VeilShaderPack.Pass::cameraData)
                        ? new MappableRingBuffer(
                                () -> "Veil creator CameraData",
                                GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_UNIFORM,
                                VeilCameraAbi.SIZE)
                        : null;
        for (VeilShaderPack.Pass pass : prepared.pack().passes()) {
            if (!pass.scenePass()) continue;
            sceneCameraRings.put(
                    pass.name(),
                    new MappableRingBuffer(
                            () -> "Veil custom scene camera " + pass.name(),
                            GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_UNIFORM,
                            VeilSceneCameraAbi.SIZE));
            sceneProjectionRings.put(
                    pass.name(),
                    new MappableRingBuffer(
                            () -> "Veil custom scene projection " + pass.name(),
                            GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_UNIFORM,
                            64));
            pass.colors().forEach(attachment -> sceneAttachments.add(attachment.resource()));
            sceneAttachments.add(pass.depthTarget());
        }
        try {
            for (var ordered : prepared.graph()) {
                var pass =
                        prepared.pack().passes().stream()
                                .filter(value -> value.name().equals(ordered.name()))
                                .findFirst()
                                .orElseThrow();
                String label = "Veil/" + prepared.pack().name() + "/" + pass.name();
                if (pass.transfer()) {
                    passes.add(new RecordedPass(pass, null, null, ordered, null, Map.of(), label));
                    continue;
                }
                if (pass.scenePass()) {
                    passes.add(new RecordedPass(pass, null, null, ordered, null, Map.of(), label));
                    continue;
                }
                var program = prepared.programs().get(pass.program());
                program.stages().values().forEach(VeilShaderBaseline::validateDeviceFeatures);
                program.stages().values().forEach(limits::validateShaderFeatures);
                List<VeilFormat> colorFormats =
                        pass.graphics()
                                ? pass.colors().stream()
                                        .map(
                                                attachment ->
                                                        prepared.pack()
                                                                .resources()
                                                                .get(attachment.resource())
                                                                .format())
                                        .toList()
                                : List.of();
                VeilFormat depthFormat = null;
                int samples = 1;
                if (pass.graphics()) {
                    limits.validate(pass.vertexLayout(), pass.name());
                    // Indirect draw streams are partitioned into legal Vulkan batches
                    // (or individual calls when multiDrawIndirect is not enabled).
                    if (!pass.colors().isEmpty())
                        samples =
                                prepared.pack()
                                        .resources()
                                        .get(pass.colors().getFirst().resource())
                                        .samples();
                    if (pass.depth() != null) {
                        var depthResource =
                                prepared.pack().resources().get(pass.depth().resource());
                        if (depthResource.hostImport()) {
                            var sceneDepth =
                                    Minecraft.getInstance()
                                            .gameRenderer
                                            .mainRenderTarget()
                                            .getDepthTexture();
                            if (sceneDepth == null)
                                throw new IllegalStateException(
                                        "Graphics pass requires Minecraft scene depth");
                            depthFormat = VeilVulkanFormats.veil(sceneDepth.getFormat());
                        } else {
                            depthFormat = depthResource.format();
                            if (pass.colors().isEmpty()) samples = depthResource.samples();
                        }
                    }
                    validateAttachments(pass, samples, width, height);
                }
                VeilShaderInterface layoutInterface =
                        prepared.pack().pipelineInterface(pass, program.shaderInterface());
                var hashes = new LinkedHashMap<VeilShaderStage, String>();
                program.stages()
                        .forEach((stage, binary) -> hashes.put(stage, binary.contentHash()));
                var key =
                        new PipelineKey(
                                hashes,
                                layoutInterface,
                                colorFormats,
                                depthFormat,
                                samples,
                                pass.geometry(),
                                pass.colors(),
                                pass.depth(),
                                pass.pipeline(),
                                pass.vertexLayout(),
                                pass.specialization(),
                                pass.maxRecursionDepth());
                VeilFormat pipelineDepthFormat = depthFormat;
                int pipelineSamples = samples;
                var lease =
                        cache.acquire(
                                key,
                                () ->
                                        pass.compute()
                                                ? new Pipeline(
                                                        VeilComputePipeline.createReflected(
                                                                runtime,
                                                                program.stage(
                                                                        VeilShaderStage.COMPUTE),
                                                                layoutInterface,
                                                                pass.values(
                                                                        VeilShaderStage.COMPUTE)),
                                                        null,
                                                        null)
                                                : pass.raytrace()
                                                        ? new Pipeline(
                                                                null,
                                                                null,
                                                                VeilRayTracingPipeline.create(
                                                                        runtime,
                                                                        program,
                                                                        layoutInterface,
                                                                        pass.specialization(),
                                                                        pass.maxRecursionDepth()))
                                                        : new Pipeline(
                                                                null,
                                                                VeilGraphicsPipeline.createPack(
                                                                        runtime,
                                                                        program,
                                                                        colorFormats,
                                                                        pipelineDepthFormat,
                                                                        pipelineSamples,
                                                                        pass,
                                                                        layoutInterface),
                                                                null));
                VeilShaderDebugNames.name(
                        runtime,
                        VK_OBJECT_TYPE_PIPELINE,
                        lease.value().handle(),
                        label + "/" + Integer.toHexString(key.hashCode()));
                passes.add(
                        new RecordedPass(
                                pass,
                                program,
                                layoutInterface,
                                ordered,
                                lease,
                                descriptorTypes(layoutInterface),
                                label));
            }
            if (prepared.pack().present() != null) {
                var program = prepared.programs().get(VeilShaderPack.PRESENTER);
                var hashes = new LinkedHashMap<VeilShaderStage, String>();
                program.stages()
                        .forEach((stage, binary) -> hashes.put(stage, binary.contentHash()));
                var presentValues =
                        VeilSpecializationValues.of(
                                Map.of(
                                        0,
                                                VeilSpecializationValues.Value.integer(
                                                        prepared.pack()
                                                                .presentEncoding()
                                                                .ordinal()),
                                        1,
                                                VeilSpecializationValues.Value.bool(
                                                        VeilVulkanFormats.veil(presentFormat)
                                                                .srgb())));
                presentValues.validate(program.shaderInterface(), VeilShaderStage.FRAGMENT);
                var presentColor =
                        new VeilShaderPack.ColorAttachment(
                                "present",
                                0,
                                0,
                                VeilShaderPack.LoadOp.LOAD,
                                VeilShaderPack.StoreOp.STORE,
                                null,
                                VeilShaderPack.BlendState.DISABLED,
                                java.util.EnumSet.allOf(VeilShaderPack.ColorChannel.class));
                var key =
                        new PipelineKey(
                                hashes,
                                program.shaderInterface(),
                                List.of(VeilVulkanFormats.veil(presentFormat)),
                                null,
                                1,
                                VeilShaderPack.Geometry.FULLSCREEN,
                                List.of(presentColor),
                                null,
                                VeilShaderPack.PipelineState.DEFAULT,
                                VeilVertexLayout.EMPTY,
                                Map.of(VeilShaderStage.FRAGMENT, presentValues),
                                1);
                presenter =
                        cache.acquire(
                                key,
                                () ->
                                        new Pipeline(
                                                null,
                                                VeilGraphicsPipeline.createSimple(
                                                        runtime,
                                                        program.stage(VeilShaderStage.VERTEX),
                                                        program.stage(VeilShaderStage.FRAGMENT),
                                                        presentFormat,
                                                        program.shaderInterface(),
                                                        VeilSpecializationValues.empty(),
                                                        presentValues),
                                                null));
            }
            resize(width, height);
        } catch (RuntimeException failure) {
            close();
            throw failure;
        }
    }

    public void resize(int width, int height) {
        RenderSystem.assertOnRenderThread();
        if (closed) throw new IllegalStateException("Shader pack generation is closed");
        if (this.width == width && this.height == height) return;
        if (width <= 0 || height <= 0)
            throw new IllegalArgumentException("Invalid shader viewport");
        PackResourceSet<VeilRayQueryScene, VeilNativeImage, VeilSampler> previous = resources;
        var replacement =
                new PackResourceSet<VeilRayQueryScene, VeilNativeImage, VeilSampler>(
                        VeilRayQueryScene::close, VeilNativeImage::close, VeilSampler::close);
        var retainedImages = new ArrayList<RetainedImage>();
        replacement.dispatch = new int[passes.size()][];
        for (int index = 0; index < passes.size(); index++) {
            RecordedPass pass = passes.get(index);
            if (pass.definition().raytrace()) {
                int[] dimensions =
                        pass.definition()
                                .trace()
                                .resolve(prepared.pack().resources(), width, height);
                VeilRayCapabilities.validateTraceDimensions(runtime, dimensions);
                replacement.dispatch[index] = dimensions;
                continue;
            }
            if (!pass.definition().compute()) continue;
            var binary = pass.program().stage(VeilShaderStage.COMPUTE);
            int[] local = VeilShaderBaseline.fixedLocalSize(binary);
            int[] groups = null;
            if (pass.definition().dispatch().indirect()) {

                limits.validate(local, new int[] {1, 1, 1}, pass.definition().name());
            } else {
                groups =
                        pass.definition()
                                .dispatch()
                                .resolve(prepared.pack().resources(), width, height);
                limits.validate(local, groups, pass.definition().name());
            }
            long shared = VeilSpirvAnalysis.inspect(binary).sharedBytes();
            if (shared < 0 || shared > limits.sharedBytes())
                throw new IllegalArgumentException(
                        pass.definition().name()
                                + ": shared memory size is unknown or exceeds device limit");
            replacement.dispatch[index] = groups;
        }
        VeilShaderLimits.Settings budgets = VeilShaderLimits.current();
        int maxImageDimension;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var properties = VkPhysicalDeviceProperties.calloc(stack);
            vkGetPhysicalDeviceProperties(runtime.vkDevice().getPhysicalDevice(), properties);
            maxImageDimension = properties.limits().maxImageDimension2D();
        }
        for (RecordedPass pass : passes) {
            if (pass.layoutInterface() == null) continue;
            for (var descriptor : pass.layoutInterface().descriptors()) {
                if (descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_STORAGE_BUFFER
                        && descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER)
                    continue;
                var binding = pass.definition().bindings().get(descriptor.binding());
                if (binding == null) continue;
                for (String logical : binding.resources()) {
                    var resource = prepared.pack().resources().get(logical);
                    long bytes =
                            resource.hostImport()
                                    ? VeilHostResourceRegistry.definition(resource.hostId()).bytes()
                                    : resource.bytes();
                    bufferBindingLimits.validate(
                            binding,
                            descriptor.descriptorType(),
                            bytes,
                            descriptor.minimumBufferSize(),
                            pass.definition().name() + "/" + logical);
                }
            }
        }
        long budget = 0;
        for (var resource : prepared.pack().resources().values()) {
            if (resource.source() != VeilShaderPack.Source.OWNED) continue;
            if (resource.kind() == VeilRenderGraph.Kind.BUFFER) {
                budget =
                        Math.addExact(
                                budget,
                                Math.multiplyExact(resource.bytes(), resource.historyCount()));
            } else if (resource.nativeImage()) {
                budget =
                        Math.addExact(
                                budget,
                                Math.multiplyExact(
                                        resource.resolvedBytes(
                                                width, height, prepared.pack().resources()),
                                        resource.historyCount()));
            } else {
                int imageWidth = resource.resolvedWidth(width, prepared.pack().resources());
                int imageHeight = resource.resolvedHeight(height, prepared.pack().resources());
                if (imageWidth > maxImageDimension || imageHeight > maxImageDimension)
                    throw new IllegalArgumentException(
                            "Image exceeds Vulkan maxImageDimension2D: " + resource.name());
                budget =
                        Math.addExact(
                                budget,
                                (long) imageWidth
                                        * imageHeight
                                        * VeilShaderPack.Resource.bytesPerTexel(resource.format())
                                        * resource.historyCount());
            }
        }
        long generalBudget =
                prepared.pack().resources().values().stream()
                        .filter(
                                resource ->
                                        resource.source() == VeilShaderPack.Source.OWNED
                                                && !sceneAttachments.contains(resource.name()))
                        .mapToLong(
                                resource ->
                                        resource.kind() == VeilRenderGraph.Kind.BUFFER
                                                ? Math.multiplyExact(
                                                        resource.bytes(), resource.historyCount())
                                                : Math.multiplyExact(
                                                        resource.resolvedBytes(
                                                                width,
                                                                height,
                                                                prepared.pack().resources()),
                                                        resource.historyCount()))
                        .reduce(0L, Math::addExact);
        if (generalBudget > budgets.packBytes())
            throw new IllegalArgumentException(
                    "Shader resources exceed the configured pack memory budget");
        if (budget > budgets.packBytes())
            throw new IllegalArgumentException(
                    "Shader resources exceed the configured pack memory budget");
        try {
            for (var resource : prepared.pack().resources().values()) {
                if (resource.sampled()
                        && resource.image2d()
                        && (!resource.nativeImage()
                                || sceneAttachments.contains(resource.name()))) {
                    VeilSampler sampler =
                            VeilSampler.create(
                                    runtime,
                                    resource.sampler(),
                                    "Veil pack " + prepared.pack().name() + "/" + resource.name());
                    replacement.ownedSamplers.add(sampler);
                    replacement.samplers.put(resource.name(), sampler);
                }
                if (resource.source() != VeilShaderPack.Source.OWNED) continue;
                String label = "Veil pack " + prepared.pack().name() + "/" + resource.name();
                if (resource.kind() == VeilRenderGraph.Kind.BUFFER) {
                    boolean rayQuery =
                            passes.stream()
                                    .anyMatch(
                                            pass ->
                                                    !pass.definition().transfer()
                                                            && !pass.definition().scenePass()
                                                            && pass
                                                                    .layoutInterface()
                                                                    .descriptors()
                                                                    .stream()
                                                                    .anyMatch(
                                                                            descriptor ->
                                                                                    descriptor
                                                                                                            .descriptorType()
                                                                                                    == org
                                                                                                            .lwjgl
                                                                                                            .vulkan
                                                                                                            .KHRAccelerationStructure
                                                                                                            .VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR
                                                                                            && pass.definition()
                                                                                                    .bindings()
                                                                                                    .get(
                                                                                                            descriptor
                                                                                                                    .binding())
                                                                                                    .resources()
                                                                                                    .contains(
                                                                                                            resource
                                                                                                                    .name())));
                    if (rayQuery) {
                        var rayScene =
                                new VeilRayQueryScene(
                                        runtime,
                                        prepared.bufferAssets()
                                                .get(resource.name())
                                                .bytesForUpload(),
                                        label);
                        replacement.rayScenes.put(resource.name(), rayScene);
                        budget = Math.addExact(budget, rayScene.bytes());
                        if (budget > budgets.packBytes())
                            throw new IllegalArgumentException(
                                    "Shader resources including ray acceleration structures exceed the configured pack memory budget");
                    }
                    int bufferUsage = 0;
                    boolean indirectArguments =
                            passes.stream()
                                    .anyMatch(
                                            pass ->
                                                    pass.definition().compute()
                                                            && pass.definition()
                                                                    .dispatch()
                                                                    .indirect()
                                                            && pass.definition()
                                                                    .dispatch()
                                                                    .indirectResource()
                                                                    .equals(resource.name()));
                    if (resource.usages().contains(VeilResourceUsage.STORAGE))
                        bufferUsage |= VeilHzb.STORAGE_USAGE;
                    if (resource.usages().contains(VeilResourceUsage.UNIFORM))
                        bufferUsage |= GpuBuffer.USAGE_UNIFORM;
                    if (resource.usages().contains(VeilResourceUsage.VERTEX))
                        bufferUsage |= GpuBuffer.USAGE_VERTEX;
                    if (resource.usages().contains(VeilResourceUsage.INDEX))
                        bufferUsage |= GpuBuffer.USAGE_INDEX;
                    if (resource.usages().contains(VeilResourceUsage.INDIRECT) || indirectArguments)
                        bufferUsage |= GpuBuffer.USAGE_INDIRECT_PARAMETERS;
                    if (resource.usages().contains(VeilResourceUsage.TRANSFER_SOURCE))
                        bufferUsage |= GpuBuffer.USAGE_COPY_SRC;
                    if (resource.usages().contains(VeilResourceUsage.TRANSFER_DESTINATION)
                            || resource.initialContent() != VeilShaderPack.InitialContent.UNDEFINED)
                        bufferUsage |= GpuBuffer.USAGE_COPY_DST;
                    for (int index = 0; index < resource.historyCount(); index++) {
                        String key = graphPlan.physical(resource.name(), index);
                        String bufferLabel = label + "/" + index;
                        GpuBuffer buffer =
                                runtime.device()
                                        .createBuffer(
                                                () -> bufferLabel, bufferUsage, resource.bytes());
                        replacement.ownedBuffers.add(buffer);
                        replacement.buffers.put(key, buffer);
                        VeilShaderPack.BufferAsset bufferAsset =
                                prepared.bufferAssets().get(resource.name());
                        if (bufferAsset != null)
                            uploadBuffer(buffer, bufferAsset.bytesForUpload(), bufferLabel);
                    }
                } else if (resource.nativeImage() && !sceneAttachments.contains(resource.name())) {
                    VeilShaderPack.ImageAsset asset = prepared.imageAssets().get(resource.name());
                    for (int index = 0; index < resource.historyCount(); index++) {
                        String key = graphPlan.physical(resource.name(), index);
                        replacement.nativeImages.put(
                                key,
                                VeilNativeImage.create(
                                        runtime,
                                        resource,
                                        prepared.pack().resources(),
                                        asset,
                                        width,
                                        height,
                                        label + "/" + index));
                    }
                } else {
                    int imageUsage = 0;
                    if (resource.renderTarget() || resource.depthTarget())
                        imageUsage |= GpuTexture.USAGE_RENDER_ATTACHMENT;
                    if (resource.sampled()) imageUsage |= GpuTexture.USAGE_TEXTURE_BINDING;
                    if (resource.usages().contains(VeilResourceUsage.TRANSFER_SOURCE))
                        imageUsage |= GpuTexture.USAGE_COPY_SRC;
                    if (resource.usages().contains(VeilResourceUsage.TRANSFER_DESTINATION))
                        imageUsage |= GpuTexture.USAGE_COPY_DST;
                    for (int index = 0; index < resource.historyCount(); index++) {
                        String key = graphPlan.physical(resource.name(), index);
                        GpuTexture retained =
                                previous == null
                                                || !retainsOnFramebufferResize(
                                                        resource,
                                                        sceneAttachments.contains(resource.name()),
                                                        this.width,
                                                        this.height,
                                                        width,
                                                        height,
                                                        prepared.pack().resources())
                                        ? null
                                        : previous.images.get(key);
                        int resolvedWidth =
                                resource.resolvedWidth(width, prepared.pack().resources());
                        int resolvedHeight =
                                resource.resolvedHeight(height, prepared.pack().resources());
                        if (retained != null
                                && retained.getWidth(0) == resolvedWidth
                                && retained.getHeight(0) == resolvedHeight) {
                            GpuTextureView view = previous.views.get(key);
                            replacement.images.put(key, retained);
                            if (view != null) replacement.views.put(key, view);
                            retainedImages.add(new RetainedImage(key, retained, view));
                            continue;
                        }
                        GpuTexture image =
                                runtime.device()
                                        .createTexture(
                                                label + "/" + index,
                                                imageUsage,
                                                VeilVulkanFormats.minecraft(resource.format()),
                                                resolvedWidth,
                                                resolvedHeight,
                                                1,
                                                1);
                        replacement.ownedImages.add(image);
                        replacement.images.put(key, image);
                        if (resource.sampled() || resource.renderTarget()) {
                            GpuTextureView view = runtime.device().createTextureView(image);
                            replacement.ownedViews.add(view);
                            replacement.views.put(key, view);
                        }
                    }
                }
            }
        } catch (RuntimeException failure) {
            replacement.close();
            throw failure;
        }
        if (previous != null) {
            for (RetainedImage retained : retainedImages) {
                previous.images.remove(retained.key());
                previous.ownedImages.remove(retained.image());
                replacement.ownedImages.add(retained.image());
                if (retained.view() != null) {
                    previous.views.remove(retained.key());
                    previous.ownedViews.remove(retained.view());
                    replacement.ownedViews.add(retained.view());
                }
            }
        }
        resources = replacement;
        surfacePrevious = null;
        history.invalidate();
        lastPlan = null;
        this.width = width;
        this.height = height;
        transferExecutor =
                new TransferPassExecutor(
                        prepared.pack().resources(),
                        this::buffer,
                        this::image,
                        width,
                        height,
                        prepared.pack().passes());
        if (previous != null) previous.close();
    }

    static boolean retainsOnFramebufferResize(
            VeilShaderPack.Resource resource,
            boolean sceneAttachment,
            int oldWidth,
            int oldHeight,
            int newWidth,
            int newHeight,
            Map<String, VeilShaderPack.Resource> resources) {
        return sceneAttachment
                && resource.source() == VeilShaderPack.Source.OWNED
                && resource.kind() == VeilRenderGraph.Kind.IMAGE
                && resource.resolvedWidth(oldWidth, resources)
                        == resource.resolvedWidth(newWidth, resources)
                && resource.resolvedHeight(oldHeight, resources)
                        == resource.resolvedHeight(newHeight, resources);
    }

    private void validateAttachments(
            VeilShaderPack.Pass pass, int samples, int viewportWidth, int viewportHeight) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var properties = VkPhysicalDeviceProperties.calloc(stack);
            vkGetPhysicalDeviceProperties(runtime.vkDevice().getPhysicalDevice(), properties);
            if (pass.colors().size() > properties.limits().maxColorAttachments()) {
                throw new IllegalArgumentException(
                        "Pass "
                                + pass.name()
                                + " color attachment count exceeds live device limit="
                                + properties.limits().maxColorAttachments());
            }
        }
        int attachmentWidth = -1;
        int attachmentHeight = -1;
        for (var attachment : pass.colors()) {
            var resource = prepared.pack().resources().get(attachment.resource());
            if (resource.samples() != samples)
                throw new IllegalArgumentException("Pass " + pass.name() + " mixes sample counts");
            int width =
                    Math.max(
                            1,
                            resource.resolvedWidth(viewportWidth, prepared.pack().resources())
                                    >> attachment.mip());
            int height =
                    Math.max(
                            1,
                            resource.resolvedHeight(viewportHeight, prepared.pack().resources())
                                    >> attachment.mip());
            if (attachmentWidth < 0) {
                attachmentWidth = width;
                attachmentHeight = height;
            } else if (attachmentWidth != width || attachmentHeight != height) {
                throw new IllegalArgumentException(
                        "Pass " + pass.name() + " attachment dimensions differ");
            }
        }
        if (pass.depth() != null) {
            var resource = prepared.pack().resources().get(pass.depth().resource());
            int depthSamples = resource.hostImport() ? 1 : resource.samples();
            if (depthSamples != samples)
                throw new IllegalArgumentException(
                        "Pass " + pass.name() + " mixes color/depth sample counts");
            int depthWidth =
                    resource.hostImport()
                            ? viewportWidth
                            : Math.max(
                                    1,
                                    resource.resolvedWidth(
                                                    viewportWidth, prepared.pack().resources())
                                            >> pass.depth().mip());
            int depthHeight =
                    resource.hostImport()
                            ? viewportHeight
                            : Math.max(
                                    1,
                                    resource.resolvedHeight(
                                                    viewportHeight, prepared.pack().resources())
                                            >> pass.depth().mip());
            if (attachmentWidth >= 0
                    && (attachmentWidth != depthWidth || attachmentHeight != depthHeight)) {
                throw new IllegalArgumentException(
                        "Pass " + pass.name() + " color/depth dimensions differ");
            }
        }
    }

    private void uploadBuffer(GpuBuffer destination, byte[] bytes, String label) {
        GpuBuffer staging =
                runtime.device()
                        .createBuffer(
                                () -> label + "/staging",
                                GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                                bytes.length);
        try {
            try (var mapping = staging.map(false, true)) {
                mapping.data().put(bytes);
            }
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var copy = VkBufferCopy.calloc(1, stack);
                copy.get(0).srcOffset(0).dstOffset(0).size(bytes.length);
                vkCmdCopyBuffer(
                        runtime.commandBuffer(),
                        ((VulkanGpuBuffer) staging).vkBuffer(),
                        ((VulkanGpuBuffer) destination).vkBuffer(),
                        copy);
            }
        } finally {
            staging.close();
        }
    }

    public void execute(float seconds, float delta) {
        if (requiresScene()) throw new IllegalStateException("Shader pack requires scene inputs");
        executeFrame(seconds, delta);
    }

    public boolean requiresScene() {
        return prepared.pack().requiresScene();
    }

    public String name() {
        return prepared.pack().name();
    }

    public Map<String, VeilShaderPack.Setting> settings() {
        return prepared.pack().settings();
    }

    public boolean replacesVanillaSky() {
        return prepared.pack().replacesVanilla().sky();
    }

    public boolean replacesVanillaSun() {
        return prepared.pack().replacesVanilla().sun();
    }

    public boolean replacesVanillaSunriseSunset() {
        return prepared.pack().replacesVanilla().sunriseSunset();
    }

    public boolean replacesVanillaWater() {
        return prepared.pack().replacesVanilla().water();
    }

    public boolean usesOpaqueSceneInputs() {
        return hostRequirements.opaqueSceneInputs();
    }

    public boolean usesFluidGeometryWater() {
        return hostRequirements.fluidGeometryWater();
    }

    public boolean usesFluidGeometryLava() {
        return hostRequirements.fluidGeometryLava();
    }

    public boolean replacesVanillaWeather() {
        return prepared.pack().replacesVanilla().weather();
    }

    public boolean usesSurfaceTransforms() {
        return surfaceRing != null;
    }

    public boolean usesEnvironment() {
        return hostRequirements.environment();
    }

    public boolean usesNativeLighting() {
        return hostRequirements.nativeLighting();
    }

    long renderedFrames() {
        RenderSystem.assertOnRenderThread();
        return frames;
    }

    public boolean usesPbrAtlas() {
        return hostRequirements.pbrAtlasMask() != 0;
    }

    public int pbrAtlasMask() {
        return hostRequirements.pbrAtlasMask();
    }

    public boolean usesIncrementalWorldRayScene() {
        return hostRequirements.incrementalWorldRayScene();
    }

    public boolean usesMaterialInputs() {
        return hostRequirements.materialInputs();
    }

    public boolean usesWorldRayScene() {
        return hostRequirements.worldRayScene();
    }

    public boolean usesWorldRayAcceleration() {
        return passes.stream()
                .anyMatch(
                        pass ->
                                pass.descriptorTypes().entrySet().stream()
                                        .anyMatch(
                                                descriptor ->
                                                        descriptor.getValue()
                                                                        == org.lwjgl.vulkan
                                                                                .KHRAccelerationStructure
                                                                                .VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR
                                                                && pass.definition()
                                                                        .bindings()
                                                                        .containsKey(
                                                                                descriptor.getKey())
                                                                && pass
                                                                        .definition()
                                                                        .bindings()
                                                                        .get(descriptor.getKey())
                                                                        .resources()
                                                                        .stream()
                                                                        .anyMatch(
                                                                                name ->
                                                                                        prepared.pack()
                                                                                                .resources()
                                                                                                .get(
                                                                                                        name)
                                                                                                .worldRayScene())));
    }

    CreatorSceneRequirements creatorSceneRequirements() {
        return creatorSceneRequirements;
    }

    public boolean usesCreatorSceneData() {
        return hostRequirements.creatorSceneData();
    }

    public boolean usesCreatorGeometry() {
        return hostRequirements.creatorGeometry();
    }

    public boolean usesCreatorMeshData() {
        return hostRequirements.creatorMeshData();
    }

    public boolean usesShadowLightData() {
        return hostRequirements.shadowLightData();
    }

    boolean requestsSceneCategory(VeilScenePass.Category category) {
        return hostRequirements.requestsSceneCategory(category);
    }

    boolean repeatsSceneCategory(VeilScenePass.Category category) {
        return hostRequirements.repeatsSceneCategory(category);
    }

    public boolean usesAbi6SceneInputs() {
        return usesOpaqueSceneInputs() || usesMaterialInputs();
    }

    public void executeScene(RenderTarget scene, float seconds, float delta) {
        executeScene(scene, null, seconds, delta);
    }

    public void executeScene(
            RenderTarget scene, CameraRenderState camera, float seconds, float delta) {
        executeScene(scene, camera, seconds, delta, 0.0f);
    }

    public void executeScene(
            RenderTarget scene,
            CameraRenderState camera,
            float seconds,
            float delta,
            float sunAngle) {
        RenderSystem.assertOnRenderThread();
        if (!Float.isFinite(sunAngle))
            throw new IllegalArgumentException("Invalid Minecraft sun angle");
        frameSunAngle = sunAngle;
        if (scene.getColorTexture() == null
                || presenter != null && scene.getColorTexture().getFormat() != presentFormat) {
            throw new IllegalArgumentException(
                    "Scene color format differs from the prepared pipeline");
        }
        if (cameraRing != null || surfaceRing != null || !sceneCameraRings.isEmpty()) {
            if (camera == null)
                throw new IllegalArgumentException(
                        "Shader pack requires CameraData but no Minecraft camera was supplied");
            currentCamera = VeilCameraAbi.capture(camera);
        }
        resize(scene.width, scene.height);
        if (surfaceRing != null) {
            surfaceCurrent =
                    VeilSurfaceTransforms.current(currentCamera, scene.width, scene.height);
            try (var mapping = surfaceRing.currentBuffer().map(false, true)) {
                VeilSurfaceTransforms.write(mapping.data(), surfaceCurrent, surfacePrevious);
            }
        }
        if (colorPipelineRing != null) {
            var format = scene.getColorTexture().getFormat();
            try (var mapping = colorPipelineRing.currentBuffer().map(false, true)) {
                VeilColorPipeline.write(
                        mapping.data(),
                        VeilVulkanFormats.veil(format),
                        VeilVulkanFormats.veil(presentFormat),
                        com.mojang.blaze3d.vulkan.VulkanConst.toVk(format),
                        com.mojang.blaze3d.vulkan.VulkanConst.toVk(presentFormat),
                        prepared.pack().presentEncoding(),
                        dev.veil.api.VeilSceneColor.description());
            }
        }
        VeilSurfaceGuideFrame guides = null;
        if (!surfaceGuideChannels.isEmpty()) {
            var prior = surfacePrevious == null ? surfaceCurrent : surfacePrevious;
            guides =
                    new VeilSurfaceGuideFrame(
                            new dev.veil.api.VeilSurfaceGuides.Context(
                                    new Object(),
                                    Minecraft.getInstance().level,
                                    resources.frame,
                                    scene,
                                    surfaceCurrent.clip(),
                                    prior.clip(),
                                    surfaceCurrent.x(),
                                    surfaceCurrent.y(),
                                    surfaceCurrent.z(),
                                    prior.x(),
                                    prior.y(),
                                    prior.z(),
                                    surfacePrevious != null,
                                    surfaceGuideChannels),
                            action -> runtime.deferDestroy(action::run));
        }
        try {
            for (var definition : prepared.pack().resources().values()) {
                if (!definition.hostImport()) continue;
                String hostId = definition.hostId();
                VeilHostResourceRegistry.Resolved resolved =
                        VeilColorPipeline.HOST_ID.equals(hostId)
                                ? new VeilHostResourceRegistry.Resolved(
                                        colorPipelineRing.currentBuffer(), null, null)
                                : VeilSurfaceTransforms.HOST_ID.equals(hostId)
                                        ? new VeilHostResourceRegistry.Resolved(
                                                surfaceRing.currentBuffer(), null, null)
                                        : VeilSurfaceGuideFrame.isHost(hostId)
                                                ? guides.resolve(hostId)
                                                : VeilHostResourceRegistry.resolve(hostId, scene);
                if (resolved == null)
                    throw new IllegalStateException(
                            "Shader pack host resource is unavailable: " + hostId);
                String physical = graphPlan.physical(definition.name(), phase);
                if (definition.kind() == VeilRenderGraph.Kind.BUFFER) {
                    if (resolved.buffer() == null)
                        throw new IllegalStateException(
                                "Host resource did not resolve a buffer: " + hostId);
                    resources.buffers.put(physical, resolved.buffer());
                } else {
                    if (resolved.image() == null || resolved.view() == null)
                        throw new IllegalStateException(
                                "Host resource did not resolve an image: " + hostId);
                    resources.images.put(physical, resolved.image());
                    resources.views.put(physical, resolved.view());
                }
            }

            if (presenter != null) {
                resources.images.put(VeilShaderGraphPlan.SCENE_COLOR, scene.getColorTexture());
                resources.views.put(VeilShaderGraphPlan.SCENE_COLOR, scene.getColorTextureView());
            }
            executeFrame(seconds, delta);
            barriers(lastPlan.release());
        } finally {
            if (guides != null) {
                var lease = guides;
                runtime.deferDestroy(lease::release);
            }
        }
    }

    public void invalidateHistory() {
        surfacePrevious = null;
        history.invalidate();
    }

    public boolean historyValid() {
        return history.valid();
    }

    private void executeFrame(float seconds, float delta) {
        RenderSystem.assertOnRenderThread();
        if (closed) throw new IllegalStateException("Shader pack generation is closed");
        worldProjectionSlice =
                worldProjectionRequired ? RenderSystem.getProjectionMatrixBuffer() : null;
        frameSeconds = seconds;
        profiler.beginFrame(VeilShaderService.profiling());
        frameDelta = delta;
        phase = resources.frame;
        prepareCameraBuffer();
        prepareSceneCameraBuffers();
        if (!resources.initialized) {
            resources.rayScenes.values().forEach(VeilRayQueryScene::build);
            VkCommandBuffer cmd = runtime.commandBuffer();
            for (var definition : prepared.pack().resources().values()) {
                if (definition.kind() != VeilRenderGraph.Kind.BUFFER
                        || definition.initialContent() != VeilShaderPack.InitialContent.ZERO)
                    continue;
                for (int index = 0; index < definition.historyCount(); index++) {
                    GpuBuffer buffer =
                            resources.buffers.get(graphPlan.physical(definition.name(), index));
                    vkCmdFillBuffer(
                            cmd, ((VulkanGpuBuffer) buffer).vkBuffer(), 0, buffer.size(), 0);
                }
            }
            for (var resource : prepared.pack().resources().values()) {
                if (resource.kind() != VeilRenderGraph.Kind.IMAGE
                        || resource.initialContent() != VeilShaderPack.InitialContent.ZERO)
                    continue;
                int copies = resource.historyCount();
                for (int index = 0; index < copies; index++) {
                    String physical = graphPlan.physical(resource.name(), index);
                    if (!resource.nativeImage() || sceneAttachments.contains(resource.name())) {
                        clearTextureZero(resources.images.get(physical));
                    } else if (resource.nativeImage() && !resource.initializedAsset()) {
                        resources.nativeImages.get(physical).clearZero();
                    }
                }
            }
            resources.initialized = true;
            applyInitialSimulationCheckpoint();
        }
        var plan = graphPlan.frame(resources.frame);
        int passIndex = 0;
        for (RecordedPass pass : passes) {
            int profileIndex = passIndex;
            boolean labelled = VeilShaderDebugNames.begin(runtime, pass.label());
            boolean measured = false;
            try {
                profiler.begin(profileIndex);
                measured = true;
                barriers(plan.passes().get(passIndex++));
                if (pass.definition().transfer()) {
                    renderTransfers(pass);
                } else if (pass.definition().scenePass()) {
                    renderScene(pass);
                } else if (pass.definition().compute()) {
                    computeExecutor.execute(
                            pass,
                            runtime.commandBuffer(),
                            width,
                            height,
                            resources.dispatch[profileIndex]);
                } else if (pass.definition().raytrace()) {
                    try (MemoryStack stack = MemoryStack.stackPush()) {
                        VkCommandBuffer cmd = runtime.commandBuffer();
                        bind(pass, cmd, stack, width, height);
                        int[] dimensions = resources.dispatch[profileIndex];
                        pass.pipeline()
                                .value()
                                .ray
                                .trace(cmd, dimensions[0], dimensions[1], dimensions[2]);
                    }
                } else {
                    renderGraphics(pass);
                }
                metrics.passes.increment();
            } finally {
                try {
                    if (measured) profiler.end(profileIndex);
                } finally {
                    VeilShaderDebugNames.end(runtime, labelled);
                }
            }
        }
        if (presenter != null) {
            profiler.begin(passes.size());
            try {
                barriers(plan.present());
                present(resources.views.get(VeilShaderGraphPlan.SCENE_COLOR));
            } finally {
                profiler.end(passes.size());
            }
        }
        lastPlan = plan;
        resources.frame++;
        history.completeFrame(resources.frame);
        frames++;
        completeCameraFrame();
    }

    private void renderScene(RecordedPass pass) {
        String colorName = pass.definition().colors().getFirst().resource();
        String depthName = pass.definition().depthTarget();
        GpuTextureView color = resources.views.get(graphPlan.physical(colorName, phase));
        GpuTextureView depth = resources.views.get(graphPlan.physical(depthName, phase));
        VeilSceneCameraAbi.Snapshot camera = sceneCameras.get(pass.definition().name());
        GpuBufferSlice projection = sceneProjectionSlices.get(pass.definition().name());
        if (color == null || depth == null || camera == null || projection == null) {
            throw new IllegalStateException(
                    "Custom scene resources are unavailable: " + pass.definition().name());
        }
        try (var sceneRasterScope =
                sceneRasterPipelines.begin(pass.definition().scene().raster())) {
            VeilSceneReplay.render(
                    pass.label(),
                    pass.definition(),
                    camera,
                    projection,
                    color,
                    depth,
                    depthOnlySceneTerrain.contains(pass.definition().name()));
        }
    }

    private void renderGraphics(RecordedPass pass) {
        graphicsExecutor.execute(pass, runtime.commandBuffer());
    }

    private void renderDraws(RecordedPass pass, VkCommandBuffer cmd, MemoryStack stack) {
        drawExecutor.execute(pass.definition(), cmd, stack, limits.maxIndirectDrawCount());
    }

    private void renderGeometry(RecordedPass pass, VkCommandBuffer cmd, MemoryStack stack) {
        if (pass.definition().geometry().fluid()) {
            VeilFluidGeometryHost.drawFluid(
                    cmd,
                    stack,
                    pass.definition().geometry() == VeilShaderPack.Geometry.FLUID_LAVA
                            ? VeilMaterialIds.LAVA
                            : VeilMaterialIds.WATER,
                    pass.definition().geometry() == VeilShaderPack.Geometry.FLUID_WATER_PHYSICAL);
        } else if (pass.definition().geometry() == VeilShaderPack.Geometry.CUSTOM) {
            renderDraws(pass, cmd, stack);
        } else {
            vkCmdDraw(cmd, 3, 1, 0, 0);
        }
    }

    private void renderTransfers(RecordedPass pass) {
        transferExecutor.execute(runtime.commandBuffer(), pass.definition().transfers());
    }

    private void clearTextureZero(GpuTexture texture) {
        dev.veil.revive.client.graphics.resources.TextureInitialization.clearZero(
                runtime.commandBuffer(), texture);
    }

    private GpuBuffer lookupBuffer(String logical) {
        return resources.buffers.get(graphPlan.physical(logical, phase));
    }

    private GpuBuffer buffer(String logical) {
        GpuBuffer buffer = resources.buffers.get(graphPlan.physical(logical, phase));
        if (buffer == null)
            throw new IllegalStateException("Transfer buffer unavailable: " + logical);
        return buffer;
    }

    private long image(String logical) {
        String physical = graphPlan.physical(logical, phase);
        VeilNativeImage nativeImage = resources.nativeImages.get(physical);
        if (nativeImage != null) return nativeImage.image();
        GpuTexture image = resources.images.get(physical);
        if (!(image instanceof VulkanGpuTexture vulkan))
            throw new IllegalStateException("Transfer image unavailable: " + logical);
        return vulkan.vkImage();
    }

    private VeilFormat attachmentFormat(String logical) {
        var resource = prepared.pack().resources().get(logical);
        if (resource.format() != null) return resource.format();
        var image = resources.images.get(graphPlan.physical(logical, phase));
        if (image == null)
            throw new IllegalStateException("Imported attachment is unavailable: " + logical);
        return VeilVulkanFormats.veil(image.getFormat());
    }

    private AttachmentView attachmentView(String logical, int mip, int layer) {
        String physical = graphPlan.physical(logical, phase);
        VeilNativeImage nativeImage = resources.nativeImages.get(physical);
        if (nativeImage != null) {
            return new AttachmentView(
                    nativeImage.attachmentView(mip, layer),
                    Math.max(1, nativeImage.width() >> mip),
                    Math.max(1, nativeImage.height() >> mip));
        }
        if (mip != 0 || layer != 0)
            throw new IllegalStateException(
                    "Host/Minecraft attachments expose only mip 0 layer 0: " + logical);
        GpuTextureView view = resources.views.get(physical);
        if (!(view instanceof VulkanGpuTextureView vulkan))
            throw new IllegalStateException("Attachment view is unavailable: " + logical);
        return new AttachmentView(vulkan.vkImageView(), view.getWidth(0), view.getHeight(0));
    }

    private void prepareCameraBuffer() {
        if (cameraRing == null) return;
        if (currentCamera == null)
            throw new IllegalStateException("CameraData was not captured for this frame");
        GpuBuffer buffer = cameraRing.currentBuffer();
        try (var mapping = buffer.map(false, true)) {
            VeilCameraAbi.write(
                    mapping.data(),
                    currentCamera,
                    history.previousCamera(),
                    width,
                    height,
                    history.cameraValid());
        }
        cameraSlice = buffer.slice(0, VeilCameraAbi.SIZE);
        if (!cameraReported) {
            cameraReported = true;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil CameraData ABI ACTIVE: stable Minecraft projection/view rotation (head-bob excluded) + previous camera state");
        }
    }

    private void prepareSceneCameraBuffers() {
        if (sceneCameraRings.isEmpty()) return;
        if (currentCamera == null)
            throw new IllegalStateException("Custom scene camera requires the Minecraft camera");
        for (VeilShaderPack.Pass pass : prepared.pack().passes()) {
            if (!pass.scenePass()) continue;
            String physical = graphPlan.physical(pass.colors().getFirst().resource(), phase);
            GpuTextureView target = resources.views.get(physical);
            if (target == null)
                throw new IllegalStateException(
                        "Custom scene target is unavailable: " + pass.name());
            var snapshot =
                    VeilSceneCameraMath.create(
                            pass.scene().camera(),
                            currentCamera,
                            frameSunAngle,
                            target.getWidth(0),
                            target.getHeight(0),
                            runtime.device().getDeviceInfo().isZZeroToOne());
            MappableRingBuffer sceneCameraRing = sceneCameraRings.get(pass.name());
            GpuBuffer sceneCameraBuffer = sceneCameraRing.currentBuffer();
            try (var mapping = sceneCameraBuffer.map(false, true)) {
                VeilSceneCameraAbi.write(mapping.data(), snapshot);
            }
            MappableRingBuffer projectionRing = sceneProjectionRings.get(pass.name());
            GpuBuffer projectionBuffer = projectionRing.currentBuffer();
            try (var mapping = projectionBuffer.map(false, true)) {
                snapshot.projection().get(0, mapping.data());
            }
            sceneCameras.put(pass.name(), snapshot);
            if (pass.name().equals("shadow"))
                VeilShadowMotionProbe.sceneCamera(snapshot, currentCamera);
            if (pass.name().equals("shadowSecondary") || pass.name().equals("shadowNear"))
                VeilShadowMotionProbe.secondaryCamera(snapshot);
            sceneCameraSlices.put(pass.name(), sceneCameraBuffer.slice(0, VeilSceneCameraAbi.SIZE));
            sceneProjectionSlices.put(pass.name(), projectionBuffer.slice(0, 64));
        }
    }

    private void completeCameraFrame() {
        if (colorPipelineRing != null) colorPipelineRing.rotate();
        if (surfaceRing != null) {
            surfacePrevious = surfaceCurrent;
            surfaceCurrent = null;
            surfaceRing.rotate();
        }
        if (cameraRing != null) {
            history.completeCamera(currentCamera);
            cameraSlice = null;
            cameraRing.rotate();
        }
        sceneCameraRings.values().forEach(MappableRingBuffer::rotate);
        sceneProjectionRings.values().forEach(MappableRingBuffer::rotate);
        sceneCameras.clear();
        sceneCameraSlices.clear();
        sceneProjectionSlices.clear();
        currentCamera = null;
    }

    private void present(GpuTextureView target) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            if (!(target instanceof VulkanGpuTextureView output))
                throw new IllegalStateException("Vulkan presentation target is unavailable");
            VkCommandBuffer cmd = runtime.commandBuffer();
            Pipeline pipeline = presenter.value();
            var colors = VkRenderingAttachmentInfo.calloc(1, stack);
            colors.get(0)
                    .sType$Default()
                    .imageView(output.vkImageView())
                    .imageLayout(VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL)
                    .loadOp(VK_ATTACHMENT_LOAD_OP_LOAD)
                    .storeOp(VK_ATTACHMENT_STORE_OP_STORE);
            var rendering =
                    VkRenderingInfo.calloc(stack)
                            .sType$Default()
                            .layerCount(1)
                            .viewMask(0)
                            .pColorAttachments(colors);
            rendering.renderArea().offset().set(0, 0);
            rendering.renderArea().extent().set(target.getWidth(0), target.getHeight(0));
            KHRDynamicRendering.vkCmdBeginRenderingKHR(cmd, rendering);
            try {
                vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline.handle());
                String logical = prepared.pack().present();
                String physical = graphPlan.physical(logical, phase);
                VeilNativeImage nativeInput = resources.nativeImages.get(physical);
                long inputView;
                long inputSampler;
                if (nativeInput != null) {
                    inputView = nativeInput.view();
                    inputSampler = nativeInput.sampler();
                } else {
                    var input = (VulkanGpuTextureView) resources.views.get(physical);
                    if (input == null)
                        throw new IllegalStateException(
                                "Presentation input is unavailable: " + logical);
                    inputView = input.vkImageView();
                    VeilSampler sampler = resources.samplers.get(logical);
                    inputSampler =
                            sampler != null
                                    ? sampler.handle()
                                    : ((VulkanGpuSampler)
                                                    RenderSystem.getSamplerCache()
                                                            .getClampToEdge(FilterMode.LINEAR))
                                            .vkSampler();
                }
                VeilResourceBindings.allocate(stack, 1)
                        .image(
                                0,
                                inputView,
                                inputSampler,
                                VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
                                VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER)
                        .push(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline.layout(), 0);
                var viewport =
                        VkViewport.calloc(1, stack)
                                .x(0)
                                .y(0)
                                .width(target.getWidth(0))
                                .height(target.getHeight(0))
                                .minDepth(0)
                                .maxDepth(1);
                var scissor = VkRect2D.calloc(1, stack);
                scissor.offset().set(0, 0);
                scissor.extent().set(target.getWidth(0), target.getHeight(0));
                vkCmdSetViewport(cmd, 0, viewport);
                vkCmdSetScissor(cmd, 0, scissor);
                vkCmdDraw(cmd, 3, 1, 0, 0);
            } finally {
                KHRDynamicRendering.vkCmdEndRenderingKHR(cmd);
            }
        }
        metrics.passes.increment();
    }

    private float frameSeconds;
    private float frameDelta;
    private float frameSunAngle;

    private static Map<Integer, Integer> descriptorTypes(VeilShaderInterface shaderInterface) {
        var result = new LinkedHashMap<Integer, Integer>();
        for (VeilShaderInterface.Descriptor descriptor : shaderInterface.descriptors()) {
            if (descriptor.set() == 0
                    && result.put(descriptor.binding(), descriptor.descriptorType()) != null) {
                throw new IllegalArgumentException(
                        "Duplicate reflected descriptor binding " + descriptor.binding());
            }
        }
        return Map.copyOf(result);
    }

    private void bind(
            RecordedPass pass,
            VkCommandBuffer cmd,
            MemoryStack stack,
            int targetWidth,
            int targetHeight) {
        int bindPoint =
                pass.definition().compute()
                        ? VK_PIPELINE_BIND_POINT_COMPUTE
                        : pass.definition().raytrace()
                                ? VK_PIPELINE_BIND_POINT_RAY_TRACING_KHR
                                : VK_PIPELINE_BIND_POINT_GRAPHICS;
        Pipeline pipeline = pass.pipeline().value();
        vkCmdBindPipeline(cmd, bindPoint, pipeline.handle());
        int descriptorCount =
                pass.definition().bindings().size()
                        + (pass.definition().cameraData() ? 1 : 0)
                        + (pass.definition().sceneProjectionData() ? 1 : 0)
                        + (pass.definition().sceneCamera() != null ? 1 : 0);
        if (descriptorCount != 0) {
            var bindings = VeilResourceBindings.allocate(stack, descriptorCount);
            for (var bindingEntry : pass.definition().bindings().entrySet()) {
                VeilShaderPack.Binding binding = bindingEntry.getValue();
                Integer descriptorTypeValue = pass.descriptorTypes().get(bindingEntry.getKey());
                if (descriptorTypeValue == null)
                    throw new IllegalStateException(
                            "Missing reflected descriptor binding " + bindingEntry.getKey());
                int descriptorType = descriptorTypeValue;
                if (descriptorType
                        == org.lwjgl.vulkan.KHRAccelerationStructure
                                .VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR) {
                    String logical = binding.resources().getFirst();
                    VeilRayQueryScene scene = resources.rayScenes.get(logical);
                    long handle =
                            scene != null
                                    ? scene.handle()
                                    : prepared.pack().resources().get(logical).worldRayScene()
                                            ? VeilWorldRayScene.accelerationHandle()
                                            : 0;
                    if (handle == 0)
                        throw new IllegalStateException(
                                "Acceleration structure unavailable: " + logical);
                    bindings.accelerationStructure(bindingEntry.getKey(), handle);
                    continue;
                }
                if (descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_BUFFER
                        || descriptorType == VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER) {
                    var infos =
                            bindings.buffers(
                                    bindingEntry.getKey(),
                                    binding.resources().size(),
                                    descriptorType);
                    for (int i = 0; i < binding.resources().size(); i++) {
                        String logical = binding.resources().get(i);
                        String physical = graphPlan.physical(binding.graphResource(logical), phase);
                        GpuBuffer buffer = resources.buffers.get(physical);
                        if (buffer == null)
                            throw new IllegalStateException(
                                    "Buffer resource unavailable: " + logical);
                        infos.get(i)
                                .buffer(((VulkanGpuBuffer) buffer).vkBuffer())
                                .offset(binding.offset())
                                .range(
                                        bufferBindingLimits.validate(
                                                binding,
                                                descriptorType,
                                                buffer.size(),
                                                0,
                                                logical));
                    }
                    continue;
                }

                boolean storageDescriptor = descriptorType == VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
                int imageLayout =
                        storageDescriptor
                                ? VK_IMAGE_LAYOUT_GENERAL
                                : VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
                var infos =
                        bindings.images(
                                bindingEntry.getKey(),
                                binding.resources().size(),
                                imageLayout,
                                descriptorType);
                for (int i = 0; i < binding.resources().size(); i++) {
                    String logical = binding.resources().get(i);
                    String physical = graphPlan.physical(binding.graphResource(logical), phase);
                    VeilShaderPack.Resource definition = prepared.pack().resources().get(logical);
                    int resourceLayout =
                            !storageDescriptor
                                            && definition != null
                                            && VeilHostResourceRegistry.BLOCK_ATLAS.equals(
                                                    definition.hostId())
                                    ? VK_IMAGE_LAYOUT_GENERAL
                                    : imageLayout;
                    VeilNativeImage nativeImage = resources.nativeImages.get(physical);
                    if (nativeImage != null) {
                        int mip = binding.selectedMip(storageDescriptor);
                        infos.get(i)
                                .imageView(
                                        nativeImage.view(
                                                mip, binding.baseLayer(), binding.layerCount()))
                                .sampler(storageDescriptor ? VK_NULL_HANDLE : nativeImage.sampler())
                                .imageLayout(imageLayout);
                        continue;
                    }
                    if (binding.mip() >= 0
                            || binding.baseLayer() != 0
                            || binding.layerCount() != 0) {
                        throw new IllegalStateException(
                                "Subresource views require a Veil native texture/storage image: "
                                        + logical);
                    }
                    var view = (VulkanGpuTextureView) resources.views.get(physical);
                    if (view == null)
                        throw new IllegalStateException("Image resource unavailable: " + logical);
                    if (!storageDescriptor
                            && definition != null
                            && definition.sampler().compare() != null) {
                        int format =
                                VeilVulkanFormats.vk(
                                        VeilVulkanFormats.veil(view.texture().getFormat()));
                        if (!validatedComparisonFormats.contains(format)) {
                            dev.veil.revive.client.graphics.resources.ImageCapabilities
                                    .validateDepthComparison(
                                            runtime.vkDevice().getPhysicalDevice(), format);
                            validatedComparisonFormats.add(format);
                        }
                    }
                    VeilSampler sampler =
                            definition == null ? null : resources.samplers.get(definition.name());
                    if (sampler == null)
                        throw new IllegalStateException(
                                "Sampler unavailable for image resource: " + logical);
                    infos.get(i)
                            .imageView(view.vkImageView())
                            .sampler(storageDescriptor ? VK_NULL_HANDLE : sampler.handle())
                            .imageLayout(resourceLayout);
                }
            }
            if (pass.definition().sceneProjectionData()) {
                bindings.buffer(
                        VeilSceneProjectionAbi.BINDING,
                        worldProjectionSlice,
                        VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER);
            }
            if (pass.definition().cameraData()) {
                if (cameraSlice == null)
                    throw new IllegalStateException("CameraData buffer is unavailable");
                bindings.buffer(
                        VeilCameraAbi.BINDING, cameraSlice, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER);
            }
            if (pass.definition().sceneCamera() != null) {
                GpuBufferSlice sceneCamera = sceneCameraSlices.get(pass.definition().sceneCamera());
                if (sceneCamera == null)
                    throw new IllegalStateException(
                            "Custom scene camera buffer is unavailable: "
                                    + pass.definition().sceneCamera());
                bindings.buffer(
                        VeilSceneCameraAbi.BINDING, sceneCamera, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER);
            }
            bindings.push(cmd, bindPoint, pipeline.layout(), 0);
        }
        if (pass.definition().frameData()) {
            var data =
                    VeilFrameAbi.write(
                            stack.malloc(VeilFrameAbi.SIZE),
                            VeilFrameAbi.versionForPack(prepared.pack().abiVersion()),
                            frames,
                            targetWidth,
                            targetHeight,
                            frameSeconds,
                            frameDelta,
                            history.valid(),
                            frameSunAngle);
            int stages = 0;
            for (var push : pass.program().shaderInterface().pushConstants())
                stages |= push.stageFlags();
            if (stages != 0) vkCmdPushConstants(cmd, pipeline.layout(), stages, 0, data);
        }
    }

    private void barriers(List<VeilRenderGraph.Barrier> barriers) {
        if (barriers.isEmpty()) return;
        barrierRecorder.record(
                runtime.commandBuffer(),
                barriers,
                resources.buffers,
                resources.images,
                resources.nativeImages);
        metrics.barriers.add(barriers.size());
    }

    List<String> recordedPassNames() {
        RenderSystem.assertOnRenderThread();
        if (closed) throw new IllegalStateException("Shader pack generation is closed");
        return passes.stream().map(pass -> pass.definition().name()).toList();
    }

    Set<String> outputNames() {
        RenderSystem.assertOnRenderThread();
        if (closed) throw new IllegalStateException("Shader pack generation is closed");
        return Set.copyOf(resources.views.keySet());
    }

    List<VeilRenderGraph.ImageState> transferImageStates(String physical) {
        RenderSystem.assertOnRenderThread();
        if (closed || lastPlan == null)
            throw new IllegalStateException(
                    "Shader image has no completed graph state: " + physical);
        var states = lastPlan.imageStates().getOrDefault(physical, List.of());
        if (states.isEmpty())
            throw new IllegalArgumentException(
                    "Shader image has no tracked subresources: " + physical);
        return states;
    }

    GpuTextureView output(String name) {
        RenderSystem.assertOnRenderThread();
        if (closed) throw new IllegalStateException("Shader pack generation is closed");
        GpuTextureView output = resources.views.get(graphPlan.physical(name, phase));
        if (output == null) throw new IllegalArgumentException("Unknown shader output: " + name);
        return output;
    }

    /**
     * Explicit GPU restoration of the base mip and first layer of a creator-owned native image. The
     * input field contains raw component bits, not interpreted float values. The caller must match
     * the original image format. Copy-source staging is retired only after GPU completion.
     */
    void restoreSimulationField(String logical, dev.veil.api.VeilSimulationFieldSnapshot field) {
        restoreSimulationField(logical, 0, 0, field);
    }

    void restoreSimulationField(
            String logical, int mip, int layer, dev.veil.api.VeilSimulationFieldSnapshot field) {
        restoreSimulationField(logical, mip, layer, field, null);
    }

    private dev.veil.api.VeilSimulationGpuField.Plan simulationRestoreLayout(
            String logical, int mip, int layer, dev.veil.api.VeilSimulationFieldSnapshot field) {
        RenderSystem.assertOnRenderThread();
        java.util.Objects.requireNonNull(field, "field");
        if (closed || resources == null)
            throw new IllegalStateException("Shader generation is unavailable for restoration");
        var declaration = prepared.pack().resources().get(logical);
        if (declaration == null
                || declaration.kind() != VeilRenderGraph.Kind.IMAGE
                || !declaration.usages().contains(VeilResourceUsage.TRANSFER_DESTINATION)
                || !declaration.persistent()
                || declaration.samples() != 1) {
            throw new IllegalArgumentException(
                    "Simulation restoration requires a persistent, single-sample transfer-destination image: "
                            + logical);
        }
        String physical = graphPlan.physical(logical, phase);
        VeilNativeImage nativeImage = resources.nativeImages.get(physical);
        if (nativeImage == null)
            throw new IllegalArgumentException(
                    "Simulation restoration currently requires a native Vulkan image: " + logical);
        int depth = declaration.image3d() ? nativeImage.depth() : 1;
        if (layer < 0 || layer >= nativeImage.layers())
            throw new IllegalArgumentException("Simulation layer outside GPU image: " + logical);
        var plan =
                dev.veil.api.VeilSimulationGpuField.plan(
                        declaration.format(),
                        nativeImage.width(),
                        nativeImage.height(),
                        depth,
                        mip,
                        nativeImage.mipLevels());
        if (field.width() != plan.width()
                || field.height() != plan.height()
                || field.depth() != plan.depth()
                || field.components() != plan.components()
                || field.type() != plan.type())
            throw new IllegalArgumentException(
                    "Simulation snapshot does not match GPU image: " + logical);
        return plan;
    }

    private void restoreSimulationField(
            String logical,
            int mip,
            int layer,
            dev.veil.api.VeilSimulationFieldSnapshot field,
            List<VeilRenderGraph.ImageState> initialStates) {
        if (closed || resources == null || !resources.initialized)
            throw new IllegalStateException("Shader generation is unavailable for restoration");
        var plan = simulationRestoreLayout(logical, mip, layer, field);
        String physical = graphPlan.physical(logical, phase);
        VeilNativeImage nativeImage = resources.nativeImages.get(physical);
        var imageStates = initialStates == null ? transferImageStates(physical) : initialStates;
        GpuBuffer upload =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil creator simulation upload: " + logical,
                                GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                                plan.bytes());
        try {
            try (var mapped = upload.map(false, true)) {
                plan.prepareUpload(field, mapped.data());
            }
            var transferWrite = VeilRenderGraph.State.of(VeilRenderGraph.Access.TRANSFER_WRITE);
            var transition =
                    dev.veil.revive.client.graphics.synchronization.ImageTransferTransitions.plan(
                            physical,
                            imageStates,
                            VeilRenderGraph.Subresource.image(mip, 1, layer, 1),
                            transferWrite);
            barriers(transition.acquire());
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var copy =
                        VkBufferImageCopy.calloc(1, stack)
                                .bufferOffset(0)
                                .bufferRowLength(0)
                                .bufferImageHeight(0);
                copy.imageSubresource()
                        .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                        .mipLevel(mip)
                        .baseArrayLayer(layer)
                        .layerCount(1);
                copy.imageOffset().set(0, 0, 0);
                copy.imageExtent().set(plan.width(), plan.height(), plan.depth());
                vkCmdCopyBufferToImage(
                        runtime.commandBuffer(),
                        ((VulkanGpuBuffer) upload).vkBuffer(),
                        nativeImage.image(),
                        VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                        copy);
            }
            barriers(transition.restore());
            runtime.deferDestroy(upload::close);
        } catch (RuntimeException | Error failure) {
            upload.close();
            throw failure;
        }
    }

    /**
     * Opt-in asynchronous readback of the base mip and first layer of one creator-defined color
     * image. Callback is invoked after GPU completion by the existing deferred GPU retirement
     * mechanism. The integration must not assume an arbitrary thread can safely touch Minecraft
     * state. Does not save to disk or infer shaderpack-specific simulation semantics.
     */
    void readSimulationField(
            String logical,
            java.util.function.Consumer<dev.veil.api.VeilSimulationFieldSnapshot> completed) {
        readSimulationField(logical, 0, 0, completed);
    }

    void readSimulationField(
            String logical,
            int mip,
            int layer,
            java.util.function.Consumer<dev.veil.api.VeilSimulationFieldSnapshot> completed) {
        java.util.Objects.requireNonNull(completed, "completed");
        readSimulationCheckpoint(
                Map.of(
                        "field",
                        new dev.veil.api.VeilSimulationCheckpoint.Selection(logical, mip, layer)),
                dev.veil.api.VeilSimulationStateStore.DEFAULT_MAX_SNAPSHOT_BYTES,
                checkpoint -> completed.accept(checkpoint.fields().get("field").data()));
    }

    public void readOutput(String name, GpuBuffer destination, Runnable whenComplete) {
        readImage(
                graphPlan.physical(name, phase),
                VK_IMAGE_ASPECT_COLOR_BIT,
                destination,
                whenComplete);
    }

    public void readDepthOutput(String name, GpuBuffer destination, Runnable whenComplete) {
        readImage(
                graphPlan.physical(name, phase),
                VK_IMAGE_ASPECT_DEPTH_BIT,
                destination,
                whenComplete);
    }

    public void readPresented(GpuBuffer destination, Runnable whenComplete) {
        if (presenter == null)
            throw new IllegalStateException("Shader pack has no presentation output");
        readImage(
                VeilShaderGraphPlan.SCENE_COLOR,
                VK_IMAGE_ASPECT_COLOR_BIT,
                destination,
                whenComplete);
    }

    private void readImage(
            String physical, int aspect, GpuBuffer destination, Runnable whenComplete) {
        RenderSystem.assertOnRenderThread();
        if (closed) throw new IllegalStateException("Shader pack generation is closed");
        GpuTextureView view = resources.views.get(physical);
        VeilNativeImage nativeImage = resources.nativeImages.get(physical);
        if (view == null && nativeImage == null)
            throw new IllegalArgumentException("Unknown shader output: " + physical);
        int width = nativeImage == null ? view.getWidth(0) : nativeImage.width();
        int height = nativeImage == null ? view.getHeight(0) : nativeImage.height();
        if (nativeImage != null) {
            String logical = physical.split("#", 2)[0];
            var definition = prepared.pack().resources().get(logical);
            if (definition == null
                    || !definition.usages().contains(VeilResourceUsage.TRANSFER_SOURCE))
                throw new IllegalArgumentException(
                        "Image readback requires transfer-source usage: " + logical);
            if (definition.samples() != 1 || nativeImage.depth() != 1 || nativeImage.layers() != 1)
                throw new IllegalArgumentException(
                        "Image readback requires a single-sample 2D image: " + logical);
            long bytes = imageReadbackBytes(definition.format(), aspect, width, height);
            if (destination.size() < bytes)
                throw new IllegalArgumentException(
                        "Image readback buffer too small: " + destination.size() + " < " + bytes);
        } else if (aspect == VK_IMAGE_ASPECT_DEPTH_BIT
                && !view.texture().getFormat().hasDepthAspect())
            throw new IllegalArgumentException("Shader output is not depth: " + physical);
        if (!resources.initialized)
            throw new IllegalStateException("Shader outputs have not been rendered");
        var imageStates = transferImageStates(physical);
        var transferRead = VeilRenderGraph.State.of(VeilRenderGraph.Access.TRANSFER_READ);
        var transition =
                dev.veil.revive.client.graphics.synchronization.ImageTransferTransitions.plan(
                        physical,
                        imageStates,
                        VeilRenderGraph.Subresource.image(0, 1, 0, 1),
                        transferRead);
        barriers(transition.acquire());
        try (MemoryStack stack = MemoryStack.stackPush()) {
            long image =
                    nativeImage != null
                            ? nativeImage.image()
                            : ((VulkanGpuTexture) view.texture()).vkImage();
            var copy =
                    VkBufferImageCopy.calloc(1, stack)
                            .bufferOffset(0)
                            .bufferRowLength(0)
                            .bufferImageHeight(0);
            copy.imageSubresource().aspectMask(aspect).mipLevel(0).baseArrayLayer(0).layerCount(1);
            copy.imageOffset().set(0, 0, 0);
            copy.imageExtent().set(width, height, 1);
            vkCmdCopyImageToBuffer(
                    runtime.commandBuffer(),
                    image,
                    VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                    ((VulkanGpuBuffer) destination).vkBuffer(),
                    copy);
        }
        barriers(transition.restore());
        runtime.deferDestroy(whenComplete::run);
    }

    int[] outputExtent(String name) {
        RenderSystem.assertOnRenderThread();
        if (closed) throw new IllegalStateException("Shader pack generation is closed");
        var nativeImage = resources.nativeImages.get(graphPlan.physical(name, phase));
        if (nativeImage != null) return new int[] {nativeImage.width(), nativeImage.height()};
        var view = output(name);
        return new int[] {view.getWidth(0), view.getHeight(0)};
    }

    static long imageReadbackBytes(VeilFormat format, int aspect, int width, int height) {
        if (width < 1 || height < 1) throw new IllegalArgumentException("Invalid readback extent");
        int stride;
        if (aspect == VK_IMAGE_ASPECT_COLOR_BIT && !format.depth() && !format.stencil())
            stride = format.bytesPerTexel();
        else if (aspect == VK_IMAGE_ASPECT_DEPTH_BIT && format.depth())
            stride = format == VeilFormat.D16_UNORM ? 2 : 4;
        else throw new IllegalArgumentException("Readback aspect does not match image format");
        return Math.multiplyExact(Math.multiplyExact((long) width, height), stride);
    }

    public String status() {
        return "pack="
                + prepared.pack().name()
                + " frames="
                + frames
                + " scene="
                + requiresScene()
                + " present="
                + prepared.pack().present()
                + " history_valid="
                + history.valid()
                + " camera_data="
                + (cameraRing != null)
                + " shader_resources_active="
                + prepared.pack().resources().size();
    }

    public String performanceReport() {
        profiler.poll();
        return VeilShaderPerformanceReport.build(
                new VeilShaderPerformanceReport.State(
                        prepared.pack(),
                        limits.report(),
                        passes,
                        resources.dispatch,
                        profiler::report,
                        this::performanceTarget,
                        width,
                        height,
                        presenter != null,
                        resources.rayScenes.values().stream()
                                .mapToLong(VeilRayQueryScene::bytes)
                                .sum(),
                        List.of(
                                VeilWorldRayScene.telemetry(),
                                VeilCreatorSceneHost.telemetry(),
                                VeilCreatorMeshHost.telemetry(),
                                VeilShadowLightHost.telemetry(),
                                VeilEntityMeshCapture.telemetry())));
    }

    private VeilShaderPerformanceReport.TargetSize performanceTarget(String logical) {
        var target = resources.views.get(graphPlan.physical(logical, phase));
        return new VeilShaderPerformanceReport.TargetSize(target.getWidth(0), target.getHeight(0));
    }

    void requireProfileSamples(long minimum) {
        profiler.poll();
        for (int index = 0; index < passes.size() + (presenter == null ? 0 : 1); index++) {
            if (profiler.samples(index) < minimum)
                throw new IllegalStateException(
                        "GPU profiler has insufficient completed samples for pass " + index);
        }
    }

    void resetProfile() {
        profiler.reset();
    }

    @Override
    public void close() {
        RenderSystem.assertOnRenderThread();
        if (closed) return;
        closed = true;
        if (initialCheckpointCompletion != null) {
            initialCheckpointCompletion.completeExceptionally(
                    new IllegalStateException("Generation closed before initial restoration"));
            initialCheckpointCompletion = null;
            initialCheckpoint = null;
        }
        var cleanup = new dev.veil.revive.core.lifecycle.CloseSequence();
        cleanup.run(sceneRasterPipelines::close);
        cleanup.run(profiler::close);
        if (resources != null) {
            var previous = resources;
            resources = null;
            cleanup.run(previous::close);
        }
        if (presenter != null) {
            var previous = presenter;
            presenter = null;
            cleanup.run(previous::close);
        }
        cleanup.each(
                passes,
                pass -> {
                    if (pass.pipeline() != null) pass.pipeline().close();
                });
        passes.clear();
        if (cameraRing != null) {
            var previous = cameraRing;
            cleanup.run(previous::close);
        }
        if (surfaceRing != null) cleanup.run(surfaceRing::close);
        if (colorPipelineRing != null) cleanup.run(colorPipelineRing::close);
        cleanup.each(sceneCameraRings.values(), MappableRingBuffer::close);
        cleanup.each(sceneProjectionRings.values(), MappableRingBuffer::close);
        sceneCameraRings.clear();
        sceneProjectionRings.clear();
        cleanup.finish();
    }
}
