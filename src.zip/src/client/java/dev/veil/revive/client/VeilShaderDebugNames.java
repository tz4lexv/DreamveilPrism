package dev.veil.revive.client;

import static org.lwjgl.vulkan.EXTDebugUtils.*;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkDebugUtilsLabelEXT;
import org.lwjgl.vulkan.VkDebugUtilsObjectNameInfoEXT;

final class VeilShaderDebugNames {
    private VeilShaderDebugNames() {}

    static void name(VeilVulkanRuntime runtime, int type, long handle, String name) {
        if (!runtime.vkDevice()
                .getPhysicalDevice()
                .getInstance()
                .getCapabilities()
                .VK_EXT_debug_utils) return;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            vkSetDebugUtilsObjectNameEXT(
                    runtime.vkDevice(),
                    VkDebugUtilsObjectNameInfoEXT.calloc(stack)
                            .sType$Default()
                            .objectType(type)
                            .objectHandle(handle)
                            .pObjectName(stack.UTF8(name)));
        }
    }

    static boolean begin(VeilVulkanRuntime runtime, String name) {
        if (!runtime.vkDevice()
                        .getPhysicalDevice()
                        .getInstance()
                        .getCapabilities()
                        .VK_EXT_debug_utils
                || !VeilShaderService.profiling() && !Boolean.getBoolean("veil.shaderDebug"))
            return false;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            vkCmdBeginDebugUtilsLabelEXT(
                    runtime.commandBuffer(),
                    VkDebugUtilsLabelEXT.calloc(stack)
                            .sType$Default()
                            .pLabelName(stack.UTF8(name)));
        }
        return true;
    }

    static void end(VeilVulkanRuntime runtime, boolean began) {
        if (began) vkCmdEndDebugUtilsLabelEXT(runtime.commandBuffer());
    }
}
