package dev.veil.revive.client;

import com.mojang.blaze3d.systems.DeviceType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanDevice;

import dev.veil.revive.mixin.GpuDeviceAccessor;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.vma.Vma;
import org.lwjgl.util.vma.VmaBudget;

final class VeilMemoryMonitor {
    private static final int VK_MAX_MEMORY_HEAPS = 16;
    private static long nextSampleNs;
    private static long usageBytes;
    private static long budgetBytes;
    private static int heapIndex = -1;
    private static long blockBytes;
    private static long allocationBytes;
    private static long blockCount;
    private static long allocationCount;
    private static double pressure;
    private static long samples;
    private static boolean vulkan;
    private static boolean integrated;

    private VeilMemoryMonitor() {}

    static void update() {
        long now = System.nanoTime();
        if (now < nextSampleNs) return;
        nextSampleNs = now + 1_000_000_000L;

        var device = RenderSystem.getDevice();
        vulkan = device.getDeviceInfo().backendName().equalsIgnoreCase("Vulkan");
        integrated = device.getDeviceInfo().type() == DeviceType.INTEGRATED;
        if (!vulkan) return;

        var backend = ((GpuDeviceAccessor) (Object) device).veil$backend();
        if (!(backend instanceof VulkanDevice vk)) return;

        try (MemoryStack stack = MemoryStack.stackPush()) {
            VmaBudget.Buffer budgets = VmaBudget.calloc(VK_MAX_MEMORY_HEAPS, stack);
            Vma.vmaGetHeapBudgets(vk.vma(), budgets);

            long selectedUsage = 0L;
            long selectedBudget = 0L;
            int selectedHeap = -1;
            double worst = -1.0;
            for (int i = 0; i < VK_MAX_MEMORY_HEAPS; i++) {
                VmaBudget heap = budgets.get(i);
                long budget = heap.budget();
                long usage = heap.usage();
                if (budget <= 0L || usage <= 0L) continue;
                double ratio = (double) usage / (double) budget;
                if (ratio > worst) {
                    worst = ratio;
                    selectedUsage = usage;
                    selectedBudget = budget;
                    selectedHeap = i;
                }
            }
            if (selectedBudget > 0L) {
                usageBytes = selectedUsage;
                budgetBytes = selectedBudget;
                heapIndex = selectedHeap;
                var statistics = budgets.get(selectedHeap).statistics();
                blockBytes = statistics.blockBytes();
                allocationBytes = statistics.allocationBytes();
                blockCount = Integer.toUnsignedLong(statistics.blockCount());
                allocationCount = Integer.toUnsignedLong(statistics.allocationCount());
                pressure = Math.min(2.0, Math.max(0.0, worst));
                ReviveRuntime.memoryBudget().updateExternalBudget(selectedBudget, selectedUsage);
                samples++;
            }
        } catch (RuntimeException ignored) {

        }
    }

    static boolean integrated() {
        return integrated;
    }

    static double pressure() {
        return pressure;
    }

    static String telemetry() {
        return "vulkan_memory_monitor="
                + vulkan
                + "\n"
                + "gpu_integrated="
                + integrated
                + "\n"
                + "gpu_heap_usage_bytes="
                + usageBytes
                + "\n"
                + "gpu_heap_budget_bytes="
                + budgetBytes
                + "\n"
                + "gpu_heap_index="
                + heapIndex
                + "\ngpu_heap_vma_block_bytes="
                + blockBytes
                + "\ngpu_heap_vma_allocation_bytes="
                + allocationBytes
                + "\ngpu_heap_vma_unallocated_block_bytes="
                + Math.max(0L, blockBytes - allocationBytes)
                + "\ngpu_heap_vma_block_count="
                + blockCount
                + "\ngpu_heap_vma_allocation_count="
                + allocationCount
                + "\n"
                + "gpu_heap_pressure="
                + String.format(java.util.Locale.ROOT, "%.4f", pressure)
                + "\n"
                + "gpu_heap_budget_samples="
                + samples
                + "\n";
    }
}
