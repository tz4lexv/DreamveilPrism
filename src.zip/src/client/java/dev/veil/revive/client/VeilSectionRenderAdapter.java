package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.BufferBuilder;

import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.block.FluidStateModelSet;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.List;
import java.util.ServiceLoader;
import java.util.function.Function;

public interface VeilSectionRenderAdapter {
    default Object geometryKey(
            RenderSectionRegion region,
            BlockPos position,
            BlockState state,
            BlockStateModel model,
            net.minecraft.util.RandomSource random) {
        return null;
    }

    default int lightingPath(RenderSectionRegion region, BlockPos position, BlockState state) {
        return state.getLightEmission();
    }

    default int visibleFaces(RenderSectionRegion region, BlockPos position, BlockState state) {
        int mask = 0;
        for (var direction : net.minecraft.core.Direction.values())
            if (net.minecraft.world.level.block.Block.shouldRenderFace(
                    state, region.getBlockState(position.relative(direction)), direction))
                mask |= 1 << direction.ordinal();
        return mask;
    }

    Session open(
            boolean ambientOcclusion,
            boolean cutoutLeaves,
            BlockColors colors,
            FluidStateModelSet fluids,
            Function<ChunkSectionLayer, BufferBuilder> builders,
            List<?> additionalRenderers);

    interface Session extends AutoCloseable {
        void model(
                RenderSectionRegion region,
                BlockPos position,
                BlockState state,
                BlockStateModel model,
                int x,
                int y,
                int z);

        void fluid(
                RenderSectionRegion region, BlockPos position, BlockState state, FluidState fluid);

        default boolean replay(RenderSectionRegion region, VeilOriginalQuadCapture.Quad quad) {
            return false;
        }

        default boolean replayBlock(
                RenderSectionRegion region,
                List<VeilOriginalQuadCapture.Quad> quads,
                int from,
                int to) {
            java.util.Objects.checkFromToIndex(from, to, quads.size());
            return from == to || to == from + 1 && replay(region, quads.get(from));
        }

        default void finish(RenderSectionRegion region) {}

        @Override
        default void close() {}
    }

    static VeilSectionRenderAdapter get() {
        return Holder.INSTANCE;
    }

    final class Holder {
        private static final VeilSectionRenderAdapter INSTANCE = load();

        private static VeilSectionRenderAdapter load() {
            var adapters =
                    ServiceLoader.load(
                                    VeilSectionRenderAdapter.class,
                                    VeilSectionRenderAdapter.class.getClassLoader())
                            .iterator();
            if (!adapters.hasNext())
                throw new IllegalStateException("Missing section renderer adapter");
            var adapter = adapters.next();
            if (adapters.hasNext())
                throw new IllegalStateException("Multiple section renderer adapters");
            return adapter;
        }
    }
}
