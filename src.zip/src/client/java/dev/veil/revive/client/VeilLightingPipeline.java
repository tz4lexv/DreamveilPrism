package dev.veil.revive.client;

import dev.veil.revive.core.FrameRateBudgetScaler;
import dev.veil.revive.core.SectionRevisionTracker;
import dev.veil.revive.core.TimeBudgetedTaskDrain;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;

import java.util.Deque;

public final class VeilLightingPipeline {
    private static final WorldState WORLD = new WorldState();

    private VeilLightingPipeline() {}

    public static boolean enabled() {
        return ReviveRuntime.optimizationsEnabled()
                && VeilVideoConfig.flag("renderer.lightPipeline", true);
    }

    public static boolean schedulerEnabled() {
        return enabled() && VeilVideoConfig.flag("renderer.lightUpdateBudget", true);
    }

    public static boolean lightmapCacheEnabled() {
        return enabled() && VeilVideoConfig.flag("renderer.lightmapCache", true);
    }

    public static void drainQueuedLightUpdates(Deque<Runnable> queue) {
        WORLD.drainQueuedLightUpdates(queue);
    }

    public static void beginLightSectionUpdate(long sectionNode) {
        WORLD.beginLightSectionUpdate(sectionNode);
    }

    public static void endLightSectionUpdate() {
        WORLD.endLightSectionUpdate();
    }

    public static boolean inLightSectionUpdate() {
        return WORLD.inLightSectionUpdate();
    }

    public static long lightSectionRevision(long sectionNode) {
        return WORLD.lightRevisions.revision(sectionNode);
    }

    public static long lightGlobalRevision() {
        return WORLD.lightRevisions.globalRevision();
    }

    public static void recordSectionDirty() {
        WORLD.recordSectionDirty();
    }

    public static void recordLightmapRender() {
        WORLD.lightmapRenders++;
    }

    public static void recordLightmapSkip() {
        WORLD.lightmapSkips++;
    }

    public static void beginClientFrame() {
        WORLD.lightSectionsThisFrame.clear();
    }

    public static void beginWorldFrame() {
        VeilShadowReceiverCache.beginFrame();
    }

    public static void clearWorldState() {
        WORLD.clear();
        VeilShadowReceiverCache.clear();
    }

    public static String telemetry() {
        return WORLD.telemetry();
    }

    private static final class WorldState {
        private final ThreadLocal<Integer> lightSectionUpdateDepth =
                ThreadLocal.withInitial(() -> 0);
        private final LongOpenHashSet lightSectionsThisFrame = new LongOpenHashSet();
        private final SectionRevisionTracker lightRevisions = new SectionRevisionTracker();
        private final FrameRateBudgetScaler frameRateScaler = new FrameRateBudgetScaler();

        private long schedulerFrames;
        private long queuedTasksSeen;
        private long tasksExecuted;
        private long tasksDeferred;
        private long burstFrames;
        private long queueCpuNanos;
        private long lightSectionUpdates;
        private long lightSectionUniqueUpdates;
        private long lightDrivenDirtyEvents;
        private long lightRevisionBumps;
        private long lightmapRenders;
        private long lightmapSkips;
        private int maxBacklog;
        private int lastBacklog;
        private int lastExecuted;
        private double lastFrameRateScale = 1.0;

        void drainQueuedLightUpdates(Deque<Runnable> queue) {
            final long nowNanos = System.nanoTime();
            final long targetFrameNanos =
                    Math.max(1L, (long) (ReviveRuntime.targetFrameMs() * 1_000_000.0));
            final double frameRateScale = frameRateScaler.nextScale(nowNanos, targetFrameNanos);
            lastFrameRateScale = frameRateScale;
            final int size = queue.size();
            schedulerFrames++;
            queuedTasksSeen += size;
            lastBacklog = size;
            maxBacklog = Math.max(maxBacklog, size);

            if (size == 0) {
                lastExecuted = 0;
                return;
            }

            final boolean burst = size >= 1_000;
            final int countCap;
            final long timeBudgetNs;
            if (!burst) {

                countCap = Math.min(size, Math.max(10, size / 10));
                timeBudgetNs =
                        Math.clamp(ReviveRuntime.maintenanceBudgetNanos() / 2L, 50_000L, 500_000L);
            } else {
                burstFrames++;
                double pressure = ReviveRuntime.framePressure();
                boolean shaderHeavy = VeilShaderPackBridge.efficiencyModeActive();
                if (shaderHeavy) VeilShaderPackBridge.recordConservativeBudgetFrame();

                int backlogCap = Math.clamp(size / 16, 128, 1_024);
                if (pressure >= 1.35) backlogCap = Math.min(backlogCap, 128);
                else if (pressure >= 1.15) backlogCap = Math.min(backlogCap, 192);
                else if (pressure >= 0.95) backlogCap = Math.min(backlogCap, 256);
                else if (pressure >= 0.80) backlogCap = Math.min(backlogCap, 512);
                if (shaderHeavy) backlogCap = Math.max(96, (backlogCap * 3) / 4);

                backlogCap = Math.clamp((int) Math.round(backlogCap * frameRateScale), 32, 1_024);
                countCap = Math.min(size, backlogCap);

                double budgetMs;
                if (pressure >= 1.35) budgetMs = 0.20;
                else if (pressure >= 1.15) budgetMs = 0.35;
                else if (pressure >= 0.95) budgetMs = 0.55;
                else if (pressure >= 0.80) budgetMs = 0.85;
                else budgetMs = 1.25;
                if (shaderHeavy) budgetMs *= 0.75;
                timeBudgetNs = Math.max(50_000L, (long) (budgetMs * 1_000_000.0 * frameRateScale));
            }

            long startNs = System.nanoTime();
            int executed = TimeBudgetedTaskDrain.drain(queue, countCap, timeBudgetNs);

            long elapsedNs = System.nanoTime() - startNs;
            queueCpuNanos += elapsedNs;
            lastExecuted = executed;
            tasksExecuted += executed;
            int deferred = Math.max(0, size - executed);
            tasksDeferred += deferred;
            VeilFullFrameTelemetry.addLoad(
                    VeilFullFrameTelemetry.LoadCounter.LIGHT_TASKS, executed);
            VeilFullFrameTelemetry.addLoad(
                    VeilFullFrameTelemetry.LoadCounter.LIGHT_TASKS_DEFERRED, deferred);
        }

        void beginLightSectionUpdate(long sectionNode) {
            lightSectionUpdates++;
            if (lightSectionsThisFrame.add(sectionNode)) lightSectionUniqueUpdates++;

            lightRevisions.markDirty(sectionNode);
            lightRevisionBumps++;
            lightSectionUpdateDepth.set(lightSectionUpdateDepth.get() + 1);
        }

        void endLightSectionUpdate() {
            int depth = lightSectionUpdateDepth.get() - 1;
            if (depth <= 0) lightSectionUpdateDepth.remove();
            else lightSectionUpdateDepth.set(depth);
        }

        boolean inLightSectionUpdate() {
            return lightSectionUpdateDepth.get() > 0;
        }

        void recordSectionDirty() {
            if (inLightSectionUpdate()) lightDrivenDirtyEvents++;
        }

        void clear() {
            lightSectionsThisFrame.clear();
            lightRevisions.invalidateAll();
            lightSectionUpdateDepth.remove();
            frameRateScaler.reset();
            lastFrameRateScale = 1.0;
        }

        String telemetry() {
            return "lighting_pipeline_enabled="
                    + enabled()
                    + "\nlight_scheduler_frames_total="
                    + schedulerFrames
                    + "\nlight_queue_tasks_seen_total="
                    + queuedTasksSeen
                    + "\nlight_queue_tasks_executed_total="
                    + tasksExecuted
                    + "\nlight_queue_tasks_deferred_total="
                    + tasksDeferred
                    + "\nlight_queue_burst_frames_total="
                    + burstFrames
                    + "\nlight_queue_cpu_ms_total="
                    + String.format(java.util.Locale.ROOT, "%.4f", queueCpuNanos / 1_000_000.0)
                    + "\nlight_queue_backlog_last="
                    + lastBacklog
                    + "\nlight_queue_backlog_max="
                    + maxBacklog
                    + "\nlight_queue_executed_last="
                    + lastExecuted
                    + "\nlight_queue_frame_rate_scale="
                    + String.format(java.util.Locale.ROOT, "%.4f", lastFrameRateScale)
                    + "\nlight_section_updates_total="
                    + lightSectionUpdates
                    + "\nlight_section_unique_updates_total="
                    + lightSectionUniqueUpdates
                    + "\nlight_driven_section_dirty_total="
                    + lightDrivenDirtyEvents
                    + "\nlight_revision_bumps_total="
                    + lightRevisionBumps
                    + "\nlightmap_renders_total="
                    + lightmapRenders
                    + "\nlightmap_redundant_skips_total="
                    + lightmapSkips
                    + "\n"
                    + VeilLightCoordsCache.telemetry()
                    + VeilShadowReceiverCache.telemetry();
        }
    }
}
