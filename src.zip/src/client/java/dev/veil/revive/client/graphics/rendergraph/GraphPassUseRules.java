package dev.veil.revive.client.graphics.rendergraph;

import dev.veil.revive.client.VeilRenderGraph.Kind;
import dev.veil.revive.client.VeilRenderGraph.Use;

import java.util.List;

/** Checks combinations of accesses that cannot be represented by a single Vulkan image layout. */
public final class GraphPassUseRules {
    private GraphPassUseRules() {}

    public static void validate(String pass, List<Use> uses) {
        for (int left = 0; left < uses.size(); left++) {
            Use first = uses.get(left);
            if (first.access().kind() != Kind.IMAGE) continue;
            for (int right = left + 1; right < uses.size(); right++) {
                Use second = uses.get(right);
                if (!first.resource().equals(second.resource())
                        || !first.subresource().overlaps(second.subresource())) continue;
                if (first.access().layout() != second.access().layout()) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass
                                    + ": conflicting image layouts for "
                                    + first.resource()
                                    + " on overlapping subresources: "
                                    + first.access()
                                    + " ("
                                    + first.subresource()
                                    + ") and "
                                    + second.access()
                                    + " ("
                                    + second.subresource()
                                    + "). "
                                    + "Use non-overlapping mip/layer ranges or compatible layouts.");
                }
            }
        }
    }
}
