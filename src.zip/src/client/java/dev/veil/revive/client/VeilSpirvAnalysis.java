package dev.veil.revive.client;

import static org.lwjgl.util.spvc.Spv.*;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

record VeilSpirvAnalysis(
        int instructions,
        int imageOperations,
        int branches,
        int loops,
        int atomics,
        int extendedInstructions,
        List<Integer> capabilities,
        long sharedBytes) {
    static VeilSpirvAnalysis inspect(VeilSpirvBinary binary) {
        var words =
                ByteBuffer.wrap(binary.unsafeCode()).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer();
        int instructions = 0, images = 0, branches = 0, loops = 0, atomics = 0, extended = 0;
        var capabilities = new ArrayList<Integer>();
        var types = new HashMap<Integer, int[]>();
        var constants = new HashMap<Integer, Long>();
        var shared = new ArrayList<Integer>();
        for (int offset = 5; offset < words.limit(); ) {
            int count = words.get(offset) >>> 16, op = words.get(offset) & 65535;
            instructions++;
            if (op >= SpvOpImageSampleImplicitLod && op <= SpvOpImageWrite) images++;
            if (op == SpvOpBranchConditional || op == SpvOpSwitch) branches++;
            if (op == SpvOpLoopMerge) loops++;
            if (op >= SpvOpAtomicLoad && op <= SpvOpAtomicXor) atomics++;
            if (op == SpvOpExtInst) extended++;
            if (op == SpvOpCapability) capabilities.add(words.get(offset + 1));
            if (op >= SpvOpTypeBool && op <= SpvOpTypePointer && count >= 2) {
                int[] type = new int[count];
                for (int i = 0; i < count; i++) type[i] = words.get(offset + i);
                types.put(type[1], type);
            }
            if (op == SpvOpConstant && count == 4)
                constants.put(words.get(offset + 2), Integer.toUnsignedLong(words.get(offset + 3)));
            if (op == SpvOpVariable
                    && count >= 4
                    && words.get(offset + 3) == SpvStorageClassWorkgroup)
                shared.add(words.get(offset + 1));
            offset += count;
        }
        long sharedBytes = 0;
        try {
            for (int pointer : shared) {
                int[] type = types.get(pointer);
                Layout layout = layout(type[3], types, constants, 0);
                sharedBytes =
                        Math.addExact(
                                align(sharedBytes, layout.alignment()),
                                align(layout.bytes(), layout.alignment()));
            }
        } catch (IllegalArgumentException | ArithmeticException failure) {
            sharedBytes = -1;
        }
        return new VeilSpirvAnalysis(
                instructions,
                images,
                branches,
                loops,
                atomics,
                extended,
                List.copyOf(capabilities),
                sharedBytes);
    }

    private record Layout(long bytes, long alignment) {}

    private static Layout layout(
            int id, Map<Integer, int[]> types, Map<Integer, Long> constants, int depth) {
        if (depth > 64 || !types.containsKey(id))
            throw new IllegalArgumentException("Unknown shared type");
        int[] type = types.get(id);
        int op = type[0] & 65535;
        if (op == SpvOpTypeBool) return new Layout(4, 4);
        if (op == SpvOpTypeInt || op == SpvOpTypeFloat) return new Layout(type[2] / 8, type[2] / 8);
        if (op == SpvOpTypeVector) {
            Layout scalar = layout(type[2], types, constants, depth + 1);
            return new Layout(
                    Math.multiplyExact(scalar.bytes(), type[3]),
                    Math.multiplyExact(scalar.alignment(), type[3] == 3 ? 4 : type[3]));
        }
        if (op == SpvOpTypeArray || op == SpvOpTypeMatrix) {
            Layout element = layout(type[2], types, constants, depth + 1);
            long count = op == SpvOpTypeMatrix ? type[3] : constants.getOrDefault(type[3], -1L);
            if (count < 0)
                throw new IllegalArgumentException("Specialized shared memory size unavailable");
            return new Layout(
                    Math.multiplyExact(align(element.bytes(), element.alignment()), count),
                    element.alignment());
        }
        if (op == SpvOpTypeStruct) {
            long bytes = 0, alignment = 1;
            for (int member = 2; member < type.length; member++) {
                Layout value = layout(type[member], types, constants, depth + 1);
                bytes = Math.addExact(align(bytes, value.alignment()), value.bytes());
                alignment = Math.max(alignment, value.alignment());
            }
            return new Layout(align(bytes, alignment), alignment);
        }
        throw new IllegalArgumentException("Unsupported shared memory type");
    }

    private static long align(long bytes, long alignment) {
        if (alignment <= 0) throw new IllegalArgumentException("Invalid shared alignment");
        return Math.multiplyExact(Math.addExact(bytes, alignment - 1) / alignment, alignment);
    }

    String report() {
        return "SPIR-V static: instructions="
                + instructions
                + " image_ops="
                + imageOperations
                + " branches="
                + branches
                + " loops="
                + loops
                + " atomics="
                + atomics
                + " ext_instructions="
                + extendedInstructions
                + " capabilities="
                + capabilities
                + " shared_bytes_conservative="
                + (sharedBytes < 0 ? "UNAVAILABLE" : sharedBytes)
                + "; static module counts, not ISA cost or dynamic invocation counts";
    }
}
