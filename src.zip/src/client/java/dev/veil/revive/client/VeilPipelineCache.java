package dev.veil.revive.client;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

public final class VeilPipelineCache<K, V extends VeilShaderReload.Generation>
        implements AutoCloseable {
    private final class Entry {
        final V value;
        int references;

        Entry(V value) {
            this.value = value;
        }
    }

    public final class Lease implements AutoCloseable {
        private Entry entry;

        private Lease(Entry entry) {
            this.entry = entry;
            entry.references++;
        }

        public V value() {
            checkThread();
            if (entry == null || closed)
                throw new IllegalStateException("Pipeline lease is closed");
            return entry.value;
        }

        @Override
        public void close() {
            checkThread();
            if (entry == null) return;
            entry.references--;
            entry = null;
            trimToCapacity();
        }
    }

    private final Thread owner = Thread.currentThread();
    private final Map<K, Entry> entries = new LinkedHashMap<>(16, 0.75f, true);
    private final int capacity;
    private final VeilShaderMetrics metrics;
    private boolean closed;

    public VeilPipelineCache(int capacity, VeilShaderMetrics metrics) {
        if (capacity < 1) throw new IllegalArgumentException("capacity < 1");
        this.capacity = capacity;
        this.metrics = metrics;
    }

    public Lease acquire(K key, Supplier<V> create) {
        checkThread();
        if (closed) throw new IllegalStateException("Pipeline cache is closed");
        Entry found = entries.get(key);
        if (found != null) {
            metrics.pipelineHits.increment();
            return new Lease(found);
        }
        metrics.pipelineMisses.increment();
        trimToCapacity(capacity - 1);

        if (entries.size() >= capacity
                && entries.values().stream().allMatch(entry -> entry.references != 0)) {
            metrics.pipelinePinnedOverflows.increment();
        }
        long started = System.nanoTime();
        Entry created;
        try {
            created = new Entry(java.util.Objects.requireNonNull(create.get(), "pipeline"));
        } finally {
            metrics.pipelineCreationNanos.add(System.nanoTime() - started);
        }
        entries.put(key, created);
        metrics.pipelineCreations.increment();
        return new Lease(created);
    }

    private void trimToCapacity() {
        trimToCapacity(capacity);
    }

    private void trimToCapacity(int target) {
        if (entries.size() <= target) return;
        var iterator = entries.entrySet().iterator();
        while (entries.size() > target && iterator.hasNext()) {
            Entry candidate = iterator.next().getValue();
            if (candidate.references != 0) continue;
            iterator.remove();
            candidate.value.close();
            metrics.pipelineEvictions.increment();
        }
    }

    int cachedEntries() {
        checkThread();
        return entries.size();
    }

    private void checkThread() {
        if (Thread.currentThread() != owner)
            throw new IllegalStateException("Pipeline cache accessed outside its owner thread");
    }

    @Override
    public void close() {
        checkThread();
        if (closed) return;
        if (entries.values().stream().anyMatch(entry -> entry.references != 0)) {
            throw new IllegalStateException("Pipeline cache still has live leases");
        }
        closed = true;
        var cleanup = new dev.veil.revive.core.lifecycle.CloseSequence();
        cleanup.each(entries.values(), entry -> entry.value.close());
        entries.clear();
        cleanup.finish();
    }
}
