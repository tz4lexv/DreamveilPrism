package dev.veil.revive.client.terrain.indirect;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPassBackend;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;
import com.mojang.blaze3d.vulkan.VulkanRenderPass;

import dev.veil.revive.mixin.VulkanRenderPassAccessor;

import org.lwjgl.vulkan.VK12;
import org.lwjgl.vulkan.VkDrawIndexedIndirectCommand;

public final class IndexedTerrainCommands {
    private IndexedTerrainCommands() {}

    public static final class Statistics {
        public long calls;
        public long indices;

        public void reset() {
            calls = 0;
            indices = 0;
        }
    }

    public static void direct(
            RenderPassBackend backend, TerrainBatchStorage batch, Statistics statistics) {
        for (int i = 0; i < batch.sectionIndices.length; i++) {
            int visibleCount = batch.directCommands.get(i * 3 + 1);
            if (visibleCount == 0) continue;
            backend.drawIndexed(
                    visibleCount,
                    1,
                    batch.firstIndices[i],
                    batch.baseVertices[i],
                    batch.sectionIndices[i]);
            statistics.calls++;
            statistics.indices += batch.indexCounts[i];
        }
    }

    public static void indirectCount(
            RenderPassBackend backend,
            GpuBufferSlice commands,
            GpuBufferSlice count,
            int maximumDraws) {
        if (!(backend instanceof VulkanRenderPass vulkan))
            throw new IllegalStateException("Indirect-count draw requires Vulkan");
        var access = (VulkanRenderPassAccessor) (Object) vulkan;
        access.veil$pushDescriptors();
        VK12.vkCmdDrawIndexedIndirectCount(
                access.veil$commandBuffer(),
                ((VulkanGpuBuffer) commands.buffer()).vkBuffer(),
                commands.offset(),
                ((VulkanGpuBuffer) count.buffer()).vkBuffer(),
                count.offset(),
                maximumDraws,
                VkDrawIndexedIndirectCommand.SIZEOF);
    }
}
