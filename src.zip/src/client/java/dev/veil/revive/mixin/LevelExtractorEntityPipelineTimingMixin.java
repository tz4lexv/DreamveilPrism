package dev.veil.revive.mixin;

import com.sun.management.ThreadMXBean;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilEntityPipelineCounters;
import dev.veil.revive.client.VeilSectionVisibilityIndex;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.extract.LevelExtractor;
import net.minecraft.client.renderer.state.level.LevelRenderState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.management.ManagementFactory;

@Mixin(LevelExtractor.class)
public abstract class LevelExtractorEntityPipelineTimingMixin {
    @Unique private static final ThreadMXBean VEIL_ALLOCATIONS = veil$allocator();
    @Unique private long veil$entityExtractStartNs;
    @Unique private long veil$entityExtractStartBytes;

    @Inject(method = "extractVisibleEntities", at = @At("HEAD"), require = 1)
    private void veil$beginEntityExtraction(
            Camera camera,
            Frustum frustum,
            DeltaTracker deltaTracker,
            LevelRenderState output,
            CallbackInfo ci) {
        dev.veil.revive.client.VeilAsyncEntityOcclusion.beginExtraction();
        VeilSectionVisibilityIndex.beginEntityExtraction(frustum);
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.ENTITY_VISIBLE_LOOP);
        if (!VeilDiagnostics.benchmarkActive()) {
            veil$entityExtractStartNs = 0L;
            veil$entityExtractStartBytes = -1L;
            return;
        }
        veil$entityExtractStartNs = System.nanoTime();
        veil$entityExtractStartBytes = veil$threadAllocatedBytes();
    }

    @Inject(method = "extractVisibleEntities", at = @At("RETURN"), require = 1)
    private void veil$endEntityExtraction(
            Camera camera,
            Frustum frustum,
            DeltaTracker deltaTracker,
            LevelRenderState output,
            CallbackInfo ci) {
        VeilSectionVisibilityIndex.endEntityExtraction();
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.ENTITY_VISIBLE_LOOP);
        if (veil$entityExtractStartNs == 0L) return;
        long elapsed = System.nanoTime() - veil$entityExtractStartNs;
        long after = veil$threadAllocatedBytes();
        long allocated =
                veil$entityExtractStartBytes >= 0L && after >= veil$entityExtractStartBytes
                        ? after - veil$entityExtractStartBytes
                        : 0L;
        VeilEntityPipelineCounters.extractVisible(elapsed, allocated);
    }

    @Unique
    private static ThreadMXBean veil$allocator() {
        var bean = ManagementFactory.getThreadMXBean();
        if (!(bean instanceof ThreadMXBean allocated)
                || !allocated.isThreadAllocatedMemorySupported()) return null;
        try {
            if (!allocated.isThreadAllocatedMemoryEnabled())
                allocated.setThreadAllocatedMemoryEnabled(true);
            return allocated.isThreadAllocatedMemoryEnabled() ? allocated : null;
        } catch (SecurityException ignored) {
            return null;
        }
    }

    @Unique
    private static long veil$threadAllocatedBytes() {
        ThreadMXBean bean = VEIL_ALLOCATIONS;
        return bean == null ? -1L : bean.getThreadAllocatedBytes(Thread.currentThread().threadId());
    }
}
