package dev.veil.revive.mixin;

import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.block.BlockStateModelSet;
import net.minecraft.client.renderer.block.FluidStateModelSet;
import net.minecraft.client.renderer.chunk.SectionCompiler;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SectionCompiler.class)
public interface SectionCompilerStateAccessor {
    @Accessor("ambientOcclusion")
    boolean veil$ambientOcclusion();

    @Accessor("cutoutLeaves")
    boolean veil$cutoutLeaves();

    @Accessor("blockModelSet")
    BlockStateModelSet veil$blockModels();

    @Accessor("fluidModelSet")
    FluidStateModelSet veil$fluidModels();

    @Accessor("blockColors")
    BlockColors veil$blockColors();
}
