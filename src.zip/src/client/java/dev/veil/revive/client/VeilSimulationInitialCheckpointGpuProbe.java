package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.api.VeilSimulationCheckpoint;
import dev.veil.api.VeilSimulationCheckpointStore;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/** Loads the prior process's actual GPU checkpoint, then verifies its first raster consumer. */
final class VeilSimulationInitialCheckpointGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.simulationInitialCheckpointGpuProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static VeilSimulationCheckpointStore store;
    private static CompletableFuture<Optional<VeilSimulationCheckpoint>> loaded;
    private static CompletableFuture<Void> restored;
    private static VeilShaderPackRuntime generation;
    private static boolean requested, completed;
    private static long started;

    static boolean before(VeilShaderPackRuntime active) {
        if (!ENABLED || completed) return true;
        if (started == 0) started = System.nanoTime();
        if (System.nanoTime() - started > 90_000_000_000L)
            throw new IllegalStateException("Initial checkpoint timeout");
        if (generation == null) {
            if (!System.getProperty("veil.shaderPack", "")
                    .equals("veil-simulation-initial-checkpoint-v1"))
                throw new IllegalStateException("Initial checkpoint probe requires its fixture");
            generation = active;
            store =
                    new VeilSimulationCheckpointStore(
                            Path.of(System.getProperty("veil.simulationCheckpointInput")), 1024);
            loaded =
                    store.load(
                            new VeilSimulationCheckpointStore.Scope(
                                    "probe-world",
                                    "minecraft:overworld",
                                    "subresource-fixture",
                                    "fields",
                                    1));
        }
        if (generation != active)
            throw new IllegalStateException("Initial checkpoint changed generation");
        if (restored != null) return true;
        if (!loaded.isDone()) return false;
        if (active.renderedFrames() != 0)
            throw new IllegalStateException("Consumer ran before checkpoint was loaded");
        var checkpoint = loaded.join().orElseThrow();
        var invalid = new HashMap<>(checkpoint.fields());
        var original = invalid.get("creator-array");
        invalid.put(
                "creator-array",
                new VeilSimulationCheckpoint.Field(
                        original.selection(), dev.veil.api.VeilFormat.RGBA8_UINT, original.data()));
        boolean rejected = false;
        try {
            active.queueInitialSimulationCheckpoint(
                    new VeilSimulationCheckpoint(
                            checkpoint.generation(), checkpoint.frame(), invalid));
        } catch (IllegalArgumentException expected) {
            rejected = true;
        }
        if (!rejected) throw new IllegalStateException("Initial format mismatch was accepted");
        restored = VeilShaderService.queueInitialSimulationCheckpoint(checkpoint);
        try {
            active.queueInitialSimulationCheckpoint(checkpoint);
            throw new IllegalStateException("Duplicate initial restore accepted");
        } catch (IllegalStateException expected) {
            if (expected.getMessage().equals("Duplicate initial restore accepted")) throw expected;
        }
        store.close();
        return true;
    }

    static void after(VeilShaderPackRuntime active) {
        if (!ENABLED || completed || requested) return;
        if (active.renderedFrames() != 1)
            throw new IllegalStateException("Initial consumer check missed first frame");
        requested = true;
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil initial checkpoint consumer",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                64);
        active.readOutput(
                "output",
                readback,
                () -> {
                    try {
                        if (!restored.isDone())
                            throw new IllegalStateException(
                                    "Initial restore completion was not retired before consumer readback");
                        restored.join();
                        try (var mapped = readback.map(true, false)) {
                            for (int i = 0; i < 64; i++)
                                if (Byte.toUnsignedInt(mapped.data().get(i)) != 130)
                                    throw new IllegalStateException(
                                            "First consumer did not observe restored array/volume, byte="
                                                    + i);
                        }
                        completed = true;
                        ReviveMod.LOGGER.info(
                                "Veil simulation initial checkpoint GPU: PASS (prior-process checkpoint, first consumer exact RGBA 130, format/duplicate rejection)");
                        Minecraft.getInstance().stop();
                    } catch (RuntimeException failure) {
                        completed = true;
                        ReviveMod.LOGGER.error(
                                "Veil simulation initial checkpoint GPU: FAIL", failure);
                        Minecraft.getInstance().stop();
                    } finally {
                        readback.close();
                    }
                });
    }
}
