package dev.veil.revive.client;

import dev.veil.revive.core.ReviveStats;
import dev.veil.revive.core.TerrainBridgeCounters;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryUsage;

final class VeilBenchmarkEvidence {
    private VeilBenchmarkEvidence() {}

    static Point capture() {
        return new Point(
                VeilTechniqueCounters.snapshot(),
                VeilTerrainDrawBridge.counters(),
                VeilFaceVisibilityCache.snapshot(),
                VeilTerrainDrawBridge.sharedWork(),
                VeilFallbackTracker.snapshot(),
                VeilEntityPipelineCounters.snapshot(),
                VeilServerAiCounters.snapshot(),
                ReviveRuntime.stats(),
                VeilFullFrameTelemetry.snapshot(),
                JvmPoint.capture());
    }

    record Point(
            VeilTechniqueCounters.Snapshot techniques,
            TerrainBridgeCounters.Snapshot terrainBridge,
            VeilFaceVisibilityCache.Snapshot faceVisibility,
            VeilSharedSectionUniforms.Snapshot sharedWork,
            VeilFallbackTracker.Snapshot fallbacks,
            VeilEntityPipelineCounters.Snapshot entities,
            VeilServerAiCounters.Snapshot serverAi,
            ReviveStats.Snapshot runtimeStats,
            VeilFullFrameTelemetry.Snapshot fullFrame,
            JvmPoint jvm) {

        Delta deltaTo(Point after) {
            return new Delta(
                    after.techniques.minus(techniques),
                    after.terrainBridge.minus(terrainBridge),
                    after.faceVisibility.minus(faceVisibility),
                    after.sharedWork.minus(sharedWork),
                    after.fallbacks.minus(fallbacks),
                    after.entities.minus(entities),
                    after.serverAi.minus(serverAi),
                    after.runtimeStats.minus(runtimeStats),
                    after.fullFrame.minus(fullFrame),
                    after.jvm.gcCollections - jvm.gcCollections,
                    after.jvm.gcTimeMs - jvm.gcTimeMs,
                    jvm.heapUsedBytes,
                    after.jvm.heapUsedBytes,
                    after.jvm.heapUsedBytes - jvm.heapUsedBytes,
                    after.jvm.heapCommittedBytes,
                    after.jvm.nonHeapUsedBytes,
                    after.jvm.liveThreads);
        }
    }

    record Delta(
            VeilTechniqueCounters.Snapshot techniques,
            TerrainBridgeCounters.Snapshot terrainBridge,
            VeilFaceVisibilityCache.Snapshot faceVisibility,
            VeilSharedSectionUniforms.Snapshot sharedWork,
            VeilFallbackTracker.Snapshot fallbacks,
            VeilEntityPipelineCounters.Snapshot entities,
            VeilServerAiCounters.Snapshot serverAi,
            ReviveStats.Snapshot runtimeStats,
            VeilFullFrameTelemetry.Snapshot fullFrame,
            long gcCollections,
            long gcTimeMs,
            long heapUsedStartBytes,
            long heapUsedEndBytes,
            long heapMeasuredDeltaBytes,
            long heapCommittedEndBytes,
            long nonHeapUsedEndBytes,
            int liveThreadsEnd) {

        Delta plus(Delta other) {
            return new Delta(
                    techniques.plus(other.techniques),
                    terrainBridge.plus(other.terrainBridge),
                    faceVisibility.plus(other.faceVisibility),
                    sharedWork.plus(other.sharedWork),
                    fallbacks.plus(other.fallbacks),
                    entities.plus(other.entities),
                    serverAi.plus(other.serverAi),
                    runtimeStats.plus(other.runtimeStats),
                    fullFrame.plus(other.fullFrame),
                    gcCollections + other.gcCollections,
                    gcTimeMs + other.gcTimeMs,
                    heapUsedStartBytes,
                    other.heapUsedEndBytes,
                    heapMeasuredDeltaBytes + other.heapMeasuredDeltaBytes,
                    other.heapCommittedEndBytes,
                    other.nonHeapUsedEndBytes,
                    other.liveThreadsEnd);
        }

        long heapDeltaBytes() {
            return heapMeasuredDeltaBytes;
        }
    }

    record JvmPoint(
            long gcCollections,
            long gcTimeMs,
            long heapUsedBytes,
            long heapCommittedBytes,
            long nonHeapUsedBytes,
            int liveThreads) {

        static JvmPoint capture() {
            long collections = 0L;
            long collectionTimeMs = 0L;
            for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
                long c = gc.getCollectionCount();
                long t = gc.getCollectionTime();
                if (c > 0L) collections += c;
                if (t > 0L) collectionTimeMs += t;
            }

            MemoryUsage heap = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
            MemoryUsage nonHeap = ManagementFactory.getMemoryMXBean().getNonHeapMemoryUsage();
            return new JvmPoint(
                    collections,
                    collectionTimeMs,
                    heap.getUsed(),
                    heap.getCommitted(),
                    nonHeap.getUsed(),
                    ManagementFactory.getThreadMXBean().getThreadCount());
        }
    }
}
