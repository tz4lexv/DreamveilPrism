package dev.veil.api;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;

public record VeilVertexLayout(List<Binding> bindings, List<Attribute> attributes) {
    public static final VeilVertexLayout EMPTY = new VeilVertexLayout(List.of(), List.of());

    public enum InputRate {
        VERTEX,
        INSTANCE
    }

    public record Binding(int binding, int stride, InputRate inputRate) {
        public Binding {
            if (binding < 0)
                throw new IllegalArgumentException("Vertex binding index must be non-negative");
            if (stride < 1)
                throw new IllegalArgumentException(
                        "Vertex binding stride must be positive: " + binding);
            Objects.requireNonNull(inputRate, "inputRate");
        }
    }

    public record Attribute(int location, int binding, VeilFormat format, int offset) {
        public Attribute {
            if (location < 0 || binding < 0 || offset < 0)
                throw new IllegalArgumentException("Vertex attribute fields must be non-negative");
            Objects.requireNonNull(format, "format");
            if (!format.vertexCandidate())
                throw new IllegalArgumentException(
                        "Format is not a supported vertex format: " + format);
            int alignment = format.bytesPerTexel() / format.channels();
            if (offset % alignment != 0)
                throw new IllegalArgumentException(
                        "Vertex attribute offset is not component-aligned: " + location);
        }
    }

    public VeilVertexLayout {
        bindings =
                bindings.stream()
                        .sorted(java.util.Comparator.comparingInt(Binding::binding))
                        .toList();
        attributes =
                attributes.stream()
                        .sorted(java.util.Comparator.comparingInt(Attribute::location))
                        .toList();
        var bindingIds = new HashSet<Integer>();
        for (Binding binding : bindings) {
            if (!bindingIds.add(binding.binding()))
                throw new IllegalArgumentException(
                        "Duplicate vertex binding: " + binding.binding());
        }
        var locations = new HashSet<Integer>();
        for (Attribute attribute : attributes) {
            if (!locations.add(attribute.location()))
                throw new IllegalArgumentException(
                        "Duplicate vertex location: " + attribute.location());
            if (!bindingIds.contains(attribute.binding()))
                throw new IllegalArgumentException(
                        "Vertex attribute references missing binding: " + attribute.binding());
            Binding binding =
                    bindings.stream()
                            .filter(value -> value.binding() == attribute.binding())
                            .findFirst()
                            .orElseThrow();
            if ((long) attribute.offset() + attribute.format().bytesPerTexel() > binding.stride()) {
                throw new IllegalArgumentException(
                        "Vertex attribute location="
                                + attribute.location()
                                + " exceeds binding stride="
                                + binding.stride());
            }
        }
    }
}
