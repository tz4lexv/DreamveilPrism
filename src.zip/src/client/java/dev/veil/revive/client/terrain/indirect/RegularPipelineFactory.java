package dev.veil.revive.client.terrain.indirect;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.vertex.VertexFormat;

import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.resources.Identifier;

import java.util.EnumMap;
import java.util.Optional;

public final class RegularPipelineFactory {
    private RegularPipelineFactory() {}

    public record Tables(
            EnumMap<ChunkSectionLayer, RenderPipeline[][]> pipelines, RenderPipeline[] depth) {}

    public static VertexFormat format(int stride) {
        return formatForSlot(stride == 16 ? 0 : 1);
    }

    public static VertexFormat formatForSlot(int slot) {
        return VertexFormat.builder(0)
                .addAttribute("VeilPosition", slot == 2 ? GpuFormat.RG32_UINT : GpuFormat.R32_UINT)
                .addAttribute("Color", GpuFormat.RGBA8_UNORM)
                .addAttribute("UV0", slot == 1 ? GpuFormat.RG32_FLOAT : GpuFormat.RG16_FLOAT)
                .addAttribute("VeilLight", GpuFormat.R32_UINT)
                .build();
    }

    public static Tables create() {
        var pipelines = new EnumMap<ChunkSectionLayer, RenderPipeline[][]>(ChunkSectionLayer.class);
        var depth = new RenderPipeline[3];
        for (ChunkSectionLayer layer : ChunkSectionLayer.values()) {
            if (layer == ChunkSectionLayer.TRANSLUCENT) continue;
            var variants = new RenderPipeline[3][2];
            for (int slot = 0; slot < 3; slot++)
                for (int direct = 0; direct < 2; direct++) {
                    var builder =
                            builder(slot, direct != 0)
                                    .withLocation(
                                            id(
                                                    "pipeline/regular_packed_"
                                                            + layer.label()
                                                            + "_"
                                                            + slot
                                                            + "_"
                                                            + direct))
                                    .withFragmentShader(id("core/terrain_indirect"))
                                    .withColorTargetState(
                                            layer.pipeline().getColorTargetStates()[0]);
                    if (layer == ChunkSectionLayer.CUTOUT)
                        builder.withShaderDefine("ALPHA_CUTOUT", 0.5f);
                    variants[slot][direct] =
                            direct == 0
                                    ? RenderPipelines.register(builder.build())
                                    : builder.build();
                }
            pipelines.put(layer, variants);
        }
        for (int slot = 0; slot < 3; slot++)
            depth[slot] =
                    RenderPipelines.register(
                            builder(slot, false)
                                    .withLocation(id("pipeline/regular_packed_depth_" + slot))
                                    .withFragmentShader(id("core/depth_only"))
                                    .withColorTargetState(
                                            new ColorTargetState(
                                                    Optional.empty(),
                                                    GpuFormat.RGBA8_UNORM,
                                                    ColorTargetState.WRITE_NONE))
                                    .build());
        return new Tables(pipelines, depth);
    }

    private static RenderPipeline.Builder builder(int slot, boolean direct) {
        var layout =
                BindGroupLayout.builder()
                        .withUniform("VeilFrame", UniformType.UNIFORM_BUFFER)
                        .withUniform(
                                "VeilSections", UniformType.TEXEL_BUFFER, GpuFormat.RGBA32_SINT);
        if (direct)
            layout.withUniform("VeilDrawCommands", UniformType.TEXEL_BUFFER, GpuFormat.R32_SINT);
        return RenderPipeline.builder(RenderPipelines.GENERIC_BLOCKS_SNIPPET)
                .withBindGroupLayout(BindGroupLayouts.PROJECTION)
                .withBindGroupLayout(layout.build())
                .withVertexBinding(0, formatForSlot(slot))
                .withVertexShader(
                        id(
                                "core/terrain_regular_"
                                        + (slot == 2 ? "wide" : "packed")
                                        + (direct ? "_multi" : "")));
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("veil", path);
    }
}
