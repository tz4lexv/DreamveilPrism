package dev.veil.revive.client;

import java.util.Arrays;

public record VeilFluidGeometry(
        int materialId,
        int originX,
        int originY,
        int originZ,
        float[] positions,
        byte[] quadFlags) {

    public static final byte QUAD_TOP = 1;

    public static final byte QUAD_SIDE = 1 << 1;

    public static final byte QUAD_SOURCE = 1 << 2;

    public static final byte QUAD_DEGENERATE = 1 << 3;

    public VeilFluidGeometry {
        positions = positions == null ? new float[0] : positions.clone();
        if ((positions.length % 12) != 0) {
            throw new IllegalArgumentException(
                    "Fluid geometry must contain complete xyz quads: floats=" + positions.length);
        }
        int quads = positions.length / 12;
        quadFlags = quadFlags == null ? conservativeFlags(quads) : quadFlags.clone();
        if (quadFlags.length != quads) {
            throw new IllegalArgumentException(
                    "Fluid geometry flags must match quad count: flags="
                            + quadFlags.length
                            + " quads="
                            + quads);
        }
    }

    public VeilFluidGeometry(
            int materialId, int originX, int originY, int originZ, float[] positions) {
        this(
                materialId,
                originX,
                originY,
                originZ,
                positions,
                conservativeFlags(positions == null ? 0 : positions.length / 12));
    }

    private static byte[] conservativeFlags(int quads) {
        byte[] flags = new byte[Math.max(quads, 0)];
        Arrays.fill(flags, QUAD_DEGENERATE);
        return flags;
    }

    @Override
    public float[] positions() {
        return positions.clone();
    }

    @Override
    public byte[] quadFlags() {
        return quadFlags.clone();
    }

    float[] positionsUnsafe() {
        return positions;
    }

    byte[] quadFlagsUnsafe() {
        return quadFlags;
    }

    public int quadCount() {
        return positions.length / 12;
    }

    public int triangleVertexCount() {
        return quadCount() * 6;
    }

    public VeilFluidGeometry copy() {
        return new VeilFluidGeometry(
                materialId,
                originX,
                originY,
                originZ,
                Arrays.copyOf(positions, positions.length),
                Arrays.copyOf(quadFlags, quadFlags.length));
    }
}
