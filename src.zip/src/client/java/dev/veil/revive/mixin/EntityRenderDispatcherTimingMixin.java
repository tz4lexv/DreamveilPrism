package dev.veil.revive.mixin;

import com.mojang.blaze3d.vertex.PoseStack;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilEntityPipelineCounters;

import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.Entity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherTimingMixin {
    @Unique private long veil$extractStartNs;
    @Unique private long veil$submitStartNs;

    @Inject(method = "extractEntity", at = @At("HEAD"), require = 1)
    private <E extends Entity> void veil$beginExtract(
            E entity, float partialTicks, CallbackInfoReturnable<EntityRenderState> cir) {
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.ENTITY_EXTRACT);
        veil$extractStartNs = VeilDiagnostics.benchmarkActive() ? System.nanoTime() : 0L;
    }

    @Inject(method = "extractEntity", at = @At("RETURN"), require = 1)
    private <E extends Entity> void veil$endExtract(
            E entity, float partialTicks, CallbackInfoReturnable<EntityRenderState> cir) {
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.ENTITY_EXTRACT);
        dev.veil.revive.client.VeilFullFrameTelemetry.addLoad(
                dev.veil.revive.client.VeilFullFrameTelemetry.LoadCounter.ENTITY_STATES, 1L);
        if (veil$extractStartNs != 0L)
            VeilEntityPipelineCounters.dispatchExtract(System.nanoTime() - veil$extractStartNs);
        dev.veil.revive.client.VeilEntityMeshCapture.associate(cir.getReturnValue(), entity);
    }

    @Inject(method = "submit", at = @At("HEAD"), require = 1)
    private void veil$beginSubmit(
            EntityRenderState renderState,
            CameraRenderState camera,
            double x,
            double y,
            double z,
            PoseStack poseStack,
            SubmitNodeCollector submitNodeCollector,
            CallbackInfo ci) {
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.ENTITY_SUBMIT);
        veil$submitStartNs = VeilDiagnostics.benchmarkActive() ? System.nanoTime() : 0L;
    }

    @Inject(method = "submit", at = @At("RETURN"), require = 1)
    private void veil$endSubmit(
            EntityRenderState renderState,
            CameraRenderState camera,
            double x,
            double y,
            double z,
            PoseStack poseStack,
            SubmitNodeCollector submitNodeCollector,
            CallbackInfo ci) {
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.ENTITY_SUBMIT);
        if (veil$submitStartNs != 0L)
            VeilEntityPipelineCounters.dispatchSubmit(System.nanoTime() - veil$submitStartNs);
    }
}
