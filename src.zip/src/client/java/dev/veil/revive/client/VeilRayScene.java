package dev.veil.revive.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public final class VeilRayScene {
    public static final int MAGIC = 0x56525431;
    public static final int MAX_TRIANGLES = (VeilShaderLimits.MAX_BUFFER_BYTES - 192) / 192;
    private static final int LEAF_TRIANGLES = 4;
    private static final int SAH_BINS = 16;

    private record Triangle(float[] a, float[] b, float[] c, int material, int sourceIndex) {
        float center(int axis) {
            return (a[axis] + b[axis] + c[axis]) / 3;
        }
    }

    private static final class Node {
        final float[] min = {
            Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY
        };
        final float[] max = {
            Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY
        };
        int first, count, escape;
    }

    private static final class SahWorkspace {
        final float[] binMin = new float[SAH_BINS * 3];
        final float[] binMax = new float[SAH_BINS * 3];
        final int[] binCount = new int[SAH_BINS];
        final float[] prefixMin = new float[(SAH_BINS - 1) * 3];
        final float[] prefixMax = new float[(SAH_BINS - 1) * 3];
        final int[] prefixCount = new int[SAH_BINS - 1];
        final Triangle[] ordered;

        SahWorkspace(int triangles) {
            ordered = new Triangle[triangles];
        }
    }

    private VeilRayScene() {}

    public static byte[] compile(byte[] json, int capacity) {
        if (json.length > VeilShaderLimits.current().bufferBytes())
            throw new IllegalArgumentException("Ray scene JSON exceeds configured buffer budget");
        if (capacity < 32 || capacity > VeilShaderLimits.MAX_BUFFER_BYTES || (capacity & 15) != 0) {
            throw new IllegalArgumentException(
                    "Ray scene buffer requires a 16-byte aligned capacity within the representable shader buffer capacity");
        }
        JsonObject root =
                JsonParser.parseString(new String(json, StandardCharsets.UTF_8)).getAsJsonObject();
        if (integer(root, "version") != 1)
            throw new IllegalArgumentException("Unsupported ray scene version");
        JsonArray materials = root.getAsJsonArray("materials"),
                input = root.getAsJsonArray("triangles");
        if (materials == null
                || materials.isEmpty()
                || materials.size() > 256
                || input == null
                || input.isEmpty()
                || input.size() > MAX_TRIANGLES) {
            throw new IllegalArgumentException(
                    "Ray scene requires 1..256 materials and triangles within the representable buffer capacity");
        }
        Triangle[] triangles = new Triangle[input.size()];
        for (int i = 0; i < triangles.length; i++) {
            JsonObject t = input.get(i).getAsJsonObject();
            int material = integer(t, "material");
            if (material < 0 || material >= materials.size())
                throw new IllegalArgumentException("Invalid triangle material");
            float[] a = vector(t, "a", -1e6f, 1e6f),
                    b = vector(t, "b", -1e6f, 1e6f),
                    c = vector(t, "c", -1e6f, 1e6f);
            double ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
            double vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
            double nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            if (nx * nx + ny * ny + nz * nz < 1e-20)
                throw new IllegalArgumentException("Degenerate ray triangle: " + i);
            triangles[i] = new Triangle(a, b, c, material, i);
        }
        var nodes = new ArrayList<Node>();
        build(triangles, 0, triangles.length, nodes, new SahWorkspace(triangles.length));
        int triangleOffset = 2 + nodes.size() * 3,
                materialOffset = triangleOffset + triangles.length * 3;
        int usedBytes = (materialOffset + materials.size() * 2) * 16;
        if (usedBytes > capacity)
            throw new IllegalArgumentException(
                    "Ray scene needs " + usedBytes + " bytes; declared capacity=" + capacity);
        ByteBuffer out = ByteBuffer.allocate(capacity).order(ByteOrder.LITTLE_ENDIAN);
        out.putInt(MAGIC).putInt(1).putInt(nodes.size()).putInt(triangles.length);
        out.putInt(2).putInt(triangleOffset).putInt(materialOffset).putInt(materials.size());
        for (Node node : nodes) {
            for (float value : node.min) out.putFloat(Math.nextDown(value));
            out.putInt(0);
            for (float value : node.max) out.putFloat(Math.nextUp(value));
            out.putInt(0);
            out.putInt(node.first).putInt(node.count).putInt(node.escape).putInt(0);
        }
        for (Triangle triangle : triangles) {
            for (float value : triangle.a) out.putFloat(value);
            out.putInt(triangle.material);
            for (float value : triangle.b) out.putFloat(value);
            out.putInt(triangle.sourceIndex);
            for (float value : triangle.c) out.putFloat(value);
            out.putInt(0);
        }
        for (var item : materials) {
            JsonObject material = item.getAsJsonObject();
            int type =
                    material.get("type").getAsJsonPrimitive().isNumber()
                            ? integer(material, "type")
                            : switch (material.get("type").getAsString()) {
                                case "diffuse" -> 0;
                                case "mirror" -> 1;
                                case "dielectric" -> 2;
                                default ->
                                        throw new IllegalArgumentException(
                                                "Unknown ray material type");
                            };
            if (type < 0 || type > 65535)
                throw new IllegalArgumentException("Creator material type must be within 0..65535");
            for (float value : vector(material, "albedo", 0, 1)) out.putFloat(value);
            out.putInt(type);
            for (float value : vector(material, "emission", 0, 1e4f)) out.putFloat(value);
            float ior = material.has("ior") ? material.get("ior").getAsFloat() : 1.5f;
            if (!Float.isFinite(ior) || ior < 1 || ior > 4)
                throw new IllegalArgumentException("Material IOR must be within 1..4");
            out.putFloat(ior);
        }
        return out.array();
    }

    static byte[] compileWorld(
            float[] vertices,
            int triangleCount,
            float originX,
            float originY,
            float originZ,
            int capacity) {
        return compileWorldV2(vertices, triangleCount, originX, originY, originZ, capacity);
    }

    static byte[] compileWorld(
            float[] vertices,
            int[] attributes,
            int[] materials,
            int triangleCount,
            float originX,
            float originY,
            float originZ,
            int capacity) {
        if (triangleCount < 0
                || triangleCount > MAX_TRIANGLES
                || vertices.length != triangleCount * 9
                || attributes.length != triangleCount * 12
                || materials.length != triangleCount) {
            throw new IllegalArgumentException("Invalid attributed world ray triangle array");
        }
        if (capacity < 64
                || capacity > VeilShaderLimits.MAX_BUFFER_BYTES
                || (capacity & 15) != 0
                || 64L + triangleCount * 48L > capacity)
            throw new IllegalArgumentException("World ray triangle data exceeds buffer capacity");
        Triangle[] triangles = new Triangle[triangleCount];
        for (int i = 0; i < triangleCount; i++) {
            int base = i * 9;
            float[] a = {vertices[base], vertices[base + 1], vertices[base + 2]};
            float[] b = {vertices[base + 3], vertices[base + 4], vertices[base + 5]};
            float[] c = {vertices[base + 6], vertices[base + 7], vertices[base + 8]};
            int material = materials[i];
            if (material < 0 || material > 3)
                throw new IllegalArgumentException("Invalid Minecraft ray material");
            triangles[i] = new Triangle(a, b, c, material, i);
        }
        var nodes = new ArrayList<Node>();
        if (triangleCount != 0)
            build(triangles, 0, triangleCount, nodes, new SahWorkspace(triangleCount));
        int nodeOffset = 4;
        int triangleOffset = nodeOffset + nodes.size() * 3;
        int materialOffset = triangleOffset + triangleCount * 3;
        int materialCount = 4;
        int attributeOffset = materialOffset + materialCount * 2;
        int usedBytes = (attributeOffset + triangleCount * 3) * 16;
        if (capacity < 64
                || capacity > VeilShaderLimits.MAX_BUFFER_BYTES
                || (capacity & 15) != 0
                || usedBytes > capacity) {
            throw new IllegalArgumentException(
                    "Attributed world ray scene needs "
                            + usedBytes
                            + " bytes; capacity="
                            + capacity);
        }
        ByteBuffer out = ByteBuffer.allocate(capacity).order(ByteOrder.LITTLE_ENDIAN);
        out.putInt(MAGIC).putInt(3).putInt(nodes.size()).putInt(triangleCount);
        out.putInt(nodeOffset).putInt(triangleOffset).putInt(materialOffset).putInt(materialCount);
        out.putFloat(originX).putFloat(originY).putFloat(originZ).putInt(3);
        out.putInt(attributeOffset).putInt(3).putInt(0).putInt(0);
        writeNodes(out, nodes);
        for (Triangle triangle : triangles) {
            for (float value : triangle.a) out.putFloat(value);
            out.putInt(triangle.material);
            for (float value : triangle.b) out.putFloat(value);
            out.putInt(triangle.sourceIndex);
            for (float value : triangle.c) out.putFloat(value);
            out.putInt(0);
        }
        writeMinecraftMaterials(out);
        for (int attribute : attributes) out.putInt(attribute);
        return out.array();
    }

    private static byte[] compileWorldV2(
            float[] vertices,
            int triangleCount,
            float originX,
            float originY,
            float originZ,
            int capacity) {
        if (triangleCount < 0
                || triangleCount > MAX_TRIANGLES
                || vertices.length != triangleCount * 9) {
            throw new IllegalArgumentException("Invalid world ray triangle array");
        }
        if (capacity < 64
                || capacity > VeilShaderLimits.MAX_BUFFER_BYTES
                || (capacity & 15) != 0
                || 64L + triangleCount * 48L > capacity)
            throw new IllegalArgumentException("World ray triangle data exceeds buffer capacity");
        Triangle[] triangles = new Triangle[triangleCount];
        for (int i = 0; i < triangleCount; i++) {
            int base = i * 9;
            float[] a = {vertices[base], vertices[base + 1], vertices[base + 2]};
            float[] b = {vertices[base + 3], vertices[base + 4], vertices[base + 5]};
            float[] c = {vertices[base + 6], vertices[base + 7], vertices[base + 8]};
            triangles[i] = new Triangle(a, b, c, 0, i);
        }
        var nodes = new ArrayList<Node>();
        if (triangleCount != 0)
            build(triangles, 0, triangleCount, nodes, new SahWorkspace(triangleCount));
        int nodeOffset = 3;
        int triangleOffset = nodeOffset + nodes.size() * 3;
        int materialOffset = triangleOffset + triangleCount * 3;
        int usedBytes = (materialOffset + 2) * 16;
        if (capacity < 64
                || capacity > VeilShaderLimits.MAX_BUFFER_BYTES
                || (capacity & 15) != 0
                || usedBytes > capacity) {
            throw new IllegalArgumentException(
                    "World ray scene needs " + usedBytes + " bytes; capacity=" + capacity);
        }
        ByteBuffer out = ByteBuffer.allocate(capacity).order(ByteOrder.LITTLE_ENDIAN);
        out.putInt(MAGIC).putInt(2).putInt(nodes.size()).putInt(triangleCount);
        out.putInt(nodeOffset).putInt(triangleOffset).putInt(materialOffset).putInt(1);
        out.putFloat(originX).putFloat(originY).putFloat(originZ).putInt(1);
        writeNodes(out, nodes);
        for (Triangle triangle : triangles) {
            for (float value : triangle.a) out.putFloat(value);
            out.putInt(0);
            for (float value : triangle.b) out.putFloat(value);
            out.putInt(triangle.sourceIndex);
            for (float value : triangle.c) out.putFloat(value);
            out.putInt(0);
        }
        out.putFloat(0.8f).putFloat(0.8f).putFloat(0.8f).putInt(0);
        out.putFloat(0).putFloat(0).putFloat(0).putFloat(1.5f);
        return out.array();
    }

    private static void writeNodes(ByteBuffer out, ArrayList<Node> nodes) {
        for (Node node : nodes) {
            for (float value : node.min) out.putFloat(Math.nextDown(value));
            out.putInt(0);
            for (float value : node.max) out.putFloat(Math.nextUp(value));
            out.putInt(0);
            out.putInt(node.first).putInt(node.count).putInt(node.escape).putInt(0);
        }
    }

    private static void writeMinecraftMaterials(ByteBuffer out) {
        float[][] colors = {
            {1, 1, 1}, {0.18f, 0.38f, 0.75f}, {1.0f, 0.32f, 0.04f}, {0.65f, 0.72f, 0.78f}
        };
        for (int i = 0; i < colors.length; i++) {
            out.putFloat(colors[i][0]).putFloat(colors[i][1]).putFloat(colors[i][2]).putInt(0);
            float emission = i == VeilMaterialIds.LAVA ? 4.0f : 0.0f;
            out.putFloat(emission).putFloat(emission * 0.35f).putFloat(0).putFloat(1.5f);
        }
    }

    private static float[] vector(JsonObject object, String key, float min, float max) {
        JsonArray array = object.getAsJsonArray(key);
        if (array == null || array.size() != 3)
            throw new IllegalArgumentException("Expected vec3: " + key);
        float[] result = new float[3];
        for (int i = 0; i < 3; i++) {
            result[i] = array.get(i).getAsFloat();
            if (!Float.isFinite(result[i]) || result[i] < min || result[i] > max)
                throw new IllegalArgumentException("Invalid ray scene " + key);
        }
        return result;
    }

    private static int integer(JsonObject object, String key) {
        try {
            return object.get(key).getAsBigDecimal().intValueExact();
        } catch (ArithmeticException | NumberFormatException failure) {
            throw new IllegalArgumentException("Expected exact integer: " + key, failure);
        }
    }

    private static void build(
            Triangle[] triangles,
            int first,
            int end,
            ArrayList<Node> nodes,
            SahWorkspace workspace) {
        Node node = new Node();
        nodes.add(node);
        for (int i = first; i < end; i++) {
            Triangle t = triangles[i];
            for (int axis = 0; axis < 3; axis++) {
                node.min[axis] =
                        Math.min(
                                node.min[axis],
                                Math.min(t.a[axis], Math.min(t.b[axis], t.c[axis])));
                node.max[axis] =
                        Math.max(
                                node.max[axis],
                                Math.max(t.a[axis], Math.max(t.b[axis], t.c[axis])));
            }
        }
        if (end - first <= LEAF_TRIANGLES) {
            node.first = first;
            node.count = end - first;
        } else {
            Split split = chooseSplit(triangles, first, end, workspace);
            int mid =
                    split == null
                            ? medianSplit(triangles, first, end, node)
                            : partition(triangles, first, end, split, workspace);
            if (mid == first || mid == end) mid = medianSplit(triangles, first, end, node);
            build(triangles, first, mid, nodes, workspace);
            build(triangles, mid, end, nodes, workspace);
        }
        node.escape = nodes.size();
    }

    private static Split chooseSplit(
            Triangle[] triangles, int first, int end, SahWorkspace workspace) {
        float bestCost = Float.POSITIVE_INFINITY;
        Split best = null;
        for (int axis = 0; axis < 3; axis++) {
            float centroidMin = Float.POSITIVE_INFINITY;
            float centroidMax = Float.NEGATIVE_INFINITY;
            for (int i = first; i < end; i++) {
                float center = triangles[i].center(axis);
                centroidMin = Math.min(centroidMin, center);
                centroidMax = Math.max(centroidMax, center);
            }
            float extent = centroidMax - centroidMin;
            if (!(extent > 1e-7f)) continue;
            Arrays.fill(workspace.binMin, Float.POSITIVE_INFINITY);
            Arrays.fill(workspace.binMax, Float.NEGATIVE_INFINITY);
            Arrays.fill(workspace.binCount, 0);
            for (int i = first; i < end; i++) {
                Triangle triangle = triangles[i];
                int index =
                        Math.min(
                                SAH_BINS - 1,
                                (int) ((triangle.center(axis) - centroidMin) * SAH_BINS / extent));
                add(workspace, index, triangle);
            }
            float[] runningMin = {
                Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY
            };
            float[] runningMax = {
                Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY
            };
            int runningCount = 0;
            for (int i = 0; i < SAH_BINS - 1; i++) {
                runningCount += workspace.binCount[i];
                merge(runningMin, runningMax, workspace, i);
                workspace.prefixCount[i] = runningCount;
                System.arraycopy(runningMin, 0, workspace.prefixMin, i * 3, 3);
                System.arraycopy(runningMax, 0, workspace.prefixMax, i * 3, 3);
            }
            runningMin =
                    new float[] {
                        Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY
                    };
            runningMax =
                    new float[] {
                        Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY
                    };
            runningCount = 0;
            for (int i = SAH_BINS - 1; i > 0; i--) {
                runningCount += workspace.binCount[i];
                merge(runningMin, runningMax, workspace, i);
                int left = workspace.prefixCount[i - 1];
                if (left == 0 || runningCount == 0) continue;
                float cost =
                        surfaceArea(workspace.prefixMin, workspace.prefixMax, (i - 1) * 3) * left
                                + surfaceArea(runningMin, runningMax) * runningCount;
                if (cost < bestCost) {
                    bestCost = cost;
                    best = new Split(axis, centroidMin + extent * i / SAH_BINS);
                }
            }
        }
        return best;
    }

    private static int partition(
            Triangle[] triangles, int first, int end, Split split, SahWorkspace workspace) {
        Triangle[] ordered = workspace.ordered;
        int left = 0;
        for (int i = first; i < end; i++)
            if (triangles[i].center(split.axis) < split.position) ordered[left++] = triangles[i];
        int right = left;
        for (int i = first; i < end; i++)
            if (triangles[i].center(split.axis) >= split.position) ordered[right++] = triangles[i];
        System.arraycopy(ordered, 0, triangles, first, end - first);
        return first + left;
    }

    private static int medianSplit(Triangle[] triangles, int first, int end, Node node) {
        int axis = 0;
        for (int i = 1; i < 3; i++)
            if (node.max[i] - node.min[i] > node.max[axis] - node.min[axis]) axis = i;
        int splitAxis = axis;
        Arrays.sort(
                triangles,
                first,
                end,
                Comparator.comparingDouble((Triangle triangle) -> triangle.center(splitAxis))
                        .thenComparingInt(Triangle::sourceIndex));
        return (first + end) >>> 1;
    }

    private static void add(SahWorkspace workspace, int bin, Triangle triangle) {
        workspace.binCount[bin]++;
        int base = bin * 3;
        for (int axis = 0; axis < 3; axis++) {
            workspace.binMin[base + axis] =
                    Math.min(
                            workspace.binMin[base + axis],
                            Math.min(
                                    triangle.a[axis],
                                    Math.min(triangle.b[axis], triangle.c[axis])));
            workspace.binMax[base + axis] =
                    Math.max(
                            workspace.binMax[base + axis],
                            Math.max(
                                    triangle.a[axis],
                                    Math.max(triangle.b[axis], triangle.c[axis])));
        }
    }

    private static void merge(float[] min, float[] max, SahWorkspace workspace, int bin) {
        if (workspace.binCount[bin] == 0) return;
        int base = bin * 3;
        for (int axis = 0; axis < 3; axis++) {
            min[axis] = Math.min(min[axis], workspace.binMin[base + axis]);
            max[axis] = Math.max(max[axis], workspace.binMax[base + axis]);
        }
    }

    private static float surfaceArea(float[] min, float[] max, int offset) {
        float x = Math.max(0, max[offset] - min[offset]);
        float y = Math.max(0, max[offset + 1] - min[offset + 1]);
        float z = Math.max(0, max[offset + 2] - min[offset + 2]);
        return 2 * (x * y + y * z + z * x);
    }

    private static float surfaceArea(float[] min, float[] max) {
        float x = Math.max(0, max[0] - min[0]);
        float y = Math.max(0, max[1] - min[1]);
        float z = Math.max(0, max[2] - min[2]);
        return 2 * (x * y + y * z + z * x);
    }

    private record Split(int axis, float position) {}
}
