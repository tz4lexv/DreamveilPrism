package dev.veil.revive.client.graphics.minecraft;

import com.mojang.blaze3d.pipeline.RenderPipeline;

import java.util.Objects;
import java.util.function.UnaryOperator;

public final class SceneRasterScope implements AutoCloseable {
    private static final ThreadLocal<SceneRasterScope> ACTIVE = new ThreadLocal<>();
    private final SceneRasterScope previous;
    private final UnaryOperator<RenderPipeline> resolver;
    private boolean closed;

    private SceneRasterScope(UnaryOperator<RenderPipeline> resolver) {
        this.resolver = Objects.requireNonNull(resolver);
        previous = ACTIVE.get();
        ACTIVE.set(this);
    }

    public static SceneRasterScope enter(UnaryOperator<RenderPipeline> resolver) {
        return new SceneRasterScope(resolver);
    }

    public static boolean active() {
        return ACTIVE.get() != null;
    }

    public static RenderPipeline resolve(RenderPipeline pipeline) {
        SceneRasterScope scope = ACTIVE.get();
        return scope == null ? pipeline : scope.resolver.apply(pipeline);
    }

    @Override
    public void close() {
        if (closed) return;
        if (ACTIVE.get() != this)
            throw new IllegalStateException("Scene raster scopes must close in order");
        closed = true;
        if (previous == null) ACTIVE.remove();
        else ACTIVE.set(previous);
    }
}
