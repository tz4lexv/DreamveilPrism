package dev.veil.revive.client;

import dev.veil.api.VeilCreatorScene;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

final class VeilDynamicGeometry {
    static final int MAX_PRIMITIVES = 2048;

    record Node(
            float minX,
            float minY,
            float minZ,
            float maxX,
            float maxY,
            float maxZ,
            int left,
            int right,
            int primitive) {
        boolean leaf() {
            return primitive >= 0;
        }
    }

    record Build(
            List<VeilCreatorScene.Instance> primitives, List<Node> nodes, int root, int maxDepth) {
        Build {
            primitives = List.copyOf(primitives);
            nodes = List.copyOf(nodes);
        }
    }

    private VeilDynamicGeometry() {}

    static Build build(List<VeilCreatorScene.Instance> source) {
        int count = Math.min(source.size(), MAX_PRIMITIVES);
        if (count == 0) return new Build(List.of(), List.of(), -1, 0);
        ArrayList<VeilCreatorScene.Instance> ordered = new ArrayList<>(source.subList(0, count));
        ArrayList<Node> nodes = new ArrayList<>(count * 2 - 1);
        int[] maxDepth = {0};
        int root = buildRange(ordered, nodes, 0, ordered.size(), 1, maxDepth);
        return new Build(ordered, nodes, root, maxDepth[0]);
    }

    private static int buildRange(
            ArrayList<VeilCreatorScene.Instance> primitives,
            ArrayList<Node> nodes,
            int from,
            int to,
            int depth,
            int[] maxDepth) {
        maxDepth[0] = Math.max(maxDepth[0], depth);
        Bounds bounds = bounds(primitives, from, to);
        int nodeIndex = nodes.size();
        nodes.add(null);
        if (to - from == 1) {
            nodes.set(
                    nodeIndex,
                    new Node(
                            bounds.minX,
                            bounds.minY,
                            bounds.minZ,
                            bounds.maxX,
                            bounds.maxY,
                            bounds.maxZ,
                            -1,
                            -1,
                            from));
            return nodeIndex;
        }
        float ex = bounds.centroidMaxX - bounds.centroidMinX;
        float ey = bounds.centroidMaxY - bounds.centroidMinY;
        float ez = bounds.centroidMaxZ - bounds.centroidMinZ;
        int axis = ex >= ey && ex >= ez ? 0 : ey >= ez ? 1 : 2;
        primitives
                .subList(from, to)
                .sort(Comparator.comparingDouble(value -> centroid(value, axis)));
        int middle = (from + to) >>> 1;
        int left = buildRange(primitives, nodes, from, middle, depth + 1, maxDepth);
        int right = buildRange(primitives, nodes, middle, to, depth + 1, maxDepth);
        nodes.set(
                nodeIndex,
                new Node(
                        bounds.minX,
                        bounds.minY,
                        bounds.minZ,
                        bounds.maxX,
                        bounds.maxY,
                        bounds.maxZ,
                        left,
                        right,
                        -1));
        return nodeIndex;
    }

    private static double centroid(VeilCreatorScene.Instance value, int axis) {
        return switch (axis) {
            case 0 -> (value.minX() + value.maxX()) * 0.5;
            case 1 -> (value.minY() + value.maxY()) * 0.5;
            default -> (value.minZ() + value.maxZ()) * 0.5;
        };
    }

    private static Bounds bounds(List<VeilCreatorScene.Instance> values, int from, int to) {
        float minX = Float.POSITIVE_INFINITY,
                minY = Float.POSITIVE_INFINITY,
                minZ = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY,
                maxY = Float.NEGATIVE_INFINITY,
                maxZ = Float.NEGATIVE_INFINITY;
        float centroidMinX = Float.POSITIVE_INFINITY,
                centroidMinY = Float.POSITIVE_INFINITY,
                centroidMinZ = Float.POSITIVE_INFINITY;
        float centroidMaxX = Float.NEGATIVE_INFINITY,
                centroidMaxY = Float.NEGATIVE_INFINITY,
                centroidMaxZ = Float.NEGATIVE_INFINITY;
        for (int index = from; index < to; index++) {
            VeilCreatorScene.Instance value = values.get(index);
            minX = Math.min(minX, value.minX());
            minY = Math.min(minY, value.minY());
            minZ = Math.min(minZ, value.minZ());
            maxX = Math.max(maxX, value.maxX());
            maxY = Math.max(maxY, value.maxY());
            maxZ = Math.max(maxZ, value.maxZ());
            float cx = (value.minX() + value.maxX()) * 0.5f;
            float cy = (value.minY() + value.maxY()) * 0.5f;
            float cz = (value.minZ() + value.maxZ()) * 0.5f;
            centroidMinX = Math.min(centroidMinX, cx);
            centroidMinY = Math.min(centroidMinY, cy);
            centroidMinZ = Math.min(centroidMinZ, cz);
            centroidMaxX = Math.max(centroidMaxX, cx);
            centroidMaxY = Math.max(centroidMaxY, cy);
            centroidMaxZ = Math.max(centroidMaxZ, cz);
        }
        return new Bounds(
                minX,
                minY,
                minZ,
                maxX,
                maxY,
                maxZ,
                centroidMinX,
                centroidMinY,
                centroidMinZ,
                centroidMaxX,
                centroidMaxY,
                centroidMaxZ);
    }

    private record Bounds(
            float minX,
            float minY,
            float minZ,
            float maxX,
            float maxY,
            float maxZ,
            float centroidMinX,
            float centroidMinY,
            float centroidMinZ,
            float centroidMaxX,
            float centroidMaxY,
            float centroidMaxZ) {}
}
