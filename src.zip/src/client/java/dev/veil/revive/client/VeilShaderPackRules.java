package dev.veil.revive.client;

import dev.veil.revive.client.VeilShaderPack.Resource;

import java.util.Map;

final class VeilShaderPackRules {
    private VeilShaderPackRules() {}

    static void validateDimensionDependencies(Map<String, Resource> resources) {
        dev.veil.revive.client.shaderpack.parsing.ResourceParser.validateDimensionDependencies(
                resources);
    }

    static String resourceName(String name) {
        return dev.veil.revive.client.shaderpack.parsing.ManifestJson.resourceName(name);
    }
}
