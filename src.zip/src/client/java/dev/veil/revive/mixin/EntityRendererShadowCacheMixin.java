package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilShadowReceiverCache;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.ChunkAccess;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererShadowCacheMixin {
    @Inject(method = "extractShadowPiece", at = @At("HEAD"), cancellable = true, require = 0)
    private void veil$cachedShadowReceiver(
            EntityRenderState state,
            Level level,
            float power,
            BlockPos.MutableBlockPos pos,
            ChunkAccess chunk,
            CallbackInfo ci) {
        if (VeilShadowReceiverCache.extract(state, level, power, pos, chunk)) {
            ci.cancel();
        }
    }
}
