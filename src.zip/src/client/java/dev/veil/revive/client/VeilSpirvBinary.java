package dev.veil.revive.client;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.Objects;

public record VeilSpirvBinary(
        byte[] code, VeilShaderStage stage, String sourceName, String entryPoint, String sha256) {

    public VeilSpirvBinary {
        Objects.requireNonNull(code, "code");
        Objects.requireNonNull(stage, "stage");
        Objects.requireNonNull(sourceName, "sourceName");
        Objects.requireNonNull(entryPoint, "entryPoint");
        Objects.requireNonNull(sha256, "sha256");
        code = Arrays.copyOf(code, code.length);
        if (sourceName.isBlank()) throw new IllegalArgumentException("sourceName is blank");
        if (entryPoint.isBlank() || entryPoint.indexOf('\0') >= 0)
            throw new IllegalArgumentException("Invalid entry point");
        validate(code);
    }

    @Override
    public byte[] code() {
        return Arrays.copyOf(code, code.length);
    }

    byte[] unsafeCode() {
        return code;
    }

    public String contentHash() {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update((byte) stage.ordinal());
            digest.update(entryPoint.getBytes(StandardCharsets.UTF_8));
            digest.update((byte) 0);
            return HexFormat.of().formatHex(digest.digest(code));
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }

    @Override
    public boolean equals(Object other) {
        return this == other
                || other instanceof VeilSpirvBinary binary
                        && stage == binary.stage
                        && sourceName.equals(binary.sourceName)
                        && entryPoint.equals(binary.entryPoint)
                        && sha256.equals(binary.sha256)
                        && Arrays.equals(code, binary.code);
    }

    @Override
    public int hashCode() {
        return 31 * Objects.hash(stage, sourceName, entryPoint, sha256) + Arrays.hashCode(code);
    }

    private static void validate(byte[] code) {
        if (code.length < 20 || (code.length & 3) != 0) {
            throw new IllegalArgumentException(
                    "SPIR-V requires a five-word header and a multiple-of-four byte length");
        }
        var words = ByteBuffer.wrap(code).order(ByteOrder.LITTLE_ENDIAN).asIntBuffer();
        if (words.get(0) != 0x07230203)
            throw new IllegalArgumentException("Invalid little-endian SPIR-V magic");
        int version = words.get(1);
        if ((version & 0xffff00ff) != 0x00010000 || ((version >>> 8) & 0xff) > 5) {
            throw new IllegalArgumentException(
                    "Veil Vulkan 1.2 baseline accepts SPIR-V 1.0 through 1.5");
        }
        if (words.get(3) <= 0 || words.get(4) != 0)
            throw new IllegalArgumentException("Invalid SPIR-V ID bound or schema");
        for (int offset = 5; offset < words.limit(); ) {
            int count = words.get(offset) >>> 16;
            if (count == 0 || count > words.limit() - offset) {
                throw new IllegalArgumentException(
                        "Truncated SPIR-V instruction at word " + offset);
            }
            offset += count;
        }
    }
}
