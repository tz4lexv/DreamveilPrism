package dev.veil.revive.client.shaderpack.parsing;

import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.*;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import dev.veil.revive.client.VeilShaderPack.Setting;

import java.util.LinkedHashMap;
import java.util.Map;

public final class SettingsExpressions {
    private SettingsExpressions() {}

    public static int positiveIntegerSetting(Map<String, Setting> settings, String name) {
        Setting setting = settings.get(name);
        if (setting == null)
            throw new IllegalArgumentException("Unknown dimension setting " + name);
        int value;
        try {
            value = new java.math.BigDecimal(setting.value()).intValueExact();
        } catch (ArithmeticException failure) {
            throw new IllegalArgumentException(
                    "Dimension setting must be an integer: " + name, failure);
        }
        if (value < 1 || value > 16384)
            throw new IllegalArgumentException("Dimension setting is outside 1..16384: " + name);
        return value;
    }

    public static float positiveFloatValue(
            JsonElement element, Map<String, Setting> settings, String field) {
        float value = floatValue(element, settings, field);
        if (value <= 0.0f) throw new IllegalArgumentException(field + " must be positive");
        return value;
    }

    public static float floatValue(
            JsonElement element, Map<String, Setting> settings, String field) {
        if (element == null) throw new IllegalArgumentException(field + " is missing");
        String value =
                element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()
                        ? settingValue(settings, element.getAsString())
                        : element.getAsString();
        float parsed;
        try {
            parsed = Float.parseFloat(value);
        } catch (NumberFormatException failure) {
            throw new IllegalArgumentException(field + " is not numeric", failure);
        }
        if (!Float.isFinite(parsed)) throw new IllegalArgumentException(field + " must be finite");
        return parsed;
    }

    private static String settingValue(Map<String, Setting> settings, String name) {
        Setting setting = settings.get(name);
        if (setting == null)
            throw new IllegalArgumentException("Unknown scene camera setting " + name);
        return setting.value();
    }

    public static Map<String, Setting> parseSettings(JsonObject root) {
        var settings = new LinkedHashMap<String, Setting>();
        for (var entry : object(root, "settings").entrySet()) {
            JsonObject item = entry.getValue().getAsJsonObject();
            fields(item, "type", "value", "options");
            settings.put(
                    resourceName(entry.getKey()),
                    new Setting(
                            item.get("type").getAsString(),
                            item.get("value").getAsString(),
                            strings(item, "options")));
        }
        return settings;
    }
}
