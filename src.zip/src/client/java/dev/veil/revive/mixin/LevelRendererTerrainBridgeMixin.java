package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilFullFrameTelemetry;
import dev.veil.revive.client.VeilMinecraftTerrainBridge;
import dev.veil.revive.client.VeilSceneTerrainSelection;
import dev.veil.revive.client.VeilSectionVisibilityIndex;
import dev.veil.revive.client.VeilShaderPackBridge;
import dev.veil.revive.client.VeilTerrainDrawBridge;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererTerrainBridgeMixin {
    @Inject(
            method =
                    "prepareChunkRenders(Lorg/joml/Matrix4fc;)Lnet/minecraft/client/renderer/chunk/ChunkSectionsToRender;",
            at = @At("HEAD"),
            cancellable = true,
            require = 0)
    private void revive$prepareTerrain(
            Matrix4fc modelViewMatrix, CallbackInfoReturnable<ChunkSectionsToRender> cir) {
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.TERRAIN_PREPARE);
        LevelRenderer renderer = (LevelRenderer) (Object) this;
        if (VeilSceneTerrainSelection.preparing(renderer)) return;
        dev.veil.revive.client.VeilMaterialHost.captureModelView(modelViewMatrix);

        if (VeilShaderPackBridge.shaderPackActive()) {
            VeilTerrainDrawBridge.shaderPackBypassFrame();
            return;
        }

        var visibleSections = renderer.visibleSections();
        SectionRenderDispatcher dispatcher = renderer.sectionRenderDispatcher();

        if (ReviveRuntime.optimizationsEnabled()) {
            Minecraft minecraft = Minecraft.getInstance();
            Camera camera = minecraft.gameRenderer.mainCamera();
            VeilMinecraftTerrainBridge.onRendererUpdate(camera, visibleSections);
            VeilSectionVisibilityIndex.update(visibleSections);
        }

        ChunkSectionsToRender prepared =
                VeilTerrainDrawBridge.prepare(
                        Minecraft.getInstance(), visibleSections, dispatcher, modelViewMatrix);

        if (prepared != null) {
            cir.setReturnValue(prepared);
            dev.veil.revive.client.VeilTechniqueCounters.terrainReturnOverride();
        }
    }

    @Inject(
            method =
                    "prepareChunkRenders(Lorg/joml/Matrix4fc;)Lnet/minecraft/client/renderer/chunk/ChunkSectionsToRender;",
            at = @At("RETURN"),
            require = 0)
    private void veil$finishTerrainPrepare(
            Matrix4fc modelViewMatrix, CallbackInfoReturnable<ChunkSectionsToRender> cir) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.TERRAIN_PREPARE);
    }
}
