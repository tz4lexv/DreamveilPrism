package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.mojang.blaze3d.vertex.VertexSorting;

import net.minecraft.client.renderer.SectionBufferBuilderPack;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.core.SectionPos;

import org.spongepowered.asm.mixin.Mixin;

@Mixin(SectionCompiler.class)
public abstract class SectionCompilerFaceCacheMixin {
    @WrapMethod(method = "compile")
    private SectionCompiler.Results veil$compileWithCaches(
            SectionPos sectionPos,
            RenderSectionRegion region,
            VertexSorting sorting,
            SectionBufferBuilderPack builders,
            Operation<SectionCompiler.Results> original) {
        return dev.veil.revive.client.VeilOwnSectionCompiler.dispatch(
                (SectionCompilerStateAccessor) (Object) this,
                sectionPos,
                region,
                sorting,
                builders,
                java.util.List.of(),
                target -> original.call(sectionPos, region, sorting, target));
    }
}
