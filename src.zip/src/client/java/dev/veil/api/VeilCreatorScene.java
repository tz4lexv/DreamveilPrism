package dev.veil.api;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

public final class VeilCreatorScene {
    public static final int LIGHT_DIRECTIONAL = 0;
    public static final int LIGHT_POINT = 1;
    public static final int LIGHT_SPOT = 2;
    public static final int LIGHT_RECTANGLE = 3;
    public static final int LIGHT_DISK = 4;
    public static final int INSTANCE_AABB = 0;
    public static final int INSTANCE_SPHERE = 1;
    public static final int INSTANCE_CAPSULE = 2;
    public static final int INSTANCE_LOCAL_PLAYER = 1;
    public static final int INSTANCE_LIVING = 2;
    public static final int INSTANCE_ITEM = 4;

    /** Actual entity contact with water; independent of the camera's medium. */
    public static final int INSTANCE_IN_WATER = 8;

    public record Light(
            long id,
            int type,
            float x,
            float y,
            float z,
            float range,
            float r,
            float g,
            float b,
            float intensity,
            float directionX,
            float directionY,
            float directionZ,
            float innerCos,
            float outerCos,
            int flags) {
        public Light {
            if (type < LIGHT_DIRECTIONAL
                    || type > LIGHT_DISK
                    || !finite(
                            x,
                            y,
                            z,
                            range,
                            r,
                            g,
                            b,
                            intensity,
                            directionX,
                            directionY,
                            directionZ,
                            innerCos,
                            outerCos)
                    || range < 0.0f
                    || intensity < 0.0f) {
                throw new IllegalArgumentException("Invalid Veil creator light");
            }
        }
    }

    public record Instance(
            long id,
            int type,
            int material,
            int flags,
            float x,
            float y,
            float z,
            float previousX,
            float previousY,
            float previousZ,
            float minX,
            float minY,
            float minZ,
            float maxX,
            float maxY,
            float maxZ,
            float yaw,
            float pitch) {
        public Instance {
            if (type < INSTANCE_AABB
                    || type > INSTANCE_CAPSULE
                    || material < 0
                    || !finite(
                            x, y, z, previousX, previousY, previousZ, minX, minY, minZ, maxX, maxY,
                            maxZ, yaw, pitch)
                    || minX > maxX
                    || minY > maxY
                    || minZ > maxZ) {
                throw new IllegalArgumentException("Invalid Veil creator instance");
            }
        }
    }

    public record Material(
            int id,
            float baseR,
            float baseG,
            float baseB,
            float alpha,
            float emissionR,
            float emissionG,
            float emissionB,
            float roughness,
            float metallic,
            float ior,
            float transmission,
            float occlusion,
            float absorptionR,
            float absorptionG,
            float absorptionB,
            float subsurface,
            int flags) {
        public Material {
            if (id < 0
                    || !finite(
                            baseR,
                            baseG,
                            baseB,
                            alpha,
                            emissionR,
                            emissionG,
                            emissionB,
                            roughness,
                            metallic,
                            ior,
                            transmission,
                            occlusion,
                            absorptionR,
                            absorptionG,
                            absorptionB,
                            subsurface)
                    || alpha < 0.0f
                    || roughness < 0.0f
                    || metallic < 0.0f
                    || ior < 1.0f
                    || transmission < 0.0f
                    || occlusion < 0.0f
                    || subsurface < 0.0f) {
                throw new IllegalArgumentException("Invalid Veil creator material");
            }
        }
    }

    public interface Registration extends AutoCloseable {
        @Override
        void close();
    }

    private static final ConcurrentHashMap<Long, Light> LIGHTS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Long, Instance> INSTANCES = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Integer, Material> MATERIALS = new ConcurrentHashMap<>();

    private VeilCreatorScene() {}

    public static Registration registerLight(Light light) {
        Objects.requireNonNull(light, "light");
        LIGHTS.put(light.id(), light);
        return () -> LIGHTS.remove(light.id(), light);
    }

    public static Registration registerInstance(Instance instance) {
        Objects.requireNonNull(instance, "instance");
        INSTANCES.put(instance.id(), instance);
        return () -> INSTANCES.remove(instance.id(), instance);
    }

    public static Registration registerMaterial(Material material) {
        Objects.requireNonNull(material, "material");
        MATERIALS.put(material.id(), material);
        return () -> MATERIALS.remove(material.id(), material);
    }

    public static List<Light> lights() {
        return List.copyOf(LIGHTS.values());
    }

    public static List<Instance> instances() {
        return List.copyOf(INSTANCES.values());
    }

    public static List<Material> materials() {
        return List.copyOf(MATERIALS.values());
    }

    private static boolean finite(float... values) {
        for (float value : values) if (!Float.isFinite(value)) return false;
        return true;
    }
}
