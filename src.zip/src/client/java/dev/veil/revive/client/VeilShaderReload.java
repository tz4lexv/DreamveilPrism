package dev.veil.revive.client;

import dev.veil.revive.client.shaderpack.reload.ReloadCoordinator;

import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.function.Function;

public final class VeilShaderReload<P, G extends VeilShaderReload.Generation>
        implements AutoCloseable {
    @FunctionalInterface
    public interface Preparation<P> extends ReloadCoordinator.Preparation<P> {
        @Override
        P prepare() throws java.io.IOException;
    }

    public interface Generation extends ReloadCoordinator.Generation {
        @Override
        void close();
    }

    private final ReloadCoordinator<P, G> coordinator;

    public VeilShaderReload(Executor worker, Function<P, G> install, VeilShaderMetrics metrics) {
        Objects.requireNonNull(worker, "worker");
        Objects.requireNonNull(install, "install");
        Objects.requireNonNull(metrics, "metrics");
        coordinator =
                new ReloadCoordinator<>(
                        worker,
                        install,
                        metrics.reloadSuccess::increment,
                        metrics.reloadFailure::increment);
    }

    public synchronized long request(Preparation<P> prepare) {
        return coordinator.request(prepare);
    }

    public synchronized boolean publishAtFrameBoundary() {
        return coordinator.publishAtFrameBoundary();
    }

    public G active() {
        return coordinator.active();
    }

    public String diagnostic() {
        return coordinator.diagnostic();
    }

    public boolean isPending() {
        return coordinator.isPending();
    }

    public boolean failed() {
        return coordinator.failed();
    }

    @Override
    public synchronized void close() {
        coordinator.close();
    }
}
