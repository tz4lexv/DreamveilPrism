package dev.veil.revive.client;

import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.shaderc.Shaderc;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

public final class VeilSpirvCompiler {
    private VeilSpirvCompiler() {}

    public static VeilSpirvBinary compile(String sourceName, String source, VeilShaderStage stage) {
        return compile(sourceName, source, stage, "main", true);
    }

    public static VeilSpirvBinary compile(
            String sourceName,
            String source,
            VeilShaderStage stage,
            String entryPoint,
            boolean optimize) {
        return compile(sourceName, source, stage, entryPoint, optimize, false);
    }

    public static VeilSpirvBinary compile(
            String sourceName,
            String source,
            VeilShaderStage stage,
            String entryPoint,
            boolean optimize,
            boolean debug) {
        if (sourceName == null || sourceName.isBlank())
            throw new IllegalArgumentException("sourceName is blank");
        if (source == null || source.isBlank())
            throw new IllegalArgumentException("shader source is blank");
        if (stage == null) throw new NullPointerException("stage");
        if (entryPoint == null || entryPoint.isBlank())
            throw new IllegalArgumentException("entryPoint is blank");

        long compiler = Shaderc.shaderc_compiler_initialize();
        if (compiler == 0L) throw new IllegalStateException("shaderc_compiler_initialize failed");
        long options = Shaderc.shaderc_compile_options_initialize();
        if (options == 0L) {
            Shaderc.shaderc_compiler_release(compiler);
            throw new IllegalStateException("shaderc_compile_options_initialize failed");
        }

        long result = 0L;
        ByteBuffer sourceUtf8 = null;
        ByteBuffer nameUtf8 = null;
        ByteBuffer entryUtf8 = null;
        try {
            Shaderc.shaderc_compile_options_set_target_env(
                    options,
                    Shaderc.shaderc_target_env_vulkan,
                    Shaderc.shaderc_env_version_vulkan_1_2);
            Shaderc.shaderc_compile_options_set_optimization_level(
                    options,
                    optimize
                            ? Shaderc.shaderc_optimization_level_performance
                            : Shaderc.shaderc_optimization_level_zero);
            Shaderc.shaderc_compile_options_set_target_spirv(
                    options, Shaderc.shaderc_spirv_version_1_5);
            if (debug) Shaderc.shaderc_compile_options_set_generate_debug_info(options);
            // Expanded includes can exceed LWJGL's fixed-size thread stack.
            // Allocate only for this compilation and release on every outcome.
            sourceUtf8 = MemoryUtil.memUTF8(source, false);
            nameUtf8 = MemoryUtil.memUTF8(sourceName, true);
            entryUtf8 = MemoryUtil.memUTF8(entryPoint, true);
            result =
                    Shaderc.shaderc_compile_into_spv(
                            compiler,
                            sourceUtf8,
                            stage.shadercKind(),
                            nameUtf8,
                            entryUtf8,
                            options);
            if (result == 0L)
                throw new IllegalStateException(
                        "shaderc_compile_into_spv returned null for " + sourceName);

            int status = Shaderc.shaderc_result_get_compilation_status(result);
            if (status != Shaderc.shaderc_compilation_status_success) {
                String diagnostics = Shaderc.shaderc_result_get_error_message(result);
                throw new IllegalStateException(
                        "SPIR-V compilation failed for " + sourceName + ":\n" + diagnostics);
            }

            ByteBuffer bytes = Shaderc.shaderc_result_get_bytes(result);
            byte[] code = new byte[bytes.remaining()];
            bytes.get(code);
            return new VeilSpirvBinary(
                    code,
                    stage,
                    sourceName,
                    entryPoint,
                    sha256(source, stage, entryPoint, optimize, debug));
        } finally {
            if (result != 0L) Shaderc.shaderc_result_release(result);
            if (entryUtf8 != null) MemoryUtil.memFree(entryUtf8);
            if (nameUtf8 != null) MemoryUtil.memFree(nameUtf8);
            if (sourceUtf8 != null) MemoryUtil.memFree(sourceUtf8);
            Shaderc.shaderc_compile_options_release(options);
            Shaderc.shaderc_compiler_release(compiler);
        }
    }

    private static String sha256(
            String source,
            VeilShaderStage stage,
            String entryPoint,
            boolean optimize,
            boolean debug) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update((byte) stage.ordinal());
            digest.update((byte) (optimize ? 1 : 0));
            digest.update((byte) (debug ? 1 : 0));
            digest.update(entryPoint.getBytes(StandardCharsets.UTF_8));
            digest.update((byte) 0);
            digest.update(source.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest.digest());
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }
}
