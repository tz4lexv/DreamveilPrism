package dev.veil.api;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;

/** Creator-supplied environmental signals, not a prescribed weather simulation. */
public final class VeilEnvironment {
    public record Wind(float x, float z) {
        public Wind {
            if (!Float.isFinite(x) || !Float.isFinite(z) || Math.hypot(x, z) > Float.MAX_VALUE)
                throw new IllegalArgumentException("Wind must be finite");
        }
    }

    public static final int CUSTOM_CHANNELS = 16;
    private static final String CHANNEL_STATE_ID = "veil:environment_channels_v1";
    private static final int SERIALIZED_BYTES = Integer.BYTES + CUSTOM_CHANNELS * Float.BYTES;

    /** Immutable snapshot. Channel indices are intentionally application-defined. */
    public static final class Channels {
        private final int mask;
        private final float[] values;

        private Channels(int mask, float[] values) {
            this.mask = mask;
            this.values = values.clone();
            for (int index = 0; index < CUSTOM_CHANNELS; index++) {
                if ((mask & (1 << index)) == 0) this.values[index] = 0;
            }
        }

        public int mask() {
            return mask;
        }

        public boolean contains(int index) {
            checkIndex(index);
            return (mask & (1 << index)) != 0;
        }

        public float value(int index) {
            checkIndex(index);
            return values[index];
        }
    }

    private static volatile Wind wind = new Wind(0, 0);
    private static volatile Channels channels = new Channels(0, new float[CUSTOM_CHANNELS]);

    private VeilEnvironment() {}

    public static Wind wind() {
        return wind;
    }

    public static void setWind(float x, float z) {
        wind = new Wind(x, z);
    }

    public static Channels channels() {
        return channels;
    }

    /** Publishes one scalar without assigning weather-specific meaning to its index. */
    public static synchronized void setChannel(int index, float value) {
        checkIndex(index);
        checkFinite(value);
        float[] values = channels.values.clone();
        values[index] = value;
        channels = new Channels(channels.mask | (1 << index), values);
    }

    /** Publishes multiple scalar values atomically to the render thread. */
    public static synchronized void setChannels(int mask, float[] values) {
        Objects.requireNonNull(values, "values");
        if (values.length != CUSTOM_CHANNELS || (mask & ~0xffff) != 0)
            throw new IllegalArgumentException("Expected 16 custom channels and a 16-bit mask");
        for (float value : values) checkFinite(value);
        channels = new Channels(mask, values);
    }

    public static synchronized void clearChannel(int index) {
        checkIndex(index);
        float[] values = channels.values.clone();
        values[index] = 0;
        channels = new Channels(channels.mask & ~(1 << index), values);
    }

    public static synchronized void clearChannels() {
        channels = new Channels(0, new float[CUSTOM_CHANNELS]);
    }

    /** Reset all creator-published environmental state at a world/client boundary. */
    public static synchronized void resetCustom() {
        wind = new Wind(0, 0);
        channels = new Channels(0, new float[CUSTOM_CHANNELS]);
    }

    /**
     * Optional, explicit persistence for creator-controlled scalar signals. The caller supplies
     * world/pack identity and decides when to checkpoint.
     */
    public static void saveChannels(VeilSimulationStateStore store, String worldId, String packId)
            throws IOException {
        Objects.requireNonNull(store, "store");
        Channels snapshot = channels;
        ByteBuffer out = ByteBuffer.allocate(SERIALIZED_BYTES).order(ByteOrder.LITTLE_ENDIAN);
        out.putInt(snapshot.mask);
        for (int i = 0; i < CUSTOM_CHANNELS; i++) out.putFloat(snapshot.values[i]);
        store.save(worldId, packId, CHANNEL_STATE_ID, out.array());
    }

    /**
     * Returns false if no previous state exists; invalid snapshots leave current state unchanged.
     */
    public static boolean restoreChannels(
            VeilSimulationStateStore store, String worldId, String packId) throws IOException {
        Objects.requireNonNull(store, "store");
        var snapshot = store.load(worldId, packId, CHANNEL_STATE_ID);
        if (snapshot.isEmpty()) return false;
        byte[] stored = snapshot.get();
        if (stored.length != SERIALIZED_BYTES)
            throw new IOException("Incompatible environment channel snapshot");
        ByteBuffer in = ByteBuffer.wrap(stored).order(ByteOrder.LITTLE_ENDIAN);
        int mask = in.getInt();
        float[] values = new float[CUSTOM_CHANNELS];
        for (int i = 0; i < CUSTOM_CHANNELS; i++) values[i] = in.getFloat();
        try {
            setChannels(mask, values);
        } catch (IllegalArgumentException badContents) {
            throw new IOException("Invalid environment channel snapshot", badContents);
        }
        return true;
    }

    private static void checkIndex(int index) {
        if (index < 0 || index >= CUSTOM_CHANNELS)
            throw new IndexOutOfBoundsException("Environment channel index: " + index);
    }

    private static void checkFinite(float value) {
        if (!Float.isFinite(value))
            throw new IllegalArgumentException("Environment channel must be finite");
    }
}
