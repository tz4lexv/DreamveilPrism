package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK12.*;

import dev.veil.revive.client.graphics.minecraft.DeferredGpuRetirement;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkQueryPoolCreateInfo;

import java.util.OptionalLong;

final class VeilShaderInvocationQueries implements AutoCloseable {
    private final VeilVulkanRuntime runtime;
    private final DeferredGpuRetirement retirement = new DeferredGpuRetirement();
    private long pool;

    VeilShaderInvocationQueries(VeilVulkanRuntime runtime, int count) {
        this.runtime = runtime;
        if (!VeilVulkanCapabilities.pipelineStatistics()) return;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var pointer = stack.mallocLong(1);
            var info =
                    VkQueryPoolCreateInfo.calloc(stack)
                            .sType$Default()
                            .queryType(VK_QUERY_TYPE_PIPELINE_STATISTICS)
                            .queryCount(count)
                            .pipelineStatistics(
                                    VK_QUERY_PIPELINE_STATISTIC_VERTEX_SHADER_INVOCATIONS_BIT
                                            | VK_QUERY_PIPELINE_STATISTIC_FRAGMENT_SHADER_INVOCATIONS_BIT
                                            | VK_QUERY_PIPELINE_STATISTIC_COMPUTE_SHADER_INVOCATIONS_BIT);
            VeilVulkanChecks.check(
                    vkCreateQueryPool(runtime.vkDevice(), info, null, pointer),
                    "native shader invocation query pool");
            pool = pointer.get(0);
            VeilShaderDebugNames.name(
                    runtime, VK_OBJECT_TYPE_QUERY_POOL, pool, "Veil/NativeShaderInvocations");
        }
    }

    void begin(int index) {
        if (pool == 0) return;
        vkCmdBeginQuery(runtime.commandBuffer(), pool, index, 0);
    }

    void reset(int first, int count) {
        if (pool != 0) vkCmdResetQueryPool(runtime.commandBuffer(), pool, first, count);
    }

    void end(int index) {
        if (pool != 0) vkCmdEndQuery(runtime.commandBuffer(), pool, index);
    }

    OptionalLong[] read(int first, int count) {
        if (pool == 0) return null;
        var result = new OptionalLong[count * 3];
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var values = stack.callocLong(count * 4);
            int status =
                    vkGetQueryPoolResults(
                            runtime.vkDevice(),
                            pool,
                            first,
                            count,
                            values,
                            32,
                            VK_QUERY_RESULT_64_BIT | VK_QUERY_RESULT_WITH_AVAILABILITY_BIT);
            if (status != VK_SUCCESS && status != VK_NOT_READY)
                VeilVulkanChecks.check(status, "native shader invocation results");
            for (int query = 0; query < count; query++)
                for (int counter = 0; counter < 3; counter++) {
                    result[query * 3 + counter] =
                            values.get(query * 4 + 3) == 0
                                    ? OptionalLong.empty()
                                    : OptionalLong.of(values.get(query * 4 + counter));
                }
        }
        return result;
    }

    @Override
    public void close() {
        long previous = pool;
        if (previous == 0) return;
        retirement.defer(
                action -> runtime.deferDestroy(action::run),
                () -> vkDestroyQueryPool(runtime.vkDevice(), previous, null));
        // An enqueue rejection retains the pool so close() may safely retry.
        if (retirement.closeRequested()) pool = 0;
    }
}
