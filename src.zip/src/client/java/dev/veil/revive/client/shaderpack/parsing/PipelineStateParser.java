package dev.veil.revive.client.shaderpack.parsing;

import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.*;

import com.google.gson.JsonObject;

import dev.veil.api.VeilTransfer;
import dev.veil.revive.client.VeilShaderPack.BlendFactor;
import dev.veil.revive.client.VeilShaderPack.BlendOp;
import dev.veil.revive.client.VeilShaderPack.BlendState;
import dev.veil.revive.client.VeilShaderPack.ClearColor;
import dev.veil.revive.client.VeilShaderPack.ColorAttachment;
import dev.veil.revive.client.VeilShaderPack.ColorChannel;
import dev.veil.revive.client.VeilShaderPack.CompareOp;
import dev.veil.revive.client.VeilShaderPack.CullMode;
import dev.veil.revive.client.VeilShaderPack.DepthAttachment;
import dev.veil.revive.client.VeilShaderPack.FrontFace;
import dev.veil.revive.client.VeilShaderPack.LoadOp;
import dev.veil.revive.client.VeilShaderPack.PipelineState;
import dev.veil.revive.client.VeilShaderPack.PolygonMode;
import dev.veil.revive.client.VeilShaderPack.RasterState;
import dev.veil.revive.client.VeilShaderPack.SampleAddress;
import dev.veil.revive.client.VeilShaderPack.SampleBorder;
import dev.veil.revive.client.VeilShaderPack.SampleFilter;
import dev.veil.revive.client.VeilShaderPack.Sampler;
import dev.veil.revive.client.VeilShaderPack.Setting;
import dev.veil.revive.client.VeilShaderPack.StencilFace;
import dev.veil.revive.client.VeilShaderPack.StencilOp;
import dev.veil.revive.client.VeilShaderPack.StencilState;
import dev.veil.revive.client.VeilShaderPack.StoreOp;
import dev.veil.revive.client.VeilShaderPack.Topology;
import dev.veil.revive.client.graphics.resources.TransferClearRules;

import java.util.Map;

public final class PipelineStateParser {
    private PipelineStateParser() {}

    public static Sampler sampler(JsonObject object) {
        fields(
                object,
                "min",
                "mag",
                "mip",
                "u",
                "v",
                "w",
                "compare",
                "borderColor",
                "minLod",
                "maxLod",
                "lodBias");
        SampleFilter min = sampleFilter(object, "min", SampleFilter.NEAREST);
        SampleFilter mag = sampleFilter(object, "mag", SampleFilter.NEAREST);
        SampleFilter mip = sampleFilter(object, "mip", SampleFilter.NEAREST);
        SampleAddress u = sampleAddress(object, "u", SampleAddress.CLAMP_TO_EDGE);
        SampleAddress v = sampleAddress(object, "v", SampleAddress.CLAMP_TO_EDGE);
        SampleAddress w = sampleAddress(object, "w", SampleAddress.CLAMP_TO_EDGE);
        return new Sampler(
                min,
                mag,
                mip,
                u,
                v,
                w,
                object.has("compare") ? compareOp(object.get("compare").getAsString()) : null,
                object.has("borderColor")
                        ? sampleBorder(object.get("borderColor").getAsString())
                        : SampleBorder.FLOAT_TRANSPARENT_BLACK,
                object.has("minLod") ? object.get("minLod").getAsFloat() : 0.0f,
                object.has("maxLod")
                        ? object.get("maxLod").getAsFloat()
                        : dev.veil.revive.client.graphics.resources.SamplerLodRules.DEFAULT_MAX_LOD,
                object.has("lodBias") ? object.get("lodBias").getAsFloat() : 0.0f);
    }

    public static ColorAttachment colorAttachment(JsonObject object) {
        fields(object, "resource", "mip", "layer", "load", "store", "clear", "blend", "writeMask");
        LoadOp load = loadOp(object, "load", LoadOp.LOAD);
        ClearColor clear = null;
        if (object.has("clear")) {
            var value = object.get("clear");
            if (value.isJsonArray()) {
                var values = value.getAsJsonArray();
                if (values.size() != 4)
                    throw new IllegalArgumentException(
                            "Color attachment clear requires four values");
                clear =
                        new ClearColor(
                                values.get(0).getAsFloat(),
                                values.get(1).getAsFloat(),
                                values.get(2).getAsFloat(),
                                values.get(3).getAsFloat());
            } else if (value.isJsonObject()) {
                JsonObject components = value.getAsJsonObject();
                fields(components, "type", "r", "g", "b", "a");
                String type =
                        components.has("type") ? components.get("type").getAsString() : "float";
                clear =
                        switch (type) {
                            case "float" ->
                                    new ClearColor(
                                            floating(components, "r", 0),
                                                    floating(components, "g", 0),
                                            floating(components, "b", 0),
                                                    floating(components, "a", 0));
                            case "sint", "uint" -> {
                                VeilTransfer.ClearColorType colorType =
                                        type.equals("sint")
                                                ? VeilTransfer.ClearColorType.SINT
                                                : VeilTransfer.ClearColorType.UINT;
                                int r = integerClearChannel(components, "r", colorType);
                                int g = integerClearChannel(components, "g", colorType);
                                int b = integerClearChannel(components, "b", colorType);
                                int a = integerClearChannel(components, "a", colorType);
                                yield colorType == VeilTransfer.ClearColorType.SINT
                                        ? ClearColor.signed(r, g, b, a)
                                        : ClearColor.unsigned(r, g, b, a);
                            }
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported attachment color clear type: " + type);
                        };
            } else {
                throw new IllegalArgumentException(
                        "Attachment clear requires [r,g,b,a] or a typed color object");
            }
        }
        BlendState blend =
                object.has("blend") ? blend(object.getAsJsonObject("blend")) : BlendState.DISABLED;
        String mask =
                object.has("writeMask")
                        ? object.get("writeMask").getAsString().toUpperCase(java.util.Locale.ROOT)
                        : "RGBA";
        var channels = java.util.EnumSet.noneOf(ColorChannel.class);
        for (int i = 0; i < mask.length(); i++) {
            ColorChannel channel = ColorChannel.valueOf(String.valueOf(mask.charAt(i)));
            if (!channels.add(channel))
                throw new IllegalArgumentException(
                        "Duplicate color write-mask channel: " + channel);
        }
        return new ColorAttachment(
                resourceName(object.get("resource").getAsString()),
                integer(object, "mip", 0),
                integer(object, "layer", 0),
                load,
                storeOp(object, "store", StoreOp.STORE),
                clear,
                blend,
                channels);
    }

    private static int integerClearChannel(
            JsonObject object, String component, VeilTransfer.ClearColorType type) {
        return object.has(component)
                ? TransferClearRules.channel(object.get(component).getAsBigDecimal(), type)
                : 0;
    }

    public static PipelineState pipelineState(JsonObject object) {
        return pipelineState(object, Map.of());
    }

    public static PipelineState pipelineState(JsonObject object, Map<String, Setting> settings) {
        object = PipelineSettingInputs.resolve(object, settings);
        fields(object, "topology", "raster", "stencil", "patchControlPoints", "primitiveRestart");
        Topology topology =
                object.has("topology")
                        ? switch (object.get("topology").getAsString()) {
                            case "pointList" -> Topology.POINT_LIST;
                            case "lineList" -> Topology.LINE_LIST;
                            case "lineStrip" -> Topology.LINE_STRIP;
                            case "triangleList" -> Topology.TRIANGLE_LIST;
                            case "triangleStrip" -> Topology.TRIANGLE_STRIP;
                            case "patchList" -> Topology.PATCH_LIST;
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported primitive topology");
                        }
                        : Topology.TRIANGLE_LIST;
        RasterState raster =
                object.has("raster")
                        ? rasterState(object.getAsJsonObject("raster"))
                        : RasterState.DEFAULT;
        StencilState stencil =
                object.has("stencil")
                        ? stencilState(object.getAsJsonObject("stencil"))
                        : StencilState.DISABLED;
        return new PipelineState(
                topology,
                raster,
                stencil,
                integer(object, "patchControlPoints", 3),
                object.has("primitiveRestart") && object.get("primitiveRestart").getAsBoolean());
    }

    private static RasterState rasterState(JsonObject object) {
        fields(
                object,
                "polygonMode",
                "cullMode",
                "frontFace",
                "depthClamp",
                "rasterizerDiscard",
                "depthBias",
                "depthBiasConstant",
                "depthBiasClamp",
                "depthBiasSlope",
                "lineWidth");
        PolygonMode polygon =
                object.has("polygonMode")
                        ? switch (object.get("polygonMode").getAsString()) {
                            case "fill" -> PolygonMode.FILL;
                            case "line" -> PolygonMode.LINE;
                            case "point" -> PolygonMode.POINT;
                            default ->
                                    throw new IllegalArgumentException("Unsupported polygon mode");
                        }
                        : PolygonMode.FILL;
        CullMode cull =
                object.has("cullMode")
                        ? switch (object.get("cullMode").getAsString()) {
                            case "none" -> CullMode.NONE;
                            case "front" -> CullMode.FRONT;
                            case "back" -> CullMode.BACK;
                            case "frontAndBack" -> CullMode.FRONT_AND_BACK;
                            default -> throw new IllegalArgumentException("Unsupported cull mode");
                        }
                        : CullMode.NONE;
        FrontFace front =
                object.has("frontFace")
                        ? switch (object.get("frontFace").getAsString()) {
                            case "counterClockwise" -> FrontFace.COUNTER_CLOCKWISE;
                            case "clockwise" -> FrontFace.CLOCKWISE;
                            default -> throw new IllegalArgumentException("Unsupported front face");
                        }
                        : FrontFace.COUNTER_CLOCKWISE;
        return new RasterState(
                polygon,
                cull,
                front,
                object.has("depthClamp") && object.get("depthClamp").getAsBoolean(),
                object.has("rasterizerDiscard") && object.get("rasterizerDiscard").getAsBoolean(),
                object.has("depthBias") && object.get("depthBias").getAsBoolean(),
                object.has("depthBiasConstant") ? object.get("depthBiasConstant").getAsFloat() : 0,
                object.has("depthBiasClamp") ? object.get("depthBiasClamp").getAsFloat() : 0,
                object.has("depthBiasSlope") ? object.get("depthBiasSlope").getAsFloat() : 0,
                object.has("lineWidth") ? object.get("lineWidth").getAsFloat() : 1);
    }

    private static StencilState stencilState(JsonObject object) {
        fields(object, "enabled", "front", "back");
        boolean enabled = !object.has("enabled") || object.get("enabled").getAsBoolean();
        StencilFace front =
                object.has("front")
                        ? stencilFace(object.getAsJsonObject("front"))
                        : StencilFace.DEFAULT;
        StencilFace back = object.has("back") ? stencilFace(object.getAsJsonObject("back")) : front;
        return new StencilState(enabled, front, back);
    }

    private static StencilFace stencilFace(JsonObject object) {
        fields(
                object,
                "compare",
                "fail",
                "pass",
                "depthFail",
                "compareMask",
                "writeMask",
                "reference");
        return new StencilFace(
                compareOp(object.has("compare") ? object.get("compare").getAsString() : "always"),
                stencilOp(object, "fail"),
                stencilOp(object, "pass"),
                stencilOp(object, "depthFail"),
                integer(object, "compareMask", -1),
                integer(object, "writeMask", -1),
                integer(object, "reference", 0));
    }

    private static StencilOp stencilOp(JsonObject object, String field) {
        if (!object.has(field)) return StencilOp.KEEP;
        return switch (object.get(field).getAsString()) {
            case "keep" -> StencilOp.KEEP;
            case "zero" -> StencilOp.ZERO;
            case "replace" -> StencilOp.REPLACE;
            case "incrementClamp" -> StencilOp.INCREMENT_CLAMP;
            case "decrementClamp" -> StencilOp.DECREMENT_CLAMP;
            case "invert" -> StencilOp.INVERT;
            case "incrementWrap" -> StencilOp.INCREMENT_WRAP;
            case "decrementWrap" -> StencilOp.DECREMENT_WRAP;
            default -> throw new IllegalArgumentException("Unsupported stencil operation");
        };
    }

    public static DepthAttachment depthAttachment(JsonObject object) {
        fields(
                object,
                "resource",
                "mip",
                "layer",
                "load",
                "store",
                "clearDepth",
                "clearStencil",
                "test",
                "write",
                "compare");
        LoadOp load = loadOp(object, "load", LoadOp.LOAD);
        boolean test = !object.has("test") || object.get("test").getAsBoolean();
        return new DepthAttachment(
                resourceName(object.get("resource").getAsString()),
                integer(object, "mip", 0),
                integer(object, "layer", 0),
                load,
                storeOp(object, "store", StoreOp.STORE),
                object.has("clearDepth") ? object.get("clearDepth").getAsFloat() : 1.0f,
                integer(object, "clearStencil", 0),
                test,
                object.has("write") && object.get("write").getAsBoolean(),
                compareOp(object.has("compare") ? object.get("compare").getAsString() : "less"));
    }

    private static BlendState blend(JsonObject object) {
        fields(
                object,
                "enabled",
                "srcColor",
                "dstColor",
                "colorOp",
                "srcAlpha",
                "dstAlpha",
                "alphaOp");
        return new BlendState(
                !object.has("enabled") || object.get("enabled").getAsBoolean(),
                blendFactor(object, "srcColor", BlendFactor.ONE),
                blendFactor(object, "dstColor", BlendFactor.ZERO),
                blendOp(object, "colorOp", BlendOp.ADD),
                blendFactor(object, "srcAlpha", BlendFactor.ONE),
                blendFactor(object, "dstAlpha", BlendFactor.ZERO),
                blendOp(object, "alphaOp", BlendOp.ADD));
    }

    private static LoadOp loadOp(JsonObject object, String field, LoadOp fallback) {
        if (!object.has(field)) return fallback;
        return switch (object.get(field).getAsString()) {
            case "load" -> LoadOp.LOAD;
            case "clear" -> LoadOp.CLEAR;
            case "dontCare" -> LoadOp.DONT_CARE;
            default ->
                    throw new IllegalArgumentException(
                            "Unsupported attachment load operation: " + object.get(field));
        };
    }

    private static StoreOp storeOp(JsonObject object, String field, StoreOp fallback) {
        if (!object.has(field)) return fallback;
        return switch (object.get(field).getAsString()) {
            case "store" -> StoreOp.STORE;
            case "dontCare" -> StoreOp.DONT_CARE;
            default ->
                    throw new IllegalArgumentException(
                            "Unsupported attachment store operation: " + object.get(field));
        };
    }

    private static CompareOp compareOp(String value) {
        return switch (value) {
            case "never" -> CompareOp.NEVER;
            case "less" -> CompareOp.LESS;
            case "equal" -> CompareOp.EQUAL;
            case "lessOrEqual" -> CompareOp.LESS_OR_EQUAL;
            case "greater" -> CompareOp.GREATER;
            case "notEqual" -> CompareOp.NOT_EQUAL;
            case "greaterOrEqual" -> CompareOp.GREATER_OR_EQUAL;
            case "always" -> CompareOp.ALWAYS;
            default ->
                    throw new IllegalArgumentException(
                            "Unsupported depth compare operation: " + value);
        };
    }

    private static BlendFactor blendFactor(JsonObject object, String field, BlendFactor fallback) {
        if (!object.has(field)) return fallback;
        String value = object.get(field).getAsString();
        return switch (value) {
            case "zero" -> BlendFactor.ZERO;
            case "one" -> BlendFactor.ONE;
            case "srcColor" -> BlendFactor.SRC_COLOR;
            case "oneMinusSrcColor" -> BlendFactor.ONE_MINUS_SRC_COLOR;
            case "dstColor" -> BlendFactor.DST_COLOR;
            case "oneMinusDstColor" -> BlendFactor.ONE_MINUS_DST_COLOR;
            case "srcAlpha" -> BlendFactor.SRC_ALPHA;
            case "oneMinusSrcAlpha" -> BlendFactor.ONE_MINUS_SRC_ALPHA;
            case "dstAlpha" -> BlendFactor.DST_ALPHA;
            case "oneMinusDstAlpha" -> BlendFactor.ONE_MINUS_DST_ALPHA;
            default -> throw new IllegalArgumentException("Unsupported blend factor: " + value);
        };
    }

    private static BlendOp blendOp(JsonObject object, String field, BlendOp fallback) {
        if (!object.has(field)) return fallback;
        String value = object.get(field).getAsString();
        return switch (value) {
            case "add" -> BlendOp.ADD;
            case "subtract" -> BlendOp.SUBTRACT;
            case "reverseSubtract" -> BlendOp.REVERSE_SUBTRACT;
            case "min" -> BlendOp.MIN;
            case "max" -> BlendOp.MAX;
            default -> throw new IllegalArgumentException("Unsupported blend operation: " + value);
        };
    }

    private static SampleFilter sampleFilter(
            JsonObject object, String field, SampleFilter fallback) {
        if (!object.has(field)) return fallback;
        return switch (object.get(field).getAsString()) {
            case "nearest" -> SampleFilter.NEAREST;
            case "linear" -> SampleFilter.LINEAR;
            default ->
                    throw new IllegalArgumentException(
                            "Unsupported sampler filter: " + object.get(field).getAsString());
        };
    }

    private static SampleBorder sampleBorder(String value) {
        return switch (value) {
            case "floatTransparentBlack" -> SampleBorder.FLOAT_TRANSPARENT_BLACK;
            case "floatOpaqueBlack" -> SampleBorder.FLOAT_OPAQUE_BLACK;
            case "floatOpaqueWhite" -> SampleBorder.FLOAT_OPAQUE_WHITE;
            case "intTransparentBlack" -> SampleBorder.INT_TRANSPARENT_BLACK;
            case "intOpaqueBlack" -> SampleBorder.INT_OPAQUE_BLACK;
            case "intOpaqueWhite" -> SampleBorder.INT_OPAQUE_WHITE;
            default ->
                    throw new IllegalArgumentException("Unsupported sampler borderColor: " + value);
        };
    }

    private static SampleAddress sampleAddress(
            JsonObject object, String field, SampleAddress fallback) {
        if (!object.has(field)) return fallback;
        return switch (object.get(field).getAsString()) {
            case "clamp_to_edge" -> SampleAddress.CLAMP_TO_EDGE;
            case "repeat" -> SampleAddress.REPEAT;
            case "mirrored_repeat" -> SampleAddress.MIRRORED_REPEAT;
            case "clamp_to_border" -> SampleAddress.CLAMP_TO_BORDER;
            default ->
                    throw new IllegalArgumentException(
                            "Unsupported sampler address mode: " + object.get(field).getAsString());
        };
    }
}
