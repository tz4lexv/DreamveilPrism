package dev.veil.revive.client.shaderpack.reload;

import dev.veil.revive.client.VeilShaderAssets;
import dev.veil.revive.client.VeilShaderId;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class PackSources {
    private PackSources() {}

    public static List<String> available(Path packRoot, VeilShaderId index) throws IOException {
        var names = new java.util.ArrayList<>(bundled(index));
        if (packRoot != null && Files.isDirectory(packRoot)) {
            try (var paths = Files.list(packRoot)) {
                paths.filter(VeilShaderAssets::isExternalPack)
                        .limit(128)
                        .sorted()
                        .forEach(path -> names.add(path.getFileName().toString()));
            }
        }
        return List.copyOf(names);
    }

    public static List<String> bundled(VeilShaderId index) throws IOException {
        var names = new java.util.ArrayList<String>();
        var seen = new java.util.LinkedHashSet<String>();
        VeilShaderAssets assets = VeilShaderAssets.classpath();
        for (String line : assets.text(index).lines().toList()) {
            String name = line.trim();
            if (name.isEmpty()) continue;
            new VeilShaderId(name, "veilpack.json");
            if (!seen.add(name)) throw new IOException("Duplicate bundled pack: " + name);
            assets.read(new VeilShaderId("veil", "shaderpacks/" + name + "/veilpack.json"));
            names.add(name);
        }
        return List.copyOf(names);
    }

    public static String fingerprint(Path path, VeilShaderAssets assets, String namespace)
            throws IOException {
        if (Files.isRegularFile(path)) {
            String stamp = Files.size(path) + ":" + Files.getLastModifiedTime(path).toMillis();
            return VeilShaderAssets.hash(stamp.getBytes(StandardCharsets.UTF_8));
        }
        var fingerprint = new StringBuilder();
        for (String entry : assets.entries(namespace)) {
            var id = new VeilShaderId(namespace, entry);
            fingerprint.append(entry).append('\0');
            if (VeilShaderAssets.isShaderSource(entry)
                    || entry.endsWith(".slangh")
                    || entry.endsWith(".h")
                    || entry.endsWith(".json")
                    || entry.endsWith(".properties")
                    || entry.endsWith(".toml")) {
                fingerprint.append(VeilShaderAssets.hash(assets.read(id)));
            } else {
                Path file = path.resolve(entry);
                fingerprint
                        .append(Files.size(file))
                        .append(':')
                        .append(Files.getLastModifiedTime(file).toMillis());
            }
            fingerprint.append('\n');
        }
        return VeilShaderAssets.hash(fingerprint.toString().getBytes(StandardCharsets.UTF_8));
    }
}
