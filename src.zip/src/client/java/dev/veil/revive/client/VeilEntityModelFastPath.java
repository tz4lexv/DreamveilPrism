package dev.veil.revive.client;

public final class VeilEntityModelFastPath {
    private static volatile boolean enabled;
    private static volatile boolean cubeEnabled;
    private static volatile boolean shadowEnabled;
    private static boolean collectTelemetry;

    private static long calls;
    private static long translations;
    private static long rotations;
    private static long scales;
    private static long identityTransforms;

    private static long cubeCalls;
    private static long cubeFaces;
    private static long cubeVertices;
    private static long cubePositionTransformsAvoided;
    private static long cubeFallbacks;

    private static long shadowSubmits;
    private static long shadowPieces;
    private static long shadowVertices;
    private static long shadowFallbacks;

    private VeilEntityModelFastPath() {}

    public static void beginWorldFrame() {
        boolean optimizations = ReviveRuntime.optimizationsEnabled();
        enabled = optimizations && VeilVideoConfig.flag("renderer.entityModelFastPath", true);
        cubeEnabled = optimizations && VeilVideoConfig.flag("renderer.entityCubeFastPath", true);
        shadowEnabled =
                optimizations && VeilVideoConfig.flag("renderer.entityShadowFastPath", true);
        collectTelemetry =
                (enabled || cubeEnabled || shadowEnabled)
                        && (VeilDiagnostics.benchmarkActive()
                                || ReviveRuntime.config().profilerEnabled());
    }

    public static void endWorldFrame() {
        enabled = false;
        cubeEnabled = false;
        shadowEnabled = false;
        collectTelemetry = false;
    }

    public static boolean enabled() {
        return enabled;
    }

    public static boolean cubeEnabled() {
        return cubeEnabled;
    }

    public static boolean shadowEnabled() {
        return shadowEnabled;
    }

    public static void record(boolean translated, boolean rotated, boolean scaled) {
        if (!collectTelemetry) return;
        calls++;
        if (translated) translations++;
        if (rotated) rotations++;
        if (scaled) scales++;
        if (!translated && !rotated && !scaled) identityTransforms++;
    }

    public static void recordCube(int emittedFaces) {
        if (!collectTelemetry) return;
        cubeCalls++;
        cubeFaces += emittedFaces;
        long vertices = (long) emittedFaces * 4L;
        cubeVertices += vertices;

        cubePositionTransformsAvoided += Math.max(0L, vertices - 8L);
    }

    public static void recordCubeFallback() {
        if (collectTelemetry) cubeFallbacks++;
    }

    public static void recordShadow(int pieces) {
        if (!collectTelemetry) return;
        shadowSubmits++;
        shadowPieces += pieces;
        shadowVertices += (long) pieces * 4L;
    }

    public static void recordShadowFallback() {
        if (collectTelemetry) shadowFallbacks++;
    }

    public static void resetTelemetry() {
        calls = 0L;
        translations = 0L;
        rotations = 0L;
        scales = 0L;
        identityTransforms = 0L;
        cubeCalls = 0L;
        cubeFaces = 0L;
        cubeVertices = 0L;
        cubePositionTransformsAvoided = 0L;
        cubeFallbacks = 0L;
        shadowSubmits = 0L;
        shadowPieces = 0L;
        shadowVertices = 0L;
        shadowFallbacks = 0L;
    }

    public static String telemetryLine() {
        return "entity ModelPart fast transform: calls="
                + calls
                + " translate="
                + translations
                + " rotate="
                + rotations
                + " scale="
                + scales
                + " identity="
                + identityTransforms
                + " | cube fast path: cubes="
                + cubeCalls
                + " faces="
                + cubeFaces
                + " vertices="
                + cubeVertices
                + " positionTransformsAvoided="
                + cubePositionTransformsAvoided
                + " fallbacks="
                + cubeFallbacks
                + " | shadow bulk path: submits="
                + shadowSubmits
                + " pieces="
                + shadowPieces
                + " vertices="
                + shadowVertices
                + " fallbacks="
                + shadowFallbacks;
    }
}
