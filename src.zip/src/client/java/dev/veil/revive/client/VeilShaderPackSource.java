package dev.veil.revive.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;

final class VeilShaderPackSource {
    private static final String MANIFEST = "veilpack.json";
    private static final String PROPERTIES = "veil.properties";
    private static final String PIPELINE = "pipeline.toml";
    private static final String BUILTIN_FULLSCREEN_VERTEX =
            "veil:shaderpacks/example/shaders/fullscreen.vert";
    private static final Pattern LAYOUT_DECLARATION =
            Pattern.compile("layout\\s*\\(([^)]*)\\)\\s*uniform\\s+([^;]+);", Pattern.MULTILINE);
    private static final Pattern SET = Pattern.compile("(?:^|,)\\s*set\\s*=\\s*(\\d+)\\s*(?:,|$)");
    private static final Pattern BINDING =
            Pattern.compile("(?:^|,)\\s*binding\\s*=\\s*(\\d+)\\s*(?:,|$)");

    record Loaded(VeilShaderPack pack, Map<VeilShaderId, String> descriptors, String format) {
        Loaded {
            descriptors = Map.copyOf(descriptors);
        }
    }

    private VeilShaderPackSource() {}

    static Loaded load(
            VeilShaderAssets assets,
            String namespace,
            String selection,
            Map<String, String> overrides)
            throws IOException {
        VeilShaderId manifest = new VeilShaderId(namespace, MANIFEST);
        if (assets.contains(manifest)) {
            byte[] bytes = assets.read(manifest);
            return new Loaded(
                    VeilShaderPack.parse(
                            new String(bytes, StandardCharsets.UTF_8), namespace, overrides),
                    Map.of(manifest, VeilShaderAssets.hash(bytes)),
                    "json");
        }
        VeilShaderId pipeline = new VeilShaderId(namespace, PIPELINE);
        if (assets.contains(pipeline)) {
            byte[] bytes = assets.read(pipeline);
            JsonObject root = VeilToml.parse(new String(bytes, StandardCharsets.UTF_8));
            PropertyFile metadata = properties(assets, namespace);
            if (!root.has("name"))
                root.addProperty(
                        "name", metadata.values().getProperty("name", displayName(selection)));
            if (!root.has("abi"))
                root.addProperty(
                        "abi",
                        integer(metadata.values(), "abi", 11, 1, VeilShaderPack.MAX_ABI_VERSION));
            mergePropertySettings(root, settings(metadata.values()).definitions());
            var descriptors = new LinkedHashMap<VeilShaderId, String>();
            descriptors.put(pipeline, VeilShaderAssets.hash(bytes));
            if (metadata.id() != null)
                descriptors.put(metadata.id(), VeilShaderAssets.hash(metadata.bytes()));
            return new Loaded(
                    VeilShaderPack.parse(root.toString(), namespace, overrides),
                    descriptors,
                    "toml");
        }
        Convention convention = convention(assets, namespace, selection);
        return new Loaded(
                VeilShaderPack.parse(convention.manifest(), namespace, overrides),
                convention.descriptors(),
                "convention");
    }

    static void verifyDescriptor(VeilShaderAssets assets, Loaded loaded) throws IOException {
        for (var descriptor : loaded.descriptors().entrySet()) {
            byte[] current = assets.read(descriptor.getKey());
            if (!descriptor.getValue().equals(VeilShaderAssets.hash(current))) {
                throw new IOException(
                        "Shader pack descriptor changed during compilation: "
                                + descriptor.getKey());
            }
        }
    }

    private static Convention convention(
            VeilShaderAssets assets, String namespace, String selection) throws IOException {
        List<String> entries = assets.entries(namespace);
        PropertyFile propertyFile = properties(assets, namespace);
        Properties properties = propertyFile.values();

        String fragment = first(entries, "shaders/final.frag", "shaders/composite.frag");
        if (fragment == null) {
            throw new IOException(
                    "Convention pack requires shaders/final.frag or shaders/composite.frag");
        }
        String base = fragment.substring(0, fragment.length() - ".frag".length());
        String vertex =
                entries.contains(base + ".vert") ? base + ".vert" : BUILTIN_FULLSCREEN_VERTEX;
        byte[] fragmentBytes = assets.read(new VeilShaderId(namespace, fragment));
        byte[] vertexBytes =
                vertex.startsWith("veil:")
                        ? new byte[0]
                        : assets.read(new VeilShaderId(namespace, vertex));

        Map<Integer, String> bindings = new LinkedHashMap<>();
        collectSceneBindings(new String(vertexBytes, StandardCharsets.UTF_8), bindings);
        collectSceneBindings(new String(fragmentBytes, StandardCharsets.UTF_8), bindings);

        var root = new JsonObject();
        root.addProperty("name", properties.getProperty("name", displayName(selection)));
        root.addProperty("abi", integer(properties, "abi", 11, 1, VeilShaderPack.MAX_ABI_VERSION));

        var resources = new JsonObject();
        if (bindings.containsKey(0)) resources.add("sceneColor", importedImage("scene_color"));
        if (bindings.containsKey(1)) resources.add("sceneDepth", importedImage("scene_depth"));
        var output = new JsonObject();
        output.addProperty("type", "image");
        output.addProperty("format", properties.getProperty("output.format", "RGBA8_UNORM"));
        output.addProperty("scale", 1);
        resources.add("output", output);
        root.add("resources", resources);

        var stages = new JsonObject();
        stages.addProperty("vertex", vertex);
        stages.addProperty("fragment", fragment);
        var programs = new JsonObject();
        programs.add("main", stages);
        root.add("programs", programs);

        Settings settings = settings(properties);
        root.add("settings", settings.definitions());

        var pass = new JsonObject();
        pass.addProperty("name", "final");
        pass.addProperty("type", "graphics");
        pass.addProperty("program", "main");
        pass.addProperty("target", "output");
        var passBindings = new JsonObject();
        bindings.forEach(
                (binding, resource) -> {
                    var value = new JsonObject();
                    value.addProperty("resource", resource);
                    value.addProperty("access", "read");
                    passBindings.add(Integer.toString(binding), value);
                });
        pass.add("bindings", passBindings);
        if (settings.specialization().size() > 0) {
            var specialization = new JsonObject();
            specialization.add("fragment", settings.specialization());
            pass.add("specialization", specialization);
        }
        var passes = new JsonArray();
        passes.add(pass);
        root.add("passes", passes);
        root.addProperty("present", "output");

        Map<VeilShaderId, String> descriptors =
                propertyFile.id() == null
                        ? Map.of()
                        : Map.of(propertyFile.id(), VeilShaderAssets.hash(propertyFile.bytes()));
        return new Convention(root.toString(), descriptors);
    }

    private static PropertyFile properties(VeilShaderAssets assets, String namespace)
            throws IOException {
        var values = new Properties();
        VeilShaderId id = new VeilShaderId(namespace, PROPERTIES);
        if (!assets.contains(id)) return new PropertyFile(values, null, null);
        byte[] bytes = assets.read(id);
        try (var reader = new StringReader(new String(bytes, StandardCharsets.UTF_8))) {
            values.load(reader);
        }
        return new PropertyFile(values, id, bytes);
    }

    private static void collectSceneBindings(String source, Map<Integer, String> bindings)
            throws IOException {
        var declarations = LAYOUT_DECLARATION.matcher(source);
        while (declarations.find()) {
            String type = declarations.group(2);
            if (!type.contains("sampler2D")) continue;
            String layout = declarations.group(1);
            Integer set = value(SET, layout);
            Integer binding = value(BINDING, layout);
            if (binding == null) continue;
            if (set != null && set != 0)
                throw new IOException(
                        "Convention packs support sampled scene inputs in descriptor set 0");
            String resource =
                    switch (binding) {
                        case 0 -> "sceneColor";
                        case 1 -> "sceneDepth";
                        default ->
                                throw new IOException(
                                        "Convention pack binding "
                                                + binding
                                                + " has no standard scene resource; declare an advanced pipeline");
                    };
            String previous = bindings.putIfAbsent(binding, resource);
            if (previous != null && !previous.equals(resource))
                throw new IOException("Conflicting convention binding " + binding);
        }
    }

    private static Settings settings(Properties properties) throws IOException {
        var names = new ArrayList<String>();
        for (String key : properties.stringPropertyNames()) {
            if (!key.startsWith("setting.") || !key.endsWith(".type")) continue;
            names.add(key.substring("setting.".length(), key.length() - ".type".length()));
        }
        names.sort(String::compareTo);
        var definitions = new JsonObject();
        var specialization = new JsonObject();
        var usedIds = new java.util.HashSet<Integer>();
        for (String name : names) {
            if (!name.matches("[A-Za-z_][A-Za-z0-9_]*"))
                throw new IOException("Invalid shader setting name " + name);
            String prefix = "setting." + name + ".";
            String type = required(properties, prefix + "type");
            String defaultValue = required(properties, prefix + "default");
            var definition = new JsonObject();
            definition.addProperty("type", type);
            definition.addProperty("value", defaultValue);
            if (type.equals("enum")) {
                var options = new JsonArray();
                for (String option : required(properties, prefix + "options").split(","))
                    options.add(option.trim());
                definition.add("options", options);
            }
            definitions.add(name, definition);
            if (properties.containsKey(prefix + "constantId")) {
                int constantId = integer(properties, prefix + "constantId", -1, 0, 65535);
                if (!usedIds.add(constantId))
                    throw new IOException("Duplicate specialization constant ID " + constantId);
                specialization.addProperty(Integer.toString(constantId), name);
            }
        }
        return new Settings(definitions, specialization);
    }

    private static void mergePropertySettings(JsonObject root, JsonObject propertySettings)
            throws IOException {
        JsonObject target;
        if (!root.has("settings")) {
            target = new JsonObject();
            root.add("settings", target);
        } else if (root.get("settings").isJsonObject()) {
            target = root.getAsJsonObject("settings");
        } else {
            throw new IOException("pipeline.toml settings must be a table");
        }
        for (var setting : propertySettings.entrySet()) {
            if (target.has(setting.getKey())) {
                throw new IOException(
                        "Shader setting is declared in both pipeline.toml and veil.properties: "
                                + setting.getKey());
            }
            target.add(setting.getKey(), setting.getValue());
        }
    }

    private static JsonObject importedImage(String source) {
        var image = new JsonObject();
        image.addProperty("type", "image");
        image.addProperty("source", source);
        return image;
    }

    private static Integer value(Pattern pattern, String input) {
        var matcher = pattern.matcher(input);
        return matcher.find() ? Integer.parseInt(matcher.group(1)) : null;
    }

    private static String first(List<String> entries, String... candidates) {
        for (String candidate : candidates) if (entries.contains(candidate)) return candidate;
        return null;
    }

    private static int integer(
            Properties properties, String key, int fallback, int minimum, int maximum)
            throws IOException {
        String raw = properties.getProperty(key);
        if (raw == null) {
            if (fallback < minimum) throw new IOException("Missing required property " + key);
            return fallback;
        }
        try {
            int value = Integer.parseInt(raw.trim());
            if (value < minimum || value > maximum)
                throw new IOException(
                        "Property " + key + " must be within " + minimum + ".." + maximum);
            return value;
        } catch (NumberFormatException invalid) {
            throw new IOException("Property " + key + " is not an integer", invalid);
        }
    }

    private static String required(Properties properties, String key) throws IOException {
        String value = properties.getProperty(key);
        if (value == null || value.isBlank())
            throw new IOException("Missing required property " + key);
        return value.trim();
    }

    private static String displayName(String selection) {
        String name = selection.replace('\\', '/');
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (name.toLowerCase(Locale.ROOT).endsWith(".zip"))
            name = name.substring(0, name.length() - 4);
        return name.isBlank() ? "Veil shader pack" : name;
    }

    private record Convention(String manifest, Map<VeilShaderId, String> descriptors) {}

    private record PropertyFile(Properties values, VeilShaderId id, byte[] bytes) {}

    private record Settings(JsonObject definitions, JsonObject specialization) {}
}
