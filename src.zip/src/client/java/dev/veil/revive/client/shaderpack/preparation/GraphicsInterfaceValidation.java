package dev.veil.revive.client.shaderpack.preparation;

import static org.lwjgl.vulkan.VK10.VK_SHADER_STAGE_FRAGMENT_BIT;
import static org.lwjgl.vulkan.VK10.VK_SHADER_STAGE_VERTEX_BIT;

import dev.veil.api.VeilVertexLayout;
import dev.veil.revive.client.VeilShaderInterface;
import dev.veil.revive.client.VeilShaderStage;

import java.util.Set;

public final class GraphicsInterfaceValidation {
    private GraphicsInterfaceValidation() {}

    public static void validateFluidGeometry(VeilShaderInterface shader, int colorAttachments) {
        validateFluidGeometry(
                shader, colorAttachments, Set.of(VeilShaderStage.VERTEX, VeilShaderStage.FRAGMENT));
    }

    public static void validateFluidGeometry(
            VeilShaderInterface shader, int colorAttachments, Set<VeilShaderStage> stages) {
        shader.validateGraphicsStages(stages);
        var inputs =
                shader.stageInputs().stream()
                        .filter(input -> input.stageFlags() == VK_SHADER_STAGE_VERTEX_BIT)
                        .sorted(
                                java.util.Comparator.comparingInt(
                                        VeilShaderInterface.StageIo::location))
                        .toList();
        if (inputs.size() != 2)
            throw new IllegalArgumentException("Fluid Geometry ABI requires two vertex attributes");
        var p = inputs.get(0);
        if (p.location() != 0
                || p.component() != 0
                || p.baseType() != org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_FP32
                || p.bitWidth() != 32
                || p.vectorSize() != 3
                || p.columns() != 1
                || p.arrayElements() != 1) {
            throw new IllegalArgumentException(
                    "Fluid Geometry ABI location 0 must be float32 vec3 localPosition: " + p);
        }
        var o = inputs.get(1);
        if (o.location() != 1
                || o.component() != 0
                || o.baseType() != org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_INT32
                || o.bitWidth() != 32
                || o.vectorSize() != 4
                || o.columns() != 1
                || o.arrayElements() != 1) {
            throw new IllegalArgumentException(
                    "Fluid Geometry ABI location 1 must be int32 ivec4 sectionOrigin_materialId: "
                            + o);
        }
        validateFragmentOutputs(shader, colorAttachments);
    }

    public static void validateFullscreen(VeilShaderInterface shader) {
        validateFullscreen(shader, 1);
    }

    public static void validateFullscreen(VeilShaderInterface shader, int colorAttachments) {
        validateFullscreen(
                shader, colorAttachments, Set.of(VeilShaderStage.VERTEX, VeilShaderStage.FRAGMENT));
    }

    public static void validateFullscreen(
            VeilShaderInterface shader, int colorAttachments, Set<VeilShaderStage> stages) {
        shader.validateGraphicsStages(stages);
        if (shader.stageInputs().stream()
                .anyMatch(input -> input.stageFlags() == VK_SHADER_STAGE_VERTEX_BIT)) {
            throw new IllegalArgumentException(
                    "Fullscreen graphics requires a vertex shader without vertex attributes");
        }
        validateFragmentOutputs(shader, colorAttachments);
    }

    public static void validateVertexLayout(
            VeilVertexLayout layout, VeilShaderInterface shader, int colorAttachments) {
        validateVertexLayout(
                layout,
                shader,
                colorAttachments,
                Set.of(VeilShaderStage.VERTEX, VeilShaderStage.FRAGMENT));
    }

    public static void validateVertexLayout(
            VeilVertexLayout layout,
            VeilShaderInterface shader,
            int colorAttachments,
            Set<VeilShaderStage> stages) {
        shader.validateGraphicsStages(stages);
        var reflected =
                shader.stageInputs().stream()
                        .filter(input -> input.stageFlags() == VK_SHADER_STAGE_VERTEX_BIT)
                        .toList();
        if (reflected.size() != layout.attributes().size()) {
            throw new IllegalArgumentException(
                    "Vertex layout attribute count does not match reflected vertex inputs; layout="
                            + layout.attributes().size()
                            + " shader="
                            + reflected.size());
        }
        for (var attribute : layout.attributes()) {
            var input =
                    reflected.stream()
                            .filter(value -> value.location() == attribute.location())
                            .findFirst()
                            .orElseThrow(
                                    () ->
                                            new IllegalArgumentException(
                                                    "Vertex shader input is missing for layout location="
                                                            + attribute.location()));
            int expectedType =
                    switch (attribute.format().numericType()) {
                        case UINT -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_UINT32;
                        case SINT -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_INT32;
                        case FLOAT, UNORM, SNORM -> org.lwjgl.util.spvc.Spvc.SPVC_BASETYPE_FP32;
                        default ->
                                throw new IllegalArgumentException(
                                        "Unsupported vertex numeric class: " + attribute.format());
                    };
            if (input.component() != 0
                    || input.baseType() != expectedType
                    || input.bitWidth() != 32
                    || input.vectorSize() != attribute.format().channels()
                    || input.columns() != 1
                    || input.arrayElements() != 1) {
                throw new IllegalArgumentException(
                        "Vertex layout location="
                                + attribute.location()
                                + " format="
                                + attribute.format()
                                + " is incompatible with reflected input "
                                + input);
            }
        }
        for (var input : reflected) {
            if (layout.attributes().stream()
                    .noneMatch(attribute -> attribute.location() == input.location())) {
                throw new IllegalArgumentException(
                        "Vertex layout is missing shader input location=" + input.location());
            }
        }
        validateFragmentOutputs(shader, colorAttachments);
    }

    private static void validateFragmentOutputs(VeilShaderInterface shader, int colorAttachments) {
        var outputs =
                shader.stageOutputs().stream()
                        .filter(output -> output.stageFlags() == VK_SHADER_STAGE_FRAGMENT_BIT)
                        .toList();
        var locations = new java.util.HashSet<Integer>();
        for (var output : outputs) {
            if (output.location() < 0 || output.location() >= colorAttachments) {
                throw new IllegalArgumentException(
                        "Fragment output location="
                                + output.location()
                                + " has no corresponding color attachment; count="
                                + colorAttachments);
            }
            if (!locations.add(output.location())
                    || output.component() != 0
                    || output.bitWidth() != 32
                    || output.columns() != 1
                    || output.arrayElements() != 1
                    || output.vectorSize() < 1
                    || output.vectorSize() > 4) {
                throw new IllegalArgumentException(
                        "Unsupported fragment output declaration: " + output);
            }
        }
    }
}
