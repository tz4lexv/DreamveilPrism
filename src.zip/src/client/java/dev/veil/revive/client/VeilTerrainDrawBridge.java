package dev.veil.revive.client;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.DeviceType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.terrain.capture.PacketSignature;
import dev.veil.revive.core.EpochComponentCache;
import dev.veil.revive.core.TerrainBridgeCounters;
import dev.veil.revive.core.terrain.RegionBindingKey;
import dev.veil.revive.core.terrain.StableIdentitySlots;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.DynamicUniforms;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.ChunkSectionsToRender;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.data.AtlasIds;
import net.minecraft.util.Util;

import org.joml.Matrix4fc;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.List;

public final class VeilTerrainDrawBridge {
    private static final TerrainBridgeCounters COUNTERS = new TerrainBridgeCounters();
    private static final FrameCache CACHE = new FrameCache();
    private static final Validation FAST_VALIDATION = new Validation(true, 0, CacheMissReason.NONE);
    private static final ChunkSectionLayer[] LAYERS = ChunkSectionLayer.values();
    private static final VeilSharedSectionUniforms UNIFORMS = new VeilSharedSectionUniforms();
    private static final VeilTerrainFrameRing TERRAIN_FRAMES = new VeilTerrainFrameRing();
    private static final EpochComponentCache<
                    SectionMesh, SectionRenderDispatcher.RenderSectionBufferSlice>
            SLICES = new EpochComponentCache<>(LAYERS.length, 32768);
    private static final boolean VERIFY_SLICES =
            dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.verifySlices");
    private static final long SLICE_VERIFICATION_LIMIT =
            Math.clamp(
                    Long.getLong("veil.sliceVerificationLimit", 100_000L),
                    100_000L,
                    Integer.MAX_VALUE);
    private static final boolean STABLE_PACKETS =
            !"false".equalsIgnoreCase(System.getProperty("veil.stableSectionPackets"));
    private static final boolean REGIONAL_PACKETS =
            STABLE_PACKETS && Boolean.getBoolean("veil.regionalTerrainPackets");
    private static final boolean RESIDENT_COMMANDS =
            STABLE_PACKETS && Boolean.getBoolean("veil.residentTerrainCommands");
    private static final ResidentGroups RESIDENT_GROUPS = new ResidentGroups();
    private static final boolean RETAINED_SLOTS =
            STABLE_PACKETS
                    && (RESIDENT_COMMANDS || Boolean.getBoolean("veil.retainedTerrainSlots"));
    private static final StableIdentitySlots<SectionRenderDispatcher.RenderSection> SECTION_SLOTS =
            new StableIdentitySlots<>();
    private static final EpochComponentCache<SectionMesh, CachedPacket> PACKETS =
            new EpochComponentCache<>(LAYERS.length, 32768);
    private static final GroupKeyAllocator STABLE_GROUP_KEYS = new GroupKeyAllocator();
    private static long packetBuilds, packetReuses, groupReuses;
    private static boolean regionalLogged;
    private static final boolean VERIFY_PACKETS =
            dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.verifyStablePackets");
    private static long verifiedPackets;
    private static long verifiedResidentPackets;
    private static long unrelatedRevisionReuses;
    private static long keyedAddressWalksAvoided;
    private static final boolean INCREMENTAL_VALIDATION =
            !"false".equalsIgnoreCase(System.getProperty("veil.incrementalTopologyValidation"));
    private static final boolean KEYED_ALLOCATIONS = Boolean.getBoolean("veil.keyedAllocations");
    private static long sliceRevision = Long.MIN_VALUE;
    private static final long IDENTITY_AUDIT_INTERVAL_NS = 2_000_000_000L;
    private static long verifiedSlices;
    private static long fastTopologyHits;
    private static long fastTopologyMisses;
    private static long fastSectionChecks;
    private static long revisionFastHits;
    private static long revisionRevalidations;
    private static long periodicIdentityAudits;
    private static long revisionSelfHeals;
    private static long relocationRevisionForces;
    private static long relocationSelfHeals;
    private static volatile boolean pathActive;
    private static boolean warned;

    private VeilTerrainDrawBridge() {}

    public static void shaderPackBypassFrame() {
        VeilShaderPackBridge.recordTerrainBridgeFastSkip();
        pathActive = false;
    }

    public static @Nullable ChunkSectionsToRender prepare(
            Minecraft minecraft,
            List<SectionRenderDispatcher.RenderSection> visibleSections,
            @Nullable SectionRenderDispatcher dispatcher,
            Matrix4fc modelViewMatrix) {

        VeilTechniqueCounters.terrainPrepareCall();
        VeilTechniqueCounters.terrainVisibleSectionsObserved(visibleSections.size());
        boolean timing =
                VeilDiagnostics.benchmarkActive()
                        || ReviveRuntime.config().profilerEnabled()
                        || VeilCameraSweepProbe.enabled();
        long prepareStartNs = timing ? System.nanoTime() : 0L;

        try {
            VeilProgressiveMeshing.tick(visibleSections);
            VeilRegularPackedLifecycleProbe.tick(minecraft, visibleSections);
            VeilCompilerCancellationProbe.tick(minecraft, visibleSections);
            VeilOriginalAttributeWork.tick(minecraft, visibleSections);
            VeilPairedTerrainLifecycleProbe.tick(minecraft, visibleSections);
            VeilParametricTerrainLifecycleProbe.tick(minecraft, visibleSections);
            VeilTransparencyLifecycleProbe.tick(minecraft, visibleSections);

            if (VeilShaderPackBridge.shaderPackActive()) {
                shaderPackBypassFrame();
                return null;
            }
            if (!ReviveRuntime.optimizationsEnabled()) {
                VeilTechniqueCounters.terrainBypassSkip();
                VeilFallbackTracker.record(VeilFallbackTracker.Reason.BYPASSED);
                return null;
            }
            if (!ReviveRuntime.config().staticDrawPacketCache()) {
                VeilTechniqueCounters.terrainCacheDisabledSkip();
                pathActive = false;
                return null;
            }
            if (dispatcher == null) {
                VeilTechniqueCounters.terrainNoDispatcherSkip();
                VeilFallbackTracker.record(VeilFallbackTracker.Reason.TERRAIN_NO_DISPATCHER);
                pathActive = false;
                return null;
            }

            List<SectionRenderDispatcher.RenderSection> drawSections =
                    VeilSectionResidencyGuard.filterReady(visibleSections);

            try {
                GpuTextureView blockAtlas =
                        minecraft
                                .getAtlasManager()
                                .getAtlasOrThrow(AtlasIds.BLOCKS)
                                .getTextureView();
                int atlasWidth = blockAtlas.getWidth(0);
                int atlasHeight = blockAtlas.getHeight(0);

                var publicationTrace = VeilTerrainPrepareJfrProbe.begin();
                dispatcher.lock();
                try {
                    if (publicationTrace != null) publicationTrace.acquired();

                    long uploadStartNs = timing ? System.nanoTime() : 0L;
                    dispatcher.uploadTerrainBuffersToGpu();

                    long allocationEpoch = VeilAllocationEpoch.current();
                    beginSlices(dispatcher, allocationEpoch);
                    if (publicationTrace != null) publicationTrace.uploadsComplete();
                    if (timing)
                        VeilTechniqueCounters.terrainUploadNanos(System.nanoTime() - uploadStartNs);

                    long validateStartNs = timing ? System.nanoTime() : 0L;
                    boolean fastTopologyMatch =
                            CACHE.fastMatches(dispatcher, drawSections, allocationEpoch);
                    Validation validation;
                    if (fastTopologyMatch) {

                        validation = FAST_VALIDATION;
                    } else if (STABLE_PACKETS
                            || CACHE.dispatcher != dispatcher
                            || CACHE.drawGroups == null
                            || CACHE.topology.size() != drawSections.size()
                            || CACHE.hostOriginRevision != VeilHostRevisions.origin()) {
                        validation =
                                new Validation(
                                        false,
                                        0,
                                        CACHE.dispatcher == null
                                                ? CacheMissReason.EMPTY
                                                : CACHE.dispatcher != dispatcher
                                                        ? CacheMissReason.DISPATCHER
                                                        : CacheMissReason.SIGNATURE);
                    } else {
                        validation = validateTopology(drawSections, dispatcher);
                        VeilTechniqueCounters.terrainSectionsScanned(drawSections.size());
                        VeilTechniqueCounters.terrainDrawPacketsValidated(validation.packetCount);
                    }
                    if (publicationTrace != null) publicationTrace.validationComplete();
                    if (timing)
                        VeilTechniqueCounters.terrainValidateNanos(
                                System.nanoTime() - validateStartNs);

                    EnumMap<
                                    ChunkSectionLayer,
                                    Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                            groups;
                    int maxIndices;

                    if (validation.cacheMatches) {
                        if (!fastTopologyMatch)
                            CACHE.refreshFastState(drawSections, allocationEpoch);
                        groups = CACHE.drawGroups;
                        maxIndices = CACHE.maxIndices;
                        if (VeilTechniqueCounters.collecting()) COUNTERS.cacheHit();
                        VeilTechniqueCounters.terrainCacheReuse();
                    } else {
                        recordCacheMissReason(validation.missReason);
                        long rebuildStartNs = timing ? System.nanoTime() : 0L;
                        BuildResult rebuilt = rebuildStaticGroups(drawSections, dispatcher);
                        if (timing)
                            VeilTechniqueCounters.terrainRebuildNanos(
                                    System.nanoTime() - rebuildStartNs);
                        CACHE.install(dispatcher, drawSections, allocationEpoch, rebuilt);
                        groups = rebuilt.drawGroups;
                        maxIndices = rebuilt.maxIndices;
                        if (VeilTechniqueCounters.collecting()) COUNTERS.cacheMiss();
                        VeilTechniqueCounters.terrainCacheRebuild();
                        VeilTechniqueCounters.terrainDrawPacketsRebuilt(rebuilt.packetCount);
                        VeilTechniqueCounters.terrainGroupsBuilt(rebuilt.groupCount);
                    }

                    if (publicationTrace != null) publicationTrace.cacheComplete();
                    if (VeilVideoConfig.on("animation.visibleOnly"))
                        CACHE.markAnimatedSpritesActive();
                    if (publicationTrace != null) publicationTrace.animationComplete();

                    boolean nativeHostSinglePass = VeilIndirectTerrain.beginPrepare(groups);
                    pathActive = true;
                    VeilTechniqueCounters.terrainPrepareSuccess();
                    if (nativeHostSinglePass) {
                        GpuBufferSlice[] hostUniforms =
                                buildHostUniformsDirect(modelViewMatrix, atlasWidth, atlasHeight);
                        var result =
                                new ChunkSectionsToRender(
                                        blockAtlas, groups, maxIndices, hostUniforms);
                        VeilIndirectTerrain.prepareNativeHost(result);
                        return result;
                    }

                    VeilTerrainFrameData sectionFrame =
                            buildTerrainFrameData(modelViewMatrix, atlasWidth, atlasHeight);
                    var result =
                            new ChunkSectionsToRender(
                                    blockAtlas, groups, maxIndices, new GpuBufferSlice[0]);
                    ((VeilChunkSectionsExtras) (Object) result)
                            .veil$setFallbackSectionFrame(sectionFrame);
                    var submissionGroups =
                            RESIDENT_COMMANDS
                                    ? RESIDENT_GROUPS.update(groups, dispatcher, allocationEpoch)
                                    : groups;
                    VeilIndirectTerrain.prepare(
                            result,
                            sectionFrame,
                            submissionGroups,
                            RESIDENT_COMMANDS ? RESIDENT_GROUPS.maxIndices : maxIndices);
                    return result;
                } finally {
                    if (publicationTrace != null) publicationTrace.beforeUnlock();
                    dispatcher.unlock();
                    if (publicationTrace != null) publicationTrace.afterUnlock();
                }
            } catch (Throwable t) {
                if (VeilTechniqueCounters.collecting()) COUNTERS.fallback();
                VeilTechniqueCounters.terrainBridgeFallback();
                VeilFallbackTracker.record(VeilFallbackTracker.Reason.TERRAIN_BRIDGE_EXCEPTION);
                pathActive = false;
                if (!warned) {
                    warned = true;
                    ReviveMod.LOGGER.warn(
                            "Veil terrain draw bridge failed once; falling back to Minecraft's original prepareChunkRenders path",
                            t);
                }
                invalidateAll();
                return null;
            }
        } finally {
            if (timing)
                VeilTechniqueCounters.terrainPrepareNanos(System.nanoTime() - prepareStartNs);
        }
    }

    public static GpuBufferSlice[] materializeFallbackUniforms(VeilTerrainFrameData frameData) {
        boolean timing =
                VeilDiagnostics.benchmarkActive() || ReviveRuntime.config().profilerEnabled();
        long startNs = timing ? System.nanoTime() : 0L;
        DynamicUniforms.ChunkSectionInfo[] infos = frameData.materializeFallbackInfos(UNIFORMS);
        GpuBufferSlice[] slices = RenderSystem.getDynamicUniforms().writeChunkSections(infos);
        if (timing) VeilTechniqueCounters.terrainUboWriteNanos(System.nanoTime() - startNs);
        VeilTechniqueCounters.terrainDynamicUbosWritten(infos.length);
        return slices;
    }

    public static void invalidateAll() {
        VeilAsyncTerrainSelection.invalidate();
        VeilTechniqueCounters.terrainCacheInvalidation();
        CACHE.clear();
        UNIFORMS.clear();
        TERRAIN_FRAMES.clear();
        SLICES.clear();
        sliceRevision = Long.MIN_VALUE;
        PACKETS.clear();
        SECTION_SLOTS.clear();
        RESIDENT_GROUPS.clear();
        STABLE_GROUP_KEYS.clear();
        pathActive = false;
    }

    public static TerrainBridgeCounters.Snapshot counters() {
        return COUNTERS.snapshot();
    }

    static void requireIncrementalOwnerVerification() {
        if (RESIDENT_COMMANDS
                && VERIFY_PACKETS
                && RESIDENT_GROUPS.incrementalOwners
                && RESIDENT_GROUPS.incrementalOwnerVerified == 0)
            throw new IllegalStateException(
                    "Incremental owner probe never reused a previous frame");
    }

    public static void resetCounters() {
        COUNTERS.reset();
        fastTopologyHits = 0L;
        fastTopologyMisses = 0L;
        fastSectionChecks = 0L;
        revisionFastHits = 0L;
        revisionRevalidations = 0L;
        periodicIdentityAudits = 0L;
        revisionSelfHeals = 0L;
        relocationRevisionForces = 0L;
        relocationSelfHeals = 0L;
        TERRAIN_FRAMES.resetTelemetry();
        VeilLodArena.resetSelectionTelemetry();
        VeilAutoLodGpuAutotune.resetTelemetry();
        VeilSectionVisibilityIndex.resetTelemetry();
        VeilEntityModelFastPath.resetTelemetry();
    }

    public static boolean pathActive() {
        return pathActive;
    }

    public static VeilSharedSectionUniforms.Snapshot sharedWork() {
        return UNIFORMS.snapshot();
    }

    public static long sliceCacheHits() {
        return SLICES.hits();
    }

    public static long sliceCacheMisses() {
        return SLICES.misses();
    }

    public static long verifiedSlices() {
        return verifiedSlices;
    }

    public static long fastTopologyHits() {
        return fastTopologyHits;
    }

    public static long fastTopologyMisses() {
        return fastTopologyMisses;
    }

    public static long fastSectionChecks() {
        return fastSectionChecks;
    }

    public static long revisionFastHits() {
        return revisionFastHits;
    }

    public static long revisionRevalidations() {
        return revisionRevalidations;
    }

    public static long periodicIdentityAudits() {
        return periodicIdentityAudits;
    }

    public static long revisionSelfHeals() {
        return revisionSelfHeals;
    }

    public static long relocationRevisionForces() {
        return relocationRevisionForces;
    }

    public static long relocationSelfHeals() {
        return relocationSelfHeals;
    }

    public static String terrainFrameTelemetry() {
        return TERRAIN_FRAMES.telemetry()
                + stablePacketTelemetry()
                + VeilAsyncTerrainSelection.telemetry();
    }

    public static boolean isSectionVisible(BlockPos origin) {
        if (origin == null) return false;
        long key = SectionPos.asLong(origin.getX() >> 4, origin.getY() >> 4, origin.getZ() >> 4);
        long[] keys = CACHE.visibleSectionKeys;
        return java.util.Arrays.binarySearch(keys, key) >= 0;
    }

    private static SectionRenderDispatcher.RenderSectionBufferSlice slice(
            SectionMesh mesh, ChunkSectionLayer layer, SectionRenderDispatcher dispatcher) {
        int component = layer.ordinal();
        var entry = SLICES.lookup(mesh, component);
        if (entry != null) {
            var cached = entry.value(component);
            if (VERIFY_SLICES && verifiedSlices < SLICE_VERIFICATION_LIMIT) {
                var actual = dispatcher.getRenderSectionSlice(mesh, layer);
                if (!java.util.Objects.equals(cached, actual))
                    throw new IllegalStateException("Cached terrain address differs from host");
                if (++verifiedSlices == SLICE_VERIFICATION_LIMIT)
                    ReviveMod.LOGGER.info(
                            "Veil slice verification PASS: {} cached addresses match host; verification overhead now disabled",
                            SLICE_VERIFICATION_LIMIT);
            }
            return cached;
        }
        var result = dispatcher.getRenderSectionSlice(mesh, layer);
        SLICES.put(mesh, component, result);
        return result;
    }

    private static GpuBufferSlice[] buildHostUniformsDirect(
            Matrix4fc modelViewMatrix, int atlasWidth, int atlasHeight) {
        boolean timing = VeilTechniqueCounters.collecting();
        long startNs = timing ? System.nanoTime() : 0L;
        UNIFORMS.begin(modelViewMatrix);
        long now = Util.getMillis();
        for (int i = 0; i < CACHE.uboSectionIndices.length; i++) {
            int sectionIndex = CACHE.uboSectionIndices[i];
            if (sectionIndex < 0) {
                UNIFORMS.add(0, 0, 0, 0.0f, atlasWidth, atlasHeight);
                continue;
            }
            SectionRenderDispatcher.RenderSection section = CACHE.topology.sections()[sectionIndex];

            BlockPos liveOrigin = section.getRenderOrigin();
            UNIFORMS.add(
                    liveOrigin.getX(),
                    liveOrigin.getY(),
                    liveOrigin.getZ(),
                    section.getVisibility(now),
                    atlasWidth,
                    atlasHeight);
        }
        DynamicUniforms.ChunkSectionInfo[] infos = UNIFORMS.finish();
        GpuBufferSlice[] slices = RenderSystem.getDynamicUniforms().writeChunkSections(infos);
        if (timing) {
            VeilTechniqueCounters.terrainUboWriteNanos(System.nanoTime() - startNs);
            VeilTechniqueCounters.terrainDynamicUbosWritten(infos.length);
        }
        return slices;
    }

    private static VeilTerrainFrameData buildTerrainFrameData(
            Matrix4fc modelViewMatrix, int atlasWidth, int atlasHeight) {
        return TERRAIN_FRAMES.capture(
                modelViewMatrix,
                atlasWidth,
                atlasHeight,
                CACHE.topology.sections(),
                CACHE.uboSectionIndices);
    }

    private static Validation validateTopology(
            List<SectionRenderDispatcher.RenderSection> visibleSections,
            SectionRenderDispatcher dispatcher) {

        int packetOrdinal = 0;
        int nextUboIndex = 0;
        CacheMissReason missReason;
        boolean matches;
        if (CACHE.dispatcher == null) {
            matches = false;
            missReason = CacheMissReason.EMPTY;
        } else if (CACHE.dispatcher != dispatcher) {
            matches = false;
            missReason = CacheMissReason.DISPATCHER;
        } else {
            matches = true;
            missReason = CacheMissReason.NONE;
        }

        for (int sectionIndex = 0; sectionIndex < visibleSections.size(); sectionIndex++) {
            SectionRenderDispatcher.RenderSection section = visibleSections.get(sectionIndex);
            SectionMesh mesh = section.getSectionMesh();
            int uboIndex = -1;

            for (ChunkSectionLayer layer : LAYERS) {
                SectionMesh.SectionDraw draw = mesh.getSectionDraw(layer);
                if (draw == null) continue;
                SectionRenderDispatcher.RenderSectionBufferSlice slice =
                        slice(mesh, layer, dispatcher);

                if (!isDrawable(draw, slice)) continue;
                if (uboIndex < 0) uboIndex = nextUboIndex++;

                if (matches) {
                    if (packetOrdinal >= CACHE.signatures.size()) {
                        return new Validation(false, packetOrdinal, CacheMissReason.PACKET_COUNT);
                    } else if (!CACHE.signatures
                            .get(packetOrdinal)
                            .matches(mesh, layer, draw, slice, uboIndex)) {
                        return new Validation(false, packetOrdinal, CacheMissReason.SIGNATURE);
                    }
                }
                packetOrdinal++;
            }
        }

        if (packetOrdinal != CACHE.signatures.size()) {
            matches = false;
            if (missReason == CacheMissReason.NONE) missReason = CacheMissReason.PACKET_COUNT;
        }
        return new Validation(matches, packetOrdinal, missReason);
    }

    private static BuildResult rebuildStaticGroups(
            List<SectionRenderDispatcher.RenderSection> visibleSections,
            SectionRenderDispatcher dispatcher) {

        EnumMap<ChunkSectionLayer, Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                groups = new EnumMap<>(ChunkSectionLayer.class);
        for (ChunkSectionLayer layer : LAYERS) {
            groups.put(layer, new Int2ObjectOpenHashMap<>());
        }

        List<PacketSignature> signatures = new ArrayList<>();
        if (STABLE_PACKETS && CACHE.dispatcher != dispatcher) {
            SECTION_SLOTS.clear();
            RESIDENT_GROUPS.clear();
            STABLE_GROUP_KEYS.clear();
        }
        PACKETS.begin(dispatcher, 0L);
        int[] stableSources =
                STABLE_PACKETS
                        ? RETAINED_SLOTS
                                ? SECTION_SLOTS.reconcile(visibleSections, 8192, 32)
                                : SECTION_SLOTS.reconcile(visibleSections)
                        : null;
        GroupKeyAllocator groupKeys = STABLE_PACKETS ? STABLE_GROUP_KEYS : new GroupKeyAllocator();
        int maxIndices = 0;
        int packetCount = 0;
        int uboIndex = 0;
        int[] uboSectionIndices = new int[visibleSections.size()];
        boolean hostOrdering =
                RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED
                        || !VeilVideoConfig.on("renderer.mdi");
        double[] distances =
                hostOrdering
                        ? new double[STABLE_PACKETS ? stableSources.length : visibleSections.size()]
                        : null;
        var camera =
                hostOrdering ? Minecraft.getInstance().gameRenderer.mainCamera().position() : null;

        boolean slotOrdering = STABLE_PACKETS && !hostOrdering;
        int sourceCount = slotOrdering ? stableSources.length : visibleSections.size();
        for (int sourceOrdinal = 0; sourceOrdinal < sourceCount; sourceOrdinal++) {
            int sectionIndex = slotOrdering ? stableSources[sourceOrdinal] : sourceOrdinal;
            if (sectionIndex < 0) continue;
            SectionRenderDispatcher.RenderSection section = visibleSections.get(sectionIndex);
            SectionMesh mesh = section.getSectionMesh();
            boolean sectionHasDraw = false;
            long region =
                    VeilTerrainRegions.key(
                            section.getSectionNode(), REGIONAL_PACKETS && slotOrdering);

            for (ChunkSectionLayer layer : LAYERS) {
                SectionMesh.SectionDraw draw = mesh.getSectionDraw(layer);
                if (draw == null) continue;
                SectionRenderDispatcher.RenderSectionBufferSlice slice =
                        slice(mesh, layer, dispatcher);

                if (!isDrawable(draw, slice)) continue;
                sectionHasDraw = true;

                VertexFormat vertexFormat = layer.vertexFormat();
                GpuBuffer vertexBuffer = slice.vertexBuffer();

                GpuBuffer indexBuffer = null;
                IndexType indexType = null;
                int firstIndex = 0;

                if (draw.hasCustomIndexBuffer()) {
                    indexBuffer = slice.indexBuffer();
                    indexType = draw.indexType();
                    firstIndex = (int) (slice.indexBufferOffset() / indexType.bytes);
                } else {
                    maxIndices = Math.max(maxIndices, draw.indexCount());
                }

                int capturedUboIndex = STABLE_PACKETS ? SECTION_SLOTS.indexOf(section) : uboIndex;
                int baseVertex = (int) (slice.vertexBufferOffset() / vertexFormat.getVertexSize());

                CachedPacket cached = null;
                if (STABLE_PACKETS) {
                    var entry = PACKETS.lookup(mesh, layer.ordinal());
                    if (entry != null) cached = entry.value(layer.ordinal());
                }
                boolean reuse =
                        cached != null
                                && cached.region
                                        == (layer == ChunkSectionLayer.TRANSLUCENT ? 0L : region)
                                && cached.signature.matches(
                                        mesh, layer, draw, slice, capturedUboIndex);
                int groupKey =
                        reuse
                                ? cached.groupKey
                                : layer == ChunkSectionLayer.TRANSLUCENT
                                        ? 0
                                        : groupKeys.idFor(
                                                vertexBuffer, indexBuffer, indexType, region);
                List<RenderPass.Draw<GpuBufferSlice[]>> list =
                        groups.get(layer).computeIfAbsent(groupKey, ignored -> new ArrayList<>());
                packetCount++;
                if (reuse) {
                    list.add(cached.draw);
                    packetReuses++;
                    if (VERIFY_PACKETS && verifiedPackets < 100_000) {
                        var actualSlice = dispatcher.getRenderSectionSlice(mesh, layer);
                        var packet = cached.draw;
                        int expectedFirst =
                                draw.hasCustomIndexBuffer()
                                        ? (int)
                                                (actualSlice.indexBufferOffset()
                                                        / draw.indexType().bytes)
                                        : 0;
                        if (stableSources[capturedUboIndex] != sectionIndex
                                || !cached.signature.matches(
                                        mesh, layer, draw, actualSlice, capturedUboIndex)
                                || packet.vertexBuffer() != actualSlice.vertexBuffer()
                                || packet.indexBuffer()
                                        != (draw.hasCustomIndexBuffer()
                                                ? actualSlice.indexBuffer()
                                                : null)
                                || packet.indexType()
                                        != (draw.hasCustomIndexBuffer() ? draw.indexType() : null)
                                || packet.baseVertex()
                                        != actualSlice.vertexBufferOffset()
                                                / vertexFormat.getVertexSize()
                                || packet.firstIndex() != expectedFirst
                                || packet.indexCount() != draw.indexCount()
                                || ((VeilSectionUniformUploader) packet.uniformUploaderConsumer())
                                                .index()
                                        != capturedUboIndex)
                            throw new IllegalStateException(
                                    "Stable terrain packet differs from host");
                        if (++verifiedPackets == 100_000)
                            ReviveMod.LOGGER.info(
                                    "Veil stable packet verification PASS: 100000 commands and section slots match host");
                    }
                } else {
                    var packet =
                            new RenderPass.Draw<GpuBufferSlice[]>(
                                    0,
                                    vertexBuffer,
                                    indexBuffer,
                                    indexType,
                                    firstIndex,
                                    draw.indexCount(),
                                    baseVertex,
                                    new VeilSectionUniformUploader(
                                            capturedUboIndex, mesh, layer, section));
                    var signature = PacketSignature.of(mesh, layer, draw, slice, capturedUboIndex);
                    list.add(packet);
                    if (!STABLE_PACKETS) signatures.add(signature);
                    if (STABLE_PACKETS)
                        PACKETS.put(
                                mesh,
                                layer.ordinal(),
                                new CachedPacket(
                                        signature,
                                        packet,
                                        groupKey,
                                        layer == ChunkSectionLayer.TRANSLUCENT ? 0L : region));
                    packetBuilds++;
                }
            }

            if (sectionHasDraw) {
                if (hostOrdering) {
                    var origin = section.getRenderOrigin();
                    double dx = origin.getX() + 8.0 - camera.x;
                    double dy = origin.getY() + 8.0 - camera.y;
                    double dz = origin.getZ() + 8.0 - camera.z;
                    distances[STABLE_PACKETS ? SECTION_SLOTS.indexOf(section) : uboIndex] =
                            dx * dx + dy * dy + dz * dz;
                }
                uboSectionIndices[uboIndex++] = sectionIndex;
            }
        }

        if (hostOrdering) {
            for (ChunkSectionLayer layer : LAYERS) {
                if (layer == ChunkSectionLayer.TRANSLUCENT) continue;
                for (var list : groups.get(layer).values()) {
                    list.sort(
                            java.util.Comparator.comparingDouble(
                                    draw ->
                                            distances[
                                                    ((VeilSectionUniformUploader)
                                                                    draw.uniformUploaderConsumer())
                                                            .index()]));
                }
            }
        }

        if (slotOrdering) {
            for (var list : groups.get(ChunkSectionLayer.TRANSLUCENT).values())
                list.sort(
                        java.util.Comparator.comparingInt(
                                draw ->
                                        stableSources[
                                                ((VeilSectionUniformUploader)
                                                                draw.uniformUploaderConsumer())
                                                        .index()]));
            for (ChunkSectionLayer layer : LAYERS) {
                if (layer == ChunkSectionLayer.TRANSLUCENT) continue;
                var previous = CACHE.drawGroups == null ? null : CACHE.drawGroups.get(layer);
                for (var entry : groups.get(layer).int2ObjectEntrySet()) {
                    var old = previous == null ? null : previous.get(entry.getIntKey());
                    if (samePackets(old, entry.getValue())) {
                        entry.setValue(old);
                        groupReuses++;
                    }
                }
            }
        }
        int groupCount = 0;
        for (Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>> layerGroups :
                groups.values()) {
            groupCount += layerGroups.size();
        }
        if (REGIONAL_PACKETS && slotOrdering && packetCount > 0 && !regionalLogged) {
            regionalLogged = true;
            ReviveMod.LOGGER.info(
                    "Veil regional terrain packets ACTIVE: opaque groups keyed by world region and buffer identity");
        }
        return new BuildResult(
                groups,
                maxIndices,
                List.copyOf(signatures),
                packetCount,
                groupCount,
                STABLE_PACKETS
                        ? stableSources
                        : java.util.Arrays.copyOf(uboSectionIndices, uboIndex));
    }

    private static boolean samePackets(
            List<RenderPass.Draw<GpuBufferSlice[]>> a, List<RenderPass.Draw<GpuBufferSlice[]>> b) {
        if (a == null || a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++) if (a.get(i) != b.get(i)) return false;
        return true;
    }

    public static String stablePacketTelemetry() {
        return "terrain_regional_packets_enabled="
                + REGIONAL_PACKETS
                + "\nterrain_retained_slots_enabled="
                + RETAINED_SLOTS
                + "\nterrain_resident_section_slots="
                + SECTION_SLOTS.residentCount()
                + "\nterrain_resident_commands_enabled="
                + RESIDENT_COMMANDS
                + "\nterrain_resident_commands="
                + RESIDENT_GROUPS.commandCount
                + "\nterrain_inactive_resident_commands="
                + RESIDENT_GROUPS.inactiveCommandCount
                + "\nterrain_resident_commands_retired="
                + RESIDENT_GROUPS.retired
                + "\nterrain_resident_address_checks="
                + RESIDENT_GROUPS.addressChecks
                + "\nterrain_resident_address_checks_avoided="
                + RESIDENT_GROUPS.addressChecksAvoided
                + "\nterrain_resident_opaque_regroupings="
                + RESIDENT_GROUPS.opaqueRegroupings
                + "\nterrain_resident_translucent_rebindings="
                + RESIDENT_GROUPS.translucentRebindings
                + "\nterrain_resident_owner_checks="
                + RESIDENT_GROUPS.ownerChecks
                + "\nterrain_resident_owner_checks_reused="
                + RESIDENT_GROUPS.ownerChecksReused
                + "\nterrain_resident_owner_checks_verified="
                + RESIDENT_GROUPS.ownerChecksVerified
                + "\nterrain_resident_owner_incremental_enabled="
                + RESIDENT_GROUPS.incrementalOwners
                + "\nterrain_resident_owner_incremental_reuses="
                + RESIDENT_GROUPS.incrementalOwnerReuses
                + "\nterrain_resident_owner_incremental_verified="
                + RESIDENT_GROUPS.incrementalOwnerVerified
                + "\nterrain_resident_active_retirement_fallbacks="
                + RESIDENT_GROUPS.activeRetirementFallbacks
                + "\nterrain_stable_packets_built_total="
                + packetBuilds
                + "\nterrain_stable_packets_reused_total="
                + packetReuses
                + "\nterrain_stable_groups_reused_total="
                + groupReuses
                + "\nterrain_unrelated_revision_reuses_total="
                + unrelatedRevisionReuses
                + "\nterrain_keyed_address_walks_avoided_total="
                + keyedAddressWalksAvoided
                + "\nterrain_snapshot_active_sections="
                + CACHE.topology.size()
                + "\nterrain_snapshot_capacity_sections="
                + CACHE.topology.sections().length
                + "\n";
    }

    static boolean inactiveResidentSlot(int slot) {
        return RESIDENT_COMMANDS
                && slot >= 0
                && slot < CACHE.uboSectionIndices.length
                && CACHE.uboSectionIndices[slot] < 0;
    }

    private static final class ResidentGroups {
        final EnumMap<ChunkSectionLayer, Int2ObjectOpenHashMap<ResidentPacket>> packets =
                new EnumMap<>(ChunkSectionLayer.class);
        EnumMap<ChunkSectionLayer, Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                groups;
        Object activeTopology;
        long activeGeneration, activeRetirementFallbacks;
        int maxIndices, commandCount, inactiveCommandCount;
        long retired, checkedEpoch = Long.MIN_VALUE, addressChecks, addressChecksAvoided;
        long opaqueRegroupings, translucentRebindings;
        long ownerChecks, ownerChecksReused, ownerChecksVerified;
        final dev.veil.revive.core.terrain.ResidentOwnerCache<ResidentPacket> ownerCache =
                new dev.veil.revive.core.terrain.ResidentOwnerCache<>(ResidentPacket[]::new);
        long ownerAuditNs, checkedOwnerRevision = Long.MIN_VALUE;
        long incrementalOwnerReuses, incrementalOwnerVerified;
        boolean incrementalOwners;
        final IdentityHashMap<SectionRenderDispatcher.RenderSection, Boolean> changedOwners =
                new IdentityHashMap<>();
        final IdentityHashMap<SectionMesh, Boolean> changedMeshes = new IdentityHashMap<>();

        EnumMap<ChunkSectionLayer, Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                update(
                        EnumMap<
                                        ChunkSectionLayer,
                                        Int2ObjectOpenHashMap<
                                                List<RenderPass.Draw<GpuBufferSlice[]>>>>
                                active,
                        SectionRenderDispatcher dispatcher,
                        long epoch) {
            boolean changed = groups == null;
            boolean opaqueChanged = changed;
            changedMeshes.clear();
            boolean allAddressesChanged =
                    checkedEpoch != epoch
                            && !VeilAllocationEpoch.visitSince(
                                    checkedEpoch,
                                    owner -> {
                                        if (owner instanceof SectionMesh mesh)
                                            changedMeshes.put(mesh, Boolean.TRUE);
                                    });
            if (activeTopology != active) {
                if (++activeGeneration <= 0)
                    throw new IllegalStateException("Resident topology generation overflow");
                for (ChunkSectionLayer layer : LAYERS) {
                    if (layer == ChunkSectionLayer.TRANSLUCENT) continue;
                    var entries =
                            packets.computeIfAbsent(
                                    layer, ignored -> new Int2ObjectOpenHashMap<>());
                    for (var group : active.get(layer).int2ObjectEntrySet()) {
                        for (var draw : group.getValue()) {
                            var uploader =
                                    (VeilSectionUniformUploader) draw.uniformUploaderConsumer();
                            int slot = uploader.index();
                            var owner = CACHE.topology.sections()[CACHE.uboSectionIndices[slot]];
                            var old = entries.get(slot);
                            if (old != null
                                    && old.owner == owner
                                    && old.draw == draw
                                    && old.node == owner.getSectionNode()) {
                                old.lastActiveGeneration = activeGeneration;
                                continue;
                            }
                            var hostDraw = uploader.mesh().getSectionDraw(layer);
                            var address = dispatcher.getRenderSectionSlice(uploader.mesh(), layer);
                            ResidentPacket packet =
                                    new ResidentPacket(
                                            owner,
                                            owner.getSectionNode(),
                                            owner.getRenderOrigin().immutable(),
                                            draw,
                                            PacketSignature.of(
                                                    uploader.mesh(),
                                                    layer,
                                                    hostDraw,
                                                    address,
                                                    slot),
                                            group.getIntKey(),
                                            epoch);
                            packet.lastActiveGeneration = activeGeneration;
                            entries.put(slot, packet);
                            changed = opaqueChanged = true;
                        }
                    }
                }
                if (groups != null
                        && groups.get(ChunkSectionLayer.TRANSLUCENT)
                                != active.get(ChunkSectionLayer.TRANSLUCENT)) changed = true;
                activeTopology = active;
            }
            injectObsoleteActivePacket();
            inactiveCommandCount = 0;
            incrementalOwners =
                    Boolean.getBoolean("veil.incrementalResidentOwners")
                            && VeilSectionChanges.notificationsSupported();
            changedOwners.clear();
            long ownerRevision = VeilSectionChanges.current();
            boolean allOwnersChanged =
                    !incrementalOwners
                            || !VeilSectionChanges.visitSince(
                                    checkedOwnerRevision,
                                    owner -> changedOwners.put(owner, Boolean.TRUE));
            long now = System.nanoTime();
            if (ownerAuditNs == 0 || now - ownerAuditNs >= IDENTITY_AUDIT_INTERVAL_NS) {
                allOwnersChanged = true;
                ownerAuditNs = now;
            }
            ownerCache.beginFrame(CACHE.uboSectionIndices.length, incrementalOwners);
            for (var layerEntry : packets.entrySet()) {
                var iterator = layerEntry.getValue().values().iterator();
                while (iterator.hasNext()) {
                    ResidentPacket packet = iterator.next();
                    boolean addressChanged =
                            packet.checkedEpoch != epoch
                                    && (allAddressesChanged
                                            || changedMeshes.containsKey(packet.signature.mesh()));
                    if (packet.checkedEpoch != epoch) {
                        if (addressChanged) addressChecks++;
                        else addressChecksAvoided++;
                    }
                    int slot = packet.signature.uboIndex();
                    ResidentPacket previous = ownerCache.previous(slot);
                    boolean ownerValid;
                    boolean previousFrame = ownerCache.previousFrame(slot);
                    if (previous != null
                            && previous.sameOwnerState(packet)
                            && SECTION_SLOTS.retains(packet.owner, slot)
                            && (!previousFrame
                                    || (!allOwnersChanged
                                            && !changedOwners.containsKey(packet.owner)))) {
                        ownerValid = ownerCache.valid(slot);
                        ownerChecksReused++;
                        if (previousFrame) incrementalOwnerReuses++;
                        if (VERIFY_PACKETS && ownerChecksVerified < 100_000) {
                            if (ownerValid != packet.validOwner()) {
                                if (previousFrame) VeilSectionChanges.rejectNotificationCoverage();
                                throw new IllegalStateException(
                                        "Resident section changed during layer validation");
                            }
                            if (++ownerChecksVerified == 100_000)
                                ReviveMod.LOGGER.info(
                                        "Veil resident owner validation PASS: 100000 shared checks matched independent layer checks");
                        }
                        if (VERIFY_PACKETS && previousFrame && incrementalOwnerVerified < 100_000) {
                            if (ownerValid != packet.validOwner()) {
                                VeilSectionChanges.rejectNotificationCoverage();
                                throw new IllegalStateException(
                                        "Resident section change was not notified");
                            }
                            if (++incrementalOwnerVerified == 100_000)
                                ReviveMod.LOGGER.info(
                                        "Veil incremental owner validation PASS: 100000 previous-frame results matched live sections");
                        }
                    } else {
                        ownerValid = packet.validOwner();
                        ownerCache.store(slot, packet, ownerValid);
                        ownerChecks++;
                    }
                    ownerCache.markChecked(slot);
                    if (!ownerValid
                            || !packet.validDraw(
                                    layerEntry.getKey(), dispatcher, epoch, addressChanged)) {
                        if (packet.lastActiveGeneration == activeGeneration) {
                            activeRetirementFallbacks++;
                            VeilResidentRetirementProbe.fallbackDetected();
                            throw new IllegalStateException(
                                    "Active resident packet invalidated at section slot " + slot);
                        }
                        iterator.remove();
                        ownerCache.invalidate(slot);
                        retired++;
                        changed = opaqueChanged = true;
                    } else if (inactiveResidentSlot(packet.signature.uboIndex()))
                        inactiveCommandCount++;
                }
            }
            checkedEpoch = epoch;
            checkedOwnerRevision = ownerRevision;
            VeilResidentRetirementProbe.recovered();
            if (!changed) return groups;
            if (!opaqueChanged) {
                translucentRebindings++;
                groups = new EnumMap<>(groups);
                groups.put(
                        ChunkSectionLayer.TRANSLUCENT, active.get(ChunkSectionLayer.TRANSLUCENT));
                return groups;
            }
            var next =
                    new EnumMap<
                            ChunkSectionLayer,
                            Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>(
                            ChunkSectionLayer.class);
            opaqueRegroupings++;
            maxIndices = commandCount = 0;
            for (ChunkSectionLayer layer : LAYERS) {
                if (layer == ChunkSectionLayer.TRANSLUCENT) {
                    next.put(layer, active.get(layer));
                    continue;
                }
                var grouped = new Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>();
                var entries = packets.get(layer);
                if (entries != null) {
                    var ordered = new ArrayList<>(entries.values());
                    ordered.sort(
                            java.util.Comparator.comparingInt(
                                    packet -> packet.signature.uboIndex()));
                    for (ResidentPacket packet : ordered) {
                        grouped.computeIfAbsent(packet.groupKey, ignored -> new ArrayList<>())
                                .add(packet.draw);
                        commandCount++;
                        if (packet.draw.indexBuffer() == null)
                            maxIndices = Math.max(maxIndices, packet.draw.indexCount());
                    }
                }
                if (groups != null) {
                    for (var entry : grouped.int2ObjectEntrySet()) {
                        var previous = groups.get(layer).get(entry.getIntKey());
                        if (previous != null && previous.equals(entry.getValue()))
                            entry.setValue(previous);
                    }
                }
                next.put(layer, grouped);
            }
            groups = next;
            return next;
        }

        private void injectObsoleteActivePacket() {
            if (!VeilResidentRetirementProbe.shouldInject(commandCount)) return;
            for (var layer : packets.values()) {
                for (var entry : layer.int2ObjectEntrySet()) {
                    ResidentPacket packet = entry.getValue();
                    if (packet.lastActiveGeneration != activeGeneration || !packet.validOwner())
                        continue;
                    ResidentPacket obsolete =
                            new ResidentPacket(
                                    packet.owner,
                                    packet.node ^ 1L,
                                    packet.origin,
                                    packet.draw,
                                    packet.signature,
                                    packet.groupKey,
                                    packet.checkedEpoch);
                    obsolete.lastActiveGeneration = activeGeneration;
                    entry.setValue(obsolete);
                    VeilResidentRetirementProbe.injected();
                    return;
                }
            }
        }

        void clear() {
            packets.clear();
            groups = null;
            activeTopology = null;
            activeGeneration = 0;
            maxIndices = commandCount = inactiveCommandCount = 0;
            checkedEpoch = Long.MIN_VALUE;
            changedMeshes.clear();
            ownerCache.clear();
            changedOwners.clear();
            checkedOwnerRevision = Long.MIN_VALUE;
            ownerAuditNs = 0L;
        }
    }

    private static final class ResidentPacket {
        final SectionRenderDispatcher.RenderSection owner;
        final long node;
        final BlockPos origin;
        final RenderPass.Draw<GpuBufferSlice[]> draw;
        final PacketSignature signature;
        final int groupKey;
        long checkedEpoch;
        long lastActiveGeneration;

        ResidentPacket(
                SectionRenderDispatcher.RenderSection owner,
                long node,
                BlockPos origin,
                RenderPass.Draw<GpuBufferSlice[]> draw,
                PacketSignature signature,
                int groupKey,
                long epoch) {
            this.owner = owner;
            this.node = node;
            this.origin = origin;
            this.draw = draw;
            this.signature = signature;
            this.groupKey = groupKey;
            checkedEpoch = epoch;
        }

        boolean sameOwnerState(ResidentPacket other) {
            return owner == other.owner
                    && signature.mesh() == other.signature.mesh()
                    && node == other.node
                    && origin.equals(other.origin);
        }

        boolean validOwner() {
            return SECTION_SLOTS.retains(owner, signature.uboIndex())
                    && owner.getSectionMesh() == signature.mesh()
                    && owner.getSectionNode() == node
                    && origin.equals(owner.getRenderOrigin());
        }

        boolean validDraw(
                ChunkSectionLayer layer,
                SectionRenderDispatcher dispatcher,
                long epoch,
                boolean addressChanged) {
            if (signature.vertexBuffer().isClosed()
                    || (signature.indexBuffer() != null && signature.indexBuffer().isClosed()))
                return false;
            var hostDraw = signature.mesh().getSectionDraw(layer);
            if (hostDraw == null
                    || hostDraw.indexCount() != signature.indexCount()
                    || hostDraw.indexType() != signature.indexType()
                    || hostDraw.hasCustomIndexBuffer() != signature.customIndex()) return false;
            if (checkedEpoch != epoch && addressChanged) {
                var address = dispatcher.getRenderSectionSlice(signature.mesh(), layer);
                if (!isDrawable(hostDraw, address)
                        || !signature.matches(
                                signature.mesh(), layer, hostDraw, address, signature.uboIndex()))
                    return false;
            }
            checkedEpoch = epoch;
            return true;
        }
    }

    private record CachedPacket(
            PacketSignature signature,
            RenderPass.Draw<GpuBufferSlice[]> draw,
            int groupKey,
            long region) {}

    private static boolean isDrawable(
            SectionMesh.SectionDraw draw, SectionRenderDispatcher.RenderSectionBufferSlice slice) {
        return draw != null
                && slice != null
                && (!draw.hasCustomIndexBuffer() || slice.indexBuffer() != null);
    }

    private static void recordCacheMissReason(CacheMissReason reason) {
        switch (reason) {
            case NONE -> {}
            case EMPTY -> VeilTechniqueCounters.cacheMissEmpty();
            case DISPATCHER -> VeilTechniqueCounters.cacheMissDispatcher();
            case SIGNATURE -> VeilTechniqueCounters.cacheMissSignature();
            case PACKET_COUNT -> VeilTechniqueCounters.cacheMissPacketCount();
        }
    }

    private enum CacheMissReason {
        NONE,
        EMPTY,
        DISPATCHER,
        SIGNATURE,
        PACKET_COUNT
    }

    private record Validation(boolean cacheMatches, int packetCount, CacheMissReason missReason) {}

    private record BuildResult(
            EnumMap<
                            ChunkSectionLayer,
                            Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                    drawGroups,
            int maxIndices,
            List<PacketSignature> signatures,
            int packetCount,
            int groupCount,
            int[] uboSectionIndices) {}

    private static void beginSlices(SectionRenderDispatcher dispatcher, long revision) {
        if (!KEYED_ALLOCATIONS) {
            SLICES.begin(dispatcher, revision);
            return;
        }
        SLICES.begin(dispatcher, 0L);
        if (sliceRevision != revision) {
            if (!VeilAllocationEpoch.visitSince(
                    sliceRevision,
                    owner -> {
                        if (owner instanceof SectionMesh mesh) SLICES.invalidate(mesh);
                    })) {
                SLICES.clear();
                SLICES.begin(dispatcher, 0L);
            }
            sliceRevision = revision;
        }
    }

    private static final class FrameCache
            extends dev.veil.revive.core.terrain.TerrainFrameValidation<
                    SectionRenderDispatcher.RenderSection, SectionMesh, SectionRenderDispatcher> {
        SectionRenderDispatcher dispatcher;
        EnumMap<ChunkSectionLayer, Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                drawGroups;
        int maxIndices;
        List<PacketSignature> signatures = List.of();

        FrameCache() {
            super(
                    new dev.veil.revive.core.terrain.SectionTopology<>(
                            SectionRenderDispatcher.RenderSection[]::new,
                            SectionMesh[]::new,
                            SectionRenderDispatcher.RenderSection::getSectionMesh,
                            SectionRenderDispatcher.RenderSection::getSectionNode),
                    IDENTITY_AUDIT_INTERVAL_NS,
                    System::nanoTime);
        }

        int[] uboSectionIndices = new int[0];
        TextureAtlasSprite[] animatedSprites = new TextureAtlasSprite[0];
        volatile long[] visibleSectionKeys = new long[0];
        final IdentityHashMap<RenderPass.Draw<GpuBufferSlice[]>, Boolean> residentPackets =
                new IdentityHashMap<>();

        boolean fastMatches(
                SectionRenderDispatcher currentDispatcher,
                List<SectionRenderDispatcher.RenderSection> visibleSections,
                long currentAllocationEpoch) {
            boolean metrics = VeilTechniqueCounters.collecting();
            if (dispatcher == null
                    || dispatcher != currentDispatcher
                    || drawGroups == null
                    || (!INCREMENTAL_VALIDATION && allocationEpoch != currentAllocationEpoch)
                    || topology.size() != visibleSections.size()) {
                if (metrics) fastTopologyMisses++;
                return false;
            }

            long currentVisibilityRevision = VeilHostRevisions.visibility();
            long currentMeshRevision = VeilHostRevisions.mesh();
            long currentOriginRevision = VeilHostRevisions.origin();
            long currentGlobalRevision = VeilHostRevisions.global();

            return validate(
                    currentDispatcher,
                    visibleSections,
                    currentAllocationEpoch,
                    currentVisibilityRevision,
                    currentMeshRevision,
                    currentOriginRevision,
                    currentGlobalRevision,
                    metrics,
                    INCREMENTAL_VALIDATION,
                    STABLE_PACKETS);
        }

        @Override
        protected boolean allocationRelevant(long previousEpoch) {
            return !KEYED_ALLOCATIONS
                    || VeilAllocationEpoch.affectsSince(previousEpoch, topology::containsMesh);
        }

        @Override
        protected boolean verificationPending() {
            return VERIFY_PACKETS && verifiedResidentPackets < 100_000;
        }

        @Override
        protected void record(Event event, long count) {
            switch (event) {
                case TOPOLOGY_HIT -> fastTopologyHits += count;
                case TOPOLOGY_MISS -> fastTopologyMisses += count;
                case SECTION_CHECKS -> fastSectionChecks += count;
                case REVISION_HIT -> revisionFastHits += count;
                case REVALIDATION -> revisionRevalidations += count;
                case IDENTITY_AUDIT -> periodicIdentityAudits += count;
                case REVISION_SELF_HEAL -> revisionSelfHeals += count;
                case ORIGIN_FORCE -> relocationRevisionForces += count;
                case ORIGIN_SELF_HEAL -> relocationSelfHeals += count;
                case ADDRESS_WALK_AVOIDED -> keyedAddressWalksAvoided += count;
                case UNRELATED_REUSE -> unrelatedRevisionReuses += count;
            }
        }

        @Override
        protected boolean addressesMatch(SectionRenderDispatcher currentDispatcher) {
            int count = 0;
            for (int i = 0; i < topology.size(); i++) {
                SectionRenderDispatcher.RenderSection section = topology.section(i);
                SectionMesh mesh = section.getSectionMesh();
                for (ChunkSectionLayer layer : LAYERS) {
                    var draw = mesh.getSectionDraw(layer);
                    if (draw == null) continue;
                    var address = slice(mesh, layer, currentDispatcher);
                    if (!isDrawable(draw, address)) continue;
                    var entry = PACKETS.lookup(mesh, layer.ordinal());
                    CachedPacket cached = entry == null ? null : entry.value(layer.ordinal());
                    int slot = SECTION_SLOTS.indexOf(section);
                    if (cached == null
                            || !residentPackets.containsKey(cached.draw)
                            || !cached.signature.matches(mesh, layer, draw, address, slot))
                        return false;
                    if (VERIFY_PACKETS && verifiedResidentPackets < 100_000) {
                        var actual = currentDispatcher.getRenderSectionSlice(mesh, layer);
                        if (!cached.signature.matches(mesh, layer, draw, actual, slot))
                            throw new IllegalStateException(
                                    "Resident terrain address differs from host");
                        if (++verifiedResidentPackets == 100_000)
                            ReviveMod.LOGGER.info(
                                    "Veil resident packet verification PASS: 100000 current addresses match host");
                    }
                    count++;
                }
            }
            return count == residentPackets.size();
        }

        void refreshFastState(
                List<SectionRenderDispatcher.RenderSection> visibleSections, long allocationEpoch) {
            this.visibleSectionKeys = topology.capture(visibleSections);
            refreshRevisions(
                    allocationEpoch,
                    VeilHostRevisions.visibility(),
                    VeilHostRevisions.mesh(),
                    VeilHostRevisions.origin(),
                    VeilHostRevisions.global());
            rebuildAnimatedSprites();
            scheduleIdentityAudit();
        }

        private void rebuildAnimatedSprites() {
            if (!VeilVideoConfig.on("animation.visibleOnly")) {
                animatedSprites = new TextureAtlasSprite[0];
                return;
            }
            IdentityHashMap<TextureAtlasSprite, Boolean> unique = new IdentityHashMap<>();
            for (int i = 0; i < topology.size(); i++) {
                SectionMesh mesh = topology.mesh(i);
                if (!(mesh instanceof VeilMeshExtras extras) || extras.veil$metadata() == null)
                    continue;
                for (TextureAtlasSprite sprite : extras.veil$metadata().animatedSprites()) {
                    if (sprite != null) unique.put(sprite, Boolean.TRUE);
                }
            }
            animatedSprites = unique.keySet().toArray(TextureAtlasSprite[]::new);
        }

        void markAnimatedSpritesActive() {
            VeilAnimatedSpriteUsage.markActive(animatedSprites);
        }

        void install(
                SectionRenderDispatcher dispatcher,
                List<SectionRenderDispatcher.RenderSection> visibleSections,
                long allocationEpoch,
                BuildResult result) {
            this.dispatcher = dispatcher;
            this.drawGroups = result.drawGroups;
            this.maxIndices = result.maxIndices;
            this.signatures = result.signatures;
            residentPackets.clear();
            if (STABLE_PACKETS)
                for (var groups : drawGroups.values())
                    for (var draws : groups.values())
                        for (var draw : draws) residentPackets.put(draw, Boolean.TRUE);
            refreshFastState(visibleSections, allocationEpoch);
            this.uboSectionIndices = result.uboSectionIndices.clone();
        }

        void clear() {
            residentPackets.clear();
            dispatcher = null;
            drawGroups = null;
            maxIndices = 0;
            signatures = List.of();
            topology.clear();
            uboSectionIndices = new int[0];
            clearRevisions();
            animatedSprites = new TextureAtlasSprite[0];
            visibleSectionKeys = new long[0];
            resetIdentityAudit();
        }
    }

    private static final class GroupKeyAllocator {
        private final dev.veil.revive.core.terrain.StableGroupKeys<RegionBindingKey> keys =
                new dev.veil.revive.core.terrain.StableGroupKeys<>();

        void clear() {
            keys.clear();
        }

        int idFor(
                GpuBuffer vertices,
                @Nullable GpuBuffer indices,
                @Nullable IndexType type,
                long region) {
            return keys.idFor(new RegionBindingKey(vertices, indices, type, region));
        }
    }
}
