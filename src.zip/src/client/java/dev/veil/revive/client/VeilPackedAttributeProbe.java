package dev.veil.revive.client;

import dev.veil.revive.core.terrain.PackedTerrainAttributeMap;
import dev.veil.revive.core.terrain.RegularTerrainVertices;

final class VeilPackedAttributeProbe {
    static final boolean REQUESTED = Boolean.getBoolean("veil.verifyPackedAttributeProvenance");
    private static long pairs, regular, vertices, grid16, float20, wide20;

    private VeilPackedAttributeProbe() {}

    static void record(
            PackedTerrainAttributeMap map, RegularTerrainVertices.Result packed, boolean paired) {
        if (!REQUESTED || map == null) return;
        if (!map.geometryCurrent(packed))
            throw new IllegalStateException("Published compact map geometry changed");
        if (paired) pairs++;
        else regular++;
        vertices += map.vertexCount();
        switch (map.layout()) {
            case GRID16 -> grid16++;
            case FLOAT_UV20 -> float20++;
            case WIDE_POSITION20 -> wide20++;
        }
    }

    static void requireComplete() {
        if (!REQUESTED) return;
        String mode = System.getProperty("veil.packedAttributeMode", "any");
        if (vertices < 1024
                || pairs + regular == 0
                || mode.equals("paired") && pairs == 0
                || mode.equals("regular") && regular == 0)
            throw new IllegalStateException("Published compact attribute maps not exercised");
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil packed attribute provenance: PASS (pairs={} regular={} vertices={} grid16={} float20={} wide20={})",
                pairs,
                regular,
                vertices,
                grid16,
                float20,
                wide20);
    }
}
