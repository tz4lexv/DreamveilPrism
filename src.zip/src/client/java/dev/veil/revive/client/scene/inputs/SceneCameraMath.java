package dev.veil.revive.client.scene.inputs;

import dev.veil.api.VeilScenePass;
import dev.veil.revive.client.VeilCameraAbi;
import dev.veil.revive.client.VeilSceneCameraAbi;

import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3f;

public final class SceneCameraMath {
    private SceneCameraMath() {}

    /** Direction from a receiver toward the sun; shadow cameras look in the opposite direction. */
    public static Vector3f towardSun(float sunAngle) {
        if (!Float.isFinite(sunAngle)) throw new IllegalArgumentException("Invalid sun angle");
        return new Vector3f(-(float) Math.sin(sunAngle), (float) Math.cos(sunAngle), 0.0f)
                .normalize();
    }

    public static VeilSceneCameraAbi.Snapshot create(
            VeilScenePass.Camera camera,
            VeilCameraAbi.Snapshot main,
            float sunAngle,
            int width,
            int height,
            boolean zeroToOne) {
        if (width < 1 || height < 1 || !Float.isFinite(sunAngle))
            throw new IllegalArgumentException("Invalid custom camera frame");
        var pose = camera.pose();
        float sunHeight = (float) Math.cos(sunAngle);
        Vector3f direction =
                camera.direction() == VeilScenePass.Direction.SUN
                        ? towardSun(sunAngle).negate()
                        : new Vector3d(pose.forwardX(), pose.forwardY(), pose.forwardZ())
                                .normalize()
                                .get(new Vector3f());
        Vector3f up =
                camera.direction() == VeilScenePass.Direction.FIXED
                        ? new Vector3d(pose.upX(), pose.upY(), pose.upZ())
                                .normalize()
                                .get(new Vector3f())
                        : Math.abs(direction.y) > 0.98f
                                ? new Vector3f(0.0f, 0.0f, 1.0f)
                                : new Vector3f(0.0f, 1.0f, 0.0f);
        Vector3f right = new Vector3f(direction).cross(up).normalize();
        Vector3f cameraUp = new Vector3f(right).cross(direction).normalize();
        double absoluteX =
                camera.anchor() == VeilScenePass.Anchor.WORLD_POSITION
                        ? pose.x()
                        : main.x() + pose.x();
        double absoluteY =
                camera.anchor() == VeilScenePass.Anchor.WORLD_POSITION
                        ? pose.y()
                        : main.y() + pose.y();
        double absoluteZ =
                camera.anchor() == VeilScenePass.Anchor.WORLD_POSITION
                        ? pose.z()
                        : main.z() + pose.z();
        Vector3f centerRelative =
                new Vector3f(
                        (float) (absoluteX - main.x()),
                        (float) (absoluteY - main.y()),
                        (float) (absoluteZ - main.z()));
        if (!centerRelative.isFinite())
            throw new IllegalArgumentException(
                    "Camera relative position exceeds matrix precision range");
        if (camera.stabilize()) {
            double texelX = camera.width() / width;
            double texelY = camera.height() / height;
            Vector3d position = new Vector3d(absoluteX, absoluteY, absoluteZ);
            double projectedX = position.x * right.x + position.y * right.y + position.z * right.z;
            double projectedY =
                    position.x * cameraUp.x + position.y * cameraUp.y + position.z * cameraUp.z;
            double snappedX = Math.rint(projectedX / texelX) * texelX;
            double snappedY = Math.rint(projectedY / texelY) * texelY;
            centerRelative
                    .fma((float) (snappedX - projectedX), right)
                    .fma((float) (snappedY - projectedY), cameraUp);
        }
        boolean perspective = camera.projection() == VeilScenePass.Projection.PERSPECTIVE;
        float eyeDistance = camera.nearPlane() * 0.5f + camera.farPlane() * 0.5f;
        Vector3f eye =
                perspective
                        ? new Vector3f(centerRelative)
                        : new Vector3f(centerRelative).fma(-eyeDistance, direction);
        Matrix4f view =
                new Matrix4f().setLookAlong(direction, cameraUp).translate(-eye.x, -eye.y, -eye.z);
        Matrix4f projection =
                perspective
                        ? new Matrix4f()
                                .setPerspective(
                                        (float) Math.toRadians(camera.verticalFov()),
                                        camera.width() / camera.height(),
                                        camera.farPlane(),
                                        camera.nearPlane(),
                                        zeroToOne)
                        : new Matrix4f()
                                .setOrtho(
                                        -camera.width() * 0.5f,
                                        camera.width() * 0.5f,
                                        -camera.height() * 0.5f,
                                        camera.height() * 0.5f,
                                        camera.farPlane(),
                                        camera.nearPlane(),
                                        zeroToOne);
        Matrix4f viewProjection = new Matrix4f(projection).mul(view);
        float determinant = viewProjection.determinant();
        if (!Float.isFinite(determinant) || Math.abs(determinant) < 1.0e-12f) {
            throw new IllegalArgumentException("Custom scene camera matrix is not invertible");
        }
        return new VeilSceneCameraAbi.Snapshot(
                view,
                projection,
                viewProjection,
                new Matrix4f(viewProjection).invert(),
                main.x(),
                main.y(),
                main.z(),
                direction,
                camera.direction() == VeilScenePass.Direction.SUN
                        ? Math.max(0.0f, sunHeight)
                        : 1.0f,
                width,
                height);
    }
}
