package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilServerAiCounters;

import net.minecraft.server.level.ServerLevel;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.BooleanSupplier;

@Mixin(ServerLevel.class)
public abstract class ServerLevelTickTimingMixin {
    @Unique private long veil$levelTickStartNs;

    @Inject(method = "tick", at = @At("HEAD"), require = 1)
    private void veil$beginLevelTick(BooleanSupplier haveTime, CallbackInfo ci) {
        veil$levelTickStartNs = VeilDiagnostics.benchmarkActive() ? System.nanoTime() : 0L;
    }

    @Inject(method = "tick", at = @At("RETURN"), require = 1)
    private void veil$endLevelTick(BooleanSupplier haveTime, CallbackInfo ci) {
        long start = veil$levelTickStartNs;
        veil$levelTickStartNs = 0L;
        if (start != 0L && VeilDiagnostics.benchmarkActive()) {
            VeilServerAiCounters.levelTick(System.nanoTime() - start);
        }
    }
}
