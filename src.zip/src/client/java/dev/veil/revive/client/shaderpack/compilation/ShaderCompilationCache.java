package dev.veil.revive.client.shaderpack.compilation;

import dev.veil.revive.client.VeilShaderId;
import dev.veil.revive.client.VeilShaderInterface;
import dev.veil.revive.client.VeilShaderStage;
import dev.veil.revive.client.VeilSpirvBinary;

import java.util.LinkedHashMap;
import java.util.Map;

public final class ShaderCompilationCache {
    public record SourceKey(VeilShaderId id, VeilShaderStage stage, String entryPoint) {}

    public record CompiledKey(
            String source,
            Map<VeilShaderId, String> dependencies,
            VeilShaderStage stage,
            String entryPoint,
            String toolchain) {
        public CompiledKey {
            dependencies = Map.copyOf(dependencies);
        }
    }

    public record SourceEntry(VeilSpirvBinary binary, Map<VeilShaderId, String> dependencies) {}

    private final int capacity;
    private final Map<SourceKey, SourceEntry> sources = new LinkedHashMap<>(16, 0.75f, true);
    private final Map<CompiledKey, VeilSpirvBinary> binaries = new LinkedHashMap<>(16, 0.75f, true);
    private final Map<String, VeilShaderInterface> interfaces =
            new LinkedHashMap<>(16, 0.75f, true);

    public ShaderCompilationCache(int capacity) {
        if (capacity < 1 || capacity > 4096)
            throw new IllegalArgumentException("Invalid shader cache capacity");
        this.capacity = capacity;
    }

    public SourceEntry source(SourceKey key) {
        return sources.get(key);
    }

    public void source(SourceKey key, SourceEntry value) {
        sources.put(key, value);
        trim(sources);
    }

    public VeilSpirvBinary binary(CompiledKey key) {
        return binaries.get(key);
    }

    public void binary(CompiledKey key, VeilSpirvBinary value) {
        binaries.put(key, value);
        trim(binaries);
    }

    public VeilShaderInterface reflected(String key) {
        return interfaces.get(key);
    }

    public void reflected(String key, VeilShaderInterface value) {
        interfaces.put(key, value);
        trim(interfaces);
    }

    private <K, V> void trim(Map<K, V> cache) {
        while (cache.size() > capacity) cache.remove(cache.keySet().iterator().next());
    }
}
