package dev.veil.revive.client;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class VeilSurfaceTransforms {
    public static final String HOST_ID = "minecraft:surface_transforms";
    public static final int SIZE = 368;
    private static final Matrix4f CAPTURED = new Matrix4f();
    private static boolean captured;

    public record Snapshot(
            Matrix4f clip, Matrix4f inverse, double x, double y, double z, int width, int height) {
        public Snapshot {
            clip = new Matrix4f(clip);
            inverse = new Matrix4f(inverse);
            if (!clip.isFinite()
                    || !inverse.isFinite()
                    || !Double.isFinite(x)
                    || !Double.isFinite(y)
                    || !Double.isFinite(z)
                    || width < 1
                    || height < 1) throw new IllegalArgumentException("Invalid surface transform");
        }
    }

    private VeilSurfaceTransforms() {}

    public static void adjustProbeProjection(Matrix4f projection) {
        VeilVolumeSupportGpuProbe.adjustProjection(projection);
    }

    public static void beginRender() {
        captured = false;
    }

    public static void capture(Matrix4fc projection) {
        CAPTURED.set(projection);
        captured = true;
    }

    public static Snapshot current(VeilCameraAbi.Snapshot camera, int width, int height) {
        if (!captured) throw new IllegalStateException("Scene depth projection was not captured");
        return create(
                CAPTURED, camera.viewRotation(), camera.x(), camera.y(), camera.z(), width, height);
    }

    public static Snapshot create(
            Matrix4fc projection,
            Matrix4fc view,
            double x,
            double y,
            double z,
            int width,
            int height) {
        Matrix4f clip = new Matrix4f(projection).mul(view);
        float determinant = clip.determinant();
        if (!Float.isFinite(determinant) || Math.abs(determinant) < 1e-12f)
            throw new IllegalArgumentException("Singular surface transform");
        return new Snapshot(clip, new Matrix4f(clip).invert(), x, y, z, width, height);
    }

    public static void write(ByteBuffer target, Snapshot current, Snapshot previous) {
        if (target.remaining() < SIZE || current == null)
            throw new IllegalArgumentException("Surface transforms require " + SIZE + " bytes");
        ByteBuffer bytes = target.slice().order(ByteOrder.nativeOrder());
        Snapshot prior = previous == null ? current : previous;
        matrix(bytes, 0, current.clip());
        matrix(bytes, 64, current.inverse());
        matrix(bytes, 128, prior.clip());
        matrix(bytes, 192, prior.inverse());
        position(bytes, 256, current);
        position(bytes, 288, prior);
        bytes.putFloat(320, current.width())
                .putFloat(324, current.height())
                .putFloat(328, 1f / current.width())
                .putFloat(332, 1f / current.height());
        bytes.putFloat(336, prior.width())
                .putFloat(340, prior.height())
                .putFloat(344, 1f / prior.width())
                .putFloat(348, 1f / prior.height());
        bytes.putFloat(352, previous == null ? 0f : 1f)
                .putFloat(356, 1f)
                .putFloat(360, 0f)
                .putFloat(364, 0f);
    }

    private static void position(ByteBuffer bytes, int offset, Snapshot snapshot) {
        component(bytes, offset, snapshot.x());
        component(bytes, offset + 4, snapshot.y());
        component(bytes, offset + 8, snapshot.z());
        bytes.putFloat(offset + 12, 0f).putFloat(offset + 28, 0f);
    }

    private static void component(ByteBuffer bytes, int offset, double value) {
        float high = (float) value;
        bytes.putFloat(offset, high).putFloat(offset + 16, (float) (value - high));
    }

    private static void matrix(ByteBuffer bytes, int offset, Matrix4fc matrix) {
        for (int column = 0; column < 4; column++)
            for (int row = 0; row < 4; row++)
                bytes.putFloat(offset + column * 16 + row * 4, matrix.get(column, row));
    }
}
