package dev.veil.revive.client;

import dev.veil.revive.client.ui.VeilSettingsScreen;

import net.minecraft.client.gui.screens.Screen;

public final class VeilVideoScreen extends VeilSettingsScreen {
    public VeilVideoScreen(Screen parent) {
        super(parent, VeilWorldRayScene::requested);
    }

    void developmentCheck() {
        checkDevelopmentSettings();
    }

    void developmentTab(int index) {
        selectDevelopmentTab(index);
    }
}
