package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilLightingPipeline;

import net.minecraft.client.renderer.Lightmap;
import net.minecraft.client.renderer.state.LightmapRenderState;

import org.joml.Vector3fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Lightmap.class)
public abstract class LightmapCacheMixin {
    @Unique private boolean veil$hasLightmapState;
    @Unique private final int[] veil$lastLightmapState = new int[18];

    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void veil$skipIdenticalLightmap(LightmapRenderState state, CallbackInfo ci) {
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.LIGHTMAP);
        if (!VeilLightingPipeline.lightmapCacheEnabled()) {
            this.veil$hasLightmapState = false;
            return;
        }
        if (!state.needsUpdate) return;
        if (this.veil$hasLightmapState && veil$matches(state, this.veil$lastLightmapState)) {
            dev.veil.revive.client.VeilNativeLightingHost.capture(
                    ((Lightmap) (Object) this).getTextureView(), state);
            VeilLightingPipeline.recordLightmapSkip();
            dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                    dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.LIGHTMAP);
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("RETURN"), require = 0)
    private void veil$endLightmap(LightmapRenderState state, CallbackInfo ci) {
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.LIGHTMAP);
    }

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void veil$captureLightmap(LightmapRenderState state, CallbackInfo ci) {
        dev.veil.revive.client.VeilNativeLightingHost.capture(
                ((Lightmap) (Object) this).getTextureView(), state);
        if (!VeilLightingPipeline.lightmapCacheEnabled()) {
            this.veil$hasLightmapState = false;
            return;
        }
        if (!state.needsUpdate) return;
        veil$capture(state, this.veil$lastLightmapState);
        this.veil$hasLightmapState = true;
        VeilLightingPipeline.recordLightmapRender();
    }

    @Unique
    private static boolean veil$matches(LightmapRenderState s, int[] v) {
        return v[0] == Float.floatToRawIntBits(s.skyFactor)
                && v[1] == Float.floatToRawIntBits(s.blockFactor)
                && v[2] == Float.floatToRawIntBits(s.nightVisionEffectIntensity)
                && v[3] == Float.floatToRawIntBits(s.darknessEffectScale)
                && v[4] == Float.floatToRawIntBits(s.bossOverlayWorldDarkening)
                && v[5] == Float.floatToRawIntBits(s.brightness)
                && veil$vecEquals(s.blockLightTint, v, 6)
                && veil$vecEquals(s.skyLightColor, v, 9)
                && veil$vecEquals(s.ambientColor, v, 12)
                && veil$vecEquals(s.nightVisionColor, v, 15);
    }

    @Unique
    private static boolean veil$vecEquals(Vector3fc vec, int[] v, int i) {
        return v[i] == Float.floatToRawIntBits(vec.x())
                && v[i + 1] == Float.floatToRawIntBits(vec.y())
                && v[i + 2] == Float.floatToRawIntBits(vec.z());
    }

    @Unique
    private static void veil$capture(LightmapRenderState s, int[] v) {
        v[0] = Float.floatToRawIntBits(s.skyFactor);
        v[1] = Float.floatToRawIntBits(s.blockFactor);
        v[2] = Float.floatToRawIntBits(s.nightVisionEffectIntensity);
        v[3] = Float.floatToRawIntBits(s.darknessEffectScale);
        v[4] = Float.floatToRawIntBits(s.bossOverlayWorldDarkening);
        v[5] = Float.floatToRawIntBits(s.brightness);
        veil$captureVec(s.blockLightTint, v, 6);
        veil$captureVec(s.skyLightColor, v, 9);
        veil$captureVec(s.ambientColor, v, 12);
        veil$captureVec(s.nightVisionColor, v, 15);
    }

    @Unique
    private static void veil$captureVec(Vector3fc vec, int[] v, int i) {
        v[i] = Float.floatToRawIntBits(vec.x());
        v[i + 1] = Float.floatToRawIntBits(vec.y());
        v[i + 2] = Float.floatToRawIntBits(vec.z());
    }
}
