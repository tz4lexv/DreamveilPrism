package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

final class VeilWorldRayGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.worldRayGpuProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final String[] MODES = {"PORTABLE", "RAY_QUERY", "PORTABLE"};
    private static long started;
    private static int mode;
    private static boolean pending, complete;
    private static VeilShaderPackRuntime previous;

    private VeilWorldRayGpuProbe() {}

    static boolean enabled() {
        return ENABLED;
    }

    static void checkTimeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 240_000_000_000L)
            fail(new IllegalStateException("World ray runtime stopped or timed out"));
    }

    static void tick(VeilShaderPackRuntime active) {
        if (!ENABLED
                || complete
                || pending
                || active == previous
                || !VeilBenchmarkWorld.terrainReady()) return;
        if (active.renderedFrames() < 32) return;
        boolean hardware = mode == 1;
        if (active.usesWorldRayAcceleration() != hardware
                || VeilWorldRayScene.hasAcceleration() != hardware) {
            fail(
                    new IllegalStateException(
                            "World acceleration demand disagrees with active shader"));
            return;
        }
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil world ray proof",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                8);
        pending = true;
        try {
            active.readOutput(
                    "output",
                    readback,
                    () -> {
                        try (var mapping = readback.map(true, false)) {
                            var pixels = mapping.data();
                            boolean notReady =
                                    (pixels.get(2) & 255) == 255 && (pixels.get(1) & 255) == 0;
                            if (!notReady) {
                                for (int pixel = 0; pixel < 2; pixel++)
                                    for (int channel = 0; channel < 4; channel++) {
                                        int expected = channel == 1 || channel == 3 ? 255 : 0;
                                        if ((pixels.get(pixel * 4 + channel) & 255) != expected)
                                            throw new IllegalStateException(
                                                    "World ray GPU intersection comparison failed");
                                    }
                                ReviveMod.LOGGER.info(
                                        "Veil world ray GPU: PASS mode={} generation={} hardware={} {}",
                                        MODES[mode],
                                        active.renderedFrames(),
                                        hardware,
                                        VeilWorldRayScene.telemetry());
                                previous = active;
                                ++mode;
                                if (mode == MODES.length) {
                                    complete = true;
                                    ReviveMod.LOGGER.info(
                                            "Veil world ray GPU: COMPLETE portable/hardware/portable; real world intersections and demand reload");
                                    Minecraft.getInstance().stop();
                                } else VeilShaderService.setting("backend", MODES[mode]);
                            }
                        } catch (RuntimeException failure) {
                            fail(failure);
                        } finally {
                            readback.close();
                            pending = false;
                        }
                    });
        } catch (RuntimeException failure) {
            readback.close();
            pending = false;
            fail(failure);
        }
    }

    private static void fail(Exception failure) {
        complete = true;
        ReviveMod.LOGGER.error("Veil world ray GPU: FAIL", failure);
        Minecraft.getInstance().stop();
    }
}
