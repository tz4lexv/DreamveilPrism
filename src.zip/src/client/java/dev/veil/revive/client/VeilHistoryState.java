package dev.veil.revive.client;

public final class VeilHistoryState extends dev.veil.revive.core.scene.SceneContinuity {
    @Override
    public boolean update(
            Object scene, double x, double y, double z, float yaw, float pitch, long now) {
        return super.update(scene, x, y, z, yaw, pitch, now);
    }

    @Override
    public boolean projection(float x, float y, float z, float translation) {
        return super.projection(x, y, z, translation);
    }

    @Override
    public void invalidate() {
        super.invalidate();
    }
}
