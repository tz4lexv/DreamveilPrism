package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilServerAiCounters;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.npc.villager.Villager;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mob.class)
public abstract class MobAiTimingMixin {
    @Unique private long veil$mobAiStartNs;
    @Unique private boolean veil$mobAiVillager;

    @Inject(method = "serverAiStep", at = @At("HEAD"), require = 1)
    private void veil$beginMobAi(CallbackInfo ci) {
        if (!VeilDiagnostics.benchmarkActive()) {
            veil$mobAiStartNs = 0L;
            return;
        }
        veil$mobAiVillager = (Object) this instanceof Villager;
        veil$mobAiStartNs = System.nanoTime();
    }

    @Inject(method = "serverAiStep", at = @At("RETURN"), require = 1)
    private void veil$endMobAi(CallbackInfo ci) {
        long start = veil$mobAiStartNs;
        veil$mobAiStartNs = 0L;
        if (start != 0L && VeilDiagnostics.benchmarkActive()) {
            VeilServerAiCounters.mobAi(System.nanoTime() - start, veil$mobAiVillager);
        }
    }
}
