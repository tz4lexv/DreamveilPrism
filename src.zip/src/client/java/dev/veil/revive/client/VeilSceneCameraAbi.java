package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

public final class VeilSceneCameraAbi {
    public static final int SET = 0;
    public static final int BINDING = 13;
    public static final int SIZE = 320;

    public record Snapshot(
            Matrix4f view,
            Matrix4f projection,
            Matrix4f viewProjection,
            Matrix4f inverseViewProjection,
            double anchorX,
            double anchorY,
            double anchorZ,
            Vector3f direction,
            float lightIntensity,
            int width,
            int height) {
        public Snapshot {
            view = new Matrix4f(view);
            projection = new Matrix4f(projection);
            viewProjection = new Matrix4f(viewProjection);
            inverseViewProjection = new Matrix4f(inverseViewProjection);
            direction = new Vector3f(direction);
            if (!Double.isFinite(anchorX)
                    || !Double.isFinite(anchorY)
                    || !Double.isFinite(anchorZ)
                    || !direction.isFinite()
                    || !Float.isFinite(lightIntensity)
                    || lightIntensity < 0.0f
                    || lightIntensity > 1.0f
                    || width < 1
                    || height < 1) {
                throw new IllegalArgumentException("Invalid custom scene camera data");
            }
        }
    }

    private VeilSceneCameraAbi() {}

    public static ByteBuffer write(ByteBuffer target, Snapshot snapshot) {
        if (target.remaining() < SIZE || snapshot == null)
            throw new IllegalArgumentException(
                    "Custom scene camera data requires " + SIZE + " bytes");
        int base = target.position();
        ByteBuffer bytes = target.slice().order(ByteOrder.nativeOrder());
        matrix(bytes, 0, snapshot.view());
        matrix(bytes, 64, snapshot.projection());
        matrix(bytes, 128, snapshot.viewProjection());
        matrix(bytes, 192, snapshot.inverseViewProjection());
        position(bytes, 256, 272, snapshot.anchorX(), snapshot.anchorY(), snapshot.anchorZ());
        bytes.putFloat(288, snapshot.direction().x)
                .putFloat(292, snapshot.direction().y)
                .putFloat(296, snapshot.direction().z)
                .putFloat(300, snapshot.lightIntensity());
        bytes.putFloat(304, snapshot.width())
                .putFloat(308, snapshot.height())
                .putFloat(312, 1.0f / snapshot.width())
                .putFloat(316, 1.0f / snapshot.height());
        target.limit(base + SIZE);
        return target;
    }

    public static boolean isBinding(VeilShaderInterface.Descriptor descriptor) {
        return descriptor.set() == SET && descriptor.binding() == BINDING;
    }

    public static VeilShaderInterface.Descriptor validate(VeilShaderInterface shader) {
        List<VeilShaderInterface.Descriptor> matches =
                shader.descriptors().stream().filter(VeilSceneCameraAbi::isBinding).toList();
        if (matches.size() != 1)
            throw new IllegalArgumentException(
                    "Custom scene camera data requires exactly one set=0 binding="
                            + BINDING
                            + " uniform buffer");
        var descriptor = matches.getFirst();
        if (descriptor.descriptorType() != VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER
                || descriptor.descriptorCount() != 1
                || descriptor.runtimeArray()
                || descriptor.minimumBufferSize() != SIZE
                || descriptor.writable()) {
            throw new IllegalArgumentException(
                    "Custom scene camera binding requires a fixed readonly uniform buffer of "
                            + SIZE
                            + " bytes; actual="
                            + descriptor);
        }
        return descriptor;
    }

    private static void matrix(ByteBuffer target, int offset, Matrix4f matrix) {
        target.putFloat(offset, matrix.m00())
                .putFloat(offset + 4, matrix.m01())
                .putFloat(offset + 8, matrix.m02())
                .putFloat(offset + 12, matrix.m03());
        target.putFloat(offset + 16, matrix.m10())
                .putFloat(offset + 20, matrix.m11())
                .putFloat(offset + 24, matrix.m12())
                .putFloat(offset + 28, matrix.m13());
        target.putFloat(offset + 32, matrix.m20())
                .putFloat(offset + 36, matrix.m21())
                .putFloat(offset + 40, matrix.m22())
                .putFloat(offset + 44, matrix.m23());
        target.putFloat(offset + 48, matrix.m30())
                .putFloat(offset + 52, matrix.m31())
                .putFloat(offset + 56, matrix.m32())
                .putFloat(offset + 60, matrix.m33());
    }

    private static void position(
            ByteBuffer target, int highOffset, int lowOffset, double x, double y, double z) {
        float hx = (float) x, hy = (float) y, hz = (float) z;
        target.putFloat(highOffset, hx)
                .putFloat(highOffset + 4, hy)
                .putFloat(highOffset + 8, hz)
                .putFloat(highOffset + 12, 0.0f);
        target.putFloat(lowOffset, (float) (x - hx))
                .putFloat(lowOffset + 4, (float) (y - hy))
                .putFloat(lowOffset + 8, (float) (z - hz))
                .putFloat(lowOffset + 12, 0.0f);
    }
}
