package dev.veil.revive.client;

import dev.veil.revive.client.graphics.pipelines.NativeComputePipeline;

import java.util.List;

final class VeilComputePipeline implements AutoCloseable {
    private final VeilShaderModule module;
    private final NativeComputePipeline pipeline;

    private VeilComputePipeline(VeilShaderModule module, NativeComputePipeline pipeline) {
        this.module = module;
        this.pipeline = pipeline;
    }

    public static VeilComputePipeline create(
            VeilVulkanRuntime runtime,
            VeilSpirvBinary binary,
            List<VeilPipelineLayout.DescriptorBinding> bindings,
            List<VeilPipelineLayout.PushConstantRange> pushConstants) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        if (binary.stage() != VeilShaderStage.COMPUTE) {
            throw new IllegalArgumentException("Compute pipeline requires a COMPUTE SPIR-V module");
        }

        VeilShaderModule module = null;
        VeilPipelineLayout layout = null;
        NativeComputePipeline pipeline = null;
        try {
            module = VeilShaderModule.create(runtime, binary);
            layout = VeilPipelineLayout.createPushDescriptorSet0(runtime, bindings, pushConstants);
            var ownedModule = module;
            var ownedLayout = layout;
            pipeline =
                    NativeComputePipeline.create(
                            runtime,
                            module.handle(),
                            layout::handle,
                            binary.entryPoint(),
                            null,
                            () -> VeilVulkanPipelineCache.handle(runtime),
                            "vkCreateComputePipelines(" + binary.sourceName() + ")",
                            () -> {
                                ownedLayout.destroyNow();
                                ownedModule.destroyNow();
                            });
            return new VeilComputePipeline(module, pipeline);
        } catch (RuntimeException failure) {
            if (pipeline != null) pipeline.destroyNow();
            else {
                if (layout != null) layout.destroyNow();
                if (module != null) module.destroyNow();
            }
            throw failure;
        }
    }

    public static VeilComputePipeline createReflected(
            VeilVulkanRuntime runtime, VeilSpirvBinary binary) {
        return createReflected(runtime, binary, VeilSpirvReflection.reflect(binary));
    }

    public static VeilComputePipeline createReflected(
            VeilVulkanRuntime runtime,
            VeilSpirvBinary binary,
            VeilShaderInterface shaderInterface) {
        return createReflected(runtime, binary, shaderInterface, VeilSpecializationValues.empty());
    }

    public static VeilComputePipeline createReflected(
            VeilVulkanRuntime runtime,
            VeilSpirvBinary binary,
            VeilShaderInterface shaderInterface,
            VeilSpecializationValues values) {
        com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread();
        if (binary.stage() != VeilShaderStage.COMPUTE) {
            throw new IllegalArgumentException("Compute pipeline requires a COMPUTE SPIR-V module");
        }
        if (shaderInterface == null) throw new NullPointerException("shaderInterface");
        values.validate(shaderInterface, VeilShaderStage.COMPUTE);

        VeilShaderModule module = null;
        VeilPipelineLayout layout = null;
        NativeComputePipeline pipeline = null;
        try (var specialization = values.nativeData()) {
            module = VeilShaderModule.create(runtime, binary);
            layout = VeilPipelineLayout.createFromReflection(runtime, shaderInterface);
            var ownedModule = module;
            var ownedLayout = layout;
            pipeline =
                    NativeComputePipeline.create(
                            runtime,
                            module.handle(),
                            layout::handle,
                            binary.entryPoint(),
                            specialization.info(),
                            () -> VeilVulkanPipelineCache.handle(runtime),
                            "vkCreateComputePipelines(reflected " + binary.sourceName() + ")",
                            () -> {
                                ownedLayout.destroyNow();
                                ownedModule.destroyNow();
                            });
            return new VeilComputePipeline(module, pipeline);
        } catch (RuntimeException failure) {
            if (pipeline != null) pipeline.destroyNow();
            else {
                if (layout != null) layout.destroyNow();
                if (module != null) module.destroyNow();
            }
            throw failure;
        }
    }

    public long handle() {
        return pipeline.handle();
    }

    public long layout() {
        return pipeline.layout();
    }

    public String shaderHash() {
        return module.binary().sha256();
    }

    @Override
    public void close() {
        pipeline.close();
    }
}
