package dev.veil.revive.client;

import org.lwjgl.util.shaderc.Shaderc;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public final class VeilSpirvTools {
    public enum Mode {
        RELEASE,
        DEBUG
    }

    private final Path validator;
    private final Path optimizer;
    private final Mode mode;
    private final String identity;

    public VeilSpirvTools(Mode mode) throws IOException {
        this.mode = mode;
        boolean disabled = Boolean.getBoolean("veil.disableSpirvTools");
        boolean required = Boolean.getBoolean("veil.requireSpirvTools");
        if (disabled && required)
            throw new IOException("SPIRV-Tools cannot be both disabled and required");
        Path selectedValidator = disabled ? null : find("spirv-val", required);
        Path selectedOptimizer =
                mode == Mode.RELEASE && selectedValidator != null
                        ? find("spirv-opt", required)
                        : null;

        if (mode == Mode.RELEASE && selectedOptimizer == null) selectedValidator = null;
        validator = selectedValidator;
        optimizer = selectedOptimizer;
        String nativeLibrary = Shaderc.getLibrary().getPath();
        if (nativeLibrary == null || !Files.isRegularFile(Path.of(nativeLibrary))) {
            throw new IOException("Cannot fingerprint the loaded shaderc library");
        }
        identity =
                "shaderc="
                        + VeilShaderAssets.hash(Files.readAllBytes(Path.of(nativeLibrary)))
                        + ";validator="
                        + (validator == null ? "INTERNAL" : version(validator))
                        + ";optimizer="
                        + (optimizer == null
                                ? (mode == Mode.RELEASE ? "SHADERC" : "NONE")
                                : version(optimizer))
                        + ";target=vulkan1.2/spirv1.5;mode="
                        + mode
                        + ";recipe=-O,preserve-bindings,preserve-interface,preserve-spec-constants;defines=preprocessed";
    }

    public String identity() {
        return identity;
    }

    public Mode mode() {
        return mode;
    }

    public boolean external() {
        return validator != null;
    }

    public VeilSpirvBinary compile(String name, String source, VeilShaderStage stage)
            throws IOException {
        return process(
                VeilSpirvCompiler.compile(
                        name,
                        source,
                        stage,
                        "main",
                        validator == null && mode == Mode.RELEASE,
                        mode == Mode.DEBUG));
    }

    public VeilSpirvBinary process(VeilSpirvBinary input) throws IOException {
        if (validator == null) {

            VeilSpirvReflection.reflect(input);
            return input;
        }
        Path directory = Files.createTempDirectory("veil-spirv-");
        Path original = directory.resolve("input.spv"),
                output = directory.resolve("output.spv"),
                log = directory.resolve("tool.log");
        try {
            Files.write(original, input.unsafeCode());
            run(
                    List.of(validator.toString(), "--target-env", "vulkan1.2", original.toString()),
                    log);
            var before = VeilSpirvReflection.reflect(input);
            if (mode == Mode.DEBUG) return input;
            run(
                    List.of(
                            optimizer.toString(),
                            "--target-env=vulkan1.2",
                            "-O",
                            "--preserve-bindings",
                            "--preserve-interface",
                            "--preserve-spec-constants",
                            original.toString(),
                            "-o",
                            output.toString()),
                    log);
            if (Files.size(output) > VeilShaderAssets.MAX_SHADER_ASSET_BYTES)
                throw new IOException("Optimized shader exceeds 4 MiB");
            run(List.of(validator.toString(), "--target-env", "vulkan1.2", output.toString()), log);
            var result =
                    new VeilSpirvBinary(
                            Files.readAllBytes(output),
                            input.stage(),
                            input.sourceName(),
                            input.entryPoint(),
                            input.sha256());
            requireInterface(before, VeilSpirvReflection.reflect(result), input.sourceName());
            return result;
        } finally {
            Files.deleteIfExists(original);
            Files.deleteIfExists(output);
            Files.deleteIfExists(log);
            Files.deleteIfExists(directory);
        }
    }

    static void requireInterface(
            VeilShaderInterface before, VeilShaderInterface after, String name) {
        if (!abi(before).equals(abi(after)))
            throw new IllegalArgumentException(
                    name + ": SPIR-V optimization changed the declared interface");
    }

    private static List<String> abi(VeilShaderInterface value) {
        var result = new ArrayList<String>();
        for (var d : value.descriptors())
            result.add(
                    "D:"
                            + d.set()
                            + ":"
                            + d.binding()
                            + ":"
                            + d.descriptorType()
                            + ":"
                            + d.descriptorCount()
                            + ":"
                            + d.runtimeArray()
                            + ":"
                            + d.stageFlags()
                            + ":"
                            + d.readable()
                            + ":"
                            + d.writable()
                            + ":"
                            + d.minimumBufferSize()
                            + ":"
                            + d.imageType());
        for (var p : value.pushConstants())
            result.add(
                    "P:" + p.offset() + ":" + p.size() + ":" + p.stageFlags() + ":" + p.members());
        for (var i : value.stageInputs()) result.add("I:" + io(i));
        for (var i : value.stageOutputs()) result.add("O:" + io(i));
        for (var s : value.specializationConstants())
            result.add(
                    "S:"
                            + s.constantId()
                            + ":"
                            + s.stageFlags()
                            + ":"
                            + s.baseType()
                            + ":"
                            + s.bitWidth());
        return result.stream().sorted().toList();
    }

    private static String io(VeilShaderInterface.StageIo i) {
        return i.location()
                + ":"
                + i.component()
                + ":"
                + i.baseType()
                + ":"
                + i.bitWidth()
                + ":"
                + i.vectorSize()
                + ":"
                + i.columns()
                + ":"
                + i.arrayElements()
                + ":"
                + i.stageFlags();
    }

    private static Path find(String name, boolean required) throws IOException {
        String executable =
                name
                        + (System.getProperty("os.name", "")
                                        .toLowerCase(Locale.ROOT)
                                        .contains("win")
                                ? ".exe"
                                : "");
        String configured = System.getProperty("veil.spirvTools");
        if (configured != null) {
            Path path = Path.of(configured).resolve(executable).toAbsolutePath();
            if (!Files.isRegularFile(path))
                throw new IOException("Missing configured SPIRV-Tools executable: " + path);
            return path;
        }
        String sdk = System.getenv("VULKAN_SDK");
        if (sdk != null)
            for (String bin : List.of("Bin", "bin")) {
                Path path = Path.of(sdk, bin, executable);
                if (Files.isRegularFile(path)) return path.toAbsolutePath();
            }
        for (String directory :
                System.getenv().getOrDefault("PATH", "").split(java.io.File.pathSeparator)) {
            if (directory.isBlank()) continue;
            Path path = Path.of(directory).resolve(executable);
            if (Files.isRegularFile(path)) return path.toAbsolutePath();
        }
        if (required)
            throw new IOException(
                    "SPIRV-Tools "
                            + executable
                            + " UNAVAILABLE; install Vulkan SDK or set -Dveil.spirvTools=<bin directory>");
        return null;
    }

    private static String version(Path tool) throws IOException {
        Path log = Files.createTempFile("veil-spirv-version-", ".log");
        try {
            return run(List.of(tool.toString(), "--version"), log).trim();
        } finally {
            Files.deleteIfExists(log);
        }
    }

    private static String run(List<String> command, Path log) throws IOException {
        Process process =
                new ProcessBuilder(command)
                        .redirectErrorStream(true)
                        .redirectOutput(log.toFile())
                        .start();
        try {
            if (!process.waitFor(30, TimeUnit.SECONDS))
                throw new IOException("SPIRV-Tools timed out: " + command.getFirst());
            String diagnostic;
            try (var stream = Files.newInputStream(log)) {
                diagnostic =
                        new String(
                                stream.readNBytes(32768), java.nio.charset.StandardCharsets.UTF_8);
            }
            if (process.exitValue() != 0)
                throw new IOException("SPIRV-Tools rejected shader: " + diagnostic);
            return diagnostic;
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new IOException("SPIRV-Tools interrupted", interrupted);
        } finally {
            if (process.isAlive()) {
                process.destroyForcibly();
                try {
                    process.waitFor(5, TimeUnit.SECONDS);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}
