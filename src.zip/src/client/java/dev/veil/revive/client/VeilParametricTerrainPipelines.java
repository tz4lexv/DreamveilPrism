package dev.veil.revive.client;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

import java.util.EnumMap;

final class VeilParametricTerrainPipelines {
    private static final EnumMap<ChunkSectionLayer, RenderPipeline[][]> PIPELINES =
            new EnumMap<>(ChunkSectionLayer.class);
    private static final RenderPipeline[] DEPTH = new RenderPipeline[4];
    private static Object device;
    private static boolean directValidated;

    private VeilParametricTerrainPipelines() {}

    private static void initialize() {
        if (!PIPELINES.isEmpty()) return;
        var tables = dev.veil.revive.client.terrain.indirect.ParametricPipelineFactory.create();
        PIPELINES.putAll(tables.pipelines());
        System.arraycopy(tables.depth(), 0, DEPTH, 0, DEPTH.length);
    }

    static void validate(boolean directAvailable) {
        if (!VeilParametricTerrainArena.enabled()
                || device == RenderSystem.getDevice() && (!directAvailable || directValidated))
            return;
        initialize();
        boolean valid = true;
        for (var variants : PIPELINES.values())
            for (var formats : variants)
                for (int d = 0; d < 2; d++)
                    if (d == 0 || directAvailable)
                        valid &= RenderSystem.getDevice().precompilePipeline(formats[d]).isValid();
        for (var pipeline : DEPTH)
            valid &= RenderSystem.getDevice().precompilePipeline(pipeline).isValid();
        if (!valid) {
            VeilParametricTerrainArena.disable();
            dev.veil.revive.ReviveMod.LOGGER.warn(
                    "Parametric terrain pipelines unavailable; preserving native terrain");
        }
        device = RenderSystem.getDevice();
        directValidated = directAvailable;
    }

    static RenderPipeline select(int slot, ChunkSectionLayer layer, boolean direct) {
        return PIPELINES.get(layer)[slot][direct ? 1 : 0];
    }

    static RenderPipeline depth(int slot) {
        return DEPTH[slot];
    }
}
