package dev.veil.revive.client.graphics.resources;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.vertex.StagingBuffer;

import net.minecraft.client.renderer.MappableRingBuffer;

import java.nio.ByteBuffer;

public class MinecraftStagingRing extends StagingBuffer {
    private final MappableRingBuffer ring;
    private GpuBuffer current;
    private GpuBufferSlice.MappedView mapping;
    private ByteBuffer bytes;

    protected MinecraftStagingRing(String name, int size) {
        ring =
                new MappableRingBuffer(
                        () -> name, GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC, size);
        remap();
    }

    private void remap() {
        current = ring.currentBuffer();
        mapping = current.map(false, true);
        bytes = mapping.data();
    }

    @Override
    protected ByteBuffer getWriteBuffer() {
        return bytes;
    }

    @Override
    protected void copyTo(
            CommandEncoder encoder,
            GpuBuffer destination,
            long destinationOffset,
            long sourceOffset,
            long size) {
        encoder.copyToBuffer(
                current.slice(sourceOffset, size), destination.slice(destinationOffset, size));
    }

    @Override
    protected void rotateBuffer() {
        mapping.close();
        ring.rotate();
        remap();
    }

    @Override
    public void close() {
        mapping.close();
        ring.close();
    }
}
