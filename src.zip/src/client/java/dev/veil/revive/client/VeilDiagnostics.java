package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.ReviveConfig;
import dev.veil.revive.core.RollingSampleWindow;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class VeilDiagnostics {
    private static final dev.veil.revive.core.diagnostics.FrameTimingSamples TIMINGS =
            new dev.veil.revive.core.diagnostics.FrameTimingSamples();

    private static volatile boolean bypassed;
    private static volatile boolean detailedOverlay;
    private static List<String> cachedDetails = List.of();
    private static long detailsExpireNs;
    private static long benchmarkOrdinal;

    private static volatile Benchmark benchmark;
    private static BenchmarkReport lastBenchmark;

    private VeilDiagnostics() {}

    public static boolean bypassed() {
        return bypassed;
    }

    public static boolean detailedOverlay() {
        return detailedOverlay;
    }

    public static boolean benchmarkActive() {
        return benchmark != null;
    }

    public static BenchmarkReport lastBenchmark() {
        return lastBenchmark;
    }

    public static void toggleBypass(Minecraft client) {
        if (VeilSubmissionBenchmark.active()) {
            message(
                    client,
                    "Veil submission benchmark is controlling the renderer; cancel it first.");
            return;
        }
        if (benchmark != null) {
            message(client, "Veil benchmark is controlling bypass; cancel benchmark first.");
            return;
        }
        setBypassed(!bypassed, client, true);
    }

    public static void toggleDetailedOverlay(Minecraft client) {
        detailedOverlay = !detailedOverlay;
        message(client, "Veil diagnostics: " + (detailedOverlay ? "DETAILS ON" : "DETAILS OFF"));
    }

    public static void setBypassed(boolean value, Minecraft client, boolean announce) {
        if (bypassed == value) return;
        bypassed = value;
        VeilTerrainDrawBridge.invalidateAll();

        if (announce) {
            TIMINGS.clearFrameIntervals();
            TIMINGS.clearLongFrameIntervals();
            TIMINGS.clearWorldRenderCpu();
            VeilTechniqueCounters.reset();
            VeilTerrainDrawBridge.resetCounters();
            VeilFallbackTracker.reset();
            VeilLatencyController.resetCounters();
            VeilEntityPipelineCounters.reset();
            TIMINGS.resetClock(true);
            message(
                    client,
                    value
                            ? "Veil Renderer: BYPASSED — Minecraft path is being used for A/B comparison."
                            : "Veil Renderer: ACTIVE — optimizations re-enabled.");
        }
    }

    public static void onFrameStart() {
        long now = System.nanoTime();
        TIMINGS.onFrameStart(now);
        VeilCameraSweepProbe.onFrameStart(TIMINGS.lastFrameIntervalMs(), now);

        Benchmark current = benchmark;
        if (current != null) current.onFrameStart(now);
        VeilSubmissionBenchmark.onFrameStart(now);
    }

    public static void onFrameEnd(double worldRenderCpuMs) {
        TIMINGS.onWorldRenderEnd(worldRenderCpuMs);
        VeilCameraSweepProbe.onFrameEnd(worldRenderCpuMs);
        Benchmark current = benchmark;
        if (current != null) current.onWorldRenderEnd(worldRenderCpuMs);
        VeilSubmissionBenchmark.onWorldRenderEnd(worldRenderCpuMs);
        VeilVisualValidation.onRenderedFrame();
    }

    public static void onClientTick(Minecraft client) {
        Benchmark current = benchmark;
        if (current != null) {
            VeilEntityPipelineCounters.sampleIntegratedServer(client);
            current.tick(client);
            if (current.finished) {
                benchmark = null;
                lastBenchmark = current.report;
            }
        }
        VeilSubmissionBenchmark.onClientTick(client);
        VeilVisualValidation.onClientTick(client);
        if (ReviveRuntime.instrumentationActive()) VeilLiveTelemetry.onClientTick(client);
    }

    public static RollingSampleWindow.Snapshot frameIntervals() {
        return TIMINGS.frameIntervals();
    }

    public static RollingSampleWindow.Snapshot longFrameIntervals() {
        return TIMINGS.longFrameIntervals();
    }

    public static RollingSampleWindow.Snapshot worldRenderCpu() {
        return TIMINGS.worldRenderCpu();
    }

    public static double lastFrameIntervalMs() {
        return TIMINGS.lastFrameIntervalMs();
    }

    public static String evidenceState() {
        if (bypassed) return "BYPASSED";
        VeilTechniqueCounters.Snapshot c = VeilTechniqueCounters.snapshot();
        boolean effective =
                c.skippedVertexBinds() > 0
                        || c.skippedIndexBinds() > 0
                        || c.terrainCacheReuses() > 0;
        if (effective) return "ACTIVE";
        if (VeilTerrainDrawBridge.pathActive()) return "ACTIVE";
        if (c.terrainBridgeFallbacks() > 0) return "FALLBACK";
        return "IDLE";
    }

    public static void startBenchmark(Minecraft client) {
        if (benchmark != null) {
            message(client, "Veil benchmark is already running.");
            return;
        }
        if (VeilSubmissionBenchmark.active()) {
            message(client, "Veil submission benchmark is running; cancel it first.");
            return;
        }
        if (client.player == null) {
            message(client, "Enter a world before starting the Veil benchmark.");
            return;
        }
        if (VeilVisualValidation.active()) {
            message(client, "Visual validation is running; wait for it to finish first.");
            return;
        }

        boolean startsWithVeil = (benchmarkOrdinal++ & 1L) == 0L;

        VeilServerAiCounters.reset();
        VeilAiCadence.resetTelemetry();
        benchmark = new Benchmark(client, bypassed, startsWithVeil);
        benchmark.begin(client);
    }

    public static void cancelBenchmark(Minecraft client) {
        Benchmark current = benchmark;
        if (current == null) {
            message(client, "No Veil benchmark is running.");
            return;
        }
        current.cancel(client, "cancelled by user");
        benchmark = null;
    }

    public static String benchmarkStatus() {
        Benchmark current = benchmark;
        if (current == null) {
            return lastBenchmark == null ? "benchmark idle" : lastBenchmark.shortResult();
        }
        return current.status();
    }

    public static void resetEvidence(Minecraft client) {
        TIMINGS.clearFrameIntervals();
        TIMINGS.clearLongFrameIntervals();
        TIMINGS.clearWorldRenderCpu();
        VeilTechniqueCounters.reset();
        VeilTerrainDrawBridge.resetCounters();
        VeilFallbackTracker.reset();
        VeilEntityPipelineCounters.reset();
        VeilServerAiCounters.reset();
        VeilAiCadence.resetTelemetry();
        TIMINGS.resetClock(true);
        message(client, "Veil diagnostic windows and counters reset.");
    }

    public static void startVisualValidation(Minecraft client) {
        if (VeilSubmissionBenchmark.active()) {
            message(client, "Cancel the submission benchmark before visual validation.");
            return;
        }
        if (benchmark != null) {
            message(client, "Cancel the benchmark before visual validation.");
            return;
        }
        VeilVisualValidation.start(client);
    }

    public static List<String> detailedLines() {
        long now = System.nanoTime();
        if (now < detailsExpireNs) return cachedDetails;
        List<String> out = new ArrayList<>();
        RollingSampleWindow.Snapshot interval = frameIntervals();
        RollingSampleWindow.Snapshot render = worldRenderCpu();
        VeilTechniqueCounters.Snapshot tech = VeilTechniqueCounters.snapshot();
        VeilFallbackTracker.Snapshot fallback = VeilFallbackTracker.snapshot();
        VeilMinecraftTerrainBridge.Snapshot terrain = VeilMinecraftTerrainBridge.latest();

        dev.veil.revive.client.diagnostics.OverlayFormatter.append(
                out,
                interval,
                render,
                tech,
                fallback,
                terrain,
                VeilTerrainDrawBridge.counters(),
                VeilFaceVisibilityCache.snapshot(),
                VeilTerrainDrawBridge.sharedWork());

        if (benchmark != null || lastBenchmark != null) {
            out.add("\u00A7eBenchmark: " + benchmarkStatus() + "\u00A7r");
        }
        if (VeilSubmissionBenchmark.active()) {
            out.add("\u00A7eSubmission benchmark: " + VeilSubmissionBenchmark.status() + "\u00A7r");
        }
        if (VeilVisualValidation.active() || VeilVisualValidation.lastResult() != null) {
            out.add("\u00A7eVisual: " + VeilVisualValidation.status() + "\u00A7r");
        }
        out.add("\u00A78F8 bypass | F9 proof benchmark | F10 details | /veil status\u00A7r");
        cachedDetails = List.copyOf(out);
        detailsExpireNs = now + 250_000_000L;
        return cachedDetails;
    }

    static void message(Minecraft client, String text) {
        detailsExpireNs = 0L;
        if (client != null && client.player != null) {
            client.player.sendSystemMessage(Component.literal(text));
        }
        ReviveMod.LOGGER.info(text);
    }

    private static final class Benchmark {
        private static final long GLOBAL_WARMUP_NS = 5_000_000_000L;
        private static final long BLOCK_WARMUP_NS = 2_000_000_000L;
        private static final long MEASURE_NS = 6_000_000_000L;

        private final boolean restoreBypass;
        private final CameraStamp origin;
        private final boolean[] order;
        private final List<BlockResult> completed = new ArrayList<>(4);

        private Phase phase = Phase.GLOBAL_WARMUP;
        private int blockIndex;
        private long phaseStartNs;
        private long lastFrameStartNs;
        private BlockAccumulator activeBlock;
        private boolean finished;
        private BenchmarkReport report;

        Benchmark(Minecraft client, boolean restoreBypass, boolean startsWithVeil) {
            this.restoreBypass = restoreBypass;
            this.origin = CameraStamp.capture(client);
            this.order =
                    startsWithVeil
                            ? new boolean[] {true, false, false, true}
                            : new boolean[] {false, true, true, false};
        }

        void begin(Minecraft client) {
            TIMINGS.clearFrameIntervals();
            TIMINGS.clearWorldRenderCpu();
            VeilTechniqueCounters.reset();
            VeilTerrainDrawBridge.resetCounters();
            VeilFallbackTracker.reset();
            VeilLatencyController.resetCounters();
            VeilEntityPipelineCounters.reset();
            TIMINGS.resetClock(false);

            applyBlockState(client, 0);
            phase = Phase.GLOBAL_WARMUP;
            phaseStartNs = System.nanoTime();
            lastFrameStartNs = 0L;
            String orderText =
                    order[0] ? "ON -> BYPASS -> BYPASS -> ON" : "BYPASS -> ON -> ON -> BYPASS";
            message(
                    client,
                    "Veil proof benchmark started ("
                            + orderText
                            + "). Keep camera/player still for ~37 seconds.");
        }

        void onFrameStart(long nowNs) {
            if (phase != Phase.MEASURE || activeBlock == null) {
                lastFrameStartNs = 0L;
                return;
            }
            if (lastFrameStartNs != 0L) {
                activeBlock.frameIntervals.add((nowNs - lastFrameStartNs) / 1_000_000.0);
            }
            lastFrameStartNs = nowNs;
        }

        void onWorldRenderEnd(double renderMs) {
            if (phase == Phase.MEASURE && activeBlock != null) {
                activeBlock.worldRender.add(renderMs);
            }
        }

        void tick(Minecraft client) {
            if (!origin.matches(client)) {
                cancel(client, "camera/player moved; proof result would not be controlled");
                return;
            }

            long elapsed = System.nanoTime() - phaseStartNs;
            switch (phase) {
                case GLOBAL_WARMUP -> {
                    if (elapsed >= GLOBAL_WARMUP_NS) beginBlockWarmup(client);
                }
                case BLOCK_WARMUP -> {
                    if (elapsed >= BLOCK_WARMUP_NS) beginMeasure();
                }
                case MEASURE -> {
                    if (elapsed >= MEASURE_NS) finishMeasure(client);
                }
            }
        }

        private void applyBlockState(Minecraft client, int index) {
            setBypassed(!order[index], client, false);
        }

        private void beginBlockWarmup(Minecraft client) {
            applyBlockState(client, blockIndex);
            phase = Phase.BLOCK_WARMUP;
            phaseStartNs = System.nanoTime();
            lastFrameStartNs = 0L;
        }

        private void beginMeasure() {

            VeilTechniqueCounters.reset();
            VeilTerrainDrawBridge.resetCounters();
            VeilFallbackTracker.reset();
            activeBlock = new BlockAccumulator(blockIndex + 1, order[blockIndex]);
            activeBlock.evidenceStart = VeilBenchmarkEvidence.capture();
            activeBlock.gpuWorldStart = VeilGpuProfiler.totals(VeilGpuProfiler.Pass.WORLD_RENDER);
            activeBlock.gpuBreakdownStart = VeilGpuProfiler.snapshot();
            phase = Phase.MEASURE;
            phaseStartNs = System.nanoTime();
            lastFrameStartNs = 0L;
        }

        private void finishMeasure(Minecraft client) {
            VeilBenchmarkEvidence.Point end = VeilBenchmarkEvidence.capture();
            activeBlock.evidence = activeBlock.evidenceStart.deltaTo(end);
            VeilGpuProfiler.PassTotals gpuWorld =
                    activeBlock.gpuWorldStart.deltaTo(
                            VeilGpuProfiler.totals(VeilGpuProfiler.Pass.WORLD_RENDER));
            VeilGpuProfiler.Snapshot gpuBreakdown =
                    activeBlock.gpuBreakdownStart.deltaTo(VeilGpuProfiler.snapshot());
            completed.add(activeBlock.finish(gpuWorld, gpuBreakdown));
            activeBlock = null;
            lastFrameStartNs = 0L;

            blockIndex++;
            if (blockIndex >= order.length) {
                finish(client);
                return;
            }
            beginBlockWarmup(client);
        }

        private void finish(Minecraft client) {
            setBypassed(restoreBypass, client, false);
            report = BenchmarkReport.create(completed, order[0]);
            finished = true;
            Path saved = saveReport(report);
            message(
                    client,
                    "Veil proof benchmark complete: "
                            + report.shortResult()
                            + (saved != null ? " | " + saved.getFileName() : ""));
        }

        void cancel(Minecraft client, String reason) {
            setBypassed(restoreBypass, client, false);
            finished = true;
            report = null;
            message(client, "Veil benchmark " + reason + ".");
        }

        String status() {
            long duration =
                    switch (phase) {
                        case GLOBAL_WARMUP -> GLOBAL_WARMUP_NS;
                        case BLOCK_WARMUP -> BLOCK_WARMUP_NS;
                        case MEASURE -> MEASURE_NS;
                    };
            double remaining =
                    Math.max(
                            0.0, (duration - (System.nanoTime() - phaseStartNs)) / 1_000_000_000.0);
            String block =
                    phase == Phase.GLOBAL_WARMUP
                            ? "global warmup"
                            : "block "
                                    + (blockIndex + 1)
                                    + "/4 "
                                    + (order[blockIndex] ? "Veil ON" : "BYPASS");
            return block + " / " + phase.label + String.format(Locale.ROOT, " %.1fs", remaining);
        }

        private enum Phase {
            GLOBAL_WARMUP("warmup"),
            BLOCK_WARMUP("settling"),
            MEASURE("measuring");

            final String label;

            Phase(String label) {
                this.label = label;
            }
        }
    }

    private static final class BlockAccumulator {
        final int ordinal;
        final boolean veilEnabled;
        final List<Double> frameIntervals = new ArrayList<>();
        final List<Double> worldRender = new ArrayList<>();
        VeilBenchmarkEvidence.Point evidenceStart;
        VeilBenchmarkEvidence.Delta evidence;
        VeilGpuProfiler.PassTotals gpuWorldStart;
        VeilGpuProfiler.Snapshot gpuBreakdownStart;

        BlockAccumulator(int ordinal, boolean veilEnabled) {
            this.ordinal = ordinal;
            this.veilEnabled = veilEnabled;
        }

        BlockResult finish(
                VeilGpuProfiler.PassTotals gpuWorld, VeilGpuProfiler.Snapshot gpuBreakdown) {
            List<Double> frame = List.copyOf(frameIntervals);
            List<Double> render = List.copyOf(worldRender);
            return new BlockResult(
                    ordinal,
                    veilEnabled,
                    frame,
                    render,
                    SampleStats.of(frame),
                    SampleStats.of(render),
                    gpuWorld.averageMs(),
                    gpuWorld.samples(),
                    gpuBreakdown,
                    evidence);
        }
    }

    private record BlockResult(
            int ordinal,
            boolean veilEnabled,
            List<Double> frameSamples,
            List<Double> renderSamples,
            SampleStats frame,
            SampleStats render,
            double gpuWorldMs,
            long gpuWorldSamples,
            VeilGpuProfiler.Snapshot gpuBreakdown,
            VeilBenchmarkEvidence.Delta evidence) {}

    public record BenchmarkReport(
            List<BlockResult> blocks,
            SampleStats veilFrame,
            SampleStats bypassFrame,
            SampleStats veilRender,
            SampleStats bypassRender,
            VeilBenchmarkEvidence.Delta veilEvidence,
            VeilBenchmarkEvidence.Delta bypassEvidence,
            boolean startedWithVeil,
            double fpsGainPercent,
            double frameMedianGainPercent,
            double renderCpuReductionPercent,
            double renderCpuMedianReductionPercent) {

        static BenchmarkReport create(List<BlockResult> blocks, boolean startedWithVeil) {
            List<Double> veilIntervals = new ArrayList<>();
            List<Double> bypassIntervals = new ArrayList<>();
            List<Double> veilRender = new ArrayList<>();
            List<Double> bypassRender = new ArrayList<>();
            VeilBenchmarkEvidence.Delta vEvidence = null;
            VeilBenchmarkEvidence.Delta bEvidence = null;

            for (BlockResult block : blocks) {
                if (block.veilEnabled) {
                    veilIntervals.addAll(block.frameSamples);
                    veilRender.addAll(block.renderSamples);
                    vEvidence = vEvidence == null ? block.evidence : vEvidence.plus(block.evidence);
                } else {
                    bypassIntervals.addAll(block.frameSamples);
                    bypassRender.addAll(block.renderSamples);
                    bEvidence = bEvidence == null ? block.evidence : bEvidence.plus(block.evidence);
                }
            }

            SampleStats vFrame = SampleStats.of(veilIntervals);
            SampleStats bFrame = SampleStats.of(bypassIntervals);
            SampleStats vRender = SampleStats.of(veilRender);
            SampleStats bRender = SampleStats.of(bypassRender);

            double vFps = vFrame.avg > 0.0 ? 1000.0 / vFrame.avg : 0.0;
            double bFps = bFrame.avg > 0.0 ? 1000.0 / bFrame.avg : 0.0;
            double fpsGain = percentRatio(vFps, bFps);
            double frameMedianGain =
                    bFrame.p50 > 0.0 ? (1.0 - vFrame.p50 / bFrame.p50) * 100.0 : 0.0;
            double cpuReduction =
                    bRender.avg > 0.0 ? (1.0 - vRender.avg / bRender.avg) * 100.0 : 0.0;
            double cpuMedianReduction =
                    bRender.p50 > 0.0 ? (1.0 - vRender.p50 / bRender.p50) * 100.0 : 0.0;

            return new BenchmarkReport(
                    List.copyOf(blocks),
                    vFrame,
                    bFrame,
                    vRender,
                    bRender,
                    vEvidence,
                    bEvidence,
                    startedWithVeil,
                    fpsGain,
                    frameMedianGain,
                    cpuReduction,
                    cpuMedianReduction);
        }

        public String shortResult() {
            double veilFps = veilFrame.avg > 0.0 ? 1000.0 / veilFrame.avg : 0.0;
            double bypassFps = bypassFrame.avg > 0.0 ? 1000.0 / bypassFrame.avg : 0.0;
            return String.format(
                    Locale.ROOT,
                    "Veil %.1f FPS vs bypass %.1f FPS (%+.1f%%), render CPU reduction %+.1f%%",
                    veilFps,
                    bypassFps,
                    fpsGainPercent,
                    renderCpuReductionPercent);
        }

        public String fullText() {
            ReviveConfig cfg = ReviveRuntime.config();
            StringBuilder out = new StringBuilder(16_384);
            out.append("========== VEIL RUNTIME PROOF + A/B BENCHMARK ==========\n");
            out.append("Veil Renderer: ").append(VeilRendererInfo.VERSION).append('\n');
            out.append("Veil: ").append(VeilRendererInfo.VEIL_VERSION).append('\n');
            out.append("Package revision: ").append(VeilRendererInfo.PACKAGE_REVISION).append('\n');
            out.append("Minecraft target: 26.2 / Fabric\n");
            out.append("Java: ").append(System.getProperty("java.version")).append('\n');
            out.append("OS: ")
                    .append(System.getProperty("os.name"))
                    .append(' ')
                    .append(System.getProperty("os.version"))
                    .append(" / ")
                    .append(System.getProperty("os.arch"))
                    .append('\n');
            out.append("CPU logical processors: ")
                    .append(Runtime.getRuntime().availableProcessors())
                    .append('\n');
            out.append("Benchmark order: ")
                    .append(
                            startedWithVeil
                                    ? "ON -> BYPASS -> BYPASS -> ON (ABBA)"
                                    : "BYPASS -> ON -> ON -> BYPASS (BAAB)")
                    .append('\n');
            out.append("Warmup: 5 s global + 2 s before each block; measurement: 6 s x 4 blocks\n");
            out.append("Camera guard: position <= 0.25 blocks, yaw/pitch <= 0.5 degrees\n");
            out.append(
                    "Benchmark latency policy: low-latency fence pacing is suspended for BOTH states to isolate renderer throughput\n\n");

            appendConfig(out, cfg);
            out.append('\n');

            out.append("--- CONTROLLED BLOCKS ---\n");
            for (BlockResult block : blocks) appendBlock(out, block);

            out.append("\n--- AGGREGATE PERFORMANCE ---\n");
            appendPerf(out, "VEIL ON", veilFrame, veilRender);
            appendPerf(out, "BYPASS", bypassFrame, bypassRender);
            appendGpuWorldAggregate(out, true);
            appendGpuWorldAggregate(out, false);
            out.append(
                    String.format(
                            Locale.ROOT,
                            "FPS change (avg frame interval): %+.2f%%\n",
                            fpsGainPercent));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Frame median improvement: %+.2f%%\n",
                            frameMedianGainPercent));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "World render CPU reduction (avg): %+.2f%%\n",
                            renderCpuReductionPercent));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "World render CPU reduction (median): %+.2f%%\n",
                            renderCpuMedianReductionPercent));

            out.append("\n--- V45 RENDERSECTION RELOCATION + TERRAIN PROOF ---\n");
            appendGpuTerrainBreakdown(out);

            out.append("\n--- ENTITY PIPELINE DIAGNOSTICS ---\n");
            appendEntityPipeline(out, "VEIL ON", veilEvidence.entities());
            appendEntityPipeline(out, "BYPASS", bypassEvidence.entities());
            out.append(
                    "Entity extraction loop includes renderer lookup/state creation/extract/finalize for surviving entities; submit is measured separately.\n");
            out.append(
                    "Integrated-server tick samples are the server rolling average observed on client ticks; multiplayer has zero samples.\n");

            out.append("\n--- SERVER / VILLAGER AI DIAGNOSTICS ---\n");
            appendServerAi(out, "VEIL ON", veilEvidence.serverAi());
            appendServerAi(out, "BYPASS", bypassEvidence.serverAi());
            appendServerAi(out, "ALL F9", veilEvidence.serverAi().plus(bypassEvidence.serverAi()));
            out.append(
                    "Server AI sub-timings overlap by design: villager Brain/Sensor/Navigation/path creation are contained inside villager entity/Mob AI ticks and must not be summed.\n");
            out.append(
                    "Server timing is asynchronous to the client-side block transition; one server tick can straddle a boundary, so ALL F9 is the most robust attribution view.\n");

            out.append("\n--- V45 VEIL ON FULL-FRAME TELEMETRY ---\n");
            out.append(VeilFullFrameTelemetry.analysis(veilEvidence.fullFrame()));
            out.append("\n--- V45 BYPASS FULL-FRAME TELEMETRY ---\n");
            out.append(VeilFullFrameTelemetry.analysis(bypassEvidence.fullFrame()));
            out.append("\n--- V45 RAW GPU PASS / PIPELINE SESSION TELEMETRY ---\n");
            out.append(VeilFullFrameTelemetry.telemetry());

            out.append("\n--- VEIL ON: EXECUTION + EFFECT EVIDENCE ---\n");
            appendEvidence(out, veilEvidence, cfg, true);

            out.append("\n--- BYPASS: CONTROL EVIDENCE ---\n");
            appendEvidence(out, bypassEvidence, cfg, false);

            out.append("\n--- TECHNIQUE PROOF MATRIX ---\n");
            appendTechniqueMatrix(out, veilEvidence, cfg);

            out.append("\n--- CONTROL QUALITY / CONTAMINATION CHECKS ---\n");
            appendControlQuality(out);

            out.append("\n--- INTERPRETATION RULES ---\n");
            out.append(
                    "ACTIVE_EFFECT = hook executed and Veil changed real host work during measured blocks.\n");
            out.append(
                    "ACTIVE_NO_EFFECT = hook executed but no reusable/redundant work was found in this scene.\n");
            out.append(
                    "ANALYSIS_ONLY = code executed and produced classifications, but it did NOT alter rendered geometry/draws.\n");
            out.append(
                    "NO_EVENT_DURING_TEST = feature may be wired, but this benchmark did not trigger the required event.\n");
            out.append(
                    "BACKEND_REQUIRED / BRIDGE_REQUIRED / CORE_READY = not a runtime optimization in this build.\n");
            out.append(
                    "GPU world-render timestamps are non-blocking; they measure LevelRenderer.render queue span and do not include CPU fence waits or client-frame work outside world rendering.\n");
            out.append("=========================================================\n");
            return out.toString();
        }

        private void appendGpuWorldAggregate(StringBuilder out, boolean veil) {
            double weighted = 0.0;
            long samples = 0L;
            for (BlockResult block : blocks) {
                if (block.veilEnabled != veil || block.gpuWorldSamples <= 0L) continue;
                weighted += block.gpuWorldMs * block.gpuWorldSamples;
                samples += block.gpuWorldSamples;
            }
            double average = samples == 0L ? 0.0 : weighted / samples;
            out.append(
                    String.format(
                            Locale.ROOT,
                            "%s GPU world-render span: %.4f ms (%d samples)%n",
                            veil ? "VEIL ON" : "BYPASS",
                            average,
                            samples));
        }

        private void appendGpuTerrainBreakdown(StringBuilder out) {
            out.append(
                    "Timing policy: GPU spans are asynchronous and some are nested/overlapping; do not sum them as exclusive frame time.\n");
            out.append(
                    "Primary render-pass classification keeps the first pipeline identity instead of demoting mixed passes to OTHER.\n"
                            + "CommandEncoder.submit includes Minecraft Vulkan backend pacing; V45 retains the V43 timeline-semaphore pacing attribution.\n");
            appendGpuTerrainState(out, "VEIL ON", aggregateGpuBreakdown(true), veilEvidence);
            appendGpuTerrainState(out, "BYPASS", aggregateGpuBreakdown(false), bypassEvidence);
        }

        private VeilGpuProfiler.Snapshot aggregateGpuBreakdown(boolean veil) {
            VeilGpuProfiler.Snapshot total = VeilGpuProfiler.Snapshot.empty();
            for (BlockResult block : blocks) {
                if (block.veilEnabled == veil) total = total.plus(block.gpuBreakdown);
            }
            return total;
        }

        private static void appendGpuTerrainState(
                StringBuilder out,
                String label,
                VeilGpuProfiler.Snapshot gpu,
                VeilBenchmarkEvidence.Delta evidence) {
            out.append(label).append(":\n");
            appendGpuPass(
                    out, gpu, VeilGpuProfiler.Pass.HOST_TERRAIN_OPAQUE, "native opaque terrain");
            appendGpuPass(out, gpu, VeilGpuProfiler.Pass.TERRAIN_OPAQUE, "Veil opaque terrain");
            appendGpuPass(
                    out, gpu, VeilGpuProfiler.Pass.TERRAIN_TRANSLUCENT, "Veil translucent terrain");
            appendGpuPass(out, gpu, VeilGpuProfiler.Pass.HZB, "HZB total");
            appendGpuPass(out, gpu, VeilGpuProfiler.Pass.HZB_BUILD, "HZB pyramid build");
            appendGpuPass(out, gpu, VeilGpuProfiler.Pass.FRUSTUM_CULL, "GPU frustum cull");
            appendGpuPass(out, gpu, VeilGpuProfiler.Pass.HZB_CULL, "GPU HZB cull");
            appendGpuPass(
                    out, gpu, VeilGpuProfiler.Pass.OPAQUE_DIRECT_DRAWS, "opaque direct draws");
            appendGpuPass(out, gpu, VeilGpuProfiler.Pass.OPAQUE_DIRECT_MDI, "opaque direct MDI");
            appendGpuPass(out, gpu, VeilGpuProfiler.Pass.OPAQUE_FRUSTUM_MDI, "opaque frustum MDI");
            appendGpuPass(out, gpu, VeilGpuProfiler.Pass.UPLOAD, "Veil GPU upload/flush");
            appendGpuPass(
                    out, gpu, VeilGpuProfiler.Pass.AUTO_LOD_HOST_PROBE, "paired LOD host probe");
            appendGpuPass(
                    out,
                    gpu,
                    VeilGpuProfiler.Pass.AUTO_LOD_CUSTOM_PROBE,
                    "paired LOD custom probe");
            appendPairedLodDelta(out, gpu);

            var t = evidence.techniques();
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  CPU terrain prepare: %.4f ms/call | calls=%d | UBO write %.4f ms/success | validate %.4f ms/success%n",
                            t.avgPrepareMs(),
                            t.terrainPrepareCalls(),
                            t.avgUboWriteMs(),
                            t.avgValidateMs()));

            var ff = evidence.fullFrame();
            int submit = VeilFullFrameTelemetry.CpuZone.COMMAND_SUBMIT.ordinal();
            int pacing = VeilFullFrameTelemetry.CpuZone.COMMAND_SUBMIT_PACING_WAIT.ordinal();
            long submitCalls = ff.cpuCalls()[submit];
            long pacingCalls = ff.cpuCalls()[pacing];
            long submitNs = ff.cpuNs()[submit];
            long pacingNs = ff.cpuNs()[pacing];
            double submitAvg = submitCalls <= 0L ? 0.0 : submitNs / 1_000_000.0 / submitCalls;
            double pacingAvg = pacingCalls <= 0L ? 0.0 : pacingNs / 1_000_000.0 / pacingCalls;
            double pacingPerSubmit = submitCalls <= 0L ? 0.0 : pacingNs / 1_000_000.0 / submitCalls;
            double nonWaitAvg =
                    submitCalls <= 0L
                            ? 0.0
                            : Math.max(0L, submitNs - pacingNs) / 1_000_000.0 / submitCalls;
            double pacingShare =
                    submitNs <= 0L ? 0.0 : Math.min(100.0, pacingNs * 100.0 / submitNs);
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  CommandEncoder.submit total: %.4f ms/call | calls=%d%n",
                            submitAvg,
                            submitCalls));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  backend pacing wait inside submit: %.4f ms/wait | waits=%d | %.4f ms/submit contribution | %.1f%% of submit time%n",
                            pacingAvg,
                            pacingCalls,
                            pacingPerSubmit,
                            pacingShare));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  submit non-wait residual: %.4f ms/call (end/batch/queue/bookkeeping; derived)%n",
                            nonWaitAvg));
        }

        private static void appendPairedLodDelta(StringBuilder out, VeilGpuProfiler.Snapshot gpu) {
            long hostSamples = gpu.samples(VeilGpuProfiler.Pass.AUTO_LOD_HOST_PROBE);
            long customSamples = gpu.samples(VeilGpuProfiler.Pass.AUTO_LOD_CUSTOM_PROBE);
            if (hostSamples <= 0L || customSamples <= 0L) return;
            double host = gpu.averageMs(VeilGpuProfiler.Pass.AUTO_LOD_HOST_PROBE);
            double custom = gpu.averageMs(VeilGpuProfiler.Pass.AUTO_LOD_CUSTOM_PROBE);
            double delta = host <= 0.0 ? 0.0 : (custom / host - 1.0) * 100.0;
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  paired LOD custom vs host: %+.2f%% (host %.4f ms, custom %.4f ms)%n",
                            delta,
                            host,
                            custom));
        }

        private static void appendGpuPass(
                StringBuilder out,
                VeilGpuProfiler.Snapshot gpu,
                VeilGpuProfiler.Pass pass,
                String label) {
            long samples = gpu.samples(pass);
            if (samples <= 0L) {
                out.append("  ").append(label).append(": no samples\n");
                return;
            }
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  %s: %.4f ms/sample | samples=%d | total=%.4f ms%n",
                            label,
                            gpu.averageMs(pass),
                            samples,
                            gpu.totalMs(pass)));
        }

        private void appendControlQuality(StringBuilder out) {
            List<String> warnings = new ArrayList<>();

            double vVisible = veilEvidence.techniques().averageVisibleSections();
            double bVisible = bypassEvidence.techniques().averageVisibleSections();
            double visibleDelta = relativeDifference(vVisible, bVisible) * 100.0;
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Average visible sections: Veil %.2f | bypass %.2f | delta %.2f%%\n",
                            vVisible,
                            bVisible,
                            visibleDelta));
            if (visibleDelta > 2.0) warnings.add("visible section load differed by >2%");

            double vEntities = veilEvidence.entities().entitiesExtractedPerFrame();
            double bEntities = bypassEvidence.entities().entitiesExtractedPerFrame();
            double entityDelta = relativeDifference(vEntities, bEntities) * 100.0;
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Extracted entities/frame: Veil %.2f | bypass %.2f | delta %.2f%%\n",
                            vEntities,
                            bEntities,
                            entityDelta));
            if (entityDelta > 2.0) warnings.add("entity render load differed by >2%");

            long veilSceneChanges =
                    veilEvidence.techniques().sectionDirtyEvents()
                            + veilEvidence.techniques().sectionMeshUpdateEvents();
            long bypassSceneChanges =
                    bypassEvidence.techniques().sectionDirtyEvents()
                            + bypassEvidence.techniques().sectionMeshUpdateEvents();
            out.append("Section dirty/mesh-update events: Veil ")
                    .append(veilSceneChanges)
                    .append(" | bypass ")
                    .append(bypassSceneChanges)
                    .append('\n');
            if (veilSceneChanges + bypassSceneChanges > 0L)
                warnings.add("chunk/mesh activity occurred during measurement");

            out.append("GC: Veil ")
                    .append(veilEvidence.gcCollections())
                    .append(" collections / ")
                    .append(veilEvidence.gcTimeMs())
                    .append(" ms | bypass ")
                    .append(bypassEvidence.gcCollections())
                    .append(" collections / ")
                    .append(bypassEvidence.gcTimeMs())
                    .append(" ms\n");
            if (veilEvidence.gcTimeMs() > 20L || bypassEvidence.gcTimeMs() > 20L) {
                warnings.add("GC pause time exceeded 20 ms in at least one state");
            }

            double veilSpread = stateBlockSpread(true);
            double bypassSpread = stateBlockSpread(false);
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Between-block avg-frame spread: Veil %.2f%% | bypass %.2f%%\n",
                            veilSpread * 100.0,
                            bypassSpread * 100.0));
            if (veilSpread > 0.10 || bypassSpread > 0.10)
                warnings.add("same-state blocks differ by >10%");

            long bypassEffects =
                    bypassEvidence.techniques().terrainReturnOverrides()
                            + bypassEvidence.techniques().terrainCacheReuses()
                            + bypassEvidence.techniques().terrainCacheRebuilds()
                            + bypassEvidence.techniques().skippedVertexBinds()
                            + bypassEvidence.techniques().skippedIndexBinds()
                            + bypassEvidence.techniques().farAnalysisRuns()
                            + bypassEvidence.faceVisibility().hits()
                            + bypassEvidence.sharedWork().recordsReused()
                            + bypassEvidence.sharedWork().recordsCreated()
                            + bypassEvidence.entities().exactDistanceRejects()
                            + bypassEvidence.entities().sectionVisibilityRejects();
            out.append("BYPASS render-affecting/analysis effect leakage: ")
                    .append(bypassEffects == 0L ? "PASS" : "FAIL")
                    .append(" (unexpected effect counters=")
                    .append(bypassEffects)
                    .append(")\n");
            if (bypassEffects != 0L)
                warnings.add("Veil effect counters moved while BYPASS was active");

            if (veilFrame.count < 100 || bypassFrame.count < 100) {
                warnings.add("too few frame samples for a stable comparison");
            }

            boolean cacheCountersAgree =
                    veilEvidence.techniques().terrainCacheReuses()
                                    == veilEvidence.terrainBridge().cacheHits()
                            && veilEvidence.techniques().terrainCacheRebuilds()
                                    == veilEvidence.terrainBridge().cacheMisses();
            out.append("Independent cache counter agreement: ")
                    .append(cacheCountersAgree ? "PASS" : "FAIL")
                    .append('\n');
            if (!cacheCountersAgree) warnings.add("independent cache counters disagree");

            boolean bypassAccounting =
                    bypassEvidence.techniques().terrainPrepareCalls()
                            == bypassEvidence.techniques().terrainBypassSkips();
            out.append("BYPASS hook accounting (prepare calls == bypass skips): ")
                    .append(bypassAccounting ? "PASS" : "FAIL")
                    .append(" (")
                    .append(bypassEvidence.techniques().terrainPrepareCalls())
                    .append(" == ")
                    .append(bypassEvidence.techniques().terrainBypassSkips())
                    .append(")\n");
            if (!bypassAccounting)
                warnings.add("BYPASS prepare hook calls were not fully accounted as bypass skips");

            boolean overrideAgreement =
                    veilEvidence.techniques().terrainPrepareSuccesses()
                            == veilEvidence.techniques().terrainReturnOverrides();
            out.append("Prepare-success vs LevelRenderer-return-override agreement: ")
                    .append(overrideAgreement ? "PASS" : "FAIL")
                    .append('\n');
            if (!overrideAgreement)
                warnings.add("terrain prepare success did not match installed return overrides");

            boolean cacheOutcomeAgreement =
                    veilEvidence.techniques().terrainPrepareSuccesses()
                            == veilEvidence.techniques().terrainCacheReuses()
                                    + veilEvidence.techniques().terrainCacheRebuilds();
            out.append("Successful prepare vs cache outcome accounting: ")
                    .append(cacheOutcomeAgreement ? "PASS" : "FAIL")
                    .append(" (success=")
                    .append(veilEvidence.techniques().terrainPrepareSuccesses())
                    .append(", hit+miss=")
                    .append(
                            veilEvidence.techniques().terrainCacheReuses()
                                    + veilEvidence.techniques().terrainCacheRebuilds())
                    .append(")\n");
            if (!cacheOutcomeAgreement)
                warnings.add(
                        "successful terrain prepares were not fully accounted as cache hit/miss outcomes");

            long accountedPrepare =
                    veilEvidence.techniques().terrainPrepareSuccesses()
                            + veilEvidence.techniques().terrainCacheDisabledSkips()
                            + veilEvidence.techniques().terrainNoDispatcherSkips()
                            + veilEvidence.techniques().terrainBridgeFallbacks();
            boolean prepareAccounting =
                    veilEvidence.techniques().terrainPrepareCalls() == accountedPrepare;
            out.append("VEIL ON prepare-path accounting: ")
                    .append(prepareAccounting ? "PASS" : "FAIL")
                    .append(" (calls=")
                    .append(veilEvidence.techniques().terrainPrepareCalls())
                    .append(", accounted=")
                    .append(accountedPrepare)
                    .append(")\n");
            if (!prepareAccounting)
                warnings.add("Veil ON terrain prepare calls contain an unclassified exit path");

            boolean fallbackAgreement =
                    veilEvidence.techniques().terrainBridgeFallbacks()
                            == veilEvidence.terrainBridge().fallbacks();
            out.append("Independent bridge-fallback counter agreement: ")
                    .append(fallbackAgreement ? "PASS" : "FAIL")
                    .append('\n');
            if (!fallbackAgreement)
                warnings.add("independent terrain bridge fallback counters disagree");

            long candidateTotal =
                    veilEvidence.techniques().farExactCandidates()
                            + veilEvidence.techniques().farSseCandidates()
                            + veilEvidence.techniques().farVoxelCandidates()
                            + veilEvidence.techniques().farVascCandidates();
            boolean farCandidateAgreement =
                    candidateTotal == veilEvidence.techniques().farSectionsAnalyzed();
            out.append("Far-analysis section classification accounting: ")
                    .append(farCandidateAgreement ? "PASS" : "FAIL")
                    .append(" (classified=")
                    .append(candidateTotal)
                    .append(", analyzed=")
                    .append(veilEvidence.techniques().farSectionsAnalyzed())
                    .append(")\n");
            if (!farCandidateAgreement)
                warnings.add("far-analysis candidates do not account for all analyzed sections");

            long missReasons =
                    veilEvidence.techniques().cacheMissEmpty()
                            + veilEvidence.techniques().cacheMissDispatcher()
                            + veilEvidence.techniques().cacheMissSignature()
                            + veilEvidence.techniques().cacheMissPacketCount();
            boolean missReasonAgreement =
                    missReasons == veilEvidence.techniques().terrainCacheRebuilds();
            out.append("Cache rebuild vs miss-reason agreement: ")
                    .append(missReasonAgreement ? "PASS" : "FAIL")
                    .append('\n');
            if (!missReasonAgreement)
                warnings.add("cache rebuilds do not match classified miss reasons");

            if (warnings.isEmpty()) {
                out.append("CONTROL QUALITY: GOOD — no major contamination flag detected.\n");
            } else {
                out.append("CONTROL QUALITY: WARN\n");
                for (String warning : warnings) out.append("  - ").append(warning).append('\n');
            }
        }

        private double stateBlockSpread(boolean veil) {
            double a = Double.NaN;
            double b = Double.NaN;
            for (BlockResult block : blocks) {
                if (block.veilEnabled != veil) continue;
                if (!Double.isFinite(a)) a = block.frame.avg;
                else {
                    b = block.frame.avg;
                    break;
                }
            }
            if (!(a > 0.0) || !(b > 0.0)) return 0.0;
            return Math.abs(a - b) / ((a + b) * 0.5);
        }

        private static void appendConfig(StringBuilder out, ReviveConfig cfg) {
            out.append("--- CONFIG SNAPSHOT ---\n");
            out.append("enabled=").append(cfg.enabled()).append('\n');
            out.append("profile=").append(cfg.profile()).append('\n');
            out.append("profilerEnabled=").append(cfg.profilerEnabled()).append('\n');
            out.append("staticDrawPacketCache=").append(cfg.staticDrawPacketCache()).append('\n');
            out.append("farTerrainPlanning=").append(cfg.farTerrainPlanning()).append('\n');
            out.append("screenSpaceErrorPixels=").append(cfg.screenSpaceErrorPixels()).append('\n');
            out.append("vascEnabled=").append(cfg.vascEnabled()).append('\n');
            out.append("vascErrorPixels=").append(cfg.vascErrorPixels()).append('\n');
            out.append("vascSilhouetteErrorPixels=")
                    .append(cfg.vascSilhouetteErrorPixels())
                    .append('\n');
            out.append("vascMinimumConfidence=").append(cfg.vascMinimumConfidence()).append('\n');
            out.append("subpixelCollapsePixels=").append(cfg.subpixelCollapsePixels()).append('\n');
            out.append("faithfulCulling=").append(cfg.faithfulCulling()).append('\n');
            out.append("submissionMode=")
                    .append(VeilSubmissionControl.effectiveMode())
                    .append('\n');
            out.append("hzbGpuBridge legacy flag=")
                    .append(cfg.hzbGpuBridge())
                    .append(" (new path uses Vulkan capability checks)\n");
            out.append("multiDrawIndirectBridge legacy flag=")
                    .append(cfg.multiDrawIndirectBridge())
                    .append(" (new path uses Vulkan capability checks)\n");
            out.append("lowLatencyConfigured=")
                    .append(VeilVideoConfig.flag("latency.lowLatency", false))
                    .append('\n');
            out.append("aiLodConfigured=")
                    .append(VeilVideoConfig.flag("simulation.aiLod", false))
                    .append('\n');
            out.append(
                    "benchmarkLatencyPolicy=veil_low_latency_disabled_for_both_states; backend_native_pacing_remains_active\n");
            out.append(
                            "Advanced Vulkan counters: SESSION TOTALS at report creation, not measured-block deltas:\n")
                    .append(VeilIndirectTerrain.telemetry())
                    .append(VeilHzb.telemetry())
                    .append(VeilLodArena.telemetry())
                    .append(VeilVisibilityBudget.telemetry())
                    .append(VeilSectionResidencyGuard.telemetry())
                    .append(VeilRebuildCoalescer.telemetry())
                    .append(VeilRebuildBudget.telemetry())
                    .append(VeilAnimatedSpriteUsage.telemetry())
                    .append(VeilLightCoordsCache.telemetry())
                    .append(VeilLightingPipeline.telemetry())
                    .append('\n')
                    .append(VeilShaderPackBridge.telemetry())
                    .append('\n')
                    .append(VeilFullFrameTelemetry.telemetry())
                    .append('\n')
                    .append(VeilShaderGeometryReduction.telemetry())
                    .append('\n')
                    .append(VeilAiCadence.telemetry())
                    .append(VeilLatencyController.telemetry());
        }

        private static void appendBlock(StringBuilder out, BlockResult block) {
            out.append('\n')
                    .append("BLOCK ")
                    .append(block.ordinal)
                    .append(" — ")
                    .append(block.veilEnabled ? "VEIL ON" : "BYPASS")
                    .append('\n');
            appendPerf(out, "block", block.frame, block.render);
            out.append(
                    String.format(
                            Locale.ROOT,
                            "GPU world-render span ms: avg %.4f | timestamp samples %d\n",
                            block.gpuWorldMs,
                            block.gpuWorldSamples));
            VeilBenchmarkEvidence.Delta e = block.evidence;
            out.append(
                    String.format(
                            Locale.ROOT,
                            "visible sections avg/max: %.2f / %d\n",
                            e.techniques().averageVisibleSections(),
                            e.techniques().maxVisibleSections()));
            appendEntityPipeline(out, "entity", e.entities());
            out.append(VeilSectionVisibilityIndex.telemetryLine()).append('\n');
            out.append(VeilEntityModelFastPath.telemetryLine()).append('\n');
            appendServerAi(out, "server", e.serverAi());
            out.append("section dirty events: ")
                    .append(e.techniques().sectionDirtyEvents())
                    .append(" | mesh updates: ")
                    .append(e.techniques().sectionMeshUpdateEvents())
                    .append('\n');
            out.append("GC: ")
                    .append(e.gcCollections())
                    .append(" collections / ")
                    .append(e.gcTimeMs())
                    .append(" ms | heap delta ")
                    .append(formatMiB(e.heapDeltaBytes()))
                    .append(" MiB\n");
            out.append(
                    String.format(
                            Locale.ROOT,
                            "cache hit/miss: %d/%d (%.2f%% hit) | successful terrain overrides %d/%d\n",
                            e.techniques().terrainCacheReuses(),
                            e.techniques().terrainCacheRebuilds(),
                            e.techniques().cacheHitRate() * 100.0,
                            e.techniques().terrainPrepareSuccesses(),
                            e.techniques().terrainPrepareCalls()));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "bind elision: vertex %d/%d (%.2f%%) | index %d/%d (%.2f%%)\n",
                            e.techniques().skippedVertexBinds(),
                            e.techniques().vertexBindCalls(),
                            e.techniques().vertexElisionRate() * 100.0,
                            e.techniques().skippedIndexBinds(),
                            e.techniques().indexBindCalls(),
                            e.techniques().indexElisionRate() * 100.0));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "exact face decisions reused/evaluated: %d/%d (%.2f%% reuse)\n",
                            e.faceVisibility().hits(),
                            e.faceVisibility().misses(),
                            e.faceVisibility().hitRate() * 100.0));
        }

        private static void appendEntityPipeline(
                StringBuilder out, String label, VeilEntityPipelineCounters.Snapshot snapshot) {
            dev.veil.revive.client.diagnostics.SnapshotReport.appendEntityPipeline(
                    out, label, snapshot);
        }

        private static void appendServerAi(
                StringBuilder out, String label, VeilServerAiCounters.Snapshot snapshot) {
            dev.veil.revive.client.diagnostics.SnapshotReport.appendServerAi(out, label, snapshot);
        }

        private static void appendPerf(
                StringBuilder out, String label, SampleStats frame, SampleStats render) {
            dev.veil.revive.client.diagnostics.SnapshotReport.appendPerf(out, label, frame, render);
        }

        private static void appendEvidence(
                StringBuilder out,
                VeilBenchmarkEvidence.Delta evidence,
                ReviveConfig cfg,
                boolean veilState) {
            VeilTechniqueCounters.Snapshot t = evidence.techniques();

            out.append("Shared uniform work: ").append(evidence.sharedWork()).append('\n');

            out.append("Terrain prepare hook calls: ").append(t.terrainPrepareCalls()).append('\n');
            out.append("Terrain prepare successes: ")
                    .append(t.terrainPrepareSuccesses())
                    .append(" (")
                    .append(formatPercent(t.terrainSuccessRate()))
                    .append(")\n");
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Work per prepare: sections scanned %.2f | packets validated %.2f | dynamic UBOs %.2f\n",
                            perCall(t.terrainSectionsScanned(), t.terrainPrepareSuccesses()),
                            perCall(t.terrainDrawPacketsValidated(), t.terrainPrepareSuccesses()),
                            perCall(t.terrainDynamicUbosWritten(), t.terrainPrepareSuccesses())));
            out.append("LevelRenderer return overrides actually installed: ")
                    .append(t.terrainReturnOverrides())
                    .append('\n');
            out.append("Prepare bypass skips: ")
                    .append(t.terrainBypassSkips())
                    .append(" | cache-config skips: ")
                    .append(t.terrainCacheDisabledSkips())
                    .append(" | no-dispatcher skips: ")
                    .append(t.terrainNoDispatcherSkips())
                    .append('\n');
            out.append("Terrain bridge exceptions/fallbacks: ")
                    .append(t.terrainBridgeFallbacks())
                    .append('\n');
            out.append("Cache reuses (real topology reuse): ")
                    .append(t.terrainCacheReuses())
                    .append('\n');
            out.append("Cache rebuilds: ").append(t.terrainCacheRebuilds()).append('\n');
            out.append("Cache invalidations observed during measured blocks: ")
                    .append(t.terrainCacheInvalidations())
                    .append('\n');
            out.append("Cache miss reasons empty/dispatcher/signature/packet-count: ")
                    .append(t.cacheMissEmpty())
                    .append(" / ")
                    .append(t.cacheMissDispatcher())
                    .append(" / ")
                    .append(t.cacheMissSignature())
                    .append(" / ")
                    .append(t.cacheMissPacketCount())
                    .append('\n');
            out.append("Cache hit rate: ").append(formatPercent(t.cacheHitRate())).append('\n');
            out.append("Visible section samples/avg/max: ")
                    .append(t.terrainVisibleSectionSamples())
                    .append(" / ")
                    .append(String.format(Locale.ROOT, "%.2f", t.averageVisibleSections()))
                    .append(" / ")
                    .append(t.maxVisibleSections())
                    .append('\n');
            out.append("Sections scanned by Veil cache validation: ")
                    .append(t.terrainSectionsScanned())
                    .append('\n');
            out.append("Fast topology hits/misses/section refs checked: ")
                    .append(VeilTerrainDrawBridge.fastTopologyHits())
                    .append(" / ")
                    .append(VeilTerrainDrawBridge.fastTopologyMisses())
                    .append(" / ")
                    .append(VeilTerrainDrawBridge.fastSectionChecks())
                    .append('\n');
            out.append("Revision fast hits/revalidations/audits/self-heals: ")
                    .append(VeilTerrainDrawBridge.revisionFastHits())
                    .append(" / ")
                    .append(VeilTerrainDrawBridge.revisionRevalidations())
                    .append(" / ")
                    .append(VeilTerrainDrawBridge.periodicIdentityAudits())
                    .append(" / ")
                    .append(VeilTerrainDrawBridge.revisionSelfHeals())
                    .append('\n');
            out.append("RenderSection relocation revision-forces/self-heals: ")
                    .append(VeilTerrainDrawBridge.relocationRevisionForces())
                    .append(" / ")
                    .append(VeilTerrainDrawBridge.relocationSelfHeals())
                    .append('\n');
            out.append("Drawable packets validated: ")
                    .append(t.terrainDrawPacketsValidated())
                    .append(" | max packets in one prepare: ")
                    .append(t.maxDrawPackets())
                    .append('\n');
            out.append("Drawable packets rebuilt into cached topology: ")
                    .append(t.terrainDrawPacketsRebuilt())
                    .append('\n');
            out.append("Draw groups built on misses: ")
                    .append(t.terrainGroupsBuilt())
                    .append(" | max groups in one rebuild: ")
                    .append(t.maxGroups())
                    .append('\n');
            out.append("Dynamic section UBOs written: ")
                    .append(t.terrainDynamicUbosWritten())
                    .append('\n');
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Measured Veil prepare cost: total %.3f ms | avg/call %.4f ms\n",
                            t.terrainPrepareNs() / 1_000_000.0,
                            t.avgPrepareMs()));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  uploadTerrainBuffersToGpu: total %.3f ms | avg/success %.4f ms\n",
                            t.terrainUploadNs() / 1_000_000.0,
                            t.avgUploadMs()));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  cache validation + dynamic-info build: total %.3f ms | avg/success %.4f ms\n",
                            t.terrainValidateNs() / 1_000_000.0,
                            t.avgValidateMs()));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  static topology rebuilds: total %.3f ms | avg/miss %.4f ms\n",
                            t.terrainRebuildNs() / 1_000_000.0,
                            t.avgRebuildMs()));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "  dynamic UBO write: total %.3f ms | avg/success %.4f ms\n",
                            t.terrainUboWriteNs() / 1_000_000.0,
                            t.avgUboWriteMs()));

            out.append("Vulkan vertex-bind hook calls: ")
                    .append(t.vertexBindCalls())
                    .append(" | skipped: ")
                    .append(t.skippedVertexBinds())
                    .append(" | forwarded: ")
                    .append(t.forwardedVertexBinds())
                    .append(" | elided: ")
                    .append(formatPercent(t.vertexElisionRate()))
                    .append('\n');
            out.append("Vulkan index-bind hook calls: ")
                    .append(t.indexBindCalls())
                    .append(" | skipped: ")
                    .append(t.skippedIndexBinds())
                    .append(" | forwarded: ")
                    .append(t.forwardedIndexBinds())
                    .append(" | elided: ")
                    .append(formatPercent(t.indexElisionRate()))
                    .append('\n');

            out.append("Exact block-face decisions reused/evaluated: ")
                    .append(evidence.faceVisibility().hits())
                    .append(" / ")
                    .append(evidence.faceVisibility().misses())
                    .append(" | reuse: ")
                    .append(formatPercent(evidence.faceVisibility().hitRate()))
                    .append('\n');

            out.append("Far-field analysis requests/runs/cadence-skips: ")
                    .append(t.farAnalysisRequests())
                    .append(" / ")
                    .append(t.farAnalysisRuns())
                    .append(" / ")
                    .append(t.farAnalysisCadenceSkips())
                    .append('\n');
            out.append("Far-field analyzed sections: ")
                    .append(t.farSectionsAnalyzed())
                    .append('\n');
            out.append("Far candidates exact/SSE/voxel/VASC: ")
                    .append(t.farExactCandidates())
                    .append(" / ")
                    .append(t.farSseCandidates())
                    .append(" / ")
                    .append(t.farVoxelCandidates())
                    .append(" / ")
                    .append(t.farVascCandidates())
                    .append('\n');
            out.append("Far conservative fallbacks dirty/translucent: ")
                    .append(t.farDirtyFallbacks())
                    .append(" / ")
                    .append(t.farTranslucentFallbacks())
                    .append('\n');
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Far analysis CPU: total %.3f ms | avg/run %.4f ms\n",
                            t.farAnalysisNs() / 1_000_000.0,
                            t.avgFarAnalysisMs()));
            out.append(
                    "IMPORTANT: far-field SSE/voxel/VASC is ANALYSIS_ONLY in this build; rendered geometry changed by it: 0\n");

            out.append("Section dirty events: ")
                    .append(t.sectionDirtyEvents())
                    .append(" | mesh-update events: ")
                    .append(t.sectionMeshUpdateEvents())
                    .append(" | global invalidations: ")
                    .append(t.globalInvalidations())
                    .append('\n');

            out.append("Independent TerrainBridgeCounters hit/miss/fallback/prepared: ")
                    .append(evidence.terrainBridge().cacheHits())
                    .append(" / ")
                    .append(evidence.terrainBridge().cacheMisses())
                    .append(" / ")
                    .append(evidence.terrainBridge().fallbacks())
                    .append(" / ")
                    .append(evidence.terrainBridge().framesPrepared())
                    .append('\n');

            out.append(
                    String.format(
                            Locale.ROOT,
                            "Host terrain upload timing: %d passes | total %.3f ms | avg %.4f ms\n",
                            evidence.runtimeStats().terrainUploadPasses(),
                            evidence.runtimeStats().totalTerrainUploadMs(),
                            evidence.runtimeStats().averageTerrainUploadMs()));
            out.append(
                    String.format(
                            Locale.ROOT,
                            "Host SectionOcclusionGraph timing: %d updates | total %.3f ms | avg %.4f ms\n",
                            evidence.runtimeStats().occlusionUpdates(),
                            evidence.runtimeStats().totalOcclusionUpdateMs(),
                            evidence.runtimeStats().averageOcclusionUpdateMs()));

            out.append("Fallback reasons: BYPASSED=")
                    .append(evidence.fallbacks().count(VeilFallbackTracker.Reason.BYPASSED))
                    .append(" NO_DISPATCHER=")
                    .append(
                            evidence.fallbacks()
                                    .count(VeilFallbackTracker.Reason.TERRAIN_NO_DISPATCHER))
                    .append(" BRIDGE_EXCEPTION=")
                    .append(
                            evidence.fallbacks()
                                    .count(VeilFallbackTracker.Reason.TERRAIN_BRIDGE_EXCEPTION))
                    .append(" VASC_DIRTY=")
                    .append(evidence.fallbacks().count(VeilFallbackTracker.Reason.VASC_DIRTY))
                    .append(" VASC_TRANSLUCENT=")
                    .append(evidence.fallbacks().count(VeilFallbackTracker.Reason.VASC_TRANSLUCENT))
                    .append('\n');

            out.append("GC collections/time: ")
                    .append(evidence.gcCollections())
                    .append(" / ")
                    .append(evidence.gcTimeMs())
                    .append(" ms\n");
            out.append("Heap used first-start/last-end/summed measured delta: ")
                    .append(formatMiB(evidence.heapUsedStartBytes()))
                    .append(" / ")
                    .append(formatMiB(evidence.heapUsedEndBytes()))
                    .append(" / ")
                    .append(formatMiB(evidence.heapDeltaBytes()))
                    .append(" MiB\n");
            out.append("Heap committed end: ")
                    .append(formatMiB(evidence.heapCommittedEndBytes()))
                    .append(" MiB | non-heap used end: ")
                    .append(formatMiB(evidence.nonHeapUsedEndBytes()))
                    .append(" MiB | live threads: ")
                    .append(evidence.liveThreadsEnd())
                    .append('\n');

            if (!veilState) {
                out.append(
                        "Control expectation: terrain overrides/reuses and skipped binds should be 0 while BYPASS is active.\n");
            } else if (!cfg.staticDrawPacketCache()) {
                out.append(
                        "Config note: staticDrawPacketCache=false, so no terrain-cache effect is expected.\n");
            }
        }

        private static void appendTechniqueMatrix(
                StringBuilder out, VeilBenchmarkEvidence.Delta evidence, ReviveConfig cfg) {
            var live =
                    new dev.veil.revive.client.diagnostics.TechniqueReport.LiveCounters(
                            VeilDiagnostics.detailedOverlay(),
                            VeilAnimatedSpriteUsage.activeMarks(),
                            VeilAnimatedSpriteUsage.uploadsSkipped(),
                            VeilAnimatedSpriteUsage.compileSpritesCaptured(),
                            VeilRebuildCoalescer.cancelled(),
                            VeilRebuildCoalescer.stalePollsSkipped(),
                            VeilTerrainDrawBridge.revisionFastHits(),
                            VeilTerrainDrawBridge.periodicIdentityAudits(),
                            VeilTerrainDrawBridge.revisionSelfHeals(),
                            VeilTerrainDrawBridge.relocationRevisionForces(),
                            VeilTerrainDrawBridge.relocationSelfHeals());
            dev.veil.revive.client.diagnostics.TechniqueReport.append(
                    out,
                    evidence.techniques(),
                    evidence.faceVisibility(),
                    evidence.sharedWork(),
                    cfg,
                    live);
        }

        private static String formatPercent(double ratio) {
            return String.format(Locale.ROOT, "%.2f%%", ratio * 100.0);
        }

        private static String formatMiB(long bytes) {
            return String.format(Locale.ROOT, "%.2f", bytes / (1024.0 * 1024.0));
        }

        private static double perCall(long work, long calls) {
            return calls <= 0L ? 0.0 : (double) work / (double) calls;
        }

        private static double relativeDifference(double a, double b) {
            if (!(a > 0.0) || !(b > 0.0)) return 0.0;
            return Math.abs(a - b) / ((a + b) * 0.5);
        }

        private static double percentRatio(double value, double baseline) {
            return baseline > 0.0 ? ((value / baseline) - 1.0) * 100.0 : 0.0;
        }
    }

    public record SampleStats(
            int count,
            double avg,
            double p50,
            double p90,
            double p95,
            double p99,
            double min,
            double max,
            double stdDev,
            double mad) {

        static SampleStats of(List<Double> input) {
            var value = dev.veil.revive.client.diagnostics.DistributionStats.of(input);
            return new SampleStats(
                    value.count(),
                    value.avg(),
                    value.p50(),
                    value.p90(),
                    value.p95(),
                    value.p99(),
                    value.min(),
                    value.max(),
                    value.stdDev(),
                    value.mad());
        }
    }

    private record CameraStamp(double x, double y, double z, float yaw, float pitch) {
        static CameraStamp capture(Minecraft client) {
            if (client.player == null) return new CameraStamp(0, 0, 0, 0, 0);
            return new CameraStamp(
                    client.player.getX(),
                    client.player.getY(),
                    client.player.getZ(),
                    client.player.getYRot(),
                    client.player.getXRot());
        }

        boolean matches(Minecraft client) {
            if (client.player == null) return false;
            double dx = client.player.getX() - x;
            double dy = client.player.getY() - y;
            double dz = client.player.getZ() - z;
            double pos2 = dx * dx + dy * dy + dz * dz;
            float dyaw = Math.abs(wrapDegrees(client.player.getYRot() - yaw));
            float dpitch = Math.abs(client.player.getXRot() - pitch);
            return pos2 <= 0.0625 && dyaw <= 0.5f && dpitch <= 0.5f;
        }

        private static float wrapDegrees(float degrees) {
            float x = degrees % 360.0f;
            if (x >= 180.0f) x -= 360.0f;
            if (x < -180.0f) x += 360.0f;
            return x;
        }
    }

    private static Path saveReport(BenchmarkReport report) {
        Path dir = VeilPlatform.get().getGameDir().resolve("logs").resolve("veil-benchmarks");
        try {
            Files.createDirectories(dir);
            String stamp =
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
            Path file = dir.resolve("veil-proof-" + stamp + ".txt");
            Files.writeString(file, report.fullText(), StandardCharsets.UTF_8);
            return file;
        } catch (IOException e) {
            ReviveMod.LOGGER.warn("Could not save Veil benchmark report", e);
            return null;
        }
    }
}
