package dev.veil.revive.client;

import dev.veil.revive.core.terrain.SectionIntCache;

import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.chunk.RenderSectionRegion;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

public final class VeilWorldLightSampler {
    public static final boolean REQUESTED = Boolean.getBoolean("veil.ownWorldLight");
    public static final boolean VERIFICATION_ENABLED =
            REQUESTED
                    && Boolean.getBoolean("veil.verifyOwnWorldLight")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final AtomicInteger VERIFIED = new AtomicInteger();
    private static final AtomicInteger HITS = new AtomicInteger();
    private static final ThreadLocal<SectionIntCache> SCOPES = new ThreadLocal<>();
    private static final Semaphore CAPACITY = new Semaphore(64);
    private static final ConcurrentLinkedQueue<SectionIntCache> POOL =
            new ConcurrentLinkedQueue<>();
    private final Emission emission;
    private final Reference reference;

    public VeilWorldLightSampler(Emission emission, Reference reference) {
        this.emission = java.util.Objects.requireNonNull(emission);
        this.reference =
                VERIFICATION_ENABLED ? java.util.Objects.requireNonNull(reference) : reference;
    }

    public static boolean begin(SectionPos section, RenderSectionRegion region) {
        if (!REQUESTED) return false;
        var cache = SCOPES.get();
        if (cache == null) {
            if (!CAPACITY.tryAcquire()) return false;
            try {
                cache = POOL.poll();
                if (cache == null) cache = new SectionIntCache();
                SCOPES.set(cache);
            } catch (RuntimeException | Error failure) {
                CAPACITY.release();
                throw failure;
            }
        }
        try {
            cache.begin(
                    region,
                    section.minBlockX() - 1,
                    section.minBlockY() - 1,
                    section.minBlockZ() - 1,
                    VeilLightingPipeline.lightGlobalRevision());
        } catch (RuntimeException | Error failure) {
            if (!cache.active()) {
                SCOPES.remove();
                POOL.offer(cache);
                CAPACITY.release();
            }
            throw failure;
        }
        return true;
    }

    public static void end() {
        var cache = SCOPES.get();
        if (cache == null) throw new IllegalStateException("Missing world light scope");
        cache.end();
        if (!cache.active()) {
            SCOPES.remove();
            POOL.offer(cache);
            CAPACITY.release();
        }
    }

    public int light(BlockState state, BlockAndTintGetter world, BlockPos position) {
        int result;
        if (state.emissiveRendering()) result = 0x00F000F0;
        else {
            long revision = VeilLightingPipeline.lightGlobalRevision();
            var cache = SCOPES.get();
            int raw =
                    cache == null
                            ? SectionIntCache.MISS
                            : cache.get(
                                    world,
                                    position.getX(),
                                    position.getY(),
                                    position.getZ(),
                                    revision);
            if (raw == SectionIntCache.MISS) {
                int sky = world.getBrightness(LightLayer.SKY, position);
                int block = world.getBrightness(LightLayer.BLOCK, position);
                raw = block << 4 | sky << 20;
                if (cache != null && revision == VeilLightingPipeline.lightGlobalRevision())
                    cache.put(
                            world,
                            position.getX(),
                            position.getY(),
                            position.getZ(),
                            revision,
                            raw);
            } else if (VERIFICATION_ENABLED
                    && HITS.get() < 10000
                    && HITS.incrementAndGet() == 10000)
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil own world light cache: PASS (hits=10000)");
            int self = emission.value(state, world, position);
            result = ((raw >> 4) & 15) < self ? (raw & 0x00FF0000) | self << 4 : raw;
        }
        if (VERIFICATION_ENABLED && VERIFIED.get() < 100000) {
            if (result != reference.light(state, world, position))
                throw new IllegalStateException("Own world light sample differs from platform");
            if (VERIFIED.incrementAndGet() == 100000)
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil own world light sampler: PASS (verified_samples=100000)");
        }
        return result;
    }

    @FunctionalInterface
    public interface Emission {
        int value(BlockState state, BlockAndTintGetter world, BlockPos position);
    }

    @FunctionalInterface
    public interface Reference {
        int light(BlockState state, BlockAndTintGetter world, BlockPos position);
    }
}
