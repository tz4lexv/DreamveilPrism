package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

final class VeilCompactPlanProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.verifyCompactPlans")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static long plans, commands;

    static boolean pending() {
        return ENABLED && commands < 100_000;
    }

    static void verify(VeilIndirectTerrain.Plan retained, VeilIndirectTerrain.Plan reference) {
        commands += VeilTerrainPlanScratch.comparePlan(retained, reference);
        plans++;
        if (!pending())
            ReviveMod.LOGGER.info(
                    "Veil incremental compact commands: PASS (plans={} commands={} exact_commands_bounds_regions=true)",
                    plans,
                    commands);
    }

    static void requireComplete(long retained, long rebuilt) {
        if (!ENABLED) return;
        if (commands < 100_000 || retained == 0 || rebuilt == 0)
            throw new IllegalStateException(
                    "incremental compact plans not completely exercised: commands="
                            + commands
                            + " retained="
                            + retained
                            + " rebuilt="
                            + rebuilt);
        ReviveMod.LOGGER.info(
                "Veil incremental compact plans: PASS (retained={} rebuilt={} verified_commands={})",
                retained,
                rebuilt,
                commands);
    }
}
