package dev.veil.revive.client.graphics.rendergraph;

import dev.veil.revive.client.VeilRenderGraph.Barrier;
import dev.veil.revive.client.VeilRenderGraph.State;
import dev.veil.revive.client.VeilRenderGraph.Subresource;
import dev.veil.revive.client.VeilRenderGraph.Use;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.TreeSet;

/**
 * Precise disjoint byte-range synchronization of Vulkan buffers. One pass may access overlapping
 * byte ranges; a previous write only creates memory dependencies for the bytes actually used. A
 * whole/unbounded host buffer is supported without inventing an allocation size.
 */
final class BufferSliceTracker {
    private record Range(long begin, long end) {
        Range {
            if (begin < 0 || end <= begin)
                throw new IllegalArgumentException("Invalid buffer range");
        }

        boolean contains(Range other) {
            return begin <= other.begin && end >= other.end;
        }

        boolean intersects(Range other) {
            return begin < other.end && other.begin < end;
        }
    }

    private record Tile(Range range, State state, State pendingWrite, State visibleRead) {}

    private record Requested(Range range, State state, boolean reads) {}

    private record Transition(Range range, State from, State to) {}

    private final Range domain;
    private final boolean unbounded;
    private List<Tile> tiles;

    BufferSliceTracker(Subresource initialRange, State initial) {
        Objects.requireNonNull(initialRange, "initialRange");
        Objects.requireNonNull(initial, "initial");
        if (!initialRange.whole() && !initialRange.bufferRange())
            throw new IllegalArgumentException("Buffer tracker requires a byte range or WHOLE");
        unbounded = initialRange.whole();
        domain = unbounded ? new Range(0, Long.MAX_VALUE) : range(initialRange);
        tiles = List.of(new Tile(domain, initial, initial.write() ? initial : null, null));
    }

    State current() {
        State combined = null;
        for (Tile tile : tiles) {
            combined = combined == null ? tile.state : combined.union(tile.state);
        }
        return combined;
    }

    List<Barrier> before(String resource, List<Use> uses) {
        var requested = new ArrayList<Requested>();
        for (Use use : uses) {
            if (!use.subresource().whole() && !use.subresource().bufferRange())
                throw new IllegalArgumentException("Buffer use is not a byte range: " + resource);
            Range bytes = use.subresource().whole() ? domain : range(use.subresource());
            if (!domain.contains(bytes))
                throw new IllegalArgumentException(
                        "Buffer use exceeds allocated bytes: "
                                + resource
                                + " "
                                + use.subresource());
            requested.add(new Requested(bytes, State.of(use.access()), use.access().reads()));
        }
        return apply(resource, requested, null, null);
    }

    /** Return modified host-buffer bytes to the host's synchronization state. */
    List<Barrier> release(String resource, State initial, State target) {
        if (target == null) return List.of();
        return apply(resource, List.of(), initial, target);
    }

    private List<Barrier> apply(
            String resource, List<Requested> uses, State externalInitial, State externalTarget) {
        if (uses.isEmpty() && externalTarget == null) return List.of();
        var cuts = new TreeSet<Long>();
        for (Tile tile : tiles) {
            cuts.add(tile.range.begin);
            cuts.add(tile.range.end);
        }
        for (Requested use : uses) {
            cuts.add(use.range.begin);
            cuts.add(use.range.end);
        }
        var endpoints = new ArrayList<>(cuts);
        var resultTiles = new ArrayList<Tile>();
        var changes = new ArrayList<Transition>();
        int priorIndex = 0;
        for (int i = 0; i + 1 < endpoints.size(); i++) {
            Range cell = new Range(endpoints.get(i), endpoints.get(i + 1));
            if (!domain.contains(cell)) continue;
            while (priorIndex < tiles.size() && tiles.get(priorIndex).range.end <= cell.begin)
                priorIndex++;
            Tile prior = priorIndex < tiles.size() ? tiles.get(priorIndex) : null;
            if (prior == null || !prior.range.contains(cell))
                throw new IllegalStateException("Lost buffer state: " + resource + " " + cell);
            State desired = null;
            boolean reads = false;
            for (Requested use : uses) {
                if (!use.range.intersects(cell)) continue;
                desired = desired == null ? use.state : desired.union(use.state);
                reads |= use.reads;
            }
            boolean releasing =
                    externalTarget != null
                            && !prior.state.equals(externalInitial)
                            && !prior.state.equals(externalTarget);
            if (releasing) {
                desired = externalTarget;
                reads = false;
            }
            if (desired == null) {
                resultTiles.add(
                        prior.range.equals(cell)
                                ? prior
                                : new Tile(
                                        cell, prior.state, prior.pendingWrite, prior.visibleRead));
                continue;
            }
            State seen = prior.visibleRead;
            boolean uncoveredRead =
                    reads
                            && (seen == null
                                    || (seen.stages() & desired.stages()) != desired.stages()
                                    || (seen.access() & desired.access()) != desired.access());
            // Buffers have no Vulkan image layout. Previous writes and subsequent writes must
            // synchronize; repeated already-visible reads need no additional barrier.
            if (releasing || desired.write() || (prior.pendingWrite != null && uncoveredRead)) {
                State from =
                        prior.pendingWrite == null
                                ? prior.state
                                : new State(
                                        prior.state.stages() | prior.pendingWrite.stages(),
                                        prior.state.access() | prior.pendingWrite.access(),
                                        true,
                                        prior.state.layout());
                changes.add(new Transition(cell, from, desired));
            }
            State pending = prior.pendingWrite;
            if (desired.write()) {
                pending = desired;
                seen = null;
            } else if (reads) {
                seen = seen == null ? desired : seen.union(desired);
                desired = seen;
            }
            resultTiles.add(new Tile(cell, desired, pending, seen));
        }
        tiles = mergeTiles(resultTiles);
        var barriers = new ArrayList<Barrier>();
        for (Transition t : mergeTransitions(changes)) {
            Subresource span =
                    unbounded && t.range.equals(domain)
                            ? Subresource.WHOLE
                            : Subresource.buffer(t.range.begin, t.range.end - t.range.begin);
            barriers.add(new Barrier(resource, span, t.from, t.to));
        }
        return List.copyOf(barriers);
    }

    private static Range range(Subresource s) {
        return new Range(s.byteOffset(), s.byteOffset() + s.byteCount());
    }

    private static List<Tile> mergeTiles(List<Tile> source) {
        var result = new ArrayList<Tile>();
        for (Tile current : source) {
            if (!result.isEmpty()) {
                Tile last = result.get(result.size() - 1);
                if (last.range.end == current.range.begin
                        && last.state.equals(current.state)
                        && Objects.equals(last.pendingWrite, current.pendingWrite)
                        && Objects.equals(last.visibleRead, current.visibleRead)) {
                    result.set(
                            result.size() - 1,
                            new Tile(
                                    new Range(last.range.begin, current.range.end),
                                    last.state,
                                    last.pendingWrite,
                                    last.visibleRead));
                    continue;
                }
            }
            result.add(current);
        }
        return List.copyOf(result);
    }

    private static List<Transition> mergeTransitions(List<Transition> source) {
        var result = new ArrayList<Transition>();
        for (Transition current : source) {
            if (!result.isEmpty()) {
                Transition last = result.get(result.size() - 1);
                if (last.range.end == current.range.begin
                        && last.from.equals(current.from)
                        && last.to.equals(current.to)) {
                    result.set(
                            result.size() - 1,
                            new Transition(
                                    new Range(last.range.begin, current.range.end),
                                    last.from,
                                    last.to));
                    continue;
                }
            }
            result.add(current);
        }
        return List.copyOf(result);
    }
}
