package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilRebuildBudget;
import dev.veil.revive.client.VeilVideoConfig;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.client.renderer.chunk.SectionRenderDispatcher")
public abstract class SectionRenderDispatcherTimingMixin {
    @Unique private long veil$budgetUploadStartNs;
    @Unique private long veil$budgetUploadBytesBefore;

    @Inject(method = "uploadTerrainBuffersToGpu", at = @At("HEAD"), require = 0)
    private void revive$uploadStart(CallbackInfo ci) {
        ReviveRuntime.onTerrainUploadStart();
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.TERRAIN_UPLOAD);
        if (ReviveRuntime.optimizationsEnabled() && VeilVideoConfig.on("renderer.rebuildBudget")) {
            veil$budgetUploadStartNs = System.nanoTime();
            veil$budgetUploadBytesBefore = VeilRebuildBudget.installedMeshBytesTotal();
        }
    }

    @Inject(method = "uploadTerrainBuffersToGpu", at = @At("RETURN"), require = 0)
    private void revive$uploadEnd(CallbackInfo ci) {
        ReviveRuntime.onTerrainUploadEnd();
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.TERRAIN_UPLOAD);
        long start = veil$budgetUploadStartNs;
        veil$budgetUploadStartNs = 0L;
        if (start == 0L) return;
        long bytes = VeilRebuildBudget.installedMeshBytesTotal() - veil$budgetUploadBytesBefore;
        if (bytes > 0L) {
            VeilRebuildBudget.recordUploadBatch(System.nanoTime() - start, bytes);
            dev.veil.revive.client.VeilFullFrameTelemetry.addLoad(
                    dev.veil.revive.client.VeilFullFrameTelemetry.LoadCounter.TERRAIN_UPLOAD_BYTES,
                    bytes);
        }
    }
}
