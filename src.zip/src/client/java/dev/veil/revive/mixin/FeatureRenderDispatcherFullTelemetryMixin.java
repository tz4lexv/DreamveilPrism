package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilEntityMeshCapture;
import dev.veil.revive.client.VeilFullFrameTelemetry;

import net.minecraft.client.renderer.feature.FeatureRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FeatureRenderDispatcher.class)
public abstract class FeatureRenderDispatcherFullTelemetryMixin {
    @Inject(method = "prepareFrame", at = @At("HEAD"), require = 0)
    private void veil$prepareStart(CallbackInfoReturnable<?> cir) {
        VeilEntityMeshCapture.beginFrame();
        VeilFullFrameTelemetry.beginCpu(VeilFullFrameTelemetry.CpuZone.FEATURE_PREPARE);
    }

    @Inject(method = "prepareFrame", at = @At("RETURN"), require = 0)
    private void veil$prepareEnd(CallbackInfoReturnable<?> cir) {
        VeilFullFrameTelemetry.endCpu(VeilFullFrameTelemetry.CpuZone.FEATURE_PREPARE);
        VeilEntityMeshCapture.publishFrame();
    }
}
