package dev.veil.revive.client.graphics.rendergraph;

import dev.veil.revive.client.VeilRenderGraph.Kind;
import dev.veil.revive.client.VeilRenderGraph.Pass;
import dev.veil.revive.client.VeilRenderGraph.Subresource;
import dev.veil.revive.client.VeilRenderGraph.Use;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class GraphCompiler {
    private GraphCompiler() {}

    public static List<Pass> compile(Map<String, Kind> resources, List<Pass> passes) {
        return compile(resources, passes, Set.of(), Set.of());
    }

    public static List<Pass> compile(
            Map<String, Kind> resources, List<Pass> passes, Set<String> imported) {
        return compile(resources, passes, imported, imported);
    }

    public static List<Pass> compile(
            Map<String, Kind> resources,
            List<Pass> passes,
            Set<String> initialized,
            Set<String> readOnly) {
        if (!resources.keySet().containsAll(initialized)
                || !resources.keySet().containsAll(readOnly)) {
            throw new IllegalArgumentException("Unknown initialized/read-only graph resource");
        }
        var byName = new LinkedHashMap<String, Pass>();
        var edges = new LinkedHashMap<String, Set<String>>();
        var indegree = new LinkedHashMap<String, Integer>();
        for (Pass pass : passes) {
            if (byName.putIfAbsent(pass.name(), pass) != null)
                throw new IllegalArgumentException("Duplicate pass: " + pass.name());
            edges.put(pass.name(), new LinkedHashSet<>());
            indegree.put(pass.name(), 0);
            for (Use use : pass.uses()) {
                Kind kind = resources.get(use.resource());
                if (kind == null)
                    throw new IllegalArgumentException(
                            "Pass " + pass.name() + ": missing resource " + use.resource());
                if (kind != use.access().kind())
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": invalid usage "
                                    + use.access()
                                    + " for "
                                    + use.resource());
                if (kind == Kind.BUFFER
                        && !use.subresource().whole()
                        && !use.subresource().bufferRange()) {
                    throw new IllegalArgumentException(
                            "Pass "
                                    + pass.name()
                                    + ": buffer subresource range is invalid for "
                                    + use.resource());
                }
                if (use.access().writes() && readOnly.contains(use.resource())) {
                    throw new IllegalArgumentException(
                            "Imported graph resource is read-only: " + use.resource());
                }
            }
        }

        for (Pass pass : passes) {
            for (String dependency : pass.after()) {
                if (!byName.containsKey(dependency))
                    throw new IllegalArgumentException("Missing pass dependency: " + dependency);
                if (dependency.equals(pass.name()))
                    throw new IllegalArgumentException(
                            "Render graph cycle: " + pass.name() + " depends on itself");
                edge(dependency, pass.name(), edges, indegree);
            }
        }

        List<Pass> explicitOrder = order(byName, edges, indegree, passes);
        var ancestors = new LinkedHashMap<String, Set<String>>();
        for (Pass pass : explicitOrder) {
            var dependencies = new LinkedHashSet<String>();
            for (String dependency : pass.after()) {
                dependencies.add(dependency);
                dependencies.addAll(ancestors.get(dependency));
            }
            ancestors.put(pass.name(), dependencies);
        }
        for (String resource : resources.keySet()) {
            var prior = new ArrayList<PassUse>();
            for (Pass pass : passes) {
                List<Use> currentUses =
                        pass.uses().stream()
                                .filter(use -> use.resource().equals(resource))
                                .toList();
                for (Use use : currentUses) {
                    for (PassUse previous : prior) {
                        if (!previous.use().subresource().overlaps(use.subresource())) continue;
                        if (previous.use().access().writes() || use.access().writes()) {
                            if (ancestors.get(previous.pass()).contains(pass.name()))
                                edge(pass.name(), previous.pass(), edges, indegree);
                            else edge(previous.pass(), pass.name(), edges, indegree);
                        }
                    }
                }
                for (Use use : currentUses) {
                    prior.add(new PassUse(pass.name(), use));
                }
            }
        }

        List<Pass> ordered = order(byName, edges, indegree, passes);
        for (String resource : resources.keySet()) {
            var prior = new ArrayList<PassUse>();
            boolean hasInitialValue = initialized.contains(resource);
            for (Pass pass : ordered) {
                List<Use> currentUses =
                        pass.uses().stream()
                                .filter(use -> use.resource().equals(resource))
                                .toList();
                for (Use use : currentUses) {
                    if (use.access().reads()
                            && !hasInitialValue
                            && !coveredByPriorWriters(use.subresource(), prior))
                        throw new IllegalArgumentException(
                                "Read before write: pass=" + pass.name() + " resource=" + resource);
                }
                for (Use use : currentUses) {
                    prior.add(new PassUse(pass.name(), use));
                    if (use.access().writes() && use.subresource().whole()) hasInitialValue = true;
                }
            }
        }
        return ordered;
    }

    private static List<Pass> order(
            Map<String, Pass> byName,
            Map<String, Set<String>> edges,
            Map<String, Integer> sourceIndegree,
            List<Pass> passes) {
        var indegree = new LinkedHashMap<>(sourceIndegree);
        var manifestOrder = new LinkedHashMap<String, Integer>();
        for (int i = 0; i < passes.size(); i++) manifestOrder.put(passes.get(i).name(), i);
        var ready =
                new java.util.PriorityQueue<String>(
                        java.util.Comparator.comparingInt(manifestOrder::get));
        indegree.forEach(
                (name, degree) -> {
                    if (degree == 0) ready.add(name);
                });
        var ordered = new ArrayList<Pass>();
        while (!ready.isEmpty()) {
            String name = ready.remove();
            ordered.add(byName.get(name));
            for (String next : edges.get(name)) {
                int remaining = indegree.compute(next, (key, degree) -> degree - 1);
                if (remaining == 0) ready.add(next);
            }
        }
        if (ordered.size() != passes.size())
            throw new IllegalArgumentException("Render graph cycle: " + indegree);
        return List.copyOf(ordered);
    }

    private record PassUse(String pass, Use use) {}

    private static boolean coveredByPriorWriters(Subresource required, List<PassUse> prior) {
        List<Subresource> writers =
                prior.stream()
                        .filter(value -> value.use().access().writes())
                        .map(value -> value.use().subresource())
                        .toList();
        if (writers.stream().anyMatch(writer -> writer.covers(required))) return true;
        if (required.whole()) return false;
        if (required.bufferRange()) {
            long covered = required.byteOffset();
            long end = covered + required.byteCount();
            for (Subresource writer :
                    writers.stream()
                            .filter(Subresource::bufferRange)
                            .sorted(java.util.Comparator.comparingLong(Subresource::byteOffset))
                            .toList()) {
                if (writer.byteOffset() > covered) break;
                covered = Math.max(covered, writer.byteOffset() + writer.byteCount());
                if (covered >= end) return true;
            }
            return false;
        }

        for (int mip = required.baseMip();
                mip < required.baseMip() + required.levelCount();
                mip++) {
            for (int layer = required.baseLayer();
                    layer < required.baseLayer() + required.layerCount();
                    layer++) {
                Subresource cell = Subresource.image(mip, 1, layer, 1);
                if (writers.stream().noneMatch(writer -> writer.covers(cell))) return false;
            }
        }
        return true;
    }

    private static void edge(
            String source,
            String destination,
            Map<String, Set<String>> edges,
            Map<String, Integer> indegree) {
        if (source.equals(destination)) return;
        if (edges.get(source).add(destination))
            indegree.compute(destination, (key, value) -> value + 1);
    }
}
