package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.BufferBuilder;

import dev.veil.revive.core.terrain.CompileCancellationScope;
import dev.veil.revive.mixin.BufferBuilderVertexCountAccessor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public final class VeilCompilerCancellationProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.verifyOwnCompilerCancellation")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final AtomicReference<Plan> ARMED = new AtomicReference<>();
    private static final ThreadLocal<Binding> TASK = new ThreadLocal<>();
    private static Plan active;
    private static int completed;
    private static long started;

    private VeilCompilerCancellationProbe() {}

    public static boolean enabled() {
        return ENABLED;
    }

    public static void taskStarted(BlockPos origin, AtomicBoolean token) {
        if (!ENABLED) return;
        var plan = ARMED.get();
        if (plan != null
                && plan.node
                        == SectionPos.asLong(
                                origin.getX() >> 4, origin.getY() >> 4, origin.getZ() >> 4)
                && plan.claimed.compareAndSet(false, true)) TASK.set(new Binding(plan, token));
    }

    public static void taskFinished(boolean aborted, boolean scopeRestored) {
        if (!ENABLED) return;
        var binding = TASK.get();
        TASK.remove();
        if (binding == null) return;
        var plan = binding.plan;
        if (!plan.forced) {
            plan.claimed.set(false);
            return;
        }
        if (!aborted || !binding.token.get() || !scopeRestored || plan.discardedVertices < 4)
            throw new IllegalStateException(
                    "Forced compiler cancellation did not release a partial mesh or restore token scope");
        plan.response = true;
    }

    public static void traversal(SectionPos section, BufferBuilder[] pending) {
        if (!ENABLED) return;
        for (var builder : pending)
            if (builder != null
                    && ((BufferBuilderVertexCountAccessor) (Object) builder).veil$vertexCount()
                            >= 4) {
                checkpoint(section, Stage.TRAVERSAL);
                return;
            }
    }

    public static void beforePublish(SectionPos section) {
        if (ENABLED) checkpoint(section, Stage.BEFORE_PUBLISH);
    }

    private static void checkpoint(SectionPos section, Stage stage) {
        var binding = TASK.get();
        if (binding == null
                || binding.plan.node != section.asLong()
                || binding.plan.stage != stage
                || binding.plan.forced
                || !CompileCancellationScope.bound()) return;
        binding.plan.forced = true;
        binding.token.set(true);
        CompileCancellationScope.check();
    }

    static void discarded(SectionPos section, long vertices) {
        if (!ENABLED) return;
        var binding = TASK.get();
        if (binding != null && binding.plan.node == section.asLong() && binding.plan.forced)
            binding.plan.discardedVertices = vertices;
    }

    static void tick(Minecraft client, List<SectionRenderDispatcher.RenderSection> visible) {
        if (!ENABLED || completed == 2 || client.level == null) return;
        var server = client.getSingleplayerServer();
        if (server == null
                || !server.getWorldData().getLevelName().startsWith("Veil-Benchmark-26.2-"))
            throw new IllegalStateException("Compiler cancellation probe requires dedicated world");
        long now = System.nanoTime();
        if (started == 0) started = now;
        if (now - started > 100_000_000_000L)
            throw new IllegalStateException("Compiler cancellation timed out: " + completed);
        if (active == null) {
            if (now - started < 24_000_000_000L) return;
            for (var section : visible) {
                var origin = section.getRenderOrigin();
                if (Math.abs(origin.getX() - client.player.getX()) > 64
                        || Math.abs(origin.getZ() - client.player.getZ()) > 64
                        || section.getSectionMesh().getSectionDraw(ChunkSectionLayer.SOLID) == null)
                    continue;
                active = new Plan(section, completed == 0 ? Stage.TRAVERSAL : Stage.BEFORE_PUBLISH);
                ARMED.set(active);
                dirty(client, active);
                return;
            }
            return;
        }
        if (!active.response) return;
        if (!active.rebuildRequested) {
            if (active.section.getSectionMesh() != active.previous)
                throw new IllegalStateException("Cancelled section replaced its previous mesh");
            active.rebuildRequested = true;
            ARMED.compareAndSet(active, null);
            dirty(client, active);
            return;
        }
        if (active.section.getSectionMesh() == active.previous
                || active.section.getSectionMesh().getSectionDraw(ChunkSectionLayer.SOLID) == null)
            return;
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil own compiler cancellation: {} PASS (discarded_vertices={} retained_mesh=true recovered=true)",
                active.stage,
                active.discardedVertices);
        completed++;
        active = null;
    }

    private static void dirty(Minecraft client, Plan plan) {
        var position = SectionPos.of(plan.node);
        client.levelExtractor.setSectionDirty(position.getX(), position.getY(), position.getZ());
    }

    static void requireComplete() {
        if (ENABLED && completed != 2)
            throw new IllegalStateException("Own compiler cancellation incomplete: " + completed);
    }

    private enum Stage {
        TRAVERSAL,
        BEFORE_PUBLISH
    }

    private record Binding(Plan plan, AtomicBoolean token) {}

    private static final class Plan {
        final SectionRenderDispatcher.RenderSection section;
        final SectionMesh previous;
        final long node;
        final Stage stage;
        final AtomicBoolean claimed = new AtomicBoolean();
        volatile boolean forced, response;
        volatile long discardedVertices;
        boolean rebuildRequested;

        Plan(SectionRenderDispatcher.RenderSection section, Stage stage) {
            this.section = section;
            this.stage = stage;
            previous = section.getSectionMesh();
            var origin = section.getRenderOrigin();
            node = SectionPos.asLong(origin.getX() >> 4, origin.getY() >> 4, origin.getZ() >> 4);
        }
    }
}
