package dev.veil.revive.mixin;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.VertexFormat;

import dev.veil.revive.client.VeilVertexBufferWriter;

import org.lwjgl.system.MemoryUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(BufferBuilder.class)
public abstract class BufferBuilderBulkWriterMixin implements VeilVertexBufferWriter {
    @Shadow private int vertices;

    @Shadow @Final private int vertexSize;

    @Shadow private long vertexPointer;

    @Shadow @Final private ByteBufferBuilder buffer;

    @Shadow private int elementsToFill;

    @Shadow @Final private VertexFormat format;

    @Shadow private boolean building;

    @Override
    public int veil$vertexCount() {
        return this.vertices;
    }

    @Override
    public boolean veil$canPush(VertexFormat sourceFormat) {
        return this.building
                && sourceFormat == this.format
                && sourceFormat.getVertexSize() == this.vertexSize
                && this.elementsToFill == 0;
    }

    @Override
    public void veil$push(long src, int count, VertexFormat sourceFormat) {
        if (!veil$canPush(sourceFormat))
            throw new IllegalStateException("Incompatible or incomplete bulk vertex target");
        if (src == 0 || count <= 0 || count > 16777215 - this.vertices)
            throw new IllegalArgumentException("Invalid bulk vertex range");
        int length = Math.multiplyExact(count, this.vertexSize);
        long dst = this.buffer.reserve(length);
        MemoryUtil.memCopy(src, dst, length);

        this.vertices += count;
        this.vertexPointer = dst + length - this.vertexSize;
        this.elementsToFill = 0;
    }
}
