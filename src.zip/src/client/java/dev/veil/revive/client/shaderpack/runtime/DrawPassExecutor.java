package dev.veil.revive.client.shaderpack.runtime;

import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.api.VeilDraw;
import dev.veil.revive.client.VeilShaderPack;
import dev.veil.revive.client.graphics.resources.IndirectDrawBatches;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkCommandBuffer;

import java.util.List;
import java.util.function.Function;

public final class DrawPassExecutor {
    private final Function<String, GpuBuffer> buffers;

    public DrawPassExecutor(Function<String, GpuBuffer> buffers) {
        this.buffers = buffers;
    }

    public void execute(
            VeilShaderPack.Pass pass,
            VkCommandBuffer cmd,
            MemoryStack stack,
            long maxDrawIndirectCount) {
        List<VeilDraw.VertexBuffer> previousVertices = null;
        VeilDraw.IndexBuffer previousIndex = null;
        var handles = stack.mallocLong(Math.max(1, pass.vertexLayout().bindings().size()));
        var offsets = stack.mallocLong(Math.max(1, pass.vertexLayout().bindings().size()));
        // Device features exposed by Minecraft describe what its Vulkan device enables.
        boolean multiDrawEnabled =
                RenderSystem.getDevice().getDeviceInfo().features().multiDrawIndirect();
        for (VeilDraw draw : pass.draws()) {
            if (!draw.vertexBuffers().equals(previousVertices)) {
                int start = 0;
                while (start < draw.vertexBuffers().size()) {
                    int end = start + 1;
                    while (end < draw.vertexBuffers().size()
                            && draw.vertexBuffers().get(end).binding()
                                    == draw.vertexBuffers().get(end - 1).binding() + 1) end++;
                    handles.clear().limit(end - start);
                    offsets.clear().limit(end - start);
                    for (int index = start; index < end; index++) {
                        VeilDraw.VertexBuffer binding = draw.vertexBuffers().get(index);
                        GpuBuffer buffer = buffers.apply(binding.resource());
                        if (buffer == null)
                            throw new IllegalStateException(
                                    "Vertex buffer unavailable: " + binding.resource());
                        handles.put(index - start, ((VulkanGpuBuffer) buffer).vkBuffer());
                        offsets.put(index - start, binding.offset());
                    }
                    vkCmdBindVertexBuffers(
                            cmd, draw.vertexBuffers().get(start).binding(), handles, offsets);
                    start = end;
                }
                previousVertices = draw.vertexBuffers();
            }
            if (draw.indexed() && !draw.indexBuffer().equals(previousIndex)) {
                VeilDraw.IndexBuffer binding = draw.indexBuffer();
                GpuBuffer buffer = buffers.apply(binding.resource());
                if (buffer == null)
                    throw new IllegalStateException(
                            "Index buffer unavailable: " + binding.resource());
                vkCmdBindIndexBuffer(
                        cmd,
                        ((VulkanGpuBuffer) buffer).vkBuffer(),
                        binding.offset(),
                        binding.type() == VeilDraw.IndexType.UINT16
                                ? VK_INDEX_TYPE_UINT16
                                : VK_INDEX_TYPE_UINT32);
                previousIndex = binding;
            }
            switch (draw.kind()) {
                case DRAW ->
                        vkCmdDraw(
                                cmd,
                                (int) draw.elementCount(),
                                (int) draw.instanceCount(),
                                (int) draw.firstElement(),
                                (int) draw.firstInstance());
                case DRAW_INDEXED ->
                        vkCmdDrawIndexed(
                                cmd,
                                (int) draw.elementCount(),
                                (int) draw.instanceCount(),
                                (int) draw.firstElement(),
                                draw.vertexOffset(),
                                (int) draw.firstInstance());
                case DRAW_INDIRECT -> {
                    GpuBuffer buffer = buffers.apply(draw.indirectBuffer());
                    if (buffer == null)
                        throw new IllegalStateException(
                                "Indirect draw buffer unavailable: " + draw.indirectBuffer());
                    long vkBuffer = ((VulkanGpuBuffer) buffer).vkBuffer();
                    IndirectDrawBatches.submit(
                            draw.indirectOffset(),
                            draw.drawCount(),
                            draw.stride(),
                            draw.commandBytes(),
                            multiDrawEnabled,
                            maxDrawIndirectCount,
                            (offset, count, stride) ->
                                    vkCmdDrawIndirect(cmd, vkBuffer, offset, count, stride));
                }
                case DRAW_INDEXED_INDIRECT -> {
                    GpuBuffer buffer = buffers.apply(draw.indirectBuffer());
                    if (buffer == null)
                        throw new IllegalStateException(
                                "Indexed indirect draw buffer unavailable: "
                                        + draw.indirectBuffer());
                    long vkBuffer = ((VulkanGpuBuffer) buffer).vkBuffer();
                    IndirectDrawBatches.submit(
                            draw.indirectOffset(),
                            draw.drawCount(),
                            draw.stride(),
                            draw.commandBytes(),
                            multiDrawEnabled,
                            maxDrawIndirectCount,
                            (offset, count, stride) ->
                                    vkCmdDrawIndexedIndirect(cmd, vkBuffer, offset, count, stride));
                }
            }
        }
    }
}
