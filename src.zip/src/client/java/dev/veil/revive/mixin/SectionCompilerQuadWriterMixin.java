package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.QuadInstance;

import net.minecraft.client.renderer.chunk.SectionCompiler;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(SectionCompiler.class)
public abstract class SectionCompilerQuadWriterMixin {
    @WrapOperation(
            method = {"lambda$compile$0", "lambda$compile$1"},
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lcom/mojang/blaze3d/vertex/BufferBuilder;putBlockBakedQuad(FFFLnet/minecraft/client/resources/model/geometry/BakedQuad;Lcom/mojang/blaze3d/vertex/QuadInstance;)V"))
    private void veil$writeTerrainQuad(
            BufferBuilder builder,
            float x,
            float y,
            float z,
            net.minecraft.client.resources.model.geometry.BakedQuad quad,
            QuadInstance instance,
            Operation<Void> original) {
        if (!dev.veil.revive.client.VeilTerrainQuadWriter.emit(builder, x, y, z, quad, instance))
            original.call(builder, x, y, z, quad, instance);
    }
}
