package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.StagingBuffer;
import com.mojang.blaze3d.vertex.UberGpuBuffer;

import dev.veil.revive.core.terrain.AttributeUploadPlan;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

final class VeilCanonicalArenaGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.canonicalArenaGpuProbe")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final ArrayList<Case> CASES = new ArrayList<>();
    private static GpuFence fence;
    private static boolean started, complete;

    private record Case(
            StagingBuffer staging,
            UberGpuBuffer<Object> arena,
            GpuBuffer oldReadback,
            GpuBuffer newReadback,
            byte[] before,
            byte[] after)
            implements AutoCloseable {
        public void close() {
            arena.close();
            staging.close();
            oldReadback.close();
            if (newReadback != null) newReadback.close();
        }
    }

    private static final class ControlledStaging extends StagingBuffer {
        private final ByteBuffer bytes = MemoryUtil.memAlloc(1024);

        protected ByteBuffer getWriteBuffer() {
            return bytes;
        }

        protected void copyTo(
                CommandEncoder encoder,
                GpuBuffer destination,
                long offset,
                long source,
                long size) {
            encoder.writeToBuffer(
                    destination.slice(offset, size), bytes.slice((int) source, (int) size));
        }

        public void close() {
            MemoryUtil.memFree(bytes);
        }
    }

    static void tick() {
        if (!ENABLED || complete) return;
        try {
            if (!started) {
                started = true;
                var encoder = RenderSystem.getDevice().createCommandEncoder();
                for (int mode = 0; mode < 4; mode++) start(mode, encoder);
                fence = encoder.createFence();
                return;
            }
            if (!fence.awaitCompletion(0)) return;
            int verified = 0;
            for (var test : CASES) {
                verified += verify(test.oldReadback, test.before);
                if (test.newReadback != null) verified += verify(test.newReadback, test.after);
            }
            complete = true;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil canonical arena GPU: PASS (cases=4 verified_bytes={} source_unchanged=true new_heap=true staging_rollback=true staging_retry=true cancelled=true full_fallback_retry=true leases_released=true)",
                    verified);
            close();
        } catch (RuntimeException | Error failure) {
            close();
            throw failure;
        }
    }

    static void requireComplete() {
        if (ENABLED && !complete)
            throw new IllegalStateException("Canonical arena GPU probe incomplete");
    }

    private static void start(int mode, CommandEncoder encoder) {
        var before = ByteBuffer.allocate(448).order(ByteOrder.LITTLE_ENDIAN);
        for (int vertex = 0; vertex < 16; vertex++)
            before.putFloat(vertex)
                    .putFloat(1)
                    .putFloat(2)
                    .putInt(-1)
                    .putFloat(.25f)
                    .putFloat(.5f)
                    .putInt(0x00f00010);
        before.flip();
        byte[] oldBytes = before.array().clone();
        byte[] newBytes = oldBytes.clone();
        var after = ByteBuffer.wrap(newBytes).order(ByteOrder.LITTLE_ENDIAN);
        after.putInt(12, 0x80abcdef);
        after.putInt(15 * 28 + 24, 0x00f000a0);
        var plan = AttributeUploadPlan.canonical(before, after, 4, 32);
        if (plan == null || plan.rangeCount() != 2 || plan.payloadBytes() != 8)
            throw new IllegalStateException("Canonical probe range fixture invalid");
        var device = RenderSystem.getDevice();
        StagingBuffer staging =
                mode == 0
                        ? StagingBuffer.create("Veil canonical native probe", device, 32768)
                        : new ControlledStaging();
        var arena =
                new UberGpuBuffer<Object>(
                        "Veil canonical probe", GpuBuffer.USAGE_VERTEX, 1024, 4, staging);
        var oldReadback = readback();
        var newReadback = mode == 3 ? null : readback();
        var test = new Case(staging, arena, oldReadback, newReadback, oldBytes, newBytes);
        CASES.add(test);
        Object padding = new Object(), source = new Object(), target = new Object();
        var scratch = MemoryUtil.memAlloc(1024);
        VeilCanonicalData data = null;
        try {
            scratch.limit(64);
            if (!arena.addAllocation(padding, ignored -> {}, scratch))
                throw new IllegalStateException("Probe padding rejected");
            upload(arena, staging, encoder);
            scratch.clear().put(oldBytes).flip();
            if (!arena.addAllocation(source, ignored -> {}, scratch))
                throw new IllegalStateException("Probe source rejected");
            upload(arena, staging, encoder);
            var oldAllocation = arena.getAllocation(source);
            if (oldAllocation == null || oldAllocation.getOffsetFromHeap() <= 0)
                throw new IllegalStateException("Probe nonzero source missing");
            encoder.copyToBuffer(
                    arena.getGpuBuffer(oldAllocation).slice(oldAllocation.getOffsetFromHeap(), 448),
                    oldReadback.slice());
            data = VeilCanonicalData.capture(after);
            if (data == null) throw new IllegalStateException("Probe canonical capture rejected");
            var bridge = (VeilCanonicalGpuArena) arena;
            int[] callbacks = {0};
            long pending = VeilCanonicalSparseUploads.pendingBytes();
            if (mode == 2) {
                scratch.clear().limit(1020);
                var filler = staging.tryAppend(scratch);
                if (filler == null) throw new IllegalStateException("Probe filler rejected");
                try {
                    if (bridge.veil$stageCanonical(
                                    source, target, ignored -> callbacks[0]++, plan, data)
                            != VeilCanonicalGpuArena.Admission.STAGING)
                        throw new IllegalStateException("Partial staging rejection missing");
                    if (VeilCanonicalSparseUploads.pendingBytes() != pending)
                        throw new IllegalStateException("Rejected payload retained");
                } finally {
                    filler.close();
                }
                clear(staging, encoder);
                scratch.clear();
                var all = staging.tryAppend(scratch);
                if (all == null) throw new IllegalStateException("Rejected staging handle leaked");
                all.close();
                clear(staging, encoder);
            }
            if (bridge.veil$stageCanonical(source, target, ignored -> callbacks[0]++, plan, data)
                    != VeilCanonicalGpuArena.Admission.ADDED)
                throw new IllegalStateException("Canonical probe admission rejected");
            data.retire();
            if (mode == 1) {
                scratch.clear().limit(1016);
                var filler = staging.tryAppend(scratch);
                if (filler == null)
                    throw new IllegalStateException("Fallback pressure fixture rejected");
                try {
                    arena.removeAllocation(source);
                    upload(arena, staging, encoder);
                    if (callbacks[0] != 0 || arena.getAllocation(target) != null)
                        throw new IllegalStateException("Blocked fallback published early");
                    if (VeilCanonicalSparseUploads.pendingBytes() != pending)
                        throw new IllegalStateException("Fallback retained patch bytes");
                    if (data.view().remaining() != 448)
                        throw new IllegalStateException("Fallback lease lost");
                } finally {
                    filler.close();
                }
                clear(staging, encoder);
            } else if (mode == 3) {
                arena.removeAllocation(target);
                clear(staging, encoder);
                scratch.clear();
                var all = staging.tryAppend(scratch);
                if (all == null) throw new IllegalStateException("Cancelled staging handle leaked");
                all.close();
                clear(staging, encoder);
            }
            boolean heapChanged = upload(arena, staging, encoder);
            if (VeilCanonicalSparseUploads.pendingBytes() != pending)
                throw new IllegalStateException("Canonical probe payload leak");
            if (mode == 3) {
                if (callbacks[0] != 0
                        || arena.getAllocation(target) != null
                        || arena.getAllocation(source) != oldAllocation)
                    throw new IllegalStateException("Cancellation changed native allocation");
            } else {
                var destination = arena.getAllocation(target);
                if (callbacks[0] != 1
                        || destination == null
                        || destination == oldAllocation
                        || (mode != 1 && !heapChanged))
                    throw new IllegalStateException("Canonical fresh publication incorrect");
                if (mode != 1 && arena.getAllocation(source) != oldAllocation)
                    throw new IllegalStateException("Canonical old allocation replaced");
                encoder.copyToBuffer(
                        arena.getGpuBuffer(destination).slice(destination.getOffsetFromHeap(), 448),
                        newReadback.slice());
            }
            if (mode != 1)
                encoder.copyToBuffer(
                        arena.getGpuBuffer(oldAllocation)
                                .slice(oldAllocation.getOffsetFromHeap(), 448),
                        oldReadback.slice());
            try {
                data.view();
                throw new IllegalStateException("Canonical probe lease leaked");
            } catch (IllegalStateException expected) {
                if (!"Canonical data retired".equals(expected.getMessage())) throw expected;
            }
        } finally {
            if (data != null) data.retire();
            MemoryUtil.memFree(scratch);
        }
    }

    private static GpuBuffer readback() {
        return RenderSystem.getDevice()
                .createBuffer(
                        () -> "Veil canonical fault readback",
                        GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_COPY_DST,
                        448);
    }

    private static boolean upload(
            UberGpuBuffer<Object> arena, StagingBuffer staging, CommandEncoder encoder) {
        try (var uploader = staging.startUploading(encoder)) {
            return arena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
        }
    }

    private static void clear(StagingBuffer staging, CommandEncoder encoder) {
        try (var uploader = staging.startUploading(encoder)) {
            uploader.checkValidFor(staging);
        }
    }

    private static int verify(GpuBuffer buffer, byte[] expected) {
        try (var mapped = buffer.map(true, false)) {
            for (int at = 0; at < expected.length; at++)
                if (mapped.data().get(at) != expected[at])
                    throw new IllegalStateException("Canonical arena GPU mismatch at " + at);
        }
        return expected.length;
    }

    private static void close() {
        if (fence != null) fence.close();
        fence = null;
        for (var test : CASES) test.close();
        CASES.clear();
    }
}
