package dev.veil.revive.client.graphics.pipelines;

import static org.lwjgl.vulkan.VK10.*;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.client.graphics.minecraft.VulkanResult;

import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;
import org.lwjgl.vulkan.VkPipelineCacheCreateInfo;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.function.Supplier;

public final class PersistentPipelineCache {
    private static final long MAGIC = 0x5645494C50434348L;
    private static final int FILE_VERSION = 1;
    private static final int UUID_BYTES = VK_UUID_SIZE;
    private static final int HEADER_BYTES = Long.BYTES + Integer.BYTES * 6 + UUID_BYTES;
    private static final int MAX_CACHE_BYTES = 64 * 1024 * 1024;

    private Owner owner;
    private final Supplier<Path> gameDirectory;

    public PersistentPipelineCache(Supplier<Path> gameDirectory) {
        this.gameDirectory = java.util.Objects.requireNonNull(gameDirectory);
    }

    public long handle(MinecraftVulkanContext runtime) {
        RenderSystem.assertOnRenderThread();
        if (owner == null || !owner.matches(runtime)) {
            if (owner != null) owner.close();
            owner = Owner.create(runtime, gameDirectory);
        }
        owner.uses++;
        return owner.handle;
    }

    public String telemetry() {
        Owner current = owner;
        if (current == null) {
            return "vk_pipeline_cache_active=false\n"
                    + "vk_pipeline_cache_loaded_bytes=0\n"
                    + "vk_pipeline_cache_saved_bytes=0\n"
                    + "vk_pipeline_cache_pipeline_creates=0\n";
        }
        return "vk_pipeline_cache_active=true\n"
                + "vk_pipeline_cache_loaded_bytes="
                + current.loadedBytes
                + "\n"
                + "vk_pipeline_cache_saved_bytes="
                + current.savedBytes
                + "\n"
                + "vk_pipeline_cache_pipeline_creates="
                + current.uses
                + "\n";
    }

    public void close() {
        RenderSystem.assertOnRenderThread();
        Owner closing = owner;
        owner = null;
        if (closing != null) closing.close();
    }

    private static final class Owner implements AutoCloseable {
        private final MinecraftVulkanContext runtime;
        private final long deviceAddress;
        private final DeviceIdentity identity;
        private final Path path;
        private long handle;
        private long loadedBytes;
        private long savedBytes;
        private long uses;

        private Owner(
                MinecraftVulkanContext runtime,
                DeviceIdentity identity,
                Path path,
                long handle,
                long loadedBytes) {
            this.runtime = runtime;
            this.deviceAddress = runtime.vkDevice().address();
            this.identity = identity;
            this.path = path;
            this.handle = handle;
            this.loadedBytes = loadedBytes;
        }

        static Owner create(MinecraftVulkanContext runtime, Supplier<Path> gameDirectory) {
            DeviceIdentity identity = DeviceIdentity.capture(runtime);
            Path gameDir = gameDirectory.get();
            Path path = gameDir.resolve("cache/veil/vulkan").resolve(identity.cacheFileName());
            Path legacyPath = gameDir.resolve("cache/veil/vulkan-pipeline-cache.bin");
            ByteBuffer initial = null;
            long loaded = 0L;
            boolean loadedFromDevicePath = false;
            try {
                initial = loadPayload(path, identity);
                loadedFromDevicePath = initial != null;

                if (initial == null) initial = loadPayload(legacyPath, identity);
                if (initial != null) loaded = initial.remaining();
            } catch (IOException | RuntimeException failure) {
                ReviveMod.LOGGER.warn(
                        "Veil Vulkan pipeline cache load ignored: {}", failure.getMessage());
                initial = null;
            }

            long cache = createNative(runtime, initial);
            if (cache == VK_NULL_HANDLE && initial != null) {
                ReviveMod.LOGGER.warn(
                        "Veil Vulkan pipeline cache rejected cached driver data; retrying empty");

                if (loadedFromDevicePath) {
                    try {
                        Files.deleteIfExists(path);
                    } catch (IOException failure) {
                        ReviveMod.LOGGER.debug(
                                "Could not remove rejected Veil Vulkan cache {}: {}",
                                path,
                                failure.getMessage());
                    }
                }
                cache = createNative(runtime, null);
                loaded = 0L;
            }
            if (cache == VK_NULL_HANDLE) {
                throw new IllegalStateException(
                        "vkCreatePipelineCache failed for both persistent and empty cache data");
            }
            return new Owner(runtime, identity, path, cache, loaded);
        }

        boolean matches(MinecraftVulkanContext other) {
            return handle != VK_NULL_HANDLE && other.vkDevice().address() == deviceAddress;
        }

        @Override
        public void close() {
            long cache = handle;
            handle = VK_NULL_HANDLE;
            if (cache == VK_NULL_HANDLE) return;
            try {
                if (uses > 0) savedBytes = save(cache);
            } catch (IOException | RuntimeException failure) {
                ReviveMod.LOGGER.warn(
                        "Veil Vulkan pipeline cache save skipped: {}", failure.getMessage());
            } finally {
                vkDestroyPipelineCache(runtime.vkDevice(), cache, null);
            }
        }

        private long save(long cache) throws IOException {
            ByteBuffer payload = null;
            try (MemoryStack stack = MemoryStack.stackPush()) {
                PointerBuffer size = stack.mallocPointer(1);
                VulkanResult.check(
                        vkGetPipelineCacheData(runtime.vkDevice(), cache, size, null),
                        "vkGetPipelineCacheData(size)");
                long bytes = size.get(0);
                if (bytes <= 0 || bytes > MAX_CACHE_BYTES || bytes > Integer.MAX_VALUE) {
                    if (bytes > MAX_CACHE_BYTES) {
                        ReviveMod.LOGGER.warn(
                                "Veil Vulkan pipeline cache is {} bytes; refusing to persist more than {} bytes",
                                bytes,
                                MAX_CACHE_BYTES);
                    }
                    return 0L;
                }
                payload = MemoryUtil.memAlloc((int) bytes);
                VulkanResult.check(
                        vkGetPipelineCacheData(runtime.vkDevice(), cache, size, payload),
                        "vkGetPipelineCacheData(data)");
                int actual = Math.toIntExact(size.get(0));
                payload.limit(actual);

                ByteBuffer file =
                        ByteBuffer.allocate(HEADER_BYTES + actual).order(ByteOrder.LITTLE_ENDIAN);
                file.putLong(MAGIC);
                file.putInt(FILE_VERSION);
                file.putInt(identity.vendorId);
                file.putInt(identity.deviceId);
                file.putInt(identity.driverVersion);
                file.putInt(identity.apiVersion);
                file.putInt(actual);
                file.put(identity.pipelineCacheUuid);
                ByteBuffer copy = payload.duplicate();
                copy.position(0).limit(actual);
                file.put(copy);

                Files.createDirectories(path.getParent());
                Path temp = path.resolveSibling(path.getFileName() + ".tmp");
                Files.write(temp, file.array());
                try {
                    Files.move(
                            temp,
                            path,
                            StandardCopyOption.REPLACE_EXISTING,
                            StandardCopyOption.ATOMIC_MOVE);
                } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                    Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING);
                }
                return actual;
            } finally {
                if (payload != null) MemoryUtil.memFree(payload);
            }
        }
    }

    private static long createNative(MinecraftVulkanContext runtime, ByteBuffer initial) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var info = VkPipelineCacheCreateInfo.calloc(stack).sType$Default();
            if (initial != null && initial.hasRemaining()) info.pInitialData(initial);
            var out = stack.callocLong(1);
            int result = vkCreatePipelineCache(runtime.vkDevice(), info, null, out);
            if (result != VK_SUCCESS) return VK_NULL_HANDLE;
            return out.get(0);
        }
    }

    private static ByteBuffer loadPayload(Path path, DeviceIdentity identity) throws IOException {
        if (!Files.isRegularFile(path)) return null;
        long size = Files.size(path);
        if (size < HEADER_BYTES || size > HEADER_BYTES + (long) MAX_CACHE_BYTES) return null;
        byte[] bytes = Files.readAllBytes(path);
        ByteBuffer file = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        if (file.getLong() != MAGIC || file.getInt() != FILE_VERSION) return null;
        if (file.getInt() != identity.vendorId
                || file.getInt() != identity.deviceId
                || file.getInt() != identity.driverVersion
                || file.getInt() != identity.apiVersion) return null;
        int payloadBytes = file.getInt();
        byte[] uuid = new byte[UUID_BYTES];
        file.get(uuid);
        if (!Arrays.equals(uuid, identity.pipelineCacheUuid)) return null;
        if (payloadBytes <= 0 || payloadBytes > MAX_CACHE_BYTES || file.remaining() != payloadBytes)
            return null;

        ByteBuffer direct = ByteBuffer.allocateDirect(payloadBytes).order(ByteOrder.nativeOrder());
        direct.put(file).flip();
        return direct;
    }

    private record DeviceIdentity(
            int vendorId,
            int deviceId,
            int driverVersion,
            int apiVersion,
            byte[] pipelineCacheUuid) {
        String cacheFileName() {
            StringBuilder uuid = new StringBuilder(pipelineCacheUuid.length * 2);
            for (byte value : pipelineCacheUuid) {
                uuid.append(String.format(java.util.Locale.ROOT, "%02x", value & 0xff));
            }
            return String.format(
                    java.util.Locale.ROOT,
                    "pipeline-%04x-%04x-%08x-%s.bin",
                    vendorId,
                    deviceId,
                    driverVersion,
                    uuid);
        }

        static DeviceIdentity capture(MinecraftVulkanContext runtime) {
            try (MemoryStack stack = MemoryStack.stackPush()) {
                VkPhysicalDeviceProperties properties = VkPhysicalDeviceProperties.calloc(stack);
                vkGetPhysicalDeviceProperties(runtime.vkDevice().getPhysicalDevice(), properties);
                byte[] uuid = new byte[UUID_BYTES];
                ByteBuffer uuidView = properties.pipelineCacheUUID();
                for (int i = 0; i < uuid.length; i++) uuid[i] = uuidView.get(i);
                return new DeviceIdentity(
                        properties.vendorID(),
                        properties.deviceID(),
                        properties.driverVersion(),
                        properties.apiVersion(),
                        uuid);
            }
        }
    }
}
