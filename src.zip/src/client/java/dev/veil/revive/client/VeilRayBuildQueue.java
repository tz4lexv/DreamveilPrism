package dev.veil.revive.client;

import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

final class VeilRayBuildQueue<T> {
    private final Executor executor;
    private final AtomicLong generation = new AtomicLong();
    private final AtomicReference<Job<T>> pending = new AtomicReference<>();

    VeilRayBuildQueue(Executor executor) {
        this.executor = executor;
    }

    void invalidate() {
        generation.incrementAndGet();
        Job<T> job = pending.get();
        if (job != null && job.done) pending.compareAndSet(job, null);
    }

    boolean busy() {
        return pending.get() != null;
    }

    long pendingKey() {
        Job<T> job = pending.get();
        return job != null && job.generation == generation.get() ? job.key : Long.MIN_VALUE;
    }

    boolean submit(long key, Supplier<T> supplier) {
        Job<T> job = new Job<>(key, generation.get());
        if (!pending.compareAndSet(null, job)) return false;
        try {
            executor.execute(
                    () -> {
                        try {
                            job.result = supplier.get();
                        } catch (Throwable failure) {
                            job.failure = failure;
                        } finally {
                            job.done = true;
                            if (job.generation != generation.get())
                                pending.compareAndSet(job, null);
                        }
                    });
        } catch (RuntimeException failure) {
            pending.compareAndSet(job, null);
            throw failure;
        }
        return true;
    }

    T poll() {
        Job<T> job = pending.get();
        if (job == null
                || !job.done
                || !pending.compareAndSet(job, null)
                || job.generation != generation.get()) return null;
        if (job.failure != null)
            throw new IllegalStateException("Minecraft ray world build failed", job.failure);
        return job.result;
    }

    private static final class Job<T> {
        final long key, generation;
        T result;
        Throwable failure;
        volatile boolean done;

        Job(long key, long generation) {
            this.key = key;
            this.generation = generation;
        }
    }
}
