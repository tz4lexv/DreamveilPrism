package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import java.util.List;

final class VeilRegularPackedLifecycleProbe {
    private static long start;
    private static SectionRenderDispatcher.RenderSection section;
    private static SectionMesh previous;
    private static boolean retired, recovered;

    private VeilRegularPackedLifecycleProbe() {}

    private static boolean enabled() {
        return Boolean.getBoolean("veil.verifyRegularPackedLifecycle")
                && Boolean.getBoolean("veil.benchmarkWorld")
                && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    }

    static void tick(Minecraft client, List<SectionRenderDispatcher.RenderSection> sections) {
        if (!enabled() || recovered || client.level == null) return;
        long now = System.nanoTime();
        if (start == 0) start = now;
        if (section == null) {
            if (now - start < 15_000_000_000L) return;
            for (var candidate : sections) {
                var mesh = candidate.getSectionMesh();
                if (VeilRegularPackedTerrain.get(mesh, ChunkSectionLayer.SOLID) == null) continue;
                section = candidate;
                previous = mesh;
                var origin = candidate.getRenderOrigin();
                client.levelExtractor.setSectionDirty(
                        origin.getX() >> 4, origin.getY() >> 4, origin.getZ() >> 4);
                ReviveMod.LOGGER.info(
                        "Veil regular packed lifecycle probe: requested native section rebuild at {}",
                        origin);
                break;
            }
            return;
        }
        var replacement = section.getSectionMesh();
        if (!retired
                || replacement == previous
                || VeilRegularPackedTerrain.get(replacement, ChunkSectionLayer.SOLID) == null)
            return;
        if (!(previous instanceof VeilMeshExtras extras)
                || !extras.veil$metadata().closed()
                || VeilRegularPackedTerrain.hasOwner(previous))
            throw new IllegalStateException("Closed native compact owner remained resident");
        recovered = true;
        ReviveMod.LOGGER.info(
                "Veil regular packed lifecycle probe: PASS (native mesh close, render-thread retirement, replacement compact allocation)");
    }

    static void retired(SectionMesh mesh) {
        if (mesh == previous) retired = true;
    }

    static void requireComplete() {
        if (enabled() && !recovered)
            throw new IllegalStateException("Regular packed native lifecycle probe incomplete");
    }
}
