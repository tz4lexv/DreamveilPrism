package dev.veil.revive.client.shaderpack.runtime;

import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.api.VeilTransfer;
import dev.veil.revive.client.VeilShaderPack;
import dev.veil.revive.client.graphics.resources.TransferClearRules;
import dev.veil.revive.client.graphics.resources.TransferWriteOrdering;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;

import java.util.Map;
import java.util.function.Function;
import java.util.function.ToLongFunction;

public final class TransferPassExecutor {
    private final Map<String, VeilShaderPack.Resource> declarations;
    private final Function<String, GpuBuffer> buffers;
    private final ToLongFunction<String> images;
    private final int width;
    private final int height;
    private final Map<java.util.List<VeilTransfer>, boolean[]> ordering =
            new java.util.IdentityHashMap<>();

    public TransferPassExecutor(
            Map<String, VeilShaderPack.Resource> declarations,
            Function<String, GpuBuffer> buffers,
            ToLongFunction<String> images,
            int width,
            int height,
            java.util.List<VeilShaderPack.Pass> passes) {
        this.declarations = declarations;
        this.buffers = buffers;
        this.images = images;
        this.width = width;
        this.height = height;
        for (var pass : passes) {
            if (!pass.transfers().isEmpty())
                ordering.put(
                        pass.transfers(),
                        TransferWriteOrdering.plan(pass.transfers(), declarations));
        }
    }

    public void execute(VkCommandBuffer cmd, java.util.List<VeilTransfer> operations) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            boolean[] barriers = ordering.get(operations);
            if (barriers == null) throw new IllegalStateException("Unprepared transfer pass");
            int index = 0;
            for (VeilTransfer operation : operations) {
                if (barriers[index++]) {
                    var memory =
                            VkMemoryBarrier2.calloc(1, stack)
                                    .sType$Default()
                                    .srcStageMask(VK_PIPELINE_STAGE_2_ALL_TRANSFER_BIT)
                                    .srcAccessMask(VK_ACCESS_2_TRANSFER_WRITE_BIT)
                                    .dstStageMask(VK_PIPELINE_STAGE_2_ALL_TRANSFER_BIT)
                                    .dstAccessMask(VK_ACCESS_2_TRANSFER_WRITE_BIT);
                    KHRSynchronization2.vkCmdPipelineBarrier2KHR(
                            cmd,
                            VkDependencyInfo.calloc(stack).sType$Default().pMemoryBarriers(memory));
                }
                switch (operation.kind()) {
                    case BUFFER_COPY -> {
                        GpuBuffer source = buffers.apply(operation.source());
                        GpuBuffer destination = buffers.apply(operation.destination());
                        var copy =
                                VkBufferCopy.calloc(1, stack)
                                        .srcOffset(operation.sourceOffset())
                                        .dstOffset(operation.destinationOffset())
                                        .size(operation.size());
                        vkCmdCopyBuffer(
                                cmd,
                                ((VulkanGpuBuffer) source).vkBuffer(),
                                ((VulkanGpuBuffer) destination).vkBuffer(),
                                copy);
                    }
                    case BUFFER_FILL -> {
                        GpuBuffer destination = buffers.apply(operation.destination());
                        vkCmdFillBuffer(
                                cmd,
                                ((VulkanGpuBuffer) destination).vkBuffer(),
                                operation.destinationOffset(),
                                operation.size(),
                                operation.fillValue());
                    }
                    case BUFFER_TO_IMAGE -> {
                        GpuBuffer source = buffers.apply(operation.source());
                        validateRuntimeRegion(
                                declarations.get(operation.destination()),
                                operation.destinationRegion());
                        var region =
                                bufferImageRegion(
                                        operation.sourceOffset(),
                                        operation.destinationRegion(),
                                        operation.bufferLayout(),
                                        stack);
                        vkCmdCopyBufferToImage(
                                cmd,
                                ((VulkanGpuBuffer) source).vkBuffer(),
                                images.applyAsLong(operation.destination()),
                                VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                region);
                    }
                    case IMAGE_TO_BUFFER -> {
                        GpuBuffer destination = buffers.apply(operation.destination());
                        validateRuntimeRegion(
                                declarations.get(operation.source()), operation.sourceRegion());
                        var region =
                                bufferImageRegion(
                                        operation.destinationOffset(),
                                        operation.sourceRegion(),
                                        operation.bufferLayout(),
                                        stack);
                        vkCmdCopyImageToBuffer(
                                cmd,
                                images.applyAsLong(operation.source()),
                                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                                ((VulkanGpuBuffer) destination).vkBuffer(),
                                region);
                    }
                    case IMAGE_COPY -> {
                        var source = operation.sourceRegion();
                        var destination = operation.destinationRegion();
                        validateRuntimeRegion(declarations.get(operation.source()), source);
                        validateRuntimeRegion(
                                declarations.get(operation.destination()), destination);
                        var copy = VkImageCopy.calloc(1, stack);
                        copy.srcSubresource()
                                .aspectMask(aspect(source.aspect()))
                                .mipLevel(source.mip())
                                .baseArrayLayer(source.baseLayer())
                                .layerCount(source.layerCount());
                        copy.srcOffset().set(source.x(), source.y(), source.z());
                        copy.dstSubresource()
                                .aspectMask(aspect(destination.aspect()))
                                .mipLevel(destination.mip())
                                .baseArrayLayer(destination.baseLayer())
                                .layerCount(destination.layerCount());
                        copy.dstOffset().set(destination.x(), destination.y(), destination.z());
                        copy.extent().set(source.width(), source.height(), source.depth());
                        vkCmdCopyImage(
                                cmd,
                                images.applyAsLong(operation.source()),
                                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                                images.applyAsLong(operation.destination()),
                                VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                copy);
                    }
                    case IMAGE_BLIT_NEAREST, IMAGE_BLIT_LINEAR -> {
                        var source = operation.sourceRegion();
                        var destination = operation.destinationRegion();
                        validateRuntimeRegion(declarations.get(operation.source()), source);
                        validateRuntimeRegion(
                                declarations.get(operation.destination()), destination);
                        var region = VkImageBlit.calloc(1, stack);
                        region.srcSubresource()
                                .aspectMask(aspect(source.aspect()))
                                .mipLevel(source.mip())
                                .baseArrayLayer(source.baseLayer())
                                .layerCount(source.layerCount());
                        region.srcOffsets(0).set(source.x(), source.y(), source.z());
                        region.srcOffsets(1)
                                .set(
                                        source.x() + source.width(),
                                        source.y() + source.height(),
                                        source.z() + source.depth());
                        region.dstSubresource()
                                .aspectMask(aspect(destination.aspect()))
                                .mipLevel(destination.mip())
                                .baseArrayLayer(destination.baseLayer())
                                .layerCount(destination.layerCount());
                        region.dstOffsets(0).set(destination.x(), destination.y(), destination.z());
                        region.dstOffsets(1)
                                .set(
                                        destination.x() + destination.width(),
                                        destination.y() + destination.height(),
                                        destination.z() + destination.depth());
                        vkCmdBlitImage(
                                cmd,
                                images.applyAsLong(operation.source()),
                                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                                images.applyAsLong(operation.destination()),
                                VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                region,
                                operation.kind() == VeilTransfer.Kind.IMAGE_BLIT_LINEAR
                                        ? VK_FILTER_LINEAR
                                        : VK_FILTER_NEAREST);
                    }
                    case IMAGE_CLEAR -> clearImage(cmd, operation, stack);
                    case IMAGE_RESOLVE -> {
                        var source = operation.sourceRegion();
                        var destination = operation.destinationRegion();
                        validateRuntimeRegion(declarations.get(operation.source()), source);
                        validateRuntimeRegion(
                                declarations.get(operation.destination()), destination);
                        var region = VkImageResolve.calloc(1, stack);
                        region.srcSubresource()
                                .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                                .mipLevel(source.mip())
                                .baseArrayLayer(source.baseLayer())
                                .layerCount(source.layerCount());
                        region.srcOffset().set(source.x(), source.y(), source.z());
                        region.dstSubresource()
                                .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                                .mipLevel(destination.mip())
                                .baseArrayLayer(destination.baseLayer())
                                .layerCount(destination.layerCount());
                        region.dstOffset().set(destination.x(), destination.y(), destination.z());
                        region.extent().set(source.width(), source.height(), source.depth());
                        vkCmdResolveImage(
                                cmd,
                                images.applyAsLong(operation.source()),
                                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                                images.applyAsLong(operation.destination()),
                                VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                region);
                    }
                }
            }
        }
    }

    private VkBufferImageCopy.Buffer bufferImageRegion(
            long offset,
            VeilTransfer.ImageRegion source,
            VeilTransfer.BufferLayout layout,
            MemoryStack stack) {
        var region =
                VkBufferImageCopy.calloc(1, stack)
                        .bufferOffset(offset)
                        .bufferRowLength(layout == null ? 0 : layout.rowLengthTexels())
                        .bufferImageHeight(layout == null ? 0 : layout.imageHeightTexels());
        region.imageSubresource()
                .aspectMask(aspect(source.aspect()))
                .mipLevel(source.mip())
                .baseArrayLayer(source.baseLayer())
                .layerCount(source.layerCount());
        region.imageOffset().set(source.x(), source.y(), source.z());
        region.imageExtent().set(source.width(), source.height(), source.depth());
        return region;
    }

    private void clearImage(VkCommandBuffer cmd, VeilTransfer operation, MemoryStack stack) {
        VeilTransfer.ImageRegion region = operation.destinationRegion();
        VeilShaderPack.Resource resource = declarations.get(operation.destination());
        validateRuntimeRegion(resource, region);
        int clearWidth = Math.max(1, resource.resolvedWidth(width, declarations) >> region.mip());
        int clearHeight =
                Math.max(1, resource.resolvedHeight(height, declarations) >> region.mip());
        int clearDepth =
                resource.image3d() ? Math.max(1, resource.resolvedDepth() >> region.mip()) : 1;
        if (region.x() != 0
                || region.y() != 0
                || region.z() != 0
                || region.width() != clearWidth
                || region.height() != clearHeight
                || region.depth() != clearDepth) {
            throw new IllegalStateException(
                    "Image clear must cover complete selected subresources: " + resource.name());
        }
        int aspect = aspect(region.aspect());
        var range = VkImageSubresourceRange.calloc(1, stack);
        range.get(0)
                .aspectMask(aspect)
                .baseMipLevel(region.mip())
                .levelCount(1)
                .baseArrayLayer(region.baseLayer())
                .layerCount(region.layerCount());
        if (region.aspect() == VeilTransfer.Aspect.COLOR) {
            VeilTransfer.ClearValue value = operation.clear();
            TransferClearRules.validate(resource.format(), region.aspect(), value);
            var clear = VkClearColorValue.calloc(stack);
            switch (value.colorType()) {
                case FLOAT ->
                        clear.float32(0, value.r())
                                .float32(1, value.g())
                                .float32(2, value.b())
                                .float32(3, value.a());
                case SINT ->
                        clear.int32(0, value.c0())
                                .int32(1, value.c1())
                                .int32(2, value.c2())
                                .int32(3, value.c3());
                case UINT ->
                        clear.uint32(0, value.c0())
                                .uint32(1, value.c1())
                                .uint32(2, value.c2())
                                .uint32(3, value.c3());
            }
            vkCmdClearColorImage(
                    cmd,
                    images.applyAsLong(operation.destination()),
                    VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                    clear,
                    range);
        } else {
            VeilTransfer.ClearValue value = operation.clear();
            TransferClearRules.validate(resource.format(), region.aspect(), value);
            var clear =
                    VkClearDepthStencilValue.calloc(stack)
                            .depth(value.depth())
                            .stencil(value.stencil());
            vkCmdClearDepthStencilImage(
                    cmd,
                    images.applyAsLong(operation.destination()),
                    VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                    clear,
                    range);
        }
    }

    private static int aspect(VeilTransfer.Aspect aspect) {
        return switch (aspect) {
            case COLOR -> VK_IMAGE_ASPECT_COLOR_BIT;
            case DEPTH -> VK_IMAGE_ASPECT_DEPTH_BIT;
            case STENCIL -> VK_IMAGE_ASPECT_STENCIL_BIT;
        };
    }

    private void validateRuntimeRegion(
            VeilShaderPack.Resource resource, VeilTransfer.ImageRegion region) {
        int resolvedWidth =
                Math.max(1, resource.resolvedWidth(width, declarations) >> region.mip());
        int resolvedHeight =
                Math.max(1, resource.resolvedHeight(height, declarations) >> region.mip());
        int resolvedDepth =
                resource.image3d() ? Math.max(1, resource.resolvedDepth() >> region.mip()) : 1;
        if ((long) region.x() + region.width() > resolvedWidth
                || (long) region.y() + region.height() > resolvedHeight
                || (long) region.z() + region.depth() > resolvedDepth) {
            throw new IllegalStateException(
                    "Transfer image region exceeds resolved resource: " + resource.name());
        }
    }
}
