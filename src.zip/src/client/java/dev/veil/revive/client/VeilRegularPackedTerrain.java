package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.terrain.RegularTerrainVertices;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;

final class VeilRegularPackedTerrain {
    private static final int UPLOAD_LIMIT = 4 << 20;
    private static final RegularTerrainVertices.Layout[] LAYOUTS =
            RegularTerrainVertices.Layout.values();
    private static volatile boolean disabled;
    private static final IdentityHashMap<SectionMesh, EnumMap<ChunkSectionLayer, Entry>> ENTRIES =
            new IdentityHashMap<>();
    private static final IdentityHashMap<GpuBuffer, RegularTerrainVertices.Layout> FORMATS =
            new IdentityHashMap<>();
    private static final java.util.ArrayList<VeilManagedGpuArena<Entry>> ARENAS =
            new java.util.ArrayList<>(java.util.Arrays.asList(null, null, null));
    private static final AtomicLong VERIFIED = new AtomicLong();
    private static final AtomicLong VERIFIED_WIDE = new AtomicLong();
    private static final ConcurrentLinkedQueue<SectionMesh> RETIRED = new ConcurrentLinkedQueue<>();
    private static final IdentityHashMap<
                    SectionRenderDispatcher.RenderSection, EnumMap<ChunkSectionLayer, Reservation>>
            REPLACEMENTS = new IdentityHashMap<>();
    private static final java.util.ArrayDeque<Reservation> EXPIRATIONS =
            new java.util.ArrayDeque<>();
    private static VeilPersistentStagingBuffer staging;
    private static ByteBuffer scratch;
    private static long revision, uploaded16, uploaded20, submitted, savedBytes, retiredOwners;
    private static long preparedBytes, peakPreparedBytes, capacityRejections, capacitySkips;
    private static long uploadedWide, submittedWide;
    private static long reusedAllocations, expiredReservations;
    private static long attributeUpdates, attributeBytes, attributeSavedBytes, unchangedAttributes;
    private static long sliceReuses, sliceCreations;

    private VeilRegularPackedTerrain() {}

    static boolean enabled() {
        return Boolean.getBoolean("veil.regularPackedTerrain")
                && !disabled
                && ReviveRuntime.optimizationsEnabled()
                && VeilSectionChanges.notificationsSupported()
                && VeilShaderPackBridge.customTerrainShadersAllowed();
    }

    static void verify(ByteBuffer source, RegularTerrainVertices.Result result) {
        VeilRegularPackedGpuProbe.capture(source, result);
        boolean wide = result.layout().widePosition();
        if (!Boolean.getBoolean("veil.verifyRegularPackedTerrain")
                || (VERIFIED.get() >= 100_000 && (!wide || VERIFIED_WIDE.get() >= 100_000))) return;
        RegularTerrainVertices.verify(source, result);
        long before = VERIFIED.getAndAdd(result.vertexCount());
        if (before < 100_000 && before + result.vertexCount() >= 100_000)
            ReviveMod.LOGGER.info(
                    "Veil regular packed parity PASS: 100000 native vertices preserve atlas UV, tint/AO and light; position respects layout precision");
        if (wide) {
            long wideBefore = VERIFIED_WIDE.getAndAdd(result.vertexCount());
            if (wideBefore < 100_000 && wideBefore + result.vertexCount() >= 100_000)
                ReviveMod.LOGGER.info(
                        "Veil wide regular packed parity PASS: 100000 native vertices, position error <= {} blocks, exact UV/tint/AO/light",
                        RegularTerrainVertices.WIDE_POSITION_ERROR);
        }
    }

    static boolean forceWide() {
        return Boolean.getBoolean("veil.regularPackedForceWide")
                && Boolean.getBoolean("veil.benchmarkWorld")
                && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    }

    static void update(
            Map<ChunkSectionLayer, ? extends Map<?, List<RenderPass.Draw<GpuBufferSlice[]>>>>
                    groups) {
        drainRetired();
        expireReservations(System.nanoTime());
        if (!enabled()) return;
        int budget = UPLOAD_LIMIT;
        long preparedBefore = preparedBytes;
        boolean staged = false;
        boolean stagingAttempted = false;
        for (var layer : groups.entrySet()) {
            if (layer.getKey() == ChunkSectionLayer.TRANSLUCENT) continue;
            for (var draws : layer.getValue().values())
                for (var draw : draws) {
                    if (!(draw.uniformUploaderConsumer()
                            instanceof VeilSectionUniformUploader uploader)) continue;
                    var owner = ENTRIES.get(uploader.mesh());
                    Entry entry = owner == null ? null : owner.get(layer.getKey());
                    var reservation = reservation(uploader.section(), layer.getKey());
                    if (entry != null) {
                        if (entry.failedCapacityRevision < 0) continue;
                        if (reservation == null
                                && entry.failedCapacityRevision
                                        == ARENAS.get(entry.slot).capacityRevision()) {
                            capacitySkips++;
                            continue;
                        }
                        owner.remove(layer.getKey());
                    }
                    if (!(uploader.mesh() instanceof VeilMeshExtras extras)
                            || extras.veil$metadata() == null
                            || extras.veil$metadata().closed()) continue;
                    var data = extras.veil$metadata().regularPacked(layer.getKey());
                    if (data == null) continue;
                    int slot = data.layout().ordinal();
                    dev.veil.revive.core.terrain.AttributeUploadPlan attributePlan = null;
                    if (Boolean.getBoolean("veil.sparseAttributeUploads")
                            && reservation != null
                            && reservation.entry.slot == slot
                            && reservation.entry.data != null) {
                        var before = reservation.entry.data;
                        if (before.layout() == data.layout()
                                && before.vertexCount() == data.vertexCount())
                            attributePlan =
                                    dev.veil.revive.core.terrain.AttributeUploadPlan.packed(
                                            before, data, 4, 32);
                    }
                    int uploadSize =
                            attributePlan == null
                                    ? data.vertices().length
                                    : attributePlan.payloadBytes();
                    if (uploadSize > budget) continue;
                    if (staging == null)
                        staging =
                                new VeilPersistentStagingBuffer(
                                        "Veil regular compact uploads", UPLOAD_LIMIT);
                    if (ARENAS.get(slot) == null)
                        ARENAS.set(
                                slot,
                                new VeilManagedGpuArena<>(
                                        "Veil regular " + data.layout() + " vertices",
                                        GpuBuffer.USAGE_VERTEX,
                                        8 << 20,
                                        data.stride(),
                                        staging,
                                        slot == 0 ? 8 : 4));
                    budget -= uploadSize;
                    var arena = ARENAS.get(slot);
                    VeilManagedGpuArena.Admission admission;
                    stagingAttempted = true;
                    if (reservation != null && reservation.entry.slot == slot) {
                        entry = reservation.entry;
                        admission =
                                attributePlan != null
                                        ? arena.tryRestageAttributes(entry, attributePlan)
                                        : arena.tryRestageAllocation(
                                                entry,
                                                data.vertices().length,
                                                () -> prepare(data.vertices()));
                        if (admission == VeilManagedGpuArena.Admission.STAGING) continue;
                        consumeReservation(reservation);
                        if (admission == VeilManagedGpuArena.Admission.ADDED) reusedAllocations++;
                        else arena.removeAllocation(entry);
                    } else {
                        if (reservation != null) {
                            consumeReservation(reservation);
                            ARENAS.get(reservation.entry.slot).removeAllocation(reservation.entry);
                        }
                        admission = VeilManagedGpuArena.Admission.CAPACITY;
                    }
                    if (admission != VeilManagedGpuArena.Admission.ADDED) {
                        if (attributePlan != null) {
                            budget += uploadSize;
                            attributePlan = null;
                            uploadSize = data.vertices().length;
                            if (uploadSize > budget) continue;
                            budget -= uploadSize;
                        }
                        entry = new Entry(slot, -1, uploader.section());
                        admission =
                                arena.tryAddAllocation(
                                        entry,
                                        ignored -> revision++,
                                        data.vertices().length,
                                        () -> prepare(data.vertices()));
                    }
                    if (admission == VeilManagedGpuArena.Admission.STAGING) continue;
                    if (admission == VeilManagedGpuArena.Admission.CAPACITY) {
                        entry = new Entry(slot, arena.capacityRevision(), uploader.section());
                        capacityRejections++;
                    }
                    if (owner == null) {
                        owner = new EnumMap<>(ChunkSectionLayer.class);
                        ENTRIES.put(uploader.mesh(), owner);
                    }
                    owner.put(layer.getKey(), entry);
                    if (admission != VeilManagedGpuArena.Admission.ADDED) continue;
                    var previousData = entry.data;
                    entry.data = Boolean.getBoolean("veil.sparseAttributeUploads") ? data : null;
                    if (attributePlan != null) {
                        attributeUpdates++;
                        attributeBytes += attributePlan.payloadBytes();
                        attributeSavedBytes +=
                                data.vertices().length - attributePlan.payloadBytes();
                        preparedBytes += attributePlan.payloadBytes();
                        if (attributePlan.rangeCount() == 0) unchangedAttributes++;
                        VeilChangedLightGpuProbe.record(
                                arena,
                                entry,
                                uploader.section().getSectionNode(),
                                previousData,
                                data,
                                attributePlan);
                    }
                    staged = true;
                    savedBytes += (long) data.vertexCount() * (28 - data.stride());
                    if (slot == 0) uploaded16 += data.vertexCount();
                    else uploaded20 += data.vertexCount();
                    if (data.layout().widePosition()) uploadedWide += data.vertexCount();
                    if (VeilPackedAttributeProbe.REQUESTED)
                        VeilPackedAttributeProbe.record(
                                extras.veil$metadata().packedAttributeMap(layer.getKey()),
                                data,
                                false);
                }
        }
        peakPreparedBytes = Math.max(peakPreparedBytes, preparedBytes - preparedBefore);
        if (staged || stagingAttempted)
            try (var uploader =
                    staging.startUploading(RenderSystem.getDevice().createCommandEncoder())) {
                for (var arena : ARENAS)
                    if (arena != null)
                        arena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
            }
        for (var arena : ARENAS) if (arena != null) arena.maintain();
        VeilChangedLightGpuProbe.uploaded();
    }

    private static ByteBuffer prepare(byte[] vertices) {
        if (scratch == null || scratch.capacity() < vertices.length) {
            if (scratch != null) MemoryUtil.memFree(scratch);
            scratch = MemoryUtil.memAlloc(Math.max(4096, vertices.length));
        }
        preparedBytes += vertices.length;
        return scratch.clear().put(vertices).flip();
    }

    static void retire(SectionMesh mesh) {
        if (!disabled) RETIRED.offer(mesh);
    }

    private static void drainRetired() {
        SectionMesh mesh;
        while ((mesh = RETIRED.poll()) != null) {
            var owner = ENTRIES.remove(mesh);
            if (owner == null) continue;
            for (var layer : owner.entrySet()) {
                var entry = layer.getValue();
                var arena = ARENAS.get(entry.slot);
                if (entry.section != null && arena.getAllocation(entry) != null) {
                    var replacement =
                            new Reservation(
                                    entry.section,
                                    layer.getKey(),
                                    entry,
                                    System.nanoTime() + 1_000_000_000L);
                    var layers =
                            REPLACEMENTS.computeIfAbsent(
                                    entry.section,
                                    ignored -> new EnumMap<>(ChunkSectionLayer.class));
                    var previous = layers.put(layer.getKey(), replacement);
                    if (previous != null && previous.entry != entry)
                        ARENAS.get(previous.entry.slot).removeAllocation(previous.entry);
                    EXPIRATIONS.addLast(replacement);
                } else arena.removeAllocation(entry);
            }
            revision++;
            retiredOwners++;
            VeilRegularPackedLifecycleProbe.retired(mesh);
        }
    }

    private static Reservation reservation(
            SectionRenderDispatcher.RenderSection section, ChunkSectionLayer layer) {
        var layers = REPLACEMENTS.get(section);
        return layers == null ? null : layers.get(layer);
    }

    private static void consumeReservation(Reservation reservation) {
        var layers = REPLACEMENTS.get(reservation.section);
        if (layers != null && layers.get(reservation.layer) == reservation) {
            layers.remove(reservation.layer);
            if (layers.isEmpty()) REPLACEMENTS.remove(reservation.section);
        }
    }

    private static void expireReservations(long now) {
        for (int removed = 0;
                removed < 64 && !EXPIRATIONS.isEmpty() && EXPIRATIONS.peekFirst().expires <= now;
                removed++) {
            var reservation = EXPIRATIONS.removeFirst();
            if (reservation(reservation.section, reservation.layer) != reservation) continue;
            consumeReservation(reservation);
            ARENAS.get(reservation.entry.slot).removeAllocation(reservation.entry);
            expiredReservations++;
            revision++;
        }
    }

    static boolean hasOwner(SectionMesh mesh) {
        return ENTRIES.containsKey(mesh);
    }

    record Slice(GpuBuffer buffer, int baseVertex) {}

    static Slice get(SectionMesh mesh, ChunkSectionLayer layer) {
        if (!enabled()) return null;
        if (!(mesh instanceof VeilMeshExtras extras)
                || extras.veil$metadata() == null
                || extras.veil$metadata().closed()) return null;
        var owner = ENTRIES.get(mesh);
        Entry entry = owner == null ? null : owner.get(layer);
        if (entry == null) return null;
        var arena = ARENAS.get(entry.slot);
        var allocation = arena.getAllocation(entry);
        if (allocation == null) return null;
        var buffer = arena.getGpuBuffer(allocation);
        int stride = entry.slot == 0 ? 16 : 20;
        FORMATS.put(buffer, LAYOUTS[entry.slot]);
        int baseVertex = Math.toIntExact(allocation.offset() / stride);
        var cached = entry.cachedSlice;
        if (cached != null && cached.buffer() == buffer && cached.baseVertex() == baseVertex) {
            sliceReuses++;
            return cached;
        }
        sliceCreations++;
        return entry.cachedSlice = new Slice(buffer, baseVertex);
    }

    static int stride(GpuBuffer buffer) {
        var layout = FORMATS.get(buffer);
        if (layout != null) return layout.stride();
        int slot = VeilPairedTerrainArena.formatSlot(buffer);
        return slot < 0 ? 0 : LAYOUTS[slot].stride();
    }

    static int formatSlot(GpuBuffer buffer) {
        var layout = FORMATS.get(buffer);
        return layout == null ? VeilPairedTerrainArena.formatSlot(buffer) : layout.ordinal();
    }

    static long revision() {
        return revision + VeilPairedTerrainArena.revision() + VeilParametricTerrainArena.revision();
    }

    static void recordSubmission(GpuBuffer buffer, int commands) {
        VeilParametricTerrainArena.recordSubmission(buffer, commands);
        VeilPairedTerrainArena.recordGpuSubmission(buffer, commands);
        if (stride(buffer) == 0) return;
        if (submitted == 0)
            ReviveMod.LOGGER.info(
                    "Veil regular packed terrain ACTIVE: {} byte vertices, native atlas UV and canonical fallback",
                    stride(buffer));
        submitted += commands;
        if (formatSlot(buffer) == RegularTerrainVertices.Layout.WIDE_POSITION20.ordinal())
            submittedWide += commands;
    }

    static void requireComplete() {
        if (Boolean.getBoolean("veil.verifySparseAttributeUploads")) {
            if (attributeUpdates == 0 || unchangedAttributes == 0 || attributeSavedBytes == 0)
                throw new IllegalStateException("Connected sparse attribute updates not exercised");
            ReviveMod.LOGGER.info(
                    "Veil sparse attribute client: PASS (updates={} uploaded_bytes={} saved_bytes={} unchanged={})",
                    attributeUpdates,
                    attributeBytes,
                    attributeSavedBytes,
                    unchangedAttributes);
        }
        if (!Boolean.getBoolean("veil.verifyRegularPackedTerrain")) return;
        if (VERIFIED.get() < 100_000 || submitted == 0 || uploaded16 + uploaded20 == 0)
            throw new IllegalStateException(
                    "Regular compact terrain native verification incomplete");
        if (peakPreparedBytes > UPLOAD_LIMIT)
            throw new IllegalStateException("Regular compact CPU copy budget exceeded");
        if (Boolean.getBoolean("veil.verifyRegularPackedWide")
                && (VERIFIED_WIDE.get() < 100_000 || uploadedWide == 0 || submittedWide == 0))
            throw new IllegalStateException("Wide regular compact native verification incomplete");
        if ("false".equalsIgnoreCase(System.getProperty("veil.regularPackedPrefer16"))
                && (uploaded20 == 0 || uploaded16 != 0))
            throw new IllegalStateException(
                    "Forced 20-byte regular terrain verification incomplete");
        ReviveMod.LOGGER.info(
                "Veil regular packed verification: vertices16={} vertices20={} submitted_commands={} saved_vertex_bytes={}",
                uploaded16,
                uploaded20,
                submitted,
                savedBytes);
    }

    static void disable() {
        disabled = true;
        close();
    }

    static void close() {
        VeilPairedTerrainArena.close();
        VeilParametricTerrainArena.close();
        for (int i = 0; i < ARENAS.size(); i++) {
            if (ARENAS.get(i) != null) ARENAS.get(i).close();
            ARENAS.set(i, null);
        }
        if (staging != null) staging.close();
        staging = null;
        if (scratch != null) MemoryUtil.memFree(scratch);
        scratch = null;
        ENTRIES.clear();
        REPLACEMENTS.clear();
        EXPIRATIONS.clear();
        RETIRED.clear();
        FORMATS.clear();
        revision++;
    }

    static String telemetry() {
        return "terrain_regular_packed16_vertices="
                + uploaded16
                + "\nterrain_regular_packed20_vertices="
                + uploaded20
                + "\nterrain_regular_packed_commands="
                + submitted
                + "\nterrain_regular_packed_saved_vertex_bytes="
                + savedBytes
                + "\nterrain_regular_packed_retired_owners="
                + retiredOwners
                + "\nterrain_regular_packed_prepared_bytes="
                + preparedBytes
                + "\nterrain_regular_packed_peak_prepared_bytes="
                + peakPreparedBytes
                + "\nterrain_regular_packed_capacity_rejections="
                + capacityRejections
                + "\nterrain_regular_packed_capacity_skips="
                + capacitySkips
                + "\nterrain_regular_packed_wide_vertices="
                + uploadedWide
                + "\nterrain_regular_packed_wide_commands="
                + submittedWide
                + "\nterrain_regular_packed_reused_allocations="
                + reusedAllocations
                + "\nterrain_regular_packed_expired_reservations="
                + expiredReservations
                + "\nterrain_regular_packed_slice_reuses="
                + sliceReuses
                + "\nterrain_regular_packed_slice_creations="
                + sliceCreations
                + "\nterrain_sparse_attribute_updates="
                + attributeUpdates
                + "\nterrain_sparse_attribute_uploaded_bytes="
                + attributeBytes
                + "\nterrain_sparse_attribute_saved_bytes="
                + attributeSavedBytes
                + "\nterrain_sparse_attribute_unchanged="
                + unchangedAttributes
                + "\n";
    }

    private static final class Entry {
        final int slot;
        final long failedCapacityRevision;
        final SectionRenderDispatcher.RenderSection section;
        RegularTerrainVertices.Result data;
        Slice cachedSlice;

        Entry(
                int slot,
                long failedCapacityRevision,
                SectionRenderDispatcher.RenderSection section) {
            this.slot = slot;
            this.failedCapacityRevision = failedCapacityRevision;
            this.section = section;
        }
    }

    private record Reservation(
            SectionRenderDispatcher.RenderSection section,
            ChunkSectionLayer layer,
            Entry entry,
            long expires) {}
}
