package dev.veil.revive.client;

import static org.lwjgl.util.shaderc.Shaderc.*;

import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.shaderc.ShadercIncludeResolve;
import org.lwjgl.util.shaderc.ShadercIncludeResult;
import org.lwjgl.util.shaderc.ShadercIncludeResultRelease;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class VeilShaderIncludes implements AutoCloseable {
    public record Preprocessed(
            String source,
            Map<VeilShaderId, String> dependencies,
            Map<VeilShaderId, Set<VeilShaderId>> graph) {
        public Preprocessed {
            dependencies = Map.copyOf(dependencies);
            var copy = new LinkedHashMap<VeilShaderId, Set<VeilShaderId>>();
            graph.forEach((id, children) -> copy.put(id, Set.copyOf(children)));
            graph = Map.copyOf(copy);
        }
    }

    private record Allocation(ShadercIncludeResult result, ByteBuffer name, ByteBuffer content) {
        void release() {
            result.free();
            MemoryUtil.memFree(name);
            MemoryUtil.memFree(content);
        }
    }

    private final VeilShaderAssets assets;
    private final Map<VeilShaderId, String> dependencies = new LinkedHashMap<>();
    private final Map<VeilShaderId, String> sources = new LinkedHashMap<>();
    private final Map<VeilShaderId, Set<VeilShaderId>> graph = new LinkedHashMap<>();
    private final Map<Long, Allocation> allocations = new LinkedHashMap<>();
    private final List<VeilShaderId> chain = new ArrayList<>();
    private final Map<String, String> failures = new LinkedHashMap<>();
    private final ShadercIncludeResolve resolver;
    private final ShadercIncludeResultRelease releaser;
    private int sourceBytes;

    private VeilShaderIncludes(VeilShaderAssets assets, VeilShaderId root) {
        this.assets = assets;
        chain.add(root);
        resolver = ShadercIncludeResolve.create(this::resolve);
        releaser = ShadercIncludeResultRelease.create((userData, address) -> release(address));
    }

    public static Preprocessed preprocess(
            VeilShaderAssets assets, VeilShaderId root, VeilShaderStage stage) throws IOException {
        try (var includes = new VeilShaderIncludes(assets, root)) {
            String source = includes.load(root);
            long compiler = shaderc_compiler_initialize();
            if (compiler == 0)
                throw new IllegalStateException("shaderc compiler allocation failed");
            long options = 0;
            long result = 0;
            try {
                options = shaderc_compile_options_initialize();
                if (options == 0)
                    throw new IllegalStateException("shaderc options allocation failed");
                shaderc_compile_options_set_target_env(
                        options, shaderc_target_env_vulkan, shaderc_env_version_vulkan_1_2);
                shaderc_compile_options_set_include_callbacks(
                        options, includes.resolver, includes.releaser, 0);
                result =
                        shaderc_compile_into_preprocessed_text(
                                compiler,
                                source,
                                stage.shadercKind(),
                                root.toString(),
                                "main",
                                options);
                if (result == 0)
                    throw new IllegalStateException("shaderc preprocessing returned null: " + root);
                if (shaderc_result_get_compilation_status(result)
                        != shaderc_compilation_status_success) {
                    throw new IllegalArgumentException(
                            "Shader include/preprocess failure ["
                                    + stage
                                    + "] "
                                    + root
                                    + "\n"
                                    + shaderc_result_get_error_message(result));
                }
                ByteBuffer bytes = shaderc_result_get_bytes(result);
                if (bytes.remaining() > VeilShaderAssets.MAX_SHADER_ASSET_BYTES) {
                    throw new IllegalArgumentException(
                            "Preprocessed shader exceeds 4 MiB: " + root);
                }
                return new Preprocessed(
                        StandardCharsets.UTF_8.decode(bytes).toString(),
                        includes.dependencies,
                        includes.graph);
            } finally {
                if (result != 0) shaderc_result_release(result);
                if (options != 0) shaderc_compile_options_release(options);
                shaderc_compiler_release(compiler);
            }
        }
    }

    private String load(VeilShaderId id) throws IOException {
        String cached = sources.get(id);
        if (cached != null) return cached;
        if (sources.size() >= 256)
            throw new IOException("Shader include dependency limit exceeded: " + id);
        byte[] bytes = assets.read(id);
        if (bytes.length > VeilShaderAssets.MAX_SHADER_ASSET_BYTES)
            throw new IOException("Shader source exceeds 4 MiB: " + id);
        sourceBytes = Math.addExact(sourceBytes, bytes.length);
        if (sourceBytes > 16 * 1024 * 1024)
            throw new IOException("Shader include sources exceed 16 MiB: " + id);
        dependencies.put(id, VeilShaderAssets.hash(bytes));
        String source = new String(bytes, StandardCharsets.UTF_8);
        sources.put(id, source);
        return source;
    }

    private long resolve(long userData, long requested, int type, long requesting, long depth) {
        String name = "";
        String content;
        String include = MemoryUtil.memUTF8(requested);
        String requestingName = MemoryUtil.memUTF8(requesting);
        String key = requestingName + "\0" + include;
        try {
            if (type != shaderc_include_type_relative && failures.containsKey(key)) {
                throw new IllegalArgumentException(failures.get(key));
            }
            VeilShaderId parent = VeilShaderId.parse(requestingName);
            VeilShaderId child =
                    type == shaderc_include_type_relative
                            ? parent.relative(include)
                            : VeilShaderId.parse(include);
            if (depth < 1 || depth > 64)
                throw new IllegalArgumentException("Include depth exceeds 64: " + child);
            while (chain.size() > depth) chain.removeLast();
            if (chain.contains(child))
                throw new IllegalArgumentException("Include cycle: " + chain + " -> " + child);
            graph.computeIfAbsent(parent, ignored -> new LinkedHashSet<>()).add(child);
            chain.add(child);
            content = load(child);
            name = child.toString();
        } catch (IOException | IllegalArgumentException failure) {
            content = failure.getMessage();
            failures.put(key, content);
        }
        ByteBuffer nativeName = MemoryUtil.memUTF8(name);
        nativeName.limit(nativeName.limit() - 1);
        ByteBuffer nativeContent = MemoryUtil.memUTF8(content);
        nativeContent.limit(nativeContent.limit() - 1);
        ShadercIncludeResult result =
                ShadercIncludeResult.calloc().source_name(nativeName).content(nativeContent);
        allocations.put(result.address(), new Allocation(result, nativeName, nativeContent));
        return result.address();
    }

    private void release(long address) {
        Allocation allocation = allocations.remove(address);
        if (allocation != null) allocation.release();
    }

    @Override
    public void close() {
        allocations.values().forEach(Allocation::release);
        allocations.clear();
        releaser.free();
        resolver.free();
    }
}
