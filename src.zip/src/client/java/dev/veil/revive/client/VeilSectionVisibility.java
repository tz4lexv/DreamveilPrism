package dev.veil.revive.client;

import dev.veil.revive.core.terrain.SectionVisibilityGraph;
import dev.veil.revive.core.terrain.WorkerLeaseCache;

import net.minecraft.client.renderer.chunk.VisGraph;
import net.minecraft.client.renderer.chunk.VisibilitySet;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import java.util.concurrent.atomic.LongAdder;

public final class VeilSectionVisibility implements AutoCloseable {
    private static final boolean REQUESTED = Boolean.getBoolean("veil.ownSectionVisibility");
    private static final boolean VERIFY =
            REQUESTED
                    && Boolean.getBoolean("veil.verifySectionVisibility")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final Direction[] FACES = {
        Direction.DOWN,
        Direction.UP,
        Direction.NORTH,
        Direction.SOUTH,
        Direction.WEST,
        Direction.EAST
    };
    private static final WorkerLeaseCache<Integer, SectionVisibilityGraph> WORKERS =
            new WorkerLeaseCache<>(
                    key -> new SectionVisibilityGraph(), SectionVisibilityGraph::begin);
    private static final LongAdder COMPILED = new LongAdder(),
            REUSED = new LongAdder(),
            CREATED = new LongAdder(),
            NESTED = new LongAdder(),
            VERIFIED = new LongAdder(),
            SPANS = new LongAdder(),
            NATIVE_RESOLVED = new LongAdder(),
            OWN_NS = new LongAdder(),
            NATIVE_NS = new LongAdder();
    private final WorkerLeaseCache.Lease<SectionVisibilityGraph> own;
    private final VisGraph nativeGraph;

    private VeilSectionVisibility(
            WorkerLeaseCache.Lease<SectionVisibilityGraph> own, VisGraph nativeGraph) {
        this.own = own;
        this.nativeGraph = nativeGraph;
    }

    public static VeilSectionVisibility open() {
        var lease = REQUESTED ? WORKERS.borrow(0, true) : null;
        try {
            if (lease != null && (VERIFY || VeilTechniqueCounters.collecting())) {
                if (lease.reused()) REUSED.increment();
                else CREATED.increment();
                if (lease.nested()) NESTED.increment();
            }
            return new VeilSectionVisibility(
                    lease, lease == null || VERIFY ? new VisGraph() : null);
        } catch (RuntimeException | Error failure) {
            if (lease != null) {
                try {
                    lease.close();
                } catch (RuntimeException | Error cleanup) {
                    failure.addSuppressed(cleanup);
                }
            }
            throw failure;
        }
    }

    public void opaque(int x, int y, int z, BlockPos position) {
        if (own != null) own.value().setOpaque(x, y, z);
        if (nativeGraph != null) nativeGraph.setOpaque(position);
    }

    public VisibilitySet resolve() {
        boolean measure = VeilTechniqueCounters.collecting();
        long start = measure ? System.nanoTime() : 0;
        try {
            if (own != null) return resolveOwn();
            var result = nativeGraph.resolve();
            if (measure) NATIVE_RESOLVED.increment();
            return result;
        } finally {
            if (measure) {
                long elapsed = System.nanoTime() - start;
                if (own == null) NATIVE_NS.add(elapsed);
                else OWN_NS.add(elapsed);
            }
        }
    }

    private VisibilitySet resolveOwn() {
        var graph = own.value();
        long connections = graph.resolve();
        var result = new VisibilitySet();
        for (int from = 0; from < 6; from++)
            for (int to = 0; to < 6; to++)
                result.set(FACES[from], FACES[to], (connections & (1L << (from * 6 + to))) != 0);
        if (VERIFY) {
            var reference = nativeGraph.resolve();
            for (var from : FACES)
                for (var to : FACES)
                    if (reference.visibilityBetween(from, to) != result.visibilityBetween(from, to))
                        throw new IllegalStateException(
                                "Section visibility differs: " + from + "/" + to);
            VERIFIED.increment();
        }
        if (VERIFY || VeilTechniqueCounters.collecting()) {
            COMPILED.increment();
            SPANS.add(graph.spansVisited());
        }
        return result;
    }

    public record Counters(
            long ownResolved,
            long nativeResolved,
            long ownNs,
            long nativeNs,
            long created,
            long reused,
            long nested,
            long spans) {
        public Counters minus(Counters before) {
            return new Counters(
                    ownResolved - before.ownResolved,
                    nativeResolved - before.nativeResolved,
                    ownNs - before.ownNs,
                    nativeNs - before.nativeNs,
                    created - before.created,
                    reused - before.reused,
                    nested - before.nested,
                    spans - before.spans);
        }
    }

    public static Counters counters() {
        return new Counters(
                COMPILED.sum(),
                NATIVE_RESOLVED.sum(),
                OWN_NS.sum(),
                NATIVE_NS.sum(),
                CREATED.sum(),
                REUSED.sum(),
                NESTED.sum(),
                SPANS.sum());
    }

    @Override
    public void close() {
        if (own != null) own.close();
    }

    static void requireComplete() {
        if (!REQUESTED) return;
        if (COMPILED.sum() == 0
                || REUSED.sum() == 0
                || SPANS.sum() == 0
                || VERIFY && VERIFIED.sum() == 0)
            throw new IllegalStateException("Own section visibility incomplete");
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil section visibility: PASS (compiled={} created={} reused={} nested={} verified={} spans={})",
                COMPILED.sum(),
                CREATED.sum(),
                REUSED.sum(),
                NESTED.sum(),
                VERIFIED.sum(),
                SPANS.sum());
    }
}
