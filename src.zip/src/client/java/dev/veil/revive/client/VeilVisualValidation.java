package dev.veil.revive.client;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

final class VeilVisualValidation {
    private static State state = State.IDLE;
    private static int waitFrames;
    private static boolean restoreBypass;
    private static Path onPath;
    private static Path bypassPath;
    private static final AtomicBoolean captureFinished = new AtomicBoolean();
    private static String lastResult;

    private VeilVisualValidation() {}

    static boolean active() {
        return state != State.IDLE;
    }

    static String lastResult() {
        return lastResult;
    }

    static String status() {
        if (state == State.IDLE) return lastResult == null ? "idle" : lastResult;
        return switch (state) {
            case WAIT_ON -> "preparing Veil ON capture";
            case CAPTURE_ON -> "capturing Veil ON";
            case WAIT_BYPASS -> "preparing BYPASS capture";
            case CAPTURE_BYPASS -> "capturing BYPASS";
            case IDLE -> "idle";
        };
    }

    static void start(Minecraft client) {
        if (active()) {
            VeilDiagnostics.message(client, "Veil visual validation is already running.");
            return;
        }
        if (client.player == null) {
            VeilDiagnostics.message(client, "Enter a world before starting visual validation.");
            return;
        }

        Path dir =
                VeilPlatform.get().getGameDir().resolve("screenshots").resolve("veil-validation");
        try {
            Files.createDirectories(dir);
        } catch (Exception e) {
            VeilDiagnostics.message(client, "Could not create screenshots/veil-validation.");
            return;
        }

        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        onPath = dir.resolve(stamp + "-veil-on.png");
        bypassPath = dir.resolve(stamp + "-veil-bypass.png");
        restoreBypass = VeilDiagnostics.bypassed();
        lastResult = null;

        VeilDiagnostics.setBypassed(false, client, false);
        waitFrames = 4;
        state = State.WAIT_ON;
        VeilDiagnostics.message(
                client, "Veil visual A/B capture started. Keep camera and world view still.");
    }

    static void onRenderedFrame() {
        if ((state == State.WAIT_ON || state == State.WAIT_BYPASS)
                && waitFrames != Integer.MAX_VALUE) {
            if (--waitFrames <= 0) {
                state = state == State.WAIT_ON ? State.CAPTURE_ON : State.CAPTURE_BYPASS;
            }
        }
    }

    static void onClientTick(Minecraft client) {
        if (state == State.CAPTURE_ON) {
            if (!captureFinished.get()) {
                captureFinished.set(false);
                if (!capture(client, onPath)) {
                    fail(client, "screenshot API unavailable");
                    return;
                }

                state = State.WAIT_ON;
                waitFrames = Integer.MAX_VALUE;
            }
            if (captureFinished.getAndSet(false)) {
                VeilDiagnostics.setBypassed(true, client, false);
                waitFrames = 4;
                state = State.WAIT_BYPASS;
            }
        } else if (state == State.CAPTURE_BYPASS) {
            if (!captureFinished.get()) {
                captureFinished.set(false);
                if (!capture(client, bypassPath)) {
                    fail(client, "screenshot API unavailable");
                    return;
                }
                state = State.WAIT_BYPASS;
                waitFrames = Integer.MAX_VALUE;
            }
            if (captureFinished.getAndSet(false)) {
                VeilDiagnostics.setBypassed(restoreBypass, client, false);
                lastResult =
                        "pair saved: " + onPath.getFileName() + " / " + bypassPath.getFileName();
                state = State.IDLE;
                VeilDiagnostics.message(
                        client, "Veil visual pair saved in screenshots/veil-validation.");
            }
        } else if ((state == State.WAIT_ON || state == State.WAIT_BYPASS)
                && waitFrames == Integer.MAX_VALUE
                && captureFinished.getAndSet(false)) {

            if (state == State.WAIT_ON) {
                VeilDiagnostics.setBypassed(true, client, false);
                waitFrames = 4;
                state = State.WAIT_BYPASS;
            } else {
                VeilDiagnostics.setBypassed(restoreBypass, client, false);
                lastResult =
                        "pair saved: " + onPath.getFileName() + " / " + bypassPath.getFileName();
                state = State.IDLE;
                VeilDiagnostics.message(
                        client, "Veil visual pair saved in screenshots/veil-validation.");
            }
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static boolean capture(Minecraft client, Path path) {
        try {
            Object gameRenderer = client.gameRenderer;
            Object target;
            try {
                target = gameRenderer.getClass().getMethod("mainRenderTarget").invoke(gameRenderer);
            } catch (NoSuchMethodException newerApiMissing) {
                target = client.getClass().getMethod("getMainRenderTarget").invoke(client);
            }

            Class<?> screenshotClass = Class.forName("net.minecraft.client.Screenshot");
            Method take = null;
            for (Method method : screenshotClass.getMethods()) {
                if (!method.getName().equals("takeScreenshot")) continue;
                Class<?>[] params = method.getParameterTypes();
                if (params.length == 2 && Consumer.class.isAssignableFrom(params[1])) {
                    take = method;
                    break;
                }
            }
            if (take == null) return false;

            Consumer consumer =
                    image -> {
                        try {
                            Method write = image.getClass().getMethod("writeToFile", Path.class);
                            write.invoke(image, path);
                        } catch (Throwable failure) {
                            ReviveMod.LOGGER.warn(
                                    "Could not save Veil visual validation screenshot {}",
                                    path,
                                    failure);
                        } finally {
                            try {
                                if (image instanceof AutoCloseable closeable) closeable.close();
                            } catch (Exception ignored) {
                            }
                            captureFinished.set(true);
                        }
                    };
            take.invoke(null, target, consumer);
            return true;
        } catch (Throwable failure) {
            ReviveMod.LOGGER.warn("Veil visual validation capture unavailable", failure);
            return false;
        }
    }

    private static void fail(Minecraft client, String reason) {
        VeilDiagnostics.setBypassed(restoreBypass, client, false);
        state = State.IDLE;
        lastResult = "failed: " + reason;
        VeilDiagnostics.message(client, "Veil visual validation failed: " + reason);
    }

    private enum State {
        IDLE,
        WAIT_ON,
        CAPTURE_ON,
        WAIT_BYPASS,
        CAPTURE_BYPASS
    }
}
