package dev.veil.revive.client;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

public record VeilMaterialRange(
        ChunkSectionLayer layer, int firstVertex, int vertexCount, int materialId) {
    public VeilMaterialRange {
        if (layer == null) throw new IllegalArgumentException("Material range layer is null");
        if (firstVertex < 0 || vertexCount <= 0)
            throw new IllegalArgumentException("Invalid material vertex range");
        if ((vertexCount & 3) != 0)
            throw new IllegalArgumentException("Fluid material range must contain complete quads");
        if (materialId < 1 || materialId > 255)
            throw new IllegalArgumentException("Material id must be within 1..255");
    }
}
