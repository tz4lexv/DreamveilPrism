package dev.veil.revive.client;

import jdk.jfr.Category;
import jdk.jfr.Event;
import jdk.jfr.EventType;
import jdk.jfr.Label;
import jdk.jfr.Name;
import jdk.jfr.StackTrace;

final class VeilFrameJfrAnchor {
    private static final boolean ENABLED = Boolean.getBoolean("veil.frameJfrAnchors");
    private static final EventType TYPE =
            ENABLED ? EventType.getEventType(ClockAnchor.class) : null;
    private static final int PHASE_COUNT =
            3 * Math.clamp(Integer.getInteger("veil.cameraSweepRepetitions", 1), 1, 5);
    private static final long[] INDICES = ENABLED ? new long[PHASE_COUNT] : null;
    private static final boolean[] RECORDED = ENABLED ? new boolean[PHASE_COUNT] : null;

    private VeilFrameJfrAnchor() {}

    static void sample(int phase, String phaseName, long frameEndNanos) {
        if (!ENABLED) return;
        long index = INDICES[phase]++;
        if (RECORDED[phase] || !TYPE.isEnabled()) return;
        ClockAnchor event = new ClockAnchor();
        event.phase = phaseName;
        event.sampleIndex = index;
        event.frameEndNanos = frameEndNanos;
        event.begin();
        event.calibrationNanos = System.nanoTime();
        event.end();
        event.commit();
        RECORDED[phase] = true;
    }

    static void captureWritten(java.nio.file.Path path) throws java.io.IOException {
        if (!ENABLED || !EventType.getEventType(CaptureDigest.class).isEnabled()) return;
        try {
            CaptureDigest event = new CaptureDigest();
            event.sha256 =
                    java.util.HexFormat.of()
                            .formatHex(
                                    java.security.MessageDigest.getInstance("SHA-256")
                                            .digest(java.nio.file.Files.readAllBytes(path)));
            event.commit();
        } catch (java.security.NoSuchAlgorithmException failure) {
            throw new IllegalStateException(failure);
        }
    }

    @Name("dev.veil.FrameCaptureDigest")
    @Label("Veil frame capture digest")
    @Category({"Veil", "Diagnostics"})
    @StackTrace(false)
    static final class CaptureDigest extends Event {
        public String sha256;
    }

    @Name("dev.veil.FrameClockAnchor")
    @Label("Veil frame clock anchor")
    @Category({"Veil", "Diagnostics"})
    @StackTrace(false)
    static final class ClockAnchor extends Event {
        public String phase;
        public long sampleIndex;
        public long frameEndNanos;
        public long calibrationNanos;
    }
}
