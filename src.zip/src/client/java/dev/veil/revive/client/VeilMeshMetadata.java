package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;

import net.minecraft.client.renderer.chunk.*;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.EnumMap;

public final class VeilMeshMetadata {
    private final boolean lightOnlyUpdate;
    private final EnumMap<ChunkSectionLayer, VeilCanonicalData> canonical =
            new EnumMap<>(ChunkSectionLayer.class);
    private static final java.util.concurrent.atomic.LongAdder
            ATTRIBUTE_MAPS = new java.util.concurrent.atomic.LongAdder(),
            INDEXED_ATTRIBUTE_MAPS = new java.util.concurrent.atomic.LongAdder(),
            ATTRIBUTE_CORNERS = new java.util.concurrent.atomic.LongAdder();
    private dev.veil.revive.core.PlanarTerrainLod.Result lod;
    private dev.veil.revive.core.DirectionalQuadBuckets.Layout lodBuckets;
    private VeilProgressiveMeshing.Request progressive;
    private volatile VeilProgressiveMeshing.Owner progressiveOwner;
    private EnumMap<ChunkSectionLayer, VeilProgressiveMeshing.Request> progressiveLayers;
    private final EnumMap<ChunkSectionLayer, float[]> bounds =
            new EnumMap<>(ChunkSectionLayer.class);
    private final TextureAtlasSprite[] animatedSprites;
    private final VeilMaterialRange[] materialRanges;
    private final VeilFluidGeometry[] fluidGeometry;
    private final VeilRaySectionGeometry rayGeometry;
    private long uploadBytes;
    private volatile boolean closed;
    private volatile VeilOriginalQuadCapture.Snapshot originalQuads;
    private final EnumMap<ChunkSectionLayer, dev.veil.revive.core.terrain.PackedTerrainAttributeMap>
            packedAttributeMaps = new EnumMap<>(ChunkSectionLayer.class);
    private final EnumMap<ChunkSectionLayer, dev.veil.revive.core.terrain.TerrainAttributeMap>
            attributeMaps = new EnumMap<>(ChunkSectionLayer.class);
    private final EnumMap<
                    ChunkSectionLayer, dev.veil.revive.core.terrain.RegularTerrainVertices.Result>
            regularPacked = new EnumMap<>(ChunkSectionLayer.class);

    public VeilMeshMetadata(SectionCompiler.Results results) {
        VeilSectionCompileExtras extras = (VeilSectionCompileExtras) (Object) results;
        lightOnlyUpdate = extras.veil$lightOnlyUpdate();
        animatedSprites = extras.veil$animatedSprites();
        materialRanges = extras.veil$materialRanges().clone();
        VeilFluidGeometry[] sourceFluid = extras.veil$fluidGeometry();
        fluidGeometry = new VeilFluidGeometry[sourceFluid.length];
        for (int i = 0; i < sourceFluid.length; ++i) fluidGeometry[i] = sourceFluid[i].copy();
        rayGeometry =
                VeilWorldRayScene.requested() ? VeilRaySectionGeometry.capture(results) : null;
        long producedBytes = 0L;
        boolean buildCustomTerrainMetadata = VeilShaderPackBridge.customTerrainShadersAllowed();
        for (var entry : results.renderedLayers.entrySet()) {
            var mesh = entry.getValue();
            producedBytes += mesh.vertexBuffer().remaining();
            if (mesh.indexBuffer() != null) producedBytes += mesh.indexBuffer().remaining();
            if (!mesh.drawState().format().equals(DefaultVertexFormat.BLOCK)) continue;

            if (!buildCustomTerrainMetadata) {
                VeilShaderPackBridge.recordCustomTerrainMetadataSkip();
                if (entry.getKey() == ChunkSectionLayer.SOLID
                        && mesh.indexBuffer() == null
                        && ReviveRuntime.optimizationsEnabled()
                        && VeilVideoConfig.on("renderer.lod")) {
                    VeilShaderPackBridge.recordCustomTerrainAnalysisSkip();
                }
                continue;
            }

            ByteBuffer vertices = mesh.vertexBuffer().duplicate().order(ByteOrder.nativeOrder());
            float[] box = {
                Float.POSITIVE_INFINITY,
                Float.POSITIVE_INFINITY,
                Float.POSITIVE_INFINITY,
                Float.NEGATIVE_INFINITY,
                Float.NEGATIVE_INFINITY,
                Float.NEGATIVE_INFINITY
            };
            boolean valid = true;
            int stride = mesh.drawState().format().getVertexSize();
            for (int v = 0; v < mesh.drawState().vertexCount(); v++) {
                for (int axis = 0; axis < 3; axis++) {
                    float p = vertices.getFloat(v * stride + axis * 4);
                    if (!Float.isFinite(p)) valid = false;
                    box[axis] = Math.min(box[axis], p);
                    box[axis + 3] = Math.max(box[axis + 3], p);
                }
            }
            if (valid && mesh.drawState().vertexCount() > 0) bounds.put(entry.getKey(), box);
            if (valid
                    && entry.getKey() == ChunkSectionLayer.SOLID
                    && mesh.indexBuffer() == null
                    && ReviveRuntime.optimizationsEnabled()
                    && VeilVideoConfig.on("renderer.lod")) {
                if (VeilProgressiveMeshing.enabled()) {
                    if (VeilProgressiveMeshing.pairsEnabled()) continue;
                    progressive =
                            VeilProgressiveMeshing.submit(
                                    this,
                                    vertices,
                                    mesh.drawState().vertexCount(),
                                    extras.veil$lightOnlyUpdate());
                    continue;
                }
                var built =
                        VeilLodBuildCache.build(
                                vertices,
                                mesh.drawState().vertexCount(),
                                extras.veil$lightOnlyUpdate());
                if (built != null) {
                    lodBuckets = dev.veil.revive.core.DirectionalQuadBuckets.prepare(built);
                    lod = lodBuckets.mesh();
                }
            }
        }
        uploadBytes = producedBytes;
        originalQuads = extras.veil$takeOriginalQuads();
        if (originalQuads != null && !originalQuads.current(originalQuads.section())) {
            originalQuads.close();
            originalQuads = null;
        }
        VeilOriginalQuadCapture.published(originalQuads);
    }

    VeilOriginalQuadCapture.Snapshot originalAttributeSnapshot() {
        return hasOriginalAttributeSource() ? originalQuads : null;
    }

    boolean lightOnlyUpdate() {
        return lightOnlyUpdate;
    }

    boolean hasOriginalAttributeSource() {
        var originals = originalQuads;
        return !closed
                && originals != null
                && originals.modelsOnly()
                && originals.current(originals.section());
    }

    dev.veil.revive.core.terrain.PackedTerrainAttributeMap packedAttributeMap(
            ChunkSectionLayer layer) {
        if (closed) return null;
        var packed = packedAttributeMaps.get(layer);
        if (packed != null) return packed;
        var pair = pairedTerrain(layer);
        return pair == null ? null : pair.attributes();
    }

    static void requireAttributeProvenance() {
        if (!Boolean.getBoolean("veil.verifyAttributeProvenance")) return;
        if (ATTRIBUTE_CORNERS.sum() < 1024 || INDEXED_ATTRIBUTE_MAPS.sum() == 0)
            throw new IllegalStateException("Native attribute provenance not exercised");
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil attribute provenance: PASS (maps={} indexed_maps={} source_corners={})",
                ATTRIBUTE_MAPS.sum(),
                INDEXED_ATTRIBUTE_MAPS.sum(),
                ATTRIBUTE_CORNERS.sum());
    }

    public void accountUploads(SectionCompiler.Results results) {
        if (VeilCanonicalSparseUploads.enabled()) {
            for (var entry : results.renderedLayers.entrySet()) {
                var mesh = entry.getValue();
                if (entry.getKey() == ChunkSectionLayer.TRANSLUCENT
                        || !mesh.drawState().format().equals(DefaultVertexFormat.BLOCK)) continue;
                var data = VeilCanonicalData.capture(mesh.vertexBuffer());
                if (data != null) canonical.put(entry.getKey(), data);
            }
        }
        if (originalQuads != null
                && originalQuads.modelsOnly()
                && originalQuads.current(originalQuads.section())) {
            for (var entry : results.renderedLayers.entrySet()) {
                var mesh = entry.getValue();
                var map = VeilIndexedTerrain.attributeMap(mesh);
                boolean indexed = map != null;
                if (map == null
                        && mesh.indexBuffer() == null
                        && mesh.drawState().format().equals(DefaultVertexFormat.BLOCK)
                        && mesh.drawState().primitiveTopology()
                                == com.mojang.blaze3d.PrimitiveTopology.QUADS)
                    map =
                            dev.veil.revive.core.terrain.TerrainAttributeMap.identity(
                                    mesh.vertexBuffer(), mesh.drawState().vertexCount());
                if (map != null) {
                    attributeMaps.put(entry.getKey(), map);
                    if (Boolean.getBoolean("veil.verifyAttributeProvenance")) {
                        ATTRIBUTE_MAPS.increment();
                        ATTRIBUTE_CORNERS.add(map.sourceVertices());
                        if (indexed) INDEXED_ATTRIBUTE_MAPS.increment();
                    }
                }
            }
        }
        if (VeilRegularPackedTerrain.enabled()
                && VeilSectionChanges.notificationsSupported()
                && VeilShaderPackBridge.customTerrainShadersAllowed()) {
            for (var entry : results.renderedLayers.entrySet()) {
                if (entry.getKey() == ChunkSectionLayer.TRANSLUCENT) continue;
                boolean fluid = false;
                for (var range : materialRanges) if (range.layer() == entry.getKey()) fluid = true;
                var mesh = entry.getValue();
                if (fluid
                        || !mesh.drawState().format().equals(DefaultVertexFormat.BLOCK)
                        || mesh.drawState().primitiveTopology()
                                != com.mojang.blaze3d.PrimitiveTopology.QUADS
                        || mesh.drawState().vertexCount() == 0
                        || mesh.drawState().vertexCount() > 1_048_576) continue;
                var source = mesh.vertexBuffer().duplicate().order(ByteOrder.nativeOrder());
                if (VeilProgressiveMeshing.pairsEnabled() && mesh.indexBuffer() == null) {
                    var request =
                            VeilProgressiveMeshing.submit(
                                    this,
                                    source,
                                    mesh.drawState().vertexCount(),
                                    false,
                                    entry.getKey() == ChunkSectionLayer.SOLID
                                            && VeilVideoConfig.on("renderer.lod"),
                                    true);
                    if (request != null) {
                        if (progressiveLayers == null)
                            progressiveLayers = new EnumMap<>(ChunkSectionLayer.class);
                        progressiveLayers.put(entry.getKey(), request);
                        if (entry.getKey() == ChunkSectionLayer.SOLID) progressive = request;
                    }
                    continue;
                }
                var packed =
                        VeilRegularPackedTerrain.forceWide()
                                ? dev.veil.revive.core.terrain.RegularTerrainVertices.encodeWide(
                                        source, mesh.drawState().vertexCount())
                                : dev.veil.revive.core.terrain.RegularTerrainVertices.encode(
                                        source,
                                        mesh.drawState().vertexCount(),
                                        !"false"
                                                .equalsIgnoreCase(
                                                        System.getProperty(
                                                                "veil.regularPackedPrefer16")),
                                        !"false"
                                                .equalsIgnoreCase(
                                                        System.getProperty(
                                                                "veil.regularPackedWidePositions")));
                if (packed != null) {
                    VeilRegularPackedTerrain.verify(
                            mesh.vertexBuffer().duplicate().order(ByteOrder.nativeOrder()), packed);
                    regularPacked.put(entry.getKey(), packed);
                    var mapping = attributeMaps.get(entry.getKey());
                    if (mapping != null)
                        packedAttributeMaps.put(
                                entry.getKey(),
                                dev.veil.revive.core.terrain.PackedTerrainAttributeMap.create(
                                        mapping, source, packed));
                }
            }
        }
        long producedBytes = 0;
        for (var mesh : results.renderedLayers.values()) {
            producedBytes += mesh.vertexBuffer().remaining();
            if (mesh.indexBuffer() != null) producedBytes += mesh.indexBuffer().remaining();
        }
        uploadBytes = producedBytes;
        if (VeilVideoConfig.on("renderer.rebuildBudget"))
            VeilRebuildBudget.recordMeshBytes(producedBytes);
    }

    public float[] bounds(ChunkSectionLayer layer) {
        return bounds.get(layer);
    }

    dev.veil.revive.core.terrain.RegularTerrainVertices.Result regularPacked(
            ChunkSectionLayer layer) {
        return regularPacked.get(layer);
    }

    dev.veil.revive.core.terrain.TerrainAttributeMap attributeMap(ChunkSectionLayer layer) {
        return closed ? null : attributeMaps.get(layer);
    }

    public void close(SectionMesh owner) {
        closed = true;
        for (var data : canonical.values()) data.retire();
        canonical.clear();
        attributeMaps.clear();
        packedAttributeMaps.clear();
        if (originalQuads != null) {
            VeilOriginalAttributeWork.retired(originalQuads.section(), owner);
            originalQuads.close();
            originalQuads = null;
        }
        discardProgressive();
        progressiveOwner = null;
        if (progressiveLayers != null) VeilPairedTerrainArena.retire(owner);
        if (progressiveLayers != null) VeilParametricTerrainArena.retire(owner);
        if (!regularPacked.isEmpty()) VeilRegularPackedTerrain.retire(owner);
    }

    boolean closed() {
        return closed;
    }

    public boolean isClosed() {
        return closed;
    }

    public VeilCanonicalData canonicalData(ChunkSectionLayer layer) {
        return closed ? null : canonical.get(layer);
    }

    public dev.veil.revive.core.PlanarTerrainLod.Result lod() {
        if (progressive != null) {
            var result = progressiveLayout();
            return result == null ? null : result.mesh();
        }
        return lod;
    }

    public dev.veil.revive.core.DirectionalQuadBuckets.Layout lodBuckets() {
        if (progressive != null) return progressiveLayout();
        return lodBuckets;
    }

    public void attachProgressive(SectionRenderDispatcher.RenderSection section, SectionMesh mesh) {
        if ((progressive == null && progressiveLayers == null) || closed) return;
        progressiveOwner =
                new VeilProgressiveMeshing.Owner(section, mesh, section.getSectionNode());
        if (progressiveReady()) VeilProgressiveMeshing.ready(this);
    }

    VeilProgressiveMeshing.Owner progressiveOwner() {
        return progressiveOwner;
    }

    private dev.veil.revive.core.DirectionalQuadBuckets.Layout progressiveLayout() {
        if (!progressiveValid()) return null;
        var result = progressive.get();
        return result == null ? null : result.layout();
    }

    private boolean progressiveValid() {
        var owner = progressiveOwner;
        if (closed
                || (owner != null
                        && (owner.section().getSectionNode() != owner.node()
                                || owner.section().getSectionMesh() != owner.mesh()))) {
            discardProgressive();
            return false;
        }
        return true;
    }

    dev.veil.revive.core.terrain.PairedTerrainMesh.Result pairedTerrain(ChunkSectionLayer layer) {
        if (progressiveLayers == null || !progressiveValid()) return null;
        var request = progressiveLayers.get(layer);
        var result = request == null ? null : request.get();
        return result == null ? null : result.paired();
    }

    boolean progressiveReady() {
        if (!progressiveValid()) return false;
        if (progressive != null && progressive.get() != null) return true;
        if (progressiveLayers != null)
            for (var request : progressiveLayers.values()) if (request.get() != null) return true;
        return false;
    }

    dev.veil.revive.core.terrain.ParametricTerrainQuads.Result parametricTerrain(
            ChunkSectionLayer layer) {
        if (progressiveLayers == null || !progressiveValid()) return null;
        var request = progressiveLayers.get(layer);
        var result = request == null ? null : request.get();
        return result == null ? null : result.parametric();
    }

    boolean claimProgressiveNotification() {
        boolean changed = progressive != null && progressive.claimNotification();
        if (progressiveLayers != null)
            for (var request : progressiveLayers.values()) changed |= request.claimNotification();
        return changed;
    }

    void discardProgressive() {
        if (progressive != null) progressive.close();
        if (progressiveLayers != null)
            for (var request : progressiveLayers.values()) request.close();
    }

    public TextureAtlasSprite[] animatedSprites() {
        return animatedSprites;
    }

    public VeilMaterialRange[] materialRanges() {
        return materialRanges;
    }

    public VeilFluidGeometry[] fluidGeometry() {
        return fluidGeometry;
    }

    VeilRaySectionGeometry rayGeometry() {
        return rayGeometry;
    }

    public long uploadBytes() {
        return uploadBytes;
    }
}
