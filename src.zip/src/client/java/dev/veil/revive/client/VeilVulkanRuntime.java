package dev.veil.revive.client;

import com.mojang.blaze3d.vulkan.Destroyable;
import com.mojang.blaze3d.vulkan.VulkanDevice;
import com.mojang.blaze3d.vulkan.VulkanQueue;

import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;

import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDevice;

final class VeilVulkanRuntime extends MinecraftVulkanContext {
    private VeilVulkanRuntime(VulkanDevice device) {
        super(device);
    }

    public static VeilVulkanRuntime wrap(VulkanDevice device) {
        return new VeilVulkanRuntime(device);
    }

    public enum BackendState {
        PENDING,
        VULKAN,
        OTHER
    }

    public static VeilVulkanRuntime currentOrNull() {
        VulkanDevice device = currentDeviceOrNull();
        return device == null ? null : new VeilVulkanRuntime(device);
    }

    public static BackendState backendState() {
        return switch (backendKind()) {
            case PENDING -> BackendState.PENDING;
            case VULKAN -> BackendState.VULKAN;
            case OTHER -> BackendState.OTHER;
        };
    }

    public static boolean isCurrentBackend() {
        return backendState() == BackendState.VULKAN;
    }

    public static VeilVulkanRuntime requireCurrent() {
        return new VeilVulkanRuntime(requireDevice());
    }

    @Override
    public VulkanDevice device() {
        return super.device();
    }

    @Override
    public VkDevice vkDevice() {
        return super.vkDevice();
    }

    @Override
    public VulkanQueue graphicsQueue() {
        return super.graphicsQueue();
    }

    @Override
    public VulkanQueue computeQueue() {
        return super.computeQueue();
    }

    @Override
    public VulkanQueue transferQueue() {
        return super.transferQueue();
    }

    @Override
    public long vma() {
        return super.vma();
    }

    @Override
    public VkCommandBuffer commandBuffer() {
        return super.commandBuffer();
    }

    @Override
    public void deferDestroy(Destroyable destruction) {
        super.deferDestroy(destruction);
    }
}
