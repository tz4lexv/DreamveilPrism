package dev.veil.revive.client;

import dev.veil.revive.core.TerrainBridgeCounters;

import java.util.Locale;

public final class VeilBridgeStatus {
    private VeilBridgeStatus() {}

    public static String f3Line() {

        return "\u00A7c" + VeilRendererInfo.displayName() + "\u00A7r";
    }

    public static String plainStatusLine() {
        TerrainBridgeCounters.Snapshot counters = VeilTerrainDrawBridge.counters();
        String state = VeilDiagnostics.evidenceState();
        String terrain =
                !ReviveRuntime.config().staticDrawPacketCache()
                        ? "Cache OFF"
                        : (VeilTerrainDrawBridge.pathActive() ? "Cache ACTIVE" : "Cache ARMED");
        return String.format(
                Locale.ROOT,
                "%s | %s | %s %.0f%%",
                VeilRendererInfo.displayName(),
                state,
                terrain,
                counters.hitRate() * 100.0);
    }

    public static String detailLine() {
        TerrainBridgeCounters.Snapshot counters = VeilTerrainDrawBridge.counters();
        VeilMinecraftTerrainBridge.Snapshot far = VeilMinecraftTerrainBridge.latest();
        return String.format(
                Locale.ROOT,
                "Terrain cache %.0f%% (%d/%d) | visible=%d exact=%d sse=%d voxel=%d vasc=%d | GPU occlusion=backend-required",
                counters.hitRate() * 100.0,
                counters.cacheHits(),
                counters.cacheHits() + counters.cacheMisses(),
                far.visibleSections(),
                far.exactSections(),
                far.sseSections(),
                far.voxelSections(),
                far.vascSections());
    }
}
