package dev.veil.revive.client;

import net.minecraft.client.gui.components.debug.DebugScreenDisplayer;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.client.gui.components.debug.DebugScreenEntry;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;

public final class VeilDebugEntries {
    public static final Identifier VEIL_RENDERER =
            Identifier.fromNamespaceAndPath("veil", "veil_renderer");

    private static boolean registered;

    private VeilDebugEntries() {}

    public static void register() {
        if (registered) return;
        registered = true;

        DebugScreenEntries.register(
                VEIL_RENDERER,
                new DebugScreenEntry() {
                    @Override
                    public void display(
                            DebugScreenDisplayer displayer,
                            Level level,
                            LevelChunk clientChunk,
                            LevelChunk serverChunk) {
                        if (!ReviveRuntime.enabled()) return;

                        displayer.addLine(VeilRendererInfo.displayName() + " details");
                        displayer.addLine(
                                "Veil: " + ReviveRuntime.config().profile() + " | standalone");
                        for (String line : VeilDiagnostics.detailedLines()) displayer.addLine(line);
                    }

                    @Override
                    public boolean isAllowed(boolean reducedDebugInfo) {
                        return true;
                    }
                });
    }
}
