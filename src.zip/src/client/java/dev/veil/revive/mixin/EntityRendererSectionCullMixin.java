package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilEntityPipelineCounters;
import dev.veil.revive.client.VeilSectionVisibilityIndex;
import dev.veil.revive.client.VeilShaderPackBridge;
import dev.veil.revive.client.VeilVideoConfig;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererSectionCullMixin<
        T extends Entity, S extends EntityRenderState> {
    @WrapOperation(
            method = "shouldRender",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/renderer/culling/Frustum;isVisible(Lnet/minecraft/world/phys/AABB;)Z",
                            ordinal = 0))
    private boolean veil$sectionVisibilityBeforeFrustum(
            Frustum frustum, AABB bounds, Operation<Boolean> original, T entity) {
        if (!ReviveRuntime.optimizationsEnabled()
                || !VeilVideoConfig.on("renderer.entityCulling")
                || VeilShaderPackBridge.shaderPackActive()
                || VeilShaderPackBridge.renderingShadowPass()) {

            return original.call(frustum, bounds);
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.shouldEntityAppearGlowing(entity)
                || entity.shouldShowName()
                || entity.isOnFire()
                || entity.hasCustomName()
                || entity instanceof net.minecraft.world.entity.player.Player) {
            return original.call(frustum, bounds);
        }
        if (minecraft.player != null && entity.hasIndirectPassenger(minecraft.player)) {
            return original.call(frustum, bounds);
        }
        if (minecraft.level == null
                || bounds.maxY < minecraft.level.getMinY() + 0.5D
                || bounds.minY > minecraft.level.getMaxY() - 0.5D) {
            return original.call(frustum, bounds);
        }

        boolean visible = VeilSectionVisibilityIndex.isBoxVisible(bounds);
        if (!visible) {
            if (VeilDiagnostics.benchmarkActive())
                VeilEntityPipelineCounters.sectionVisibilityReject();
            return false;
        }
        return original.call(frustum, bounds)
                && !dev.veil.revive.client.VeilAsyncEntityOcclusion.isOccluded(entity, bounds);
    }
}
