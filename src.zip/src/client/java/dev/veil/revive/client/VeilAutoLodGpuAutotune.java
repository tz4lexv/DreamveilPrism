package dev.veil.revive.client;

import dev.veil.revive.core.AutoLodGpuPathPolicy;
import dev.veil.revive.core.WallClockCadence;

final class VeilAutoLodGpuAutotune {
    private static final long REPROBE_INTERVAL_NS = 4_000_000_000L;
    private static final double EMA_ALPHA = 0.25;

    private static Object topologyIdentity;
    private static boolean wasStaticProfitable;
    private static boolean active;
    private static boolean useCustomThisFrame;
    private static boolean measureHostThisFrame;
    private static boolean measureCustomThisFrame;
    private static AutoLodGpuPathPolicy.Choice preferred = AutoLodGpuPathPolicy.Choice.CUSTOM;

    private static long hostSeenSamples, customSeenSamples;
    private static double hostSeenTotalMs, customSeenTotalMs;
    private static long hostSamples, customSamples;
    private static double hostEmaMs, customEmaMs;
    private static final WallClockCadence REPROBE_CADENCE = new WallClockCadence();
    private static int reprobeStage;
    private static int discardFrames;

    private static long evaluations, hostFrames, customFrames;
    private static long initialHostProbeFrames, initialCustomProbeFrames;
    private static long periodicProbePairs, switchesToHost, switchesToCustom, contextResets;

    private VeilAutoLodGpuAutotune() {}

    static boolean timingNeededNextFrame() {
        return active
                && (hostSamples < AutoLodGpuPathPolicy.MIN_SAMPLES_PER_PATH
                        || customSamples < AutoLodGpuPathPolicy.MIN_SAMPLES_PER_PATH
                        || reprobeStage != 0
                        || REPROBE_CADENCE.ready(System.nanoTime()));
    }

    static void onGpuFrameStart() {
        measureHostThisFrame = false;
        measureCustomThisFrame = false;
    }

    static boolean beginStandaloneFrame(
            Object drawGroupsIdentity, boolean staticProfitable, boolean visibilityNeedsCustom) {
        consumeGpuResults();
        evaluations++;

        boolean contextChanged = topologyIdentity != drawGroupsIdentity;
        boolean becameProfitable = staticProfitable && !wasStaticProfitable;
        wasStaticProfitable = staticProfitable;
        if (contextChanged || becameProfitable) {
            topologyIdentity = drawGroupsIdentity;
            resetMeasurements(true);
            contextResets++;
        }

        if (visibilityNeedsCustom || !staticProfitable) {
            active = false;
            useCustomThisFrame = visibilityNeedsCustom;
            return useCustomThisFrame;
        }

        active = true;

        if (discardFrames > 0) {
            discardFrames--;
            syncSeenTotals();
            useCustomThisFrame = preferred == AutoLodGpuPathPolicy.Choice.CUSTOM;
            if (useCustomThisFrame) customFrames++;
            else hostFrames++;
            return useCustomThisFrame;
        }

        AutoLodGpuPathPolicy.Choice before = preferred;
        preferred =
                AutoLodGpuPathPolicy.choose(
                        preferred, hostSamples, hostEmaMs, customSamples, customEmaMs);
        if (preferred != before) {
            if (preferred == AutoLodGpuPathPolicy.Choice.HOST) switchesToHost++;
            else switchesToCustom++;
        }

        AutoLodGpuPathPolicy.Choice choice;
        boolean measure = false;
        if (hostSamples < AutoLodGpuPathPolicy.MIN_SAMPLES_PER_PATH) {
            choice = AutoLodGpuPathPolicy.Choice.HOST;
            measure = true;
            initialHostProbeFrames++;
        } else if (customSamples < AutoLodGpuPathPolicy.MIN_SAMPLES_PER_PATH) {
            choice = AutoLodGpuPathPolicy.Choice.CUSTOM;
            measure = true;
            initialCustomProbeFrames++;
        } else {
            if (reprobeStage == 0 && REPROBE_CADENCE.ready(System.nanoTime())) {
                reprobeStage = 1;
                periodicProbePairs++;
            }
            if (reprobeStage == 1) {
                choice = preferred;
                measure = true;
                reprobeStage = 2;
            } else if (reprobeStage == 2) {
                choice =
                        preferred == AutoLodGpuPathPolicy.Choice.CUSTOM
                                ? AutoLodGpuPathPolicy.Choice.HOST
                                : AutoLodGpuPathPolicy.Choice.CUSTOM;
                measure = true;
                reprobeStage = 0;
                REPROBE_CADENCE.scheduleFrom(System.nanoTime(), REPROBE_INTERVAL_NS);
            } else {
                choice = preferred;
            }
        }

        useCustomThisFrame = choice == AutoLodGpuPathPolicy.Choice.CUSTOM;
        if (useCustomThisFrame) {
            customFrames++;
            if (measure) measureCustomThisFrame = true;
        } else {
            hostFrames++;
            if (measure) measureHostThisFrame = true;
        }
        return useCustomThisFrame;
    }

    static boolean useCustomThisFrame() {
        return useCustomThisFrame;
    }

    static boolean measureHostThisFrame() {
        return active && measureHostThisFrame;
    }

    static boolean measureCustomThisFrame() {
        return active && measureCustomThisFrame;
    }

    private static void consumeGpuResults() {
        if (discardFrames > 0) {
            syncSeenTotals();
            return;
        }
        VeilGpuProfiler.PassTotals host =
                VeilGpuProfiler.totals(VeilGpuProfiler.Pass.AUTO_LOD_HOST_PROBE);
        if (host.samples() > hostSeenSamples) {
            long n = host.samples() - hostSeenSamples;
            double avg = (host.totalMs() - hostSeenTotalMs) / n;
            hostEmaMs = hostSamples == 0L ? avg : hostEmaMs * (1.0 - EMA_ALPHA) + avg * EMA_ALPHA;
            hostSamples += n;
            hostSeenSamples = host.samples();
            hostSeenTotalMs = host.totalMs();
        }
        VeilGpuProfiler.PassTotals custom =
                VeilGpuProfiler.totals(VeilGpuProfiler.Pass.AUTO_LOD_CUSTOM_PROBE);
        if (custom.samples() > customSeenSamples) {
            long n = custom.samples() - customSeenSamples;
            double avg = (custom.totalMs() - customSeenTotalMs) / n;
            customEmaMs =
                    customSamples == 0L ? avg : customEmaMs * (1.0 - EMA_ALPHA) + avg * EMA_ALPHA;
            customSamples += n;
            customSeenSamples = custom.samples();
            customSeenTotalMs = custom.totalMs();
        }
    }

    private static void syncSeenTotals() {
        VeilGpuProfiler.PassTotals host =
                VeilGpuProfiler.totals(VeilGpuProfiler.Pass.AUTO_LOD_HOST_PROBE);
        VeilGpuProfiler.PassTotals custom =
                VeilGpuProfiler.totals(VeilGpuProfiler.Pass.AUTO_LOD_CUSTOM_PROBE);
        hostSeenSamples = host.samples();
        hostSeenTotalMs = host.totalMs();
        customSeenSamples = custom.samples();
        customSeenTotalMs = custom.totalMs();
    }

    private static void resetMeasurements(boolean preferCustom) {
        syncSeenTotals();
        hostSamples = customSamples = 0L;
        hostEmaMs = customEmaMs = 0.0;
        preferred =
                preferCustom
                        ? AutoLodGpuPathPolicy.Choice.CUSTOM
                        : AutoLodGpuPathPolicy.Choice.HOST;
        REPROBE_CADENCE.scheduleFrom(System.nanoTime(), REPROBE_INTERVAL_NS);
        reprobeStage = 0;
        discardFrames = 6;
    }

    static void resetTelemetry() {
        evaluations = hostFrames = customFrames = 0L;
        initialHostProbeFrames = initialCustomProbeFrames = periodicProbePairs = 0L;
        switchesToHost = switchesToCustom = contextResets = 0L;
    }

    static void close() {
        active = false;
        useCustomThisFrame = false;
        measureHostThisFrame = false;
        measureCustomThisFrame = false;
        topologyIdentity = null;
        wasStaticProfitable = false;
        resetMeasurements(true);
    }

    static String telemetry() {
        consumeGpuResults();
        return "lod_gpu_autotune_active="
                + active
                + "\nlod_gpu_autotune_preferred="
                + preferred.name().toLowerCase(java.util.Locale.ROOT)
                + "\nlod_gpu_autotune_host_samples="
                + hostSamples
                + "\nlod_gpu_autotune_custom_samples="
                + customSamples
                + "\nlod_gpu_autotune_host_ema_ms="
                + String.format(java.util.Locale.ROOT, "%.4f", hostEmaMs)
                + "\nlod_gpu_autotune_custom_ema_ms="
                + String.format(java.util.Locale.ROOT, "%.4f", customEmaMs)
                + "\nlod_gpu_autotune_switch_margin_ms="
                + String.format(
                        java.util.Locale.ROOT, "%.4f", AutoLodGpuPathPolicy.SWITCH_MARGIN_MS)
                + "\nlod_gpu_autotune_evaluations_total="
                + evaluations
                + "\nlod_gpu_autotune_host_frames_total="
                + hostFrames
                + "\nlod_gpu_autotune_custom_frames_total="
                + customFrames
                + "\nlod_gpu_autotune_initial_host_probe_frames_total="
                + initialHostProbeFrames
                + "\nlod_gpu_autotune_initial_custom_probe_frames_total="
                + initialCustomProbeFrames
                + "\nlod_gpu_autotune_periodic_probe_pairs_total="
                + periodicProbePairs
                + "\nlod_gpu_autotune_switches_to_host_total="
                + switchesToHost
                + "\nlod_gpu_autotune_switches_to_custom_total="
                + switchesToCustom
                + "\nlod_gpu_autotune_context_resets_total="
                + contextResets
                + "\n";
    }
}
