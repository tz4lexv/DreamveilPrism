package dev.veil.revive.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public final class VeilClientCommands {
    private VeilClientCommands() {}

    public interface Feedback {
        void sendFeedback(Component message);

        void sendError(Component message);
    }

    public static <S> void register(
            com.mojang.brigadier.CommandDispatcher<S> dispatcher,
            java.util.function.Function<S, Feedback> feedback) {
        dispatcher.register(
                VeilClientCommands.<S>literal("veil")
                        .executes(ctx -> status(feedback.apply(ctx.getSource())))
                        .then(
                                VeilClientCommands.<S>literal("shaders")
                                        .executes(
                                                ctx -> {
                                                    feedback.apply(ctx.getSource())
                                                            .sendFeedback(
                                                                    Component.literal(
                                                                            VeilShaderService
                                                                                    .status()));
                                                    return 1;
                                                })
                                        .then(
                                                VeilClientCommands.<S>literal("reload")
                                                        .executes(
                                                                ctx -> {
                                                                    VeilShaderService
                                                                            .requestReload();
                                                                    feedback.apply(ctx.getSource())
                                                                            .sendFeedback(
                                                                                    Component
                                                                                            .literal(
                                                                                                    "Veil shader reload requested"));
                                                                    return 1;
                                                                }))
                                        .then(
                                                VeilClientCommands.<S>literal("off")
                                                        .executes(
                                                                ctx -> {
                                                                    VeilShaderService.select("");
                                                                    feedback.apply(ctx.getSource())
                                                                            .sendFeedback(
                                                                                    Component
                                                                                            .literal(
                                                                                                    "Veil shaders disabled"));
                                                                    return 1;
                                                                }))
                                        .then(
                                                VeilClientCommands.<S>literal("list")
                                                        .executes(
                                                                ctx ->
                                                                        shaderAction(
                                                                                feedback.apply(
                                                                                        ctx
                                                                                                .getSource()),
                                                                                () ->
                                                                                        String.join(
                                                                                                ", ",
                                                                                                VeilShaderService
                                                                                                        .availablePacks()))))
                                        .then(
                                                VeilClientCommands.<S>literal("load")
                                                        .then(
                                                                VeilClientCommands
                                                                        .<S, String>argument(
                                                                                "pack",
                                                                                com.mojang.brigadier
                                                                                        .arguments
                                                                                        .StringArgumentType
                                                                                        .string())
                                                                        .executes(
                                                                                ctx ->
                                                                                        shaderAction(
                                                                                                feedback
                                                                                                        .apply(
                                                                                                                ctx
                                                                                                                        .getSource()),
                                                                                                () -> {
                                                                                                    String
                                                                                                            pack =
                                                                                                                    com
                                                                                                                            .mojang
                                                                                                                            .brigadier
                                                                                                                            .arguments
                                                                                                                            .StringArgumentType
                                                                                                                            .getString(
                                                                                                                                    ctx,
                                                                                                                                    "pack");
                                                                                                    VeilShaderService
                                                                                                            .select(
                                                                                                                    pack);
                                                                                                    return "Veil shader pack requested: "
                                                                                                            + pack;
                                                                                                }))))
                                        .then(
                                                VeilClientCommands.<S>literal("settings")
                                                        .executes(
                                                                ctx ->
                                                                        shaderAction(
                                                                                feedback.apply(
                                                                                        ctx
                                                                                                .getSource()),
                                                                                VeilShaderService
                                                                                        ::settings)))
                                        .then(
                                                VeilClientCommands.<S>literal("profile")
                                                        .executes(
                                                                ctx ->
                                                                        shaderAction(
                                                                                feedback.apply(
                                                                                        ctx
                                                                                                .getSource()),
                                                                                VeilShaderService
                                                                                        ::performanceReport))
                                                        .then(
                                                                VeilClientCommands.<S>literal(
                                                                                "export")
                                                                        .executes(
                                                                                ctx ->
                                                                                        shaderAction(
                                                                                                feedback
                                                                                                        .apply(
                                                                                                                ctx
                                                                                                                        .getSource()),
                                                                                                VeilShaderService
                                                                                                        ::exportPerformanceReport)))
                                                        .then(
                                                                VeilClientCommands.<S>literal(
                                                                                "reset")
                                                                        .executes(
                                                                                ctx ->
                                                                                        shaderAction(
                                                                                                feedback
                                                                                                        .apply(
                                                                                                                ctx
                                                                                                                        .getSource()),
                                                                                                () -> {
                                                                                                    VeilShaderService
                                                                                                            .resetPerformanceSamples();
                                                                                                    return "Native shader samples reset";
                                                                                                })))
                                                        .then(
                                                                VeilClientCommands.<S>literal("on")
                                                                        .executes(
                                                                                ctx ->
                                                                                        shaderAction(
                                                                                                feedback
                                                                                                        .apply(
                                                                                                                ctx
                                                                                                                        .getSource()),
                                                                                                () -> {
                                                                                                    VeilShaderService
                                                                                                            .profiling(
                                                                                                                    true);
                                                                                                    return "Native shader GPU profiling enabled";
                                                                                                })))
                                                        .then(
                                                                VeilClientCommands.<S>literal("off")
                                                                        .executes(
                                                                                ctx ->
                                                                                        shaderAction(
                                                                                                feedback
                                                                                                        .apply(
                                                                                                                ctx
                                                                                                                        .getSource()),
                                                                                                () -> {
                                                                                                    VeilShaderService
                                                                                                            .profiling(
                                                                                                                    false);
                                                                                                    return "Native shader GPU profiling disabled";
                                                                                                }))))
                                        .then(
                                                VeilClientCommands.<S>literal("setting")
                                                        .then(
                                                                VeilClientCommands
                                                                        .<S, String>argument(
                                                                                "name",
                                                                                com.mojang.brigadier
                                                                                        .arguments
                                                                                        .StringArgumentType
                                                                                        .word())
                                                                        .then(
                                                                                VeilClientCommands
                                                                                        .<S, String>
                                                                                                argument(
                                                                                                        "value",
                                                                                                        com
                                                                                                                .mojang
                                                                                                                .brigadier
                                                                                                                .arguments
                                                                                                                .StringArgumentType
                                                                                                                .string())
                                                                                        .executes(
                                                                                                ctx ->
                                                                                                        shaderAction(
                                                                                                                feedback
                                                                                                                        .apply(
                                                                                                                                ctx
                                                                                                                                        .getSource()),
                                                                                                                () -> {
                                                                                                                    VeilShaderService
                                                                                                                            .setting(
                                                                                                                                    com
                                                                                                                                            .mojang
                                                                                                                                            .brigadier
                                                                                                                                            .arguments
                                                                                                                                            .StringArgumentType
                                                                                                                                            .getString(
                                                                                                                                                    ctx,
                                                                                                                                                    "name"),
                                                                                                                                    com
                                                                                                                                            .mojang
                                                                                                                                            .brigadier
                                                                                                                                            .arguments
                                                                                                                                            .StringArgumentType
                                                                                                                                            .getString(
                                                                                                                                                    ctx,
                                                                                                                                                    "value"));
                                                                                                                    return "Veil shader setting transaction requested";
                                                                                                                }))))))
                        .then(
                                VeilClientCommands.<S>literal("status")
                                        .executes(ctx -> status(feedback.apply(ctx.getSource()))))
                        .then(
                                VeilClientCommands.<S>literal("bypass")
                                        .executes(
                                                ctx -> {
                                                    VeilDiagnostics.toggleBypass(
                                                            Minecraft.getInstance());
                                                    return 1;
                                                }))
                        .then(
                                VeilClientCommands.<S>literal("benchmark")
                                        .executes(
                                                ctx -> {
                                                    VeilDiagnostics.startBenchmark(
                                                            Minecraft.getInstance());
                                                    return 1;
                                                })
                                        .then(
                                                VeilClientCommands.<S>literal("cancel")
                                                        .executes(
                                                                ctx -> {
                                                                    VeilDiagnostics.cancelBenchmark(
                                                                            Minecraft
                                                                                    .getInstance());
                                                                    return 1;
                                                                })))
                        .then(
                                VeilClientCommands.<S>literal("submissionbenchmark")
                                        .executes(
                                                ctx -> {
                                                    VeilSubmissionBenchmark.start(
                                                            Minecraft.getInstance());
                                                    return 1;
                                                })
                                        .then(
                                                VeilClientCommands.<S>literal("cancel")
                                                        .executes(
                                                                ctx -> {
                                                                    VeilSubmissionBenchmark.cancel(
                                                                            Minecraft
                                                                                    .getInstance());
                                                                    return 1;
                                                                })))
                        .then(
                                VeilClientCommands.<S>literal("details")
                                        .executes(
                                                ctx -> {
                                                    VeilDiagnostics.toggleDetailedOverlay(
                                                            Minecraft.getInstance());
                                                    return 1;
                                                }))
                        .then(
                                VeilClientCommands.<S>literal("visualcheck")
                                        .executes(
                                                ctx -> {
                                                    VeilDiagnostics.startVisualValidation(
                                                            Minecraft.getInstance());
                                                    return 1;
                                                }))
                        .then(
                                VeilClientCommands.<S>literal("reset")
                                        .executes(
                                                ctx -> {
                                                    VeilDiagnostics.resetEvidence(
                                                            Minecraft.getInstance());
                                                    return 1;
                                                })));
    }

    private static <S> com.mojang.brigadier.builder.LiteralArgumentBuilder<S> literal(String name) {
        return com.mojang.brigadier.builder.LiteralArgumentBuilder.literal(name);
    }

    private static <S, T> com.mojang.brigadier.builder.RequiredArgumentBuilder<S, T> argument(
            String name, com.mojang.brigadier.arguments.ArgumentType<T> type) {
        return com.mojang.brigadier.builder.RequiredArgumentBuilder.argument(name, type);
    }

    @FunctionalInterface
    private interface ShaderAction {
        String run() throws java.io.IOException;
    }

    private static int shaderAction(Feedback source, ShaderAction action) {
        try {
            source.sendFeedback(Component.literal(action.run()));
            return 1;
        } catch (java.io.IOException | IllegalArgumentException failure) {
            source.sendError(Component.literal(failure.getMessage()));
            return 0;
        }
    }

    private static int status(Feedback source) {
        source.sendFeedback(Component.literal(VeilBridgeStatus.plainStatusLine()));
        for (String line : VeilDiagnostics.detailedLines()) {
            source.sendFeedback(Component.literal(line));
        }
        return 1;
    }
}
