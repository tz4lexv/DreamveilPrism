package dev.veil.revive.client.terrain.capture;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;

import java.util.List;
import java.util.function.Function;

public class TerrainPlanSource {

    private final Function<Object, UniformOwner> owners;

    public interface UniformOwner {
        int index();

        SectionMesh mesh();

        ChunkSectionLayer layer();
    }

    public interface Origins {
        int count();

        int x(int index);

        int y(int index);

        int z(int index);
    }

    public final ChunkSectionLayer layer;
    public final GpuBuffer[] vertices;
    public final GpuBuffer[] indices;
    public final IndexType[] indexTypes;
    public final SectionMesh[] meshes;
    public final int[] indexCounts, firstIndices, baseVertices, sectionIndices;
    public final int[] originX, originY, originZ;

    public TerrainPlanSource(
            ChunkSectionLayer layer, int size, Function<Object, UniformOwner> owners) {
        this.owners = owners;
        this.layer = layer;
        vertices = new GpuBuffer[size];
        indices = new GpuBuffer[size];
        indexTypes = new IndexType[size];
        meshes = new SectionMesh[size];
        indexCounts = new int[size];
        firstIndices = new int[size];
        baseVertices = new int[size];
        sectionIndices = new int[size];
        originX = new int[size];
        originY = new int[size];
        originZ = new int[size];
    }

    public final void captureDraws(List<RenderPass.Draw<GpuBufferSlice[]>> source) {
        for (int i = 0; i < source.size(); i++) {
            var draw = source.get(i);
            UniformOwner uploader = owners.apply(draw.uniformUploaderConsumer());
            if (uploader == null) {
                throw new IllegalStateException("Unknown terrain uniform owner");
            }
            this.vertices[i] = draw.vertexBuffer();
            this.indices[i] = draw.indexBuffer();
            this.indexTypes[i] = draw.indexType();
            this.meshes[i] = uploader.mesh();
            this.indexCounts[i] = draw.indexCount();
            this.firstIndices[i] = draw.firstIndex();
            this.baseVertices[i] = draw.baseVertex();
            this.sectionIndices[i] = uploader.index();
        }
    }

    public final void captureOrigins(Origins frame) {
        for (int i = 0; i < sectionIndices.length; i++) {
            int index = sectionIndices[i];
            originX[i] = frame.x(index);
            originY[i] = frame.y(index);
            originZ[i] = frame.z(index);
        }
    }

    public final boolean matchesOrigins(Origins frame) {
        for (int i = 0; i < sectionIndices.length; i++) {
            int index = sectionIndices[i];
            if (index < 0
                    || index >= frame.count()
                    || originX[i] != frame.x(index)
                    || originY[i] != frame.y(index)
                    || originZ[i] != frame.z(index)) return false;
        }
        return true;
    }

    public final boolean matches(List<RenderPass.Draw<GpuBufferSlice[]>> source) {
        if (source.size() != vertices.length) return false;
        for (int i = 0; i < source.size(); i++) {
            var draw = source.get(i);
            UniformOwner uploader = owners.apply(draw.uniformUploaderConsumer());
            if (uploader == null
                    || uploader.layer() != layer
                    || vertices[i] != draw.vertexBuffer()
                    || indices[i] != draw.indexBuffer()
                    || indexTypes[i] != draw.indexType()
                    || meshes[i] != uploader.mesh()
                    || indexCounts[i] != draw.indexCount()
                    || firstIndices[i] != draw.firstIndex()
                    || baseVertices[i] != draw.baseVertex()
                    || sectionIndices[i] != uploader.index()) {
                return false;
            }
        }
        return true;
    }
}
