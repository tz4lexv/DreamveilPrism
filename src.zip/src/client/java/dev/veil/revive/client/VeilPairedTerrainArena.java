package dev.veil.revive.client;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.terrain.CapacityRetryBackoff;
import dev.veil.revive.core.terrain.PairedTerrainMesh;
import dev.veil.revive.core.terrain.RegularTerrainVertices;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

final class VeilPairedTerrainArena {
    private static final int LIMIT = 4 << 20;
    private static final boolean BACKOFF = Boolean.getBoolean("veil.pairedCapacityBackoff");
    private static final List<VeilManagedGpuArena<Entry>> VERTICES =
            new ArrayList<>(Arrays.asList(null, null, null));
    private static final List<VeilManagedGpuArena<Entry>> INDICES =
            new ArrayList<>(Arrays.asList(null, null));
    private static final IdentityHashMap<SectionMesh, EnumMap<ChunkSectionLayer, Entry>> OWNERS =
            new IdentityHashMap<>();
    private static final IdentityHashMap<GpuBuffer, Integer> FORMATS = new IdentityHashMap<>();
    private static final IdentityHashMap<SectionMesh, EnumMap<ChunkSectionLayer, Failure>>
            FAILURES = new IdentityHashMap<>();
    private static final ConcurrentLinkedQueue<SectionMesh> RETIRED = new ConcurrentLinkedQueue<>();
    private static final IdentityHashMap<
                    SectionRenderDispatcher.RenderSection, EnumMap<ChunkSectionLayer, Reservation>>
            REPLACEMENTS = new IdentityHashMap<>();
    private static final ArrayDeque<Reservation> EXPIRATIONS = new ArrayDeque<>();
    private static VeilPersistentStagingBuffer staging;
    private static ByteBuffer scratch;
    private static long revision, uploaded, submitted, gpuCommands;
    private static long vertexCapacityFailures, indexCapacityFailures, capacitySkips, expiredPairs;
    private static long nextExpiry;
    private static long reusedPairs, expiredReservations;
    private static long delaySkips, updateFrames;

    private static final class Entry {
        final int layout, indexSlot, indexCount;
        final SectionRenderDispatcher.RenderSection section;
        final long origin;
        long lastSeen;

        Entry(
                int layout,
                int indexSlot,
                int indexCount,
                long now,
                SectionRenderDispatcher.RenderSection section) {
            this.layout = layout;
            this.indexSlot = indexSlot;
            this.indexCount = indexCount;
            this.lastSeen = now;
            this.section = section;
            this.origin = section == null ? 0 : section.getRenderOrigin().asLong();
        }
    }

    private record Reservation(
            SectionRenderDispatcher.RenderSection section,
            ChunkSectionLayer layer,
            Entry entry,
            long expires) {}

    private record Failure(
            PairedTerrainMesh.Result data,
            long vertexRevision,
            long indexRevision,
            CapacityRetryBackoff retry,
            String reason) {}

    record Slice(
            GpuBuffer vertices,
            GpuBuffer indices,
            IndexType indexType,
            int baseVertex,
            int firstIndex,
            int indexCount) {}

    static boolean enabled() {
        return VeilProgressiveMeshing.pairsEnabled();
    }

    static void update(
            Map<ChunkSectionLayer, ? extends Map<?, List<RenderPass.Draw<GpuBufferSlice[]>>>>
                    groups) {
        drainRetired();
        VeilPairedTerrainGpuProbe.tick();
        if (!enabled()) return;
        updateFrames++;
        long now = System.nanoTime();
        expireReservations(now);
        int budget = LIMIT;
        boolean staged = false;
        for (var layer : groups.entrySet()) {
            if (layer.getKey() == ChunkSectionLayer.TRANSLUCENT) continue;
            for (var draws : layer.getValue().values())
                for (var draw : draws) {
                    if (!(draw.uniformUploaderConsumer()
                            instanceof VeilSectionUniformUploader uploader)) continue;
                    var owner = OWNERS.get(uploader.mesh());
                    if (owner != null && owner.containsKey(layer.getKey())) {
                        owner.get(layer.getKey()).lastSeen = now;
                        continue;
                    }
                    if (!(uploader.mesh() instanceof VeilMeshExtras extras)
                            || extras.veil$metadata() == null
                            || extras.veil$metadata().closed()) continue;
                    var data = extras.veil$metadata().pairedTerrain(layer.getKey());
                    if (data == null || data.byteSize() > budget) continue;
                    if (staging == null)
                        staging =
                                new VeilPersistentStagingBuffer(
                                        "Veil paired terrain uploads", LIMIT);
                    int slot = data.vertices().layout().ordinal(),
                            indexSlot = data.indexBytes() == 2 ? 0 : 1;
                    if (VERTICES.get(slot) == null)
                        VERTICES.set(
                                slot,
                                new VeilManagedGpuArena<>(
                                        "Veil paired vertices " + slot,
                                        GpuBuffer.USAGE_VERTEX,
                                        8 << 20,
                                        data.vertices().stride(),
                                        staging,
                                        2));
                    if (INDICES.get(indexSlot) == null)
                        INDICES.set(
                                indexSlot,
                                new VeilManagedGpuArena<>(
                                        "Veil paired indices " + indexSlot,
                                        GpuBuffer.USAGE_INDEX,
                                        4 << 20,
                                        data.indexBytes(),
                                        staging,
                                        2));
                    var vertexArena = VERTICES.get(slot);
                    var indexArena = INDICES.get(indexSlot);
                    var reservation = reservation(uploader.section(), layer.getKey());
                    var failures = FAILURES.get(uploader.mesh());
                    var failure = failures == null ? null : failures.get(layer.getKey());
                    if (reservation == null
                            && failure != null
                            && failure.data == data
                            && ((failure.vertexRevision == vertexArena.capacityRevision()
                                            && failure.indexRevision
                                                    == indexArena.capacityRevision())
                                    || BACKOFF && !failure.retry.ready(now))) {
                        capacitySkips++;
                        if (BACKOFF && !failure.retry.ready(now)) delaySkips++;
                        continue;
                    }
                    if (failures != null) failures.remove(layer.getKey());
                    budget -= data.byteSize();
                    var entry =
                            new Entry(slot, indexSlot, data.indexCount(), now, uploader.section());
                    if (reservation != null) {
                        var reserved = reservation.entry;
                        var va = VERTICES.get(reserved.layout).getAllocation(reserved);
                        var ia = INDICES.get(reserved.indexSlot).getAllocation(reserved);
                        boolean compatible =
                                reserved.layout == slot
                                        && reserved.indexSlot == indexSlot
                                        && reserved.origin == entry.origin
                                        && va != null
                                        && ia != null
                                        && va.size() >= data.vertices().vertices().length
                                        && ia.size() >= data.indices().length;
                        if (compatible) {
                            var first =
                                    vertexArena.tryRestageAllocation(
                                            reserved,
                                            data.vertices().vertices().length,
                                            () -> prepare(data.vertices().vertices()));
                            if (first == VeilManagedGpuArena.Admission.STAGING) continue;
                            var second =
                                    first == VeilManagedGpuArena.Admission.ADDED
                                            ? indexArena.tryRestageAllocation(
                                                    reserved,
                                                    data.indices().length,
                                                    () -> prepare(data.indices()))
                                            : VeilManagedGpuArena.Admission.CAPACITY;
                            if (second == VeilManagedGpuArena.Admission.ADDED) {
                                consumeReservation(reservation);
                                vertexArena.rekeyAllocation(reserved, entry);
                                indexArena.rekeyAllocation(reserved, entry);
                                if (owner == null) {
                                    owner = new EnumMap<>(ChunkSectionLayer.class);
                                    OWNERS.put(uploader.mesh(), owner);
                                }
                                owner.put(layer.getKey(), entry);
                                reusedPairs++;
                                uploaded++;
                                if (VeilPackedAttributeProbe.REQUESTED)
                                    VeilPackedAttributeProbe.record(
                                            data.attributes(), data.vertices(), true);
                                staged = true;
                                continue;
                            }
                        }
                        consumeReservation(reservation);
                        release(reserved);
                    }
                    var vertexAdmission =
                            vertexArena.tryAddAllocation(
                                    entry,
                                    ignored -> revision++,
                                    data.vertices().vertices().length,
                                    () -> prepare(data.vertices().vertices()));
                    if (vertexAdmission != VeilManagedGpuArena.Admission.ADDED) {
                        if (vertexAdmission == VeilManagedGpuArena.Admission.CAPACITY) {
                            vertexCapacityFailures++;
                            rememberFailure(
                                    uploader.mesh(),
                                    layer.getKey(),
                                    data,
                                    vertexArena,
                                    indexArena,
                                    "VERTEX_CAPACITY",
                                    failure,
                                    now);
                        }
                        continue;
                    }
                    boolean paired = false;
                    VeilManagedGpuArena.Admission indexAdmission;
                    try {
                        indexAdmission =
                                indexArena.tryAddAllocation(
                                        entry,
                                        ignored -> revision++,
                                        data.indices().length,
                                        () -> prepare(data.indices()));
                        paired = indexAdmission == VeilManagedGpuArena.Admission.ADDED;
                    } finally {
                        if (!paired) vertexArena.removeAllocation(entry);
                    }
                    if (!paired) {
                        if (indexAdmission == VeilManagedGpuArena.Admission.CAPACITY) {
                            indexCapacityFailures++;
                            rememberFailure(
                                    uploader.mesh(),
                                    layer.getKey(),
                                    data,
                                    vertexArena,
                                    indexArena,
                                    "INDEX_CAPACITY",
                                    failure,
                                    now);
                        }
                        continue;
                    }
                    if (owner == null) {
                        owner = new EnumMap<>(ChunkSectionLayer.class);
                        OWNERS.put(uploader.mesh(), owner);
                    }
                    owner.put(layer.getKey(), entry);
                    staged = true;
                    uploaded++;
                    if (VeilPackedAttributeProbe.REQUESTED)
                        VeilPackedAttributeProbe.record(data.attributes(), data.vertices(), true);
                }
        }
        if (staged)
            try (var uploader =
                    staging.startUploading(RenderSystem.getDevice().createCommandEncoder())) {
                for (var arena : VERTICES)
                    if (arena != null)
                        arena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
                for (var arena : INDICES)
                    if (arena != null)
                        arena.uploadStagedAllocations(RenderSystem.getDevice(), uploader);
            }
        expireUnsubmitted(now);
        for (var arena : VERTICES) if (arena != null) arena.maintain();
        for (var arena : INDICES) if (arena != null) arena.maintain();
        if (VeilPairedTerrainGpuProbe.enabled()) {
            for (var owner : OWNERS.entrySet()) {
                if (!(owner.getKey() instanceof VeilMeshExtras extras)) continue;
                for (var layer : owner.getValue().entrySet()) {
                    var data = extras.veil$metadata().pairedTerrain(layer.getKey());
                    if (data == null) continue;
                    var entry = layer.getValue();
                    var vertices = VERTICES.get(entry.layout);
                    var indices = INDICES.get(entry.indexSlot);
                    var va = vertices.getAllocation(entry);
                    var ia = indices.getAllocation(entry);
                    if (va == null || ia == null) continue;
                    VeilPairedTerrainGpuProbe.capture(
                            entry,
                            data,
                            vertices.getGpuBuffer(va),
                            va.offset(),
                            indices.getGpuBuffer(ia),
                            ia.offset());
                }
            }
        }
    }

    private static Reservation reservation(
            SectionRenderDispatcher.RenderSection section, ChunkSectionLayer layer) {
        var layers = REPLACEMENTS.get(section);
        return layers == null ? null : layers.get(layer);
    }

    private static void consumeReservation(Reservation reservation) {
        var layers = REPLACEMENTS.get(reservation.section);
        if (layers == null || layers.get(reservation.layer) != reservation) return;
        layers.remove(reservation.layer);
        if (layers.isEmpty()) REPLACEMENTS.remove(reservation.section);
    }

    private static void release(Entry entry) {
        VERTICES.get(entry.layout).removeAllocation(entry);
        INDICES.get(entry.indexSlot).removeAllocation(entry);
        revision++;
    }

    private static void expireReservations(long now) {
        for (int removed = 0;
                removed < 64 && !EXPIRATIONS.isEmpty() && EXPIRATIONS.peekFirst().expires <= now;
                removed++) {
            var reservation = EXPIRATIONS.removeFirst();
            if (reservation(reservation.section, reservation.layer) != reservation) continue;
            consumeReservation(reservation);
            release(reservation.entry);
            expiredReservations++;
        }
    }

    private static void expireUnsubmitted(long now) {
        if (now < nextExpiry) return;
        nextExpiry = now + 1_000_000_000L;
        var owners = OWNERS.entrySet().iterator();
        while (owners.hasNext()) {
            var owner = owners.next().getValue();
            var layers = owner.values().iterator();
            while (layers.hasNext()) {
                var entry = layers.next();
                if (now - entry.lastSeen < 2_000_000_000L) continue;
                VERTICES.get(entry.layout).removeAllocation(entry);
                INDICES.get(entry.indexSlot).removeAllocation(entry);
                layers.remove();
                expiredPairs++;
                revision++;
            }
            if (owner.isEmpty()) owners.remove();
        }
    }

    private static void rememberFailure(
            SectionMesh mesh,
            ChunkSectionLayer layer,
            PairedTerrainMesh.Result data,
            VeilManagedGpuArena<Entry> vertices,
            VeilManagedGpuArena<Entry> indices,
            String reason,
            Failure previous,
            long now) {
        FAILURES.computeIfAbsent(mesh, ignored -> new EnumMap<>(ChunkSectionLayer.class))
                .put(
                        layer,
                        new Failure(
                                data,
                                vertices.capacityRevision(),
                                indices.capacityRevision(),
                                CapacityRetryBackoff.failed(
                                        now,
                                        previous != null && previous.data == data
                                                ? previous.retry
                                                : null),
                                reason));
    }

    static String failureReason(SectionMesh mesh, ChunkSectionLayer layer) {
        var failures = FAILURES.get(mesh);
        var failure = failures == null ? null : failures.get(layer);
        return failure == null ? "NONE" : failure.reason;
    }

    private static ByteBuffer prepare(byte[] bytes) {
        if (scratch == null || scratch.capacity() < bytes.length) {
            if (scratch != null) MemoryUtil.memFree(scratch);
            scratch = MemoryUtil.memAlloc(Math.max(4096, bytes.length));
        }
        return scratch.clear().put(bytes).flip();
    }

    static Slice get(SectionMesh mesh, ChunkSectionLayer layer) {
        if (!enabled()
                || !(mesh instanceof VeilMeshExtras extras)
                || extras.veil$metadata() == null
                || extras.veil$metadata().closed()
                || extras.veil$metadata().pairedTerrain(layer) == null) return null;
        var owner = OWNERS.get(mesh);
        var entry = owner == null ? null : owner.get(layer);
        if (entry == null) return null;
        var vertices = VERTICES.get(entry.layout);
        var indices = INDICES.get(entry.indexSlot);
        var va = vertices.getAllocation(entry);
        var ia = indices.getAllocation(entry);
        if (va == null || ia == null) return null;
        var vb = vertices.getGpuBuffer(va);
        FORMATS.put(vb, entry.layout);
        int stride = RegularTerrainVertices.Layout.values()[entry.layout].stride();
        int indexBytes = entry.indexSlot == 0 ? 2 : 4;
        return new Slice(
                vb,
                indices.getGpuBuffer(ia),
                entry.indexSlot == 0 ? IndexType.SHORT : IndexType.INT,
                Math.toIntExact(va.offset() / stride),
                Math.toIntExact(ia.offset() / indexBytes),
                entry.indexCount);
    }

    static int formatSlot(GpuBuffer buffer) {
        return FORMATS.getOrDefault(buffer, -1);
    }

    static boolean verifyGpuPair(SectionMesh mesh, ChunkSectionLayer layer) {
        var owner = OWNERS.get(mesh);
        var entry = owner == null ? null : owner.get(layer);
        if (entry == null || !(mesh instanceof VeilMeshExtras extras)) return false;
        var data = extras.veil$metadata().pairedTerrain(layer);
        var vertices = VERTICES.get(entry.layout);
        var indices = INDICES.get(entry.indexSlot);
        var va = vertices.getAllocation(entry);
        var ia = indices.getAllocation(entry);
        if (data == null || va == null || ia == null) return false;
        return VeilPairedTerrainGpuProbe.verify(
                entry,
                data,
                vertices.getGpuBuffer(va),
                va.offset(),
                indices.getGpuBuffer(ia),
                ia.offset());
    }

    static long revision() {
        return revision;
    }

    static void recordSubmission() {
        submitted++;
    }

    static void recordGpuSubmission(GpuBuffer buffer, int count) {
        if (FORMATS.containsKey(buffer)) gpuCommands += count;
    }

    static void requireComplete() {
        requireActiveRoute();
        VeilPairedTerrainGpuProbe.requireComplete();
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil paired terrain: PASS (uploaded_pairs={} resolved_draws={} gpu_commands={})",
                uploaded,
                submitted,
                gpuCommands);
        logStatistics();
    }

    static void requireActiveRoute() {
        if (!enabled() || uploaded == 0 || submitted == 0 || gpuCommands == 0)
            throw new IllegalStateException("Paired terrain upload/draw route incomplete");
    }

    static void logStatistics() {
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil paired statistics: uploaded_pairs={} resolved_draws={} gpu_commands={}",
                uploaded,
                submitted,
                gpuCommands);
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil paired capacity: vertex_failures={} index_failures={} unchanged_skips={} expired_pairs={}",
                vertexCapacityFailures,
                indexCapacityFailures,
                capacitySkips,
                expiredPairs);
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil paired replacements: reused_pairs={} expired_reservations={}",
                reusedPairs,
                expiredReservations);
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil paired admission: backoff={} delay_skips={} update_frames={}",
                BACKOFF,
                delaySkips,
                updateFrames);
    }

    static void retire(SectionMesh mesh) {
        RETIRED.offer(mesh);
    }

    static boolean hasOwner(SectionMesh mesh) {
        return OWNERS.containsKey(mesh);
    }

    private static void drainRetired() {
        SectionMesh mesh;
        while ((mesh = RETIRED.poll()) != null) {
            FAILURES.remove(mesh);
            var owner = OWNERS.remove(mesh);
            if (owner == null) continue;
            for (var layer : owner.entrySet()) {
                var entry = layer.getValue();
                if (entry.section == null
                        || VERTICES.get(entry.layout).getAllocation(entry) == null
                        || INDICES.get(entry.indexSlot).getAllocation(entry) == null) {
                    release(entry);
                    continue;
                }
                var replacement =
                        new Reservation(
                                entry.section,
                                layer.getKey(),
                                entry,
                                System.nanoTime() + 1_000_000_000L);
                var layers =
                        REPLACEMENTS.computeIfAbsent(
                                entry.section, ignored -> new EnumMap<>(ChunkSectionLayer.class));
                var previous = layers.put(layer.getKey(), replacement);
                if (previous != null && previous.entry != entry) release(previous.entry);
                EXPIRATIONS.addLast(replacement);
            }
            revision++;
        }
    }

    static void close() {
        VeilPairedTerrainGpuProbe.close();
        for (int i = 0; i < VERTICES.size(); i++) {
            if (VERTICES.get(i) != null) VERTICES.get(i).close();
            VERTICES.set(i, null);
        }
        for (int i = 0; i < INDICES.size(); i++) {
            if (INDICES.get(i) != null) INDICES.get(i).close();
            INDICES.set(i, null);
        }
        OWNERS.clear();
        FAILURES.clear();
        nextExpiry = 0;
        FORMATS.clear();
        RETIRED.clear();
        REPLACEMENTS.clear();
        EXPIRATIONS.clear();
        if (staging != null) staging.close();
        staging = null;
        if (scratch != null) MemoryUtil.memFree(scratch);
        scratch = null;
        revision++;
    }
}
