package dev.veil.revive.client;

public interface VeilSpriteActivity {
    void veil$markActive();

    boolean veil$takeActive();
}
