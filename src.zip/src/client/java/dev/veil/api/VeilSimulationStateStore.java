package dev.veil.api;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Objects;
import java.util.Optional;

/**
 * Opt-in, bounded storage for small creator-defined CPU simulation snapshots. It does not copy GPU
 * resources or decide how a simulation evolves.
 */
public final class VeilSimulationStateStore {
    private static final int MAGIC = 0x56535331; // VSS1
    private static final int VERSION = 1;
    private static final int HEADER_BYTES = 4 + 4 + 4 + 32;
    public static final int DEFAULT_MAX_SNAPSHOT_BYTES = 16 * 1024 * 1024;

    private final Path root;
    private final int maxSnapshotBytes;

    public VeilSimulationStateStore(Path root) {
        this(root, DEFAULT_MAX_SNAPSHOT_BYTES);
    }

    public VeilSimulationStateStore(Path root, int maxSnapshotBytes) {
        this.root = Objects.requireNonNull(root, "root").toAbsolutePath().normalize();
        if (maxSnapshotBytes < 1 || maxSnapshotBytes > DEFAULT_MAX_SNAPSHOT_BYTES)
            throw new IllegalArgumentException("Invalid snapshot budget");
        this.maxSnapshotBytes = maxSnapshotBytes;
    }

    /** Maximum number of payload bytes per snapshot, excluding the store checksum header. */
    public int maxSnapshotBytes() {
        return maxSnapshotBytes;
    }

    public void save(String worldId, String packId, String stateId, byte[] snapshot)
            throws IOException {
        saveInternal(worldId, packId, stateId, snapshot, false);
    }

    /**
     * Fail closed if the filesystem does not support atomic replacement. This guarantees that a
     * multi-entry checkpoint never becomes only partially visible after a process interruption.
     */
    public void saveAtomic(String worldId, String packId, String stateId, byte[] snapshot)
            throws IOException {
        saveInternal(worldId, packId, stateId, snapshot, true);
    }

    private void saveInternal(
            String worldId, String packId, String stateId, byte[] snapshot, boolean requireAtomic)
            throws IOException {
        Objects.requireNonNull(snapshot, "snapshot");
        if (snapshot.length > maxSnapshotBytes)
            throw new IllegalArgumentException("Simulation snapshot exceeds configured budget");
        Path target = location(worldId, packId, stateId);
        Path directory = target.getParent();
        ensureDirectories(directory);
        byte[] checksum = sha256(snapshot);
        ByteBuffer header = ByteBuffer.allocate(HEADER_BYTES).order(ByteOrder.LITTLE_ENDIAN);
        header.putInt(MAGIC).putInt(VERSION).putInt(snapshot.length).put(checksum).flip();
        Path temporary = Files.createTempFile(directory, ".veil-state-", ".tmp");
        try {
            try (FileChannel channel =
                    FileChannel.open(
                            temporary,
                            StandardOpenOption.WRITE,
                            StandardOpenOption.TRUNCATE_EXISTING)) {
                while (header.hasRemaining()) channel.write(header);
                ByteBuffer contents = ByteBuffer.wrap(snapshot);
                while (contents.hasRemaining()) channel.write(contents);
                channel.force(true);
            }
            // Never follow a pre-existing symlink in place of an owned snapshot.
            if (Files.isSymbolicLink(target))
                throw new IOException("Snapshot path is a symbolic link");
            try {
                Files.move(
                        temporary,
                        target,
                        StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (java.nio.file.AtomicMoveNotSupportedException unsupported) {
                if (requireAtomic) throw unsupported;
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    public Optional<byte[]> load(String worldId, String packId, String stateId) throws IOException {
        Path source = location(worldId, packId, stateId);
        rejectSymlinkParents(source.getParent());
        if (Files.isSymbolicLink(source)) throw new IOException("Snapshot path is a symbolic link");
        if (!Files.exists(source, LinkOption.NOFOLLOW_LINKS)) return Optional.empty();
        if (!Files.isRegularFile(source, LinkOption.NOFOLLOW_LINKS)
                || Files.size(source) > (long) HEADER_BYTES + maxSnapshotBytes)
            throw new IOException("Invalid or oversized simulation snapshot");
        try (FileChannel channel = FileChannel.open(source, StandardOpenOption.READ)) {
            ByteBuffer header = ByteBuffer.allocate(HEADER_BYTES).order(ByteOrder.LITTLE_ENDIAN);
            readExactly(channel, header);
            header.flip();
            if (header.getInt() != MAGIC || header.getInt() != VERSION)
                throw new IOException("Unsupported simulation snapshot format");
            int size = header.getInt();
            if (size < 0 || size > maxSnapshotBytes || channel.size() != (long) HEADER_BYTES + size)
                throw new IOException("Invalid simulation snapshot length");
            byte[] checksum = new byte[32];
            header.get(checksum);
            ByteBuffer body = ByteBuffer.allocate(size);
            readExactly(channel, body);
            byte[] result = body.array();
            if (!MessageDigest.isEqual(checksum, sha256(result)))
                throw new IOException("Simulation snapshot checksum mismatch");
            return Optional.of(result);
        }
    }

    /** Deletes an owned snapshot without exposing the hashed disk layout to integrations. */
    public boolean delete(String worldId, String packId, String stateId) throws IOException {
        Path target = location(worldId, packId, stateId);
        rejectSymlinkParents(target.getParent());
        if (Files.isSymbolicLink(target)) throw new IOException("Snapshot path is a symbolic link");
        return Files.deleteIfExists(target);
    }

    private Path location(String worldId, String packId, String stateId) {
        return root.resolve(key(worldId)).resolve(key(packId)).resolve(key(stateId) + ".vss");
    }

    private void ensureDirectories(Path directory) throws IOException {
        rejectSymlinkParents(root);
        Files.createDirectories(root);
        if (Files.isSymbolicLink(root)) throw new IOException("State root is a symbolic link");
        Path worldDirectory = directory.getParent();
        if (Files.isSymbolicLink(worldDirectory))
            throw new IOException("World state directory is a symbolic link");
        Files.createDirectories(worldDirectory);
        if (Files.isSymbolicLink(worldDirectory))
            throw new IOException("World state directory is a symbolic link");
        if (Files.isSymbolicLink(directory))
            throw new IOException("Pack state directory is a symbolic link");
        Files.createDirectories(directory);
        if (Files.isSymbolicLink(directory))
            throw new IOException("Pack state directory is a symbolic link");
    }

    private static void rejectSymlinkParents(Path path) throws IOException {
        for (Path current = path; current != null; current = current.getParent()) {
            if (Files.isSymbolicLink(current))
                throw new IOException("Simulation state path contains a symbolic link");
        }
    }

    private static String key(String raw) {
        Objects.requireNonNull(raw, "state key");
        if (raw.isBlank() || raw.length() > 512)
            throw new IllegalArgumentException("Invalid simulation state key");
        return HexFormat.of()
                .formatHex(sha256(raw.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    }

    private static byte[] sha256(byte[] bytes) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(bytes);
        } catch (NoSuchAlgorithmException impossible) {
            throw new AssertionError(impossible);
        }
    }

    private static void readExactly(FileChannel channel, ByteBuffer target) throws IOException {
        while (target.hasRemaining()) {
            if (channel.read(target) < 0) throw new IOException("Truncated simulation snapshot");
        }
    }
}
