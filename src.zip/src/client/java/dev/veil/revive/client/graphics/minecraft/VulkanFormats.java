package dev.veil.revive.client.graphics.minecraft;

import static org.lwjgl.vulkan.VK10.*;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.vulkan.VulkanConst;

import dev.veil.api.VeilFormat;

public final class VulkanFormats {
    private VulkanFormats() {}

    public static int vk(VeilFormat format) {
        return switch (format) {
            case RGBA8_SRGB -> VK_FORMAT_R8G8B8A8_SRGB;
            case D16_UNORM -> VK_FORMAT_D16_UNORM;
            case D32_FLOAT -> VK_FORMAT_D32_SFLOAT;
            case D24_UNORM_S8_UINT -> VK_FORMAT_D24_UNORM_S8_UINT;
            case D32_FLOAT_S8_UINT -> VK_FORMAT_D32_SFLOAT_S8_UINT;
            case S8_UINT -> VK_FORMAT_S8_UINT;
            default -> VulkanConst.toVk(minecraft(format));
        };
    }

    public static GpuFormat minecraft(VeilFormat format) {
        if (format == VeilFormat.RGBA8_SRGB) {
            throw new IllegalArgumentException(format + " requires a Veil-native image");
        }
        return GpuFormat.valueOf(format.name());
    }

    public static VeilFormat veil(GpuFormat format) {
        return VeilFormat.valueOf(format.name());
    }
}
