package dev.veil.revive.client;

import net.minecraft.core.Direction;

import java.util.Set;

public final class VeilModelCuboid {
    public static final int NUM_CUBE_VERTICES = 8;
    public static final int NUM_CUBE_FACES = 6;
    public static final int NUM_FACE_VERTICES = 4;

    public static final int VERTEX_X0_Y0_Z0 = 0,
            VERTEX_X1_Y0_Z0 = 1,
            VERTEX_X1_Y1_Z0 = 2,
            VERTEX_X0_Y1_Z0 = 3,
            VERTEX_X0_Y0_Z1 = 4,
            VERTEX_X1_Y0_Z1 = 5,
            VERTEX_X1_Y1_Z1 = 6,
            VERTEX_X0_Y1_Z1 = 7;
    public static final int FACE_NEG_Y = 0,
            FACE_POS_Y = 1,
            FACE_NEG_X = 2,
            FACE_NEG_Z = 3,
            FACE_POS_X = 4,
            FACE_POS_Z = 5;

    public final float originX;
    public final float originY;
    public final float originZ;
    public final float sizeX;
    public final float sizeY;
    public final float sizeZ;

    private final int cullMask;
    private final int visibleFaceCount;
    private final byte[] positions = new byte[NUM_CUBE_FACES * NUM_FACE_VERTICES];
    private final float[] texU = new float[NUM_CUBE_FACES * NUM_FACE_VERTICES];
    private final float[] texV = new float[NUM_CUBE_FACES * NUM_FACE_VERTICES];
    private final Direction[] normals = new Direction[NUM_CUBE_FACES];

    public VeilModelCuboid(
            int u,
            int v,
            float x1,
            float y1,
            float z1,
            float sizeX,
            float sizeY,
            float sizeZ,
            float extraX,
            float extraY,
            float extraZ,
            boolean mirror,
            float textureWidth,
            float textureHeight,
            Set<Direction> renderDirections) {
        float x2 = x1 + sizeX;
        float y2 = y1 + sizeY;
        float z2 = z1 + sizeZ;

        x1 -= extraX;
        y1 -= extraY;
        z1 -= extraZ;
        x2 += extraX;
        y2 += extraY;
        z2 += extraZ;

        if (mirror) {
            float swap = x2;
            x2 = x1;
            x1 = swap;
        }

        x1 *= 1.0F / 16.0F;
        y1 *= 1.0F / 16.0F;
        z1 *= 1.0F / 16.0F;
        x2 *= 1.0F / 16.0F;
        y2 *= 1.0F / 16.0F;
        z2 *= 1.0F / 16.0F;

        this.originX = x1;
        this.originY = y1;
        this.originZ = z1;
        this.sizeX = x2 - x1;
        this.sizeY = y2 - y1;
        this.sizeZ = z2 - z1;

        float scaleU = 1.0F / textureWidth;
        float scaleV = 1.0F / textureHeight;

        float u0 = scaleU * u;
        float u1 = scaleU * (u + sizeZ);
        float u2 = scaleU * (u + sizeZ + sizeX);
        float u3 = scaleU * (u + sizeZ + sizeX + sizeX);
        float u4 = scaleU * (u + sizeZ + sizeX + sizeZ);
        float u5 = scaleU * (u + sizeZ + sizeX + sizeZ + sizeX);

        float v0 = scaleV * v;
        float v1 = scaleV * (v + sizeZ);
        float v2 = scaleV * (v + sizeZ + sizeY);

        this.cullMask = createCullMask(renderDirections);
        this.visibleFaceCount = Integer.bitCount(this.cullMask);

        this.normals[FACE_NEG_Y] = Direction.DOWN;
        this.normals[FACE_POS_Y] = Direction.UP;
        this.normals[FACE_NEG_X] = Direction.EAST;
        this.normals[FACE_NEG_Z] = Direction.NORTH;
        this.normals[FACE_POS_X] = Direction.WEST;
        this.normals[FACE_POS_Z] = Direction.SOUTH;

        writeVertexList(
                FACE_NEG_Y, VERTEX_X1_Y0_Z1, VERTEX_X0_Y0_Z1, VERTEX_X0_Y0_Z0, VERTEX_X1_Y0_Z0);
        writeTexCoords(FACE_NEG_Y, u1, v0, u2, v1);

        writeVertexList(
                FACE_POS_Y, VERTEX_X1_Y1_Z0, VERTEX_X0_Y1_Z0, VERTEX_X0_Y1_Z1, VERTEX_X1_Y1_Z1);
        writeTexCoords(FACE_POS_Y, u2, v1, u3, v0);

        writeVertexList(
                FACE_NEG_Z, VERTEX_X1_Y0_Z0, VERTEX_X0_Y0_Z0, VERTEX_X0_Y1_Z0, VERTEX_X1_Y1_Z0);
        writeTexCoords(FACE_NEG_Z, u1, v1, u2, v2);

        writeVertexList(
                FACE_POS_Z, VERTEX_X0_Y0_Z1, VERTEX_X1_Y0_Z1, VERTEX_X1_Y1_Z1, VERTEX_X0_Y1_Z1);
        writeTexCoords(FACE_POS_Z, u4, v1, u5, v2);

        writeVertexList(
                FACE_NEG_X, VERTEX_X1_Y0_Z1, VERTEX_X1_Y0_Z0, VERTEX_X1_Y1_Z0, VERTEX_X1_Y1_Z1);
        writeTexCoords(FACE_NEG_X, u2, v1, u4, v2);

        writeVertexList(
                FACE_POS_X, VERTEX_X0_Y0_Z0, VERTEX_X0_Y0_Z1, VERTEX_X0_Y1_Z1, VERTEX_X0_Y1_Z0);
        writeTexCoords(FACE_POS_X, u0, v1, u1, v2);

        if (mirror) {
            reverseVertices();
            this.normals[FACE_POS_X] = Direction.EAST;
            this.normals[FACE_NEG_X] = Direction.WEST;
        }
    }

    public boolean shouldDrawFace(int faceIndex) {
        return (this.cullMask & (1 << faceIndex)) != 0;
    }

    public int visibleFaceCount() {
        return this.visibleFaceCount;
    }

    public int positionIndex(int elementIndex) {
        return this.positions[elementIndex] & 0xFF;
    }

    public float texU(int elementIndex) {
        return this.texU[elementIndex];
    }

    public float texV(int elementIndex) {
        return this.texV[elementIndex];
    }

    public Direction normal(int faceIndex) {
        return this.normals[faceIndex];
    }

    private static int createCullMask(Set<Direction> directions) {
        int mask = 0;
        for (Direction direction : directions) {
            mask |= 1 << getFaceIndex(direction);
        }
        return mask;
    }

    private void reverseVertices() {
        for (int face = 0; face < NUM_CUBE_FACES; face++) {
            int base = face * NUM_FACE_VERTICES;
            swap(this.positions, base, base + 3);
            swap(this.positions, base + 1, base + 2);
            swap(this.texU, base, base + 3);
            swap(this.texU, base + 1, base + 2);
            swap(this.texV, base, base + 3);
            swap(this.texV, base + 1, base + 2);
        }
    }

    private void writeVertexList(int face, int i0, int i1, int i2, int i3) {
        int base = face * NUM_FACE_VERTICES;
        this.positions[base] = (byte) i0;
        this.positions[base + 1] = (byte) i1;
        this.positions[base + 2] = (byte) i2;
        this.positions[base + 3] = (byte) i3;
    }

    private void writeTexCoords(int face, float u1, float v1, float u2, float v2) {
        int base = face * NUM_FACE_VERTICES;
        this.texU[base] = u2;
        this.texV[base] = v1;
        this.texU[base + 1] = u1;
        this.texV[base + 1] = v1;
        this.texU[base + 2] = u1;
        this.texV[base + 2] = v2;
        this.texU[base + 3] = u2;
        this.texV[base + 3] = v2;
    }

    private static int getFaceIndex(Direction direction) {
        return switch (direction) {
            case DOWN -> FACE_NEG_Y;
            case UP -> FACE_POS_Y;
            case NORTH -> FACE_NEG_Z;
            case SOUTH -> FACE_POS_Z;
            case WEST -> FACE_POS_X;
            case EAST -> FACE_NEG_X;
        };
    }

    private static void swap(byte[] values, int a, int b) {
        byte value = values[a];
        values[a] = values[b];
        values[b] = value;
    }

    private static void swap(float[] values, int a, int b) {
        float value = values[a];
        values[a] = values[b];
        values[b] = value;
    }
}
