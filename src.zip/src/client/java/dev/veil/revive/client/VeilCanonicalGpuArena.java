package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.UberGpuBuffer;

import dev.veil.revive.core.terrain.AttributeUploadPlan;

public interface VeilCanonicalGpuArena {
    enum Admission {
        ADDED,
        STAGING,
        UNSUPPORTED
    }

    Admission veil$stageCanonical(
            Object source,
            Object target,
            UberGpuBuffer.UploadCallback<Object> callback,
            AttributeUploadPlan plan,
            VeilCanonicalData data);
}
