package dev.veil.revive.client;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public final class VeilTransparencyState {
    private static final VeilTransparencyOrder CLOSED = new VeilTransparencyOrder(new int[0]);
    private final AtomicReference<VeilTransparencyOrder> order = new AtomicReference<>();
    private final AtomicInteger pending = new AtomicInteger();

    public VeilTransparencyOrder idleOrder() {
        return pending.get() == 0 ? get() : null;
    }

    public Task task() {
        pending.incrementAndGet();
        return new Task();
    }

    public final class Task {
        private final AtomicInteger phase = new AtomicInteger();

        public void start() {
            phase.compareAndSet(0, 1);
        }

        public void cancel() {
            if (phase.compareAndSet(0, 2)) pending.decrementAndGet();
        }

        public void finish() {
            if (phase.getAndSet(2) != 2) pending.decrementAndGet();
        }
    }

    public VeilTransparencyOrder get() {
        VeilTransparencyOrder current = order.get();
        return current == CLOSED ? null : current;
    }

    public void set(VeilTransparencyOrder value) {
        VeilTransparencyOrder previous;
        do {
            previous = order.get();
            if (previous == CLOSED) return;
        } while (!order.compareAndSet(previous, value));
    }

    public void close() {
        order.set(CLOSED);
    }
}
