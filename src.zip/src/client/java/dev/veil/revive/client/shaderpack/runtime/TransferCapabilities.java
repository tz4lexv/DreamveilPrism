package dev.veil.revive.client.shaderpack.runtime;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.api.VeilTransfer;
import dev.veil.revive.client.VeilShaderPack;
import dev.veil.revive.client.graphics.minecraft.VulkanFormats;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkFormatProperties;
import org.lwjgl.vulkan.VkPhysicalDevice;

public final class TransferCapabilities {
    private TransferCapabilities() {}

    public static void validate(VkPhysicalDevice physical, VeilShaderPack pack) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var properties = VkFormatProperties.calloc(stack);
            for (var pass : pack.passes()) {
                for (var operation : pass.transfers()) {
                    switch (operation.kind()) {
                        case IMAGE_RESOLVE ->
                                require(
                                        physical,
                                        pack,
                                        operation.destination(),
                                        VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT,
                                        properties);
                        case IMAGE_BLIT_NEAREST, IMAGE_BLIT_LINEAR -> {
                            require(
                                    physical,
                                    pack,
                                    operation.source(),
                                    VK_FORMAT_FEATURE_BLIT_SRC_BIT
                                            | (operation.kind()
                                                            == VeilTransfer.Kind.IMAGE_BLIT_LINEAR
                                                    ? VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT
                                                    : 0),
                                    properties);
                            require(
                                    physical,
                                    pack,
                                    operation.destination(),
                                    VK_FORMAT_FEATURE_BLIT_DST_BIT,
                                    properties);
                        }
                        default -> {}
                    }
                }
            }
        }
    }

    private static void require(
            VkPhysicalDevice physical,
            VeilShaderPack pack,
            String resource,
            int required,
            VkFormatProperties properties) {
        var format = pack.resources().get(resource).format();
        vkGetPhysicalDeviceFormatProperties(physical, VulkanFormats.vk(format), properties);
        if ((properties.optimalTilingFeatures() & required) != required) {
            throw new IllegalArgumentException(
                    "Image transfer "
                            + resource
                            + ": format "
                            + format
                            + " lacks required Vulkan format features 0x"
                            + Integer.toHexString(required));
        }
    }
}
