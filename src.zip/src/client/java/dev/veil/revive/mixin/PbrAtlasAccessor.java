package dev.veil.revive.mixin;

import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.Identifier;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;

@Mixin(TextureAtlas.class)
public interface PbrAtlasAccessor {
    @Accessor("texturesByName")
    Map<Identifier, TextureAtlasSprite> veil$pbrSprites();
}
