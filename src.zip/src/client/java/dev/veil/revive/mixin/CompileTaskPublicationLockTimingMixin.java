package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import dev.veil.revive.client.VeilPublicationLockTimingAccess;

import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.concurrent.locks.ReentrantLock;

@Mixin(
        targets =
                "net.minecraft.client.renderer.chunk.SectionRenderDispatcher$RenderSection$CompileTask")
public abstract class CompileTaskPublicationLockTimingMixin {
    @Shadow @Final private SectionRenderDispatcher.RenderSection this$1;

    @WrapOperation(
            method = "doTask",
            at =
                    @At(
                            value = "INVOKE",
                            target = "Ljava/util/concurrent/locks/ReentrantLock;lock()V"),
            require = 2)
    private void veil$acquire(ReentrantLock lock, Operation<Void> original) {
        var timing = ((VeilPublicationLockTimingAccess) this$1).veil$publicationLockTiming();
        timing.beforeLock();
        original.call(lock);
        timing.afterLock();
    }

    @WrapOperation(
            method = "doTask",
            at =
                    @At(
                            value = "INVOKE",
                            target = "Ljava/util/concurrent/locks/ReentrantLock;unlock()V"),
            require = 4)
    private void veil$release(ReentrantLock lock, Operation<Void> original) {
        var timing = ((VeilPublicationLockTimingAccess) this$1).veil$publicationLockTiming();
        timing.beforeUnlock();
        original.call(lock);
        timing.afterUnlock();
    }
}
