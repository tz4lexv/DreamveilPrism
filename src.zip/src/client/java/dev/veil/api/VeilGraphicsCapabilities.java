package dev.veil.api;

import dev.veil.api.graphics.GraphicsCapabilitySource;
import dev.veil.api.graphics.RasterFeature;

import java.util.ServiceLoader;
import java.util.Set;

public final class VeilGraphicsCapabilities {
    private VeilGraphicsCapabilities() {}

    private static final class Source {
        static final GraphicsCapabilitySource VALUE = load();

        private static GraphicsCapabilitySource load() {
            var sources =
                    ServiceLoader.load(
                                    GraphicsCapabilitySource.class,
                                    VeilGraphicsCapabilities.class.getClassLoader())
                            .iterator();
            if (!sources.hasNext())
                throw new IllegalStateException("Missing Veil graphics capability provider");
            var source = sources.next();
            if (sources.hasNext())
                throw new IllegalStateException("Multiple Veil graphics capability providers");
            return source;
        }
    }

    public static boolean portableRayTracing() {
        return true;
    }

    public static boolean accelerationStructures() {
        return Source.VALUE.accelerationStructures();
    }

    public static boolean rayQuery() {
        return Source.VALUE.rayQuery();
    }

    public static boolean rayPipeline() {
        return Source.VALUE.rayPipeline();
    }

    public static boolean dynamicInstances() {
        return true;
    }

    public static boolean hierarchicalDynamicGeometry() {
        return true;
    }

    public static int maximumDynamicGeometryPrimitives() {
        return 2048;
    }

    public static boolean creatorTriangleMeshes() {
        return true;
    }

    public static int maximumCreatorMeshVertices() {
        return 65_536;
    }

    public static int maximumCreatorMeshTriangles() {
        return 16_384;
    }

    public static boolean creatorLights() {
        return true;
    }

    public static boolean budgetedShadowLights() {
        return true;
    }

    public static int maximumSelectedShadowLights() {
        return 16;
    }

    public static boolean pbrMaterials() {
        return true;
    }

    public static boolean labPbrAtlases() {
        return true;
    }

    public static boolean shaderInt64() {
        return Source.VALUE.shaderInt64();
    }

    public static boolean shaderBufferInt64Atomics() {
        return Source.VALUE.shaderBufferInt64Atomics();
    }

    public static boolean shaderSharedInt64Atomics() {
        return Source.VALUE.shaderSharedInt64Atomics();
    }

    public static Set<String> enabledDeviceFeatures() {
        return Set.copyOf(Source.VALUE.enabledDeviceFeatures());
    }

    public static boolean weatherReplacement() {
        return true;
    }

    public static boolean lavaReplacement() {
        return true;
    }

    public static boolean temporalHistory() {
        return true;
    }

    public static Set<String> hostResources() {
        return Set.copyOf(Source.VALUE.hostResources());
    }

    public static Set<RasterFeature> rasterFeatures() {
        return Set.copyOf(Source.VALUE.rasterFeatures());
    }
}
