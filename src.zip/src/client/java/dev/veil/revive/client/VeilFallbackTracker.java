package dev.veil.revive.client;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.atomic.LongAdder;

public final class VeilFallbackTracker {
    public enum Reason {
        BYPASSED,
        TERRAIN_NO_DISPATCHER,
        TERRAIN_BRIDGE_EXCEPTION,
        VASC_DIRTY,
        VASC_TRANSLUCENT
    }

    private static final EnumMap<Reason, LongAdder> COUNTS = new EnumMap<>(Reason.class);

    static {
        for (Reason reason : Reason.values()) COUNTS.put(reason, new LongAdder());
    }

    private VeilFallbackTracker() {}

    public static void record(Reason reason) {
        COUNTS.get(reason).increment();
    }

    public static void add(Reason reason, long count) {
        if (count > 0) COUNTS.get(reason).add(count);
    }

    public static long count(Reason reason) {
        return COUNTS.get(reason).sum();
    }

    public static Snapshot snapshot() {
        EnumMap<Reason, Long> copy = new EnumMap<>(Reason.class);
        long total = 0L;
        for (Map.Entry<Reason, LongAdder> entry : COUNTS.entrySet()) {
            long value = entry.getValue().sum();
            copy.put(entry.getKey(), value);
            total += value;
        }
        return new Snapshot(Map.copyOf(copy), total);
    }

    public static void reset() {
        for (LongAdder adder : COUNTS.values()) adder.reset();
    }

    public record Snapshot(Map<Reason, Long> counts, long total) {
        public long count(Reason reason) {
            return counts.getOrDefault(reason, 0L);
        }

        public Snapshot minus(Snapshot before) {
            EnumMap<Reason, Long> delta = new EnumMap<>(Reason.class);
            long sum = 0L;
            for (Reason reason : Reason.values()) {
                long value = count(reason) - before.count(reason);
                delta.put(reason, value);
                sum += value;
            }
            return new Snapshot(Map.copyOf(delta), sum);
        }

        public Snapshot plus(Snapshot other) {
            EnumMap<Reason, Long> sumMap = new EnumMap<>(Reason.class);
            long sum = 0L;
            for (Reason reason : Reason.values()) {
                long value = count(reason) + other.count(reason);
                sumMap.put(reason, value);
                sum += value;
            }
            return new Snapshot(Map.copyOf(sumMap), sum);
        }
    }
}
