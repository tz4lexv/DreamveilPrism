package dev.veil.revive.client;

import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.*;
import static dev.veil.revive.client.shaderpack.parsing.PassParser.*;
import static dev.veil.revive.client.shaderpack.parsing.PipelineStateParser.*;
import static dev.veil.revive.client.shaderpack.parsing.ProgramParser.*;
import static dev.veil.revive.client.shaderpack.parsing.SceneCameraParser.*;
import static dev.veil.revive.client.shaderpack.parsing.SettingsExpressions.*;

import static org.lwjgl.vulkan.VK10.*;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import dev.veil.api.VeilDraw;
import dev.veil.api.VeilTransfer;
import dev.veil.revive.client.VeilShaderPack.Binding;
import dev.veil.revive.client.VeilShaderPack.Geometry;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.VanillaReplacement;

import java.util.LinkedHashSet;
import java.util.Map;

final class VeilShaderPackParser {
    private VeilShaderPackParser() {}

    static VeilShaderPack parse(String source, String namespace) {
        return parse(source, namespace, Map.of());
    }

    static VeilShaderPack parse(String source, String namespace, Map<String, String> overrides) {
        try {
            if (!overrides.isEmpty()) {
                JsonObject root = JsonParser.parseString(source).getAsJsonObject();
                JsonObject settings = object(root, "settings");
                overrides.forEach(
                        (name, value) -> {
                            if (!settings.has(name))
                                throw new IllegalArgumentException(
                                        "Unknown shader setting " + name);
                            settings.getAsJsonObject(name).addProperty("value", value);
                        });
                source = root.toString();
            }
            return parseManifest(source, namespace);
        } catch (RuntimeException failure) {
            throw new IllegalArgumentException(
                    namespace + ":veilpack.json: " + failure.getMessage(), failure);
        }
    }

    private static VeilShaderPack parseManifest(String source, String namespace) {
        JsonObject root = JsonParser.parseString(source).getAsJsonObject();
        fields(
                root,
                "name",
                "abi",
                "resources",
                "programs",
                "settings",
                "passes",
                "present",
                "presentEncoding",
                "replacesVanilla");
        int manifestAbi = root.get("abi").getAsBigDecimal().intValueExact();
        var settings = parseSettings(root);
        var resources =
                dev.veil.revive.client.shaderpack.parsing.ResourceParser.parseResources(
                        root,
                        namespace,
                        manifestAbi,
                        settings,
                        VeilHostResourceRegistry::legacyId,
                        id -> {
                            var host = VeilHostResourceRegistry.definition(id);
                            return new dev.veil.revive.client.shaderpack.parsing.ResourceParser
                                    .HostDefinition(host.kind(), host.type(), host.usages());
                        });
        var programs = parsePrograms(root, namespace);
        var entryPoints = parseEntryPoints(root, namespace);
        var parsedPasses = parsePasses(root, namespace, manifestAbi, settings);
        var passes = parsedPasses.passes();
        boolean disabledPasses = parsedPasses.disabled();
        VanillaReplacement replacement = VanillaReplacement.NONE;
        if (disabledPasses) {
            var used = new LinkedHashSet<String>();
            for (Pass pass : passes) {
                pass.colors().forEach(color -> used.add(color.resource()));
                if (pass.depthTarget() != null) used.add(pass.depthTarget());
                for (Binding binding : pass.bindings().values()) used.addAll(binding.resources());
                if (pass.compute() && pass.dispatch().dynamic())
                    used.add(pass.dispatch().resource());
                if (pass.compute() && pass.dispatch().indirect())
                    used.add(pass.dispatch().indirectResource());
                if (pass.raytrace() && pass.trace().dynamic()) used.add(pass.trace().resource());
                for (VeilDraw draw : pass.draws()) {
                    draw.vertexBuffers().forEach(binding -> used.add(binding.resource()));
                    if (draw.indexBuffer() != null) used.add(draw.indexBuffer().resource());
                    if (draw.indirectBuffer() != null) used.add(draw.indirectBuffer());
                }
                for (VeilTransfer transferOperation : pass.transfers()) {
                    if (transferOperation.source() != null) used.add(transferOperation.source());
                    if (transferOperation.destination() != null)
                        used.add(transferOperation.destination());
                }
            }
            if (root.has("present")) used.add(root.get("present").getAsString());
            resources.keySet().retainAll(used);
        }
        if (root.has("replacesVanilla")) {
            JsonObject item = root.getAsJsonObject("replacesVanilla");
            fields(item, "sky", "sun", "sunriseSunset", "water", "lava", "weather");
            replacement =
                    new VanillaReplacement(
                            item.has("sky") && item.get("sky").getAsBoolean(),
                            item.has("sun") && item.get("sun").getAsBoolean(),
                            item.has("sunriseSunset") && item.get("sunriseSunset").getAsBoolean(),
                            item.has("water") && item.get("water").getAsBoolean(),
                            item.has("lava") && item.get("lava").getAsBoolean(),
                            item.has("weather") && item.get("weather").getAsBoolean());
        }
        int abiVersion = manifestAbi;
        if (replacement.water()) {
            if (abiVersion < 6)
                throw new IllegalArgumentException(
                        "replacesVanilla.water requires Veil shader ABI 6+");
            boolean hasOpaqueColor =
                    resources.values().stream()
                            .anyMatch(
                                    r ->
                                            VeilHostResourceRegistry.SCENE_OPAQUE_COLOR.equals(
                                                    r.hostId()));
            boolean hasOpaqueDepth =
                    resources.values().stream()
                            .anyMatch(
                                    r ->
                                            VeilHostResourceRegistry.SCENE_OPAQUE_DEPTH.equals(
                                                    r.hostId()));
            if (abiVersion == 6) {
                boolean hasMaterialId =
                        resources.values().stream()
                                .anyMatch(
                                        r ->
                                                VeilHostResourceRegistry.SCENE_MATERIAL_ID.equals(
                                                        r.hostId()));
                boolean hasMaterialDepth =
                        resources.values().stream()
                                .anyMatch(
                                        r ->
                                                VeilHostResourceRegistry.SCENE_MATERIAL_DEPTH
                                                        .equals(r.hostId()));
                if (!(hasOpaqueColor && hasOpaqueDepth && hasMaterialId && hasMaterialDepth)) {
                    throw new IllegalArgumentException(
                            "ABI 6 replacesVanilla.water requires scene_opaque_color, scene_opaque_depth, scene_material_id and scene_material_depth imports");
                }
            } else {
                boolean fluidPass =
                        passes.stream()
                                .anyMatch(pass -> !pass.compute() && pass.geometry().water());
                if (!fluidPass) {
                    throw new IllegalArgumentException(
                            "ABI 7+ replacesVanilla.water requires a fluid geometry graphics pass");
                }
                boolean hasSceneDepth =
                        resources.values().stream()
                                .anyMatch(
                                        r ->
                                                VeilHostResourceRegistry.SCENE_DEPTH.equals(
                                                        r.hostId()));
                if (!(hasOpaqueColor && hasOpaqueDepth && hasSceneDepth)) {
                    throw new IllegalArgumentException(
                            "ABI 7+ water replacement requires scene_opaque_color, scene_opaque_depth and scene_depth imports");
                }
            }
        }
        if (replacement.lava()) {
            if (abiVersion < 17
                    || passes.stream().noneMatch(pass -> pass.geometry() == Geometry.FLUID_LAVA))
                throw new IllegalArgumentException(
                        "Lava replacement requires ABI 17 and a fluid_lava pass");
            if (resources.values().stream()
                    .noneMatch(
                            resource ->
                                    VeilHostResourceRegistry.SCENE_DEPTH.equals(resource.hostId())))
                throw new IllegalArgumentException("Lava replacement requires scene depth");
        }
        if (replacement.weather()
                && (abiVersion < 17
                        || !root.has("present")
                        || resources.values().stream()
                                .noneMatch(
                                        resource ->
                                                VeilHostResourceRegistry.ENVIRONMENT.equals(
                                                        resource.hostId()))
                        || resources.values().stream()
                                .noneMatch(
                                        resource ->
                                                VeilHostResourceRegistry.SCENE_DEPTH.equals(
                                                        resource.hostId()))))
            throw new IllegalArgumentException(
                    "Weather replacement requires ABI 17, environment, scene depth and presentation");
        return new VeilShaderPack(
                root.get("name").getAsString(),
                abiVersion,
                resources,
                programs,
                settings,
                passes,
                root.has("present") ? resourceName(root.get("present").getAsString()) : null,
                replacement,
                entryPoints,
                root.has("presentEncoding")
                        ? VeilShaderPack.PresentEncoding.valueOf(
                                root.get("presentEncoding")
                                        .getAsString()
                                        .toUpperCase(java.util.Locale.ROOT))
                        : VeilShaderPack.PresentEncoding.LEGACY);
    }
}
