package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.vkCmdCopyBuffer;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.api.VeilCreatorMeshes;

import net.minecraft.client.Minecraft;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkBufferCopy;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

final class VeilCreatorMeshHost {
    static final String HOST_ID = "minecraft:creator_meshes";
    static final int CAPACITY = 8 * 1024 * 1024;
    private static final int HEADER = 64;
    private static final int VERTEX_STRIDE = 32;
    private static final int TRIANGLE_STRIDE = 32;
    private static final int NODE_STRIDE = 32;
    private static final int MAX_VERTICES = 65_536;

    private static GpuBuffer buffer;
    private static int originX, originY, originZ;
    private static int[] topologyKey;
    private static VeilTriangleMeshBvh.Topology topology;
    private static int dataHash;
    private static boolean uploaded;
    private static long sourceRevision = Long.MIN_VALUE;
    private static long frames, uploads, rebuilds, refits;
    private static int meshCount, vertexCount, triangleCount, nodeCount, maxDepth;

    private VeilCreatorMeshHost() {}

    static void prepare() {
        RenderSystem.assertOnRenderThread();
        Minecraft client = Minecraft.getInstance();
        if (client.level == null
                || client.gameRenderer == null
                || client.gameRenderer.mainCamera() == null) return;
        var camera = client.gameRenderer.mainCamera().position();
        int nextOriginX = floor256(camera.x),
                nextOriginY = floor256(camera.y),
                nextOriginZ = floor256(camera.z);
        if (buffer == null)
            buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil creator triangle meshes",
                                    VeilHzb.STORAGE_USAGE | GpuBuffer.USAGE_COPY_DST,
                                    CAPACITY);
        VeilCreatorMeshes.Snapshot snapshot = VeilCreatorMeshes.snapshot();
        if (uploaded
                && snapshot.revision() == sourceRevision
                && nextOriginX == originX
                && nextOriginY == originY
                && nextOriginZ == originZ) {
            frames++;
            return;
        }
        originX = nextOriginX;
        originY = nextOriginY;
        originZ = nextOriginZ;
        byte[] encoded = encode(snapshot.meshes());
        int nextHash = Arrays.hashCode(encoded);
        if (!uploaded || nextHash != dataHash) {
            upload(encoded);
            dataHash = nextHash;
            uploaded = true;
            uploads++;
        }
        sourceRevision = snapshot.revision();
        frames++;
    }

    static GpuBuffer buffer() {
        if (buffer == null) throw new IllegalStateException(HOST_ID + " is not prepared");
        return buffer;
    }

    static byte[] encode(List<VeilCreatorMeshes.Mesh> source) {
        ArrayList<VeilCreatorMeshes.Mesh> meshes = new ArrayList<>(source);
        meshes.sort(Comparator.comparingLong(VeilCreatorMeshes.Mesh::id));
        ArrayList<VeilCreatorMeshes.Mesh> accepted = new ArrayList<>();
        int vertices = 0, triangles = 0;
        for (VeilCreatorMeshes.Mesh mesh : meshes) {
            if (vertices + mesh.vertexCount() > MAX_VERTICES
                    || triangles + mesh.triangleCount() > VeilTriangleMeshBvh.MAX_TRIANGLES) break;
            accepted.add(mesh);
            vertices += mesh.vertexCount();
            triangles += mesh.triangleCount();
        }

        ArrayList<Triangle> triangleData = new ArrayList<>(triangles);
        ArrayList<VeilTriangleMeshBvh.Bounds> bounds = new ArrayList<>(triangles);
        int vertexBase = 0;
        ArrayList<Integer> nextTopologyKey = new ArrayList<>();
        for (VeilCreatorMeshes.Mesh mesh : accepted) {
            nextTopologyKey.add((int) mesh.id());
            nextTopologyKey.add((int) (mesh.id() >>> 32));
            nextTopologyKey.add(mesh.vertexCount());
            nextTopologyKey.add(mesh.triangleCount());
            for (int triangle = 0; triangle < mesh.triangleCount(); triangle++) {
                int a = mesh.index(triangle * 3),
                        b = mesh.index(triangle * 3 + 1),
                        c = mesh.index(triangle * 3 + 2);
                nextTopologyKey.add(a);
                nextTopologyKey.add(b);
                nextTopologyKey.add(c);
                triangleData.add(
                        new Triangle(
                                vertexBase + a,
                                vertexBase + b,
                                vertexBase + c,
                                mesh.material(),
                                mesh.id(),
                                mesh.flags(),
                                mesh.hasTextureCoordinates()));
                bounds.add(bounds(mesh, a, b, c));
            }
            vertexBase += mesh.vertexCount();
        }

        List<VeilTriangleMeshBvh.Node> nodes;
        int[] topologySignature = nextTopologyKey.stream().mapToInt(Integer::intValue).toArray();
        if (topology == null || !Arrays.equals(topologySignature, topologyKey)) {
            VeilTriangleMeshBvh.Build build = VeilTriangleMeshBvh.build(bounds);
            topology = build.topology();
            nodes = build.nodes();
            topologyKey = topologySignature;
            rebuilds++;
        } else if (triangles == 0) {
            nodes = List.of();
        } else {
            nodes = VeilTriangleMeshBvh.refit(topology, bounds);
            refits++;
        }

        int vertexOffsetWords = HEADER / 16;
        int triangleOffsetWords = vertexOffsetWords + vertices * (VERTEX_STRIDE / 16);
        int nodeOffsetWords = triangleOffsetWords + triangles * (TRIANGLE_STRIDE / 16);
        boolean hasUv = accepted.stream().anyMatch(VeilCreatorMeshes.Mesh::hasTextureCoordinates);
        int uvOffsetWords = hasUv ? nodeOffsetWords + nodes.size() * (NODE_STRIDE / 16) : 0;
        int size =
                HEADER
                        + vertices * VERTEX_STRIDE
                        + triangles * TRIANGLE_STRIDE
                        + nodes.size() * NODE_STRIDE
                        + (hasUv ? vertices * 16 : 0);
        if (size > CAPACITY)
            throw new IllegalStateException("Creator triangle mesh buffer exceeds host capacity");
        ByteBuffer out = ByteBuffer.wrap(new byte[size]).order(ByteOrder.LITTLE_ENDIAN);
        out.putInt(0, 0x56474d31).putInt(4, 1).putInt(8, vertices).putInt(12, triangles);
        out.putFloat(16, originX)
                .putFloat(20, originY)
                .putFloat(24, originZ)
                .putInt(28, nodes.size());
        out.putInt(32, vertexOffsetWords)
                .putInt(36, triangleOffsetWords)
                .putInt(40, nodeOffsetWords)
                .putInt(44, topology.root());
        out.putInt(48, accepted.size())
                .putInt(52, topology.maxDepth())
                .putInt(56, (int) rebuilds)
                .putInt(60, uvOffsetWords);
        int offset = HEADER;
        for (VeilCreatorMeshes.Mesh mesh : accepted) {
            for (int vertex = 0; vertex < mesh.vertexCount(); vertex++) {
                out.putFloat(offset, mesh.position(vertex, 0) - originX)
                        .putFloat(offset + 4, mesh.position(vertex, 1) - originY)
                        .putFloat(offset + 8, mesh.position(vertex, 2) - originZ)
                        .putInt(offset + 12, 0);
                out.putFloat(offset + 16, mesh.previousPosition(vertex, 0) - originX)
                        .putFloat(offset + 20, mesh.previousPosition(vertex, 1) - originY)
                        .putFloat(offset + 24, mesh.previousPosition(vertex, 2) - originZ)
                        .putInt(offset + 28, 0);
                offset += VERTEX_STRIDE;
            }
        }
        for (Triangle triangle : triangleData) {
            out.putInt(offset, triangle.a)
                    .putInt(offset + 4, triangle.b)
                    .putInt(offset + 8, triangle.c)
                    .putInt(offset + 12, triangle.material);
            out.putInt(offset + 16, (int) triangle.meshId)
                    .putInt(offset + 20, (int) (triangle.meshId >>> 32))
                    .putInt(offset + 24, triangle.flags)
                    .putInt(offset + 28, triangle.hasUv ? 1 : 0);
            offset += TRIANGLE_STRIDE;
        }
        for (VeilTriangleMeshBvh.Node node : nodes) {
            int left = node.leaf() ? node.primitive() | 0x80000000 : node.left();
            int right = node.leaf() ? -1 : node.right();
            var value = node.bounds();
            out.putFloat(offset, value.minX() - originX)
                    .putFloat(offset + 4, value.minY() - originY)
                    .putFloat(offset + 8, value.minZ() - originZ)
                    .putInt(offset + 12, left);
            out.putFloat(offset + 16, value.maxX() - originX)
                    .putFloat(offset + 20, value.maxY() - originY)
                    .putFloat(offset + 24, value.maxZ() - originZ)
                    .putInt(offset + 28, right);
            offset += NODE_STRIDE;
        }
        if (hasUv) {
            for (VeilCreatorMeshes.Mesh mesh : accepted) {
                for (int vertex = 0; vertex < mesh.vertexCount(); vertex++) {
                    out.putFloat(offset, mesh.textureCoordinate(vertex, 0))
                            .putFloat(offset + 4, mesh.textureCoordinate(vertex, 1));
                    offset += 16;
                }
            }
        }
        meshCount = accepted.size();
        vertexCount = vertices;
        triangleCount = triangles;
        nodeCount = nodes.size();
        maxDepth = topology.maxDepth();
        return out.array();
    }

    private static VeilTriangleMeshBvh.Bounds bounds(
            VeilCreatorMeshes.Mesh mesh, int a, int b, int c) {
        float minX = Float.POSITIVE_INFINITY,
                minY = Float.POSITIVE_INFINITY,
                minZ = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY,
                maxY = Float.NEGATIVE_INFINITY,
                maxZ = Float.NEGATIVE_INFINITY;
        int[] vertices = {a, b, c};
        for (int vertex : vertices)
            for (int previous = 0; previous < 2; previous++) {
                float x =
                        previous == 0 ? mesh.position(vertex, 0) : mesh.previousPosition(vertex, 0);
                float y =
                        previous == 0 ? mesh.position(vertex, 1) : mesh.previousPosition(vertex, 1);
                float z =
                        previous == 0 ? mesh.position(vertex, 2) : mesh.previousPosition(vertex, 2);
                minX = Math.min(minX, x);
                minY = Math.min(minY, y);
                minZ = Math.min(minZ, z);
                maxX = Math.max(maxX, x);
                maxY = Math.max(maxY, y);
                maxZ = Math.max(maxZ, z);
            }
        float epsilon = 1.0e-5f;
        return new VeilTriangleMeshBvh.Bounds(
                minX - epsilon,
                minY - epsilon,
                minZ - epsilon,
                maxX + epsilon,
                maxY + epsilon,
                maxZ + epsilon);
    }

    private static void upload(byte[] data) {
        GpuBuffer staging =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil creator mesh staging",
                                GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                                data.length);
        try {
            try (var mapping = staging.map(false, true)) {
                mapping.data().put(data);
            }
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var copy = VkBufferCopy.calloc(1, stack);
                copy.get(0).srcOffset(0).dstOffset(0).size(data.length);
                vkCmdCopyBuffer(
                        VeilVulkanRuntime.requireCurrent().commandBuffer(),
                        ((VulkanGpuBuffer) staging).vkBuffer(),
                        ((VulkanGpuBuffer) buffer).vkBuffer(),
                        copy);
            }
        } finally {
            staging.close();
        }
    }

    static String telemetry() {
        return "creator_mesh_frames="
                + frames
                + "\ncreator_mesh_uploads_total="
                + uploads
                + "\ncreator_meshes="
                + meshCount
                + "\ncreator_mesh_vertices="
                + vertexCount
                + "\ncreator_mesh_triangles="
                + triangleCount
                + "\ncreator_mesh_nodes="
                + nodeCount
                + "\ncreator_mesh_max_depth="
                + maxDepth
                + "\ncreator_mesh_bvh_rebuilds="
                + rebuilds
                + "\ncreator_mesh_bvh_refits="
                + refits;
    }

    static void close() {
        if (buffer != null) {
            buffer.close();
            buffer = null;
        }
        topology = null;
        topologyKey = null;
        dataHash = 0;
        uploaded = false;
        sourceRevision = Long.MIN_VALUE;
        meshCount = vertexCount = triangleCount = nodeCount = maxDepth = 0;
    }

    private static int floor256(double value) {
        return Math.floorDiv((int) Math.floor(value), 256) * 256;
    }

    private record Triangle(
            int a, int b, int c, int material, long meshId, int flags, boolean hasUv) {}
}
