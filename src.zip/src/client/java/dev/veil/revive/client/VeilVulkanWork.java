package dev.veil.revive.client;

public final class VeilVulkanWork {
    private static long uniforms, pipelines;

    private VeilVulkanWork() {}

    public static void skippedUniform() {
        uniforms++;
    }

    public static void skippedPipeline() {
        pipelines++;
    }

    public static Snapshot snapshot() {
        return new Snapshot(uniforms, pipelines);
    }

    public record Snapshot(long uniforms, long pipelines) {}
}
