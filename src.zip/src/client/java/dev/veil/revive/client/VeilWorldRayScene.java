package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.vkCmdCopyBuffer;
import static org.lwjgl.vulkan.VK10.vkGetPhysicalDeviceProperties;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;

import dev.veil.revive.mixin.ViewAreaSectionsAccessor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.chunk.CompiledSectionMesh;
import net.minecraft.client.renderer.chunk.RenderRegionCache;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.core.SectionPos;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkBufferCopy;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class VeilWorldRayScene {
    static final String HOST_ID = "minecraft:ray_world";
    static final int CAPACITY = 8 * 1024 * 1024;
    private static volatile boolean requested;
    private static boolean accelerationRequested;
    private static boolean incremental;
    private static Object cacheGeneration = new Object();
    private static final VeilRaySectionCache SECTION_CACHE = new VeilRaySectionCache();
    private static final VeilRayAccelerationCache ACCELERATION_CACHE =
            new VeilRayAccelerationCache();
    private static long rebuiltSections, reusedSections;
    private static GpuBuffer data;
    private static VeilRayQueryScene acceleration;
    private static final ExecutorService BUILDER =
            Executors.newSingleThreadExecutor(
                    task -> {
                        Thread thread = new Thread(task, "Veil ray world builder");
                        thread.setDaemon(true);
                        return thread;
                    });
    private static final VeilRayBuildQueue<Compiled> BUILDS = new VeilRayBuildQueue<>(BUILDER);
    private static long sceneKey = Long.MIN_VALUE;
    private static ClientLevel world;
    private static VeilShaderLimits.Settings settings;
    private static int triangleCapacity;
    private static long lastScheduleNanos, lastScanNanos;
    private static long builds,
            capturedSections,
            capturedTriangles,
            truncatedFrames,
            offscreenCompiles;

    private VeilWorldRayScene() {}

    static boolean requested() {
        return requested;
    }

    static boolean hasAcceleration() {
        return acceleration != null;
    }

    static void accelerationRequested(boolean value) {
        if (accelerationRequested == value) return;
        accelerationRequested = value;
        close();
    }

    static void incremental(boolean value) {
        if (incremental == value) return;
        incremental = value;
        close();
    }

    static void requested(boolean value) {
        if (requested == value) return;
        requested = value;
        if (!value) {
            close();
            return;
        }
        BUILDS.invalidate();
        cacheGeneration = new Object();
        sceneKey = Long.MIN_VALUE;
        lastScanNanos = 0;
    }

    static void prepare() {
        RenderSystem.assertOnRenderThread();
        if (!requested) return;
        Minecraft client = Minecraft.getInstance();
        VeilShaderLimits.Settings current = VeilShaderLimits.current();
        if (world != client.level || !current.equals(settings)) {
            releaseBuffers();
            ACCELERATION_CACHE.close();
            world = client.level;
            settings = current;
            BUILDS.invalidate();
            cacheGeneration = new Object();
            sceneKey = Long.MIN_VALUE;
            lastScanNanos = 0;
            long storageBytes;
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var properties = VkPhysicalDeviceProperties.calloc(stack);
                vkGetPhysicalDeviceProperties(
                        VeilVulkanRuntime.requireCurrent().vkDevice().getPhysicalDevice(),
                        properties);
                storageBytes = Integer.toUnsignedLong(properties.limits().maxStorageBufferRange());
            }
            long bytes =
                    Math.min(
                            storageBytes,
                            Math.min(
                                    settings.rayBytes(),
                                    Math.min(settings.bufferBytes(), settings.packBytes())));
            if (bytes < CAPACITY)
                throw new IllegalStateException(
                        "Minecraft ray world requires at least 8 MiB of storage buffer capacity");
            triangleCapacity = VeilShaderLimits.rayTriangleCapacity(bytes);
        }
        publishPending();
        ensureEmpty();
        if (world == null
                || client.levelRenderer == null
                || client.gameRenderer == null
                || client.gameRenderer.mainCamera() == null) return;
        long now = System.nanoTime();
        if (now - lastScanNanos < settings.rebuildMs() * 1_000_000L) return;
        lastScanNanos = now;
        var viewArea = client.levelRenderer.viewArea();
        if (viewArea == null) return;
        var camera = client.gameRenderer.mainCamera().position();
        int originX = floor256(camera.x),
                originY = floor256(camera.y),
                originZ = floor256(camera.z);
        var candidates = new ArrayList<Candidate>();
        var missing = new ArrayList<Missing>();
        double radiusSquared = (double) settings.rayRadius() * settings.rayRadius();
        for (var section : ((ViewAreaSectionsAccessor) viewArea).veil$sections()) {
            if (section == null) continue;
            long node = section.getSectionNode();
            int sx = SectionPos.x(node) << 4,
                    sy = SectionPos.y(node) << 4,
                    sz = SectionPos.z(node) << 4;
            double dx = sx + 8.0 - camera.x, dy = sy + 8.0 - camera.y, dz = sz + 8.0 - camera.z;
            double distance = dx * dx + dy * dy + dz * dz;
            if (distance > radiusSquared) continue;
            var mesh = section.getSectionMesh();
            if (mesh == CompiledSectionMesh.UNCOMPILED
                    && !((VeilRayCompileState) section).veil$rayCompilePending())
                missing.add(new Missing(section, distance));
            if (!(mesh instanceof VeilMeshExtras extras)) continue;
            var metadata = extras.veil$metadata();
            if (metadata == null
                    || metadata.rayGeometry() == null
                    || metadata.rayGeometry().triangleCount() == 0) continue;
            candidates.add(
                    new Candidate(
                            metadata.rayGeometry(),
                            node,
                            sx - originX,
                            sy - originY,
                            sz - originZ,
                            distance));
        }
        compileMissing(client, missing);
        candidates.sort(
                Comparator.comparingDouble(Candidate::distance).thenComparingLong(Candidate::node));
        int total = 0;
        long availableTriangles = 0;
        long key =
                mix(originX)
                        ^ Long.rotateLeft(mix(originY), 21)
                        ^ Long.rotateLeft(mix(originZ), 42);
        var selected = new ArrayList<Candidate>();
        for (Candidate candidate : candidates) {
            availableTriangles += candidate.geometry().triangleCount();
            int included =
                    Math.min(candidate.geometry().triangleCount(), triangleCapacity - total) & ~1;
            if (included == 0) continue;
            total += included;
            selected.add(candidate);
            key =
                    Long.rotateLeft(
                            key
                                    ^ mix(candidate.node())
                                    ^ System.identityHashCode(candidate.geometry())
                                    ^ included,
                            13);
        }
        key ^= selected.size();
        if (key == sceneKey
                || key == BUILDS.pendingKey()
                || BUILDS.busy()
                || now - lastScheduleNanos < settings.rebuildMs() * 1_000_000L) return;
        int triangles = total;
        boolean truncated = availableTriangles > total;
        long compiledKey = key;
        var snapshot = java.util.List.copyOf(selected);
        lastScheduleNanos = now;
        Object generation = cacheGeneration;
        BUILDS.submit(
                compiledKey,
                () ->
                        compile(
                                snapshot,
                                triangles,
                                originX,
                                originY,
                                originZ,
                                compiledKey,
                                truncated,
                                generation));
    }

    private static Compiled compile(
            java.util.List<Candidate> selected,
            int triangles,
            int originX,
            int originY,
            int originZ,
            long key,
            boolean truncated,
            Object generation) {
        var sections = new ArrayList<VeilRaySectionCache.Section>();
        int remaining = triangles;
        for (var candidate : selected) {
            int included = Math.min(remaining, candidate.geometry().triangleCount()) & ~1;
            remaining -= included;
            var sectionKey = new VeilRaySectionCache.Key(candidate.geometry(), included);
            sections.add(
                    new VeilRaySectionCache.Section(
                            sectionKey,
                            candidate.x(),
                            candidate.y(),
                            candidate.z(),
                            () -> compileSection(candidate.geometry(), included)));
        }
        var compiled =
                SECTION_CACHE.compile(generation, sections, originX, originY, originZ, CAPACITY);
        return new Compiled(key, compiled.bytes(), selected.size(), triangles, truncated, compiled);
    }

    private static byte[] compileSection(VeilRaySectionGeometry geometry, int triangles) {
        float[] vertices = new float[triangles * 9];
        int[] attributes = new int[triangles * 12];
        int[] materials = new int[triangles];
        int appended = geometry.append(vertices, attributes, materials, 0, 0, 0, 0, triangles);
        if (appended != triangles)
            throw new IllegalStateException("Immutable section geometry size changed");
        byte[] bytes =
                VeilRayScene.compileWorld(
                        vertices,
                        attributes,
                        materials,
                        triangles,
                        0,
                        0,
                        0,
                        VeilShaderLimits.rayCapacityBytes(triangles));
        var header = java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        int usedBytes = Math.toIntExact(16L * (header.getInt(48) + triangles * 3L));
        return java.util.Arrays.copyOf(bytes, usedBytes);
    }

    private static void compileMissing(Minecraft client, ArrayList<Missing> missing) {
        var dispatcher = client.levelRenderer.sectionRenderDispatcher();
        if (settings.offscreenCompiles() == 0
                || missing.isEmpty()
                || dispatcher == null
                || dispatcher.getCompileQueueSize() != 0
                || dispatcher.getFreeBufferCount() == 0) return;
        missing.sort(Comparator.comparingDouble(Missing::distance));
        RenderRegionCache cache = new RenderRegionCache();
        int scheduled = 0;
        long deadline = System.nanoTime() + 1_000_000L;
        for (Missing candidate : missing) {
            if (scheduled >= settings.offscreenCompiles() || System.nanoTime() >= deadline) break;
            var section = candidate.section();
            long node = section.getSectionNode();
            int x = SectionPos.x(node), z = SectionPos.z(node);
            boolean loaded = true;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    loaded &= world.getChunkSource().hasChunk(x + dx, z + dz);
            if (!loaded || ((VeilRayCompileState) section).veil$rayCompilePending()) continue;
            section.compileAsync(cache.createRegion(world, node));
            scheduled++;
            offscreenCompiles++;
        }
    }

    private static void publishPending() {
        Compiled compiled = BUILDS.poll();
        if (compiled == null) return;
        upload(compiled.bytes(), compiled.result());
        rebuiltSections += compiled.result().rebuilt();
        reusedSections += compiled.result().reused();
        sceneKey = compiled.key();
        builds++;
        capturedSections = compiled.sections();
        capturedTriangles = compiled.triangles();
        if (compiled.truncated()) truncatedFrames++;
    }

    private static void ensureEmpty() {
        if (data == null)
            upload(
                    VeilRayScene.compileWorld(
                            new float[0], new int[0], new int[0], 0, 0, 0, 0, CAPACITY),
                    null);
    }

    private static void upload(byte[] compiled, VeilRaySectionCache.Result sectionResult) {
        var runtime = VeilVulkanRuntime.requireCurrent();
        GpuBuffer replacement =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil Minecraft ray world data",
                                VeilHzb.STORAGE_USAGE | GpuBuffer.USAGE_COPY_DST,
                                compiled.length);
        VeilRayQueryScene replacementAcceleration = null;
        try {
            try (GpuBuffer upload =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil Minecraft ray world upload",
                                    GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_COPY_SRC,
                                    compiled.length)) {
                try (var mapping = upload.map(false, true)) {
                    mapping.data().put(compiled);
                }
                try (MemoryStack stack = MemoryStack.stackPush()) {
                    var copy = VkBufferCopy.calloc(1, stack);
                    copy.get(0).srcOffset(0).dstOffset(0).size(compiled.length);
                    vkCmdCopyBuffer(
                            runtime.commandBuffer(),
                            ((VulkanGpuBuffer) upload).vkBuffer(),
                            ((VulkanGpuBuffer) replacement).vkBuffer(),
                            copy);
                }
            }
            if (accelerationRequested && VeilRayCapabilities.accelerationStructures()) {
                if (incremental && sectionResult != null && !sectionResult.parts().isEmpty()) {
                    replacementAcceleration =
                            ACCELERATION_CACHE.prepare(
                                    runtime, sectionResult.parts(), compiled.length);
                } else {
                    replacementAcceleration =
                            new VeilRayQueryScene(runtime, compiled, "Veil Minecraft ray world");
                    replacementAcceleration.build();
                }
            }
        } catch (RuntimeException | Error failure) {
            replacement.close();
            if (replacementAcceleration != null) replacementAcceleration.close();
            throw failure;
        }
        releaseBuffers();
        data = replacement;
        acceleration = replacementAcceleration;
    }

    static GpuBuffer buffer() {
        if (data == null) throw new IllegalStateException("Minecraft ray world is not prepared");
        return data;
    }

    static long accelerationHandle() {
        if (acceleration == null)
            throw new IllegalStateException("Minecraft ray acceleration structure is unavailable");
        return acceleration.handle();
    }

    static String telemetry() {
        return "ray_world_requested="
                + requested
                + "\nray_world_ready="
                + (data != null)
                + "\nray_world_format=VRT3\nray_world_surface_attributes=uv_rg16f,color_rgba8,light_rg16u,layer_flags"
                + "\nray_world_section_rebuilds_total="
                + rebuiltSections
                + "\nray_world_section_reuses_total="
                + reusedSections
                + "\n"
                + ACCELERATION_CACHE.telemetry()
                + "\nray_world_builds_total="
                + builds
                + "\nray_world_sections="
                + capturedSections
                + "\nray_world_triangles="
                + capturedTriangles
                + "\nray_world_triangle_capacity="
                + triangleCapacity
                + "\nray_world_buffer_bytes="
                + (data == null ? 0 : data.size())
                + "\nray_world_offscreen_compiles_total="
                + offscreenCompiles
                + "\nray_world_truncated_frames_total="
                + truncatedFrames;
    }

    static void close() {
        releaseBuffers();
        ACCELERATION_CACHE.close();
        BUILDS.invalidate();
        BUILDER.execute(SECTION_CACHE::clear);
        cacheGeneration = new Object();
        world = null;
        settings = null;
        sceneKey = Long.MIN_VALUE;
        lastScheduleNanos = 0;
        lastScanNanos = 0;
    }

    private static void releaseBuffers() {
        if (acceleration != null) {
            acceleration.close();
            acceleration = null;
        }
        if (data != null) {
            data.close();
            data = null;
        }
    }

    private static int floor256(double value) {
        return Math.floorDiv((int) Math.floor(value), 256) * 256;
    }

    private static long mix(long value) {
        value ^= value >>> 30;
        value *= 0xbf58476d1ce4e5b9L;
        value ^= value >>> 27;
        value *= 0x94d049bb133111ebL;
        return value ^ value >>> 31;
    }

    private record Candidate(
            VeilRaySectionGeometry geometry,
            long node,
            float x,
            float y,
            float z,
            double distance) {}

    private record Missing(SectionRenderDispatcher.RenderSection section, double distance) {}

    private record Compiled(
            long key,
            byte[] bytes,
            int sections,
            int triangles,
            boolean truncated,
            VeilRaySectionCache.Result result) {}
}
