package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.CompactVectorArray;

import org.joml.Vector3f;

public record VeilTransparencyRegion(
        float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
    public boolean contains(float x, float y, float z) {
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    static VeilTransparencyRegion create(
            CompactVectorArray points, int[] order, float x, float y, float z) {
        if (!Float.isFinite(x)
                || !Float.isFinite(y)
                || !Float.isFinite(z)
                || points.size() != order.length
                || order.length == 0) return null;
        for (int index : order) if (index < 0 || index >= points.size()) return null;
        Vector3f a = new Vector3f(), b = new Vector3f();
        boolean identical = true;
        points.get(order[0], a);
        if (!a.isFinite()) return null;
        for (int i = 1; i < order.length; i++) {
            points.get(order[i], b);
            if (!b.isFinite()) return null;
            if (a.x != b.x || a.y != b.y || a.z != b.z || order[i - 1] > order[i]) {
                identical = false;
                break;
            }
        }
        if (identical)
            return new VeilTransparencyRegion(
                    -Float.MAX_VALUE,
                    -Float.MAX_VALUE,
                    -Float.MAX_VALUE,
                    Float.MAX_VALUE,
                    Float.MAX_VALUE,
                    Float.MAX_VALUE);
        if (order.length <= 4096) {
            for (float radius = .25f; radius >= .00390625f; radius *= .25f) {
                var region =
                        new VeilTransparencyRegion(
                                x - radius,
                                y - radius,
                                z - radius,
                                x + radius,
                                y + radius,
                                z + radius);
                if (region.certified(points, order, a, b)) return region;
            }
        }
        return new VeilTransparencyRegion(x, y, z, x, y, z);
    }

    private boolean certified(CompactVectorArray points, int[] order, Vector3f a, Vector3f b) {
        points.get(order[0], a);
        if (!a.isFinite()) return false;
        long previous = bounds(a);
        for (int i = 1; i < order.length; i++) {
            points.get(order[i], b);
            if (!b.isFinite()) return false;
            long current = bounds(b);
            if (a.x == b.x && a.y == b.y && a.z == b.z) {
                if (order[i - 1] > order[i]) return false;
            } else {
                float lower = Float.intBitsToFloat((int) (previous >>> 32));
                float upper = Float.intBitsToFloat((int) current);
                if (!Float.isFinite(lower)
                        || !Float.isFinite(upper)
                        || lower < upper
                        || (lower == upper && order[i - 1] > order[i])) return false;
            }
            a.set(b);
            previous = current;
        }
        return true;
    }

    private long bounds(Vector3f point) {
        float lx = squareBound(point.x, minX, maxX, false);
        float ly = squareBound(point.y, minY, maxY, false);
        float lz = squareBound(point.z, minZ, maxZ, false);
        float ux = squareBound(point.x, minX, maxX, true);
        float uy = squareBound(point.y, minY, maxY, true);
        float uz = squareBound(point.z, minZ, maxZ, true);
        float lower = Math.max(0, Math.nextDown(lx + Math.max(0, Math.nextDown(ly + lz))));
        float upper = Math.nextUp(ux + Math.nextUp(uy + uz));
        return ((long) Float.floatToRawIntBits(lower) << 32)
                | Integer.toUnsignedLong(Float.floatToRawIntBits(upper));
    }

    private static float squareBound(float point, float min, float max, boolean upper) {
        float lo = point - max, hi = point - min;
        float distance =
                upper
                        ? Math.max(Math.abs(lo), Math.abs(hi))
                        : lo <= 0 && hi >= 0 ? 0 : Math.min(Math.abs(lo), Math.abs(hi));
        float square = distance * distance;
        return upper ? Math.nextUp(square) : Math.max(0, Math.nextDown(square));
    }
}
