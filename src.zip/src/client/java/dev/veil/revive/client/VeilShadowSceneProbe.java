package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

final class VeilShadowSceneProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.shadowProbe") && VeilPlatform.get().isDevelopmentEnvironment();
    private static long started;
    private static int frames;
    private static int generation;
    private static boolean pending;
    private static boolean completed;
    private static VeilShaderPackRuntime previous;

    private VeilShadowSceneProbe() {}

    static void tick(VeilShaderPackRuntime active, boolean failed) {
        if (!ENABLED || completed) return;
        long now = System.nanoTime();
        if (started == 0) started = now;
        if (failed || now - started > 300_000_000_000L) {
            fail(new IllegalStateException("custom scene runtime unavailable or timed out"));
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (pending
                || active == null
                || active == previous
                || minecraft.level == null
                || minecraft.player == null
                || ++frames < 120) return;
        var view = active.output("shadowDepth");
        int width = view.getWidth(0);
        int height = view.getHeight(0);
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil shadow depth probe",
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                (long) width * height * Float.BYTES);
        pending = true;
        try {
            active.readDepthOutput(
                    "shadowDepth",
                    readback,
                    () -> {
                        try (var mapped = readback.map(true, false)) {
                            var bytes = mapped.data().order(java.nio.ByteOrder.nativeOrder());
                            int written = 0;
                            int clear = 0;
                            float minimum = 1.0f;
                            float maximum = 0.0f;
                            int stride = Math.max(1, width * height / 262144);
                            for (int pixel = 0; pixel < width * height; pixel += stride) {
                                float depth = bytes.getFloat(pixel * Float.BYTES);
                                if (!Float.isFinite(depth) || depth < 0.0f || depth > 1.0f) {
                                    throw new IllegalStateException(
                                            "invalid shadow depth at pixel "
                                                    + pixel
                                                    + ": "
                                                    + depth);
                                }
                                minimum = Math.min(minimum, depth);
                                maximum = Math.max(maximum, depth);
                                if (depth > 0.000001f) written++;
                                else clear++;
                            }
                            if (written == 0 || clear == 0 || maximum - minimum < 0.0001f) {
                                throw new IllegalStateException(
                                        "shadow depth lacks caster/background separation: written="
                                                + written
                                                + " clear="
                                                + clear
                                                + " range="
                                                + minimum
                                                + ".."
                                                + maximum);
                            }
                            generation++;
                            if (generation == 1) {
                                previous = active;
                                frames = 0;
                                started = System.nanoTime();
                                VeilShaderService.requestReload();
                                ReviveMod.LOGGER.info(
                                        "Veil shadow GPU probe: first generation verified; requesting hot reload");
                            } else {
                                if (VeilShaderService.profiling()) active.requireProfileSamples(16);
                                completed = true;
                                ReviveMod.LOGGER.info(
                                        "Veil shadow GPU probe: PASS ({}x{}, D32 depth caster/background separation, custom camera terrain replay, cutout pipeline, hot reload, 2 generations)\n{}",
                                        width,
                                        height,
                                        VeilShaderService.performanceReport());
                            }
                        } catch (RuntimeException failure) {
                            fail(failure);
                        } finally {
                            readback.close();
                            pending = false;
                            if (completed) Minecraft.getInstance().stop();
                        }
                    });
        } catch (RuntimeException failure) {
            readback.close();
            pending = false;
            fail(failure);
        }
    }

    private static void fail(RuntimeException failure) {
        completed = true;
        ReviveMod.LOGGER.error("Veil shadow GPU probe: FAIL ({})", failure.getMessage(), failure);
        if (!pending) Minecraft.getInstance().stop();
    }
}
