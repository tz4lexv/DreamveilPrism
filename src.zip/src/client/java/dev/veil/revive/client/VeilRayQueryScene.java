package dev.veil.revive.client;

import static org.lwjgl.vulkan.KHRAccelerationStructure.*;
import static org.lwjgl.vulkan.KHRRayTracingPipeline.VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR;
import static org.lwjgl.vulkan.VK12.*;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.*;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

final class VeilRayQueryScene implements AutoCloseable {
    private final VeilVulkanRuntime runtime;
    private final ArrayList<Buffer> buffers = new ArrayList<>();
    private final int triangles;
    private final int buildTriangles;
    private final String label;
    private Buffer vertices, instances, scratch;
    private long bottom, top;
    private long alignment;
    private boolean built, closed, bottomOnly, topOnly;
    private int instanceCount = 1;

    record Instance(long address, int triangleOffset, float x, float y, float z) {}

    VeilRayQueryScene(VeilVulkanRuntime runtime, byte[] scene, String label) {
        this(runtime, scene, label, false);
    }

    VeilRayQueryScene(VeilVulkanRuntime runtime, byte[] scene, String label, boolean bottomOnly) {
        this.bottomOnly = bottomOnly;
        this.runtime = runtime;
        this.label = label;
        if (!VeilRayCapabilities.accelerationStructures())
            throw new IllegalStateException(
                    "Shader requires enabled VK_KHR_acceleration_structure + bufferDeviceAddress; no automatic fallback");
        ByteBuffer input = ByteBuffer.wrap(scene).order(ByteOrder.LITTLE_ENDIAN);
        int version = input.getInt(4);
        if (input.getInt(0) != VeilRayScene.MAGIC || version < 1 || version > 3)
            throw new IllegalArgumentException("Ray query requires a compiled Veil ray scene");
        triangles = input.getInt(12);
        buildTriangles = Math.max(1, triangles);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var props =
                    VkPhysicalDeviceAccelerationStructurePropertiesKHR.calloc(stack)
                            .sType$Default();
            vkGetPhysicalDeviceProperties2(
                    runtime.vkDevice().getPhysicalDevice(),
                    VkPhysicalDeviceProperties2.calloc(stack)
                            .sType$Default()
                            .pNext(props.address()));
            alignment = props.minAccelerationStructureScratchOffsetAlignment();
            if (triangles < 0
                    || triangles > VeilRayScene.MAX_TRIANGLES
                    || buildTriangles > props.maxPrimitiveCount()
                    || props.maxInstanceCount() < 1) {
                throw new IllegalArgumentException(
                        "Ray scene exceeds physical acceleration-structure limits");
            }
            var format = VkFormatProperties.calloc(stack);
            vkGetPhysicalDeviceFormatProperties(
                    runtime.vkDevice().getPhysicalDevice(), VK_FORMAT_R32G32B32_SFLOAT, format);
            if ((format.bufferFeatures()
                            & VK_FORMAT_FEATURE_ACCELERATION_STRUCTURE_VERTEX_BUFFER_BIT_KHR)
                    == 0) {
                throw new IllegalStateException(
                        "Ray scene vertex format unsupported by physical device");
            }
            vertices =
                    allocate(
                            (long) buildTriangles * 36,
                            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR,
                            true);
            if ((vertices.address & 3) != 0)
                throw new IllegalStateException("Unaligned ray vertex address");
            int start = input.getInt(20) * 16;
            vertices.write(
                    data -> {
                        for (int i = 0; i < triangles * 3; i++) {
                            for (int axis = 0; axis < 3; axis++)
                                data.putFloat(input.getFloat(start + i * 16 + axis * 4));
                        }
                        while (data.hasRemaining()) data.putFloat(0);
                    });
            var bottomSizes = sizes(false, stack);
            Buffer bottomStorage =
                    allocate(
                            bottomSizes.accelerationStructureSize(),
                            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR,
                            false);
            bottom = create(bottomStorage, VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR, stack);
            VeilShaderDebugNames.name(
                    runtime, VK_OBJECT_TYPE_ACCELERATION_STRUCTURE_KHR, bottom, label + "/BLAS");
            long bottomAddress =
                    vkGetAccelerationStructureDeviceAddressKHR(
                            runtime.vkDevice(),
                            VkAccelerationStructureDeviceAddressInfoKHR.calloc(stack)
                                    .sType$Default()
                                    .accelerationStructure(bottom));
            if (bottomAddress == 0)
                throw new IllegalStateException("BLAS device address unavailable");
            if (bottomOnly) {
                scratch =
                        allocate(
                                Math.addExact(bottomSizes.buildScratchSize(), alignment - 1),
                                VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
                                false);
                return;
            }
            instances =
                    allocate(
                            64,
                            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR,
                            true);
            if ((instances.address & 15) != 0)
                throw new IllegalStateException("Unaligned ray instance address");
            instances.write(
                    data -> {
                        for (int row = 0; row < 3; row++)
                            for (int col = 0; col < 4; col++) data.putFloat(row == col ? 1 : 0);
                        data.putInt((triangles == 0 ? 0 : 0xff) << 24)
                                .putInt(
                                        VK_GEOMETRY_INSTANCE_TRIANGLE_FACING_CULL_DISABLE_BIT_KHR
                                                << 24)
                                .putLong(bottomAddress);
                    });
            var topSizes = sizes(true, stack);
            Buffer topStorage =
                    allocate(
                            topSizes.accelerationStructureSize(),
                            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR,
                            false);
            top = create(topStorage, VK_ACCELERATION_STRUCTURE_TYPE_TOP_LEVEL_KHR, stack);
            VeilShaderDebugNames.name(
                    runtime, VK_OBJECT_TYPE_ACCELERATION_STRUCTURE_KHR, top, label + "/TLAS");
            scratch =
                    allocate(
                            Math.addExact(
                                    Math.max(
                                            bottomSizes.buildScratchSize(),
                                            topSizes.buildScratchSize()),
                                    alignment - 1),
                            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
                            false);
        } catch (RuntimeException | Error failure) {
            close();
            throw failure;
        }
    }

    VeilRayQueryScene(VeilVulkanRuntime runtime, java.util.List<Instance> selected, String label) {
        this.runtime = runtime;
        this.label = label;
        triangles = 0;
        buildTriangles = 1;
        topOnly = true;
        instanceCount = selected.size();
        if (instanceCount == 0) throw new IllegalArgumentException("TLAS requires instances");
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var props =
                    VkPhysicalDeviceAccelerationStructurePropertiesKHR.calloc(stack)
                            .sType$Default();
            vkGetPhysicalDeviceProperties2(
                    runtime.vkDevice().getPhysicalDevice(),
                    VkPhysicalDeviceProperties2.calloc(stack)
                            .sType$Default()
                            .pNext(props.address()));
            alignment = props.minAccelerationStructureScratchOffsetAlignment();
            if (instanceCount > props.maxInstanceCount())
                throw new IllegalArgumentException(
                        "Section count exceeds physical TLAS instance limit");
            instances =
                    allocate(
                            Math.multiplyExact(64L, instanceCount),
                            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR,
                            true);
            if ((instances.address & 15) != 0)
                throw new IllegalStateException("Unaligned ray instance address");
            instances.write(
                    data -> {
                        for (var instance : selected) {
                            if (instance.address() == 0
                                    || instance.triangleOffset() < 0
                                    || instance.triangleOffset() > 0xffffff)
                                throw new IllegalArgumentException("Invalid section ray instance");
                            for (int row = 0; row < 3; row++)
                                for (int col = 0; col < 4; col++)
                                    data.putFloat(
                                            col == 3
                                                    ? (row == 0
                                                            ? instance.x()
                                                            : row == 1
                                                                    ? instance.y()
                                                                    : instance.z())
                                                    : row == col ? 1 : 0);
                            data.putInt(instance.triangleOffset() | (0xff << 24))
                                    .putInt(
                                            VK_GEOMETRY_INSTANCE_TRIANGLE_FACING_CULL_DISABLE_BIT_KHR
                                                    << 24)
                                    .putLong(instance.address());
                        }
                    });
            var sizes = sizes(true, stack);
            var storage =
                    allocate(
                            sizes.accelerationStructureSize(),
                            VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR,
                            false);
            top = create(storage, VK_ACCELERATION_STRUCTURE_TYPE_TOP_LEVEL_KHR, stack);
            VeilShaderDebugNames.name(
                    runtime, VK_OBJECT_TYPE_ACCELERATION_STRUCTURE_KHR, top, label + "/TLAS");
            scratch =
                    allocate(
                            Math.addExact(sizes.buildScratchSize(), alignment - 1),
                            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
                            false);
        } catch (RuntimeException | Error failure) {
            close();
            throw failure;
        }
    }

    long bottomAddress() {
        if (closed || bottom == 0) throw new IllegalStateException("Section BLAS unavailable");
        try (MemoryStack stack = MemoryStack.stackPush()) {
            return vkGetAccelerationStructureDeviceAddressKHR(
                    runtime.vkDevice(),
                    VkAccelerationStructureDeviceAddressInfoKHR.calloc(stack)
                            .sType$Default()
                            .accelerationStructure(bottom));
        }
    }

    long handle() {
        return top;
    }

    long bytes() {
        return buffers.stream().mapToLong(value -> value.allocationBytes).sum();
    }

    private Buffer allocate(long size, int usage, boolean host) {
        if (size <= 0
                || size > VeilShaderLimits.current().packBytes()
                || bytes() > VeilShaderLimits.current().packBytes() - size) {
            throw new IllegalArgumentException(
                    "Ray query allocation exceeds the configured shader memory budget");
        }
        Buffer result = new Buffer(size, usage, host);
        buffers.add(result);
        VeilShaderDebugNames.name(
                runtime,
                VK_OBJECT_TYPE_BUFFER,
                result.handle,
                label + "/ray-buffer-" + buffers.size());
        if (bytes() > VeilShaderLimits.current().packBytes())
            throw new IllegalArgumentException("Ray query memory requirements exceed scene budget");
        return result;
    }

    private VkAccelerationStructureGeometryKHR.Buffer geometry(boolean tlas, MemoryStack stack) {
        var geometry = VkAccelerationStructureGeometryKHR.calloc(1, stack);
        geometry.get(0)
                .sType$Default()
                .geometryType(
                        tlas ? VK_GEOMETRY_TYPE_INSTANCES_KHR : VK_GEOMETRY_TYPE_TRIANGLES_KHR);
        if (tlas) {
            var data =
                    geometry.get(0).geometry().instances().sType$Default().arrayOfPointers(false);
            data.data().deviceAddress(instances == null ? 0 : instances.address);
        } else {
            var data =
                    geometry.get(0)
                            .geometry()
                            .triangles()
                            .sType$Default()
                            .vertexFormat(VK_FORMAT_R32G32B32_SFLOAT)
                            .vertexStride(12)
                            .maxVertex(buildTriangles * 3 - 1)
                            .indexType(VK_INDEX_TYPE_NONE_KHR);
            data.vertexData().deviceAddress(vertices.address);
        }
        return geometry;
    }

    private VkAccelerationStructureBuildGeometryInfoKHR info(boolean tlas, MemoryStack stack) {
        return VkAccelerationStructureBuildGeometryInfoKHR.calloc(stack)
                .sType$Default()
                .type(
                        tlas
                                ? VK_ACCELERATION_STRUCTURE_TYPE_TOP_LEVEL_KHR
                                : VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR)
                .flags(VK_BUILD_ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT_KHR)
                .mode(VK_BUILD_ACCELERATION_STRUCTURE_MODE_BUILD_KHR)
                .geometryCount(1)
                .pGeometries(geometry(tlas, stack));
    }

    private VkAccelerationStructureBuildSizesInfoKHR sizes(boolean tlas, MemoryStack stack) {
        var sizes = VkAccelerationStructureBuildSizesInfoKHR.calloc(stack).sType$Default();
        vkGetAccelerationStructureBuildSizesKHR(
                runtime.vkDevice(),
                VK_ACCELERATION_STRUCTURE_BUILD_TYPE_DEVICE_KHR,
                info(tlas, stack),
                stack.ints(tlas ? instanceCount : buildTriangles),
                sizes);
        return sizes;
    }

    private long create(Buffer storage, int type, MemoryStack stack) {
        var result = stack.longs(0);
        check(
                vkCreateAccelerationStructureKHR(
                        runtime.vkDevice(),
                        VkAccelerationStructureCreateInfoKHR.calloc(stack)
                                .sType$Default()
                                .buffer(storage.handle)
                                .size(storage.size)
                                .type(type),
                        null,
                        result),
                "create acceleration structure");
        return result.get(0);
    }

    void build() {
        if (built) return;
        if (closed) throw new IllegalStateException("Ray scene closed");
        var cmd = runtime.commandBuffer();
        boolean debug = VeilShaderDebugNames.begin(runtime, label + "/Build BLAS + TLAS");
        try (MemoryStack stack = MemoryStack.stackPush()) {
            barrier(
                    cmd,
                    VK_PIPELINE_STAGE_HOST_BIT,
                    VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR,
                    VK_ACCESS_HOST_WRITE_BIT,
                    VK_ACCESS_SHADER_READ_BIT,
                    stack);
            for (int level = 0; level < 2; level++) {
                boolean tlas = level == 1;
                if (tlas && bottomOnly || !tlas && topOnly) continue;
                var infos = VkAccelerationStructureBuildGeometryInfoKHR.calloc(1, stack);
                infos.get(0).set(info(tlas, stack)).dstAccelerationStructure(tlas ? top : bottom);
                long scratchAddress = (scratch.address + alignment - 1) & -alignment;
                infos.get(0).scratchData().deviceAddress(scratchAddress);
                var range = VkAccelerationStructureBuildRangeInfoKHR.calloc(1, stack);
                range.get(0).primitiveCount(tlas ? instanceCount : buildTriangles);
                vkCmdBuildAccelerationStructuresKHR(cmd, infos, stack.pointers(range.address()));
                barrier(
                        cmd,
                        VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR,
                        tlas
                                ? VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT
                                        | VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT
                                        | VK_PIPELINE_STAGE_VERTEX_SHADER_BIT
                                        | VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR
                                : VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR,
                        VK_ACCESS_ACCELERATION_STRUCTURE_WRITE_BIT_KHR
                                | VK_ACCESS_ACCELERATION_STRUCTURE_READ_BIT_KHR,
                        tlas
                                ? VK_ACCESS_ACCELERATION_STRUCTURE_READ_BIT_KHR
                                : VK_ACCESS_ACCELERATION_STRUCTURE_READ_BIT_KHR
                                        | VK_ACCESS_ACCELERATION_STRUCTURE_WRITE_BIT_KHR,
                        stack);
            }
        } finally {
            VeilShaderDebugNames.end(runtime, debug);
        }
        built = true;
    }

    private static void barrier(
            VkCommandBuffer cmd,
            int sourceStage,
            int targetStage,
            int sourceAccess,
            int targetAccess,
            MemoryStack stack) {
        var barrier = VkMemoryBarrier.calloc(1, stack);
        barrier.get(0).sType$Default().srcAccessMask(sourceAccess).dstAccessMask(targetAccess);
        vkCmdPipelineBarrier(cmd, sourceStage, targetStage, 0, barrier, null, null);
    }

    @Override
    public void close() {
        if (closed) return;
        closed = true;
        long oldTop = top, oldBottom = bottom;
        var allocations = new ArrayList<>(buffers);
        runtime.deferDestroy(
                () -> {
                    if (oldTop != 0)
                        vkDestroyAccelerationStructureKHR(runtime.vkDevice(), oldTop, null);
                    if (oldBottom != 0)
                        vkDestroyAccelerationStructureKHR(runtime.vkDevice(), oldBottom, null);
                    allocations.forEach(Buffer::destroy);
                });
        buffers.clear();
        top = bottom = 0;
    }

    private static void check(int result, String operation) {
        if (result != VK_SUCCESS)
            throw new IllegalStateException(
                    "Ray query " + operation + " failed: VkResult=" + result);
    }

    private final class Buffer {
        long handle, memory, address, allocationBytes;
        final long size;

        Buffer(long size, int usage, boolean host) {
            this.size = size;
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var output = stack.longs(0);
                check(
                        vkCreateBuffer(
                                runtime.vkDevice(),
                                VkBufferCreateInfo.calloc(stack)
                                        .sType$Default()
                                        .size(size)
                                        .usage(usage | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT)
                                        .sharingMode(VK_SHARING_MODE_EXCLUSIVE),
                                null,
                                output),
                        "create buffer");
                handle = output.get(0);
                var requirements = VkMemoryRequirements.calloc(stack);
                vkGetBufferMemoryRequirements(runtime.vkDevice(), handle, requirements);
                allocationBytes = requirements.size();
                var properties = VkPhysicalDeviceMemoryProperties.calloc(stack);
                vkGetPhysicalDeviceMemoryProperties(
                        runtime.vkDevice().getPhysicalDevice(), properties);
                int memoryType = -1,
                        required =
                                host
                                        ? VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT
                                                | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT
                                        : 0;
                for (int i = 0; i < properties.memoryTypeCount(); i++) {
                    int flags = properties.memoryTypes(i).propertyFlags();
                    if ((requirements.memoryTypeBits() & (1 << i)) != 0
                            && (flags & required) == required) {
                        memoryType = i;
                        if (host || (flags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) != 0) break;
                    }
                }
                if (memoryType < 0)
                    throw new IllegalStateException("Ray query has no compatible memory type");
                var flags =
                        VkMemoryAllocateFlagsInfo.calloc(stack)
                                .sType$Default()
                                .flags(VK_MEMORY_ALLOCATE_DEVICE_ADDRESS_BIT);
                check(
                        vkAllocateMemory(
                                runtime.vkDevice(),
                                VkMemoryAllocateInfo.calloc(stack)
                                        .sType$Default()
                                        .pNext(flags.address())
                                        .allocationSize(allocationBytes)
                                        .memoryTypeIndex(memoryType),
                                null,
                                output),
                        "allocate memory");
                memory = output.get(0);
                check(vkBindBufferMemory(runtime.vkDevice(), handle, memory, 0), "bind memory");
                address =
                        vkGetBufferDeviceAddress(
                                runtime.vkDevice(),
                                VkBufferDeviceAddressInfo.calloc(stack)
                                        .sType$Default()
                                        .buffer(handle));
                if (address == 0)
                    throw new IllegalStateException("Ray query buffer device address unavailable");
            } catch (RuntimeException | Error failure) {
                destroy();
                throw failure;
            }
        }

        void write(java.util.function.Consumer<ByteBuffer> writer) {
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var pointer = stack.mallocPointer(1);
                check(vkMapMemory(runtime.vkDevice(), memory, 0, size, 0, pointer), "map geometry");
                try {
                    writer.accept(
                            MemoryUtil.memByteBuffer(pointer.get(0), Math.toIntExact(size))
                                    .order(ByteOrder.LITTLE_ENDIAN));
                } finally {
                    vkUnmapMemory(runtime.vkDevice(), memory);
                }
            }
        }

        void destroy() {
            if (handle != 0) vkDestroyBuffer(runtime.vkDevice(), handle, null);
            if (memory != 0) vkFreeMemory(runtime.vkDevice(), memory, null);
            handle = memory = 0;
        }
    }
}
