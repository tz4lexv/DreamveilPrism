package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilRebuildBudget;
import dev.veil.revive.client.VeilVideoConfig;
import dev.veil.revive.core.CoalescedWorkKick;

import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.extract.LevelExtractor;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelExtractor.class)
public abstract class LevelExtractorRebuildBudgetMixin {
    @Shadow @Final private LevelRenderer levelRenderer;
    @Unique private SectionRenderDispatcher veil$kickDispatcher;
    @Unique private CoalescedWorkKick veil$workerKick;

    @Inject(
            method = "extract(Lnet/minecraft/client/DeltaTracker;Lnet/minecraft/client/Camera;F)V",
            at = @At("HEAD"),
            require = 0)
    private void veil$beginRebuildFrame(
            DeltaTracker deltaTracker, Camera camera, float partialTick, CallbackInfo ci) {
        if (!ReviveRuntime.optimizationsEnabled() || !VeilVideoConfig.on("renderer.rebuildBudget"))
            return;
        SectionRenderDispatcher dispatcher = levelRenderer.sectionRenderDispatcher();
        if (dispatcher == null) return;

        VeilRebuildBudget.beginFrame(dispatcher.getCompileQueueSize());

        if (!dispatcher.isQueueEmpty() && dispatcher.getFreeBufferCount() > 0) {
            var access = (SectionRenderDispatcherInvoker) (Object) dispatcher;
            if (veil$kickDispatcher != dispatcher) {
                veil$kickDispatcher = dispatcher;
                veil$workerKick = new CoalescedWorkKick(access::veil$runTask);
            }
            if (veil$workerKick.submit(access.veil$executor())) VeilRebuildBudget.recordAsyncKick();
        }
    }
}
