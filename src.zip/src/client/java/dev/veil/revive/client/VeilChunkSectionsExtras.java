package dev.veil.revive.client;

public interface VeilChunkSectionsExtras {
    void veil$setFallbackSectionFrame(VeilTerrainFrameData frameData);

    void veil$ensureHostUniforms();
}
