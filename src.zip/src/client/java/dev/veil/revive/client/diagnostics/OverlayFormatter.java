package dev.veil.revive.client.diagnostics;

import dev.veil.revive.client.VeilFaceVisibilityCache;
import dev.veil.revive.client.VeilFallbackTracker;
import dev.veil.revive.client.VeilMinecraftTerrainBridge;
import dev.veil.revive.client.VeilSharedSectionUniforms;
import dev.veil.revive.client.VeilTechniqueCounters;
import dev.veil.revive.core.RollingSampleWindow;
import dev.veil.revive.core.TerrainBridgeCounters;

import java.util.List;
import java.util.Locale;

public final class OverlayFormatter {
    private OverlayFormatter() {}

    public static void append(
            List<String> out,
            RollingSampleWindow.Snapshot interval,
            RollingSampleWindow.Snapshot render,
            VeilTechniqueCounters.Snapshot tech,
            VeilFallbackTracker.Snapshot fallback,
            VeilMinecraftTerrainBridge.Snapshot terrain,
            TerrainBridgeCounters.Snapshot terrainCounters,
            VeilFaceVisibilityCache.Snapshot faceCache,
            VeilSharedSectionUniforms.Snapshot shared) {
        double fps = interval.average() > 0.0 ? 1000.0 / interval.average() : 0.0;
        out.add(
                String.format(
                        Locale.ROOT,
                        "\u00A77Frame: %.2f ms avg | P95 %.2f | P99 %.2f | ~%.0f FPS\u00A7r",
                        interval.average(),
                        interval.p95(),
                        interval.p99(),
                        fps));
        out.add(
                String.format(
                        Locale.ROOT,
                        "\u00A77World render CPU: %.2f ms avg | P95 %.2f | P99 %.2f\u00A7r",
                        render.average(),
                        render.p95(),
                        render.p99()));
        out.add(
                String.format(
                        Locale.ROOT,
                        "\u00A77Terrain: visible %d | exact %d | SSE %d | voxel %d | VASC %d\u00A7r",
                        terrain.visibleSections(),
                        terrain.exactSections(),
                        terrain.sseSections(),
                        terrain.voxelSections(),
                        terrain.vascSections()));

        out.add(
                String.format(
                        Locale.ROOT,
                        "\u00A77Cache: %.1f%% hit | reuse %d | rebuild %d | bridge fallbacks %d\u00A7r",
                        terrainCounters.hitRate() * 100.0,
                        tech.terrainCacheReuses(),
                        tech.terrainCacheRebuilds(),
                        tech.terrainBridgeFallbacks()));

        out.add(
                String.format(
                        Locale.ROOT,
                        "\u00A77Bind elision: V %d/%d (%.1f%%) | I %d/%d (%.1f%%)\u00A7r",
                        tech.skippedVertexBinds(),
                        tech.vertexBindCalls(),
                        tech.vertexElisionRate() * 100.0,
                        tech.skippedIndexBinds(),
                        tech.indexBindCalls(),
                        tech.indexElisionRate() * 100.0));

        out.add(
                "Shared uniforms: matrix copies avoided "
                        + shared.matrixCopiesAvoided()
                        + " | records reused "
                        + shared.recordsReused());
        out.add(
                String.format(
                        Locale.ROOT,
                        "\u00A77Meshing face cache: %d hits / %d misses (%.1f%%)\u00A7r",
                        faceCache.hits(),
                        faceCache.misses(),
                        faceCache.hitRate() * 100.0));

        out.add(
                String.format(
                        Locale.ROOT,
                        "\u00A77Fallbacks: total %d | VASC dirty %d | VASC translucent %d | bridge %d | bypass %d\u00A7r",
                        fallback.total(),
                        fallback.count(VeilFallbackTracker.Reason.VASC_DIRTY),
                        fallback.count(VeilFallbackTracker.Reason.VASC_TRANSLUCENT),
                        fallback.count(VeilFallbackTracker.Reason.TERRAIN_BRIDGE_EXCEPTION),
                        fallback.count(VeilFallbackTracker.Reason.BYPASSED)));
    }
}
