package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.*;

import dev.veil.api.VeilDraw;
import dev.veil.api.VeilFormat;
import dev.veil.api.VeilResourceType;
import dev.veil.api.VeilResourceUsage;
import dev.veil.api.VeilScenePass;
import dev.veil.api.VeilTransfer;
import dev.veil.api.VeilVertexLayout;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public record VeilShaderPack(
        String name,
        int abiVersion,
        Map<String, Resource> resources,
        Map<VeilShaderId, Map<VeilShaderStage, VeilShaderId>> programs,
        Map<String, Setting> settings,
        List<Pass> passes,
        String present,
        VanillaReplacement replacesVanilla,
        Map<VeilShaderId, Map<VeilShaderStage, String>> entryPoints,
        PresentEncoding presentEncoding) {
    public static final int MAX_ABI_VERSION = 21;
    public static final VeilShaderId PRESENTER = VeilShaderId.parse("veil:runtime_present");
    private static final int MAX_DECLARED_VOLUME_DIMENSION = 16_384;

    /** Encoding of sampled present RGB; LEGACY preserves the original numeric pass-through. */
    public enum PresentEncoding {
        LEGACY,
        LINEAR_SRGB,
        DISPLAY_SRGB
    }

    public enum Source {
        OWNED,
        SCENE_COLOR,
        SCENE_DEPTH,
        SCENE_OPAQUE_COLOR,
        SCENE_OPAQUE_DEPTH,
        SCENE_MATERIAL_ID,
        SCENE_MATERIAL_DEPTH,
        HOST
    }

    public enum Lifetime {
        TRANSIENT,
        PERSISTENT,
        HISTORY
    }

    public enum InitialContent {
        UNDEFINED,
        HOST,
        ASSET,
        ZERO
    }

    public enum SampleFilter {
        NEAREST,
        LINEAR
    }

    public enum SampleAddress {
        CLAMP_TO_EDGE,
        REPEAT,
        MIRRORED_REPEAT,
        CLAMP_TO_BORDER
    }

    /** A typed Vulkan border value. Used only when an address axis clamps to border. */
    public enum SampleBorder {
        FLOAT_TRANSPARENT_BLACK,
        FLOAT_OPAQUE_BLACK,
        FLOAT_OPAQUE_WHITE,
        INT_TRANSPARENT_BLACK,
        INT_OPAQUE_BLACK,
        INT_OPAQUE_WHITE
    }

    public enum BindingAccess {
        READ,
        WRITE,
        READ_WRITE
    }

    public enum LoadOp {
        LOAD,
        CLEAR,
        DONT_CARE
    }

    public enum StoreOp {
        STORE,
        DONT_CARE
    }

    public enum CompareOp {
        NEVER,
        LESS,
        EQUAL,
        LESS_OR_EQUAL,
        GREATER,
        NOT_EQUAL,
        GREATER_OR_EQUAL,
        ALWAYS
    }

    public enum BlendFactor {
        ZERO,
        ONE,
        SRC_COLOR,
        ONE_MINUS_SRC_COLOR,
        DST_COLOR,
        ONE_MINUS_DST_COLOR,
        SRC_ALPHA,
        ONE_MINUS_SRC_ALPHA,
        DST_ALPHA,
        ONE_MINUS_DST_ALPHA
    }

    public enum BlendOp {
        ADD,
        SUBTRACT,
        REVERSE_SUBTRACT,
        MIN,
        MAX
    }

    public enum ColorChannel {
        R,
        G,
        B,
        A
    }

    public enum Topology {
        POINT_LIST,
        LINE_LIST,
        LINE_STRIP,
        TRIANGLE_LIST,
        TRIANGLE_STRIP,
        PATCH_LIST
    }

    public enum PolygonMode {
        FILL,
        LINE,
        POINT
    }

    public enum CullMode {
        NONE,
        FRONT,
        BACK,
        FRONT_AND_BACK
    }

    public enum FrontFace {
        COUNTER_CLOCKWISE,
        CLOCKWISE
    }

    public enum StencilOp {
        KEEP,
        ZERO,
        REPLACE,
        INCREMENT_CLAMP,
        DECREMENT_CLAMP,
        INVERT,
        INCREMENT_WRAP,
        DECREMENT_WRAP
    }

    public enum Geometry {
        FULLSCREEN,
        CUSTOM,
        FLUID_WATER,

        FLUID_WATER_PHYSICAL,
        FLUID_LAVA;

        public boolean fluid() {
            return water() || this == FLUID_LAVA;
        }

        public boolean water() {
            return this == FLUID_WATER || this == FLUID_WATER_PHYSICAL;
        }
    }

    public record Sampler(
            SampleFilter min,
            SampleFilter mag,
            SampleFilter mip,
            SampleAddress u,
            SampleAddress v,
            SampleAddress w,
            CompareOp compare,
            SampleBorder border,
            float minLod,
            float maxLod,
            float lodBias) {
        public Sampler {
            if (border == null) border = SampleBorder.FLOAT_TRANSPARENT_BLACK;
            dev.veil.revive.client.graphics.resources.SamplerLodRules.validate(
                    minLod, maxLod, lodBias);
        }

        public Sampler(
                SampleFilter min,
                SampleFilter mag,
                SampleFilter mip,
                SampleAddress u,
                SampleAddress v,
                SampleAddress w,
                CompareOp compare,
                SampleBorder border) {
            this(
                    min,
                    mag,
                    mip,
                    u,
                    v,
                    w,
                    compare,
                    border,
                    0.0f,
                    dev.veil.revive.client.graphics.resources.SamplerLodRules.DEFAULT_MAX_LOD,
                    0.0f);
        }

        public Sampler(
                SampleFilter min,
                SampleFilter mag,
                SampleFilter mip,
                SampleAddress u,
                SampleAddress v,
                SampleAddress w,
                CompareOp compare) {
            this(min, mag, mip, u, v, w, compare, SampleBorder.FLOAT_TRANSPARENT_BLACK);
        }

        public Sampler(
                SampleFilter min,
                SampleFilter mag,
                SampleFilter mip,
                SampleAddress u,
                SampleAddress v,
                SampleAddress w) {
            this(min, mag, mip, u, v, w, null);
        }

        public static final Sampler DEFAULT =
                new Sampler(
                        SampleFilter.NEAREST,
                        SampleFilter.NEAREST,
                        SampleFilter.NEAREST,
                        SampleAddress.CLAMP_TO_EDGE,
                        SampleAddress.CLAMP_TO_EDGE,
                        SampleAddress.CLAMP_TO_EDGE);
    }

    public record VanillaReplacement(
            boolean sky,
            boolean sun,
            boolean sunriseSunset,
            boolean water,
            boolean lava,
            boolean weather) {
        public VanillaReplacement(boolean sky, boolean sun, boolean sunriseSunset, boolean water) {
            this(sky, sun, sunriseSunset, water, false, false);
        }

        public static final VanillaReplacement NONE =
                new VanillaReplacement(false, false, false, false, false, false);
    }

    public record Resource(
            String name,
            VeilRenderGraph.Kind kind,
            long bytes,
            VeilFormat format,
            int width,
            int height,
            int depth,
            int layers,
            int mipLevels,
            float widthScale,
            float heightScale,
            String sizeFrom,
            int samples,
            Source source,
            Lifetime lifetime,
            int historyCount,
            String host,
            VeilResourceType type,
            Set<VeilResourceUsage> usages,
            VeilShaderId asset,
            Sampler sampler,
            InitialContent initialization) {
        private static final Set<VeilResourceUsage> IMAGE_USAGES =
                Set.of(
                        VeilResourceUsage.SAMPLED,
                        VeilResourceUsage.STORAGE,
                        VeilResourceUsage.COLOR_ATTACHMENT,
                        VeilResourceUsage.DEPTH_ATTACHMENT,
                        VeilResourceUsage.TRANSFER_SOURCE,
                        VeilResourceUsage.TRANSFER_DESTINATION);
        private static final Set<VeilResourceUsage> BUFFER_USAGES =
                Set.of(
                        VeilResourceUsage.STORAGE,
                        VeilResourceUsage.UNIFORM,
                        VeilResourceUsage.VERTEX,
                        VeilResourceUsage.INDEX,
                        VeilResourceUsage.INDIRECT,
                        VeilResourceUsage.TRANSFER_SOURCE,
                        VeilResourceUsage.TRANSFER_DESTINATION);

        public Resource {
            sampler = sampler == null ? Sampler.DEFAULT : sampler;
            lifetime = lifetime == null ? Lifetime.TRANSIENT : lifetime;
            usages = Set.copyOf(usages);
            Objects.requireNonNull(type, "type");
            if (sampler.compare() != null) {
                boolean depthImage =
                        source == Source.OWNED
                                ? format != null && format.depth()
                                : source == Source.SCENE_DEPTH
                                        || source == Source.SCENE_OPAQUE_DEPTH
                                        || source == Source.SCENE_MATERIAL_DEPTH
                                        || source == Source.HOST
                                                && host != null
                                                && Set.of(
                                                                VeilHostResourceRegistry
                                                                        .SCENE_DEPTH,
                                                                VeilHostResourceRegistry
                                                                        .SCENE_OPAQUE_DEPTH,
                                                                VeilHostResourceRegistry
                                                                        .SCENE_MATERIAL_DEPTH)
                                                        .contains(host);
                if (kind != VeilRenderGraph.Kind.IMAGE
                        || !depthImage
                        || samples != 1
                        || !usages.contains(VeilResourceUsage.SAMPLED))
                    throw new IllegalArgumentException(
                            "Comparison sampler requires a sampled single-sample depth image: "
                                    + name);
            }
            if (usages.isEmpty())
                throw new IllegalArgumentException("Resource requires at least one usage: " + name);
            if (historyCount < 1
                    || historyCount > 8
                    || lifetime == Lifetime.HISTORY && historyCount < 2
                    || lifetime != Lifetime.HISTORY && historyCount != 1) {
                throw new IllegalArgumentException("Invalid history count for " + name);
            }
            if (source == Source.OWNED && host != null)
                throw new IllegalArgumentException(
                        "Owned resource cannot declare a host ID: " + name);
            if (source == Source.HOST) {
                if (host == null || host.isBlank())
                    throw new IllegalArgumentException("Host resource ID is blank: " + name);
                var definition = VeilHostResourceRegistry.definition(host);
                if (definition.kind() != kind
                        || definition.type() != type
                        || !definition.usages().equals(usages)) {
                    throw new IllegalArgumentException(
                            "Host resource descriptor mismatch for " + name + ": " + host);
                }
            }
            if (source != Source.OWNED) {
                if (lifetime != Lifetime.TRANSIENT
                        || historyCount != 1
                        || bytes != 0
                        || format != null
                        || width != 0
                        || height != 0
                        || depth != 1
                        || layers != 1
                        || mipLevels != 1
                        || widthScale != 1
                        || heightScale != 1
                        || sizeFrom != null
                        || samples != 1
                        || asset != null
                        || initialization != null) {
                    throw new IllegalArgumentException(
                            "Imported resource must not declare creator-owned fields: " + name);
                }
                if (kind == VeilRenderGraph.Kind.IMAGE
                        && !usages.contains(VeilResourceUsage.SAMPLED)) {
                    throw new IllegalArgumentException(
                            "Imported image must be sampleable: " + name);
                }
                if ((source == Source.SCENE_DEPTH
                                || source == Source.SCENE_OPAQUE_DEPTH
                                || source == Source.SCENE_MATERIAL_ID
                                || source == Source.SCENE_MATERIAL_DEPTH
                                || source == Source.HOST
                                        && VeilHostResourceRegistry.definition(host).nearestOnly())
                        && sampler.compare() == null
                        && (sampler.min() == SampleFilter.LINEAR
                                || sampler.mag() == SampleFilter.LINEAR
                                || sampler.mip() == SampleFilter.LINEAR)) {
                    throw new IllegalArgumentException(
                            "Depth and material-ID imports require nearest filtering: " + name);
                }
            } else if (kind == VeilRenderGraph.Kind.BUFFER) {
                if (type != VeilResourceType.BUFFER || !BUFFER_USAGES.containsAll(usages)) {
                    throw new IllegalArgumentException("Invalid buffer type or usage: " + name);
                }
                if (bytes <= 0
                        || bytes > VeilShaderLimits.current().bufferBytes()
                        || (bytes & 3) != 0) {
                    throw new IllegalArgumentException(
                            "Buffer "
                                    + name
                                    + " requires 4-byte aligned size within the configured shader buffer budget");
                }
                if (format != null
                        || width != 0
                        || height != 0
                        || depth != 1
                        || layers != 1
                        || mipLevels != 1
                        || widthScale != 1
                        || heightScale != 1
                        || sizeFrom != null
                        || samples != 1) {
                    throw new IllegalArgumentException(
                            "Buffer contains image-only fields: " + name);
                }
            } else {
                if (type == VeilResourceType.BUFFER || !IMAGE_USAGES.containsAll(usages)) {
                    throw new IllegalArgumentException("Invalid image type or usage: " + name);
                }
                if (format == null)
                    throw new IllegalArgumentException("Owned image requires a format: " + name);
                if (format.depth() || format.stencil()) {
                    if (!format.depth()
                            || usages.contains(VeilResourceUsage.COLOR_ATTACHMENT)
                            || usages.contains(VeilResourceUsage.STORAGE)) {
                        throw new IllegalArgumentException(
                                "Depth/stencil formats cannot be color/storage images: " + name);
                    }
                } else if (usages.contains(VeilResourceUsage.DEPTH_ATTACHMENT)) {
                    throw new IllegalArgumentException(
                            "Depth attachment requires a depth format: " + name);
                }
                if (usages.contains(VeilResourceUsage.COLOR_ATTACHMENT) && !format.color()) {
                    throw new IllegalArgumentException(
                            "Color attachment requires a color format: " + name);
                }
                if (usages.contains(VeilResourceUsage.STORAGE) && !format.storageCandidate()) {
                    throw new IllegalArgumentException(
                            "Format cannot be a storage image: " + format);
                }
                if ((lifetime == Lifetime.PERSISTENT || lifetime == Lifetime.HISTORY)
                        && !usages.contains(VeilResourceUsage.TRANSFER_DESTINATION)) {
                    throw new IllegalArgumentException(
                            "Persistent/history images require transfer-destination usage for deterministic initialization: "
                                    + name);
                }
                if (samples != 1 && samples != 2 && samples != 4 && samples != 8 && samples != 16) {
                    throw new IllegalArgumentException(
                            "Image samples must be 1, 2, 4, 8 or 16: " + name);
                }
                if (samples > 1
                        && (mipLevels != 1
                                || usages.contains(VeilResourceUsage.STORAGE)
                                || asset != null)) {
                    throw new IllegalArgumentException(
                            "Multisampled images cannot use mip chains, storage usage or assets: "
                                    + name);
                }
                if (mipLevels < 1)
                    throw new IllegalArgumentException("Image mipLevels must be >= 1: " + name);
                if (type == VeilResourceType.TEXTURE_3D) {
                    if (layers != 1
                            || width < 1
                            || height < 1
                            || depth < 1
                            || width > MAX_DECLARED_VOLUME_DIMENSION
                            || height > MAX_DECLARED_VOLUME_DIMENSION
                            || depth > MAX_DECLARED_VOLUME_DIMENSION
                            || widthScale != 1
                            || heightScale != 1
                            || sizeFrom != null
                            || samples != 1) {
                        throw new IllegalArgumentException(
                                "Invalid fixed 3D descriptor for " + name);
                    }
                    if (usages.contains(VeilResourceUsage.COLOR_ATTACHMENT)
                            || usages.contains(VeilResourceUsage.DEPTH_ATTACHMENT)) {
                        throw new IllegalArgumentException(
                                "3D images cannot be graphics attachments: " + name);
                    }
                } else if (type == VeilResourceType.TEXTURE_1D
                        || type == VeilResourceType.TEXTURE_1D_ARRAY) {
                    if (height != 1
                            || depth != 1
                            || samples != 1
                            || layers < 1
                            || type == VeilResourceType.TEXTURE_1D && layers != 1
                            || width < 0
                            || heightScale != 1
                            || !Float.isFinite(widthScale)
                            || widthScale <= 0
                            || sizeFrom != null && (width != 0 || widthScale != 1))
                        throw new IllegalArgumentException("Invalid 1D image descriptor: " + name);
                } else {
                    if (depth != 1)
                        throw new IllegalArgumentException("2D images must use depth=1: " + name);
                    if (type == VeilResourceType.TEXTURE_2D && layers != 1)
                        throw new IllegalArgumentException("2D images require layers=1: " + name);
                    if (type == VeilResourceType.TEXTURE_2D_ARRAY
                            && (layers < 1 || layers > 2048)) {
                        throw new IllegalArgumentException(
                                "2D array layers must be within 1..2048: " + name);
                    }
                    if (type == VeilResourceType.CUBEMAP && layers != 6)
                        throw new IllegalArgumentException("Cubemaps require six layers: " + name);
                    if (type == VeilResourceType.CUBEMAP_ARRAY && (layers < 6 || layers % 6 != 0))
                        throw new IllegalArgumentException(
                                "Cubemap arrays require a positive multiple of six layers: "
                                        + name);
                    if ((type == VeilResourceType.CUBEMAP || type == VeilResourceType.CUBEMAP_ARRAY)
                            && samples != 1)
                        throw new IllegalArgumentException("Cubemaps require one sample: " + name);
                    boolean derived = sizeFrom != null;
                    boolean fixed = width > 0 || height > 0;
                    if (derived && (fixed || widthScale != 1 || heightScale != 1)) {
                        throw new IllegalArgumentException(
                                "Derived image dimensions cannot also be fixed or scaled: " + name);
                    }
                    if (!derived
                            && fixed
                            && (width < 1 || height < 1 || width > 16384 || height > 16384)) {
                        throw new IllegalArgumentException(
                                "Invalid fixed image dimensions: " + name);
                    }
                    if (!derived
                            && !fixed
                            && (!Float.isFinite(widthScale)
                                    || !Float.isFinite(heightScale)
                                    || widthScale <= 0
                                    || heightScale <= 0
                                    || widthScale > 4
                                    || heightScale > 4)) {
                        throw new IllegalArgumentException(
                                "Invalid framebuffer-relative image dimensions: " + name);
                    }
                    if ((width == 0) != (height == 0))
                        throw new IllegalArgumentException(
                                "Image width and height must both be fixed or relative: " + name);
                }
                if (asset != null) {
                    if (width < 1
                            || height < 1
                            || !usages.contains(VeilResourceUsage.TRANSFER_DESTINATION)
                            || format.depth()
                            || format.stencil()
                            || samples != 1) {
                        throw new IllegalArgumentException(
                                "Image assets require fixed single-sample color dimensions and transfer-destination usage: "
                                        + name);
                    }
                    int maxMips = maxMipLevels(width, height, image3d() ? depth : 1);
                    if (mipLevels > maxMips)
                        throw new IllegalArgumentException(
                                "Image asset mip chain exceeds its dimensions: " + name);
                }
                if (initialization != null) {
                    if (asset != null
                            || initialization == InitialContent.ASSET
                            || initialization == InitialContent.HOST) {
                        throw new IllegalArgumentException(
                                "Explicit initialization must be zero or undefined: " + name);
                    }
                    if (initialization == InitialContent.ZERO
                            && kind == VeilRenderGraph.Kind.IMAGE
                            && !usages.contains(VeilResourceUsage.TRANSFER_DESTINATION)) {
                        throw new IllegalArgumentException(
                                "Zero-initialized image requires transfer-destination usage: "
                                        + name);
                    }
                }
            }
        }

        public boolean image3d() {
            return type == VeilResourceType.TEXTURE_3D;
        }

        public boolean image2d() {
            return type == VeilResourceType.TEXTURE_2D;
        }

        public boolean image1d() {
            return type == VeilResourceType.TEXTURE_1D || image1dArray();
        }

        public boolean image1dArray() {
            return type == VeilResourceType.TEXTURE_1D_ARRAY;
        }

        public boolean image2dArray() {
            return type == VeilResourceType.TEXTURE_2D_ARRAY;
        }

        public boolean cubemap() {
            return type == VeilResourceType.CUBEMAP || cubeArray();
        }

        public boolean cubeArray() {
            return type == VeilResourceType.CUBEMAP_ARRAY;
        }

        public boolean hostImport() {
            return source != Source.OWNED;
        }

        public String hostId() {
            return source == Source.HOST ? host : VeilHostResourceRegistry.legacyId(source);
        }

        public boolean history() {
            return lifetime == Lifetime.HISTORY;
        }

        public boolean persistent() {
            return lifetime == Lifetime.PERSISTENT;
        }

        public boolean transientResource() {
            return lifetime == Lifetime.TRANSIENT;
        }

        public boolean renderTarget() {
            return usages.contains(VeilResourceUsage.COLOR_ATTACHMENT);
        }

        public boolean depthTarget() {
            return usages.contains(VeilResourceUsage.DEPTH_ATTACHMENT);
        }

        public boolean sampled() {
            return usages.contains(VeilResourceUsage.SAMPLED);
        }

        public boolean sampledAsset() {
            return sampled() && asset != null && !storageImage();
        }

        public boolean storageImage() {
            return kind == VeilRenderGraph.Kind.IMAGE && usages.contains(VeilResourceUsage.STORAGE);
        }

        public boolean nativeImage() {
            if (kind != VeilRenderGraph.Kind.IMAGE || source != Source.OWNED) return false;
            return !image2d()
                    || format != null && format.depth()
                    || depthTarget()
                    || storageImage()
                    || initializedAsset()
                    || mipLevels != 1
                    || (!sampled() && !renderTarget() && !depthTarget())
                    || samples != 1
                    || format == VeilFormat.RGBA8_SRGB;
        }

        public boolean initializedAsset() {
            return kind == VeilRenderGraph.Kind.IMAGE && source == Source.OWNED && asset != null;
        }

        public boolean initializedBufferAsset() {
            return kind == VeilRenderGraph.Kind.BUFFER && source == Source.OWNED && asset != null;
        }

        public InitialContent initialContent() {
            if (hostImport()) return InitialContent.HOST;
            if (initializedAsset() || initializedBufferAsset()) return InitialContent.ASSET;
            if (initialization != null) return initialization;
            if (kind == VeilRenderGraph.Kind.BUFFER || persistent() || history())
                return InitialContent.ZERO;
            return InitialContent.UNDEFINED;
        }

        public boolean raySceneAsset() {
            return initializedBufferAsset() && asset.path().endsWith(".veilrt.json");
        }

        public boolean worldRayScene() {
            return hostImport() && VeilWorldRayScene.HOST_ID.equals(hostId());
        }

        public boolean ktx2Asset() {
            return initializedAsset()
                    && asset.path().toLowerCase(java.util.Locale.ROOT).endsWith(".ktx2");
        }

        public boolean requiresExtendedStorageFormats() {
            if (!storageImage()) return false;
            return switch (format.name()) {
                case "RGBA32_FLOAT",
                        "RGBA16_FLOAT",
                        "R32_FLOAT",
                        "RGBA8_UNORM",
                        "RGBA8_SNORM",
                        "RGBA32_SINT",
                        "RGBA16_SINT",
                        "RGBA8_SINT",
                        "R32_SINT",
                        "RGBA32_UINT",
                        "RGBA16_UINT",
                        "RGBA8_UINT",
                        "R32_UINT" ->
                        false;
                default -> true;
            };
        }

        public int resolvedWidth(int viewport, Map<String, Resource> resources) {
            if (sizeFrom != null)
                return derived(sizeFrom, resources).resolvedWidth(viewport, resources);
            return width == 0
                    ? Math.max(1, (int) Math.ceil(viewport * (double) widthScale))
                    : width;
        }

        public int resolvedHeight(int viewport, Map<String, Resource> resources) {
            if (image1d()) return 1;
            if (sizeFrom != null)
                return derived(sizeFrom, resources).resolvedHeight(viewport, resources);
            return height == 0
                    ? Math.max(1, (int) Math.ceil(viewport * (double) heightScale))
                    : height;
        }

        public int resolvedWidth(int viewport) {
            return resolvedWidth(viewport, Map.of());
        }

        public int resolvedHeight(int viewport) {
            return resolvedHeight(viewport, Map.of());
        }

        public int resolvedDepth() {
            return image3d() ? depth : 1;
        }

        public int dispatchDepth() {
            return image3d() ? depth : image1dArray() || image2dArray() || cubemap() ? layers : 1;
        }

        public long expectedAssetBytes() {
            if (asset == null) return 0;
            long totalTexels = 0;
            for (int level = 0; level < mipLevels; level++) {
                int w = Math.max(1, width >> level);
                int h = Math.max(1, height >> level);
                int slices = image3d() ? Math.max(1, depth >> level) : layers;
                totalTexels =
                        Math.addExact(
                                totalTexels,
                                Math.multiplyExact(Math.multiplyExact((long) w, h), slices));
            }
            return Math.multiplyExact(totalTexels, bytesPerTexel(format));
        }

        public long resolvedBytes(
                int viewportWidth, int viewportHeight, Map<String, Resource> resources) {
            int w0 = resolvedWidth(viewportWidth, resources);
            int h0 = resolvedHeight(viewportHeight, resources);
            long totalTexels = 0;
            for (int level = 0; level < mipLevels; level++) {
                int w = Math.max(1, w0 >> level);
                int h = Math.max(1, h0 >> level);
                int slices = image3d() ? Math.max(1, depth >> level) : layers;
                totalTexels =
                        Math.addExact(
                                totalTexels,
                                Math.multiplyExact(Math.multiplyExact((long) w, h), slices));
            }
            return Math.multiplyExact(
                    Math.multiplyExact(totalTexels, bytesPerTexel(format)), samples);
        }

        public long resolvedBytes(int viewportWidth, int viewportHeight) {
            return resolvedBytes(viewportWidth, viewportHeight, Map.of());
        }

        private Resource derived(String id, Map<String, Resource> resources) {
            Resource resource = resources.get(id);
            if (resource == null
                    || resource == this
                    || resource.kind() != VeilRenderGraph.Kind.IMAGE) {
                throw new IllegalArgumentException(
                        "Invalid derived image resource " + id + " for " + name);
            }
            return resource;
        }

        private static int maxMipLevels(int width, int height, int depth) {
            int extent = Math.max(width, Math.max(height, depth));
            return 32 - Integer.numberOfLeadingZeros(extent);
        }

        public static int bytesPerTexel(VeilFormat format) {
            if (format == null) throw new IllegalArgumentException("Missing image format");
            return format.bytesPerTexel();
        }
    }

    public record Setting(String type, String value, List<String> options) {
        public Setting {
            options = List.copyOf(options);
            switch (type) {
                case "bool" -> {
                    if (!value.equals("true") && !value.equals("false"))
                        throw new IllegalArgumentException("Invalid bool setting: " + value);
                }
                case "int" -> Integer.parseInt(value);
                case "float" -> {
                    if (!Float.isFinite(Float.parseFloat(value)))
                        throw new IllegalArgumentException("Nonfinite float setting");
                }
                case "enum" -> {
                    if (options.isEmpty()
                            || new LinkedHashSet<>(options).size() != options.size()
                            || !options.contains(value)) {
                        throw new IllegalArgumentException("Invalid enum setting: " + value);
                    }
                }
                default -> throw new IllegalArgumentException("Unsupported setting type: " + type);
            }
        }

        public VeilSpecializationValues.Value specialization() {
            return switch (type) {
                case "bool" -> VeilSpecializationValues.Value.bool(Boolean.parseBoolean(value));
                case "int" -> VeilSpecializationValues.Value.integer(Integer.parseInt(value));
                case "float" -> VeilSpecializationValues.Value.floating(Float.parseFloat(value));
                case "enum" -> VeilSpecializationValues.Value.integer(options.indexOf(value));
                default -> throw new IllegalStateException(type);
            };
        }
    }

    public record Binding(
            List<String> resources,
            BindingAccess access,
            int historyOffset,
            int mip,
            int baseLayer,
            int layerCount,
            long offset,
            long range) {
        public Binding(
                List<String> resources,
                BindingAccess access,
                int historyOffset,
                int mip,
                int baseLayer,
                int layerCount) {
            this(resources, access, historyOffset, mip, baseLayer, layerCount, 0, 0);
        }

        public Binding {
            resources = List.copyOf(resources);
            Objects.requireNonNull(access, "access");
            if (resources.isEmpty() || resources.size() > VeilShaderLimits.current().resources())
                throw new IllegalArgumentException("Binding requires 1..32 resources");
            if (new LinkedHashSet<>(resources).size() != resources.size())
                throw new IllegalArgumentException(
                        "Binding descriptor array contains duplicate resources");
            if (historyOffset < 0 || historyOffset > 7)
                throw new IllegalArgumentException("Binding historyOffset must be 0..7");
            if (mip < -1 || baseLayer < 0 || layerCount < 0)
                throw new IllegalArgumentException("Invalid image subresource selector");
            if (offset < 0 || range < 0 || range > Long.MAX_VALUE - offset)
                throw new IllegalArgumentException("Invalid buffer offset/range");
        }

        public long resolvedBufferRange(long bytes) {
            if (offset >= bytes || (range != 0 && range > bytes - offset))
                throw new IllegalArgumentException(
                        "Buffer binding offset/range exceeds buffer size=" + bytes);
            return range == 0 ? bytes - offset : range;
        }

        public String resource() {
            return resources.getFirst();
        }

        public boolean array() {
            return resources.size() > 1;
        }

        public boolean reads() {
            return access == BindingAccess.READ || access == BindingAccess.READ_WRITE;
        }

        public boolean writes() {
            return access == BindingAccess.WRITE || access == BindingAccess.READ_WRITE;
        }

        public boolean previous() {
            return historyOffset > 0;
        }

        public String graphResource(String resource) {
            return historyOffset == 0 ? resource : resource + "#history:" + historyOffset;
        }

        public String graphResource() {
            return graphResource(resource());
        }

        public int selectedMip(boolean storageDescriptor) {
            return mip >= 0 ? mip : storageDescriptor ? 0 : -1;
        }
    }

    /** Typed Vulkan color attachment clear. Legacy four-float values remain compatible. */
    public record ClearColor(
            float r,
            float g,
            float b,
            float a,
            VeilTransfer.ClearColorType colorType,
            int c0,
            int c1,
            int c2,
            int c3) {
        public ClearColor(float r, float g, float b, float a) {
            this(r, g, b, a, VeilTransfer.ClearColorType.FLOAT, 0, 0, 0, 0);
        }

        public static ClearColor signed(int r, int g, int b, int a) {
            return new ClearColor(0, 0, 0, 0, VeilTransfer.ClearColorType.SINT, r, g, b, a);
        }

        /** Unsigned channels are raw 32-bit values, preserving 0xffffffff. */
        public static ClearColor unsigned(int r, int g, int b, int a) {
            return new ClearColor(0, 0, 0, 0, VeilTransfer.ClearColorType.UINT, r, g, b, a);
        }

        public ClearColor {
            Objects.requireNonNull(colorType, "colorType");
            if (!Float.isFinite(r)
                    || !Float.isFinite(g)
                    || !Float.isFinite(b)
                    || !Float.isFinite(a)) {
                throw new IllegalArgumentException("Attachment clear color must be finite");
            }
        }
    }

    public record BlendState(
            boolean enabled,
            BlendFactor srcColor,
            BlendFactor dstColor,
            BlendOp colorOp,
            BlendFactor srcAlpha,
            BlendFactor dstAlpha,
            BlendOp alphaOp) {
        public static final BlendState DISABLED =
                new BlendState(
                        false,
                        BlendFactor.ONE,
                        BlendFactor.ZERO,
                        BlendOp.ADD,
                        BlendFactor.ONE,
                        BlendFactor.ZERO,
                        BlendOp.ADD);

        public BlendState {
            Objects.requireNonNull(srcColor, "srcColor");
            Objects.requireNonNull(dstColor, "dstColor");
            Objects.requireNonNull(colorOp, "colorOp");
            Objects.requireNonNull(srcAlpha, "srcAlpha");
            Objects.requireNonNull(dstAlpha, "dstAlpha");
            Objects.requireNonNull(alphaOp, "alphaOp");
        }
    }

    public record RasterState(
            PolygonMode polygonMode,
            CullMode cullMode,
            FrontFace frontFace,
            boolean depthClamp,
            boolean rasterizerDiscard,
            boolean depthBias,
            float depthBiasConstant,
            float depthBiasClamp,
            float depthBiasSlope,
            float lineWidth) {
        public static final RasterState DEFAULT =
                new RasterState(
                        PolygonMode.FILL,
                        CullMode.NONE,
                        FrontFace.COUNTER_CLOCKWISE,
                        false,
                        false,
                        false,
                        0,
                        0,
                        0,
                        1);

        public RasterState {
            Objects.requireNonNull(polygonMode, "polygonMode");
            Objects.requireNonNull(cullMode, "cullMode");
            Objects.requireNonNull(frontFace, "frontFace");
            if (!Float.isFinite(depthBiasConstant)
                    || !Float.isFinite(depthBiasClamp)
                    || !Float.isFinite(depthBiasSlope)
                    || !Float.isFinite(lineWidth)
                    || lineWidth <= 0) {
                throw new IllegalArgumentException("Invalid raster state");
            }
        }
    }

    public record StencilFace(
            CompareOp compare,
            StencilOp fail,
            StencilOp pass,
            StencilOp depthFail,
            int compareMask,
            int writeMask,
            int reference) {
        public static final StencilFace DEFAULT =
                new StencilFace(
                        CompareOp.ALWAYS,
                        StencilOp.KEEP,
                        StencilOp.KEEP,
                        StencilOp.KEEP,
                        -1,
                        -1,
                        0);

        public StencilFace {
            Objects.requireNonNull(compare, "compare");
            Objects.requireNonNull(fail, "fail");
            Objects.requireNonNull(pass, "pass");
            Objects.requireNonNull(depthFail, "depthFail");
        }
    }

    public record StencilState(boolean enabled, StencilFace front, StencilFace back) {
        public static final StencilState DISABLED =
                new StencilState(false, StencilFace.DEFAULT, StencilFace.DEFAULT);

        public StencilState {
            front = front == null ? StencilFace.DEFAULT : front;
            back = back == null ? front : back;
        }
    }

    public record PipelineState(
            Topology topology,
            RasterState raster,
            StencilState stencil,
            int patchControlPoints,
            boolean primitiveRestart) {
        public static final PipelineState DEFAULT =
                new PipelineState(
                        Topology.TRIANGLE_LIST, RasterState.DEFAULT, StencilState.DISABLED, 3);

        /** Backwards-compatible constructor for existing pipeline declarations. */
        public PipelineState(
                Topology topology,
                RasterState raster,
                StencilState stencil,
                int patchControlPoints) {
            this(topology, raster, stencil, patchControlPoints, false);
        }

        public PipelineState {
            topology = topology == null ? Topology.TRIANGLE_LIST : topology;
            raster = raster == null ? RasterState.DEFAULT : raster;
            stencil = stencil == null ? StencilState.DISABLED : stencil;
            if (patchControlPoints < 1 || patchControlPoints > 32)
                throw new IllegalArgumentException("patchControlPoints must be within 1..32");
            if (primitiveRestart
                    && topology != Topology.LINE_STRIP
                    && topology != Topology.TRIANGLE_STRIP) {
                throw new IllegalArgumentException(
                        "primitiveRestart requires lineStrip or triangleStrip topology");
            }
        }
    }

    public record ColorAttachment(
            String resource,
            int mip,
            int layer,
            LoadOp load,
            StoreOp store,
            ClearColor clear,
            BlendState blend,
            Set<ColorChannel> writeMask) {
        public ColorAttachment {
            resource = VeilShaderPackRules.resourceName(resource);
            if (mip < 0 || layer < 0)
                throw new IllegalArgumentException(
                        "Invalid color attachment subresource: " + resource);
            Objects.requireNonNull(load, "load");
            Objects.requireNonNull(store, "store");
            blend = blend == null ? BlendState.DISABLED : blend;
            writeMask = Set.copyOf(writeMask);
            if (load == LoadOp.CLEAR && clear == null || load != LoadOp.CLEAR && clear != null) {
                throw new IllegalArgumentException(
                        "Color clear value must match load=clear: " + resource);
            }
        }
    }

    public record DepthAttachment(
            String resource,
            int mip,
            int layer,
            LoadOp load,
            StoreOp store,
            float clearDepth,
            int clearStencil,
            boolean test,
            boolean write,
            CompareOp compare) {
        public DepthAttachment {
            resource = VeilShaderPackRules.resourceName(resource);
            if (mip < 0
                    || layer < 0
                    || !Float.isFinite(clearDepth)
                    || clearDepth < 0
                    || clearDepth > 1
                    || clearStencil < 0) {
                throw new IllegalArgumentException("Invalid depth attachment state: " + resource);
            }
            Objects.requireNonNull(load, "load");
            Objects.requireNonNull(store, "store");
            Objects.requireNonNull(compare, "compare");
            if (write && !test)
                throw new IllegalArgumentException(
                        "Depth writes require depth testing: " + resource);
        }

        public VeilRenderGraph.Access access() {
            return write
                    ? VeilRenderGraph.Access.DEPTH_READ_WRITE
                    : VeilRenderGraph.Access.DEPTH_READ;
        }
    }

    public record Dispatch(
            int x,
            int y,
            int z,
            String resource,
            int mip,
            int localX,
            int localY,
            int localZ,
            String indirectResource,
            long indirectOffset) {
        public Dispatch {
            boolean relative = resource != null;
            boolean indirect = indirectResource != null;
            if (relative && indirect)
                throw new IllegalArgumentException(
                        "Dispatch cannot be both resource-relative and indirect");
            if (!relative && !indirect) {
                if (x < 1 || y < 1 || z < 1 || x > 65535 || y > 65535 || z > 65535) {
                    throw new IllegalArgumentException("Dispatch groups must be within 1..65535");
                }
                if (mip != 0 || localX != 0 || localY != 0 || localZ != 0 || indirectOffset != 0) {
                    throw new IllegalArgumentException(
                            "Fixed dispatch cannot declare mip/local size/indirect offset");
                }
            } else if (relative) {
                if (resource.isBlank()
                        || x != 0
                        || y != 0
                        || z != 0
                        || mip < 0
                        || localX < 1
                        || localY < 1
                        || localZ < 1
                        || localX > 65535
                        || localY > 65535
                        || localZ > 65535
                        || indirectOffset != 0) {
                    throw new IllegalArgumentException(
                            "Resource dispatch requires a valid resource/mip and positive local size; live device limits apply");
                }
            } else {
                if (indirectResource.isBlank()
                        || x != 0
                        || y != 0
                        || z != 0
                        || mip != 0
                        || localX != 0
                        || localY != 0
                        || localZ != 0
                        || indirectOffset < 0
                        || (indirectOffset & 3L) != 0) {
                    throw new IllegalArgumentException(
                            "Indirect dispatch requires an indirect buffer and a non-negative 4-byte-aligned offset");
                }
            }
        }

        public static Dispatch fixed(int x, int y, int z) {
            return new Dispatch(x, y, z, null, 0, 0, 0, 0, null, 0);
        }

        public static Dispatch resource(
                String resource, int mip, int localX, int localY, int localZ) {
            return new Dispatch(0, 0, 0, resource, mip, localX, localY, localZ, null, 0);
        }

        public static Dispatch indirect(String resource, long offset) {
            return new Dispatch(0, 0, 0, null, 0, 0, 0, 0, resource, offset);
        }

        public boolean dynamic() {
            return resource != null;
        }

        public boolean indirect() {
            return indirectResource != null;
        }

        public boolean fixed() {
            return !dynamic() && !indirect();
        }

        public int[] resolve(
                Map<String, Resource> resources, int viewportWidth, int viewportHeight) {
            if (indirect())
                throw new IllegalStateException("Indirect dispatch group counts are GPU-provided");
            if (!dynamic()) return new int[] {x, y, z};
            Resource definition = resources.get(resource);
            if (definition == null
                    || definition.kind() != VeilRenderGraph.Kind.IMAGE
                    || definition.source() != Source.OWNED) {
                throw new IllegalArgumentException(
                        "Dispatch resource must be an owned image: " + resource);
            }
            if (mip >= definition.mipLevels())
                throw new IllegalArgumentException(
                        "Dispatch mip exceeds resource mip chain: " + resource + " mip=" + mip);
            int dispatchWidth =
                    Math.max(1, definition.resolvedWidth(viewportWidth, resources) >> mip);
            int dispatchHeight =
                    Math.max(1, definition.resolvedHeight(viewportHeight, resources) >> mip);
            int dispatchDepth =
                    definition.image3d()
                            ? Math.max(1, definition.resolvedDepth() >> mip)
                            : definition.dispatchDepth();
            int gx = ceilDiv(dispatchWidth, localX);
            int gy = ceilDiv(dispatchHeight, localY);
            int gz = ceilDiv(dispatchDepth, localZ);
            if (gx < 1 || gy < 1 || gz < 1 || gx > 65535 || gy > 65535 || gz > 65535) {
                throw new IllegalArgumentException(
                        "Resolved dispatch groups exceed Vulkan baseline for resource "
                                + resource
                                + " mip="
                                + mip
                                + ": "
                                + gx
                                + "x"
                                + gy
                                + "x"
                                + gz);
            }
            return new int[] {gx, gy, gz};
        }

        private static int ceilDiv(int value, int divisor) {
            return (value + divisor - 1) / divisor;
        }
    }

    public record Trace(int width, int height, int depth, String resource, int mip) {
        public Trace {
            if (resource == null) {
                if (width < 1 || height < 1 || depth < 1)
                    throw new IllegalArgumentException("Ray trace dimensions must be positive");
            } else if (width != 0 || height != 0 || depth != 0 || mip < 0) {
                throw new IllegalArgumentException(
                        "Resource ray trace cannot also declare fixed dimensions");
            }
        }

        public static Trace fixed(int width, int height, int depth) {
            return new Trace(width, height, depth, null, 0);
        }

        public static Trace resource(String resource, int mip) {
            return new Trace(0, 0, 0, resource, mip);
        }

        public boolean dynamic() {
            return resource != null;
        }

        public int[] resolve(
                Map<String, Resource> resources, int viewportWidth, int viewportHeight) {
            if (!dynamic()) return new int[] {width, height, depth};
            Resource definition = resources.get(resource);
            if (definition == null
                    || definition.kind() != VeilRenderGraph.Kind.IMAGE
                    || definition.source() != Source.OWNED) {
                throw new IllegalArgumentException(
                        "Ray trace resource must be an owned image: " + resource);
            }
            if (mip >= definition.mipLevels())
                throw new IllegalArgumentException(
                        "Ray trace mip exceeds resource mip chain: " + resource);
            return new int[] {
                Math.max(1, definition.resolvedWidth(viewportWidth, resources) >> mip),
                Math.max(1, definition.resolvedHeight(viewportHeight, resources) >> mip),
                definition.image3d()
                        ? Math.max(1, definition.resolvedDepth() >> mip)
                        : definition.dispatchDepth()
            };
        }
    }

    public record Pass(
            String name,
            VeilShaderId program,
            boolean compute,
            boolean raytrace,
            boolean transfer,
            VeilScenePass scene,
            Map<Integer, Binding> bindings,
            List<ColorAttachment> colors,
            DepthAttachment depth,
            Geometry geometry,
            Dispatch dispatch,
            Trace trace,
            int maxRecursionDepth,
            boolean frameData,
            boolean cameraData,
            boolean sceneProjectionData,
            String sceneCamera,
            Map<VeilShaderStage, VeilSpecializationValues> specialization,
            Set<String> after,
            PipelineState pipeline,
            VeilVertexLayout vertexLayout,
            List<VeilDraw> draws,
            List<VeilTransfer> transfers) {
        public Pass {
            bindings = Map.copyOf(bindings);
            specialization = Map.copyOf(specialization);
            after = Set.copyOf(after);
            colors = List.copyOf(colors);
            geometry = geometry == null ? Geometry.FULLSCREEN : geometry;
            pipeline = pipeline == null ? PipelineState.DEFAULT : pipeline;
            vertexLayout = vertexLayout == null ? VeilVertexLayout.EMPTY : vertexLayout;
            draws = List.copyOf(draws);
            transfers = List.copyOf(transfers);
            boolean graphicsPass = !compute && !raytrace && !transfer && scene == null;
            if (draws.size() > 4096)
                throw new IllegalArgumentException("Graphics pass exceeds 4096 draws: " + name);
            if (transfers.size() > 256)
                throw new IllegalArgumentException("Transfer pass exceeds 256 operations: " + name);
            if ((compute ? 1 : 0)
                            + (raytrace ? 1 : 0)
                            + (transfer ? 1 : 0)
                            + (scene != null ? 1 : 0)
                    > 1) {
                throw new IllegalArgumentException("Pass type is ambiguous: " + name);
            }
            if (scene != null) {
                if (program != null
                        || !bindings.isEmpty()
                        || colors.isEmpty()
                        || depth == null
                        || dispatch != null
                        || trace != null
                        || geometry != Geometry.FULLSCREEN
                        || frameData
                        || cameraData
                        || sceneProjectionData
                        || sceneCamera != null
                        || !specialization.isEmpty()
                        || pipeline != PipelineState.DEFAULT
                        || !vertexLayout.equals(VeilVertexLayout.EMPTY)
                        || !draws.isEmpty()
                        || !transfers.isEmpty()) {
                    throw new IllegalArgumentException(
                            "Custom scene pass contains shader-command fields: " + name);
                }
            } else if (transfer) {
                if (program != null
                        || !bindings.isEmpty()
                        || !colors.isEmpty()
                        || depth != null
                        || dispatch != null
                        || trace != null
                        || geometry != Geometry.FULLSCREEN
                        || frameData
                        || cameraData
                        || sceneProjectionData
                        || !specialization.isEmpty()
                        || pipeline != PipelineState.DEFAULT
                        || !vertexLayout.equals(VeilVertexLayout.EMPTY)
                        || !draws.isEmpty()
                        || transfers.isEmpty()) {
                    throw new IllegalArgumentException(
                            "Transfer pass contains graphics/compute fields: " + name);
                }
            } else {
                Objects.requireNonNull(program, "program");
                if (!transfers.isEmpty())
                    throw new IllegalArgumentException(
                            "Graphics/compute pass cannot contain transfers: " + name);
                if (raytrace) {
                    if (trace == null
                            || dispatch != null
                            || !colors.isEmpty()
                            || depth != null
                            || geometry != Geometry.FULLSCREEN
                            || !vertexLayout.equals(VeilVertexLayout.EMPTY)
                            || !draws.isEmpty()
                            || pipeline != PipelineState.DEFAULT) {
                        throw new IllegalArgumentException(
                                "Raytrace pass requires trace and cannot declare graphics/compute fields: "
                                        + name);
                    }
                    if (maxRecursionDepth < 1 || maxRecursionDepth > 31)
                        throw new IllegalArgumentException(
                                "Ray recursion depth must be within 1..31: " + name);
                } else if (trace != null || maxRecursionDepth != 1) {
                    throw new IllegalArgumentException(
                            "Only raytrace passes may declare trace or maxRecursionDepth: " + name);
                }
                if (compute && geometry != Geometry.FULLSCREEN)
                    throw new IllegalArgumentException(
                            "Compute pass cannot declare geometry: " + name);
                if (compute && (!colors.isEmpty() || depth != null))
                    throw new IllegalArgumentException(
                            "Compute pass cannot declare attachments: " + name);
                if (graphicsPass && geometry.fluid() && depth == null) {
                    throw new IllegalArgumentException(
                            "Fluid geometry pass requires a depth attachment: " + name);
                }
                if (graphicsPass && colors.size() > 8)
                    throw new IllegalArgumentException(
                            "Graphics pass supports at most eight color attachments: " + name);
                if (graphicsPass && colors.isEmpty() && depth == null)
                    throw new IllegalArgumentException(
                            "Graphics pass requires an attachment: " + name);
                if (compute != (dispatch != null)) {
                    throw new IllegalArgumentException(
                            "Compute passes require dispatch and graphics passes must not declare it: "
                                    + name);
                }
                if (compute && (!vertexLayout.equals(VeilVertexLayout.EMPTY) || !draws.isEmpty())) {
                    throw new IllegalArgumentException(
                            "Compute pass cannot declare vertex input or draws: " + name);
                }
                if (graphicsPass && geometry == Geometry.CUSTOM && draws.isEmpty())
                    throw new IllegalArgumentException(
                            "Custom graphics pass requires draws: " + name);
                if (graphicsPass
                        && geometry != Geometry.CUSTOM
                        && (!vertexLayout.equals(VeilVertexLayout.EMPTY) || !draws.isEmpty())) {
                    throw new IllegalArgumentException(
                            "Legacy fullscreen/water geometry cannot declare custom vertex input or draws: "
                                    + name);
                }
            }
        }

        public VeilSpecializationValues values(VeilShaderStage stage) {
            return specialization.getOrDefault(stage, VeilSpecializationValues.empty());
        }

        public String target() {
            return colors.isEmpty() ? null : colors.getFirst().resource();
        }

        public String depthTarget() {
            return depth == null ? null : depth.resource();
        }

        public boolean graphics() {
            return !compute && !raytrace && !transfer && scene == null;
        }

        public boolean scenePass() {
            return scene != null;
        }
    }

    public static final class ImageAsset {
        private final byte[] bytes;
        private final String hash;

        ImageAsset(byte[] bytes, String hash) {
            this.bytes = Objects.requireNonNull(bytes, "bytes");
            this.hash = Objects.requireNonNull(hash, "hash");
        }

        public String hash() {
            return hash;
        }

        public int size() {
            return bytes.length;
        }

        public byte[] copyBytes() {
            return bytes.clone();
        }

        byte[] bytesForUpload() {
            return bytes;
        }
    }

    public static final class BufferAsset {
        private final byte[] bytes;
        private final String hash;

        BufferAsset(byte[] bytes, String hash) {
            this.bytes = Objects.requireNonNull(bytes, "bytes");
            this.hash = Objects.requireNonNull(hash, "hash");
        }

        public String hash() {
            return hash;
        }

        public int size() {
            return bytes.length;
        }

        public byte[] copyBytes() {
            return bytes.clone();
        }

        byte[] bytesForUpload() {
            return bytes;
        }
    }

    public record Prepared(
            VeilShaderPack pack,
            Map<VeilShaderId, VeilShaderProgram> programs,
            List<VeilRenderGraph.Pass> graph,
            Map<String, ImageAsset> imageAssets,
            Map<String, BufferAsset> bufferAssets) {
        public Prepared {
            programs = Map.copyOf(programs);
            graph = List.copyOf(graph);
            imageAssets = Map.copyOf(imageAssets);
            bufferAssets = Map.copyOf(bufferAssets);
        }
    }

    public VeilShaderPack(
            String name,
            int abiVersion,
            Map<String, Resource> resources,
            Map<VeilShaderId, Map<VeilShaderStage, VeilShaderId>> programs,
            Map<String, Setting> settings,
            List<Pass> passes,
            String present,
            VanillaReplacement replacesVanilla) {
        this(
                name,
                abiVersion,
                resources,
                programs,
                settings,
                passes,
                present,
                replacesVanilla,
                Map.of());
    }

    public VeilShaderPack(
            String name,
            int abiVersion,
            Map<String, Resource> resources,
            Map<VeilShaderId, Map<VeilShaderStage, VeilShaderId>> programs,
            Map<String, Setting> settings,
            List<Pass> passes,
            String present,
            VanillaReplacement replacesVanilla,
            Map<VeilShaderId, Map<VeilShaderStage, String>> entryPoints) {
        this(
                name,
                abiVersion,
                resources,
                programs,
                settings,
                passes,
                present,
                replacesVanilla,
                entryPoints,
                PresentEncoding.LEGACY);
    }

    public VeilShaderPack {
        presentEncoding = Objects.requireNonNull(presentEncoding);
        if (presentEncoding != PresentEncoding.LEGACY && (abiVersion < 21 || present == null))
            throw new IllegalArgumentException(
                    "Explicit presentation encoding requires ABI21 and a present output");
        if (abiVersion < 21
                && resources.values().stream()
                        .anyMatch(r -> VeilColorPipeline.HOST_ID.equals(r.hostId())))
            throw new IllegalArgumentException("Color pipeline metadata requires ABI21");
        resources = Map.copyOf(resources);
        var copy = new LinkedHashMap<VeilShaderId, Map<VeilShaderStage, VeilShaderId>>();
        programs.forEach((id, stages) -> copy.put(id, Map.copyOf(stages)));
        programs = Map.copyOf(copy);
        var declaredPrograms = programs;
        var entryCopy = new LinkedHashMap<VeilShaderId, Map<VeilShaderStage, String>>();
        entryPoints.forEach(
                (id, stages) -> {
                    if (!declaredPrograms.containsKey(id))
                        throw new IllegalArgumentException(
                                "Entry points reference unknown program " + id);
                    stages.forEach(
                            (stage, entry) -> {
                                if (!declaredPrograms.get(id).containsKey(stage)
                                        || !entry.matches("[A-Za-z_][A-Za-z0-9_]*"))
                                    throw new IllegalArgumentException(
                                            "Invalid shader entry point " + entry);
                            });
                    entryCopy.put(id, Map.copyOf(stages));
                });
        entryPoints = Map.copyOf(entryCopy);
        settings = Map.copyOf(settings);
        passes = List.copyOf(passes);
        replacesVanilla = replacesVanilla == null ? VanillaReplacement.NONE : replacesVanilla;
        if (abiVersion < 1 || abiVersion > MAX_ABI_VERSION)
            throw new IllegalArgumentException("Unsupported Veil shader ABI: " + abiVersion);
        if (abiVersion < 9) {
            for (Resource resource : resources.values()) {
                if (resource.source() != Source.OWNED
                        || resource.kind() != VeilRenderGraph.Kind.IMAGE) continue;
                boolean legacyFormat =
                        switch (resource.format().name()) {
                            case "R8_UNORM",
                                    "RG8_UNORM",
                                    "RGBA8_UNORM",
                                    "R16_FLOAT",
                                    "RG16_FLOAT",
                                    "RGBA16_FLOAT",
                                    "R32_FLOAT",
                                    "RG32_FLOAT",
                                    "RGBA32_FLOAT" ->
                                    true;
                            default -> false;
                        };
                if (!legacyFormat) {
                    throw new IllegalArgumentException(
                            "Creator image format "
                                    + resource.format()
                                    + " requires Veil shader ABI 9+");
                }
                if (resource.renderTarget()
                        && resource.format() != VeilFormat.RGBA8_UNORM
                        && resource.format() != VeilFormat.RGBA16_FLOAT) {
                    throw new IllegalArgumentException(
                            "Render target format "
                                    + resource.format()
                                    + " requires Veil shader ABI 9+");
                }
            }
        }
        if (abiVersion < 19
                && resources.values().stream()
                        .anyMatch(
                                resource ->
                                        VeilSurfaceTransforms.HOST_ID.equals(resource.hostId())))
            throw new IllegalArgumentException("Surface transforms require ABI 19+");
        if (abiVersion < 20
                && resources.values().stream()
                        .anyMatch(resource -> VeilSurfaceGuideFrame.isHost(resource.hostId())))
            throw new IllegalArgumentException("Surface guides require ABI 20+");
        boolean extendedHost =
                resources.values().stream()
                        .map(Resource::hostId)
                        .anyMatch(
                                id ->
                                        VeilHostResourceRegistry.ENVIRONMENT.equals(id)
                                                || VeilHostResourceRegistry.BLOCK_NORMAL_ATLAS
                                                        .equals(id)
                                                || VeilHostResourceRegistry.BLOCK_SPECULAR_ATLAS
                                                        .equals(id));
        if (abiVersion < 17 && extendedHost)
            throw new IllegalArgumentException("PBR atlases and environment require ABI 17+");
        if (replacesVanilla.lava()
                && passes.stream().noneMatch(pass -> pass.geometry() == Geometry.FLUID_LAVA))
            throw new IllegalArgumentException("Lava replacement requires a fluid_lava pass");
        if (replacesVanilla.weather()
                && (present == null
                        || resources.values().stream()
                                .noneMatch(
                                        resource ->
                                                VeilHostResourceRegistry.ENVIRONMENT.equals(
                                                        resource.hostId()))))
            throw new IllegalArgumentException(
                    "Weather replacement requires presentation and environment data");
        if ((replacesVanilla.lava() || replacesVanilla.weather())
                && resources.values().stream()
                        .noneMatch(
                                resource ->
                                        resource.source() == Source.SCENE_DEPTH
                                                || VeilHostResourceRegistry.SCENE_DEPTH.equals(
                                                        resource.hostId())))
            throw new IllegalArgumentException("Lava/weather replacement requires scene depth");
        if (abiVersion < 17
                && (replacesVanilla.lava()
                        || replacesVanilla.weather()
                        || passes.stream()
                                .anyMatch(pass -> pass.geometry() == Geometry.FLUID_LAVA)))
            throw new IllegalArgumentException(
                    "Lava and weather replacement require shader ABI 17+");
        if (abiVersion < 2 && resources.values().stream().anyMatch(Resource::history)) {
            throw new IllegalArgumentException("Temporal resources require ABI 2");
        }
        if (abiVersion < 3 && passes.stream().anyMatch(Pass::cameraData)) {
            throw new IllegalArgumentException("CameraData requires ABI 3");
        }
        if (abiVersion < 3 && passes.stream().anyMatch(Pass::sceneProjectionData)) {
            throw new IllegalArgumentException("SceneProjectionData requires ABI 3");
        }
        if (abiVersion < 4
                && (resources.values().stream()
                                .anyMatch(
                                        resource ->
                                                resource.storageImage()
                                                        || resource.image2dArray()
                                                        || resource.kind()
                                                                        == VeilRenderGraph.Kind
                                                                                .BUFFER
                                                                && resource.history()
                                                        || resource.initializedBufferAsset()
                                                        || resource.mipLevels() > 1
                                                        || resource.source() == Source.OWNED
                                                                && resource.sampledAsset()
                                                                && resource.image2d())
                        || passes.stream()
                                .anyMatch(
                                        pass ->
                                                pass.compute() && pass.dispatch().dynamic()
                                                        || pass.bindings().values().stream()
                                                                .anyMatch(
                                                                        binding ->
                                                                                binding.access()
                                                                                        == BindingAccess
                                                                                                .READ_WRITE)))) {
            throw new IllegalArgumentException(
                    "Veil storage images, texture2d assets/arrays, mip chains, raw buffer assets, temporal buffers, resource-relative dispatch and readwrite bindings require ABI 4: "
                            + resources.values().stream()
                                    .filter(
                                            resource ->
                                                    resource.storageImage()
                                                            || resource.image2dArray()
                                                            || resource.kind()
                                                                            == VeilRenderGraph.Kind
                                                                                    .BUFFER
                                                                    && resource.history()
                                                            || resource.initializedBufferAsset()
                                                            || resource.mipLevels() > 1
                                                            || resource.source() == Source.OWNED
                                                                    && resource.sampledAsset()
                                                                    && resource.image2d())
                                    .map(Resource::name)
                                    .toList());
        }
        if (abiVersion < 5
                && (resources.values().stream()
                                .anyMatch(
                                        resource ->
                                                resource.storageImage() && resource.mipLevels() > 1
                                                        || resource.ktx2Asset())
                        || passes.stream()
                                .anyMatch(
                                        pass ->
                                                pass.compute()
                                                                && pass.dispatch().dynamic()
                                                                && pass.dispatch().mip() > 0
                                                        || pass.bindings().values().stream()
                                                                .anyMatch(
                                                                        binding ->
                                                                                binding.array()
                                                                                        || binding
                                                                                                        .mip()
                                                                                                >= 0
                                                                                        || binding
                                                                                                        .baseLayer()
                                                                                                != 0
                                                                                        || binding
                                                                                                        .layerCount()
                                                                                                != 0)))) {
            throw new IllegalArgumentException(
                    "Writable mip views, mip-relative dispatch, descriptor arrays/subresource bindings and KTX2 assets require ABI 5");
        }
        if (abiVersion < 6
                && resources.values().stream()
                        .anyMatch(
                                resource ->
                                        switch (resource.source()) {
                                            case SCENE_OPAQUE_COLOR,
                                                    SCENE_OPAQUE_DEPTH,
                                                    SCENE_MATERIAL_ID,
                                                    SCENE_MATERIAL_DEPTH ->
                                                    true;
                                            default -> false;
                                        })) {
            throw new IllegalArgumentException("Opaque-scene and material imports require ABI 6");
        }
        if (abiVersion < 7
                && passes.stream()
                        .anyMatch(pass -> pass.geometry().fluid() || pass.depthTarget() != null)) {
            throw new IllegalArgumentException("Fluid Geometry/depth attachments require ABI 7");
        }
        if (abiVersion < 8
                && passes.stream()
                        .anyMatch(pass -> pass.geometry() == Geometry.FLUID_WATER_PHYSICAL)) {
            throw new IllegalArgumentException("fluid_water_physical requires Veil shader ABI 8+");
        }
        if (abiVersion < 9
                && passes.stream().anyMatch(pass -> pass.compute() && pass.dispatch().indirect())) {
            throw new IllegalArgumentException(
                    "GPU indirect compute dispatch requires Veil shader ABI 9+");
        }
        if (abiVersion < 10
                && resources.values().stream()
                        .anyMatch(
                                resource ->
                                        resource.source() == Source.HOST
                                                || resource.persistent())) {
            throw new IllegalArgumentException(
                    "Generic host resources and explicit resource lifetimes require Veil shader ABI 10+");
        }
        if (abiVersion < 11
                && (resources.values().stream()
                                .anyMatch(
                                        resource ->
                                                resource.samples() != 1
                                                        || resource.cubemap()
                                                        || resource.sizeFrom() != null
                                                        || resource.widthScale()
                                                                != resource.heightScale()
                                                        || resource.historyCount() > 2
                                                        || resource.source() == Source.OWNED
                                                                && resource.depthTarget()
                                                        || resource.usages()
                                                                .contains(VeilResourceUsage.UNIFORM)
                                                        || resource.usages()
                                                                .contains(VeilResourceUsage.VERTEX)
                                                        || resource.usages()
                                                                .contains(VeilResourceUsage.INDEX)
                                                        || resource.usages()
                                                                .contains(
                                                                        VeilResourceUsage.INDIRECT))
                        || passes.stream().anyMatch(pass -> pass.colors().size() > 1))) {
            throw new IllegalArgumentException(
                    "Generic resource descriptors, N-frame history, custom depth and MRT require Veil shader ABI 11+");
        }
        if (abiVersion < 12 && passes.stream().anyMatch(Pass::raytrace)) {
            throw new IllegalArgumentException(
                    "Ray tracing pipelines and shader binding tables require Veil shader ABI 12+");
        }
        if (abiVersion < 13
                && resources.values().stream()
                        .map(Resource::hostId)
                        .anyMatch(
                                id ->
                                        VeilHostResourceRegistry.CREATOR_LIGHTS.equals(id)
                                                || VeilHostResourceRegistry.CREATOR_INSTANCES
                                                        .equals(id)
                                                || VeilHostResourceRegistry.CREATOR_MATERIALS
                                                        .equals(id))) {
            throw new IllegalArgumentException(
                    "Creator lights, dynamic instances and PBR materials require Veil shader ABI 13+");
        }
        if (abiVersion < 14
                && resources.values().stream()
                        .map(Resource::hostId)
                        .anyMatch(VeilHostResourceRegistry.CREATOR_GEOMETRY::equals)) {
            throw new IllegalArgumentException(
                    "Hierarchical dynamic geometry requires Veil shader ABI 14+");
        }
        if (abiVersion < 15
                && resources.values().stream()
                        .map(Resource::hostId)
                        .anyMatch(VeilHostResourceRegistry.CREATOR_MESHES::equals)) {
            throw new IllegalArgumentException(
                    "Creator dynamic triangle meshes require Veil shader ABI 15+");
        }
        if (abiVersion < 16
                && resources.values().stream()
                        .map(Resource::hostId)
                        .anyMatch(VeilHostResourceRegistry.SHADOW_LIGHTS::equals)) {
            throw new IllegalArgumentException(
                    "Budgeted shadow lights require Veil shader ABI 16+");
        }
        var hostIds = new LinkedHashSet<String>();
        for (Resource resource : resources.values()) {
            if (!resource.hostImport()) continue;
            if (!hostIds.add(resource.hostId()))
                throw new IllegalArgumentException("Duplicate host import " + resource.hostId());
        }
        if (name.isBlank()
                || resources.size() > VeilShaderLimits.current().resources()
                || passes.isEmpty()
                || passes.size() > VeilShaderLimits.current().passes()) {
            throw new IllegalArgumentException(
                    "Pack requires a name and non-empty passes within configured shader pass/resource budgets");
        }
        var sceneNames = new LinkedHashSet<String>();
        passes.stream().filter(Pass::scenePass).forEach(pass -> sceneNames.add(pass.name()));
        for (Pass pass : passes) {
            if (pass.sceneCamera() != null && !sceneNames.contains(pass.sceneCamera())) {
                throw new IllegalArgumentException(
                        "Pass "
                                + pass.name()
                                + " references unknown custom scene camera "
                                + pass.sceneCamera());
            }
        }
    }

    public boolean requiresScene() {
        return present != null
                || resources.values().stream().anyMatch(Resource::hostImport)
                || passes.stream()
                        .anyMatch(
                                pass ->
                                        pass.scenePass()
                                                || pass.cameraData()
                                                || pass.sceneProjectionData()
                                                || pass.sceneCamera() != null);
    }

    public static VeilShaderPack parse(String source, String namespace) {
        return VeilShaderPackParser.parse(source, namespace);
    }

    public static VeilShaderPack parse(
            String source, String namespace, Map<String, String> overrides) {
        return VeilShaderPackParser.parse(source, namespace, overrides);
    }

    public Prepared prepare(VeilShaderLibrary library) throws IOException {
        return new VeilShaderPackPreparation(this).prepare(library);
    }

    public VeilShaderInterface pipelineInterface(Pass pass, VeilShaderInterface shaderInterface) {
        return VeilShaderPackPreparation.pipelineInterface(pass, shaderInterface);
    }
}
