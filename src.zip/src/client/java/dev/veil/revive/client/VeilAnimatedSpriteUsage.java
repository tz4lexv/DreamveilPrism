package dev.veil.revive.client;

import net.minecraft.client.renderer.texture.TextureAtlasSprite;

import java.util.IdentityHashMap;
import java.util.concurrent.atomic.LongAdder;

public final class VeilAnimatedSpriteUsage {
    private static final TextureAtlasSprite[] EMPTY = new TextureAtlasSprite[0];
    private static final ThreadLocal<CompileContext> COMPILE =
            ThreadLocal.withInitial(CompileContext::new);
    private static final LongAdder COMPILE_SPRITES = new LongAdder();
    private static final LongAdder ACTIVE_MARKS = new LongAdder();
    private static final LongAdder UPLOADS_SKIPPED = new LongAdder();

    private VeilAnimatedSpriteUsage() {}

    public static void beginSectionCompile() {
        CompileContext context = COMPILE.get();
        context.sprites.clear();
        context.active =
                VeilVideoConfig.on("animation.visibleOnly") && ReviveRuntime.optimizationsEnabled();
    }

    public static TextureAtlasSprite[] endSectionCompile() {
        CompileContext context = COMPILE.get();
        context.active = false;
        if (context.sprites.isEmpty()) return EMPTY;
        TextureAtlasSprite[] result = context.sprites.keySet().toArray(TextureAtlasSprite[]::new);
        COMPILE_SPRITES.add(result.length);
        context.sprites.clear();
        return result;
    }

    public static void recordOrMark(TextureAtlasSprite sprite) {
        if (!VeilVideoConfig.on("animation.visibleOnly")
                || !ReviveRuntime.optimizationsEnabled()
                || sprite == null
                || !sprite.contents().isAnimated()) return;
        CompileContext context = COMPILE.get();
        if (context.active) {
            context.sprites.put(sprite, Boolean.TRUE);
            VeilOriginalQuadCapture.recordSprite(sprite);
        } else {
            ((VeilSpriteActivity) (Object) sprite.contents()).veil$markActive();
            ACTIVE_MARKS.increment();
        }
    }

    public static void markActive(TextureAtlasSprite sprite) {
        if (!VeilVideoConfig.on("animation.visibleOnly")
                || !ReviveRuntime.optimizationsEnabled()
                || sprite == null
                || !sprite.contents().isAnimated()) return;
        ((VeilSpriteActivity) (Object) sprite.contents()).veil$markActive();
        ACTIVE_MARKS.increment();
    }

    public static void markActive(TextureAtlasSprite[] sprites) {
        if (!VeilVideoConfig.on("animation.visibleOnly")
                || !ReviveRuntime.optimizationsEnabled()
                || sprites == null
                || sprites.length == 0) return;
        long marked = 0L;
        for (TextureAtlasSprite sprite : sprites) {
            if (sprite == null) continue;

            ((VeilSpriteActivity) (Object) sprite.contents()).veil$markActive();
            marked++;
        }
        if (marked != 0L) ACTIVE_MARKS.add(marked);
    }

    public static void recordUploadSkipped() {
        UPLOADS_SKIPPED.increment();
    }

    public static long compileSpritesCaptured() {
        return COMPILE_SPRITES.sum();
    }

    public static long activeMarks() {
        return ACTIVE_MARKS.sum();
    }

    public static long uploadsSkipped() {
        return UPLOADS_SKIPPED.sum();
    }

    public static String telemetry() {
        return "animated_sprite_compile_captures_total="
                + COMPILE_SPRITES.sum()
                + "\n"
                + "animated_sprite_active_marks_total="
                + ACTIVE_MARKS.sum()
                + "\n"
                + "animated_sprite_uploads_skipped_total="
                + UPLOADS_SKIPPED.sum()
                + "\n";
    }

    private static final class CompileContext {
        final IdentityHashMap<TextureAtlasSprite, Boolean> sprites = new IdentityHashMap<>();
        boolean active;
    }
}
