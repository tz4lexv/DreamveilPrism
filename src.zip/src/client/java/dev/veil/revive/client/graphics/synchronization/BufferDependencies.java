package dev.veil.revive.client.graphics.synchronization;

import dev.veil.revive.client.VeilRenderGraph.Layout;
import dev.veil.revive.client.VeilRenderGraph.State;

public final class BufferDependencies {
    private BufferDependencies() {}

    public static boolean executionOnly(State source, State destination) {
        if (source.layout() != Layout.NONE || destination.layout() != Layout.NONE) return false;
        return !source.write() && destination.write();
    }
}
