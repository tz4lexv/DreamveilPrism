package dev.veil.revive.client.shaderpack.preparation;

import dev.veil.api.VeilResourceUsage;
import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.Resource;

import java.util.Map;

public final class ResourceRequirements {
    private ResourceRequirements() {}

    public static Resource buffer(
            Map<String, Resource> resources,
            Pass pass,
            String name,
            VeilResourceUsage usage,
            String role) {
        Resource resource = resources.get(name);
        if (resource == null || resource.kind() != VeilRenderGraph.Kind.BUFFER) {
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": " + role + " buffer is missing: " + name);
        }
        if (!resource.usages().contains(usage)) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + ": "
                            + role
                            + " buffer requires "
                            + usage
                            + " usage: "
                            + name);
        }
        return resource;
    }
}
