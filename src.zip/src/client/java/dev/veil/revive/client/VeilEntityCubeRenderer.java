package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.core.Direction;

import org.joml.Matrix3f;
import org.joml.Matrix4f;

public final class VeilEntityCubeRenderer {
    private static final ThreadLocal<Scratch> SCRATCH = ThreadLocal.withInitial(Scratch::new);

    private VeilEntityCubeRenderer() {}

    public static void render(
            PoseStack.Pose pose,
            VertexConsumer consumer,
            VeilModelCuboid cuboid,
            int light,
            int overlay,
            int color) {
        Scratch scratch = SCRATCH.get();
        prepareCorners(pose.pose(), cuboid, scratch);

        Matrix3f normalMatrix = pose.normal();
        int emittedFaces = 0;

        for (int face = 0; face < VeilModelCuboid.NUM_CUBE_FACES; face++) {
            if (!cuboid.shouldDrawFace(face)) continue;

            Direction direction = cuboid.normal(face);
            float nx = normalX(normalMatrix, direction);
            float ny = normalY(normalMatrix, direction);
            float nz = normalZ(normalMatrix, direction);

            float lengthSquared = Math.fma(nx, nx, Math.fma(ny, ny, nz * nz));
            if (lengthSquared > 1.0e-20F) {
                float inverseLength = 1.0F / (float) Math.sqrt(lengthSquared);
                nx *= inverseLength;
                ny *= inverseLength;
                nz *= inverseLength;
            }

            int base = face * VeilModelCuboid.NUM_FACE_VERTICES;
            emitVertex(consumer, cuboid, scratch, base, color, overlay, light, nx, ny, nz);
            emitVertex(consumer, cuboid, scratch, base + 1, color, overlay, light, nx, ny, nz);
            emitVertex(consumer, cuboid, scratch, base + 2, color, overlay, light, nx, ny, nz);
            emitVertex(consumer, cuboid, scratch, base + 3, color, overlay, light, nx, ny, nz);
            emittedFaces++;
        }

        VeilEntityModelFastPath.recordCube(emittedFaces);
    }

    private static void prepareCorners(Matrix4f matrix, VeilModelCuboid cuboid, Scratch scratch) {
        float vxx = matrix.m00() * cuboid.sizeX;
        float vxy = matrix.m01() * cuboid.sizeX;
        float vxz = matrix.m02() * cuboid.sizeX;
        float vyx = matrix.m10() * cuboid.sizeY;
        float vyy = matrix.m11() * cuboid.sizeY;
        float vyz = matrix.m12() * cuboid.sizeY;
        float vzx = matrix.m20() * cuboid.sizeZ;
        float vzy = matrix.m21() * cuboid.sizeZ;
        float vzz = matrix.m22() * cuboid.sizeZ;

        float c000x = transformPositionX(matrix, cuboid.originX, cuboid.originY, cuboid.originZ);
        float c000y = transformPositionY(matrix, cuboid.originX, cuboid.originY, cuboid.originZ);
        float c000z = transformPositionZ(matrix, cuboid.originX, cuboid.originY, cuboid.originZ);
        scratch.set(VeilModelCuboid.VERTEX_X0_Y0_Z0, c000x, c000y, c000z);

        float c100x = c000x + vxx;
        float c100y = c000y + vxy;
        float c100z = c000z + vxz;
        scratch.set(VeilModelCuboid.VERTEX_X1_Y0_Z0, c100x, c100y, c100z);

        float c110x = c100x + vyx;
        float c110y = c100y + vyy;
        float c110z = c100z + vyz;
        scratch.set(VeilModelCuboid.VERTEX_X1_Y1_Z0, c110x, c110y, c110z);

        float c010x = c000x + vyx;
        float c010y = c000y + vyy;
        float c010z = c000z + vyz;
        scratch.set(VeilModelCuboid.VERTEX_X0_Y1_Z0, c010x, c010y, c010z);

        float c001x = c000x + vzx;
        float c001y = c000y + vzy;
        float c001z = c000z + vzz;
        scratch.set(VeilModelCuboid.VERTEX_X0_Y0_Z1, c001x, c001y, c001z);

        float c101x = c100x + vzx;
        float c101y = c100y + vzy;
        float c101z = c100z + vzz;
        scratch.set(VeilModelCuboid.VERTEX_X1_Y0_Z1, c101x, c101y, c101z);

        float c111x = c110x + vzx;
        float c111y = c110y + vzy;
        float c111z = c110z + vzz;
        scratch.set(VeilModelCuboid.VERTEX_X1_Y1_Z1, c111x, c111y, c111z);

        float c011x = c010x + vzx;
        float c011y = c010y + vzy;
        float c011z = c010z + vzz;
        scratch.set(VeilModelCuboid.VERTEX_X0_Y1_Z1, c011x, c011y, c011z);
    }

    private static void emitVertex(
            VertexConsumer consumer,
            VeilModelCuboid cuboid,
            Scratch scratch,
            int element,
            int color,
            int overlay,
            int light,
            float nx,
            float ny,
            float nz) {
        int corner = cuboid.positionIndex(element);
        consumer.addVertex(scratch.x[corner], scratch.y[corner], scratch.z[corner]);
        consumer.setColor(color);
        consumer.setUv(cuboid.texU(element), cuboid.texV(element));
        consumer.setOverlay(overlay);
        consumer.setLight(light);
        consumer.setNormal(nx, ny, nz);
    }

    private static float transformPositionX(Matrix4f matrix, float x, float y, float z) {
        return (matrix.m00() * x) + ((matrix.m10() * y) + ((matrix.m20() * z) + matrix.m30()));
    }

    private static float transformPositionY(Matrix4f matrix, float x, float y, float z) {
        return (matrix.m01() * x) + ((matrix.m11() * y) + ((matrix.m21() * z) + matrix.m31()));
    }

    private static float transformPositionZ(Matrix4f matrix, float x, float y, float z) {
        return (matrix.m02() * x) + ((matrix.m12() * y) + ((matrix.m22() * z) + matrix.m32()));
    }

    private static float normalX(Matrix3f matrix, Direction direction) {
        return switch (direction) {
            case DOWN -> -matrix.m10();
            case UP -> matrix.m10();
            case NORTH -> -matrix.m20();
            case SOUTH -> matrix.m20();
            case WEST -> -matrix.m00();
            case EAST -> matrix.m00();
        };
    }

    private static float normalY(Matrix3f matrix, Direction direction) {
        return switch (direction) {
            case DOWN -> -matrix.m11();
            case UP -> matrix.m11();
            case NORTH -> -matrix.m21();
            case SOUTH -> matrix.m21();
            case WEST -> -matrix.m01();
            case EAST -> matrix.m01();
        };
    }

    private static float normalZ(Matrix3f matrix, Direction direction) {
        return switch (direction) {
            case DOWN -> -matrix.m12();
            case UP -> matrix.m12();
            case NORTH -> -matrix.m22();
            case SOUTH -> matrix.m22();
            case WEST -> -matrix.m02();
            case EAST -> matrix.m02();
        };
    }

    private static final class Scratch {
        final float[] x = new float[VeilModelCuboid.NUM_CUBE_VERTICES];
        final float[] y = new float[VeilModelCuboid.NUM_CUBE_VERTICES];
        final float[] z = new float[VeilModelCuboid.NUM_CUBE_VERTICES];

        void set(int index, float x, float y, float z) {
            this.x[index] = x;
            this.y[index] = y;
            this.z[index] = z;
        }
    }
}
