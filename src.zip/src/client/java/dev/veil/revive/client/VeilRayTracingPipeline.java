package dev.veil.revive.client;

import static org.lwjgl.vulkan.KHRRayTracingPipeline.*;
import static org.lwjgl.vulkan.VK12.*;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.client.graphics.minecraft.DeferredGpuRetirement;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.vulkan.VkBufferCreateInfo;
import org.lwjgl.vulkan.VkBufferDeviceAddressInfo;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkMemoryAllocateFlagsInfo;
import org.lwjgl.vulkan.VkMemoryAllocateInfo;
import org.lwjgl.vulkan.VkMemoryRequirements;
import org.lwjgl.vulkan.VkPhysicalDeviceMemoryProperties;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties2;
import org.lwjgl.vulkan.VkPhysicalDeviceRayTracingPipelinePropertiesKHR;
import org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo;
import org.lwjgl.vulkan.VkRayTracingPipelineCreateInfoKHR;
import org.lwjgl.vulkan.VkRayTracingShaderGroupCreateInfoKHR;
import org.lwjgl.vulkan.VkStridedDeviceAddressRegionKHR;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

final class VeilRayTracingPipeline implements AutoCloseable {
    private static final VeilShaderStage[] ORDER = {
        VeilShaderStage.RAYGEN, VeilShaderStage.MISS, VeilShaderStage.CLOSEST_HIT,
        VeilShaderStage.ANY_HIT, VeilShaderStage.INTERSECTION, VeilShaderStage.CALLABLE
    };

    private final VeilVulkanRuntime runtime;
    private final List<VeilShaderModule> modules;
    private final VeilPipelineLayout layout;
    private final SbtBuffer sbt;
    private final Region raygen;
    private final Region miss;
    private final Region hit;
    private final Region callable;
    private final DeferredGpuRetirement closeRequested = new DeferredGpuRetirement();
    private long pipeline;

    private VeilRayTracingPipeline(
            VeilVulkanRuntime runtime,
            List<VeilShaderModule> modules,
            VeilPipelineLayout layout,
            SbtBuffer sbt,
            long pipeline,
            Region raygen,
            Region miss,
            Region hit,
            Region callable) {
        this.runtime = runtime;
        this.modules = List.copyOf(modules);
        this.layout = layout;
        this.sbt = sbt;
        this.pipeline = pipeline;
        this.raygen = raygen;
        this.miss = miss;
        this.hit = hit;
        this.callable = callable;
    }

    static VeilRayTracingPipeline create(
            VeilVulkanRuntime runtime,
            VeilShaderProgram program,
            VeilShaderInterface shaderInterface,
            Map<VeilShaderStage, VeilSpecializationValues> values,
            int recursionDepth) {
        RenderSystem.assertOnRenderThread();
        if (!VeilRayCapabilities.rayPipeline())
            throw new IllegalStateException(
                    "Raytrace pass requires an enabled VK_KHR_ray_tracing_pipeline device");
        if (!program.rayTracing())
            throw new IllegalArgumentException("Ray tracing pipeline requires ray stages");
        var modules = new ArrayList<VeilShaderModule>();
        var nativeValues = new ArrayList<VeilSpecializationValues.NativeData>();
        VeilPipelineLayout layout = null;
        SbtBuffer sbt = null;
        long pipeline = VK_NULL_HANDLE;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            var properties =
                    VkPhysicalDeviceRayTracingPipelinePropertiesKHR.calloc(stack).sType$Default();
            vkGetPhysicalDeviceProperties2(
                    runtime.vkDevice().getPhysicalDevice(),
                    VkPhysicalDeviceProperties2.calloc(stack)
                            .sType$Default()
                            .pNext(properties.address()));
            if (recursionDepth > properties.maxRayRecursionDepth()) {
                throw new IllegalArgumentException(
                        "Requested ray recursion depth="
                                + recursionDepth
                                + " exceeds device limit="
                                + properties.maxRayRecursionDepth());
            }
            layout = VeilPipelineLayout.createFromReflection(runtime, shaderInterface);
            var stageIndices = new EnumMap<VeilShaderStage, Integer>(VeilShaderStage.class);
            var stages = VkPipelineShaderStageCreateInfo.calloc(program.stages().size(), stack);
            int stageIndex = 0;
            for (VeilShaderStage stage : ORDER) {
                VeilSpirvBinary binary = program.stages().get(stage);
                if (binary == null) continue;
                VeilSpecializationValues specialization =
                        values.getOrDefault(stage, VeilSpecializationValues.empty());
                specialization.validate(shaderInterface, stage);
                VeilSpecializationValues.NativeData nativeData = specialization.nativeData();
                nativeValues.add(nativeData);
                VeilShaderModule module = VeilShaderModule.create(runtime, binary);
                modules.add(module);
                stages.get(stageIndex)
                        .sType$Default()
                        .stage(stage.vkStageFlags())
                        .module(module.handle())
                        .pName(stack.UTF8(binary.entryPoint()))
                        .pSpecializationInfo(nativeData.info());
                stageIndices.put(stage, stageIndex++);
            }

            boolean hasHit =
                    stageIndices.containsKey(VeilShaderStage.CLOSEST_HIT)
                            || stageIndices.containsKey(VeilShaderStage.ANY_HIT)
                            || stageIndices.containsKey(VeilShaderStage.INTERSECTION);
            boolean hasCallable = stageIndices.containsKey(VeilShaderStage.CALLABLE);
            int groupCount = 2 + (hasHit ? 1 : 0) + (hasCallable ? 1 : 0);
            var groups = VkRayTracingShaderGroupCreateInfoKHR.calloc(groupCount, stack);
            configureGeneral(groups.get(0), stageIndices.get(VeilShaderStage.RAYGEN));
            configureGeneral(groups.get(1), stageIndices.get(VeilShaderStage.MISS));
            int hitGroup = -1;
            int callableGroup = -1;
            int groupIndex = 2;
            if (hasHit) {
                hitGroup = groupIndex;
                var group =
                        groups.get(groupIndex++)
                                .sType$Default()
                                .type(
                                        stageIndices.containsKey(VeilShaderStage.INTERSECTION)
                                                ? VK_RAY_TRACING_SHADER_GROUP_TYPE_PROCEDURAL_HIT_GROUP_KHR
                                                : VK_RAY_TRACING_SHADER_GROUP_TYPE_TRIANGLES_HIT_GROUP_KHR)
                                .generalShader(VK_SHADER_UNUSED_KHR)
                                .closestHitShader(
                                        stageIndices.getOrDefault(
                                                VeilShaderStage.CLOSEST_HIT, VK_SHADER_UNUSED_KHR))
                                .anyHitShader(
                                        stageIndices.getOrDefault(
                                                VeilShaderStage.ANY_HIT, VK_SHADER_UNUSED_KHR))
                                .intersectionShader(
                                        stageIndices.getOrDefault(
                                                VeilShaderStage.INTERSECTION,
                                                VK_SHADER_UNUSED_KHR));
            }
            if (hasCallable) {
                callableGroup = groupIndex;
                configureGeneral(
                        groups.get(groupIndex), stageIndices.get(VeilShaderStage.CALLABLE));
            }
            var createInfo = VkRayTracingPipelineCreateInfoKHR.calloc(1, stack);
            createInfo
                    .get(0)
                    .sType$Default()
                    .pStages(stages)
                    .pGroups(groups)
                    .maxPipelineRayRecursionDepth(recursionDepth)
                    .layout(layout.handle());
            var output = stack.mallocLong(1);
            VeilVulkanChecks.check(
                    vkCreateRayTracingPipelinesKHR(
                            runtime.vkDevice(),
                            VK_NULL_HANDLE,
                            VeilVulkanPipelineCache.handle(runtime),
                            createInfo,
                            null,
                            output),
                    "vkCreateRayTracingPipelinesKHR");
            pipeline = output.get(0);

            int handleSize = properties.shaderGroupHandleSize();
            long stride = align(handleSize, properties.shaderGroupHandleAlignment());
            if (stride > properties.maxShaderGroupStride())
                throw new IllegalStateException("Aligned SBT stride exceeds device limit");
            long sectionAlignment = properties.shaderGroupBaseAlignment();
            long raygenOffset = 0;
            long missOffset = align(raygenOffset + stride, sectionAlignment);
            long hitOffset = hasHit ? align(missOffset + stride, sectionAlignment) : 0;
            long callableOffset =
                    hasCallable
                            ? align((hasHit ? hitOffset : missOffset) + stride, sectionAlignment)
                            : 0;
            long total = (hasCallable ? callableOffset : hasHit ? hitOffset : missOffset) + stride;
            sbt = new SbtBuffer(runtime, total, sectionAlignment);
            ByteBuffer handles = stack.malloc(Math.multiplyExact(groupCount, handleSize));
            VeilVulkanChecks.check(
                    vkGetRayTracingShaderGroupHandlesKHR(
                            runtime.vkDevice(), pipeline, 0, groupCount, handles),
                    "vkGetRayTracingShaderGroupHandlesKHR");
            int finalHitGroup = hitGroup;
            int finalCallableGroup = callableGroup;
            long sbtBaseOffset = sbt.baseOffset;
            sbt.write(
                    target -> {
                        copyHandle(handles, target, 0, handleSize, sbtBaseOffset + raygenOffset);
                        copyHandle(handles, target, 1, handleSize, sbtBaseOffset + missOffset);
                        if (hasHit)
                            copyHandle(
                                    handles,
                                    target,
                                    finalHitGroup,
                                    handleSize,
                                    sbtBaseOffset + hitOffset);
                        if (hasCallable)
                            copyHandle(
                                    handles,
                                    target,
                                    finalCallableGroup,
                                    handleSize,
                                    sbtBaseOffset + callableOffset);
                    });
            long baseAddress = sbt.address + sbt.baseOffset;
            Region raygen = new Region(baseAddress + raygenOffset, stride, stride);
            Region miss = new Region(baseAddress + missOffset, stride, stride);
            Region hit =
                    hasHit ? new Region(baseAddress + hitOffset, stride, stride) : Region.EMPTY;
            Region callable =
                    hasCallable
                            ? new Region(baseAddress + callableOffset, stride, stride)
                            : Region.EMPTY;
            return new VeilRayTracingPipeline(
                    runtime, modules, layout, sbt, pipeline, raygen, miss, hit, callable);
        } catch (RuntimeException | Error failure) {
            if (pipeline != VK_NULL_HANDLE) vkDestroyPipeline(runtime.vkDevice(), pipeline, null);
            if (sbt != null) sbt.destroy();
            if (layout != null) layout.destroyNow();
            modules.forEach(VeilShaderModule::destroyNow);
            throw failure;
        } finally {
            nativeValues.forEach(VeilSpecializationValues.NativeData::close);
        }
    }

    private static void configureGeneral(VkRayTracingShaderGroupCreateInfoKHR group, int stage) {
        group.sType$Default()
                .type(VK_RAY_TRACING_SHADER_GROUP_TYPE_GENERAL_KHR)
                .generalShader(stage)
                .closestHitShader(VK_SHADER_UNUSED_KHR)
                .anyHitShader(VK_SHADER_UNUSED_KHR)
                .intersectionShader(VK_SHADER_UNUSED_KHR);
    }

    private static void copyHandle(
            ByteBuffer source, ByteBuffer target, int group, int handleSize, long offset) {
        for (int i = 0; i < handleSize; i++)
            target.put(Math.toIntExact(offset) + i, source.get(group * handleSize + i));
    }

    void trace(VkCommandBuffer commandBuffer, int width, int height, int depth) {
        if (closeRequested.closeRequested() || pipeline == VK_NULL_HANDLE)
            throw new IllegalStateException("Ray tracing pipeline is closed");
        try (MemoryStack stack = MemoryStack.stackPush()) {
            vkCmdTraceRaysKHR(
                    commandBuffer,
                    region(stack, raygen),
                    region(stack, miss),
                    region(stack, hit),
                    region(stack, callable),
                    width,
                    height,
                    depth);
        }
    }

    private static VkStridedDeviceAddressRegionKHR region(MemoryStack stack, Region region) {
        return VkStridedDeviceAddressRegionKHR.calloc(stack)
                .deviceAddress(region.address)
                .stride(region.stride)
                .size(region.size);
    }

    long handle() {
        return pipeline;
    }

    long layout() {
        return layout.handle();
    }

    private void destroyNow() {
        closeRequested.markDestroyed();
        long old = pipeline;
        pipeline = VK_NULL_HANDLE;
        if (old != VK_NULL_HANDLE) vkDestroyPipeline(runtime.vkDevice(), old, null);
        sbt.destroy();
        layout.destroyNow();
        modules.forEach(VeilShaderModule::destroyNow);
    }

    @Override
    public void close() {
        RenderSystem.assertOnRenderThread();
        closeRequested.defer(action -> runtime.deferDestroy(action::run), this::destroyNow);
    }

    private static long align(long value, long alignment) {
        return (value + alignment - 1) / alignment * alignment;
    }

    private record Region(long address, long stride, long size) {
        private static final Region EMPTY = new Region(0, 0, 0);
    }

    private static final class SbtBuffer {
        private final VeilVulkanRuntime runtime;
        private final long size;
        private long handle;
        private long memory;
        private long address;
        private long baseOffset;

        SbtBuffer(VeilVulkanRuntime runtime, long dataSize, long baseAlignment) {
            this.runtime = runtime;
            this.size = Math.addExact(dataSize, baseAlignment - 1);
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var output = stack.mallocLong(1);
                VeilVulkanChecks.check(
                        vkCreateBuffer(
                                runtime.vkDevice(),
                                VkBufferCreateInfo.calloc(stack)
                                        .sType$Default()
                                        .size(this.size)
                                        .usage(
                                                VK_BUFFER_USAGE_SHADER_BINDING_TABLE_BIT_KHR
                                                        | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT)
                                        .sharingMode(VK_SHARING_MODE_EXCLUSIVE),
                                null,
                                output),
                        "create SBT buffer");
                handle = output.get(0);
                var requirements = VkMemoryRequirements.calloc(stack);
                vkGetBufferMemoryRequirements(runtime.vkDevice(), handle, requirements);
                var memoryProperties = VkPhysicalDeviceMemoryProperties.calloc(stack);
                vkGetPhysicalDeviceMemoryProperties(
                        runtime.vkDevice().getPhysicalDevice(), memoryProperties);
                int memoryType = -1;
                int required =
                        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
                for (int i = 0; i < memoryProperties.memoryTypeCount(); i++) {
                    if ((requirements.memoryTypeBits() & (1 << i)) != 0
                            && (memoryProperties.memoryTypes(i).propertyFlags() & required)
                                    == required) {
                        memoryType = i;
                        break;
                    }
                }
                if (memoryType < 0)
                    throw new IllegalStateException(
                            "No host-visible coherent memory type for ray tracing SBT");
                var flags =
                        VkMemoryAllocateFlagsInfo.calloc(stack)
                                .sType$Default()
                                .flags(VK_MEMORY_ALLOCATE_DEVICE_ADDRESS_BIT);
                VeilVulkanChecks.check(
                        vkAllocateMemory(
                                runtime.vkDevice(),
                                VkMemoryAllocateInfo.calloc(stack)
                                        .sType$Default()
                                        .pNext(flags.address())
                                        .allocationSize(requirements.size())
                                        .memoryTypeIndex(memoryType),
                                null,
                                output),
                        "allocate SBT memory");
                memory = output.get(0);
                VeilVulkanChecks.check(
                        vkBindBufferMemory(runtime.vkDevice(), handle, memory, 0),
                        "bind SBT memory");
                address =
                        vkGetBufferDeviceAddress(
                                runtime.vkDevice(),
                                VkBufferDeviceAddressInfo.calloc(stack)
                                        .sType$Default()
                                        .buffer(handle));
                if (address == 0)
                    throw new IllegalStateException("SBT buffer device address unavailable");
                baseOffset = align(address, baseAlignment) - address;
            } catch (RuntimeException | Error failure) {
                destroy();
                throw failure;
            }
        }

        void write(java.util.function.Consumer<ByteBuffer> writer) {
            try (MemoryStack stack = MemoryStack.stackPush()) {
                var pointer = stack.mallocPointer(1);
                VeilVulkanChecks.check(
                        vkMapMemory(runtime.vkDevice(), memory, 0, size, 0, pointer),
                        "map SBT memory");
                try {
                    ByteBuffer target =
                            MemoryUtil.memByteBuffer(pointer.get(0), Math.toIntExact(size));
                    MemoryUtil.memSet(target, 0);
                    writer.accept(target);
                } finally {
                    vkUnmapMemory(runtime.vkDevice(), memory);
                }
            }
        }

        void destroy() {
            if (handle != VK_NULL_HANDLE) vkDestroyBuffer(runtime.vkDevice(), handle, null);
            if (memory != VK_NULL_HANDLE) vkFreeMemory(runtime.vkDevice(), memory, null);
            handle = memory = address = VK_NULL_HANDLE;
        }
    }
}
