package dev.veil.revive.client;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.DeviceType;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuSampler;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.terrain.capture.TerrainPlanSource;
import dev.veil.revive.client.terrain.indirect.IndexedTerrainCommands;
import dev.veil.revive.client.terrain.indirect.TerrainBatchEncoder;
import dev.veil.revive.client.terrain.indirect.TerrainBatchStorage;
import dev.veil.revive.core.CachedPrefixedLabel;
import dev.veil.revive.core.WallClockCadence;
import dev.veil.revive.core.terrain.BatchBuildTransaction;
import dev.veil.revive.core.terrain.SparseUploadPlanner;
import dev.veil.revive.mixin.RenderPassAccessor;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.DynamicUniformStorage;
import net.minecraft.client.renderer.chunk.*;
import net.minecraft.resources.Identifier;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

public final class VeilIndirectTerrain {
    public static final int MAX_BATCH_SIZE = 4096;
    public static final int FRAME_UBO_SIZE = 80;
    private static final EnumMap<ChunkSectionLayerGroup, java.util.function.Supplier<String>>
            PASS_LABELS = new EnumMap<>(ChunkSectionLayerGroup.class);
    private static final boolean INCREMENTAL_COMPACT_PLANS =
            Boolean.getBoolean("veil.incrementalCompactPlans");
    private static final boolean COMMAND_VISIBILITY_MASKS =
            Boolean.getBoolean("veil.commandVisibilityMasks")
                    || Boolean.getBoolean("veil.residentTerrainCommands");
    private static final EnumMap<ChunkSectionLayer, RenderPipeline> PIPELINES =
            new EnumMap<>(ChunkSectionLayer.class);
    private static final IdentityHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>, Plan> PLANS =
            new IdentityHashMap<>();
    private static final ArrayList<LayerBatches> SCRATCH_LAYERS = new ArrayList<>(3);
    private static final EnumMap<ChunkSectionLayer, LayerBatches> LAYER_SCRATCH =
            new EnumMap<>(ChunkSectionLayer.class);
    private static final EnumMap<ChunkSectionLayer, RenderPipeline> DIRECT_PIPELINES =
            new EnumMap<>(ChunkSectionLayer.class);
    private static long directMultiCalls, directMultiCommands;
    private static long commandVisibilityUploadBytes,
            commandVisibilitySavedBytes,
            commandVisibilityRanges,
            commandVisibilityFallbacks;
    private static long voxelCellCommandsPlanned;
    private static final RuntimeState STATE = new RuntimeState();
    private static final IndexedTerrainCommands.Statistics DIRECT_STATISTICS =
            new IndexedTerrainCommands.Statistics();
    private static final java.util.function.ToIntFunction<Resolved> SECTION_INDEX =
            value -> value.uploader.index();
    private static final dev.veil.revive.core.terrain.SpatialBatchPlanner.SectionCoordinates
            SECTION_COORDINATES =
                    new dev.veil.revive.core.terrain.SpatialBatchPlanner.SectionCoordinates() {
                        public int x(int index) {
                            return STATE.sectionFrame.x(index);
                        }

                        public int y(int index) {
                            return STATE.sectionFrame.y(index);
                        }

                        public int z(int index) {
                            return STATE.sectionFrame.z(index);
                        }
                    };
    private static final dev.veil.revive.core.terrain.StableBatchOrdering.Bindings<Resolved>
            BATCH_BINDINGS =
                    new dev.veil.revive.core.terrain.StableBatchOrdering.Bindings<>() {
                        public Object vertices(Resolved value) {
                            return value.vertices;
                        }

                        public Object indices(Resolved value) {
                            return value.indices;
                        }

                        public Object type(Resolved value) {
                            return value.type;
                        }

                        public int typeOrdinal(Resolved value) {
                            return value.type.ordinal();
                        }

                        public boolean lod(Resolved value) {
                            return value.lod;
                        }
                    };
    private static long calls,
            draws,
            depthCalls,
            depthDraws,
            compactedCandidateDraws,
            directCandidateDraws,
            rebuilds,
            failures,
            spatialSortedBatches,
            spatialSortedCommands;
    private static long planBuilds,
            planHits,
            planBuildNanos,
            planResolveNanos,
            planOrderNanos,
            planBatchNanos,
            planCaptureNanos,
            planSpatialNanos,
            planRegionNanos,
            planStageNanos,
            planReconcileNanos,
            planLodRebuilds,
            planIndexRebuilds,
            planOriginRebuilds,
            planCompactRebuilds,
            planCompactRetained,
            topologyPlanClears,
            indexGenerationChanges,
            regionBoundsBytesBuilt;
    private static long topologyChanges,
            topologyIdentityRetained,
            topologyPlanRebinds,
            topologyPlanRetired,
            topologyPlanUnmatched;
    private static long planSettingsClears,
            planCloseClears,
            adaptiveRegion8Batches,
            adaptiveRegion4Batches;
    private static long submissionDirectDrawCalls,
            submissionDirectDrawCommands,
            submissionDirectDrawIndices;
    private static long submissionDirectMdiCalls,
            submissionDirectMdiCommands,
            submissionFrustumMdiCalls,
            submissionFrustumMdiCommands;
    private static long submissionAutoDirectDrawCalls,
            submissionAutoDirectDrawCommands,
            submissionAutoDirectDrawIndices;
    private static long submissionAutoCompactedMdiCalls, submissionAutoCompactedMdiCommands;
    private static long submissionAutoHostGroups, submissionAutoHostCommands;
    private static long submissionAutoHostFastGroups, submissionAutoHostFastCommands;
    private static long autoHostPrepareFastFrames,
            autoHostSinglePassPrepareFrames,
            autoHostSectionTableSkips,
            autoHostLodDiscoveryFrames,
            autoHostLodProfitabilitySkips;
    private static int submissionMaxMdiDraws;
    private static long lodRevision;
    private static long defaultIndexGeneration;

    static void requireCompactPlanProof() {
        VeilCompactPlanProbe.requireComplete(planCompactRetained, planCompactRebuilds);
    }

    static PlanCounters planCounters() {
        return new PlanCounters(
                planBuilds,
                topologyChanges,
                topologyPlanRetired,
                planHits,
                planBuildNanos,
                planResolveNanos,
                planOrderNanos,
                planBatchNanos,
                planCaptureNanos,
                planSpatialNanos,
                planRegionNanos,
                planStageNanos,
                planReconcileNanos);
    }

    record PlanCounters(
            long builds,
            long topologyChanges,
            long retired,
            long hits,
            long buildNanos,
            long resolveNanos,
            long orderNanos,
            long batchNanos,
            long captureNanos,
            long spatialNanos,
            long regionNanos,
            long stageNanos,
            long reconcileNanos) {}

    private static final long SHADER_COMPAT_INTERVAL_NS = 2_000_000_000L;
    private static final long LOD_DISCOVERY_INTERVAL_NS = 250_000_000L;
    private static final WallClockCadence SHADER_COMPAT_CADENCE = new WallClockCadence();
    private static final WallClockCadence LOD_DISCOVERY_CADENCE = new WallClockCadence();

    private VeilIndirectTerrain() {}

    public static boolean lodPipelineCulls() {
        return STATE.lodPipeline != null && STATE.lodPipeline.isCull();
    }

    public static void initializePipelines() {
        if (!PIPELINES.isEmpty()) return;
        var pipelines = dev.veil.revive.client.terrain.indirect.TerrainPipelineFactory.create();
        PIPELINES.putAll(pipelines.normal());
        DIRECT_PIPELINES.putAll(pipelines.direct());
        STATE.lodPipeline = pipelines.lod();
        STATE.directLodPipeline = pipelines.directLod();
        for (int index = 0; index < STATE.packedPipelines.length; index++)
            System.arraycopy(
                    pipelines.packed()[index],
                    0,
                    STATE.packedPipelines[index],
                    0,
                    STATE.packedPipelines[index].length);
    }

    private static void validatePackedPipelines() {
        if (!VeilPackedTerrain.enabled()) return;
        var device = RenderSystem.getDevice();
        if (STATE.packedValidatedDevice == device) return;
        boolean valid = true;
        for (var variants : STATE.packedPipelines)
            for (int direct = 0; direct < variants.length; direct++)
                if (direct == 0 || STATE.directMultiAvailable)
                    valid &= device.precompilePipeline(variants[direct]).isValid();
        if (!valid) {
            VeilLodArena.close();
            VeilPackedTerrain.disable();
            ReviveMod.LOGGER.warn(
                    "Packed terrain pipelines unavailable; retaining wide terrain vertices");
        }
        STATE.packedValidatedDevice = device;
    }

    private static RenderPipeline lodPipeline(GpuBuffer vertices, boolean direct) {
        int stride = VeilPackedTerrain.stride(vertices);
        return stride == 32
                ? (direct ? STATE.directLodPipeline : STATE.lodPipeline)
                : STATE.packedPipelines[stride == 16 ? 0 : 1][direct ? 1 : 0];
    }

    private static void bindPackedTiles(RenderPass pass, Batch batch) {
        if (batch.lod && VeilPackedTerrain.stride(batch.vertices) != 32)
            pass.setUniform("VeilTiles", VeilPackedTerrain.tiles());
    }

    private static void refreshShaderCompatibility() {
        var resources = Minecraft.getInstance().getResourceManager();
        boolean managerChanged = STATE.shaderResourceManager != resources;

        long nowNanos = System.nanoTime();
        if (!managerChanged && !SHADER_COMPAT_CADENCE.due(nowNanos, SHADER_COMPAT_INTERVAL_NS))
            return;
        if (managerChanged) SHADER_COMPAT_CADENCE.scheduleFrom(nowNanos, SHADER_COMPAT_INTERVAL_NS);
        boolean previousCompatibility = STATE.compatibleShaders;
        boolean currentCompatibility =
                resources
                                .getResource(
                                        Identifier.withDefaultNamespace("shaders/core/terrain.vsh"))
                                .map(r -> r.sourcePackId().equals("vanilla"))
                                .orElse(false)
                        && resources
                                .getResource(
                                        Identifier.withDefaultNamespace("shaders/core/terrain.fsh"))
                                .map(r -> r.sourcePackId().equals("vanilla"))
                                .orElse(false);
        STATE.shaderResourceManager = resources;
        STATE.compatibleShaders = currentCompatibility;
        if (managerChanged || previousCompatibility != currentCompatibility) {
            STATE.pipelinesValidated = false;
        }
    }

    static void requireDirectMultiProbeComplete() {
        if (dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment()
                && Boolean.getBoolean("veil.directMultiProbe")
                && (!STATE.directMultiAvailable || directMultiCalls == 0))
            throw new IllegalStateException("direct multi-draw GPU probe did not execute");
    }

    private static void validatePipelines(com.mojang.blaze3d.systems.GpuDevice device) {
        if (STATE.pipelinesValidated && STATE.validatedPipelineDevice == device) return;
        if (!device.precompilePipeline(STATE.lodPipeline).isValid()) {
            throw new IllegalStateException("Invalid Veil LOD shader");
        }
        if (VeilPackedTerrain.enabled())
            for (var variants : STATE.packedPipelines)
                for (int direct = 0; direct < variants.length; direct++)
                    if ((direct == 0 || STATE.directMultiAvailable)
                            && !device.precompilePipeline(variants[direct]).isValid())
                        throw new IllegalStateException("Invalid Veil packed terrain shader");
        for (RenderPipeline pipeline : PIPELINES.values()) {
            if (!device.precompilePipeline(pipeline).isValid()) {
                throw new IllegalStateException("Invalid Veil indirect shader");
            }
        }
        STATE.directMultiAvailable =
                device.getDeviceInfo().features().multiDrawDirectInterleaved()
                        && VeilVulkanCapabilities.shaderDrawParameters();
        STATE.directMultiLimit = MAX_BATCH_SIZE;
        if (STATE.directMultiAvailable) {
            STATE.directMultiLimit =
                    Math.max(
                            1,
                            Math.min(
                                    MAX_BATCH_SIZE,
                                    device.getDeviceInfo()
                                            .limits()
                                            .maxMultiDrawDirectInterleavedDrawCount()));
        }
        if (STATE.directMultiAvailable) {
            STATE.directMultiAvailable =
                    device.precompilePipeline(STATE.directLodPipeline).isValid();
            for (var pipeline : DIRECT_PIPELINES.values())
                STATE.directMultiAvailable &= device.precompilePipeline(pipeline).isValid();
        }
        STATE.validatedPipelineDevice = device;
        STATE.pipelinesValidated = true;
    }

    public static boolean beginPrepare(Object drawGroupsIdentity) {
        STATE.clearFrameReferences();

        if (VeilShaderPackBridge.shaderPackActive()) {
            VeilShaderPackBridge.recordCustomSubmissionFastSkip();
            if (STATE.uniforms != null) STATE.uniforms.endFrame();
            return true;
        }
        VeilHzb.beginFrame();
        var deviceInfo = RenderSystem.getDevice().getDeviceInfo();
        VeilSubmissionControl.Mode mode = VeilSubmissionControl.effectiveMode();
        boolean integratedAuto =
                mode == VeilSubmissionControl.Mode.AUTO
                        && deviceInfo.type() == DeviceType.INTEGRATED;
        if (!integratedAuto) {

            refreshShaderCompatibility();
            return false;
        }

        boolean topologyChanged = STATE.topology != drawGroupsIdentity;
        boolean visibilityNeedsCustom = VeilHzb.autoNeedsCustomOpaquePath();
        boolean lodStandaloneProfitable = VeilLodArena.autoStandaloneProfitable();
        boolean lodCustomThisFrame =
                VeilAutoLodGpuAutotune.beginStandaloneFrame(
                        drawGroupsIdentity, lodStandaloneProfitable, visibilityNeedsCustom);

        long nowNanos = System.nanoTime();
        if (topologyChanged) {
            STATE.lodDiscoveryThisFrame = true;
            LOD_DISCOVERY_CADENCE.scheduleFrom(nowNanos, LOD_DISCOVERY_INTERVAL_NS);
        } else {
            STATE.lodDiscoveryThisFrame =
                    LOD_DISCOVERY_CADENCE.due(nowNanos, LOD_DISCOVERY_INTERVAL_NS);
        }
        boolean lodDiscovery =
                (!lodStandaloneProfitable || !lodCustomThisFrame) && STATE.lodDiscoveryThisFrame;

        if (!visibilityNeedsCustom && !lodCustomThisFrame && !lodDiscovery) {
            if (VeilLodArena.hasSelected() && VeilTechniqueCounters.collecting())
                autoHostLodProfitabilitySkips++;
            return true;
        }

        refreshShaderCompatibility();
        if (STATE.disabled
                || !STATE.compatibleShaders
                || !VeilShaderPackBridge.customTerrainShadersAllowed()
                || !VeilVideoConfig.on("renderer.mdi")
                || !deviceInfo.backendName().equalsIgnoreCase("Vulkan")
                || !deviceInfo.features().multiDrawIndirect()
                || !deviceInfo.features().nonZeroFirstInstance()
                || !VeilVulkanCapabilities.drawIndirectCount()) {
            return true;
        }
        return false;
    }

    public static void prepareNativeHost(ChunkSectionsToRender prepared) {
        STATE.frame = prepared;
        STATE.nativeHostPreparedFrame = prepared;
        STATE.sectionFrame = null;
        VeilSectionTable.deferUntilNeeded();
        if (VeilTechniqueCounters.collecting()) {
            autoHostPrepareFastFrames++;
            autoHostSinglePassPrepareFrames++;
            autoHostSectionTableSkips++;
        }
        if (STATE.uniforms != null) STATE.uniforms.endFrame();
    }

    static boolean submissionContainsMesh(net.minecraft.client.renderer.chunk.SectionMesh mesh) {
        if (STATE.submissionGroups == null) return false;
        for (var layer : STATE.submissionGroups.values())
            for (var draws : layer.values())
                for (var draw : draws)
                    if (draw.uniformUploaderConsumer()
                                    instanceof VeilSectionUniformUploader uploader
                            && uploader.mesh() == mesh) return true;
        return false;
    }

    public static void prepare(ChunkSectionsToRender prepared, VeilTerrainFrameData frameData) {
        prepare(prepared, frameData, prepared.drawGroupsPerLayer(), prepared.maxIndicesRequired());
    }

    static void prepare(
            ChunkSectionsToRender prepared,
            VeilTerrainFrameData frameData,
            EnumMap<
                            ChunkSectionLayer,
                            Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                    submissionGroups,
            int submissionMaxIndices) {
        STATE.submissionGroups = submissionGroups;
        STATE.submissionMaxIndices = submissionMaxIndices;
        validatePackedPipelines();
        STATE.frame = prepared;
        STATE.nativeHostPreparedFrame = null;
        STATE.sectionFrame = frameData;
        var deviceInfo = RenderSystem.getDevice().getDeviceInfo();
        if (!STATE.disabled
                && STATE.compatibleShaders
                && VeilShaderPackBridge.customTerrainShadersAllowed()
                && VeilVideoConfig.on("renderer.mdi")
                && deviceInfo.backendName().equalsIgnoreCase("Vulkan")
                && deviceInfo.features().multiDrawIndirect()
                && deviceInfo.features().nonZeroFirstInstance()
                && VeilVulkanCapabilities.drawIndirectCount()) {
            VeilSubmissionControl.Mode mode = VeilSubmissionControl.effectiveMode();
            boolean integratedAuto =
                    mode == VeilSubmissionControl.Mode.AUTO
                            && deviceInfo.type() == DeviceType.INTEGRATED;
            if (integratedAuto) {
                boolean topologyChanged = STATE.topology != prepared.drawGroupsPerLayer();
                boolean visibilityNeedsCustom = VeilHzb.autoNeedsCustomOpaquePath();
                boolean lodStandaloneProfitable = VeilLodArena.autoStandaloneProfitable();
                boolean lodCustomThisFrame =
                        lodStandaloneProfitable && VeilAutoLodGpuAutotune.useCustomThisFrame();
                boolean lodDiscovery =
                        (!lodStandaloneProfitable || !lodCustomThisFrame)
                                && STATE.lodDiscoveryThisFrame;
                if (visibilityNeedsCustom || VeilLodArena.hasSelected() || lodDiscovery) {
                    VeilLodArena.update(prepared, frameData);
                    if (lodDiscovery && VeilTechniqueCounters.collecting())
                        autoHostLodDiscoveryFrames++;
                }
                boolean customOpaqueNeeded =
                        visibilityNeedsCustom
                                || (VeilLodArena.autoStandaloneProfitable()
                                        && VeilAutoLodGpuAutotune.useCustomThisFrame());
                if (customOpaqueNeeded) {
                    VeilSectionTable.update(frameData);
                } else {
                    VeilSectionTable.deferUntilNeeded();
                    if (VeilTechniqueCounters.collecting()) {
                        autoHostSectionTableSkips++;
                        autoHostPrepareFastFrames++;
                    }
                }
            } else {
                VeilSectionTable.update(frameData);
                VeilLodArena.update(prepared, frameData);
            }
        }
        if (STATE.uniforms != null) STATE.uniforms.endFrame();
        if (STATE.topology != submissionGroups) {
            reconcilePlans(submissionGroups);
            STATE.topology = submissionGroups;
        }
        lodRevision = VeilLodArena.revision();
        if (!STATE.disabled
                && STATE.compatibleShaders
                && VeilShaderPackBridge.customTerrainShadersAllowed()
                && VeilVideoConfig.on("renderer.mdi")
                && deviceInfo.backendName().equalsIgnoreCase("Vulkan")
                && deviceInfo.features().multiDrawIndirect()
                && VeilVulkanCapabilities.drawIndirectCount()) {
            VeilRegularTerrainPipelines.validate(
                    deviceInfo.features().multiDrawDirectInterleaved()
                            && VeilVulkanCapabilities.shaderDrawParameters());
            VeilRegularPackedTerrain.update(submissionGroups);
            VeilParametricTerrainPipelines.validate(
                    deviceInfo.features().multiDrawDirectInterleaved()
                            && VeilVulkanCapabilities.shaderDrawParameters());
            VeilParametricTerrainArena.update(submissionGroups);
            VeilPairedTerrainArena.update(submissionGroups);
        }
    }

    public static boolean render(
            ChunkSectionsToRender prepared, ChunkSectionLayerGroup group, GpuSampler sampler) {
        if (STATE.nativeHostPreparedFrame == prepared) {
            if (VeilTechniqueCounters.collecting()) {
                long hostCommands = countHostDraws(prepared, group);
                submissionAutoHostGroups++;
                submissionAutoHostCommands += hostCommands;
                submissionAutoHostFastGroups++;
                submissionAutoHostFastCommands += hostCommands;
            }
            return false;
        }
        var device = RenderSystem.getDevice();
        var features = device.getDeviceInfo().features();
        if (STATE.disabled
                || !STATE.compatibleShaders
                || !VeilShaderPackBridge.customTerrainShadersAllowed()
                || !VeilVideoConfig.on("renderer.mdi")
                || !ReviveRuntime.optimizationsEnabled()
                || STATE.frame != prepared
                || STATE.sectionFrame == null
                || !device.getDeviceInfo().backendName().equalsIgnoreCase("Vulkan")
                || !features.multiDrawIndirect()
                || !features.nonZeroFirstInstance()
                || !VeilVulkanCapabilities.drawIndirectCount()
                || Minecraft.getInstance().wireframe) return false;

        VeilSubmissionControl.Mode earlySubmissionMode = VeilSubmissionControl.effectiveMode();
        boolean integratedAuto =
                earlySubmissionMode == VeilSubmissionControl.Mode.AUTO
                        && device.getDeviceInfo().type() == DeviceType.INTEGRATED;
        if (integratedAuto) {
            boolean nativeHostFastPath;
            if (group == ChunkSectionLayerGroup.OPAQUE) {
                boolean lodCustomThisFrame =
                        VeilLodArena.autoStandaloneProfitable()
                                && VeilAutoLodGpuAutotune.useCustomThisFrame();
                nativeHostFastPath = !lodCustomThisFrame && !VeilHzb.autoNeedsCustomOpaquePath();
            } else {

                nativeHostFastPath = true;
            }
            if (nativeHostFastPath) {
                if (VeilTechniqueCounters.collecting()) {
                    long hostCommands = countHostDraws(prepared, group);
                    submissionAutoHostGroups++;
                    submissionAutoHostCommands += hostCommands;
                    submissionAutoHostFastGroups++;
                    submissionAutoHostFastCommands += hostCommands;
                    if (group == ChunkSectionLayerGroup.OPAQUE
                            && VeilLodArena.hasSelected()
                            && (!VeilLodArena.autoStandaloneProfitable()
                                    || !VeilAutoLodGpuAutotune.useCustomThisFrame()))
                        autoHostLodProfitabilitySkips++;
                }
                return false;
            }
        }

        SCRATCH_LAYERS.clear();
        List<LayerBatches> layers = SCRATCH_LAYERS;

        GpuBufferSlice frameUniform;
        try {
            initializePipelines();
            validatePipelines(device);
            if (STATE.uniforms == null)
                STATE.uniforms =
                        new DynamicUniformStorage<>("Veil frame constants", FRAME_UBO_SIZE, 16);
            var auto = RenderSystem.getSequentialBuffer(PrimitiveTopology.QUADS);
            int requiredIndices =
                    Math.max(prepared.maxIndicesRequired(), STATE.submissionMaxIndices);
            GpuBuffer indexBuffer = requiredIndices == 0 ? null : auto.getBuffer(requiredIndices);
            IndexType indexType = requiredIndices == 0 ? null : auto.type();
            if (indexBuffer != STATE.defaultIndices || indexType != STATE.defaultIndexType) {

                STATE.defaultIndices = indexBuffer;
                STATE.defaultIndexType = indexType;
                defaultIndexGeneration++;
                indexGenerationChanges++;
            }
            if (STATE.sectionFrame.count() == 0) return false;
            STATE.frameUniform.set(STATE.sectionFrame);
            frameUniform = STATE.uniforms.writeUniform(STATE.frameUniform);
            for (ChunkSectionLayer layer : group.layers()) {
                RenderPipeline pipeline = PIPELINES.get(layer);
                LayerBatches layerBatches =
                        LAYER_SCRATCH.computeIfAbsent(
                                layer, key -> new LayerBatches(key, PIPELINES.get(key)));
                layerBatches.batches.clear();
                for (var list : STATE.submissionGroups.get(layer).values()) {
                    Plan plan = PLANS.get(list);
                    if (plan == null) {
                        plan = buildPlan(layer, list);
                        PLANS.put(list, plan);
                    } else {
                        boolean rebuildForIndices =
                                plan.usesDefaultIndices
                                        && plan.defaultIndexGeneration != defaultIndexGeneration;
                        boolean rebuildForLod =
                                layer == ChunkSectionLayer.SOLID
                                        && plan.checkedLodRevision != lodRevision
                                        && !plan.matchesLod(list);
                        boolean rebuildForOrigins =
                                plan.checkedOriginRevision != VeilHostRevisions.origin()
                                        && !plan.sourceState.matchesOrigins(STATE.sectionFrame);
                        boolean rebuildForCompact =
                                plan.checkedCompactRevision != VeilRegularPackedTerrain.revision()
                                        && (plan.compactState == null
                                                || !plan.compactState.matches(list));
                        if (rebuildForIndices
                                || rebuildForLod
                                || rebuildForOrigins
                                || rebuildForCompact) {
                            for (Batch batch : plan.batches) closeBatch(batch);
                            if (rebuildForIndices) planIndexRebuilds++;
                            if (rebuildForLod) planLodRebuilds++;
                            if (rebuildForOrigins) planOriginRebuilds++;
                            if (rebuildForCompact) planCompactRebuilds++;
                            plan = buildPlan(layer, list);
                            PLANS.put(list, plan);
                        } else {
                            if (plan.checkedCompactRevision
                                    != VeilRegularPackedTerrain.revision()) {
                                planCompactRetained++;
                                if (VeilCompactPlanProbe.pending()) {
                                    Plan reference = null;
                                    try {
                                        reference =
                                                buildPlan(
                                                        layer,
                                                        list,
                                                        null,
                                                        true,
                                                        plan.orderingCamera);
                                        VeilCompactPlanProbe.verify(plan, reference);
                                    } finally {
                                        if (reference != null)
                                            for (Batch batch : reference.batches) closeBatch(batch);
                                    }
                                }
                            }
                            plan.checkedCompactRevision = VeilRegularPackedTerrain.revision();
                            plan.checkedLodRevision = lodRevision;
                            plan.checkedOriginRevision = VeilHostRevisions.origin();
                            plan.defaultIndexGeneration = defaultIndexGeneration;
                            planHits++;
                        }
                    }
                    for (Batch batch : plan.batches) {
                        batch.prepared.uniform = frameUniform;
                        batch.prepared.directUniform = null;
                        batch.prepared.compacted = false;
                        layerBatches.batches.add(batch.prepared);
                    }
                }
                layers.add(layerBatches);
            }
            VeilGpuProfiler.begin(VeilGpuProfiler.Pass.UPLOAD);
            VeilGpuArena.flush();
            updateCommandVisibility(layers, STATE.sectionFrame);
            VeilGpuProfiler.end(VeilGpuProfiler.Pass.UPLOAD);
            VeilHzb.process(group, layers, sampler);

            VeilSubmissionControl.Mode preparedSubmissionMode =
                    VeilSubmissionControl.effectiveMode();
            boolean standaloneLodCustomThisFrame =
                    VeilLodArena.autoStandaloneProfitable()
                            && VeilAutoLodGpuAutotune.useCustomThisFrame();
            if (preparedSubmissionMode == VeilSubmissionControl.Mode.AUTO
                    && device.getDeviceInfo().type() == DeviceType.INTEGRATED
                    && canUseNativeHostSubmission(layers, !standaloneLodCustomThisFrame)) {
                if (VeilTechniqueCounters.collecting()) {
                    submissionAutoHostGroups++;
                    submissionAutoHostCommands += countPreparedDraws(layers);
                    if (VeilLodArena.hasSelected() && !standaloneLodCustomThisFrame)
                        autoHostLodProfitabilitySkips++;
                }
                return false;
            }
        } catch (RuntimeException failure) {
            failures++;
            STATE.disabled = true;
            ReviveMod.LOGGER.error(
                    "Veil indirect setup failed; retaining Minecraft terrain path", failure);
            return false;
        }

        var target = group.outputTarget();
        VeilGpuProfiler.Pass terrainPass =
                group == ChunkSectionLayerGroup.OPAQUE
                        ? VeilGpuProfiler.Pass.TERRAIN_OPAQUE
                        : VeilGpuProfiler.Pass.TERRAIN_TRANSLUCENT;
        VeilSubmissionControl.Mode submissionMode = VeilSubmissionControl.effectiveMode();
        VeilGpuProfiler.Pass submissionPass =
                group == ChunkSectionLayerGroup.OPAQUE
                        ? switch (submissionMode) {
                            case DIRECT_DRAWS -> VeilGpuProfiler.Pass.OPAQUE_DIRECT_DRAWS;
                            case DIRECT_MDI, DIRECT_MULTIDRAW ->
                                    VeilGpuProfiler.Pass.OPAQUE_DIRECT_MDI;
                            case FRUSTUM_MDI -> VeilGpuProfiler.Pass.OPAQUE_FRUSTUM_MDI;
                            case AUTO -> null;
                        }
                        : null;
        VeilGpuProfiler.begin(terrainPass);
        boolean autoLodCustomProbe =
                group == ChunkSectionLayerGroup.OPAQUE
                        && VeilAutoLodGpuAutotune.measureCustomThisFrame();
        if (autoLodCustomProbe) VeilGpuProfiler.begin(VeilGpuProfiler.Pass.AUTO_LOD_CUSTOM_PROBE);
        if (submissionPass != null) VeilGpuProfiler.begin(submissionPass);
        try (RenderPass pass =
                device.createCommandEncoder()
                        .createRenderPass(
                                PASS_LABELS.computeIfAbsent(
                                        group,
                                        key ->
                                                new CachedPrefixedLabel(
                                                        "Veil indirect ", key::label)),
                                target.getColorTextureView(),
                                Optional.empty(),
                                target.getDepthTextureView(),
                                OptionalDouble.empty())) {
            RenderSystem.bindDefaultUniforms(pass);
            pass.bindTexture("Sampler0", prepared.textureView(), sampler);
            pass.bindTexture(
                    "Sampler2",
                    Minecraft.getInstance().gameRenderer.lightmap(),
                    RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR));
            for (LayerBatches layer : layers) {

                pass.setPipeline(layer.pipeline);
                pass.setUniform("VeilSections", VeilSectionTable.buffer());
                pass.setUniform("VeilFrame", frameUniform);
                for (PreparedBatch ready : layer.batches)
                    if (!ready.batch.lod) drawBatch(pass, ready);

                boolean hasLod = false;
                for (PreparedBatch ready : layer.batches)
                    if (ready.batch.lod) {
                        hasLod = true;
                        break;
                    }
                if (hasLod) {
                    pass.setPipeline(STATE.lodPipeline);
                    pass.setUniform("VeilSections", VeilSectionTable.buffer());
                    pass.setUniform("VeilFrame", frameUniform);
                    for (PreparedBatch ready : layer.batches)
                        if (ready.batch.lod) drawBatch(pass, ready);
                }
            }
        }
        if (submissionPass != null) VeilGpuProfiler.end(submissionPass);
        if (autoLodCustomProbe) VeilGpuProfiler.end(VeilGpuProfiler.Pass.AUTO_LOD_CUSTOM_PROBE);
        VeilGpuProfiler.end(terrainPass);
        if (!STATE.logged && calls > 0) {
            STATE.logged = true;
            ReviveMod.LOGGER.info(
                    "Veil MDI ACTIVE: global section table + indexed indirect draws, maximum {} sections per call",
                    batchLimit());
        }
        return true;
    }

    private static long countHostDraws(
            ChunkSectionsToRender prepared, ChunkSectionLayerGroup group) {
        long count = 0L;
        for (ChunkSectionLayer layer : group.layers()) {
            for (var draws : prepared.drawGroupsPerLayer().get(layer).values())
                count += draws.size();
        }
        return count;
    }

    private static boolean canUseNativeHostSubmission(
            List<LayerBatches> layers, boolean ignoreUnprofitableLod) {
        for (LayerBatches layer : layers) {
            for (PreparedBatch ready : layer.batches) {

                if (ready.compacted || (ready.batch.lod && !ignoreUnprofitableLod)) return false;
            }
        }
        return true;
    }

    private static long countPreparedDraws(List<LayerBatches> layers) {
        long count = 0L;
        for (LayerBatches layer : layers) {
            for (PreparedBatch ready : layer.batches) count += ready.batch.sectionIndices.length;
        }
        return count;
    }

    public static boolean beginHostTerrainGpuProfile(ChunkSectionLayerGroup group) {
        if (group != ChunkSectionLayerGroup.OPAQUE) return false;
        VeilGpuProfiler.begin(VeilGpuProfiler.Pass.HOST_TERRAIN_OPAQUE);
        if (VeilAutoLodGpuAutotune.measureHostThisFrame())
            VeilGpuProfiler.begin(VeilGpuProfiler.Pass.AUTO_LOD_HOST_PROBE);
        return true;
    }

    public static void endHostTerrainGpuProfile(boolean active) {
        if (!active) return;
        if (VeilAutoLodGpuAutotune.measureHostThisFrame())
            VeilGpuProfiler.end(VeilGpuProfiler.Pass.AUTO_LOD_HOST_PROBE);
        VeilGpuProfiler.end(VeilGpuProfiler.Pass.HOST_TERRAIN_OPAQUE);
    }

    static com.mojang.blaze3d.textures.GpuTextureView texture() {
        return STATE.frame.textureView();
    }

    static void drawBatch(RenderPass pass, PreparedBatch ready) {
        submitBatch(pass, ready, false, false);
    }

    static void drawDepthBatch(RenderPass pass, PreparedBatch ready) {
        submitBatch(pass, ready, true, true);
    }

    static void drawShadowBatch(RenderPass pass, PreparedBatch ready) {
        submitBatch(pass, ready, true, false);
    }

    private static void submitBatch(
            RenderPass pass, PreparedBatch ready, boolean depthOnly, boolean countDepthStats) {
        Batch batch = ready.batch;
        boolean parametric = VeilParametricTerrainArena.formatSlot(batch.vertices) >= 0;
        if (!parametric) pass.setVertexBuffer(0, batch.vertexSlice);
        pass.setIndexBuffer(batch.indices, batch.indexType);
        VeilSubmissionControl.Mode submissionMode = VeilSubmissionControl.effectiveMode();
        boolean autoDirectDraws =
                !depthOnly
                        && submissionMode == VeilSubmissionControl.Mode.AUTO
                        && !ready.compacted
                        && RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED;
        boolean directMulti =
                !depthOnly
                        && !ready.compacted
                        && STATE.directMultiAvailable
                        && (submissionMode == VeilSubmissionControl.Mode.DIRECT_MULTIDRAW
                                || (submissionMode == VeilSubmissionControl.Mode.AUTO
                                        && !autoDirectDraws));
        if (directMulti) {
            pass.setPipeline(
                    batch.lod
                            ? lodPipeline(batch.vertices, true)
                            : VeilRegularTerrainPipelines.select(
                                    batch.vertices,
                                    batch.layer,
                                    true,
                                    DIRECT_PIPELINES.get(batch.layer)));
            bindPackedTiles(pass, batch);
            if (parametric) pass.setUniform("VeilQuadWords", batch.vertices);
            pass.setUniform("VeilSections", VeilSectionTable.buffer());
            if (ready.directUniform == null) {
                ready.directFrame.set(
                        STATE.sectionFrame, Math.toIntExact(batch.commands().offset() / 4));
                ready.directUniform = STATE.uniforms.writeUniform(ready.directFrame);
            }
            pass.setUniform("VeilFrame", ready.directUniform);
            pass.setUniform("VeilDrawCommands", batch.commands().buffer());
            pass.multiDrawIndexed(batch.directCommands, 1, 0, batch.sectionIndices.length);
            directMultiCalls++;
            directMultiCommands += batch.sectionIndices.length;
        } else {
            if (!depthOnly) {
                pass.setPipeline(
                        batch.lod
                                ? lodPipeline(batch.vertices, false)
                                : VeilRegularTerrainPipelines.select(
                                        batch.vertices,
                                        batch.layer,
                                        false,
                                        PIPELINES.get(batch.layer)));
                bindPackedTiles(pass, batch);
                if (parametric) pass.setUniform("VeilQuadWords", batch.vertices);
                pass.setUniform("VeilSections", VeilSectionTable.buffer());
                pass.setUniform("VeilFrame", ready.uniform);
            }
            if (depthOnly && parametric) pass.setUniform("VeilQuadWords", batch.vertices);
            if (!depthOnly
                    && (submissionMode == VeilSubmissionControl.Mode.DIRECT_DRAWS
                            || autoDirectDraws)) {

                var backend = ((RenderPassAccessor) (Object) pass).veil$backend();
                DIRECT_STATISTICS.reset();
                try {
                    IndexedTerrainCommands.direct(backend, batch, DIRECT_STATISTICS);
                } finally {
                    submissionDirectDrawCalls += DIRECT_STATISTICS.calls;
                    submissionDirectDrawCommands += DIRECT_STATISTICS.calls;
                    submissionDirectDrawIndices += DIRECT_STATISTICS.indices;
                    if (autoDirectDraws) {
                        submissionAutoDirectDrawCalls += DIRECT_STATISTICS.calls;
                        submissionAutoDirectDrawCommands += DIRECT_STATISTICS.calls;
                        submissionAutoDirectDrawIndices += DIRECT_STATISTICS.indices;
                    }
                }
            } else if (ready.compacted) {
                VeilIndirectCount.draw(
                        pass, batch.compacted(), batch.count(), batch.sectionIndices.length);
                if (!depthOnly && submissionMode == VeilSubmissionControl.Mode.AUTO) {
                    submissionAutoCompactedMdiCalls++;
                    submissionAutoCompactedMdiCommands += batch.sectionIndices.length;
                }
            } else {
                pass.drawIndexedIndirect(batch.commands(), batch.sectionIndices.length);
            }
        }
        if (depthOnly) {
            if (countDepthStats) {
                depthCalls++;
                depthDraws += batch.sectionIndices.length;
            }
        } else {
            calls++;
            draws += batch.sectionIndices.length;
            VeilRegularPackedTerrain.recordSubmission(batch.vertices, batch.sectionIndices.length);
            if (ready.compacted) compactedCandidateDraws += batch.sectionIndices.length;
            else directCandidateDraws += batch.sectionIndices.length;
            if (submissionMode == VeilSubmissionControl.Mode.DIRECT_MDI) {
                submissionDirectMdiCalls++;
                submissionDirectMdiCommands += batch.sectionIndices.length;
                submissionMaxMdiDraws =
                        Math.max(submissionMaxMdiDraws, batch.sectionIndices.length);
            } else if (submissionMode == VeilSubmissionControl.Mode.FRUSTUM_MDI) {
                submissionFrustumMdiCalls++;
                submissionFrustumMdiCommands += batch.sectionIndices.length;
                submissionMaxMdiDraws =
                        Math.max(submissionMaxMdiDraws, batch.sectionIndices.length);
            }
            if (batch.lod) VeilLodArena.recordDraws(batch.sectionIndices.length);
        }
    }

    private static void updateCommandVisibility(
            List<LayerBatches> layers, VeilTerrainFrameData frame) {
        if (!COMMAND_VISIBILITY_MASKS && !VeilCommandVisibilityProbe.enabled()) return;
        VeilCommandVisibilityProbe.poll();
        for (var layer : layers) {
            for (var prepared : layer.batches()) {
                Batch batch = prepared.batch();
                updateBatchVisibility(batch, frame, !VeilHzb.residentVisibilityCompactionEnabled());
                VeilCommandVisibilityProbe.capture(batch, frame);
            }
        }
    }

    static void updateBatchVisibility(Batch batch, VeilTerrainFrameData frame) {
        updateBatchVisibility(batch, frame, true);
    }

    private static void updateBatchVisibility(
            Batch batch, VeilTerrainFrameData frame, boolean uploadCounts) {
        BitSet dirty = STATE.commandVisibilityDirty;
        dirty.clear();
        for (int i = 0; i < batch.sectionIndices.length; i++) {
            int section = batch.sectionIndices[i];
            int count =
                    section >= 0 && section < frame.count() && !(frame.visibility(section) <= 0.0f)
                            ? batch.indexCounts[i]
                            : 0;
            if (batch.directCommands.get(i * 3 + 1) == count) continue;
            batch.directCommands.put(i * 3 + 1, count);
            if (uploadCounts) dirty.set(i);
        }
        if (dirty.isEmpty()) return;
        SparseUploadPlanner ranges = STATE.commandVisibilityRanges;
        ranges.plan(dirty, batch.sectionIndices.length);
        var encoder = RenderSystem.getDevice().createCommandEncoder();
        for (int range = 0; range < ranges.count(); range++) {
            int first = ranges.first(range), last = ranges.last(range);
            ByteBuffer upload = batchUploadScratch((last - first + 1) * 20);
            for (int i = first; i <= last; i++) {
                upload.putInt(batch.directCommands.get(i * 3 + 1))
                        .putInt(1)
                        .putInt(batch.firstIndices[i])
                        .putInt(batch.baseVertices[i])
                        .putInt(batch.sectionIndices[i]);
            }
            upload.flip();
            encoder.writeToBuffer(batch.commands().slice(first * 20L, upload.remaining()), upload);
        }
        commandVisibilityUploadBytes += ranges.entries() * 20L;
        commandVisibilitySavedBytes +=
                (dirty.length() - dirty.nextSetBit(0) - ranges.entries()) * 20L;
        commandVisibilityRanges += ranges.count();
        if (ranges.fallback()) commandVisibilityFallbacks++;
    }

    static void writeCommandCounts(Batch batch, boolean unmasked) {
        ByteBuffer upload = batchUploadScratch(batch.sectionIndices.length * 20);
        for (int i = 0; i < batch.sectionIndices.length; i++) {
            upload.putInt(unmasked ? batch.indexCounts[i] : batch.directCommands.get(i * 3 + 1))
                    .putInt(1)
                    .putInt(batch.firstIndices[i])
                    .putInt(batch.baseVertices[i])
                    .putInt(batch.sectionIndices[i]);
        }
        upload.flip();
        RenderSystem.getDevice().createCommandEncoder().writeToBuffer(batch.commands(), upload);
        commandVisibilityUploadBytes += batch.sectionIndices.length * 20L;
        commandVisibilityRanges++;
    }

    private static Resolved resolve(
            RenderPass.Draw<GpuBufferSlice[]> draw, VeilTerrainPlanScratch scratch) {
        if (!(draw.uniformUploaderConsumer() instanceof VeilSectionUniformUploader uploader))
            throw new IllegalStateException("Unknown terrain uniform owner");
        var lod =
                uploader.layer() == ChunkSectionLayer.SOLID
                        ? VeilLodArena.getForDraw(uploader.mesh(), uploader.index())
                        : null;
        if (lod != null)
            return resolved(
                    scratch,
                    lod.buffer(),
                    STATE.defaultIndices,
                    STATE.defaultIndexType,
                    lod.indexCount(),
                    0,
                    lod.baseVertex(),
                    uploader,
                    true,
                    null);
        var parametric = VeilParametricTerrainArena.get(uploader.mesh(), uploader.layer());
        if (parametric != null) {
            if (VeilParametricTerrainGpuProbe.enabled()
                    && uploader.mesh() instanceof VeilMeshExtras extras
                    && extras.veil$metadata() != null)
                VeilParametricTerrainGpuProbe.capture(
                        extras.veil$metadata().parametricTerrain(uploader.layer()),
                        parametric.buffer(),
                        parametric.baseVertex(),
                        STATE.defaultIndices,
                        STATE.defaultIndexType);
            return resolved(
                    scratch,
                    parametric.buffer(),
                    STATE.defaultIndices,
                    STATE.defaultIndexType,
                    parametric.indexCount(),
                    0,
                    parametric.baseVertex(),
                    uploader,
                    false,
                    null);
        }
        var paired = VeilPairedTerrainArena.get(uploader.mesh(), uploader.layer());
        if (paired != null) {
            VeilPairedTerrainArena.recordSubmission();
            return resolved(
                    scratch,
                    paired.vertices(),
                    paired.indices(),
                    paired.indexType(),
                    paired.indexCount(),
                    paired.firstIndex(),
                    paired.baseVertex(),
                    uploader,
                    false,
                    null);
        }
        var compact = VeilRegularPackedTerrain.get(uploader.mesh(), uploader.layer());
        if (compact != null)
            return resolved(
                    scratch,
                    compact.buffer(),
                    draw.indexBuffer() == null ? STATE.defaultIndices : draw.indexBuffer(),
                    draw.indexType() == null ? STATE.defaultIndexType : draw.indexType(),
                    draw.indexCount(),
                    draw.firstIndex(),
                    compact.baseVertex(),
                    uploader,
                    false,
                    null);
        return resolved(
                scratch,
                draw.vertexBuffer(),
                draw.indexBuffer() == null ? STATE.defaultIndices : draw.indexBuffer(),
                draw.indexType() == null ? STATE.defaultIndexType : draw.indexType(),
                draw.indexCount(),
                draw.firstIndex(),
                draw.baseVertex(),
                uploader,
                false,
                null);
    }

    private static void resolveAll(
            RenderPass.Draw<GpuBufferSlice[]> draw,
            List<Resolved> output,
            VeilTerrainPlanScratch scratch) {
        var resolved = resolve(draw, scratch);
        if (!resolved.lod) {
            output.add(resolved);
            return;
        }
        var slice = VeilLodArena.getForDraw(resolved.uploader.mesh(), resolved.uploader.index());
        var buckets = slice.buckets();
        if (buckets == null || !buckets.active()) {
            output.add(resolved);
            return;
        }
        int[] firstQuads = buckets.firstQuads();
        int[] quadCounts = buckets.quadCounts();
        var cells = slice.voxelCells() ? buckets.cells() : null;
        if (cells == null) {
            int first = -1;
            int quads = 0;
            for (int face = 0; face < quadCounts.length; face++) {
                int count = quadCounts[face];
                if (count == 0) continue;
                if (face < 6 && (slice.faceMask() & (1 << face)) == 0) {
                    if (quads > 0) {
                        output.add(
                                resolved(
                                        scratch,
                                        resolved.vertices,
                                        resolved.indices,
                                        resolved.type,
                                        quads * 6,
                                        0,
                                        resolved.baseVertex + first * 4,
                                        resolved.uploader,
                                        true,
                                        null));
                        first = -1;
                        quads = 0;
                    }
                    continue;
                }
                if (first < 0) first = firstQuads[face];
                quads += count;
            }
            if (quads > 0)
                output.add(
                        resolved(
                                scratch,
                                resolved.vertices,
                                resolved.indices,
                                resolved.type,
                                quads * 6,
                                0,
                                resolved.baseVertex + first * 4,
                                resolved.uploader,
                                true,
                                null));
            return;
        }
        for (int face = 0; face < quadCounts.length; face++) {
            if (face < 6 && (slice.faceMask() & (1 << face)) == 0) continue;
            for (int cell = 0; cell < 8; cell++) {
                int slot = face * 8 + cell;
                int cellQuads = cells.quadCounts()[slot];
                if (cellQuads == 0) continue;
                output.add(
                        resolved(
                                scratch,
                                resolved.vertices,
                                resolved.indices,
                                resolved.type,
                                cellQuads * 6,
                                0,
                                resolved.baseVertex + cells.firstQuads()[slot] * 4,
                                resolved.uploader,
                                true,
                                cells.bounds()[slot]));
                voxelCellCommandsPlanned++;
            }
        }
    }

    private static Plan buildPlan(
            ChunkSectionLayer layer, List<RenderPass.Draw<GpuBufferSlice[]>> list) {
        if (!VeilTerrainPlanScratch.requested()) return buildPlan(layer, list, null);
        Plan plan;
        try (var lease = VeilTerrainPlanScratch.open()) {
            plan = buildPlan(layer, list, lease.value());
        }
        if (VeilTerrainPlanScratch.verificationPending()) {
            Plan reference = null;
            try {
                reference = buildPlan(layer, list, null, true, plan.orderingCamera);
                VeilTerrainPlanScratch.verifyPlan(plan, reference);
            } catch (RuntimeException | Error failure) {
                for (Batch batch : plan.batches) closeBatch(batch);
                throw failure;
            } finally {
                if (!VeilCompactPlanProbe.pending())
                    for (Batch batch : plan.batches) batch.verificationPayload = null;
                if (reference != null) for (Batch batch : reference.batches) closeBatch(batch);
            }
        }
        return plan;
    }

    private static Plan buildPlan(
            ChunkSectionLayer layer,
            List<RenderPass.Draw<GpuBufferSlice[]>> list,
            VeilTerrainPlanScratch scratch) {
        return buildPlan(layer, list, scratch, false);
    }

    private static Plan buildPlan(
            ChunkSectionLayer layer,
            List<RenderPass.Draw<GpuBufferSlice[]>> list,
            VeilTerrainPlanScratch scratch,
            boolean reference) {
        return buildPlan(
                layer,
                list,
                scratch,
                reference,
                Minecraft.getInstance().gameRenderer.mainCamera().position());
    }

    private static Plan buildPlan(
            ChunkSectionLayer layer,
            List<RenderPass.Draw<GpuBufferSlice[]>> list,
            VeilTerrainPlanScratch scratch,
            boolean reference,
            net.minecraft.world.phys.Vec3 orderingCamera) {
        long probeStart = VeilCameraSweepProbe.enabled() ? System.nanoTime() : 0L;
        List<Resolved> buildSource =
                scratch == null ? new ArrayList<>(list.size()) : scratch.source;
        for (var draw : layer == ChunkSectionLayer.TRANSLUCENT ? list.reversed() : list)
            resolveAll(draw, buildSource, scratch);
        long resolveEnd = probeStart != 0L ? System.nanoTime() : 0L;
        buildSource =
                dev.veil.revive.core.terrain.StableBatchOrdering.order(
                        layer == ChunkSectionLayer.TRANSLUCENT,
                        layer.ordinal(),
                        buildSource,
                        scratch == null ? null : scratch.ordered,
                        BATCH_BINDINGS);
        long orderEnd = probeStart != 0L ? System.nanoTime() : 0L;
        var construction = buildBatches(layer, buildSource, !reference, orderingCamera);
        long batchEnd = probeStart != 0L ? System.nanoTime() : 0L;

        Plan plan =
                construction.complete(
                        batches -> {
                            SourceState sourceState = SourceState.capture(layer, list);
                            boolean usesDefault = false;
                            for (Batch batch : batches) {
                                if (batch.indices == STATE.defaultIndices) {
                                    usesDefault = true;
                                    break;
                                }
                            }
                            return new Plan(
                                    layer,
                                    sourceState,
                                    batches,
                                    lodRevision,
                                    layer == ChunkSectionLayer.SOLID
                                            ? LodState.capture(sourceState)
                                            : null,
                                    defaultIndexGeneration,
                                    usesDefault,
                                    orderingCamera);
                        });
        planBuilds++;
        if (probeStart != 0L) {
            long end = System.nanoTime();
            planBuildNanos += end - probeStart;
            planResolveNanos += resolveEnd - probeStart;
            planOrderNanos += orderEnd - resolveEnd;
            planBatchNanos += batchEnd - orderEnd;
            planCaptureNanos += end - batchEnd;
        }
        return plan;
    }

    private static BatchBuildTransaction<Batch> buildBatches(
            ChunkSectionLayer layer,
            List<Resolved> source,
            boolean stage,
            net.minecraft.world.phys.Vec3 orderingCamera) {
        var construction = new BatchBuildTransaction<Batch>(BATCH_RELEASE);
        try {
            int start = 0;
            while (start < source.size()) {
                var first = source.get(start);
                GpuBuffer indices = first.indices;
                IndexType type = first.type;
                int end =
                        dev.veil.revive.core.terrain.StableBatchOrdering.endOfRun(
                                source, start, batchLimit(), BATCH_BINDINGS);
                int count = end - start;
                long probeStart = VeilCameraSweepProbe.enabled() ? System.nanoTime() : 0L;
                long[] order = spatialOrder(layer, source, start, count, orderingCamera);
                long spatialEnd = probeStart != 0L ? System.nanoTime() : 0L;
                int regionShift = chooseRegionShift(layer, source, start, count, order);
                if (probeStart != 0L) {
                    long regionEnd = System.nanoTime();
                    planSpatialNanos += spatialEnd - probeStart;
                    planRegionNanos += regionEnd - spatialEnd;
                }
                int[] sectionIndices = new int[count];
                Batch batch =
                        new Batch(
                                layer,
                                first.vertices,
                                indices,
                                type,
                                sectionIndices,
                                first.lod,
                                count,
                                regionShift);
                construction.add(batch);
                if (regionShift == 2) adaptiveRegion4Batches++;
                else adaptiveRegion8Batches++;
                regionBoundsBytesBuilt += (long) batch.regionCount * 32L;
                ByteBuffer upload = batchUploadScratch(batch.allocationSize);
                TerrainBatchEncoder.encode(batch, upload, source, start, order, STATE.sectionFrame);
                VeilTerrainPlanScratch.captureBatch(batch, upload);
                long stageStart = VeilCameraSweepProbe.enabled() ? System.nanoTime() : 0L;
                if (stage) VeilGpuArena.stage(batch, upload);
                if (stageStart != 0L) planStageNanos += System.nanoTime() - stageStart;
                rebuilds++;
                start = end;
            }
            return construction;
        } catch (RuntimeException | Error failure) {
            construction.rollback(failure);
            throw failure;
        }
    }

    private static long[] spatialOrder(
            ChunkSectionLayer layer,
            List<Resolved> source,
            int start,
            int count,
            net.minecraft.world.phys.Vec3 camera) {
        if (layer == ChunkSectionLayer.TRANSLUCENT || count < 8) return null;
        long[] result =
                STATE.spatialPlanner.order(
                        layer == ChunkSectionLayer.TRANSLUCENT,
                        source,
                        start,
                        count,
                        SECTION_INDEX,
                        SECTION_COORDINATES,
                        camera.x,
                        camera.y,
                        camera.z);
        if (result != null) {
            spatialSortedBatches++;
            spatialSortedCommands += count;
        }
        return result;
    }

    private static int chooseRegionShift(
            ChunkSectionLayer layer, List<Resolved> source, int start, int count, long[] order) {
        return STATE.spatialPlanner.regionShift(
                layer == ChunkSectionLayer.TRANSLUCENT,
                source,
                start,
                count,
                order,
                SECTION_INDEX,
                SECTION_COORDINATES);
    }

    private static final java.util.function.Function<Object, TerrainPlanSource.UniformOwner>
            PLAN_OWNERS =
                    value -> value instanceof VeilSectionUniformUploader uploader ? uploader : null;

    static final class SourceState extends TerrainPlanSource {
        SourceState(ChunkSectionLayer layer, int size) {
            super(layer, size, PLAN_OWNERS);
        }

        static SourceState capture(
                ChunkSectionLayer layer, List<RenderPass.Draw<GpuBufferSlice[]>> source) {
            SourceState state = new SourceState(layer, source.size());
            state.captureDraws(source);
            state.captureOrigins(STATE.sectionFrame);
            return state;
        }
    }

    private static final class LodState {
        final SectionMesh[] meshes;
        final VeilLodArena.Slice[] slices;

        private LodState(SectionMesh[] meshes, VeilLodArena.Slice[] slices) {
            this.meshes = meshes;
            this.slices = slices;
        }

        static LodState capture(SourceState source) {
            VeilLodArena.Slice[] slices = new VeilLodArena.Slice[source.meshes.length];
            for (int i = 0; i < slices.length; i++) {
                slices[i] = VeilLodArena.getForDraw(source.meshes[i], source.sectionIndices[i]);
            }
            return new LodState(source.meshes, slices);
        }

        boolean matches(List<RenderPass.Draw<GpuBufferSlice[]>> source) {
            int n = 0;
            for (var draw : source) {
                if (!(draw.uniformUploaderConsumer()
                        instanceof VeilSectionUniformUploader uploader)) continue;
                if (n >= meshes.length
                        || meshes[n] != uploader.mesh()
                        || !Objects.equals(
                                slices[n],
                                VeilLodArena.getForDraw(uploader.mesh(), uploader.index())))
                    return false;
                n++;
            }
            return n == meshes.length;
        }
    }

    private static ByteBuffer batchUploadScratch(int minimumBytes) {
        if (STATE.batchUploadScratch == null
                || STATE.batchUploadScratch.capacity() < minimumBytes) {
            int capacity = Math.max(64, minimumBytes);
            if (capacity < (1 << 30)) {
                int highest = Integer.highestOneBit(capacity - 1);
                capacity = highest <= 0 ? 64 : highest << 1;
            }
            if (STATE.batchUploadScratch != null) MemoryUtil.memFree(STATE.batchUploadScratch);
            STATE.batchUploadScratch = MemoryUtil.memAlloc(capacity).order(ByteOrder.nativeOrder());
        }
        STATE.batchUploadScratch.clear();
        STATE.batchUploadScratch.limit(minimumBytes);
        return STATE.batchUploadScratch;
    }

    private static void reconcilePlans(
            EnumMap<
                            ChunkSectionLayer,
                            Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                    nextTopology) {
        long probeStart = VeilCameraSweepProbe.enabled() ? System.nanoTime() : 0L;
        topologyChanges++;
        if (PLANS.isEmpty()) return;

        IdentityHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>, Plan> nextPlans =
                new IdentityHashMap<>();
        IdentityHashMap<Plan, Boolean> usedPlans = new IdentityHashMap<>();
        boolean needsRebinding = false;

        for (ChunkSectionLayer layer : ChunkSectionLayer.values()) {
            Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>> groups =
                    nextTopology.get(layer);
            if (groups == null) continue;
            for (List<RenderPass.Draw<GpuBufferSlice[]>> list : groups.values()) {
                Plan direct = PLANS.get(list);
                if (direct != null && direct.layer == layer && direct.sourceState.matches(list)) {
                    nextPlans.put(list, direct);
                    usedPlans.put(direct, Boolean.TRUE);
                    topologyIdentityRetained++;
                } else {
                    needsRebinding = true;
                }
            }
        }

        Plan[] previous = null;
        if (needsRebinding) {
            for (ChunkSectionLayer layer : ChunkSectionLayer.values()) {
                Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>> groups =
                        nextTopology.get(layer);
                if (groups == null) continue;
                for (List<RenderPass.Draw<GpuBufferSlice[]>> list : groups.values()) {
                    if (nextPlans.containsKey(list)) continue;
                    if (previous == null) previous = PLANS.values().toArray(Plan[]::new);
                    Plan match = null;
                    for (Plan candidate : previous) {
                        if (usedPlans.containsKey(candidate) || candidate.layer != layer) continue;
                        if (candidate.sourceState.matches(list)) {
                            match = candidate;
                            break;
                        }
                    }
                    if (match != null) {
                        nextPlans.put(list, match);
                        usedPlans.put(match, Boolean.TRUE);
                        topologyPlanRebinds++;
                    } else {
                        topologyPlanUnmatched++;
                    }
                }
            }
        }
        IdentityHashMap<Plan, Boolean> retired = new IdentityHashMap<>();
        for (Plan plan : PLANS.values()) {
            if (!usedPlans.containsKey(plan) && retired.put(plan, Boolean.TRUE) == null) {
                for (Batch batch : plan.batches) closeBatch(batch);
                topologyPlanRetired++;
            }
        }
        PLANS.clear();
        PLANS.putAll(nextPlans);
        if (probeStart != 0L) planReconcileNanos += System.nanoTime() - probeStart;
    }

    private enum PlanClearReason {
        SETTINGS,
        CLOSE
    }

    private static void clearPlans(PlanClearReason reason) {
        for (Plan plan : PLANS.values()) for (Batch batch : plan.batches) closeBatch(batch);
        PLANS.clear();
        if (reason == PlanClearReason.SETTINGS) planSettingsClears++;
        else planCloseClears++;
    }

    private static final java.util.function.Consumer<Batch> BATCH_RELEASE =
            VeilIndirectTerrain::closeBatch;

    private static void closeBatch(Batch batch) {
        try (batch) {
            VeilGpuArena.remove(batch);
        }
    }

    public static void settingsChanged() {
        clearPlans(PlanClearReason.SETTINGS);
        STATE.invalidateTopologyAndPipelines();
        VeilLodArena.close();
        VeilRegularPackedTerrain.close();
        VeilAutoLodGpuAutotune.close();
        VeilGpuArena.reconfigure();
        VeilSectionTable.close();
    }

    public static void close() {
        clearPlans(PlanClearReason.CLOSE);
        VeilRegularPackedTerrain.close();
        STATE.close();
        VeilGpuArena.close();
        VeilSectionTable.close();
        VeilAutoLodGpuAutotune.close();
        VeilGpuProfiler.close();
        SHADER_COMPAT_CADENCE.reset();
        LOD_DISCOVERY_CADENCE.reset();
    }

    public static String telemetry() {
        return VeilRegularPackedTerrain.telemetry()
                + "submission_direct_multi_calls_total="
                + directMultiCalls
                + "\nsubmission_direct_multi_commands_total="
                + directMultiCommands
                + "\nsubmission_direct_multi_available="
                + STATE.directMultiAvailable
                + "\nmdi_calls_total="
                + calls
                + "\nmdi_draws_total="
                + (draws + depthDraws)
                + "\nmdi_candidate_commands_total="
                + draws
                + "\nmdi_compacted_candidate_commands_total="
                + compactedCandidateDraws
                + "\nmdi_direct_candidate_commands_total="
                + directCandidateDraws
                + "\nhzb_depth_mdi_calls_total="
                + depthCalls
                + "\nhzb_depth_candidate_commands_total="
                + depthDraws
                + "\nmdi_rebuilds_total="
                + rebuilds
                + "\nmdi_resident_visibility_compaction_enabled="
                + VeilHzb.residentVisibilityCompactionEnabled()
                + "\nmdi_command_visibility_upload_bytes="
                + commandVisibilityUploadBytes
                + "\nmdi_command_visibility_saved_bytes="
                + commandVisibilitySavedBytes
                + "\nmdi_command_visibility_upload_ranges="
                + commandVisibilityRanges
                + "\nmdi_command_visibility_range_fallbacks="
                + commandVisibilityFallbacks
                + "\nmdi_plan_builds_total="
                + planBuilds
                + "\nlod_voxel_cell_commands_planned_total="
                + voxelCellCommandsPlanned
                + "\nmdi_plan_hits_total="
                + planHits
                + "\nmdi_plan_lod_rebuilds_total="
                + planLodRebuilds
                + "\nmdi_plan_index_rebuilds_total="
                + planIndexRebuilds
                + "\nmdi_plan_origin_rebuilds_total="
                + planOriginRebuilds
                + "\nmdi_plan_compact_rebuilds_total="
                + planCompactRebuilds
                + "\nmdi_plan_compact_retained_total="
                + planCompactRetained
                + "\nmdi_topology_plan_clears_total="
                + topologyPlanClears
                + "\nmdi_topology_changes_total="
                + topologyChanges
                + "\nmdi_topology_identity_retained_total="
                + topologyIdentityRetained
                + "\nmdi_topology_plan_rebinds_total="
                + topologyPlanRebinds
                + "\nmdi_topology_plan_retired_total="
                + topologyPlanRetired
                + "\nmdi_topology_plan_unmatched_total="
                + topologyPlanUnmatched
                + "\nmdi_plan_settings_clears_total="
                + planSettingsClears
                + "\nmdi_plan_close_clears_total="
                + planCloseClears
                + "\nmdi_index_generation_changes_total="
                + indexGenerationChanges
                + "\nmdi_region_bounds_bytes_built_total="
                + regionBoundsBytesBuilt
                + "\nmdi_failures_total="
                + failures
                + "\nmdi_disabled="
                + STATE.disabled
                + "\nmdi_shader_compatible="
                + STATE.compatibleShaders
                + "\nmdi_batch_limit="
                + batchLimit()
                + "\nmdi_upload_scratch_bytes="
                + (STATE.batchUploadScratch == null ? 0 : STATE.batchUploadScratch.capacity())
                + "\nmdi_spatial_sorted_batches_total="
                + spatialSortedBatches
                + "\nmdi_spatial_sorted_commands_total="
                + spatialSortedCommands
                + "\nmdi_adaptive_region8_batches_total="
                + adaptiveRegion8Batches
                + "\nmdi_adaptive_region4_batches_total="
                + adaptiveRegion4Batches
                + "\nsubmission_mode="
                + VeilSubmissionControl.effectiveMode().telemetryName()
                + "\nsubmission_direct_draw_calls_total="
                + submissionDirectDrawCalls
                + "\nsubmission_direct_draw_commands_total="
                + submissionDirectDrawCommands
                + "\nsubmission_direct_draw_indices_total="
                + submissionDirectDrawIndices
                + "\nsubmission_direct_mdi_calls_total="
                + submissionDirectMdiCalls
                + "\nsubmission_direct_mdi_commands_total="
                + submissionDirectMdiCommands
                + "\nsubmission_frustum_mdi_calls_total="
                + submissionFrustumMdiCalls
                + "\nsubmission_frustum_mdi_commands_total="
                + submissionFrustumMdiCommands
                + "\nsubmission_auto_direct_draw_calls_total="
                + submissionAutoDirectDrawCalls
                + "\nsubmission_auto_direct_draw_commands_total="
                + submissionAutoDirectDrawCommands
                + "\nsubmission_auto_direct_draw_indices_total="
                + submissionAutoDirectDrawIndices
                + "\nsubmission_auto_compacted_mdi_calls_total="
                + submissionAutoCompactedMdiCalls
                + "\nsubmission_auto_compacted_mdi_commands_total="
                + submissionAutoCompactedMdiCommands
                + "\nsubmission_auto_host_groups_total="
                + submissionAutoHostGroups
                + "\nsubmission_auto_host_commands_total="
                + submissionAutoHostCommands
                + "\nsubmission_auto_host_fast_groups_total="
                + submissionAutoHostFastGroups
                + "\nsubmission_auto_host_fast_commands_total="
                + submissionAutoHostFastCommands
                + "\nsubmission_auto_prepare_fast_frames_total="
                + autoHostPrepareFastFrames
                + "\nsubmission_auto_single_pass_prepare_frames_total="
                + autoHostSinglePassPrepareFrames
                + "\nsubmission_auto_section_table_skips_total="
                + autoHostSectionTableSkips
                + "\nsubmission_auto_lod_discovery_frames_total="
                + autoHostLodDiscoveryFrames
                + "\nsubmission_auto_lod_profitability_host_skips_total="
                + autoHostLodProfitabilitySkips
                + "\nsubmission_auto_uncompacted_policy="
                + (RenderSystem.getDevice().getDeviceInfo().type() == DeviceType.INTEGRATED
                        ? "native_host_groups_single_pass_v25"
                        : "mdi")
                + "\nsubmission_max_mdi_draws="
                + submissionMaxMdiDraws
                + "\nmdi_spatial_sort_scratch_bytes="
                + STATE.spatialPlanner.scratchBytes()
                + "\n"
                + VeilTerrainDrawBridge.terrainFrameTelemetry()
                + "\n"
                + VeilLodArena.residentSelectionTelemetry()
                + "\n"
                + VeilSectionTable.telemetry()
                + VeilGpuArena.telemetry()
                + VeilGpuProfiler.telemetry()
                + VeilMaterialHost.telemetry()
                + VeilAutoLodGpuAutotune.telemetry();
    }

    private static Resolved resolved(
            VeilTerrainPlanScratch scratch,
            GpuBuffer vertices,
            GpuBuffer indices,
            IndexType type,
            int indexCount,
            int firstIndex,
            int baseVertex,
            VeilSectionUniformUploader uploader,
            boolean lod,
            float[] boundsOverride) {
        var result = scratch == null ? new Resolved() : scratch.record();
        result.vertices = vertices;
        result.indices = indices;
        result.type = type;
        result.indexCount = indexCount;
        result.firstIndex = firstIndex;
        result.baseVertex = baseVertex;
        result.uploader = uploader;
        result.lod = lod;
        result.boundsOverride = boundsOverride;
        return result;
    }

    static final class Resolved implements TerrainBatchEncoder.Draw {
        GpuBuffer vertices, indices;
        IndexType type;
        int indexCount, firstIndex, baseVertex;
        VeilSectionUniformUploader uploader;
        boolean lod;
        float[] boundsOverride;

        @Override
        public int sectionIndex() {
            return uploader.index();
        }

        @Override
        public int indexCount() {
            return indexCount;
        }

        @Override
        public int firstIndex() {
            return firstIndex;
        }

        @Override
        public int baseVertex() {
            return baseVertex;
        }

        @Override
        public float[] bounds() {
            return boundsOverride != null
                    ? boundsOverride
                    : uploader.mesh() instanceof VeilMeshExtras extras
                                    && extras.veil$metadata() != null
                            ? extras.veil$metadata().bounds(uploader.layer())
                            : null;
        }

        void clear() {
            vertices = null;
            indices = null;
            type = null;
            uploader = null;
            boundsOverride = null;
            indexCount = firstIndex = baseVertex = 0;
            lod = false;
        }

        boolean cleared() {
            return vertices == null
                    && indices == null
                    && type == null
                    && uploader == null
                    && boundsOverride == null
                    && indexCount == 0
                    && firstIndex == 0
                    && baseVertex == 0
                    && !lod;
        }
    }

    static final class Plan {
        final ChunkSectionLayer layer;
        final SourceState sourceState;
        final List<Batch> batches;
        long checkedLodRevision;
        long checkedCompactRevision = VeilRegularPackedTerrain.revision();
        final VeilCompactPlanState compactState;
        long checkedOriginRevision;
        final LodState lodState;
        long defaultIndexGeneration;
        final boolean usesDefaultIndices;
        final net.minecraft.world.phys.Vec3 orderingCamera;

        Plan(
                ChunkSectionLayer layer,
                SourceState sourceState,
                List<Batch> batches,
                long checkedLodRevision,
                LodState lodState,
                long defaultIndexGeneration,
                boolean usesDefaultIndices,
                net.minecraft.world.phys.Vec3 orderingCamera) {
            this.layer = layer;
            this.sourceState = sourceState;
            this.compactState =
                    INCREMENTAL_COMPACT_PLANS
                            ? VeilCompactPlanState.captureSource(sourceState)
                            : null;
            this.batches = batches;
            this.checkedLodRevision = checkedLodRevision;
            this.checkedOriginRevision = VeilHostRevisions.origin();
            this.lodState = lodState;
            this.defaultIndexGeneration = defaultIndexGeneration;
            this.usesDefaultIndices = usesDefaultIndices;
            this.orderingCamera = orderingCamera;
        }

        boolean matchesLod(List<RenderPass.Draw<GpuBufferSlice[]>> source) {
            return lodState == null || lodState.matches(source);
        }
    }

    static final class Batch extends TerrainBatchStorage {
        final PreparedBatch prepared;
        byte[] verificationPayload;

        Batch(
                ChunkSectionLayer layer,
                GpuBuffer vertices,
                GpuBuffer indices,
                IndexType indexType,
                int[] sectionIndices,
                boolean lod,
                int draws,
                int regionShift) {
            super(
                    layer,
                    vertices,
                    indices,
                    indexType,
                    sectionIndices,
                    lod,
                    draws,
                    regionShift,
                    VeilGpuArena.storageAlignment());
            prepared = new PreparedBatch(this, null);
        }
    }

    static final class PreparedBatch {
        final Batch batch;
        GpuBufferSlice uniform;
        final FrameUniform directFrame = new FrameUniform();
        GpuBufferSlice directUniform;
        boolean compacted;

        PreparedBatch(Batch batch, GpuBufferSlice uniform) {
            this.batch = batch;
            this.uniform = uniform;
        }

        Batch batch() {
            return batch;
        }

        GpuBufferSlice uniform() {
            return uniform;
        }
    }

    static final class LayerBatches {
        final ChunkSectionLayer layer;
        final RenderPipeline pipeline;
        final ArrayList<PreparedBatch> batches = new ArrayList<>();

        LayerBatches(ChunkSectionLayer layer, RenderPipeline pipeline) {
            this.layer = layer;
            this.pipeline = pipeline;
        }

        ChunkSectionLayer layer() {
            return layer;
        }

        RenderPipeline pipeline() {
            return pipeline;
        }

        List<PreparedBatch> batches() {
            return batches;
        }
    }

    private static int batchLimit() {
        int fallback =
                RenderSystem.getDevice().getDeviceInfo().type()
                                == com.mojang.blaze3d.systems.DeviceType.INTEGRATED
                        ? 1024
                        : 2048;
        int configured =
                VeilVideoConfig.number("renderer.mdiBatchSize", fallback, 256, MAX_BATCH_SIZE);
        return Math.min(Integer.highestOneBit(configured), STATE.directMultiLimit);
    }

    private static final class RuntimeState implements AutoCloseable {
        DynamicUniformStorage<FrameUniform> uniforms;
        final FrameUniform frameUniform = new FrameUniform();
        ChunkSectionsToRender frame;
        ChunkSectionsToRender nativeHostPreparedFrame;
        VeilTerrainFrameData sectionFrame;
        Object topology;
        EnumMap<ChunkSectionLayer, Int2ObjectOpenHashMap<List<RenderPass.Draw<GpuBufferSlice[]>>>>
                submissionGroups;
        int submissionMaxIndices;
        GpuBuffer defaultIndices;
        IndexType defaultIndexType;
        boolean disabled;
        boolean logged;
        ByteBuffer batchUploadScratch;
        final BitSet commandVisibilityDirty = new BitSet();
        final SparseUploadPlanner commandVisibilityRanges = new SparseUploadPlanner(8, 16);
        final dev.veil.revive.core.terrain.SpatialBatchPlanner spatialPlanner =
                new dev.veil.revive.core.terrain.SpatialBatchPlanner();
        RenderPipeline lodPipeline, directLodPipeline;
        final RenderPipeline[][] packedPipelines = new RenderPipeline[2][2];
        Object packedValidatedDevice;
        boolean directMultiAvailable;
        int directMultiLimit = MAX_BATCH_SIZE;
        boolean compatibleShaders = true;
        Object shaderResourceManager;
        Object validatedPipelineDevice;
        boolean pipelinesValidated;
        boolean lodDiscoveryThisFrame;

        void clearFrameReferences() {
            frame = null;
            nativeHostPreparedFrame = null;
            sectionFrame = null;
            submissionGroups = null;
            submissionMaxIndices = 0;
            lodDiscoveryThisFrame = false;
        }

        void invalidateTopologyAndPipelines() {
            topology = null;
            validatedPipelineDevice = null;
            packedValidatedDevice = null;
            pipelinesValidated = false;
        }

        @Override
        public void close() {
            if (uniforms != null) {
                uniforms.close();
                uniforms = null;
            }
            if (batchUploadScratch != null) {
                MemoryUtil.memFree(batchUploadScratch);
                batchUploadScratch = null;
            }
            spatialPlanner.clear();
            clearFrameReferences();
            topology = null;
            defaultIndices = null;
            defaultIndexType = null;
            shaderResourceManager = null;
            validatedPipelineDevice = null;
            packedValidatedDevice = null;
            pipelinesValidated = false;
        }
    }

    static final class FrameUniform implements DynamicUniformStorage.DynamicUniform {
        private VeilTerrainFrameData frameData;
        private int commandTexelBase;

        void set(VeilTerrainFrameData frameData) {
            set(frameData, 0);
        }

        void set(VeilTerrainFrameData frameData, int commandTexelBase) {
            this.frameData = frameData;
            this.commandTexelBase = commandTexelBase;
        }

        @Override
        public void write(ByteBuffer out) {
            int start = out.position();
            frameData.modelView().get(start, out);
            out.position(start + 64);
            out.putInt(frameData.atlasWidth())
                    .putInt(frameData.atlasHeight())
                    .putInt(commandTexelBase)
                    .putInt(0);
        }
    }
}
