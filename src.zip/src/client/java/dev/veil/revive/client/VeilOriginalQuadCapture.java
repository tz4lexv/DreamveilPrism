package dev.veil.revive.client;

import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

public final class VeilOriginalQuadCapture {
    public static final boolean REQUESTED = Boolean.getBoolean("veil.captureOriginalQuads");
    private static final boolean MODELS_ONLY_CAPTURE =
            Boolean.getBoolean("veil.verifyOriginalQuadReplay");
    private static final int GLOBAL_LIMIT = 65536;
    private static final int SECTION_LIMIT = 4096;
    private static final java.util.concurrent.atomic.AtomicLong GENERATION =
            new java.util.concurrent.atomic.AtomicLong(1);
    private static final java.util.concurrent.atomic.LongAdder WORLD_INVALIDATIONS =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder RESOURCE_INVALIDATIONS =
            new java.util.concurrent.atomic.LongAdder();
    private static final AtomicInteger RETAINED = new AtomicInteger();
    private static final AtomicInteger RETAINED_MODELS = new AtomicInteger();
    private static final AtomicInteger RETAINED_SPRITES = new AtomicInteger();
    private static final java.util.LinkedHashSet<Snapshot> RESIDENT =
            new java.util.LinkedHashSet<>();
    private static final java.util.concurrent.atomic.LongAdder EVICTED =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder COPIED =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder PUBLISHED =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder CLOSED =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder PUBLISHED_QUADS =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder CLOSED_QUADS =
            new java.util.concurrent.atomic.LongAdder();
    private static final java.util.concurrent.atomic.LongAdder STALE =
            new java.util.concurrent.atomic.LongAdder();
    private static final ThreadLocal<ArrayDeque<Builder>> SCOPES = new ThreadLocal<>();

    private VeilOriginalQuadCapture() {}

    public interface Geometry {}

    record ModelInput(
            Quad probe,
            int from,
            int to,
            List<net.minecraft.client.renderer.texture.TextureAtlasSprite> sprites) {}

    public record Quad(
            long position,
            BlockState state,
            BlockStateModel model,
            float x,
            float y,
            float z,
            Direction cullFace,
            boolean ambient,
            boolean neighborLight,
            Geometry geometry,
            VeilModelGeometryStamp modelGeometry) {
        public Quad(
                long position,
                BlockState state,
                BlockStateModel model,
                float x,
                float y,
                float z,
                Direction cullFace,
                boolean ambient,
                boolean neighborLight,
                Geometry geometry) {
            this(position, state, model, x, y, z, cullFace, ambient, neighborLight, geometry, null);
        }
    }

    public static boolean sameBlock(Quad a, Quad b) {
        return a.position() == b.position()
                && a.state() == b.state()
                && a.model() == b.model()
                && Float.floatToRawIntBits(a.x()) == Float.floatToRawIntBits(b.x())
                && Float.floatToRawIntBits(a.y()) == Float.floatToRawIntBits(b.y())
                && Float.floatToRawIntBits(a.z()) == Float.floatToRawIntBits(b.z());
    }

    public static int blockEnd(List<Quad> quads, int start) {
        var first = quads.get(start);
        int end = start + 1;
        while (end < quads.size() && sameBlock(first, quads.get(end))) end++;
        return end;
    }

    public static void begin(net.minecraft.core.SectionPos section) {
        begin(REQUESTED, section.asLong());
    }

    public static void invalidate() {
        GENERATION.incrementAndGet();
    }

    public static void worldChanged() {
        WORLD_INVALIDATIONS.increment();
        invalidate();
    }

    public static void resourcesChanged() {
        RESOURCE_INVALIDATIONS.increment();
        invalidate();
    }

    static void begin(boolean enabled) {
        begin(enabled, 0L);
    }

    static void begin(boolean enabled, long section) {
        var stack = SCOPES.get();
        if (stack == null) {
            if (!enabled) return;
            stack = new ArrayDeque<>();
            SCOPES.set(stack);
        }
        stack.push(new Builder(enabled, enabled ? Stamp.capture(section) : null));
    }

    public static Suppression suspend() {
        var stack = SCOPES.get();
        if (stack == null) return Suppression.NONE;
        var builder = new Builder(false, null);
        var suppression = new Suppression(Thread.currentThread(), builder);
        stack.push(builder);
        return suppression;
    }

    public static final class Suppression implements AutoCloseable {
        private static final Suppression NONE = new Suppression(null, null);
        private Thread owner;
        private Builder builder;

        private Suppression(Thread owner, Builder builder) {
            this.owner = owner;
            this.builder = builder;
        }

        @Override
        public void close() {
            if (builder == null) return;
            var stack = SCOPES.get();
            if (Thread.currentThread() != owner || stack == null || stack.peek() != builder)
                throw new IllegalStateException(
                        "Original quad suppression closed outside its scope");
            end(false);
            builder = null;
            owner = null;
        }
    }

    public static boolean active() {
        var stack = SCOPES.get();
        return stack != null && stack.peek().enabled && !stack.peek().exhausted;
    }

    public static void mixedGeometry() {
        var stack = SCOPES.get();
        if (stack == null) return;
        var builder = stack.peek();
        builder.modelsOnly = false;
        if (MODELS_ONLY_CAPTURE) {
            builder.discard();
            builder.exhausted = true;
        }
    }

    static void modelGeometry(VeilModelGeometryStamp stamp) {
        var stack = SCOPES.get();
        if (stack != null && !stack.isEmpty()) stack.peek().modelGeometry = stamp;
    }

    static void beginModel(
            BlockPos position,
            BlockState state,
            BlockStateModel model,
            VeilModelGeometryStamp stamp) {
        if (!active()) return;
        var builder = SCOPES.get().peek();
        if (builder.pending != null) throw new IllegalStateException("Unfinished captured model");
        builder.modelGeometry = stamp;
        builder.pending =
                new Quad(
                        position.asLong(),
                        state,
                        model,
                        position.getX() & 15,
                        position.getY() & 15,
                        position.getZ() & 15,
                        null,
                        false,
                        false,
                        null,
                        stamp);
        builder.modelFrom = builder.quads.size();
    }

    static void recordSprite(net.minecraft.client.renderer.texture.TextureAtlasSprite sprite) {
        if (sprite == null || !active()) return;
        var builder = SCOPES.get().peek();
        if (builder.pending == null) return;
        if (builder.sprites.containsKey(sprite)) return;
        if (builder.spriteCount >= SECTION_LIMIT || !reserve(RETAINED_SPRITES)) {
            builder.discard();
            builder.exhausted = true;
            return;
        }
        builder.sprites.put(sprite, Boolean.TRUE);
        builder.spriteCount++;
    }

    static void finishModelGeometry(VeilModelGeometryStamp current) {
        var stack = SCOPES.get();
        if (stack == null || stack.isEmpty()) return;
        var builder = stack.peek();
        var previous = builder.modelGeometry;
        builder.modelGeometry = null;
        if (previous != null && !previous.matches(current)) {
            builder.discard();
            builder.exhausted = true;
        }
        if (builder.pending != null && !builder.exhausted) {
            if (builder.models.size() >= SECTION_LIMIT || !reserve(RETAINED_MODELS)) {
                builder.discard();
                builder.exhausted = true;
                return;
            }
            boolean added = false;
            try {
                builder.models.add(
                        new ModelInput(
                                builder.modelFrom < builder.quads.size()
                                        ? builder.quads.get(builder.modelFrom)
                                        : builder.pending,
                                builder.modelFrom,
                                builder.quads.size(),
                                List.copyOf(builder.sprites.keySet())));
                added = true;
            } finally {
                if (!added) RETAINED_MODELS.decrementAndGet();
            }
        }
        builder.pending = null;
        builder.sprites.clear();
    }

    public static void record(
            BlockPos position,
            BlockState state,
            BlockStateModel model,
            float x,
            float y,
            float z,
            Direction face,
            boolean ambient,
            Supplier<? extends Geometry> copy) {
        record(position, state, model, x, y, z, face, ambient, false, copy);
    }

    public static void record(
            BlockPos position,
            BlockState state,
            BlockStateModel model,
            float x,
            float y,
            float z,
            Direction face,
            boolean ambient,
            boolean neighborLight,
            Supplier<? extends Geometry> copy) {
        if (!active()) return;
        var builder = SCOPES.get().peek();
        if (builder.quads.size() >= SECTION_LIMIT || !reserve()) {
            builder.discard();
            builder.exhausted = true;
            return;
        }
        boolean added = false;
        try {
            var geometry = copy.get();
            if (geometry == null) {
                builder.discard();
                builder.exhausted = true;
                return;
            }
            builder.quads.add(
                    new Quad(
                            position.asLong(),
                            state,
                            model,
                            x,
                            y,
                            z,
                            face,
                            ambient,
                            neighborLight,
                            geometry,
                            builder.modelGeometry));
            added = true;
            COPIED.increment();
        } finally {
            if (!added) RETAINED.decrementAndGet();
        }
    }

    public static Snapshot end(boolean success) {
        var stack = SCOPES.get();
        if (stack == null) return null;
        var builder = stack.pop();
        if (stack.isEmpty()) SCOPES.remove();
        if (!success || !builder.enabled || builder.exhausted || builder.pending != null) {
            builder.discard();
            return null;
        }
        if (builder.quads.isEmpty() && builder.models.isEmpty()) return null;
        if (!builder.stamp.current(builder.stamp.section)) {
            STALE.increment();
            builder.discard();
            return null;
        }
        try {
            var snapshot =
                    new Snapshot(
                            builder.stamp,
                            builder.modelsOnly,
                            List.copyOf(builder.quads),
                            List.copyOf(builder.models),
                            builder.spriteCount);
            synchronized (RESIDENT) {
                RESIDENT.add(snapshot);
            }
            return snapshot;
        } catch (RuntimeException | Error failure) {
            builder.discard();
            throw failure;
        }
    }

    private static boolean reserve() {
        return reserve(RETAINED);
    }

    private static boolean reserve(AtomicInteger budget) {
        if (reserve(budget, 1)) return true;
        for (int attempt = 0; attempt < 32; attempt++) {
            Snapshot candidate;
            synchronized (RESIDENT) {
                if (RESIDENT.isEmpty()) return false;
                candidate = RESIDENT.removeFirst();
            }
            candidate.evictUnused();
            if (reserve(budget, 1)) return true;
        }
        return false;
    }

    private static boolean reserve(AtomicInteger budget, int amount) {
        int count = budget.get();
        while (count <= GLOBAL_LIMIT - amount) {
            if (budget.compareAndSet(count, count + amount)) return true;
            count = budget.get();
        }
        return false;
    }

    public static void published(Snapshot snapshot) {
        if (snapshot != null) {
            PUBLISHED.increment();
            PUBLISHED_QUADS.add(snapshot.size());
        }
    }

    public static void requireComplete() {
        if (!REQUESTED) return;
        if (COPIED.sum() < 1024
                || PUBLISHED_QUADS.sum() < 1024
                || CLOSED_QUADS.sum() == 0
                || WORLD_INVALIDATIONS.sum() == 0
                || RESOURCE_INVALIDATIONS.sum() == 0)
            throw new IllegalStateException("Original quad capture lifecycle not exercised");
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil original quad capture: PASS (copied={} published={} closed={} retained={} published_quads={} closed_quads={} stale={} world_invalidations={} resource_invalidations={})",
                COPIED.sum(),
                PUBLISHED.sum(),
                CLOSED.sum(),
                RETAINED.get(),
                PUBLISHED_QUADS.sum(),
                CLOSED_QUADS.sum(),
                STALE.sum(),
                WORLD_INVALIDATIONS.sum(),
                RESOURCE_INVALIDATIONS.sum());
    }

    static int retained() {
        return RETAINED.get();
    }

    static int retainedModels() {
        return RETAINED_MODELS.get();
    }

    static int retainedSprites() {
        return RETAINED_SPRITES.get();
    }

    static long evicted() {
        return EVICTED.sum();
    }

    public static final class Snapshot implements AutoCloseable {
        private final Stamp stamp;
        private final boolean modelsOnly;
        private List<Quad> quads;
        private List<ModelInput> models;
        private final int spriteCount;
        private int readers;
        private boolean closed;

        private Snapshot(
                Stamp stamp,
                boolean modelsOnly,
                List<Quad> quads,
                List<ModelInput> models,
                int spriteCount) {
            this.stamp = stamp;
            this.modelsOnly = modelsOnly;
            this.quads = quads;
            this.models = models;
            this.spriteCount = spriteCount;
        }

        public synchronized boolean current(long section) {
            return !closed && stamp.current(section);
        }

        public long section() {
            return stamp.section;
        }

        public boolean modelsOnly() {
            return modelsOnly;
        }

        public synchronized boolean attributesCurrent() {
            return current(stamp.section)
                    && stamp.attributes
                            == VeilMinecraftTerrainBridge.sectionRevision(stamp.section);
        }

        public synchronized Lease acquire(long section) {
            if (!current(section)) return null;
            var lease = new Lease(this, quads, models);
            readers = Math.incrementExact(readers);
            synchronized (RESIDENT) {
                if (RESIDENT.contains(this)) RESIDENT.addLast(this);
            }
            return lease;
        }

        private synchronized void evictUnused() {
            if (closed) return;
            if (readers != 0) {
                synchronized (RESIDENT) {
                    RESIDENT.addLast(this);
                }
                return;
            }
            EVICTED.increment();
            close();
        }

        synchronized Snapshot duplicateForRetirementProbe() {
            if (!current(stamp.section) || !reserve(RETAINED, quads.size())) return null;
            boolean heldModels = false, heldSprites = false, transferred = false;
            try {
                if (!(heldModels = reserve(RETAINED_MODELS, models.size()))
                        || !(heldSprites = reserve(RETAINED_SPRITES, spriteCount))) return null;
                var result = new Snapshot(stamp, modelsOnly, quads, models, spriteCount);
                transferred = true;
                return result;
            } finally {
                if (!transferred) {
                    RETAINED.addAndGet(-quads.size());
                    if (heldModels) RETAINED_MODELS.addAndGet(-models.size());
                    if (heldSprites) RETAINED_SPRITES.addAndGet(-spriteCount);
                }
            }
        }

        private synchronized int size() {
            if (closed) throw new IllegalStateException("Closed original quad snapshot");
            return quads.size();
        }

        @Override
        public synchronized void close() {
            if (closed) return;
            closed = true;
            synchronized (RESIDENT) {
                RESIDENT.remove(this);
            }
            CLOSED.increment();
            releaseIfUnused();
        }

        private synchronized void readerClosed() {
            if (readers <= 0) throw new IllegalStateException("Original quad reader underflow");
            readers--;
            releaseIfUnused();
        }

        private void releaseIfUnused() {
            if (!closed || readers != 0 || quads == null) return;
            RETAINED.addAndGet(-quads.size());
            RETAINED_MODELS.addAndGet(-models.size());
            RETAINED_SPRITES.addAndGet(-spriteCount);
            CLOSED_QUADS.add(quads.size());
            quads = null;
            models = null;
        }
    }

    public static final class Lease implements AutoCloseable {
        private Snapshot owner;
        private List<Quad> quads;
        private List<ModelInput> models;

        private Lease(Snapshot owner, List<Quad> quads, List<ModelInput> models) {
            this.owner = owner;
            this.quads = quads;
            this.models = models;
        }

        synchronized List<ModelInput> models() {
            if (owner == null) throw new IllegalStateException("Closed original model reader");
            return models;
        }

        public synchronized List<Quad> quads() {
            if (owner == null) throw new IllegalStateException("Closed original quad reader");
            return quads;
        }

        public synchronized boolean current() {
            return owner != null && owner.current(owner.section());
        }

        @Override
        public synchronized void close() {
            if (owner == null) return;
            owner.readerClosed();
            owner = null;
            quads = null;
            models = null;
        }
    }

    private record Stamp(
            long section, long generation, long global, long geometry, long attributes) {
        static Stamp capture(long section) {
            return new Stamp(
                    section,
                    GENERATION.get(),
                    VeilHostRevisions.global(),
                    VeilMinecraftTerrainBridge.geometrySectionRevision(section),
                    VeilMinecraftTerrainBridge.sectionRevision(section));
        }

        boolean current(long requestedSection) {
            return requestedSection == section
                    && generation == GENERATION.get()
                    && global == VeilHostRevisions.global()
                    && geometry == VeilMinecraftTerrainBridge.geometrySectionRevision(section)
                    && global == VeilHostRevisions.global()
                    && generation == GENERATION.get();
        }
    }

    private static final class Builder {
        final boolean enabled;
        final Stamp stamp;
        final List<Quad> quads = new ArrayList<>();
        final List<ModelInput> models = new ArrayList<>();
        final java.util.IdentityHashMap<
                        net.minecraft.client.renderer.texture.TextureAtlasSprite, Boolean>
                sprites = new java.util.IdentityHashMap<>();
        Quad pending;
        int modelFrom, spriteCount;
        boolean exhausted;
        boolean modelsOnly = true;
        VeilModelGeometryStamp modelGeometry;

        Builder(boolean enabled, Stamp stamp) {
            this.enabled = enabled;
            this.stamp = stamp;
        }

        void discard() {
            RETAINED.addAndGet(-quads.size());
            RETAINED_MODELS.addAndGet(-models.size());
            RETAINED_SPRITES.addAndGet(-spriteCount);
            quads.clear();
            models.clear();
            sprites.clear();
            spriteCount = 0;
            pending = null;
        }
    }
}
