package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.sugar.Local;

import dev.veil.revive.client.VeilCompilerCancellationProbe;
import dev.veil.revive.core.terrain.CompileCancellationScope;

import net.minecraft.client.renderer.SectionBufferBuilderPack;
import net.minecraft.client.renderer.chunk.CompiledSectionMesh;
import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
        targets =
                "net.minecraft.client.renderer.chunk.SectionRenderDispatcher$RenderSection$CompileTask")
public abstract class OwnSectionCompilerCancellationMixin {
    @WrapMethod(method = "doTask")
    private SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult
            veil$bindCancellation(
                    SectionBufferBuilderPack buffers,
                    Operation<SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult>
                            original) {
        var token = ((SectionTaskAccessor) (Object) this).veil$isCancelled();
        boolean previousScope = CompileCancellationScope.bound();
        boolean abortedTask = false;
        if (VeilCompilerCancellationProbe.enabled())
            VeilCompilerCancellationProbe.taskStarted(
                    ((SectionTaskAccessor) (Object) this).veil$getRenderOrigin(), token);
        try (var scope = CompileCancellationScope.bind(token)) {
            try {
                return original.call(buffers);
            } catch (CompileCancellationScope.Aborted aborted) {
                if (!token.get() || aborted.getSuppressed().length != 0) throw aborted;
                abortedTask = true;
                return SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult
                        .CANCELLED;
            }
        } finally {
            VeilCompilerCancellationProbe.taskFinished(
                    abortedTask, CompileCancellationScope.bound() == previousScope);
        }
    }

    @Inject(
            method = "doTask",
            at =
                    @At(
                            value = "NEW",
                            target = "net/minecraft/client/renderer/chunk/CompiledSectionMesh"),
            cancellable = true,
            require = 1)
    private void veil$rejectCancelledResult(
            SectionBufferBuilderPack buffers,
            CallbackInfoReturnable<
                            SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult>
                    callback,
            @Local SectionCompiler.Results results) {
        if (((SectionTaskAccessor) (Object) this).veil$isCancelled().get()) {
            results.release();
            callback.setReturnValue(
                    SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult.CANCELLED);
        }
    }

    @Inject(
            method = "doTask",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/client/renderer/chunk/SectionRenderDispatcher$RenderSection;setSectionMesh(Lnet/minecraft/client/renderer/chunk/SectionMesh;)Lnet/minecraft/client/renderer/chunk/SectionMesh;"),
            cancellable = true,
            require = 1)
    private void veil$rejectCancelledEmptyMesh(
            SectionBufferBuilderPack buffers,
            CallbackInfoReturnable<
                            SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult>
                    callback,
            @Local CompiledSectionMesh mesh) {
        if (((SectionTaskAccessor) (Object) this).veil$isCancelled().get()) {
            mesh.close();
            callback.setReturnValue(
                    SectionRenderDispatcher.RenderSection.SectionTask.SectionTaskResult.CANCELLED);
        }
    }
}
