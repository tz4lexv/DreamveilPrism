package dev.veil.revive.client;

import dev.veil.revive.client.shaderpack.compilation.ShaderCompilationCache;
import dev.veil.revive.client.shaderpack.compilation.ShaderCompilationCache.CompiledKey;
import dev.veil.revive.client.shaderpack.compilation.ShaderCompilationCache.SourceEntry;
import dev.veil.revive.client.shaderpack.compilation.ShaderCompilationCache.SourceKey;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public final class VeilShaderLibrary {
    private final VeilShaderAssets assets;
    private final VeilShaderMetrics metrics;
    private final int capacity;
    private final ShaderCompilationCache cache;
    private Map<VeilShaderId, VeilShaderProgram> programs = Map.of();
    private long generation;
    private VeilSpirvTools tools;

    public VeilShaderLibrary(VeilShaderAssets assets, VeilShaderMetrics metrics, int capacity) {
        this.assets = Objects.requireNonNull(assets, "assets");
        this.metrics = Objects.requireNonNull(metrics, "metrics");
        if (capacity < 1 || capacity > 4096)
            throw new IllegalArgumentException("Invalid shader cache capacity");
        this.capacity = capacity;
        this.cache = new ShaderCompilationCache(capacity);
    }

    public synchronized Map<VeilShaderId, VeilShaderProgram> prepare(
            Map<VeilShaderId, Map<VeilShaderStage, VeilShaderId>> declarations) throws IOException {
        return prepare(declarations, Map.of());
    }

    public synchronized Map<VeilShaderId, VeilShaderProgram> prepare(
            Map<VeilShaderId, Map<VeilShaderStage, VeilShaderId>> declarations,
            Map<VeilShaderId, Map<VeilShaderStage, String>> entryPoints)
            throws IOException {
        if (declarations.isEmpty() || declarations.size() > capacity) {
            throw new IllegalArgumentException("Program count must be between 1 and " + capacity);
        }
        long nextGeneration = Math.incrementExact(generation);
        var candidate = new LinkedHashMap<VeilShaderId, VeilShaderProgram>();
        for (var declaration : declarations.entrySet()) {
            var binaries = new EnumMap<VeilShaderStage, VeilSpirvBinary>(VeilShaderStage.class);
            var merged = new java.util.ArrayList<VeilShaderInterface>();
            var dependencies = new LinkedHashMap<VeilShaderId, String>();
            for (var stage : declaration.getValue().entrySet()) {
                SourceEntry source =
                        load(
                                new SourceKey(
                                        stage.getValue(),
                                        stage.getKey(),
                                        entryPoints
                                                .getOrDefault(declaration.getKey(), Map.of())
                                                .getOrDefault(stage.getKey(), "main")));
                binaries.put(stage.getKey(), source.binary());
                source.dependencies()
                        .forEach(
                                (id, hash) -> {
                                    String old = dependencies.putIfAbsent(id, hash);
                                    if (old != null && !old.equals(hash)) {
                                        throw new IllegalStateException(
                                                "Asset changed during shader transaction: " + id);
                                    }
                                });
                String hash =
                        source.binary().contentHash()
                                + ":"
                                + stage.getKey()
                                + ":"
                                + source.binary().entryPoint();
                VeilShaderInterface reflected = cache.reflected(hash);
                if (reflected == null) {
                    reflected = VeilSpirvReflection.reflect(source.binary());
                    metrics.reflectionTotal.increment();
                    cache.reflected(hash, reflected);
                } else {
                    metrics.reflectionHits.increment();
                }
                merged.add(reflected);
            }
            candidate.put(
                    declaration.getKey(),
                    new VeilShaderProgram(
                            declaration.getKey(),
                            nextGeneration,
                            binaries,
                            VeilShaderInterface.merge(merged.toArray(VeilShaderInterface[]::new)),
                            dependencies));
        }
        for (VeilShaderProgram program : candidate.values()) {
            if (!unchanged(program.dependencies()))
                throw new IOException("Shader assets changed during transaction: " + program.id());
        }
        generation = nextGeneration;
        programs = Map.copyOf(candidate);
        return programs;
    }

    public synchronized VeilShaderProgram lookup(VeilShaderId id) {
        return programs.get(id);
    }

    byte[] readAsset(VeilShaderId id) throws IOException {
        return assets.read(id);
    }

    private SourceEntry load(SourceKey key) throws IOException {
        if (tools == null)
            tools =
                    new VeilSpirvTools(
                            Boolean.getBoolean("veil.shaderDebug")
                                    ? VeilSpirvTools.Mode.DEBUG
                                    : VeilSpirvTools.Mode.RELEASE);
        SourceEntry previous = cache.source(key);
        if (!key.id().path().endsWith(".slang")
                && previous != null
                && unchanged(previous.dependencies())) {
            metrics.shaderHits.increment();
            return previous;
        }
        metrics.shaderMisses.increment();
        SourceEntry loaded;
        if (key.id().path().endsWith(".spv")) {
            byte[] bytes = assets.read(key.id());
            if (bytes.length > VeilShaderAssets.MAX_SHADER_ASSET_BYTES)
                throw new IOException("SPIR-V asset exceeds 4 MiB: " + key.id());
            String hash = VeilShaderAssets.hash(bytes);
            loaded =
                    new SourceEntry(
                            tools.process(
                                    new VeilSpirvBinary(
                                            bytes,
                                            key.stage(),
                                            key.id().toString(),
                                            key.entryPoint(),
                                            hash)),
                            Map.of(key.id(), hash));
        } else if (key.id().path().endsWith(".slang")) {
            var snapshot = VeilSlangSources.capture(assets, key.id());
            var cacheKey =
                    new CompiledKey(
                            snapshot.hash(),
                            snapshot.dependencies(),
                            key.stage(),
                            key.entryPoint(),
                            VeilSlangCompiler.identity() + ";" + tools.identity());
            VeilSpirvBinary binary = cache.binary(cacheKey);
            if (binary == null) {
                long start = System.nanoTime();
                metrics.compileTotal.increment();
                try {
                    binary =
                            tools.process(
                                    VeilSlangCompiler.compile(
                                            snapshot, key.id(), key.stage(), key.entryPoint()));
                    cache.binary(cacheKey, binary);
                } catch (IOException | RuntimeException failure) {
                    metrics.compileFailures.increment();
                    throw failure;
                } finally {
                    metrics.compileNanos.add(System.nanoTime() - start);
                }
            } else metrics.shaderHits.increment();
            loaded = new SourceEntry(binary, snapshot.dependencies());
        } else {
            var expanded = VeilShaderIncludes.preprocess(assets, key.id(), key.stage());
            var cacheKey =
                    new CompiledKey(
                            VeilShaderAssets.hash(
                                    expanded.source().getBytes(StandardCharsets.UTF_8)),
                            expanded.dependencies(),
                            key.stage(),
                            "main",
                            tools.identity());
            VeilSpirvBinary binary = cache.binary(cacheKey);
            if (binary == null) {
                long start = System.nanoTime();
                metrics.compileTotal.increment();
                try {
                    binary = tools.compile(key.id().toString(), expanded.source(), key.stage());
                    cache.binary(cacheKey, binary);
                } catch (IOException | RuntimeException failure) {
                    metrics.compileFailures.increment();
                    throw failure;
                } finally {
                    metrics.compileNanos.add(System.nanoTime() - start);
                }
            } else {
                metrics.shaderHits.increment();
            }
            loaded = new SourceEntry(binary, expanded.dependencies());
        }
        cache.source(key, loaded);
        return loaded;
    }

    private boolean unchanged(Map<VeilShaderId, String> dependencies) throws IOException {
        for (var dependency : dependencies.entrySet()) {
            if (!VeilShaderAssets.hash(assets.read(dependency.getKey()))
                    .equals(dependency.getValue())) return false;
        }
        return true;
    }
}
