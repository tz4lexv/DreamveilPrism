package dev.veil.revive.client.shaderpack.preparation;

import dev.veil.api.VeilResourceUsage;
import dev.veil.api.VeilTransfer;
import dev.veil.revive.client.VeilRenderGraph;
import dev.veil.revive.client.VeilShaderPack.Pass;
import dev.veil.revive.client.VeilShaderPack.Resource;
import dev.veil.revive.client.graphics.resources.TransferBufferRules;
import dev.veil.revive.client.graphics.resources.TransferClearRules;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class TransferPlanBuilder {
    private final Map<String, Resource> resources;

    public TransferPlanBuilder(Map<String, Resource> resources) {
        this.resources = resources;
    }

    public VeilRenderGraph.Pass prepare(Pass pass) {
        var uses = new LinkedHashMap<String, VeilRenderGraph.Access>();
        var graphUses = new ArrayList<VeilRenderGraph.Use>();
        for (VeilTransfer operation : pass.transfers()) {
            switch (operation.kind()) {
                case BUFFER_COPY -> {
                    Resource source =
                            transferBuffer(
                                    pass,
                                    operation.source(),
                                    VeilResourceUsage.TRANSFER_SOURCE,
                                    false);
                    Resource destination =
                            transferBuffer(
                                    pass,
                                    operation.destination(),
                                    VeilResourceUsage.TRANSFER_DESTINATION,
                                    true);
                    requireRange(pass, source, operation.sourceOffset(), operation.size());
                    requireRange(
                            pass, destination, operation.destinationOffset(), operation.size());
                    if (source == destination
                            && operation.sourceOffset()
                                    < operation.destinationOffset() + operation.size()
                            && operation.destinationOffset()
                                    < operation.sourceOffset() + operation.size())
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + ": overlapping self buffer copies are unsupported");
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            source.name(),
                            VeilRenderGraph.Access.BUFFER_TRANSFER_READ,
                            VeilRenderGraph.Subresource.buffer(
                                    operation.sourceOffset(), operation.size()));
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            destination.name(),
                            VeilRenderGraph.Access.BUFFER_TRANSFER_WRITE,
                            bufferWriteRange(
                                    destination, operation.destinationOffset(), operation.size()));
                }
                case BUFFER_FILL -> {
                    Resource destination =
                            transferBuffer(
                                    pass,
                                    operation.destination(),
                                    VeilResourceUsage.TRANSFER_DESTINATION,
                                    true);
                    requireRange(
                            pass, destination, operation.destinationOffset(), operation.size());
                    TransferBufferRules.validateFill(
                            operation.destinationOffset(), operation.size());
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            destination.name(),
                            VeilRenderGraph.Access.BUFFER_TRANSFER_WRITE,
                            bufferWriteRange(
                                    destination, operation.destinationOffset(), operation.size()));
                }
                case BUFFER_TO_IMAGE -> {
                    Resource source =
                            transferBuffer(
                                    pass,
                                    operation.source(),
                                    VeilResourceUsage.TRANSFER_SOURCE,
                                    false);
                    Resource destination =
                            transferImage(
                                    pass,
                                    operation.destination(),
                                    VeilResourceUsage.TRANSFER_DESTINATION,
                                    true);
                    validateBufferImage(
                            pass,
                            source,
                            operation.sourceOffset(),
                            destination,
                            operation.destinationRegion(),
                            operation.bufferLayout());
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            source.name(),
                            VeilRenderGraph.Access.BUFFER_TRANSFER_READ,
                            VeilRenderGraph.Subresource.buffer(
                                    operation.sourceOffset(),
                                    bufferImageBytes(
                                            destination,
                                            operation.destinationRegion(),
                                            operation.bufferLayout())));
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            destination.name(),
                            VeilRenderGraph.Access.TRANSFER_WRITE,
                            transferSubresource(operation.destinationRegion()));
                }
                case IMAGE_TO_BUFFER -> {
                    Resource source =
                            transferImage(
                                    pass,
                                    operation.source(),
                                    VeilResourceUsage.TRANSFER_SOURCE,
                                    false);
                    Resource destination =
                            transferBuffer(
                                    pass,
                                    operation.destination(),
                                    VeilResourceUsage.TRANSFER_DESTINATION,
                                    true);
                    validateBufferImage(
                            pass,
                            destination,
                            operation.destinationOffset(),
                            source,
                            operation.sourceRegion(),
                            operation.bufferLayout());
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            source.name(),
                            VeilRenderGraph.Access.TRANSFER_READ,
                            transferSubresource(operation.sourceRegion()));
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            destination.name(),
                            VeilRenderGraph.Access.BUFFER_TRANSFER_WRITE,
                            bufferWriteRange(
                                    destination,
                                    operation.destinationOffset(),
                                    bufferImageBytes(
                                            source,
                                            operation.sourceRegion(),
                                            operation.bufferLayout())));
                }
                case IMAGE_COPY, IMAGE_RESOLVE, IMAGE_BLIT_NEAREST, IMAGE_BLIT_LINEAR -> {
                    Resource source =
                            transferImage(
                                    pass,
                                    operation.source(),
                                    VeilResourceUsage.TRANSFER_SOURCE,
                                    false);
                    Resource destination =
                            transferImage(
                                    pass,
                                    operation.destination(),
                                    VeilResourceUsage.TRANSFER_DESTINATION,
                                    true);
                    boolean resolve = operation.kind() == VeilTransfer.Kind.IMAGE_RESOLVE;
                    boolean blit =
                            operation.kind() == VeilTransfer.Kind.IMAGE_BLIT_NEAREST
                                    || operation.kind() == VeilTransfer.Kind.IMAGE_BLIT_LINEAR;
                    if ((!blit && source.format() != destination.format())
                            || (!resolve && source.samples() != destination.samples())
                            || (source == destination
                                    && transferSubresource(operation.sourceRegion())
                                            .overlaps(
                                                    transferSubresource(
                                                            operation.destinationRegion())))) {
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + (resolve
                                                ? ": image resolve requires non-overlapping resources/subresources with identical format"
                                                : ": image transfer requires compatible formats/samples and disjoint self-transfer subresources"));
                    }
                    validateImageRegion(pass, source, operation.sourceRegion());
                    validateImageRegion(pass, destination, operation.destinationRegion());
                    if (resolve
                            && (source.samples() <= 1
                                    || destination.samples() != 1
                                    || source.image3d()
                                    || destination.image3d()
                                    || !source.format().color()
                                    || operation.sourceRegion().aspect()
                                            != VeilTransfer.Aspect.COLOR
                                    || operation.destinationRegion().aspect()
                                            != VeilTransfer.Aspect.COLOR)) {
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + ": image resolve requires multisampled color source and single-sample 2D color destination");
                    }
                    if (blit) validateBlit(pass, source, destination, operation);
                    if ((!blit
                                    && (operation.sourceRegion().width()
                                                    != operation.destinationRegion().width()
                                            || operation.sourceRegion().height()
                                                    != operation.destinationRegion().height()
                                            || operation.sourceRegion().depth()
                                                    != operation.destinationRegion().depth()))
                            || operation.sourceRegion().layerCount()
                                    != operation.destinationRegion().layerCount()
                            || operation.sourceRegion().aspect()
                                    != operation.destinationRegion().aspect()) {
                        throw new IllegalArgumentException(
                                "Pass "
                                        + pass.name()
                                        + ": image copy regions must have equal extent, layers and aspect");
                    }
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            source.name(),
                            VeilRenderGraph.Access.TRANSFER_READ,
                            transferSubresource(operation.sourceRegion()));
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            destination.name(),
                            VeilRenderGraph.Access.TRANSFER_WRITE,
                            transferSubresource(operation.destinationRegion()));
                }
                case IMAGE_CLEAR -> {
                    Resource destination =
                            transferImage(
                                    pass,
                                    operation.destination(),
                                    VeilResourceUsage.TRANSFER_DESTINATION,
                                    true);
                    validateImageRegion(pass, destination, operation.destinationRegion());
                    TransferClearRules.validate(
                            destination.format(),
                            operation.destinationRegion().aspect(),
                            operation.clear());
                    if (destination.width() > 0) {
                        var region = operation.destinationRegion();
                        int clearWidth = Math.max(1, destination.width() >> region.mip());
                        int clearHeight = Math.max(1, destination.height() >> region.mip());
                        int clearDepth =
                                destination.image3d()
                                        ? Math.max(1, destination.depth() >> region.mip())
                                        : 1;
                        if (region.x() != 0
                                || region.y() != 0
                                || region.z() != 0
                                || region.width() != clearWidth
                                || region.height() != clearHeight
                                || region.depth() != clearDepth) {
                            throw new IllegalArgumentException(
                                    "Pass "
                                            + pass.name()
                                            + ": image clear must cover complete selected subresources");
                        }
                    }
                    addTransferUse(
                            pass,
                            uses,
                            graphUses,
                            destination.name(),
                            VeilRenderGraph.Access.TRANSFER_WRITE,
                            transferSubresource(operation.destinationRegion()));
                }
            }
        }
        return new VeilRenderGraph.Pass(pass.name(), uses, graphUses, pass.after());
    }

    private Resource transferBuffer(
            Pass pass, String name, VeilResourceUsage usage, boolean write) {
        Resource resource = ResourceRequirements.buffer(resources, pass, name, usage, "transfer");
        if (write && resource.hostImport())
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": host buffer is read-only: " + name);
        return resource;
    }

    private Resource transferImage(Pass pass, String name, VeilResourceUsage usage, boolean write) {
        Resource resource = resources.get(name);
        if (resource == null
                || resource.kind() != VeilRenderGraph.Kind.IMAGE
                || !resource.usages().contains(usage)) {
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": image " + name + " requires " + usage + " usage");
        }
        if (write && resource.hostImport())
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": host image is read-only: " + name);
        return resource;
    }

    private static void requireRange(Pass pass, Resource resource, long offset, long size) {
        if (size < 1 || offset > resource.bytes() || size > resource.bytes() - offset) {
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": transfer range exceeds buffer " + resource.name());
        }
    }

    private void validateBufferImage(
            Pass pass,
            Resource buffer,
            long offset,
            Resource image,
            VeilTransfer.ImageRegion region,
            VeilTransfer.BufferLayout layout) {
        validateImageRegion(pass, image, region);
        if (!image.format().color()
                || region.aspect() != VeilTransfer.Aspect.COLOR
                || image.samples() != 1) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + ": buffer/image copies currently require single-sample color images");
        }
        long bytes = bufferImageBytes(image, region, layout);
        requireRange(pass, buffer, offset, bytes);
        TransferBufferRules.validateImageCopy(
                offset, image.format(), region.width(), region.height(), layout);
    }

    private static VeilRenderGraph.Subresource bufferWriteRange(
            Resource buffer, long offset, long bytes) {
        return offset == 0 && bytes == buffer.bytes()
                ? VeilRenderGraph.Subresource.WHOLE
                : VeilRenderGraph.Subresource.buffer(offset, bytes);
    }

    private static long bufferImageBytes(
            Resource image, VeilTransfer.ImageRegion region, VeilTransfer.BufferLayout layout) {
        int slices = image.image3d() ? region.depth() : region.layerCount();
        // The declared transfer footprint must also include padding *between* rows and
        // array layers / depth slices. The last row needs only the copied texel bytes.
        VeilTransfer.BufferLayout actual =
                layout == null ? new VeilTransfer.BufferLayout(0, 0) : layout;
        return actual.requiredBytes(
                region.width(), region.height(), slices, image.format().bytesPerTexel());
    }

    private void validateImageRegion(Pass pass, Resource image, VeilTransfer.ImageRegion region) {
        if (region.mip() >= image.mipLevels()
                || (long) region.baseLayer() + region.layerCount() > image.layers()) {
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": image transfer mip/layer exceeds " + image.name());
        }
        if (image.image3d() && (region.baseLayer() != 0 || region.layerCount() != 1)) {
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": 3D image transfers use depth, not array layers");
        }
        if (!image.image3d() && (region.z() != 0 || region.depth() != 1)) {
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": 2D image transfer z/depth must be 0/1");
        }
        if (image.image1d() && (region.y() != 0 || region.height() != 1))
            throw new IllegalArgumentException(
                    "Pass " + pass.name() + ": 1D image transfer y/height must be 0/1");
        boolean aspectValid =
                switch (region.aspect()) {
                    case COLOR -> image.format().color();
                    case DEPTH -> image.format().depth();
                    case STENCIL -> image.format().stencil();
                };
        if (!aspectValid)
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + ": image transfer aspect is incompatible with "
                            + image.format());
        if (image.width() > 0) {
            int width = Math.max(1, image.width() >> region.mip());
            int height = Math.max(1, image.height() >> region.mip());
            int depth = image.image3d() ? Math.max(1, image.depth() >> region.mip()) : 1;
            if ((long) region.x() + region.width() > width
                    || (long) region.y() + region.height() > height
                    || (long) region.z() + region.depth() > depth) {
                throw new IllegalArgumentException(
                        "Pass " + pass.name() + ": image transfer extent exceeds " + image.name());
            }
        }
    }

    private static VeilRenderGraph.Subresource transferSubresource(
            VeilTransfer.ImageRegion region) {
        return VeilRenderGraph.Subresource.image(
                region.mip(), 1, region.baseLayer(), region.layerCount());
    }

    private static void addTransferUse(
            Pass pass,
            Map<String, VeilRenderGraph.Access> uses,
            List<VeilRenderGraph.Use> graphUses,
            String resource,
            VeilRenderGraph.Access access,
            VeilRenderGraph.Subresource subresource) {
        uses.putIfAbsent(resource, access);
        if (graphUses.stream()
                .anyMatch(
                        use ->
                                use.resource().equals(resource)
                                        && use.access() != access
                                        && use.subresource().overlaps(subresource))) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + ": transfer subresource cannot be both read and written in one pass: "
                            + resource);
        }
        graphUses.add(new VeilRenderGraph.Use(resource, access, subresource));
    }

    private static void validateBlit(
            Pass pass, Resource source, Resource destination, VeilTransfer operation) {
        var sourceType = source.format().numericType();
        var destinationType = destination.format().numericType();
        boolean integer =
                sourceType == dev.veil.api.VeilFormat.NumericType.UINT
                        || sourceType == dev.veil.api.VeilFormat.NumericType.SINT
                        || destinationType == dev.veil.api.VeilFormat.NumericType.UINT
                        || destinationType == dev.veil.api.VeilFormat.NumericType.SINT;
        boolean linear = operation.kind() == VeilTransfer.Kind.IMAGE_BLIT_LINEAR;
        if (source.samples() != 1
                || destination.samples() != 1
                || source.image3d() != destination.image3d()
                || (integer && sourceType != destinationType)
                || ((!source.format().color() || !destination.format().color())
                        && (source.format() != destination.format() || linear))
                || (integer && linear)) {
            throw new IllegalArgumentException(
                    "Pass "
                            + pass.name()
                            + ": image blit requires single-sample compatible image types/numeric formats; integer and depth/stencil blits require nearest filtering");
        }
    }
}
