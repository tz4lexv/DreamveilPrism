package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

final class VeilGlobalIlluminationProbe {
    private static final boolean REFINED = Boolean.getBoolean("veil.refinedGiProbe");
    private static final boolean ENABLED =
            (Boolean.getBoolean("veil.globalIlluminationProbe") || REFINED)
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final String[] MODES =
            REFINED
                    ? new String[] {
                        "FINAL",
                        "DIRECT_ONLY",
                        "GI_INDIRECT",
                        "GI_COVERAGE",
                        "GI_TRANSMISSION",
                        "GI_VARIANCE",
                        "GI_HIT_RATE",
                        "GI_SURFACE_NORMALS",
                        "GI_ALBEDO",
                        "GI_TRANSPARENT_LAYERS",
                        "GI_RAW"
                    }
                    : new String[] {"COMBINED", "DIRECT", "INDIRECT", "MOVED"};
    private static final boolean CAMERA_MOTION = Boolean.getBoolean("veil.giCameraMotion");
    private static double originalCameraX;
    private static long started, ready;
    private static int mode, returned;
    private static boolean reset, pending, complete;
    private static VeilShaderPackRuntime previous;

    private VeilGlobalIlluminationProbe() {}

    static boolean enabled() {
        return ENABLED;
    }

    static Map<String, String> overrides() {
        if (ENABLED && REFINED)
            return Map.of(
                    "DEBUG_VIEW",
                    "FINAL",
                    "GI_ENABLE",
                    "true",
                    "GI_SAMPLES",
                    "16",
                    "CLOUDS_ENABLE",
                    "false",
                    "FOG_DENSITY",
                    "0",
                    "LENS_FLARE",
                    "false");
        return ENABLED
                ? Map.of(
                        "backend",
                        "PORTABLE",
                        "vanillaFill",
                        "false",
                        "lightingView",
                        "COMBINED",
                        "samples",
                        "1",
                        "bounces",
                        "4")
                : Map.of();
    }

    static void checkTimeout(boolean failed) {
        if (!ENABLED || complete) return;
        long now = System.nanoTime();
        if (started == 0) started = now;
        if (failed || now - started > 300_000_000_000L)
            fail(new IllegalStateException("GI execution failed or timed out"));
    }

    static void tick(VeilShaderPackRuntime active) {
        if (!ENABLED || complete || pending || !VeilBenchmarkWorld.terrainReady()) return;
        try {
            if (mode == 3 && !REFINED) {
                double cameraX = Minecraft.getInstance().gameRenderer.mainCamera().position().x;
                if (Math.abs(cameraX - originalCameraX) < 0.1) return;
                ReviveMod.LOGGER.info(
                        "Veil GI camera motion: original_x={} moved_x={}",
                        originalCameraX,
                        cameraX);
                pending = true;
                returned = 0;
                capture(active, "radiance", 16, "rgba32f");
                capture(active, "output", 4, "rgba");
                return;
            }
            if (ready == 0) ready = System.nanoTime();
            if (System.nanoTime() - ready < 15_000_000_000L) return;
            if (!reset) {
                reset = true;
                previous = active;
                VeilShaderService.requestReload();
                return;
            }
            if (active == previous || active.renderedFrames() < 64) return;
            if (!REFINED && active.renderedFrames() != 64)
                throw new IllegalStateException("GI capture missed sample 64");
            pending = true;
            returned = 0;
            capture(active, REFINED ? "giRadiance" : "radiance", 16, "rgba32f");
            capture(active, REFINED ? "shadowed" : "output", 4, "rgba");
            if (REFINED) {
                capture(active, "giTransmission", 16, "transmission32f");
                capture(active, "giDiagnostic", 16, "diagnostic32f");
            }
        } catch (RuntimeException failure) {
            fail(failure);
        }
    }

    private static void capture(
            VeilShaderPackRuntime active, String output, int stride, String extension) {
        var extent = active.outputExtent(output);
        int width = extent[0], height = extent[1];
        if (!REFINED && (width != 320 || height != 180))
            throw new IllegalStateException("Unexpected GI diagnostic extent");
        var readback =
                RenderSystem.getDevice()
                        .createBuffer(
                                () -> "Veil GI " + output,
                                GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                (long) width * height * stride);
        try {
            active.readOutput(
                    output,
                    readback,
                    () -> {
                        try (var mapping = readback.map(true, false)) {
                            byte[] pixels = new byte[width * height * stride];
                            mapping.data().duplicate().position(0).get(pixels);
                            Path directory =
                                    Path.of("logs", REFINED ? "refined-gi" : "global-illumination");
                            Files.createDirectories(directory);
                            Files.write(
                                    directory.resolve(
                                            MODES[mode].toLowerCase(java.util.Locale.ROOT)
                                                    + "."
                                                    + extension),
                                    pixels);
                            if (REFINED)
                                writePreview(directory, pixels, width, height, stride, extension);
                            if (++returned == (REFINED ? 4 : 2)) {
                                if (REFINED) {
                                    ReviveMod.LOGGER.info(
                                            "Veil refined GI capture: mode={} samples=16 linear_and_presented=true composition=vanilla_plus_shader_indirect",
                                            MODES[mode]);
                                } else {
                                    ReviveMod.LOGGER.info(
                                            "Veil GI capture: mode={} samples={} linear_and_presented=true vanilla_fill=false",
                                            MODES[mode],
                                            mode == 3 ? 1 : 64);
                                }
                                previous = active;
                                pending = false;
                                ++mode;
                                if (mode == 3 && CAMERA_MOTION && !REFINED) {
                                    var client = Minecraft.getInstance();
                                    originalCameraX = client.gameRenderer.mainCamera().position().x;
                                    client.player.setPos(
                                            client.player.getX() + 0.25,
                                            client.player.getY(),
                                            client.player.getZ());
                                } else if (mode >= (REFINED ? MODES.length : 3)) {
                                    complete = true;
                                    ReviveMod.LOGGER.info(
                                            "Veil GI capture: PASS (lighting views captured; numerical and visual analysis pending)");
                                    Minecraft.getInstance().stop();
                                } else
                                    VeilShaderService.setting(
                                            REFINED ? "DEBUG_VIEW" : "lightingView", MODES[mode]);
                            }
                        } catch (IOException | RuntimeException failure) {
                            fail(failure);
                        } finally {
                            readback.close();
                        }
                    });
        } catch (RuntimeException failure) {
            readback.close();
            throw failure;
        }
    }

    private static void writePreview(
            Path directory, byte[] pixels, int width, int height, int stride, String extension)
            throws IOException {
        var image =
                new java.awt.image.BufferedImage(
                        width, height, java.awt.image.BufferedImage.TYPE_INT_RGB);
        var data = java.nio.ByteBuffer.wrap(pixels).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        int covered = 0, lit = 0;
        float peak = 0;
        for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++) {
                int offset = (y * width + x) * stride;
                int rgb = 0;
                float sum = 0;
                for (int channel = 0; channel < 3; channel++) {
                    float value =
                            stride == 16
                                    ? data.getFloat(offset + channel * 4)
                                    : (pixels[offset + channel] & 255) / 255f;
                    if (!Float.isFinite(value) || value < 0)
                        throw new IOException("Non-finite or negative GI output");
                    sum += value;
                    peak = Math.max(peak, value);
                    if (stride == 16) value = (float) Math.pow(value / (1 + value), 1 / 2.2);
                    rgb = (rgb << 8) | Math.min(255, Math.round(value * 255));
                }
                if (stride == 16 && data.getFloat(offset + 12) > 0.5) covered++;
                if (sum > 0.0001) lit++;
                image.setRGB(x, y, rgb);
            }
        String name = MODES[mode].toLowerCase(java.util.Locale.ROOT);
        javax.imageio.ImageIO.write(
                image, "png", directory.resolve(name + "-" + extension + ".png").toFile());
        ReviveMod.LOGGER.info(
                "Veil refined GI diagnostic: mode={} format={} width={} height={} covered={} lit={} peak={}",
                MODES[mode],
                extension,
                width,
                height,
                covered,
                lit,
                peak);
    }

    private static void fail(Exception failure) {
        complete = true;
        ReviveMod.LOGGER.error("Veil GI capture: FAIL", failure);
        Minecraft.getInstance().stop();
    }
}
