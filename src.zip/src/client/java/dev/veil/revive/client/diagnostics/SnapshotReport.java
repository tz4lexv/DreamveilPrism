package dev.veil.revive.client.diagnostics;

import dev.veil.revive.client.VeilDiagnostics.SampleStats;
import dev.veil.revive.client.VeilEntityPipelineCounters;
import dev.veil.revive.client.VeilServerAiCounters;

import java.util.Locale;

public final class SnapshotReport {
    private SnapshotReport() {}

    public static void appendEntityPipeline(
            StringBuilder out, String label, VeilEntityPipelineCounters.Snapshot e) {
        out.append(
                String.format(
                        Locale.ROOT,
                        "%s visibility: checks %d | rejected before extraction %d | exact-distance rejects %d | section-tree rejects %d | extracted %d | submitted %d\n",
                        label,
                        e.visibilityChecks(),
                        e.rejectedBeforeExtraction(),
                        e.exactDistanceRejects(),
                        e.sectionVisibilityRejects(),
                        e.dispatchExtractCalls(),
                        e.dispatchSubmitCalls()));
        out.append(
                String.format(
                        Locale.ROOT,
                        "%s CPU: visible-loop %.4f ms/frame | dispatcher extract %.4f ms/frame (%.3f us/entity) | submit %.4f ms/frame (%.3f us/entity)\n",
                        label,
                        e.visibleLoopMsPerFrame(),
                        e.dispatcherExtractMsPerFrame(),
                        e.dispatcherExtractUsPerEntity(),
                        e.dispatcherSubmitMsPerFrame(),
                        e.dispatcherSubmitUsPerEntity()));
        out.append(
                String.format(
                        Locale.ROOT,
                        "%s load: %.2f extracted/frame | render-thread allocation %.2f KiB/frame (%.1f B/extracted entity)\n",
                        label,
                        e.entitiesExtractedPerFrame(),
                        e.allocatedKiBPerFrame(),
                        e.allocatedBytesPerExtractedEntity()));
        if (e.serverTickSamples() > 0L) {
            out.append(
                    String.format(
                            Locale.ROOT,
                            "%s integrated-server rolling tick: avg %.3f ms | max sampled average %.3f ms | samples %d\n",
                            label,
                            e.serverTickAverageMs(),
                            e.serverTickMaxSampledAverageMs(),
                            e.serverTickSamples()));
        } else {
            out.append(label)
                    .append(
                            " integrated-server rolling tick: no samples (multiplayer or no integrated server)\n");
        }
    }

    public static void appendServerAi(
            StringBuilder out, String label, VeilServerAiCounters.Snapshot s) {
        VeilServerAiCounters.MetricSnapshot tick = s.serverTick();
        long serverTicks = tick.calls();
        if (serverTicks <= 0L) {
            out.append(label).append(" server AI: no complete integrated-server ticks captured\n");
            return;
        }

        out.append(
                String.format(
                        Locale.ROOT,
                        "%s server tick: %.3f ms avg | %d complete ticks | level work %.3f ms/tick\n",
                        label,
                        tick.averageMs(),
                        serverTicks,
                        perServerTickMs(s.levelTick(), serverTicks)));
        out.append(
                String.format(
                        Locale.ROOT,
                        "%s entity simulation: %d entity ticks (%.1f/tick) | %.3f ms/tick total | villagers %d (%.2f/tick), %.3f ms/tick\n",
                        label,
                        s.entityTick().calls(),
                        perServerTickCalls(s.entityTick(), serverTicks),
                        perServerTickMs(s.entityTick(), serverTicks),
                        s.villagerEntityTick().calls(),
                        perServerTickCalls(s.villagerEntityTick(), serverTicks),
                        perServerTickMs(s.villagerEntityTick(), serverTicks)));
        out.append(
                String.format(
                        Locale.ROOT,
                        "%s AI attribution: Mob AI %.3f ms/tick | villager Mob AI %.3f | villager custom AI %.3f | villager Brain %.3f | Sensors %.3f | Navigation %.3f | path create %.3f ms/tick\n",
                        label,
                        perServerTickMs(s.mobAi(), serverTicks),
                        perServerTickMs(s.villagerMobAi(), serverTicks),
                        perServerTickMs(s.villagerCustomAi(), serverTicks),
                        perServerTickMs(s.villagerBrain(), serverTicks),
                        perServerTickMs(s.villagerSensor(), serverTicks),
                        perServerTickMs(s.villagerNavigation(), serverTicks),
                        perServerTickMs(s.villagerPathCreate(), serverTicks)));
        out.append(
                String.format(
                        Locale.ROOT,
                        "%s AI calls: Brain %d (villager %d) | Sensor %d (villager %d) | Navigation %d (villager %d) | path creates %d (villager %d)\n",
                        label,
                        s.brain().calls(),
                        s.villagerBrain().calls(),
                        s.sensor().calls(),
                        s.villagerSensor().calls(),
                        s.navigation().calls(),
                        s.villagerNavigation().calls(),
                        s.pathCreate().calls(),
                        s.villagerPathCreate().calls()));
    }

    private static double perServerTickMs(
            VeilServerAiCounters.MetricSnapshot metric, long serverTicks) {
        return serverTicks <= 0L ? 0.0 : metric.totalMs() / serverTicks;
    }

    private static double perServerTickCalls(
            VeilServerAiCounters.MetricSnapshot metric, long serverTicks) {
        return serverTicks <= 0L ? 0.0 : (double) metric.calls() / serverTicks;
    }

    public static void appendPerf(
            StringBuilder out, String label, SampleStats frame, SampleStats render) {
        double fps = frame.avg() > 0.0 ? 1000.0 / frame.avg() : 0.0;
        out.append(label).append(" frame samples: ").append(frame.count()).append('\n');
        out.append(
                String.format(
                        Locale.ROOT,
                        "frame ms: avg %.3f | P50 %.3f | P90 %.3f | P95 %.3f | P99 %.3f | min %.3f | max %.3f | stddev %.3f | MAD %.3f\n",
                        frame.avg(),
                        frame.p50(),
                        frame.p90(),
                        frame.p95(),
                        frame.p99(),
                        frame.min(),
                        frame.max(),
                        frame.stdDev(),
                        frame.mad()));
        out.append(String.format(Locale.ROOT, "derived FPS: %.2f\n", fps));
        out.append(label).append(" world-render samples: ").append(render.count()).append('\n');
        out.append(
                String.format(
                        Locale.ROOT,
                        "world render CPU ms: avg %.3f | P50 %.3f | P90 %.3f | P95 %.3f | P99 %.3f | max %.3f | stddev %.3f | MAD %.3f\n",
                        render.avg(),
                        render.p50(),
                        render.p90(),
                        render.p95(),
                        render.p99(),
                        render.max(),
                        render.stdDev(),
                        render.mad()));
    }
}
