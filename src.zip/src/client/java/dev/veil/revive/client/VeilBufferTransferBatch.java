package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.CommandEncoder;

import dev.veil.revive.client.graphics.resources.RangeTransferRecorder;
import dev.veil.revive.core.terrain.SparseUploadPlanner;

final class VeilBufferTransferBatch {
    private static final RangeTransferRecorder RECORDER =
            new RangeTransferRecorder(
                    Boolean.getBoolean("veil.batchedTransfers"),
                    Boolean.getBoolean("veil.sectionTransferDependencies"),
                    VeilHzb.STORAGE_USAGE,
                    ReviveRuntime::optimizationsEnabled);

    private VeilBufferTransferBatch() {}

    static boolean eligible(
            SparseUploadPlanner ranges, int stride, long sourceSize, long targetSize) {
        return RangeTransferRecorder.eligible(ranges, stride, sourceSize, targetSize);
    }

    static boolean sectionTableContract(int sourceUsage, int targetUsage) {
        return RECORDER.sectionTableContract(sourceUsage, targetUsage);
    }

    static void copy(
            CommandEncoder encoder,
            GpuBuffer source,
            GpuBuffer target,
            SparseUploadPlanner ranges,
            int stride) {
        RECORDER.copy(encoder, source, target, ranges, stride);
    }

    static void copySectionTable(
            CommandEncoder encoder,
            GpuBuffer source,
            GpuBuffer target,
            SparseUploadPlanner ranges,
            int stride) {
        RECORDER.copySectionTable(encoder, source, target, ranges, stride);
    }

    static long batches() {
        return RECORDER.batches();
    }

    static long nativeRanges() {
        return RECORDER.nativeRanges();
    }

    static long sectionBatches() {
        return RECORDER.sectionBatches();
    }

    static String telemetry() {
        return RECORDER.telemetry();
    }
}
