package dev.veil.revive.client.shaderpack.preparation;

import dev.veil.revive.client.VeilShaderPack;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public final class Ktx2Decoder {
    private static final byte[] IDENTIFIER = {
        (byte) 0xAB, 0x4B, 0x54, 0x58, 0x20, 0x32, 0x30, (byte) 0xBB, 0x0D, 0x0A, 0x1A, 0x0A
    };
    private static final int HEADER_BYTES = 80;
    private static final int LEVEL_INDEX_BYTES = 24;
    private static final int SUPERCOMPRESSION_NONE = 0;
    private static final int SUPERCOMPRESSION_BASIS_LZ = 1;
    private static final int SUPERCOMPRESSION_ZSTD = 2;
    private static final int SUPERCOMPRESSION_ZLIB = 3;

    private Ktx2Decoder() {}

    public static byte[] decode(
            VeilShaderPack.Resource resource, byte[] file, int expectedVkFormat) {
        if (file.length < HEADER_BYTES
                || !Arrays.equals(IDENTIFIER, Arrays.copyOf(file, IDENTIFIER.length))) {
            throw new IllegalArgumentException(
                    "Image " + resource.name() + " is not a valid KTX2 file");
        }
        ByteBuffer in = ByteBuffer.wrap(file).order(ByteOrder.LITTLE_ENDIAN);
        int vkFormat = in.getInt(12);
        int pixelWidth = positiveInt(in.getInt(20), "pixelWidth");
        int pixelHeightRaw = in.getInt(24);
        int pixelDepthRaw = in.getInt(28);
        int layerCountRaw = in.getInt(32);
        int faceCount = in.getInt(36);
        int levelCountRaw = in.getInt(40);
        int scheme = in.getInt(44);
        int pixelHeight = pixelHeightRaw == 0 ? 1 : positiveInt(pixelHeightRaw, "pixelHeight");
        int pixelDepth = pixelDepthRaw == 0 ? 1 : positiveInt(pixelDepthRaw, "pixelDepth");
        int layerCount = layerCountRaw == 0 ? 1 : positiveInt(layerCountRaw, "layerCount");
        int levelCount = levelCountRaw == 0 ? 1 : positiveInt(levelCountRaw, "levelCount");

        if (resource.image1d() != (pixelHeightRaw == 0))
            throw new IllegalArgumentException("KTX2 image dimension mismatch: " + resource.name());
        if (faceCount != (resource.cubemap() ? 6 : 1))
            throw new IllegalArgumentException("KTX2 face count mismatch: " + resource.name());
        if (levelCount != resource.mipLevels()) {
            throw new IllegalArgumentException(
                    "KTX2 mip count mismatch for "
                            + resource.name()
                            + "; manifest="
                            + resource.mipLevels()
                            + " file="
                            + levelCount);
        }
        if (pixelWidth != resource.width() || pixelHeight != resource.height()) {
            throw new IllegalArgumentException("KTX2 dimensions mismatch for " + resource.name());
        }
        if (resource.image3d()) {
            if (pixelDepthRaw == 0 || pixelDepth != resource.depth() || layerCountRaw != 0) {
                throw new IllegalArgumentException(
                        "KTX2 dimensionality mismatch; expected non-array 3D image for "
                                + resource.name());
            }
        } else {
            if (pixelDepthRaw != 0)
                throw new IllegalArgumentException(
                        "KTX2 dimensionality mismatch; expected 2D image for " + resource.name());
            int expectedLayers =
                    resource.cubeArray()
                            ? resource.layers() / 6
                            : resource.image1dArray() || resource.image2dArray()
                                    ? resource.layers()
                                    : 1;
            boolean array =
                    resource.image1dArray() || resource.image2dArray() || resource.cubeArray();
            if (layerCount != expectedLayers || (array ? layerCountRaw == 0 : layerCountRaw != 0)) {
                throw new IllegalArgumentException(
                        "KTX2 layer count mismatch for "
                                + resource.name()
                                + "; expected="
                                + expectedLayers
                                + " file="
                                + layerCount);
            }
        }
        if (vkFormat != expectedVkFormat) {
            throw new IllegalArgumentException(
                    "KTX2 VkFormat mismatch for "
                            + resource.name()
                            + "; expected="
                            + expectedVkFormat
                            + " file="
                            + vkFormat);
        }
        if (scheme == SUPERCOMPRESSION_BASIS_LZ) {
            throw new IllegalArgumentException(
                    "KTX2 BasisLZ requires transcoding and is not part of the V52.2 native-format frontend");
        }
        if (scheme == SUPERCOMPRESSION_ZSTD) {
            throw new IllegalArgumentException(
                    "KTX2 Zstandard requires an optional codec not present in the V52.2 baseline");
        }
        if (scheme != SUPERCOMPRESSION_NONE && scheme != SUPERCOMPRESSION_ZLIB) {
            throw new IllegalArgumentException(
                    "Unsupported KTX2 supercompression scheme=" + scheme);
        }

        long indexEnd = HEADER_BYTES + Math.multiplyExact((long) levelCount, LEVEL_INDEX_BYTES);
        if (indexEnd > file.length)
            throw new IllegalArgumentException("Truncated KTX2 level index: " + resource.name());
        ByteArrayOutputStream output =
                new ByteArrayOutputStream(Math.toIntExact(resource.expectedAssetBytes()));
        int bytesPerTexel = VeilShaderPack.Resource.bytesPerTexel(resource.format());
        for (int level = 0; level < levelCount; level++) {
            int entry = HEADER_BYTES + level * LEVEL_INDEX_BYTES;
            long offset = in.getLong(entry);
            long length = in.getLong(entry + 8);
            long unpackedLength = in.getLong(entry + 16);
            int width = Math.max(1, resource.width() >> level);
            int height = Math.max(1, resource.height() >> level);
            int slices =
                    resource.image3d() ? Math.max(1, resource.depth() >> level) : resource.layers();
            long expected =
                    Math.multiplyExact(
                            Math.multiplyExact((long) width, height),
                            Math.multiplyExact((long) slices, bytesPerTexel));
            if (unpackedLength != expected) {
                throw new IllegalArgumentException(
                        "KTX2 level "
                                + level
                                + " decoded size mismatch for "
                                + resource.name()
                                + "; expected="
                                + expected
                                + " file="
                                + unpackedLength);
            }
            if (offset < 0
                    || length < 0
                    || offset > file.length
                    || length > file.length - offset
                    || length > Integer.MAX_VALUE) {
                throw new IllegalArgumentException(
                        "KTX2 level " + level + " range is outside the file: " + resource.name());
            }
            byte[] levelBytes =
                    Arrays.copyOfRange(file, (int) offset, Math.toIntExact(offset + length));
            if (scheme == SUPERCOMPRESSION_ZLIB)
                levelBytes = inflate(levelBytes, Math.toIntExact(expected), resource.name(), level);
            if (levelBytes.length != expected) {
                throw new IllegalArgumentException(
                        "KTX2 level " + level + " byteLength mismatch for " + resource.name());
            }
            output.writeBytes(levelBytes);
        }
        byte[] decoded = output.toByteArray();
        if (decoded.length != resource.expectedAssetBytes())
            throw new IllegalStateException("KTX2 repack size mismatch");
        return decoded;
    }

    private static byte[] inflate(byte[] compressed, int expected, String name, int level) {
        Inflater inflater = new Inflater();
        inflater.setInput(compressed);
        byte[] decoded = new byte[expected];
        try {
            int count = inflater.inflate(decoded);
            if (count != expected || !inflater.finished() || inflater.getRemaining() != 0) {
                throw new IllegalArgumentException(
                        "KTX2 ZLIB level "
                                + level
                                + " did not decode to the expected size for "
                                + name);
            }
            return decoded;
        } catch (DataFormatException failure) {
            throw new IllegalArgumentException(
                    "Invalid KTX2 ZLIB payload at level " + level + " for " + name, failure);
        } finally {
            inflater.end();
        }
    }

    private static int positiveInt(int value, String field) {
        if (value <= 0)
            throw new IllegalArgumentException(
                    "Invalid KTX2 " + field + "=" + Integer.toUnsignedString(value));
        return value;
    }
}
