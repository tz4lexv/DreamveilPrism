package dev.veil.revive.mixin;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.CommandEncoderBackend;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(CommandEncoder.class)
public interface CommandEncoderBackendAccessor {
    @Accessor("backend")
    CommandEncoderBackend veil$backend();

    @Accessor("isInRenderPass")
    boolean veil$isInRenderPass();
}
