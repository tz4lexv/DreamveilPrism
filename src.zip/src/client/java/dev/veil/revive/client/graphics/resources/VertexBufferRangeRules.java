package dev.veil.revive.client.graphics.resources;

/**
 * Bounds checking for direct, non-indexed vertex and per-instance fetches.
 *
 * <p>Vulkan fetches only the attributes declared by the pipeline, not the trailing padding of the
 * last vertex's stride. An entire final stride is therefore not required in the buffer if the final
 * attribute ends earlier.
 */
public final class VertexBufferRangeRules {
    private VertexBufferRangeRules() {}

    /**
     * Return the exclusive last byte a draw may fetch from this binding. The span is the largest
     * attribute offset plus its format size for the binding.
     */
    public static long requiredEnd(
            long bindingOffset,
            long firstElement,
            long elementCount,
            int stride,
            int attributeSpan) {
        if (bindingOffset < 0
                || firstElement < 0
                || elementCount < 0
                || stride < 1
                || attributeSpan < 0
                || attributeSpan > stride) {
            throw new IllegalArgumentException("Invalid vertex binding fetch range");
        }
        if (elementCount == 0 || attributeSpan == 0) return bindingOffset;
        try {
            return Math.addExact(
                    bindingOffset,
                    Math.addExact(
                            Math.multiplyExact(
                                    Math.addExact(firstElement, elementCount - 1), (long) stride),
                            attributeSpan));
        } catch (ArithmeticException overflow) {
            throw new IllegalArgumentException("Vertex binding fetch range exceeds long", overflow);
        }
    }

    public static void validate(
            long bindingOffset,
            long firstElement,
            long elementCount,
            int stride,
            int attributeSpan,
            long bufferBytes) {
        if (bufferBytes < 0
                || requiredEnd(bindingOffset, firstElement, elementCount, stride, attributeSpan)
                        > bufferBytes) {
            throw new IllegalArgumentException("Draw fetch exceeds vertex buffer size");
        }
    }
}
