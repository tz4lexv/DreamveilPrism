package dev.veil.revive.client.shaderpack.parsing;

import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.*;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import dev.veil.api.VeilDraw;
import dev.veil.api.VeilFormat;
import dev.veil.api.VeilTransfer;
import dev.veil.api.VeilVertexLayout;
import dev.veil.revive.client.graphics.resources.TransferClearRules;

import java.util.ArrayList;
import java.util.List;

public final class CommandParser {
    private CommandParser() {}

    public static VeilVertexLayout vertexLayout(JsonObject object) {
        fields(object, "bindings", "attributes");
        var bindings = new ArrayList<VeilVertexLayout.Binding>();
        if (object.has("bindings"))
            for (JsonElement element : object.getAsJsonArray("bindings")) {
                JsonObject item = element.getAsJsonObject();
                fields(item, "binding", "stride", "inputRate");
                VeilVertexLayout.InputRate rate =
                        switch (item.has("inputRate")
                                ? item.get("inputRate").getAsString()
                                : "vertex") {
                            case "vertex" -> VeilVertexLayout.InputRate.VERTEX;
                            case "instance" -> VeilVertexLayout.InputRate.INSTANCE;
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported vertex input rate");
                        };
                bindings.add(
                        new VeilVertexLayout.Binding(
                                integer(item, "binding", -1), integer(item, "stride", 0), rate));
            }
        var attributes = new ArrayList<VeilVertexLayout.Attribute>();
        if (object.has("attributes"))
            for (JsonElement element : object.getAsJsonArray("attributes")) {
                JsonObject item = element.getAsJsonObject();
                fields(item, "location", "binding", "format", "offset");
                attributes.add(
                        new VeilVertexLayout.Attribute(
                                integer(item, "location", -1),
                                integer(item, "binding", -1),
                                VeilFormat.valueOf(item.get("format").getAsString()),
                                integer(item, "offset", 0)));
            }
        return new VeilVertexLayout(bindings, attributes);
    }

    public static List<VeilDraw> draws(JsonArray array) {
        var draws = new ArrayList<VeilDraw>();
        for (JsonElement element : array) {
            JsonObject item = element.getAsJsonObject();
            fields(
                    item,
                    "type",
                    "vertexBuffers",
                    "indexBuffer",
                    "vertexCount",
                    "indexCount",
                    "instanceCount",
                    "firstVertex",
                    "firstIndex",
                    "vertexOffset",
                    "firstInstance",
                    "indirect");
            VeilDraw.Kind kind =
                    switch (item.get("type").getAsString()) {
                        case "draw" -> VeilDraw.Kind.DRAW;
                        case "drawIndexed" -> VeilDraw.Kind.DRAW_INDEXED;
                        case "drawIndirect" -> VeilDraw.Kind.DRAW_INDIRECT;
                        case "drawIndexedIndirect" -> VeilDraw.Kind.DRAW_INDEXED_INDIRECT;
                        default ->
                                throw new IllegalArgumentException(
                                        "Unsupported draw type: " + item.get("type").getAsString());
                    };
            boolean indexedKind =
                    kind == VeilDraw.Kind.DRAW_INDEXED
                            || kind == VeilDraw.Kind.DRAW_INDEXED_INDIRECT;
            boolean indirectKind =
                    kind == VeilDraw.Kind.DRAW_INDIRECT
                            || kind == VeilDraw.Kind.DRAW_INDEXED_INDIRECT;
            if (indirectKind != item.has("indirect"))
                throw new IllegalArgumentException(
                        "Indirect draw type must declare indirect parameters");
            if (indexedKind != item.has("indexBuffer"))
                throw new IllegalArgumentException(
                        "Indexed draw type must declare an index buffer");
            if (indirectKind
                    && (item.has("vertexCount")
                            || item.has("indexCount")
                            || item.has("instanceCount")
                            || item.has("firstVertex")
                            || item.has("firstIndex")
                            || item.has("vertexOffset")
                            || item.has("firstInstance"))) {
                throw new IllegalArgumentException(
                        "Indirect draw cannot declare direct count/offset fields");
            }
            if (!indexedKind
                    && (item.has("indexCount")
                            || item.has("firstIndex")
                            || item.has("vertexOffset"))) {
                throw new IllegalArgumentException(
                        "Non-indexed draw cannot declare indexed fields");
            }
            if (indexedKind && (item.has("vertexCount") || item.has("firstVertex"))) {
                throw new IllegalArgumentException(
                        "Indexed draw cannot declare non-indexed fields");
            }
            var vertexBuffers = new ArrayList<VeilDraw.VertexBuffer>();
            if (item.has("vertexBuffers"))
                for (JsonElement bufferElement : item.getAsJsonArray("vertexBuffers")) {
                    JsonObject buffer = bufferElement.getAsJsonObject();
                    fields(buffer, "binding", "resource", "offset");
                    vertexBuffers.add(
                            new VeilDraw.VertexBuffer(
                                    integer(buffer, "binding", -1),
                                    resourceName(buffer.get("resource").getAsString()),
                                    longInteger(buffer, "offset", 0)));
                }
            VeilDraw.IndexBuffer indexBuffer = null;
            if (item.has("indexBuffer")) {
                JsonObject buffer = item.getAsJsonObject("indexBuffer");
                fields(buffer, "resource", "offset", "type");
                VeilDraw.IndexType indexType =
                        switch (buffer.get("type").getAsString()) {
                            case "uint16" -> VeilDraw.IndexType.UINT16;
                            case "uint32" -> VeilDraw.IndexType.UINT32;
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported index type: "
                                                    + buffer.get("type").getAsString());
                        };
                indexBuffer =
                        new VeilDraw.IndexBuffer(
                                resourceName(buffer.get("resource").getAsString()),
                                longInteger(buffer, "offset", 0),
                                indexType);
            }
            String indirectBuffer = null;
            long indirectOffset = 0;
            int drawCount = 0;
            int stride = 0;
            if (item.has("indirect")) {
                JsonObject indirect = item.getAsJsonObject("indirect");
                fields(indirect, "resource", "offset", "drawCount", "stride");
                indirectBuffer = resourceName(indirect.get("resource").getAsString());
                indirectOffset = longInteger(indirect, "offset", 0);
                drawCount = integer(indirect, "drawCount", 1);
                stride = integer(indirect, "stride", 0);
            }
            boolean indexed = indexedKind;
            boolean indirect = indirectKind;
            long count =
                    indirect
                            ? 0
                            : indexed
                                    ? unsigned(item, "indexCount", 0)
                                    : unsigned(item, "vertexCount", 0);
            long first =
                    indirect
                            ? 0
                            : indexed
                                    ? unsigned(item, "firstIndex", 0)
                                    : unsigned(item, "firstVertex", 0);
            draws.add(
                    new VeilDraw(
                            kind,
                            vertexBuffers,
                            indexBuffer,
                            count,
                            indirect ? 0 : unsigned(item, "instanceCount", 1),
                            first,
                            indirect ? 0 : integer(item, "vertexOffset", 0),
                            indirect ? 0 : unsigned(item, "firstInstance", 0),
                            indirectBuffer,
                            indirectOffset,
                            drawCount,
                            stride));
        }
        return List.copyOf(draws);
    }

    public static List<VeilTransfer> transfers(JsonArray array) {
        var transfers = new ArrayList<VeilTransfer>();
        for (JsonElement element : array) {
            JsonObject item = element.getAsJsonObject();
            fields(
                    item,
                    "type",
                    "source",
                    "destination",
                    "sourceOffset",
                    "destinationOffset",
                    "size",
                    "value",
                    "sourceRegion",
                    "destinationRegion",
                    "clear",
                    "filter",
                    "bufferLayout");
            if (item.has("bufferLayout")
                    && !item.get("type").getAsString().equals("bufferToImage")
                    && !item.get("type").getAsString().equals("imageToBuffer"))
                throw new IllegalArgumentException("Only buffer/image copies accept bufferLayout");
            if (item.has("filter") && !item.get("type").getAsString().equals("imageBlit"))
                throw new IllegalArgumentException("Only imageBlit accepts a transfer filter");
            VeilTransfer.Kind kind =
                    switch (item.get("type").getAsString()) {
                        case "bufferCopy" -> VeilTransfer.Kind.BUFFER_COPY;
                        case "bufferFill" -> VeilTransfer.Kind.BUFFER_FILL;
                        case "bufferToImage" -> VeilTransfer.Kind.BUFFER_TO_IMAGE;
                        case "imageToBuffer" -> VeilTransfer.Kind.IMAGE_TO_BUFFER;
                        case "imageCopy" -> VeilTransfer.Kind.IMAGE_COPY;
                        case "imageResolve" -> VeilTransfer.Kind.IMAGE_RESOLVE;
                        case "imageBlit" ->
                                switch (item.has("filter")
                                        ? item.get("filter").getAsString()
                                        : "nearest") {
                                    case "nearest" -> VeilTransfer.Kind.IMAGE_BLIT_NEAREST;
                                    case "linear" -> VeilTransfer.Kind.IMAGE_BLIT_LINEAR;
                                    default ->
                                            throw new IllegalArgumentException(
                                                    "Image blit filter must be nearest or linear");
                                };
                        case "imageClear" -> VeilTransfer.Kind.IMAGE_CLEAR;
                        default ->
                                throw new IllegalArgumentException(
                                        "Unsupported transfer type: "
                                                + item.get("type").getAsString());
                    };
            VeilTransfer.ClearValue clear = null;
            if (item.has("clear")) {
                JsonObject value = item.getAsJsonObject("clear");
                fields(value, "type", "r", "g", "b", "a", "depth", "stencil");
                String type = value.has("type") ? value.get("type").getAsString() : "float";
                clear =
                        switch (type) {
                            case "float" ->
                                    new VeilTransfer.ClearValue(
                                            floating(value, "r", 0),
                                            floating(value, "g", 0),
                                            floating(value, "b", 0),
                                            floating(value, "a", 0),
                                            floating(value, "depth", 0),
                                            integer(value, "stencil", 0));
                            case "sint", "uint" -> {
                                if (value.has("depth") || value.has("stencil"))
                                    throw new IllegalArgumentException(
                                            "Integer color clear cannot declare depth/stencil fields");
                                var colorType =
                                        type.equals("uint")
                                                ? VeilTransfer.ClearColorType.UINT
                                                : VeilTransfer.ClearColorType.SINT;
                                int r = integerClearChannel(value, "r", colorType);
                                int g = integerClearChannel(value, "g", colorType);
                                int b = integerClearChannel(value, "b", colorType);
                                int a = integerClearChannel(value, "a", colorType);
                                yield colorType == VeilTransfer.ClearColorType.UINT
                                        ? VeilTransfer.ClearValue.unsigned(r, g, b, a)
                                        : VeilTransfer.ClearValue.signed(r, g, b, a);
                            }
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported image clear component type: " + type);
                        };
            }
            transfers.add(
                    new VeilTransfer(
                            kind,
                            item.has("source")
                                    ? resourceName(item.get("source").getAsString())
                                    : null,
                            item.has("destination")
                                    ? resourceName(item.get("destination").getAsString())
                                    : null,
                            longInteger(item, "sourceOffset", 0),
                            longInteger(item, "destinationOffset", 0),
                            longInteger(item, "size", 0),
                            integer(item, "value", 0),
                            item.has("sourceRegion")
                                    ? imageRegion(item.getAsJsonObject("sourceRegion"))
                                    : null,
                            item.has("destinationRegion")
                                    ? imageRegion(item.getAsJsonObject("destinationRegion"))
                                    : null,
                            clear,
                            item.has("bufferLayout")
                                    ? bufferLayout(item.getAsJsonObject("bufferLayout"))
                                    : null));
        }
        return List.copyOf(transfers);
    }

    private static int integerClearChannel(
            JsonObject value, String name, VeilTransfer.ClearColorType type) {
        return value.has(name)
                ? TransferClearRules.channel(value.get(name).getAsBigDecimal(), type)
                : 0;
    }

    private static VeilTransfer.BufferLayout bufferLayout(JsonObject item) {
        fields(item, "rowLengthTexels", "imageHeightTexels");
        return new VeilTransfer.BufferLayout(
                integer(item, "rowLengthTexels", 0), integer(item, "imageHeightTexels", 0));
    }

    private static VeilTransfer.ImageRegion imageRegion(JsonObject item) {
        fields(item, "mip", "baseLayer", "layerCount", "offset", "extent", "aspect");
        JsonArray offset = item.has("offset") ? item.getAsJsonArray("offset") : null;
        JsonArray extent = item.getAsJsonArray("extent");
        if (offset != null && offset.size() != 3 || extent == null || extent.size() != 3) {
            throw new IllegalArgumentException(
                    "Image transfer region requires offset and extent with three components");
        }
        VeilTransfer.Aspect aspect =
                switch (item.has("aspect") ? item.get("aspect").getAsString() : "color") {
                    case "color" -> VeilTransfer.Aspect.COLOR;
                    case "depth" -> VeilTransfer.Aspect.DEPTH;
                    case "stencil" -> VeilTransfer.Aspect.STENCIL;
                    default ->
                            throw new IllegalArgumentException("Unsupported transfer image aspect");
                };
        return new VeilTransfer.ImageRegion(
                integer(item, "mip", 0),
                integer(item, "baseLayer", 0),
                integer(item, "layerCount", 1),
                offset == null ? 0 : offset.get(0).getAsBigDecimal().intValueExact(),
                offset == null ? 0 : offset.get(1).getAsBigDecimal().intValueExact(),
                offset == null ? 0 : offset.get(2).getAsBigDecimal().intValueExact(),
                extent.get(0).getAsBigDecimal().intValueExact(),
                extent.get(1).getAsBigDecimal().intValueExact(),
                extent.get(2).getAsBigDecimal().intValueExact(),
                aspect);
    }
}
