package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.api.*;
import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;

import org.joml.Vector4f;

import java.nio.ByteOrder;
import java.nio.file.Files;
import java.util.*;

final class VeilGiConformanceProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.giConformanceProbe")
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static final boolean GUIDES =
            System.getProperty("veil.shaderPack", "").equals("surfaceguideconformance");
    private static final String[] OUTPUTS = {
        "raw",
        "components",
        "normal",
        "motion",
        "identity",
        "albedoDepth",
        "filtered",
        "history",
        "extra"
    };
    private static final Map<Integer, Map<String, float[]>> CAPTURES = new TreeMap<>();
    private static final List<String> EVIDENCE = new ArrayList<>();
    private static VeilSurfaceGuides.Registration provider;
    private static VeilEntityMaterials.Registration material;
    private static VeilCreatorMeshes.Registration sphere;
    private static VeilSurfaceGuides.Context latestContext;
    private static int stage, frames, requestedFrames;
    private static long started, baseFrame;
    private static boolean complete, pending, initialized, ready, waitGeneration, invalidChecked;
    private static VeilShaderPackRuntime previous;
    private static int acquired, released;
    private static int badMode;
    private static float sphereX = -.85f;
    private static float roughness = .025f;

    private VeilGiConformanceProbe() {}

    static boolean enabled() {
        return ENABLED;
    }

    static void prepareClient() {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (GUIDES && provider == null)
            provider = VeilSurfaceGuides.register(VeilGiConformanceProbe::guideFrame);
    }

    private static float[][] guideValues() {
        return new float[][] {
            {0, 1, 0, .25f},
            {.3f, .4f, .5f, .7f},
            {1, 2, 3, .9f},
            {4, 5, 6, 1.5f},
            {.8f, .2f, 1, 0},
            {.125f, -.25f, .4f, .6f},
            {Float.intBitsToFloat(17), 0, Float.intBitsToFloat(201), Float.intBitsToFloat(7)}
        };
    }

    private static VeilSurfaceGuides.Frame guideFrame(VeilSurfaceGuides.Context context) {
        latestContext = context;
        if (badMode != 0)
            return new VeilSurfaceGuides.Frame(
                    badMode == 1 ? new Object() : context.token(), Map.of(), () -> released++);
        acquired++;
        var images =
                new EnumMap<VeilSurfaceGuides.Channel, GpuTextureView>(
                        VeilSurfaceGuides.Channel.class);
        var owned = new ArrayList<GpuTexture>();
        try {
            var device = RenderSystem.getDevice();
            var encoder = device.createCommandEncoder();
            for (var channel : context.requested()) {
                var texture =
                        device.createTexture(
                                "Veil guide producer " + channel,
                                GpuTexture.USAGE_RENDER_ATTACHMENT
                                        | GpuTexture.USAGE_TEXTURE_BINDING,
                                GpuFormat.RGBA32_FLOAT,
                                context.scene().width,
                                context.scene().height,
                                1,
                                1);
                owned.add(texture);
                var view = device.createTextureView(texture);
                images.put(channel, view);
                float[] v = guideValues()[channel.ordinal()];
                try (var pass =
                        encoder.createRenderPass(
                                () -> "Veil guide producer clear",
                                view,
                                Optional.of(new Vector4f(v)))) {}
            }
            return new VeilSurfaceGuides.Frame(
                    context.token(),
                    images,
                    () -> {
                        images.values().forEach(GpuTextureView::close);
                        owned.forEach(GpuTexture::close);
                        released++;
                    });
        } catch (RuntimeException failure) {
            VeilVulkanRuntime.currentOrNull()
                    .deferDestroy(
                            () -> {
                                images.values().forEach(GpuTextureView::close);
                                owned.forEach(GpuTexture::close);
                            });
            throw failure;
        }
    }

    static void timeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (failed || started != 0 && System.nanoTime() - started > 600_000_000_000L)
            fail(new IllegalStateException("GI conformance timeout or runtime failure"));
    }

    static void beforeScene(VeilShaderPackRuntime active) {
        if (!ENABLED || complete || pending || !VeilBenchmarkWorld.terrainReady()) return;
        ready = false;
        try {
            if (GUIDES) {
                ready = true;
                return;
            }
            if (!initialized) {
                initialized = true;
                frames = 0;
                baseFrame = active.renderedFrames();
                previous = active;
                waitGeneration = false;
                requestedFrames =
                        stage == 2 || stage == 6 || stage == 9 || stage == 11 || stage == 16
                                ? 72
                                : 8;
                if (stage == 0) {
                    installMaterial(.025f);
                    publishSphere(sphereX, sphereX);
                }
                if (stage <= 6 || stage == 10 || stage == 11) {
                    int spp = stage == 1 || stage == 2 || stage == 6 || stage == 11 ? 1 : 128;
                    boolean temporal = stage == 2 || stage == 6 || stage == 11;
                    VeilShaderService.settings(
                            Map.of(
                                    "SPP",
                                    Integer.toString(spp),
                                    "BOUNCES",
                                    stage == 3 ? "1" : "5",
                                    "TEMPORAL",
                                    Boolean.toString(temporal),
                                    "GLASS_RED",
                                    Boolean.toString(stage >= 5),
                                    "LIGHT_X",
                                    stage >= 6 ? "0.8" : "0.0",
                                    "VIEW",
                                    "0"));
                    waitGeneration = true;
                }
                if (stage == 7) {
                    installMaterial(.45f);
                    requestedFrames = 1;
                }
                if (stage == 8) {
                    publishSphere(sphereX + .35f, sphereX);
                    sphereX += .35f;
                    requestedFrames = 1;
                }
                if (stage == 9) publishSphere(sphereX, sphereX);
                if (stage == 12) {
                    Minecraft.getInstance().getWindow().setWindowed(800, 450);
                    requestedFrames = 1;
                }
                if (stage == 13) {
                    VeilShaderService.requestReload();
                    waitGeneration = true;
                    requestedFrames = 1;
                }
                if (stage == 14 || stage == 15) {
                    var client = Minecraft.getInstance();
                    var server = client.getSingleplayerServer();
                    var uuid = client.player.getUUID();
                    var dimension = stage == 14 ? Level.NETHER : Level.OVERWORLD;
                    server.execute(
                            () ->
                                    server.getPlayerList()
                                            .getPlayer(uuid)
                                            .teleportTo(
                                                    server.getLevel(dimension),
                                                    8,
                                                    100,
                                                    8,
                                                    Set.of(),
                                                    0f,
                                                    0f,
                                                    true));
                    requestedFrames = 1;
                }
            }
            if (waitGeneration && active == previous) return;
            var client = Minecraft.getInstance();
            if (stage == 12
                    && (client.gameRenderer.mainRenderTarget().width != 800
                            || client.gameRenderer.mainRenderTarget().height != 450)) return;
            if (stage == 14 && !client.level.dimension().equals(Level.NETHER)) return;
            if (stage == 15 && !client.level.dimension().equals(Level.OVERWORLD)) return;
            ready = true;
            frames++;
        } catch (Exception failure) {
            fail(failure);
        }
    }

    private static void installMaterial(float r) {
        roughness = r;
        if (material != null) material.close();
        material =
                VeilEntityMaterials.register(
                        "minecraft:pig",
                        "*",
                        new VeilCreatorScene.Material(
                                201, .94f, .94f, .94f, 1, 0, 0, 0, r, 1, 1.5f, 0, 1, 0, 0, 0, 0,
                                0));
        for (int i = 0; i < 4; i++) {
            float[] c =
                    i == 1
                            ? new float[] {.7f, .06f, .03f}
                            : i == 2
                                    ? new float[] {.05f, .65f, .08f}
                                    : new float[] {.75f, .75f, .75f};
            VeilCreatorScene.registerMaterial(
                    new VeilCreatorScene.Material(
                            100 + i,
                            c[0],
                            c[1],
                            c[2],
                            1,
                            0,
                            0,
                            0,
                            i == 3 ? .02f : .8f,
                            0,
                            1.5f,
                            i == 3 ? 1 : 0,
                            1,
                            0,
                            0,
                            0,
                            0,
                            0));
        }
    }

    private static void publishSphere(float x, float oldX) {
        int nx = 24, ny = 12;
        float[] positions = new float[(nx + 1) * (ny + 1) * 3], old = new float[positions.length];
        var indices = new ArrayList<Integer>();
        for (int y = 0; y <= ny; y++)
            for (int i = 0; i <= nx; i++) {
                double theta = Math.PI * y / ny, phi = 2 * Math.PI * i / nx;
                int p = (y * (nx + 1) + i) * 3;
                positions[p] = x + .72f * (float) (Math.sin(theta) * Math.cos(phi));
                positions[p + 1] = .75f + .72f * (float) Math.cos(theta);
                positions[p + 2] = -.1f + .72f * (float) (Math.sin(theta) * Math.sin(phi));
                old[p] = positions[p] + oldX - x;
                old[p + 1] = positions[p + 1];
                old[p + 2] = positions[p + 2];
            }
        for (int y = 0; y < ny; y++)
            for (int i = 0; i < nx; i++) {
                int a = y * (nx + 1) + i, b = a + nx + 1;
                if (y > 0) {
                    indices.add(a);
                    indices.add(b);
                    indices.add(a + 1);
                }
                if (y < ny - 1) {
                    indices.add(a + 1);
                    indices.add(b);
                    indices.add(b + 1);
                }
            }
        var mesh =
                new VeilCreatorMeshes.Mesh(
                        0x434f524e454c4cL,
                        201,
                        1,
                        positions,
                        old,
                        indices.stream().mapToInt(Integer::intValue).toArray());
        if (sphere == null) sphere = VeilCreatorMeshes.register(mesh);
        else sphere.update(mesh);
    }

    static void afterScene(VeilShaderPackRuntime active) {
        if (!ENABLED || complete || pending || !ready) return;
        if (GUIDES) {
            if (active.renderedFrames() < 12) return;
            capture(active, new String[] {"proof"});
            return;
        }
        if (frames < requestedFrames) return;
        capture(active, OUTPUTS);
    }

    private static void capture(VeilShaderPackRuntime active, String[] names) {
        pending = true;
        ready = false;
        var values = new HashMap<String, float[]>();
        for (String name : names) {
            int[] extent = active.outputExtent(name);
            int bytes = extent[0] * extent[1] * 16;
            var buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "GI conformance " + name,
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    bytes);
            try {
                active.readOutput(
                        name,
                        buffer,
                        () -> {
                            try (var mapped = buffer.map(true, false)) {
                                float[] data = new float[bytes / 4];
                                mapped.data()
                                        .order(ByteOrder.nativeOrder())
                                        .asFloatBuffer()
                                        .get(data);
                                values.put(name, data);
                                if (values.size() == names.length) {
                                    if (GUIDES) verifyGuides(values.get("proof"));
                                    else verifyCornell(active, values);
                                    pending = false;
                                }
                            } catch (Exception failure) {
                                fail(failure);
                            } finally {
                                buffer.close();
                            }
                        });
            } catch (RuntimeException failure) {
                buffer.close();
                fail(failure);
            }
        }
    }

    private static void verifyGuides(float[] proof) throws Exception {
        float[][] expected = guideValues();
        for (int i = 0; i < 7; i++)
            for (int c = 0; c < 4; c++) {
                if (i == 6)
                    require(
                            Float.floatToRawIntBits(proof[i * 4 + c])
                                    == Float.floatToRawIntBits(expected[i][c]),
                            "guide identity bits");
                else
                    require(
                            Math.abs(proof[i * 4 + c] - expected[i][c]) < .0001,
                            "guide value channel " + i);
            }
        for (int i = 7; i < 16; i++)
            require(proof[i * 4] == 1, "guide acceptance/rejection case " + i);
        if (!invalidChecked) {
            var runtime = VeilVulkanRuntime.currentOrNull();
            for (int mode : new int[] {1, 2}) {
                badMode = mode;
                boolean rejected = false;
                try {
                    new VeilSurfaceGuideFrame(
                            latestContext, action -> runtime.deferDestroy(action::run));
                } catch (IllegalArgumentException expectedFailure) {
                    rejected = true;
                }
                require(rejected, "stale/missing provider frame rejected");
            }
            badMode = 0;
            invalidChecked = true;
            ready = true;
            return;
        }
        require(released > 0, "provider leases released after GPU");
        EVIDENCE.add(
                "Surface guides: 7 channels exact, 9 rejection/acceptance cases, stale/missing rejected; acquired="
                        + acquired
                        + " retired="
                        + released);
        finish("Veil surface guide GPU: PASS");
    }

    private static void verifyCornell(VeilShaderPackRuntime active, Map<String, float[]> data)
            throws Exception {
        for (var entry : data.entrySet())
            if (!entry.getKey().equals("identity"))
                for (float v : entry.getValue())
                    require(Float.isFinite(v), "finite " + entry.getKey());
        CAPTURES.put(stage, data);
        float indirect = mean(data.get("components"), null, -1, 0);
        int mirrors = 0, glass = 0;
        double mirrorEnergy = 0;
        float maxMotion = 0;
        for (int p = 0; p < data.get("identity").length / 4; p++) {
            int id = Float.floatToRawIntBits(data.get("identity")[p * 4 + 2]);
            if (id == 201) {
                mirrors++;
                mirrorEnergy += luma(data.get("raw"), p);
                maxMotion =
                        Math.max(
                                maxMotion,
                                Math.abs(data.get("motion")[p * 4])
                                        + Math.abs(data.get("motion")[p * 4 + 1]));
            }
            if (id == 103) glass++;
        }
        require(mirrors > 80 && glass > 80, "mirror/glass coverage");
        if (stage == 0) {
            require(indirect > .005, "nonzero indirect transport");
            require(mirrorEnergy / mirrors > .01, "colored environment visible in reflections");
        }
        if (stage == 2) {
            double raw = mse(CAPTURES.get(1).get("raw"), CAPTURES.get(0).get("raw"), data, false);
            double temporal = mse(data.get("history"), CAPTURES.get(0).get("raw"), data, false);
            EVIDENCE.add("low-SPP MSE=" + raw + " temporal MSE=" + temporal);
            require(temporal < raw * .8, "temporal noise reduction without more SPP");
        }
        if (stage == 3) {
            float[] white = CAPTURES.get(0).get("raw"), direct = data.get("raw");
            double[] left = new double[3], right = new double[3];
            int nl = 0, nr = 0;
            for (int p = 0; p < white.length / 4; p++)
                if (Float.floatToRawIntBits(data.get("identity")[p * 4 + 2]) == 100
                        && data.get("normal")[p * 4 + 1] > .95) {
                    boolean l = p % 160 < 80;
                    if (l) nl++;
                    else nr++;
                    for (int c = 0; c < 3; c++)
                        (l ? left : right)[c] += white[p * 4 + c] - direct[p * 4 + c];
                }
            EVIDENCE.add(
                    "floor bleeding left="
                            + Arrays.toString(left)
                            + " right="
                            + Arrays.toString(right)
                            + " pixels="
                            + nl
                            + "/"
                            + nr);
            require(
                    nl > 50 && nr > 50 && left[0] > left[1] && right[1] > right[0],
                    "red/green indirect color bleeding");
        }
        if (stage == 5) {
            double[] blue = colorFor(CAPTURES.get(4), 103), red = colorFor(data, 103);
            EVIDENCE.add(
                    "blue glass RGB="
                            + Arrays.toString(blue)
                            + " red glass RGB="
                            + Arrays.toString(red));
            require(
                    blue[2] > blue[0] * 1.15 && red[0] > red[2] * 1.15,
                    "colored glass transmission");
        }
        if (stage == 6)
            require(
                    mse(data.get("filtered"), CAPTURES.get(5).get("raw"), data, false) > .0001,
                    "same-energy light moved changes illumination");
        if (stage == 7) {
            int reset = 0;
            for (int p = 0; p < data.get("identity").length / 4; p++)
                if (Float.floatToRawIntBits(data.get("identity")[p * 4 + 2]) == 201) {
                    require(
                            Math.abs(data.get("normal")[p * 4 + 3] - .45) < .001,
                            "entity PBR roughness update visible");
                    if (data.get("history")[p * 4 + 3] == 1) reset++;
                }
            require(reset > mirrors * .9, "material change rejects reflection history");
        }
        if (stage == 8) require(maxMotion > .001, "moving reflection geometry exports motion");
        if (stage == 9) require(maxMotion < .00001, "stopped reflection geometry has zero motion");
        if (stage == 10) {
            double temporal = mse(CAPTURES.get(9).get("history"), data.get("raw"), data, true);
            EVIDENCE.add("moved/stopped specular MSE=" + temporal);
            require(Double.isFinite(temporal), "specular temporal result");
        }
        if (stage >= 12 && stage <= 15) {
            int reset = 0;
            for (int p = 0; p < data.get("history").length / 4; p++)
                if (data.get("history")[p * 4 + 3] == 1) reset++;
            require(
                    reset > data.get("history").length / 4 * .95,
                    "GI history reset after resize/reload/dimension");
        }
        EVIDENCE.add(
                "stage="
                        + stage
                        + " indirect="
                        + indirect
                        + " mirror_pixels="
                        + mirrors
                        + " mirror_energy="
                        + mirrorEnergy / mirrors
                        + " glass_pixels="
                        + glass
                        + " max_motion="
                        + maxMotion
                        + " PASS");
        var directory = VeilPlatform.get().getGameDir().resolve("logs/gi-cornell");
        Files.createDirectories(directory);
        png(
                directory.resolve(String.format("stage-%02d-final.png", stage)),
                data.get("filtered"),
                true);
        if (stage == 2 || stage == 9 || stage == 16) {
            png(
                    directory.resolve(String.format("stage-%02d-raw.png", stage)),
                    data.get("raw"),
                    true);
            png(
                    directory.resolve(String.format("stage-%02d-indirect.png", stage)),
                    data.get("components"),
                    true);
        }
        Files.writeString(
                directory.resolve(String.format("stage-%02d-profile.txt", stage)),
                active.performanceReport());
        ReviveMod.LOGGER.info("Veil Cornell GI stage: {}", EVIDENCE.getLast());
        if (stage == 16) {
            finish("Veil Cornell GI GPU: PASS");
            return;
        }
        stage++;
        initialized = false;
    }

    private static double[] colorFor(Map<String, float[]> data, int id) {
        double[] rgb = new double[3];
        int n = 0;
        for (int p = 0; p < data.get("identity").length / 4; p++)
            if (Float.floatToRawIntBits(data.get("identity")[p * 4 + 2]) == id) {
                for (int c = 0; c < 3; c++) rgb[c] += data.get("raw")[p * 4 + c];
                n++;
            }
        for (int c = 0; c < 3; c++) rgb[c] /= Math.max(n, 1);
        return rgb;
    }

    private static float mean(float[] a, float[] id, int material, int channel) {
        double sum = 0;
        int n = 0;
        for (int p = 0; p < a.length / 4; p++) {
            if (id != null && Float.floatToRawIntBits(id[p * 4 + 2]) != material) continue;
            sum += channel < 0 ? luma(a, p) : a[p * 4 + channel];
            n++;
        }
        return (float) (sum / Math.max(n, 1));
    }

    private static double luma(float[] a, int p) {
        return .2126 * a[p * 4] + .7152 * a[p * 4 + 1] + .0722 * a[p * 4 + 2];
    }

    private static double mse(float[] a, float[] b, Map<String, float[]> guides, boolean specular) {
        double e = 0;
        int n = 0;
        for (int p = 0; p < a.length / 4; p++) {
            int id = Float.floatToRawIntBits(guides.get("identity")[p * 4 + 2]);
            if (specular ? id != 201 : id != 100) continue;
            for (int c = 0; c < 3; c++) {
                double d = a[p * 4 + c] - b[p * 4 + c];
                e += d * d;
                n++;
            }
        }
        return e / Math.max(n, 1);
    }

    private static void png(java.nio.file.Path path, float[] values, boolean tone)
            throws Exception {
        var image =
                new java.awt.image.BufferedImage(
                        160, 120, java.awt.image.BufferedImage.TYPE_INT_RGB);
        for (int p = 0; p < 160 * 120; p++) {
            int rgb = 0;
            for (int c = 0; c < 3; c++) {
                double v = Math.max(0, values[p * 4 + c]);
                if (tone) v = Math.pow(v / (1 + v), 1 / 2.2);
                rgb = rgb << 8 | (int) Math.round(Math.clamp(v, 0, 1) * 255);
            }
            image.setRGB(p % 160, p / 160, rgb);
        }
        javax.imageio.ImageIO.write(image, "png", path.toFile());
    }

    private static void finish(String marker) throws Exception {
        complete = true;
        var directory = VeilPlatform.get().getGameDir().resolve("logs/gi-cornell");
        Files.createDirectories(directory);
        Files.write(directory.resolve(GUIDES ? "guides-proof.txt" : "cornell-proof.txt"), EVIDENCE);
        ReviveMod.LOGGER.info("{} cases={}", marker, EVIDENCE.size());
        if (provider != null) provider.close();
        if (material != null) material.close();
        if (sphere != null) sphere.close();
        Minecraft.getInstance().stop();
    }

    private static void require(boolean ok, String message) {
        if (!ok) throw new IllegalStateException(message);
    }

    private static void fail(Throwable failure) {
        complete = true;
        ReviveMod.LOGGER.error("Veil GI conformance: FAIL stage=" + stage, failure);
        Minecraft.getInstance().stop();
    }
}
