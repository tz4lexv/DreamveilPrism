package dev.veil.revive.client.graphics.synchronization;

import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.vulkan.VulkanGpuBuffer;
import com.mojang.blaze3d.vulkan.VulkanGpuTexture;

import dev.veil.revive.client.VeilRenderGraph;

import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;

import java.util.List;
import java.util.Map;
import java.util.function.ToIntFunction;
import java.util.function.ToLongFunction;

public final class BarrierRecorder<N> {
    private final ToLongFunction<N> nativeHandle;
    private final ToIntFunction<N> nativeAspect;
    private final ToIntFunction<N> nativeMips;
    private final ToIntFunction<N> nativeLayers;

    public BarrierRecorder(
            ToLongFunction<N> nativeHandle,
            ToIntFunction<N> nativeAspect,
            ToIntFunction<N> nativeMips,
            ToIntFunction<N> nativeLayers) {
        this.nativeHandle = nativeHandle;
        this.nativeAspect = nativeAspect;
        this.nativeMips = nativeMips;
        this.nativeLayers = nativeLayers;
    }

    public void record(
            VkCommandBuffer command,
            List<VeilRenderGraph.Barrier> barriers,
            Map<String, GpuBuffer> bufferResources,
            Map<String, GpuTexture> imageResources,
            Map<String, N> nativeImages) {
        if (barriers.isEmpty()) return;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            int bufferCount = 0;
            for (var barrier : barriers)
                if (bufferResources.containsKey(barrier.resource())) bufferCount++;
            int imageCount = barriers.size() - bufferCount;
            var buffers = VkBufferMemoryBarrier2.calloc(bufferCount, stack);
            var images = VkImageMemoryBarrier2.calloc(imageCount, stack);
            int bufferIndex = 0, imageIndex = 0;
            for (var barrier : barriers) {
                GpuBuffer buffer = bufferResources.get(barrier.resource());
                if (buffer != null) {
                    boolean executionOnly =
                            BufferDependencies.executionOnly(
                                    barrier.source(), barrier.destination());
                    buffers.get(bufferIndex++)
                            .sType$Default()
                            .srcStageMask(barrier.source().stages())
                            .srcAccessMask(executionOnly ? 0 : barrier.source().access())
                            .dstStageMask(barrier.destination().stages())
                            .dstAccessMask(executionOnly ? 0 : barrier.destination().access())
                            .srcQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                            .dstQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                            .buffer(((VulkanGpuBuffer) buffer).vkBuffer())
                            .offset(
                                    barrier.subresource().bufferRange()
                                            ? barrier.subresource().byteOffset()
                                            : 0)
                            .size(
                                    barrier.subresource().bufferRange()
                                            ? barrier.subresource().byteCount()
                                            : buffer.size());
                } else {
                    N nativeImage = nativeImages.get(barrier.resource());
                    long imageHandle;
                    int aspect;
                    int importedMips = 1, importedLayers = 1;
                    if (nativeImage != null) {
                        imageHandle = nativeHandle.applyAsLong(nativeImage);
                        aspect = nativeAspect.applyAsInt(nativeImage);
                    } else {
                        var image = (VulkanGpuTexture) imageResources.get(barrier.resource());
                        if (image == null)
                            throw new IllegalStateException(
                                    "Image barrier resource unavailable: " + barrier.resource());
                        imageHandle = image.vkImage();
                        importedMips = image.getMipLevels();
                        importedLayers = image.getDepthOrLayers();
                        aspect =
                                image.getFormat().hasDepthAspect()
                                        ? VK_IMAGE_ASPECT_DEPTH_BIT
                                        : VK_IMAGE_ASPECT_COLOR_BIT;
                        if (image.getFormat().hasStencilAspect())
                            aspect |= VK_IMAGE_ASPECT_STENCIL_BIT;
                    }
                    var nativeBarrier =
                            images.get(imageIndex++)
                                    .sType$Default()
                                    .srcStageMask(barrier.source().stages())
                                    .srcAccessMask(barrier.source().access())
                                    .dstStageMask(barrier.destination().stages())
                                    .dstAccessMask(barrier.destination().access())
                                    .oldLayout(vkLayout(barrier.source().layout()))
                                    .newLayout(vkLayout(barrier.destination().layout()))
                                    .srcQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                                    .dstQueueFamilyIndex(VK_QUEUE_FAMILY_IGNORED)
                                    .image(imageHandle);
                    int totalMips =
                            nativeImage != null ? nativeMips.applyAsInt(nativeImage) : importedMips;
                    int totalLayers =
                            nativeImage != null
                                    ? nativeLayers.applyAsInt(nativeImage)
                                    : importedLayers;
                    VeilRenderGraph.Subresource range = barrier.subresource();
                    if (nativeImage == null)
                        range = ImportedImageRanges.resolve(range, totalMips, totalLayers);
                    int baseMip = range.whole() ? 0 : range.baseMip();
                    int levelCount = range.whole() ? totalMips : range.levelCount();
                    int baseLayer = range.whole() ? 0 : range.baseLayer();
                    int layerCount = range.whole() ? totalLayers : range.layerCount();
                    if (baseMip + levelCount > totalMips || baseLayer + layerCount > totalLayers) {
                        throw new IllegalStateException(
                                "Barrier subresource exceeds image allocation: "
                                        + barrier.resource());
                    }
                    nativeBarrier
                            .subresourceRange()
                            .aspectMask(aspect)
                            .baseMipLevel(baseMip)
                            .levelCount(levelCount)
                            .baseArrayLayer(baseLayer)
                            .layerCount(layerCount);
                }
            }
            var dependency = VkDependencyInfo.calloc(stack).sType$Default();
            if (bufferCount != 0) dependency.pBufferMemoryBarriers(buffers);
            if (imageCount != 0) dependency.pImageMemoryBarriers(images);
            KHRSynchronization2.vkCmdPipelineBarrier2KHR(command, dependency);
        }
    }

    private static int vkLayout(VeilRenderGraph.Layout layout) {
        return switch (layout) {
            case UNDEFINED -> VK_IMAGE_LAYOUT_UNDEFINED;
            case GENERAL -> VK_IMAGE_LAYOUT_GENERAL;
            case SHADER_READ_ONLY -> VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
            case COLOR_ATTACHMENT -> VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
            case DEPTH_READ_ONLY -> VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
            case DEPTH_ATTACHMENT -> VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
            case TRANSFER_SOURCE -> VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
            case TRANSFER_DESTINATION -> VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
            case NONE -> throw new IllegalArgumentException("Image state has no layout");
        };
    }
}
