package dev.veil.revive.client;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

final class VeilSlangCompiler {
    static final String VERSION = "2026.18.3";
    private static final String[] BINARIES = {
        "slangc.exe", "slang.dll", "slang-compiler.dll", "slang-glslang.dll"
    };
    private static Path compiler;
    private static String compilerIdentity;

    private VeilSlangCompiler() {}

    static synchronized String identity() throws IOException {
        if (compiler == null) {
            String override = System.getProperty("veil.slangc");
            if (override != null && !override.isBlank()) {
                compiler = Path.of(override).toRealPath();
                if (!Files.isRegularFile(compiler))
                    throw new IOException("Slang compiler is not a file: " + compiler);
            } else {
                String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
                String arch = System.getProperty("os.arch", "");
                if (!os.contains("win") || !(arch.equals("amd64") || arch.equals("x86_64")))
                    throw new IOException(
                            "Slang source compilation requires -Dveil.slangc=/path/to/slangc on this platform; precompiled SPIR-V and GLSL remain available");
                Path directory = Files.createTempDirectory("veil-slang-compiler-");
                directory.toFile().deleteOnExit();
                for (String name : BINARIES) {
                    Path file = directory.resolve(name);
                    try (var input =
                            VeilSlangCompiler.class.getResourceAsStream(
                                    "/assets/veil/slang/compiler/windows-x86_64/" + name)) {
                        if (input == null)
                            throw new IOException("Missing bundled Slang compiler file " + name);
                        Files.copy(input, file);
                    }
                    file.toFile().deleteOnExit();
                }
                compiler = directory.resolve("slangc.exe");
            }
            Path versionLog = Files.createTempFile("veil-slang-version-", ".log");
            try {
                run(List.of(compiler.toString(), "-version"), compiler.getParent(), versionLog);
                String version = Files.readString(versionLog).trim();
                if (!version.equals(VERSION))
                    throw new IOException("Veil requires Slang " + VERSION + "; found " + version);
                var hashes = new StringBuilder(VeilShaderAssets.hash(Files.readAllBytes(compiler)));
                for (String name : BINARIES) {
                    Path dependency = compiler.getParent().resolve(name);
                    if (Files.isRegularFile(dependency) && !dependency.equals(compiler))
                        hashes.append(';')
                                .append(name)
                                .append('=')
                                .append(VeilShaderAssets.hash(Files.readAllBytes(dependency)));
                }
                compilerIdentity =
                        "slang="
                                + VERSION
                                + ";binary="
                                + hashes
                                + ";target=spirv1.5;column-major;O3;named-entrypoints";
            } catch (IOException failure) {
                compiler = null;
                throw failure;
            } finally {
                Files.deleteIfExists(versionLog);
            }
        }
        return compilerIdentity;
    }

    static VeilSpirvBinary compile(
            VeilSlangSources.Snapshot snapshot,
            VeilShaderId source,
            VeilShaderStage stage,
            String entryPoint)
            throws IOException {
        String identity = identity();
        String cacheKey =
                VeilShaderAssets.hash(
                        (snapshot.hash() + source + stage + entryPoint + identity)
                                .getBytes(StandardCharsets.UTF_8));
        Path cache = Path.of(System.getProperty("java.io.tmpdir"), "veil-slang-cache-" + VERSION);
        Files.createDirectories(cache);
        Path cached = cache.resolve(cacheKey + ".spv");
        if (Files.isRegularFile(cached)
                && Files.size(cached) <= VeilShaderAssets.MAX_SHADER_ASSET_BYTES) {
            try {
                return binary(Files.readAllBytes(cached), source, stage, entryPoint, cacheKey);
            } catch (IllegalArgumentException malformed) {
                Files.deleteIfExists(cached);
            }
        }
        Path temporary = Files.createTempDirectory("veil-slang-source-");
        try {
            for (var file : snapshot.files().entrySet()) {
                Path target =
                        temporary
                                .resolve(file.getKey().namespace())
                                .resolve(file.getKey().path())
                                .normalize();
                if (!target.startsWith(temporary))
                    throw new IOException("Invalid Slang staging path");
                Files.createDirectories(target.getParent());
                Files.write(target, file.getValue());
            }
            Path root = temporary.resolve(source.namespace());
            Path input = root.resolve(source.path());
            Path output = temporary.resolve("output.spv");
            Path log = temporary.resolve("compiler.log");
            var command =
                    new ArrayList<>(
                            List.of(
                                    compiler.toString(),
                                    input.toString(),
                                    "-I",
                                    input.getParent().toString(),
                                    "-I",
                                    root.toString(),
                                    "-I",
                                    temporary.resolve("veil/slang").toString(),
                                    "-entry",
                                    entryPoint,
                                    "-stage",
                                    stageName(stage),
                                    "-target",
                                    "spirv",
                                    "-profile",
                                    "spirv_1_5",
                                    "-emit-spirv-directly",
                                    "-matrix-layout-column-major",
                                    "-fvk-use-entrypoint-name",
                                    "-O3",
                                    "-o",
                                    output.toString()));
            try {
                run(command, temporary, log);
            } catch (IOException failure) {
                String message = Files.exists(log) ? Files.readString(log) : failure.getMessage();
                throw new IOException(
                        "Slang compilation failed for "
                                + source
                                + " ("
                                + entryPoint
                                + "):\n"
                                + message.replace(temporary.toString(), "pack"),
                        failure);
            }
            if (!Files.isRegularFile(output)
                    || Files.size(output) > VeilShaderAssets.MAX_SHADER_ASSET_BYTES)
                throw new IOException("Invalid Slang SPIR-V output size: " + source);
            byte[] bytes = Files.readAllBytes(output);
            var binary = binary(bytes, source, stage, entryPoint, cacheKey);
            Path pending = Files.createTempFile(cache, "compiled-", ".spv");
            try {
                Files.write(pending, bytes);
                try {
                    Files.move(
                            pending,
                            cached,
                            java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                } catch (java.nio.file.AtomicMoveNotSupportedException unavailable) {
                    Files.move(pending, cached, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(pending);
            }
            return binary;
        } finally {
            try (var paths = Files.walk(temporary)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList())
                    Files.deleteIfExists(path);
            }
        }
    }

    private static VeilSpirvBinary binary(
            byte[] bytes, VeilShaderId source, VeilShaderStage stage, String entry, String hash) {
        return new VeilSpirvBinary(bytes, stage, source.toString(), entry, hash);
    }

    private static String stageName(VeilShaderStage stage) {
        return switch (stage) {
            case VERTEX -> "vertex";
            case TESS_CONTROL -> "hull";
            case TESS_EVALUATION -> "domain";
            case GEOMETRY -> "geometry";
            case FRAGMENT -> "fragment";
            case COMPUTE -> "compute";
            case RAYGEN -> "raygeneration";
            case MISS -> "miss";
            case CLOSEST_HIT -> "closesthit";
            case ANY_HIT -> "anyhit";
            case INTERSECTION -> "intersection";
            case CALLABLE -> "callable";
        };
    }

    private static void run(List<String> command, Path directory, Path log) throws IOException {
        Process process =
                new ProcessBuilder(command)
                        .directory(directory.toFile())
                        .redirectErrorStream(true)
                        .redirectOutput(log.toFile())
                        .start();
        try {
            if (!process.waitFor(90, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                process.waitFor();
                throw new IOException("Slang compiler timed out after 90 seconds");
            }
            if (process.exitValue() != 0)
                throw new IOException("Slang compiler exited with " + process.exitValue());
        } catch (InterruptedException interrupted) {
            process.destroyForcibly();
            Thread.currentThread().interrupt();
            throw new IOException("Slang compilation interrupted", interrupted);
        }
    }
}
