package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import dev.veil.revive.client.VeilFaceVisibilityCache;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Pseudo
@Mixin(
        targets =
                "net.fabricmc.fabric.impl.client.indigo.renderer.render.AltModelBlockRendererImpl",
        remap = false)
public abstract class IndigoFaceVisibilityMixin {
    @org.spongepowered.asm.mixin.Shadow @org.spongepowered.asm.mixin.Final private boolean cull;

    @org.spongepowered.asm.mixin.Shadow
    private net.minecraft.client.renderer.block.BlockAndTintGetter level;

    @org.spongepowered.asm.mixin.Shadow private net.minecraft.core.BlockPos pos;
    @org.spongepowered.asm.mixin.Shadow private BlockState blockState;

    @ModifyReturnValue(method = "shouldCullFace", at = @At("RETURN"), require = 1)
    private boolean veil$skipDeepLeafFace(boolean original, Direction direction) {
        if (cull
                && direction != null
                && !original
                && dev.veil.revive.client.VeilLeafCulling.hidesFaceFromOrigin(
                        level, blockState, direction, pos)) return true;
        return original;
    }

    @Redirect(
            method = "shouldCullFace",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lnet/minecraft/world/level/block/Block;shouldRenderFace(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z"),
            require = 1)
    private boolean veil$cachedFace(BlockState state, BlockState neighbor, Direction direction) {
        return VeilFaceVisibilityCache.shouldRenderFace(state, neighbor, direction);
    }
}
