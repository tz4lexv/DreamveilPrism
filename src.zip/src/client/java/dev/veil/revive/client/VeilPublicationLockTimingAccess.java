package dev.veil.revive.client;

public interface VeilPublicationLockTimingAccess {
    VeilPublicationLockJfrProbe veil$publicationLockTiming();
}
