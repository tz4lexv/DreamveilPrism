package dev.veil.revive.client.shaderpack.parsing;

import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.*;
import static dev.veil.revive.client.shaderpack.parsing.SettingsExpressions.*;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import dev.veil.api.VeilScenePass;
import dev.veil.revive.client.VeilShaderPack.Setting;

import java.util.LinkedHashSet;
import java.util.Map;

public final class SceneCameraParser {
    private SceneCameraParser() {}

    public static VeilScenePass scenePass(JsonObject object, Map<String, Setting> settings) {
        fields(object, "camera", "categories", "raster");
        JsonObject camera = object.getAsJsonObject("camera");
        if (camera == null) throw new IllegalArgumentException("Custom scene pass requires camera");
        fields(
                camera,
                "projection",
                "anchor",
                "direction",
                "width",
                "height",
                "near",
                "far",
                "stabilize",
                "position",
                "forward",
                "up",
                "fov");
        VeilScenePass.Projection projection =
                switch (camera.get("projection").getAsString()) {
                    case "orthographic" -> VeilScenePass.Projection.ORTHOGRAPHIC;
                    case "perspective" -> VeilScenePass.Projection.PERSPECTIVE;
                    default ->
                            throw new IllegalArgumentException(
                                    "Unsupported custom scene projection");
                };
        VeilScenePass.Anchor anchor =
                switch (camera.get("anchor").getAsString()) {
                    case "main_camera" -> VeilScenePass.Anchor.MAIN_CAMERA;
                    case "world_position" -> VeilScenePass.Anchor.WORLD_POSITION;
                    default ->
                            throw new IllegalArgumentException("Unsupported custom scene anchor");
                };
        VeilScenePass.Direction direction =
                switch (camera.get("direction").getAsString()) {
                    case "sun" -> VeilScenePass.Direction.SUN;
                    case "fixed" -> VeilScenePass.Direction.FIXED;
                    default ->
                            throw new IllegalArgumentException(
                                    "Unsupported custom scene direction");
                };
        float width = positiveFloatValue(camera.get("width"), settings, "scene camera width");
        float height = positiveFloatValue(camera.get("height"), settings, "scene camera height");
        float near = floatValue(camera.get("near"), settings, "scene camera near");
        float far = floatValue(camera.get("far"), settings, "scene camera far");
        if (anchor == VeilScenePass.Anchor.WORLD_POSITION && !camera.has("position"))
            throw new IllegalArgumentException("World scene camera requires position");
        if (direction == VeilScenePass.Direction.FIXED && !camera.has("forward"))
            throw new IllegalArgumentException("Fixed scene camera requires forward");
        if (direction == VeilScenePass.Direction.SUN && (camera.has("forward") || camera.has("up")))
            throw new IllegalArgumentException("Explicit forward/up requires fixed direction");
        double[] position = sceneCameraVector(camera, "position", settings, new double[] {0, 0, 0});
        double[] forward = sceneCameraVector(camera, "forward", settings, new double[] {0, 0, -1});
        double[] up = sceneCameraVector(camera, "up", settings, new double[] {0, 1, 0});
        var pose =
                new VeilScenePass.Pose(
                        position[0],
                        position[1],
                        position[2],
                        (float) forward[0],
                        (float) forward[1],
                        (float) forward[2],
                        (float) up[0],
                        (float) up[1],
                        (float) up[2]);
        float fov =
                camera.has("fov")
                        ? floatValue(camera.get("fov"), settings, "scene camera fov")
                        : 60.0f;
        var categories = new LinkedHashSet<VeilScenePass.Category>();
        JsonArray values = object.getAsJsonArray("categories");
        if (values == null)
            throw new IllegalArgumentException("Custom scene pass requires categories");
        for (JsonElement value : values)
            categories.add(
                    switch (value.getAsString()) {
                        case "terrain_opaque" -> VeilScenePass.Category.TERRAIN_OPAQUE;
                        case "terrain_cutout" -> VeilScenePass.Category.TERRAIN_CUTOUT;
                        case "entities" -> VeilScenePass.Category.ENTITIES;
                        case "block_entities" -> VeilScenePass.Category.BLOCK_ENTITIES;
                        default ->
                                throw new IllegalArgumentException(
                                        "Unsupported custom scene category " + value);
                    });
        return new VeilScenePass(
                new VeilScenePass.Camera(
                        projection,
                        anchor,
                        direction,
                        width,
                        height,
                        near,
                        far,
                        camera.has("stabilize") && camera.get("stabilize").getAsBoolean(),
                        pose,
                        fov),
                categories,
                object.has("raster")
                        ? SceneRasterParser.parse(object.getAsJsonObject("raster"), settings)
                        : VeilScenePass.Raster.INHERIT);
    }

    private static double[] sceneCameraVector(
            JsonObject camera, String name, Map<String, Setting> settings, double[] fallback) {
        if (!camera.has(name)) return fallback;
        JsonArray values = camera.getAsJsonArray(name);
        if (values == null || values.size() != 3)
            throw new IllegalArgumentException(
                    "Scene camera " + name + " requires three components");
        double[] result = new double[3];
        for (int index = 0; index < 3; index++) {
            String value = values.get(index).getAsString();
            if (settings.containsKey(value)) value = settings.get(value).value();
            result[index] = Double.parseDouble(value);
            if (!Double.isFinite(result[index]))
                throw new IllegalArgumentException("Scene camera " + name + " must be finite");
        }
        return result;
    }
}
