package dev.veil.revive.client;

import com.mojang.blaze3d.GpuFormat;

import dev.veil.api.VeilFormat;
import dev.veil.revive.client.graphics.minecraft.VulkanFormats;

final class VeilVulkanFormats {
    private VeilVulkanFormats() {}

    static int vk(VeilFormat format) {
        return VulkanFormats.vk(format);
    }

    static GpuFormat minecraft(VeilFormat format) {
        return VulkanFormats.minecraft(format);
    }

    static VeilFormat veil(GpuFormat format) {
        return VulkanFormats.veil(format);
    }
}
