package dev.veil.revive.client;

import com.mojang.blaze3d.vertex.QuadInstance;

import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.ARGB;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.world.level.block.state.BlockState;

import org.joml.Vector3fc;

public final class VeilSmoothQuadLighting {
    private static final Direction[] FIRST = {
        Direction.WEST, Direction.EAST, Direction.UP, Direction.WEST, Direction.UP, Direction.DOWN
    };
    private static final Direction[] SECOND = {
        Direction.NORTH,
        Direction.NORTH,
        Direction.EAST,
        Direction.DOWN,
        Direction.NORTH,
        Direction.NORTH
    };
    private static final Direction[] DIRECTIONS = Direction.values();
    private static final boolean LEGACY_BLEND =
            Boolean.getBoolean("neoforge.ao.disableLightmapBlendingFix");
    private final VeilFlatQuadLighting.Lookup lookup;
    private final boolean fabricCenter, offsetChecks, legacyBlend;
    private final float[] brightness = new float[96];
    private final int[] light = new int[96];
    private final float[] samples = new float[9];
    private final int[] sampleLight = new int[9];
    private final boolean[] clear = new boolean[9];
    private final float[] weights = new float[4];
    private final BlockPos.MutableBlockPos scratch = new BlockPos.MutableBlockPos();
    private int ready;

    public VeilSmoothQuadLighting(VeilFlatQuadLighting.Lookup lookup) {
        this(lookup, false, true, !LEGACY_BLEND);
    }

    public VeilSmoothQuadLighting(
            VeilFlatQuadLighting.Lookup lookup,
            boolean fabricCenter,
            boolean offsetChecks,
            boolean correctedBlend) {
        this.lookup = lookup;
        this.fabricCenter = fabricCenter;
        this.offsetChecks = offsetChecks;
        this.legacyBlend = !correctedBlend;
    }

    public float cornerBrightness(int index) {
        return brightness[index];
    }

    public int cornerLight(int index) {
        return light[index];
    }

    public void begin() {
        ready = 0;
    }

    public void prepare(
            BlockAndTintGetter world,
            BlockState state,
            BlockPos pos,
            BakedQuad quad,
            float[] normals,
            QuadInstance output) {
        Direction face = quad.direction();
        float lo = 32f, hi = -32f;
        for (int v = 0; v < 4; v++) {
            float coordinate = coordinate(quad.position(v), face.getAxis());
            lo = Math.min(lo, coordinate);
            hi = Math.max(hi, coordinate);
        }
        boolean full = state.isCollisionShapeFullBlock(world, pos);
        boolean shade = quad.materialInfo().shade();
        if (lo == hi) {
            boolean outside =
                    (face.getAxisDirection() == Direction.AxisDirection.POSITIVE
                                    ? hi > 0.9999f
                                    : lo < 0.0001f)
                            || full;
            int slot = face(world, state, pos, face, shade, outside);
            for (int v = 0; v < 4; v++) {
                weights(face, quad.position(v));
                output.setColor(v, ARGB.gray(brightness(slot)));
                output.setLightCoords(v, light(slot));
            }
            return;
        }
        for (int v = 0; v < 4; v++) {
            float sum = 0f, maximum = 0f;
            int sumLight = 0, maximumLight = 0;
            Vector3fc point = quad.position(v);
            for (int axis = 0; axis < 3; axis++) {
                float n = normals[v * 3 + axis];
                if (n == 0) continue;
                Direction projection =
                        DIRECTIONS[
                                switch (axis) {
                                    case 0 -> n > 0 ? 5 : 4;
                                    case 1 -> n > 0 ? 1 : 0;
                                    default -> n > 0 ? 3 : 2;
                                }];
                float coordinate = coordinate(point, projection.getAxis());
                float depth =
                        projection.getAxisDirection() == Direction.AxisDirection.POSITIVE
                                ? 1f - coordinate
                                : coordinate;
                int slot = face(world, state, pos, projection, shade, depth < 0.0001f || full);
                weights(projection, point);
                float value = brightness(slot);
                int packed = light(slot);
                float contribution = n * n;
                sum += value * contribution;
                sumLight = blend(sumLight, 1f, packed, contribution);
                maximum = Math.max(maximum, value);
                maximumLight =
                        LightCoordsUtil.smoothPack(
                                Math.max(
                                        LightCoordsUtil.smoothBlock(maximumLight),
                                        LightCoordsUtil.smoothBlock(packed)),
                                Math.max(
                                        LightCoordsUtil.smoothSky(maximumLight),
                                        LightCoordsUtil.smoothSky(packed)));
            }
            output.setColor(v, ARGB.gray(Math.clamp(sum * 0.75f + maximum * 0.25f, 0f, 1f)));
            output.setLightCoords(v, blend(sumLight, 0.75f, maximumLight, 0.25f));
        }
    }

    public int face(
            BlockAndTintGetter world,
            BlockState state,
            BlockPos pos,
            Direction face,
            boolean shade,
            boolean outside) {
        int key = face.ordinal() + (outside ? 6 : 0) + (shade ? 12 : 0);
        int offset = key * 4;
        if ((ready & (1 << key)) != 0) return offset;
        int x = pos.getX() + (outside ? face.getStepX() : 0);
        int y = pos.getY() + (outside ? face.getStepY() : 0);
        int z = pos.getZ() + (outside ? face.getStepZ() : 0);
        Direction a = FIRST[face.ordinal()], b = SECOND[face.ordinal()];
        for (int i = 0; i < 4; i++) {
            Direction side = i < 2 ? a : b;
            int sign = (i & 1) == 0 ? 1 : -1;
            scratch.set(
                    x + sign * side.getStepX(),
                    y + sign * side.getStepY(),
                    z + sign * side.getStepZ());
            sample(world, world.getBlockState(scratch), i);
            if (!offsetChecks) {
                scratch.move(face);
                BlockState blocking = world.getBlockState(scratch);
                clear[i] =
                        !blocking.isViewBlocking(world, scratch)
                                || blocking.getLightDampening() == 0;
            }
        }
        for (int i = 0; i < 4; i++) {
            int ai = i < 2 ? 0 : 1, bi = (i & 1) + 2;
            if (!clear[ai] && !clear[bi]) {
                samples[i + 4] = samples[ai];
                sampleLight[i + 4] = sampleLight[ai];
                clear[i + 4] = false;
            } else {
                int sa = ai == 0 ? 1 : -1, sb = bi == 2 ? 1 : -1;
                scratch.set(
                        x + sa * a.getStepX() + sb * b.getStepX(),
                        y + sa * a.getStepY() + sb * b.getStepY(),
                        z + sa * a.getStepZ() + sb * b.getStepZ());
                sample(world, world.getBlockState(scratch), i + 4);
            }
        }
        scratch.set(x, y, z);
        sample(world, outside || fabricCenter ? world.getBlockState(scratch) : state, 8);
        if (fabricCenter) {
            scratch.setWithOffset(pos, face);
            BlockState neighbor = world.getBlockState(scratch);
            if (!outside || neighbor.isSolidRender()) {
                scratch.set(pos);
                neighbor = state;
            }
            sampleLight[8] = lookup.light(neighbor, world, scratch);
            clear[8] =
                    !neighbor.isViewBlocking(world, scratch) || neighbor.getLightDampening() == 0;
        }
        float directional =
                shade ? world.cardinalLighting().byFace(face) : world.cardinalLighting().up();
        for (int i = 0; i < 4; i++) {
            int ai = i < 2 ? 0 : 1, bi = i == 0 || i == 3 ? 3 : 2;
            int diagonal = 4 + ai * 2 + bi - 2;
            brightness[offset + i] =
                    ((samples[bi] + samples[ai] + samples[diagonal] + samples[8]) * 0.25f)
                            * directional;
            light[offset + i] = cornerLight(bi, ai, diagonal);
        }
        ready |= 1 << key;
        return offset;
    }

    private void sample(BlockAndTintGetter world, BlockState state, int index) {
        samples[index] = state.getShadeBrightness(world, scratch);
        sampleLight[index] = lookup.light(state, world, scratch);
        clear[index] = !state.isViewBlocking(world, scratch) || state.getLightDampening() == 0;
    }

    private int cornerLight(int a, int b, int diagonal) {
        int first = sampleLight[a],
                second = sampleLight[b],
                corner = sampleLight[diagonal],
                inside = sampleLight[8];
        if (legacyBlend) {
            if (first == 0) first = inside;
            if (second == 0) second = inside;
            if (corner == 0) corner = inside;
        } else {
            int minBlock = 65536, minSky = 65536;
            for (int i = 0; i < 4; i++) {
                int index =
                        switch (i) {
                            case 0 -> a;
                            case 1 -> b;
                            case 2 -> diagonal;
                            default -> 8;
                        };
                if (clear[index]) {
                    minBlock = Math.min(minBlock, LightCoordsUtil.smoothBlock(sampleLight[index]));
                    minSky = Math.min(minSky, LightCoordsUtil.smoothSky(sampleLight[index]));
                }
            }
            minBlock &= 65535;
            minSky &= 65535;
            first = floor(first, minBlock, minSky);
            second = floor(second, minBlock, minSky);
            corner = floor(corner, minBlock, minSky);
            inside = floor(inside, minBlock, minSky);
        }
        return ((first + second + corner + inside) >> 2) & 0xFF00FF;
    }

    private static int floor(int light, int block, int sky) {
        return LightCoordsUtil.smoothPack(
                Math.max(block, LightCoordsUtil.smoothBlock(light)),
                Math.max(sky, LightCoordsUtil.smoothSky(light)));
    }

    private void weights(Direction face, Vector3fc point) {
        Direction a = FIRST[face.ordinal()], b = SECOND[face.ordinal()];
        float u = Math.clamp(coordinate(point, a.getAxis()), 0f, 1f),
                v = Math.clamp(coordinate(point, b.getAxis()), 0f, 1f);
        float a0 = a.getAxisDirection() == Direction.AxisDirection.POSITIVE ? u : 1f - u;
        float a1 = a.getAxisDirection() == Direction.AxisDirection.POSITIVE ? 1f - u : u;
        float b0 = b.getAxisDirection() == Direction.AxisDirection.POSITIVE ? v : 1f - v;
        float b1 = b.getAxisDirection() == Direction.AxisDirection.POSITIVE ? 1f - v : v;
        weights[0] = a0 * b1;
        weights[1] = a0 * b0;
        weights[2] = a1 * b0;
        weights[3] = a1 * b1;
    }

    private float brightness(int offset) {
        return Math.clamp(
                brightness[offset] * weights[0]
                        + brightness[offset + 1] * weights[1]
                        + brightness[offset + 2] * weights[2]
                        + brightness[offset + 3] * weights[3],
                0f,
                1f);
    }

    private int light(int offset) {
        return LightCoordsUtil.smoothWeightedBlend(
                light[offset],
                light[offset + 1],
                light[offset + 2],
                light[offset + 3],
                weights[0],
                weights[1],
                weights[2],
                weights[3]);
    }

    private static float coordinate(Vector3fc point, Direction.Axis axis) {
        return switch (axis) {
            case X -> point.x();
            case Y -> point.y();
            case Z -> point.z();
        };
    }

    private static int blend(int first, float a, int second, float b) {
        int block =
                Math.round(
                                LightCoordsUtil.smoothBlock(first) * a
                                        + LightCoordsUtil.smoothBlock(second) * b)
                        & 255;
        int sky =
                Math.round(
                                LightCoordsUtil.smoothSky(first) * a
                                        + LightCoordsUtil.smoothSky(second) * b)
                        & 255;
        return LightCoordsUtil.smoothPack(block, sky);
    }
}
