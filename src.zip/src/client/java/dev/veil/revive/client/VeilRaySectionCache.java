package dev.veil.revive.client;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

final class VeilRaySectionCache {
    record Key(Object geometry, int triangles) {}

    record Section(Key key, float x, float y, float z, Supplier<byte[]> compile) {}

    record Part(Key key, byte[] bytes, int triangleOffset, float x, float y, float z) {}

    record Result(byte[] bytes, List<Part> parts, int rebuilt, int reused) {}

    private record Local(Section section, ByteBuffer data) {}

    private static final class Node {
        float[] min = new float[3], max = new float[3];
        int first, count, escape;
    }

    private Object generation;
    private Map<Key, byte[]> cache = new HashMap<>();

    void clear() {
        cache.clear();
        generation = null;
    }

    Result compile(
            Object generation,
            List<Section> sections,
            float ox,
            float oy,
            float oz,
            int minimumBytes) {
        if (this.generation != generation) {
            cache.clear();
            this.generation = generation;
        }
        var next = new HashMap<Key, byte[]>();
        var local = new ArrayList<Local>();
        int rebuilt = 0, reused = 0;
        for (var section : sections) {
            byte[] bytes = cache.get(section.key());
            if (bytes == null) {
                bytes = section.compile().get();
                rebuilt++;
            } else reused++;
            var data = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
            if (data.getInt(0) != VeilRayScene.MAGIC
                    || data.getInt(4) != 3
                    || data.getInt(12) != section.key().triangles()
                    || data.getInt(8) < 1)
                throw new IllegalArgumentException("Invalid cached section ray scene");
            next.put(section.key(), bytes);
            local.add(new Local(section, data));
        }
        var nodes = new ArrayList<Node>();
        var parts = new ArrayList<Part>();
        if (!local.isEmpty()) append(local, 0, local.size(), nodes, parts, new int[1]);
        int triangles = parts.stream().mapToInt(part -> part.key().triangles()).sum();
        int triangleWord = 4 + nodes.size() * 3,
                materialWord = triangleWord + triangles * 3,
                attributeWord = materialWord + 8;
        int bytes = Math.max(minimumBytes, Math.toIntExact((attributeWord + triangles * 3L) * 16));
        if (bytes > VeilShaderLimits.MAX_BUFFER_BYTES)
            throw new IllegalArgumentException("Incremental ray scene exceeds buffer capacity");
        var out = ByteBuffer.allocate(bytes).order(ByteOrder.LITTLE_ENDIAN);
        out.putInt(VeilRayScene.MAGIC).putInt(3).putInt(nodes.size()).putInt(triangles);
        out.putInt(4).putInt(triangleWord).putInt(materialWord).putInt(4);
        out.putFloat(ox).putFloat(oy).putFloat(oz).putInt(3);
        out.putInt(attributeWord).putInt(3).putInt(0).putInt(0);
        for (var node : nodes) {
            for (float value : node.min) out.putFloat(value);
            out.putInt(0);
            for (float value : node.max) out.putFloat(value);
            out.putInt(0);
            out.putInt(node.first).putInt(node.count).putInt(node.escape).putInt(0);
        }
        for (var part : parts) {
            var input = ByteBuffer.wrap(part.bytes()).order(ByteOrder.LITTLE_ENDIAN);
            int start = input.getInt(20) * 16;
            for (int i = 0; i < part.key().triangles(); i++)
                for (int vertex = 0; vertex < 3; vertex++) {
                    int p = start + i * 48 + vertex * 16;
                    out.putFloat(input.getFloat(p) + part.x())
                            .putFloat(input.getFloat(p + 4) + part.y())
                            .putFloat(input.getFloat(p + 8) + part.z());
                    out.putInt(
                            vertex == 1
                                    ? input.getInt(p + 12) + part.triangleOffset()
                                    : input.getInt(p + 12));
                }
        }
        if (parts.isEmpty()) {
            byte[] empty =
                    VeilRayScene.compileWorld(
                            new float[0], new int[0], new int[0], 0, ox, oy, oz, 192);
            out.put(empty, 64, 128);
        } else {
            var first = ByteBuffer.wrap(parts.getFirst().bytes()).order(ByteOrder.LITTLE_ENDIAN);
            out.put(parts.getFirst().bytes(), first.getInt(24) * 16, 128);
        }
        for (var part : parts) {
            var input = ByteBuffer.wrap(part.bytes()).order(ByteOrder.LITTLE_ENDIAN);
            out.put(part.bytes(), input.getInt(48) * 16, part.key().triangles() * 48);
        }
        cache = next;
        return new Result(out.array(), List.copyOf(parts), rebuilt, reused);
    }

    private static void append(
            ArrayList<Local> local,
            int first,
            int end,
            ArrayList<Node> nodes,
            ArrayList<Part> parts,
            int[] triangleOffset) {
        if (end - first == 1) {
            var item = local.get(first);
            var section = item.section();
            var input = item.data();
            int nodeBase = nodes.size(), triangleBase = triangleOffset[0], count = input.getInt(8);
            for (int i = 0; i < count; i++) {
                int p = 64 + i * 48;
                var node = new Node();
                for (int axis = 0; axis < 3; axis++) {
                    float translation =
                            axis == 0 ? section.x() : axis == 1 ? section.y() : section.z();
                    node.min[axis] = Math.nextDown(input.getFloat(p + axis * 4) + translation);
                    node.max[axis] = Math.nextUp(input.getFloat(p + 16 + axis * 4) + translation);
                }
                node.count = input.getInt(p + 36);
                node.first = node.count == 0 ? 0 : input.getInt(p + 32) + triangleBase;
                node.escape = input.getInt(p + 40) + nodeBase;
                nodes.add(node);
            }
            parts.add(
                    new Part(
                            section.key(),
                            input.array(),
                            triangleBase,
                            section.x(),
                            section.y(),
                            section.z()));
            triangleOffset[0] += section.key().triangles();
            return;
        }
        var node = new Node();
        java.util.Arrays.fill(node.min, Float.POSITIVE_INFINITY);
        java.util.Arrays.fill(node.max, Float.NEGATIVE_INFINITY);
        for (int i = first; i < end; i++)
            for (int axis = 0; axis < 3; axis++) {
                var item = local.get(i);
                float t =
                        axis == 0
                                ? item.section().x()
                                : axis == 1 ? item.section().y() : item.section().z();
                node.min[axis] =
                        Math.min(
                                node.min[axis],
                                Math.nextDown(item.data().getFloat(64 + axis * 4) + t));
                node.max[axis] =
                        Math.max(
                                node.max[axis],
                                Math.nextUp(item.data().getFloat(80 + axis * 4) + t));
            }
        int axis = 0;
        for (int a = 1; a < 3; a++)
            if (node.max[a] - node.min[a] > node.max[axis] - node.min[axis]) axis = a;
        int splitAxis = axis;
        local.subList(first, end).sort(Comparator.comparingDouble(item -> center(item, splitAxis)));
        nodes.add(node);
        int mid = (first + end) >>> 1;
        append(local, first, mid, nodes, parts, triangleOffset);
        append(local, mid, end, nodes, parts, triangleOffset);
        node.escape = nodes.size();
    }

    private static float center(Local item, int axis) {
        float t =
                axis == 0
                        ? item.section().x()
                        : axis == 1 ? item.section().y() : item.section().z();
        return (item.data().getFloat(64 + axis * 4) + item.data().getFloat(80 + axis * 4)) * .5f
                + t;
    }
}
