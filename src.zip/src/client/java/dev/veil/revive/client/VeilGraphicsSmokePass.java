package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK10.*;

import com.mojang.blaze3d.GpuFormat;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.revive.ReviveMod;

import org.joml.Vector4f;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VkRect2D;
import org.lwjgl.vulkan.VkViewport;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

public final class VeilGraphicsSmokePass {
    private static final AtomicBoolean ATTEMPTED = new AtomicBoolean();
    private static VeilGraphicsPipeline pipeline;
    private static GpuTexture target;
    private static GpuTextureView targetView;

    private VeilGraphicsSmokePass() {}

    public static void runOnce() {
        if (ATTEMPTED.get() || !VeilVulkanRuntime.isCurrentBackend()) return;
        if (!ATTEMPTED.compareAndSet(false, true)) return;
        try {
            VeilVulkanRuntime runtime = VeilVulkanRuntime.requireCurrent();
            var vs =
                    VeilSpirvCompiler.compile(
                            "veil_v50_smoke.vert", VERTEX_SOURCE, VeilShaderStage.VERTEX);
            var fs =
                    VeilSpirvCompiler.compile(
                            "veil_v50_smoke.frag", FRAGMENT_SOURCE, VeilShaderStage.FRAGMENT);
            VeilShaderInterface reflected =
                    VeilShaderInterface.merge(
                            VeilSpirvReflection.reflect(vs), VeilSpirvReflection.reflect(fs));
            validateReflection(reflected);
            pipeline =
                    VeilGraphicsPipeline.createSimple(
                            runtime, vs, fs, GpuFormat.RGBA8_UNORM, reflected);

            var device = RenderSystem.getDevice();
            target =
                    device.createTexture(
                            "Veil V50 graphics reflection smoke target",
                            GpuTexture.USAGE_RENDER_ATTACHMENT | GpuTexture.USAGE_COPY_SRC,
                            GpuFormat.RGBA8_UNORM,
                            64,
                            64,
                            1,
                            1);
            targetView = device.createTextureView(target);

            var encoder = device.createCommandEncoder();
            try (var pass =
                    encoder.createRenderPass(
                            () -> "Veil V50 native graphics reflection smoke",
                            targetView,
                            Optional.of(new Vector4f(0.0f, 0.0f, 0.0f, 1.0f)))) {
                var cmd = runtime.commandBuffer();
                try (MemoryStack stack = MemoryStack.stackPush()) {
                    VkViewport.Buffer vp = VkViewport.calloc(1, stack);
                    vp.get(0)
                            .x(0.0f)
                            .y(0.0f)
                            .width(64.0f)
                            .height(64.0f)
                            .minDepth(0.0f)
                            .maxDepth(1.0f);
                    VkRect2D.Buffer scissor = VkRect2D.calloc(1, stack);
                    scissor.get(0).offset().set(0, 0);
                    scissor.get(0).extent().set(64, 64);
                    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline.handle());
                    vkCmdSetViewport(cmd, 0, vp);
                    vkCmdSetScissor(cmd, 0, scissor);
                    vkCmdDraw(cmd, 3, 1, 0, 0);
                }
            }
            ReviveMod.LOGGER.info(
                    "Veil V50 native Vulkan shader reflection ACTIVE: SPIR-V reflection + automatic pipeline layout + vertex/fragment Dynamic Rendering + vkCmdDraw");
        } catch (RuntimeException failure) {
            ReviveMod.LOGGER.error("Veil V50 graphics/reflection smoke failed", failure);
            close();
        }
    }

    private static void validateReflection(VeilShaderInterface shader) {
        if (!shader.descriptors().isEmpty() || !shader.pushConstants().isEmpty()) {
            throw new IllegalStateException(
                    "V50 graphics smoke unexpectedly reflected descriptors/push constants");
        }
        boolean fragmentColor =
                shader.stageOutputs().stream()
                        .anyMatch(
                                output ->
                                        output.stageFlags() == VK_SHADER_STAGE_FRAGMENT_BIT
                                                && output.location() == 0);
        if (!fragmentColor) {
            throw new IllegalStateException(
                    "V50 reflection did not report fragment output location 0");
        }
    }

    public static void close() {
        if (targetView != null) {
            targetView.close();
            targetView = null;
        }
        if (target != null) {
            target.close();
            target = null;
        }
        if (pipeline != null) {
            pipeline.close();
            pipeline = null;
        }
    }

    private static final String VERTEX_SOURCE =
            """
            #version 450
            void main() {
                vec2 p[3] = vec2[](vec2(-1.0, -1.0), vec2(3.0, -1.0), vec2(-1.0, 3.0));
                gl_Position = vec4(p[gl_VertexIndex], 0.0, 1.0);
            }
            """;

    private static final String FRAGMENT_SOURCE =
            """
            #version 450
            layout(location = 0) out vec4 outColor;
            void main() {
                outColor = vec4(0.125, 0.5, 1.0, 1.0);
            }
            """;
}
