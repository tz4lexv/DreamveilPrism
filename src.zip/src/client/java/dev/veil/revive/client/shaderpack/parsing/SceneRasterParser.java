package dev.veil.revive.client.shaderpack.parsing;

import static dev.veil.revive.client.shaderpack.parsing.ManifestJson.*;

import com.google.gson.JsonObject;

import dev.veil.api.VeilScenePass;
import dev.veil.revive.client.VeilShaderPack.Setting;

import java.util.Map;

final class SceneRasterParser {
    private SceneRasterParser() {}

    static VeilScenePass.Raster parse(JsonObject source, Map<String, Setting> settings) {
        fields(
                source,
                "depthBias",
                "depthBiasConstant",
                "depthBiasSlope",
                "depthBiasClamp",
                "depthClamp",
                "cullMode",
                "frontFace");
        JsonObject wrapper = new JsonObject();
        wrapper.add("raster", source);
        JsonObject object =
                PipelineSettingInputs.resolve(wrapper, settings).getAsJsonObject("raster");
        VeilScenePass.CullMode cull =
                !object.has("cullMode")
                        ? null
                        : switch (object.get("cullMode").getAsString()) {
                            case "none" -> VeilScenePass.CullMode.NONE;
                            case "front" -> VeilScenePass.CullMode.FRONT;
                            case "back" -> VeilScenePass.CullMode.BACK;
                            case "frontAndBack" -> VeilScenePass.CullMode.FRONT_AND_BACK;
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported scene cullMode");
                        };
        VeilScenePass.FrontFace front =
                !object.has("frontFace")
                        ? null
                        : switch (object.get("frontFace").getAsString()) {
                            case "clockwise" -> VeilScenePass.FrontFace.CLOCKWISE;
                            case "counterClockwise" -> VeilScenePass.FrontFace.COUNTER_CLOCKWISE;
                            default ->
                                    throw new IllegalArgumentException(
                                            "Unsupported scene frontFace");
                        };
        return new VeilScenePass.Raster(
                bool(object, "depthBias"),
                number(object, "depthBiasConstant"),
                number(object, "depthBiasSlope"),
                number(object, "depthBiasClamp"),
                bool(object, "depthClamp"),
                cull,
                front);
    }

    private static Boolean bool(JsonObject object, String field) {
        if (!object.has(field)) return null;
        var value = object.get(field);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isBoolean()) {
            throw new IllegalArgumentException("Scene raster " + field + " must be boolean");
        }
        return value.getAsBoolean();
    }

    private static Float number(JsonObject object, String field) {
        if (!object.has(field)) return null;
        var value = object.get(field);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) {
            throw new IllegalArgumentException("Scene raster " + field + " must be numeric");
        }
        return floating(object, field, 0f);
    }
}
