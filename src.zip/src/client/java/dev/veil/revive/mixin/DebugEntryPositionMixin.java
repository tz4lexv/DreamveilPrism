package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilBridgeStatus;

import net.minecraft.client.gui.components.debug.DebugEntryPosition;
import net.minecraft.client.gui.components.debug.DebugScreenDisplayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DebugEntryPosition.class)
public abstract class DebugEntryPositionMixin {
    @Inject(method = "display", at = @At("HEAD"), require = 0)
    private void revive$veilRendererBeforeCoordinates(
            DebugScreenDisplayer displayer,
            Level level,
            LevelChunk clientChunk,
            LevelChunk serverChunk,
            CallbackInfo ci) {
        if (!ReviveRuntime.enabled()) return;
        displayer.addLine(VeilBridgeStatus.f3Line());
    }
}
