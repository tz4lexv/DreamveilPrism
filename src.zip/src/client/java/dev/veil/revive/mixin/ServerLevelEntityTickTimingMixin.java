package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilDiagnostics;
import dev.veil.revive.client.VeilServerAiCounters;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.villager.Villager;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerLevel.class)
public abstract class ServerLevelEntityTickTimingMixin {
    @Unique private long veil$entityTickStartNs;
    @Unique private boolean veil$entityTickVillager;

    @Inject(method = "tickNonPassenger", at = @At("HEAD"), require = 1)
    private void veil$beginEntityTick(Entity entity, CallbackInfo ci) {
        if (!VeilDiagnostics.benchmarkActive()) {
            veil$entityTickStartNs = 0L;
            return;
        }
        veil$entityTickVillager = entity instanceof Villager;
        veil$entityTickStartNs = System.nanoTime();
    }

    @Inject(method = "tickNonPassenger", at = @At("RETURN"), require = 1)
    private void veil$endEntityTick(Entity entity, CallbackInfo ci) {
        long start = veil$entityTickStartNs;
        veil$entityTickStartNs = 0L;
        if (start != 0L && VeilDiagnostics.benchmarkActive()) {
            VeilServerAiCounters.entityTick(System.nanoTime() - start, veil$entityTickVillager);
        }
    }
}
