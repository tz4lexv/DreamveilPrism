package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilPbrAnimationOwner;

import net.minecraft.client.renderer.texture.SpriteContents;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "net.minecraft.client.renderer.texture.SpriteContents$AnimatedTexture")
public abstract class PbrAnimatedTextureMixin {
    @Inject(method = "createAnimationState", at = @At("RETURN"), require = 1)
    private void veil$pbrAnimation(CallbackInfoReturnable<SpriteContents.AnimationState> cir) {
        if (cir.getReturnValue() != null)
            ((VeilPbrAnimationOwner) (Object) cir.getReturnValue()).veil$setPbrAnimation(this);
    }
}
