package dev.veil.revive.client.diagnostics;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.client.VeilHostRevisions;
import dev.veil.revive.client.VeilTerrainDrawBridge;
import dev.veil.revive.client.VeilWorldHistoryGpuProbe;
import dev.veil.revive.client.graphics.minecraft.MinecraftVulkanContext;
import dev.veil.revive.core.TerrainBridgeCounters;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;

import java.nio.file.Files;
import java.util.Set;

public final class TerrainWorldLifecycleProbe {
    private static final boolean ENABLED =
            VeilPlatform.get().isDevelopmentEnvironment()
                    && Boolean.getBoolean("veil.modularWorldLifecycleProbe");
    private static Object initialDevice, previousLevel, observedLevel;
    private static long observedAt, requestedRevision, verifiedSlicesAtStart;
    private static java.util.concurrent.CompletableFuture<Void> resourceReload;
    private static long reloadRequestedRevision;
    private static boolean resourcesVerified;
    private static final boolean RESOURCE_RELOAD =
            Boolean.getBoolean("veil.terrainResourceReloadProbe");
    private static int phase;
    private static double x, y, z;
    private static float yaw, pitch;
    private static TerrainBridgeCounters.Snapshot baseline;
    private static boolean pending, captured;
    private static volatile RuntimeException failure;
    private static final boolean DIMENSIONS = Boolean.getBoolean("veil.graphicsContractsProbe");

    private static net.minecraft.resources.ResourceKey<Level> dimension() {
        return DIMENSIONS && phase == 2 ? Level.END : phase == 1 ? Level.NETHER : Level.OVERWORLD;
    }

    private TerrainWorldLifecycleProbe() {}

    public static boolean enabled() {
        return ENABLED;
    }

    public static boolean tick(Minecraft client, long now) {
        if (!ENABLED) return false;
        if (dev.veil.revive.client.PbrReloadGpuProbe.started())
            return dev.veil.revive.client.PbrReloadGpuProbe.tick(client, now);
        if (failure != null) throw failure;
        if (client.level == null || client.player == null || client.gui.screen() != null)
            return false;
        var dimension = dimension();
        if (!client.level.dimension().equals(dimension)) return false;
        if (observedLevel == null) {
            if (phase == 0) {
                initialDevice = MinecraftVulkanContext.currentDeviceOrNull();
                if (initialDevice == null)
                    throw new IllegalStateException("World probe requires Vulkan");
                x = client.player.getX();
                y = client.player.getY();
                z = client.player.getZ();
                yaw = client.player.getYRot();
                pitch = client.player.getXRot();
            } else if (client.level == previousLevel
                    || VeilHostRevisions.global() <= requestedRevision) {
                throw new IllegalStateException(
                        "World replacement did not invalidate terrain revisions");
            }
            observedLevel = client.level;
            observedAt = now;
            baseline = VeilTerrainDrawBridge.counters();
            verifiedSlicesAtStart = VeilTerrainDrawBridge.verifiedSlices();
            client.player.input = new net.minecraft.client.player.ClientInput();
        }
        if (observedLevel != client.level)
            throw new IllegalStateException("Unexpected world replaced the active probe phase");
        if (MinecraftVulkanContext.currentDeviceOrNull() != initialDevice)
            throw new IllegalStateException("World transition replaced Minecraft's Vulkan device");
        if (resourceReload != null && !resourcesVerified) {
            if (!resourceReload.isDone()) return false;
            resourceReload.join();
            if (VeilHostRevisions.global() <= reloadRequestedRevision)
                throw new IllegalStateException(
                        "Resource reload did not invalidate terrain revisions");
            resourcesVerified = true;
            observedAt = now;
            baseline = VeilTerrainDrawBridge.counters();
            verifiedSlicesAtStart = VeilTerrainDrawBridge.verifiedSlices();
            ReviveMod.LOGGER.info(
                    "Veil terrain resource reload: complete requested_revision={} current_revision={} same_world=true same_device=true verified_slices={}",
                    reloadRequestedRevision,
                    VeilHostRevisions.global(),
                    verifiedSlicesAtStart);
            return false;
        }
        client.player.setDeltaMovement(net.minecraft.world.phys.Vec3.ZERO);
        long warmup = phase == 0 ? 15_000_000_000L : 10_000_000_000L;
        if (now - observedAt < warmup || pending) return false;
        if (!VeilWorldHistoryGpuProbe.verified(client.level)) return false;
        var delta = VeilTerrainDrawBridge.counters().minus(baseline);
        if (!VeilTerrainDrawBridge.pathActive()
                || delta.framesPrepared() < 20
                || delta.cacheHits() == 0) return false;
        if (RESOURCE_RELOAD && phase == 0 && resourceReload == null) {
            reloadRequestedRevision = VeilHostRevisions.global();
            ReviveMod.LOGGER.info(
                    "Veil terrain resource reload: requested revision={} verified_slices={}",
                    reloadRequestedRevision,
                    VeilTerrainDrawBridge.verifiedSlices());
            resourceReload = client.reloadResourcePacks();
            return false;
        }
        if (!captured) {
            pending = true;
            int capturedPhase = phase;
            var directory = VeilPlatform.get().getGameDir().resolve("logs/modular-world-lifecycle");
            net.minecraft.client.Screenshot.takeScreenshot(
                    client.gameRenderer.mainRenderTarget(),
                    image -> {
                        try {
                            Files.createDirectories(directory);
                            image.writeToFile(directory.resolve("phase-" + capturedPhase + ".png"));
                            captured = true;
                        } catch (Exception problem) {
                            failure =
                                    new IllegalStateException(
                                            "World transition screenshot failed", problem);
                        } finally {
                            image.close();
                            pending = false;
                        }
                    });
            return false;
        }
        ReviveMod.LOGGER.info(
                "Veil terrain world lifecycle phase: {} dimension={} frames={} hits={} misses={} fallbacks={} global_revision={} same_device=true replaced_world={} verified_slices={} phase_verified_slices={}",
                phase,
                dimension.identifier(),
                delta.framesPrepared(),
                delta.cacheHits(),
                delta.cacheMisses(),
                delta.fallbacks(),
                VeilHostRevisions.global(),
                phase != 0,
                VeilTerrainDrawBridge.verifiedSlices(),
                VeilTerrainDrawBridge.verifiedSlices() - verifiedSlicesAtStart);
        if (phase == (DIMENSIONS ? 3 : 2)) {
            ReviveMod.LOGGER.info(
                    "Veil terrain world lifecycle: PASS (dimension sequence complete; new client worlds, global invalidation, real terrain cache, same Minecraft Vulkan device)");
            if (dev.veil.revive.client.PbrReloadGpuProbe.enabled())
                return dev.veil.revive.client.PbrReloadGpuProbe.start(client, now);
            ReviveMod.LOGGER.info("Veil benchmark world: PASS (dedicated world lifecycle fixture)");
            return true;
        }
        previousLevel = observedLevel;
        observedLevel = null;
        requestedRevision = VeilHostRevisions.global();
        phase++;
        captured = false;
        requestTransition(client);
        return false;
    }

    private static void requestTransition(Minecraft client) {
        var server = client.getSingleplayerServer();
        if (server == null)
            throw new IllegalStateException(
                    "World lifecycle probe requires private integrated server");
        var playerId = client.player.getUUID();
        var dimension = dimension();
        server.execute(
                () -> {
                    try {
                        var player = server.getPlayerList().getPlayer(playerId);
                        var level = server.getLevel(dimension);
                        if (player == null || level == null)
                            throw new IllegalStateException("World transition target disappeared");
                        player.setGameMode(net.minecraft.world.level.GameType.SPECTATOR);
                        if (!player.teleportTo(level, x, y, z, Set.of(), yaw, pitch, true))
                            throw new IllegalStateException("World transition teleport rejected");
                    } catch (RuntimeException problem) {
                        failure = problem;
                    }
                });
    }
}
