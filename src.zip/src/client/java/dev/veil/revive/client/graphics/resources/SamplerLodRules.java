package dev.veil.revive.client.graphics.resources;

/** Portable sampler LOD contract, independent of any shader language or Vulkan binding. */
public final class SamplerLodRules {
    public static final float DEFAULT_MAX_LOD = 1000.0f;

    private SamplerLodRules() {}

    public static void validate(float minLod, float maxLod, float lodBias) {
        if (!Float.isFinite(minLod)
                || !Float.isFinite(maxLod)
                || !Float.isFinite(lodBias)
                || maxLod < minLod) {
            throw new IllegalArgumentException(
                    "Sampler minLod/maxLod/lodBias must be finite; " + "minLod <= maxLod");
        }
    }

    /** Native images have a known mip chain; do not silently clamp away the requested minimum. */
    public static float ownedMaxLod(float minLod, float maxLod, int mipLevels) {
        validate(minLod, maxLod, 0.0f);
        if (mipLevels < 1) throw new IllegalArgumentException("Invalid image mipLevels");
        float lastMip = mipLevels - 1;
        if (minLod > lastMip) {
            throw new IllegalArgumentException(
                    "Sampler minLod " + minLod + " exceeds the last allocated mip " + lastMip);
        }
        return Math.min(maxLod, lastMip);
    }

    /** A device's maxSamplerLodBias is a two-sided absolute limit. */
    public static void validateDeviceBias(float lodBias, float maxSamplerLodBias) {
        if (!Float.isFinite(lodBias)
                || !Float.isFinite(maxSamplerLodBias)
                || maxSamplerLodBias < 0.0f
                || Math.abs((double) lodBias) > maxSamplerLodBias) {
            throw new IllegalArgumentException(
                    "Sampler lodBias exceeds enabled device maxSamplerLodBias: "
                            + lodBias
                            + " (limit "
                            + maxSamplerLodBias
                            + ")");
        }
    }
}
