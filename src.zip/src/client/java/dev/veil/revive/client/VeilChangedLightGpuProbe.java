package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuFence;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.core.terrain.AttributeUploadPlan;
import dev.veil.revive.core.terrain.RegularTerrainVertices;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

import java.util.concurrent.atomic.AtomicBoolean;

final class VeilChangedLightGpuProbe {
    private static final boolean ENABLED =
            Boolean.getBoolean("veil.verifyChangedLightUpload")
                    && Boolean.getBoolean("veil.benchmarkWorld")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment();
    private static final AtomicBoolean REQUESTED = new AtomicBoolean();
    private static final boolean CYCLE = Boolean.getBoolean("veil.verifyChangedLightCycle");
    private static volatile BlockPos source;
    private static volatile boolean applied;
    private static volatile long appliedAt;
    private static volatile long removedAt;
    private static volatile boolean restored;
    private static volatile RuntimeException failure;
    private static Runnable pending;
    private static GpuBuffer readback;
    private static GpuFence fence;
    private static byte[] expected;
    private static int uploadedBytes;
    private static int changedLightVertices;
    private static boolean complete;
    private static boolean observedAfter;
    private static boolean sampledAfter;
    private static boolean removalQueued;
    private static boolean restorationQueued;

    static void prepare(ServerLevel level, BlockPos position) {
        if (!ENABLED) return;
        source = position.immutable();
        level.setBlock(source, Blocks.AIR.defaultBlockState(), 3);
    }

    static void request(net.minecraft.client.Minecraft client, int notifications) {
        if (!ENABLED
                || notifications < 2
                || source == null
                || !REQUESTED.compareAndSet(false, true)) return;
        var server = client.getSingleplayerServer();
        dev.veil.revive.ReviveMod.LOGGER.info(
                "Veil changed light client baseline: sample={} block_light={} source_air={}",
                source.offset(5, 0, 0),
                client.level.getBrightness(
                        net.minecraft.world.level.LightLayer.BLOCK, source.offset(5, 0, 0)),
                client.level.getBlockState(source).isAir());
        server.execute(
                () -> {
                    try {
                        var level = server.getLevel(Level.OVERWORLD);
                        if (level == null || !level.getBlockState(source).isAir())
                            throw new IllegalStateException(
                                    "Changed-light fixture source not empty");
                        dev.veil.revive.ReviveMod.LOGGER.info(
                                "Veil changed light server baseline: sample={} block_light={}",
                                source.offset(5, 0, 0),
                                level.getBrightness(
                                        net.minecraft.world.level.LightLayer.BLOCK,
                                        source.offset(5, 0, 0)));
                        level.setBlock(source, Blocks.GLOWSTONE.defaultBlockState(), 3);
                        appliedAt = System.nanoTime();
                        applied = true;
                        dev.veil.revive.ReviveMod.LOGGER.info(
                                "Veil changed light fixture: glowstone applied at {}", source);
                    } catch (RuntimeException problem) {
                        failure = problem;
                    }
                });
    }

    static <T> void record(
            VeilManagedGpuArena<T> arena,
            T key,
            long node,
            RegularTerrainVertices.Result before,
            RegularTerrainVertices.Result data,
            AttributeUploadPlan plan) {
        if (!ENABLED
                || complete
                || pending != null
                || readback != null
                || !applied
                || (CYCLE && !restored)
                || node != VeilBenchmarkWorld.provenanceSection) return;
        if (data.vertices().length > 4 << 20)
            throw new IllegalStateException("Changed-light readback budget");
        int changed = 0;
        int oldMin = Integer.MAX_VALUE, oldMax = 0, newMin = Integer.MAX_VALUE, newMax = 0;
        for (int vertex = 0; vertex < data.vertexCount(); vertex++) {
            int at = vertex * data.stride() + data.stride() - 4;
            int oldLight =
                    Byte.toUnsignedInt(before.vertices()[at])
                            | Byte.toUnsignedInt(before.vertices()[at + 1]) << 8;
            int newLight =
                    Byte.toUnsignedInt(data.vertices()[at])
                            | Byte.toUnsignedInt(data.vertices()[at + 1]) << 8;
            if (newLight > oldLight) changed++;
            oldMin = Math.min(oldMin, oldLight);
            oldMax = Math.max(oldMax, oldLight);
            newMin = Math.min(newMin, newLight);
            newMax = Math.max(newMax, newLight);
        }
        if (!observedAfter) {
            observedAfter = true;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil changed light compact checkpoint: old_min={} old_max={} new_min={} new_max={} changed={} payload_bytes={}",
                    oldMin,
                    oldMax,
                    newMin,
                    newMax,
                    changed,
                    plan.payloadBytes());
        }
        if (changed == 0) return;
        changedLightVertices = changed;
        byte[] copy = data.vertices().clone();
        int bytes = plan.payloadBytes();
        pending =
                () -> {
                    var allocation = arena.getAllocation(key);
                    if (allocation == null)
                        throw new IllegalStateException("Changed-light allocation unpublished");
                    var device = RenderSystem.getDevice();
                    expected = copy;
                    uploadedBytes = bytes;
                    readback =
                            device.createBuffer(
                                    () -> "Veil changed-light actual terrain readback",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    copy.length);
                    var encoder = device.createCommandEncoder();
                    encoder.copyToBuffer(
                            arena.getGpuBuffer(allocation).slice(allocation.offset(), copy.length),
                            readback.slice());
                    fence = encoder.createFence();
                };
    }

    static void uploaded() {
        if (pending == null) return;
        var work = pending;
        pending = null;
        work.run();
    }

    static void tick() {
        if (!ENABLED) return;
        if (failure != null) throw failure;
        if (CYCLE && applied && !removalQueued && System.nanoTime() - appliedAt > 5_000_000_000L) {
            removalQueued = true;
            var server = net.minecraft.client.Minecraft.getInstance().getSingleplayerServer();
            server.execute(
                    () -> {
                        try {
                            server.getLevel(Level.OVERWORLD)
                                    .setBlock(source, Blocks.AIR.defaultBlockState(), 3);
                            removedAt = System.nanoTime();
                            dev.veil.revive.ReviveMod.LOGGER.info(
                                    "Veil changed light cycle: source removed");
                        } catch (RuntimeException problem) {
                            failure = problem;
                        }
                    });
        }
        if (CYCLE
                && removedAt != 0
                && !restorationQueued
                && System.nanoTime() - removedAt > 5_000_000_000L) {
            var client = net.minecraft.client.Minecraft.getInstance();
            if (client.level.getBlockState(source).isAir()
                    && client.level.getBrightness(
                                    net.minecraft.world.level.LightLayer.BLOCK,
                                    source.offset(5, 0, 0))
                            == 0) {
                restorationQueued = true;
                dev.veil.revive.ReviveMod.LOGGER.info(
                        "Veil changed light cycle: client confirmed dark block_light=0 source_air=true");
                var server = client.getSingleplayerServer();
                server.execute(
                        () -> {
                            try {
                                server.getLevel(Level.OVERWORLD)
                                        .setBlock(source, Blocks.GLOWSTONE.defaultBlockState(), 3);
                                restored = true;
                                dev.veil.revive.ReviveMod.LOGGER.info(
                                        "Veil changed light cycle: source restored");
                            } catch (RuntimeException problem) {
                                failure = problem;
                            }
                        });
            }
        }
        if (applied && !sampledAfter && System.nanoTime() - appliedAt > 5_000_000_000L) {
            sampledAfter = true;
            var client = net.minecraft.client.Minecraft.getInstance();
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil changed light client after: sample={} block_light={} source_glowstone={}",
                    source.offset(5, 0, 0),
                    client.level.getBrightness(
                            net.minecraft.world.level.LightLayer.BLOCK, source.offset(5, 0, 0)),
                    client.level.getBlockState(source).is(Blocks.GLOWSTONE));
        }
        if (fence == null || !fence.awaitCompletion(0)) return;
        try {
            try (var mapped = readback.map(true, false)) {
                for (int at = 0; at < expected.length; at++)
                    if (mapped.data().get(at) != expected[at])
                        throw new IllegalStateException(
                                "Actual changed-light compact terrain GPU mismatch at " + at);
            }
            complete = true;
            dev.veil.revive.ReviveMod.LOGGER.info(
                    "Veil changed light GPU: PASS (verified_bytes={} uploaded_attribute_bytes={} brighter_vertices={} geometry_unchanged=true)",
                    expected.length,
                    uploadedBytes,
                    changedLightVertices);
        } finally {
            fence.close();
            readback.close();
            fence = null;
            readback = null;
            expected = null;
        }
    }

    static void requireComplete() {
        if (ENABLED && !complete)
            throw new IllegalStateException(
                    "Actual changed-light sparse publication not exercised: applied="
                            + applied
                            + " removed="
                            + removalQueued
                            + " restored="
                            + restored);
    }
}
