package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "net.minecraft.client.renderer.SectionOcclusionGraph")
public abstract class SectionOcclusionGraphTimingMixin {
    @Inject(method = "consumeFrustumUpdate", at = @At("RETURN"), require = 0)
    private void veil$visibilityRevision(CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ()) dev.veil.revive.client.VeilHostRevisions.visibilityChanged();
    }

    @Inject(method = "update", at = @At("HEAD"), require = 0)
    private void revive$occlusionStart(CallbackInfo ci) {
        ReviveRuntime.onOcclusionUpdateStart();
        dev.veil.revive.client.VeilFullFrameTelemetry.beginCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.OCCLUSION_GRAPH);
    }

    @Inject(method = "update", at = @At("RETURN"), require = 0)
    private void revive$occlusionEnd(CallbackInfo ci) {
        ReviveRuntime.onOcclusionUpdateEnd();
        dev.veil.revive.client.VeilFullFrameTelemetry.endCpu(
                dev.veil.revive.client.VeilFullFrameTelemetry.CpuZone.OCCLUSION_GRAPH);
    }
}
