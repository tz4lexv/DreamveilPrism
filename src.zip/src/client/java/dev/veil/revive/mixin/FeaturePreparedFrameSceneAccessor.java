package dev.veil.revive.mixin;

import net.minecraft.client.renderer.feature.FeatureFrameContext;
import net.minecraft.client.renderer.feature.FeatureRenderDispatcher;
import net.minecraft.client.renderer.feature.phase.FeatureRenderPhase;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(FeatureRenderDispatcher.PreparedFrame.class)
public interface FeaturePreparedFrameSceneAccessor {
    @Accessor("context")
    FeatureFrameContext veil$context();

    @Invoker("executePhase")
    void veil$executePhase(FeatureRenderPhase<?> phase, FeatureFrameContext context);
}
