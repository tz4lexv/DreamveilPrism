package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilAsyncTerrainSelection;

import net.minecraft.client.renderer.SectionOcclusionGraph;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.state.level.ChunkLoadingRenderState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(SectionOcclusionGraph.class)
public abstract class SectionOcclusionGraphAsyncMixin {
    @Inject(method = "update", at = @At("RETURN"))
    private void veil$prepareAsync(
            CameraRenderState camera,
            int fov,
            ChunkLoadingRenderState loading,
            CallbackInfo callback) {
        VeilAsyncTerrainSelection.prepare(
                (SectionOcclusionGraph) (Object) this, camera.cullFrustum);
    }

    @Inject(method = "addSectionsInFrustum", at = @At("HEAD"), cancellable = true)
    private void veil$selectAsync(
            Frustum frustum,
            List<SectionRenderDispatcher.RenderSection> visible,
            List<SectionRenderDispatcher.RenderSection> nearby,
            CallbackInfo callback) {
        if (VeilAsyncTerrainSelection.trySelect(
                (SectionOcclusionGraph) (Object) this, frustum, visible, nearby)) callback.cancel();
    }
}
