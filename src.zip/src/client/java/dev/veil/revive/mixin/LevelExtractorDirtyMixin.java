package dev.veil.revive.mixin;

import dev.veil.revive.client.ReviveRuntime;
import dev.veil.revive.client.VeilMinecraftTerrainBridge;

import net.minecraft.client.renderer.extract.LevelExtractor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelExtractor.class)
public abstract class LevelExtractorDirtyMixin {
    @Inject(method = "setSectionDirty(IIIZ)V", at = @At("HEAD"), require = 1)
    private void revive$sectionDirty(
            int sectionX, int sectionY, int sectionZ, boolean playerChanged, CallbackInfo ci) {
        dev.veil.revive.client.VeilAsyncEntityOcclusion.invalidate();
        if (ReviveRuntime.enabled()) {
            VeilMinecraftTerrainBridge.onSectionDirty(sectionX, sectionY, sectionZ);
        }
    }

    @Inject(method = "allChanged()V", at = @At("HEAD"), require = 1)
    private void revive$allChanged(CallbackInfo ci) {
        dev.veil.revive.client.VeilAsyncEntityOcclusion.invalidate();
        dev.veil.revive.client.VeilOriginalQuadCapture.invalidate();
        if (ReviveRuntime.enabled()) {
            VeilMinecraftTerrainBridge.invalidateAll();
        }
    }

    @Inject(method = "setLevel", at = @At("HEAD"), require = 1)
    private void veil$originalWorldChanged(CallbackInfo ci) {
        dev.veil.revive.client.VeilOriginalQuadCapture.worldChanged();
    }

    @Inject(method = "onResourceManagerReload", at = @At("HEAD"), require = 1)
    private void veil$originalResourcesChanged(CallbackInfo ci) {
        dev.veil.revive.client.VeilOriginalQuadCapture.resourcesChanged();
    }
}
