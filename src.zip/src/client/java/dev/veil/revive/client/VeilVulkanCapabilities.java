package dev.veil.revive.client;

import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.client.graphics.minecraft.EnabledDeviceFeatures;

public final class VeilVulkanCapabilities {
    public static boolean shaderDrawParameters() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("shaderDrawParameters");
    }

    public static boolean pipelineStatistics() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("pipelineStatisticsQuery");
    }

    public static boolean shaderFloat16() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("shaderFloat16");
    }

    public static boolean shaderInt8() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("shaderInt8");
    }

    public static boolean shaderInt16() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("shaderInt16");
    }

    public static boolean shaderInt64() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(EnabledDeviceFeatures.SHADER_INT64);
    }

    public static boolean shaderBufferInt64Atomics() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(
                EnabledDeviceFeatures.BUFFER_INT64_ATOMICS);
    }

    public static boolean shaderSharedInt64Atomics() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(
                EnabledDeviceFeatures.SHARED_INT64_ATOMICS);
    }

    public static boolean storageBuffer16() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("storageBuffer16BitAccess");
    }

    public static boolean storageBuffer8() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("storageBuffer8BitAccess");
    }

    public static boolean subgroupExtendedTypes() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("shaderSubgroupExtendedTypes");
    }

    private static volatile boolean synchronization2;
    private static volatile boolean nvLowLatency2;
    private static volatile boolean amdAntiLag;
    private static volatile boolean presentWait2;
    private static volatile boolean presentId2;
    private static volatile boolean fifoLatestReady;

    private VeilVulkanCapabilities() {}

    public static boolean drawIndirectCount() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("drawIndirectCount");
    }

    public static boolean independentBlend() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("independentBlend");
    }

    public static boolean shaderStorageImageExtendedFormats() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("shaderStorageImageExtendedFormats");
    }

    public static boolean descriptorIndexing() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("descriptorIndexing");
    }

    public static boolean shaderSampledImageArrayDynamicIndexing() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(
                "shaderSampledImageArrayDynamicIndexing");
    }

    public static boolean shaderStorageBufferArrayDynamicIndexing() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(
                "shaderStorageBufferArrayDynamicIndexing");
    }

    public static boolean shaderStorageImageArrayDynamicIndexing() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(
                "shaderStorageImageArrayDynamicIndexing");
    }

    public static boolean runtimeDescriptorArray() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice("runtimeDescriptorArray");
    }

    public static boolean shaderSampledImageArrayNonUniformIndexing() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(
                "shaderSampledImageArrayNonUniformIndexing");
    }

    public static boolean shaderStorageBufferArrayNonUniformIndexing() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(
                "shaderStorageBufferArrayNonUniformIndexing");
    }

    public static boolean shaderStorageImageArrayNonUniformIndexing() {
        return EnabledDeviceFeatures.enabledOnCurrentDevice(
                "shaderStorageImageArrayNonUniformIndexing");
    }

    public static void refreshEnabledExtensions() {
        try {
            var info = RenderSystem.getDevice().getDeviceInfo();
            if (!info.backendName().equalsIgnoreCase("Vulkan")) return;
            var extensions = info.underlyingExtensions();
            synchronization2 = extensions.contains("VK_KHR_synchronization2");
            nvLowLatency2 = extensions.contains("VK_NV_low_latency2");
            amdAntiLag = extensions.contains("VK_AMD_anti_lag");
            presentWait2 = extensions.contains("VK_KHR_present_wait2");
            presentId2 = extensions.contains("VK_KHR_present_id2");
            fifoLatestReady = extensions.contains("VK_KHR_present_mode_fifo_latest_ready");
        } catch (RuntimeException ignored) {
        }
    }

    public static boolean synchronization2() {
        return synchronization2;
    }

    public static boolean nvLowLatency2() {
        return nvLowLatency2;
    }

    public static boolean amdAntiLag() {
        return amdAntiLag;
    }

    public static boolean presentWait2() {
        return presentWait2;
    }

    public static boolean presentId2() {
        return presentId2;
    }

    public static boolean fifoLatestReady() {
        return fifoLatestReady;
    }

    public static String telemetry() {
        return "vk_shader_draw_parameters="
                + shaderDrawParameters()
                + "\n"
                + "vk_draw_indirect_count="
                + drawIndirectCount()
                + "\n"
                + "vk_independent_blend="
                + independentBlend()
                + "\n"
                + "vk_shader_storage_image_extended_formats="
                + shaderStorageImageExtendedFormats()
                + "\n"
                + "vk_descriptor_indexing="
                + descriptorIndexing()
                + "\n"
                + "vk_runtime_descriptor_array="
                + runtimeDescriptorArray()
                + "\n"
                + "vk_sampled_image_array_dynamic_indexing="
                + shaderSampledImageArrayDynamicIndexing()
                + "\n"
                + "vk_storage_buffer_array_dynamic_indexing="
                + shaderStorageBufferArrayDynamicIndexing()
                + "\n"
                + "vk_storage_image_array_dynamic_indexing="
                + shaderStorageImageArrayDynamicIndexing()
                + "\n"
                + "vk_sampled_image_array_nonuniform_indexing="
                + shaderSampledImageArrayNonUniformIndexing()
                + "\n"
                + "vk_storage_buffer_array_nonuniform_indexing="
                + shaderStorageBufferArrayNonUniformIndexing()
                + "\n"
                + "vk_storage_image_array_nonuniform_indexing="
                + shaderStorageImageArrayNonUniformIndexing()
                + "\n"
                + "vk_nv_low_latency2_enabled="
                + nvLowLatency2
                + "\n"
                + "vk_amd_anti_lag_enabled="
                + amdAntiLag
                + "\n"
                + "vk_present_wait2_enabled="
                + presentWait2
                + "\n"
                + "vk_present_id2_enabled="
                + presentId2
                + "\n"
                + "vk_fifo_latest_ready_enabled="
                + fifoLatestReady
                + "\n";
    }
}
