package dev.veil.revive.client;

public interface VeilRayCompileState {
    boolean veil$rayCompilePending();
}
