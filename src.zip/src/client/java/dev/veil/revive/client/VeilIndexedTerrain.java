package dev.veil.revive.client;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.core.terrain.IndexedTerrainVertices;
import dev.veil.revive.core.terrain.TerrainVertexCache;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionCompiler;

import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicLong;

public final class VeilIndexedTerrain {
    private static final AtomicLong ACCEPTED = new AtomicLong(), SAVED = new AtomicLong();
    private static final AtomicLong VERIFIED = new AtomicLong();
    private static final AtomicLong FAILURES = new AtomicLong();
    private static final AtomicLong CANDIDATES = new AtomicLong(), BUILD_NS = new AtomicLong();
    private static final AtomicLong CACHE_REORDERED = new AtomicLong();

    private VeilIndexedTerrain() {}

    public static void optimize(SectionCompiler.Results results, VeilMeshMetadata metadata) {
        boolean captureAttributes = metadata.hasOriginalAttributeSource();
        if (VeilProgressiveMeshing.pairsEnabled()) return;
        if (!Boolean.getBoolean("veil.indexedTerrain")
                || !ReviveRuntime.optimizationsEnabled()
                || !VeilSectionChanges.notificationsSupported()
                || !VeilShaderPackBridge.customTerrainShadersAllowed()) return;
        VeilSectionCompileExtras extras = (VeilSectionCompileExtras) (Object) results;
        for (var entry : results.renderedLayers.entrySet()) {
            if (entry.getKey() == ChunkSectionLayer.TRANSLUCENT) continue;
            boolean hasRanges = false;
            for (VeilMaterialRange range : extras.veil$materialRanges())
                if (range.layer() == entry.getKey()) hasRanges = true;
            if (hasRanges) continue;
            MeshData original = entry.getValue();
            MeshData replacement;
            long start = System.nanoTime();
            CANDIDATES.incrementAndGet();
            try {
                replacement = optimize(original, captureAttributes);
            } catch (RuntimeException failure) {
                FAILURES.incrementAndGet();
                ReviveMod.LOGGER.warn(
                        "Veil indexed terrain kept original mesh after optimization failure",
                        failure);
                continue;
            } finally {
                BUILD_NS.addAndGet(System.nanoTime() - start);
            }
            if (replacement == original) continue;
            entry.setValue(replacement);
            original.close();
        }
    }

    public static dev.veil.revive.core.terrain.TerrainAttributeMap attributeMap(MeshData mesh) {
        return mesh instanceof OwnedMesh owned ? owned.attributes : null;
    }

    static MeshData optimize(MeshData original) {
        return optimize(original, false);
    }

    static MeshData optimize(MeshData original, boolean captureAttributes) {
        var state = original.drawState();
        if (!state.format().equals(DefaultVertexFormat.BLOCK)
                || state.primitiveTopology() != PrimitiveTopology.QUADS
                || original.indexBuffer() != null
                || state.vertexCount() == 0
                || state.vertexCount() > 1_048_576
                || state.indexCount() != state.vertexCount() / 4 * 6) return original;
        var built =
                IndexedTerrainVertices.buildIfSmaller(original.vertexBuffer(), state.vertexCount());
        if (built == null) return original;
        int[] sourceQuads = null;
        if (Boolean.getBoolean("veil.indexedTerrainCache")) {
            var ordered = TerrainVertexCache.optimize(built);
            built = ordered.mesh();
            sourceQuads = ordered.sourceQuads();
            if (sourceQuads != null && CACHE_REORDERED.incrementAndGet() == 1)
                ReviveMod.LOGGER.info(
                        "Veil indexed terrain cache ACTIVE: quad adjacency order and vertex fetch remap");
        }
        var attributes =
                captureAttributes
                        ? dev.veil.revive.core.terrain.TerrainAttributeMap.indexed(
                                original.vertexBuffer(),
                                state.vertexCount(),
                                ByteBuffer.wrap(built.vertices()),
                                built.vertexCount(),
                                built.indices(),
                                sourceQuads)
                        : null;
        ByteBufferBuilder vertices = ByteBufferBuilder.exactlySized(built.vertices().length);
        ByteBufferBuilder indices = null;
        try {
            MemoryUtil.memByteBuffer(
                            vertices.reserve(built.vertices().length), built.vertices().length)
                    .put(built.vertices());
            int indexSize = built.indices().length * built.indexBytes();
            indices = ByteBufferBuilder.exactlySized(indexSize);
            ByteBuffer out =
                    MemoryUtil.memByteBuffer(indices.reserve(indexSize), indexSize)
                            .order(ByteOrder.nativeOrder());
            for (int index : built.indices()) {
                if (built.indexBytes() == 2) out.putShort((short) index);
                else out.putInt(index);
            }
            var result =
                    new OwnedMesh(
                            vertices,
                            indices,
                            attributes,
                            new MeshData.DrawState(
                                    state.format(),
                                    built.vertexCount(),
                                    built.indices().length,
                                    state.primitiveTopology(),
                                    built.indexBytes() == 2 ? IndexType.SHORT : IndexType.INT));
            if (Boolean.getBoolean("veil.verifyIndexedTerrain")
                    && dev.veil.revive.platform.VeilPlatform.get().isDevelopmentEnvironment()
                    && VERIFIED.get() < 100_000) {
                try {
                    verify(original, result, sourceQuads);
                } catch (RuntimeException | Error failure) {
                    result.close();
                    throw failure;
                }
                long before = VERIFIED.getAndAdd(built.indices().length);
                if (before < 100_000 && before + built.indices().length >= 100_000)
                    ReviveMod.LOGGER.info(
                            "Veil indexed terrain parity PASS: 100000 triangle corners match original bytes and winding");
            }
            SAVED.addAndGet(built.bytesSaved());
            if (ACCEPTED.incrementAndGet() == 1)
                ReviveMod.LOGGER.info(
                        "Veil indexed terrain ACTIVE: exact attribute deduplication and first-use vertex fetch order");
            return result;
        } catch (RuntimeException | Error failure) {
            vertices.close();
            if (indices != null) indices.close();
            throw failure;
        }
    }

    static long accepted() {
        return ACCEPTED.get();
    }

    static long savedBytes() {
        return SAVED.get();
    }

    static void requireComplete() {
        if (VeilProgressiveMeshing.pairsEnabled()) {
            if (VeilParametricTerrainArena.requested())
                VeilParametricTerrainArena.requireComplete();
            else VeilPairedTerrainArena.requireActiveRoute();
            if (Boolean.getBoolean("veil.verifyIndexedTerrain"))
                VeilProgressiveMeshing.requirePairedParity();
            ReviveMod.LOGGER.info("Veil indexed terrain route: deferred paired terrain");
            return;
        }
        if (Boolean.getBoolean("veil.indexedTerrain") && ACCEPTED.get() == 0)
            throw new IllegalStateException("Indexed terrain did not optimize any native mesh");
        if (Boolean.getBoolean("veil.verifyIndexedTerrain") && VERIFIED.get() < 100_000)
            throw new IllegalStateException("Indexed terrain parity probe incomplete");
        if (Boolean.getBoolean("veil.verifyIndexedTerrain") && FAILURES.get() != 0)
            throw new IllegalStateException(
                    "Indexed terrain parity run encountered optimization failures");
        if (Boolean.getBoolean("veil.indexedTerrain"))
            ReviveMod.LOGGER.info(
                    "Veil indexed terrain verification: meshes={} saved_bytes={} candidates={} build_cpu_ms={} cache_reordered={}",
                    ACCEPTED.get(),
                    SAVED.get(),
                    CANDIDATES.get(),
                    BUILD_NS.get() / 1_000_000.0,
                    CACHE_REORDERED.get());
    }

    private static void verify(MeshData original, MeshData optimized, int[] sourceQuads) {
        ByteBuffer source = original.vertexBuffer().slice();
        ByteBuffer vertices = optimized.vertexBuffer().slice();
        ByteBuffer indices = optimized.indexBuffer().slice().order(ByteOrder.nativeOrder());
        int[] corners = {0, 1, 2, 2, 3, 0};
        for (int i = 0; i < optimized.drawState().indexCount(); i++) {
            int index =
                    optimized.drawState().indexType() == IndexType.SHORT
                            ? Short.toUnsignedInt(indices.getShort(i * 2))
                            : indices.getInt(i * 4);
            int quad = sourceQuads == null ? i / 6 : sourceQuads[i / 6];
            int sourceVertex = quad * 4 + corners[i % 6];
            for (int b = 0; b < IndexedTerrainVertices.STRIDE; b++)
                if (source.get(sourceVertex * IndexedTerrainVertices.STRIDE + b)
                        != vertices.get(index * IndexedTerrainVertices.STRIDE + b))
                    throw new IllegalStateException(
                            "Indexed terrain changed native triangle attributes/order");
        }
    }

    private static final class OwnedMesh extends MeshData {
        private final ByteBufferBuilder vertices, indices;
        private final ByteBufferBuilder.Result indexResult;
        private boolean closed;
        private final dev.veil.revive.core.terrain.TerrainAttributeMap attributes;

        OwnedMesh(
                ByteBufferBuilder vertices,
                ByteBufferBuilder indices,
                dev.veil.revive.core.terrain.TerrainAttributeMap attributes,
                DrawState state) {
            super(vertices.build(), state);
            this.vertices = vertices;
            this.indices = indices;
            this.attributes = attributes;
            indexResult = indices.build();
        }

        @Override
        public ByteBuffer indexBuffer() {
            return indexResult.byteBuffer();
        }

        @Override
        public void close() {
            if (closed) return;
            closed = true;
            try {
                super.close();
            } finally {
                try {
                    indexResult.close();
                } finally {
                    vertices.close();
                    indices.close();
                }
            }
        }
    }
}
