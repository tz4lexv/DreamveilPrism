package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilFluidGeometry;
import dev.veil.revive.client.VeilMaterialRange;
import dev.veil.revive.client.VeilSectionCompileExtras;

import net.minecraft.client.renderer.chunk.SectionCompiler;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(SectionCompiler.Results.class)
public abstract class SectionCompilerResultsMixin implements VeilSectionCompileExtras {
    @Unique private TextureAtlasSprite[] veil$animatedSprites = new TextureAtlasSprite[0];
    @Unique private VeilMaterialRange[] veil$materialRanges = new VeilMaterialRange[0];
    @Unique private VeilFluidGeometry[] veil$fluidGeometry = new VeilFluidGeometry[0];
    @Unique private boolean veil$lightOnlyUpdate;
    @Unique private int veil$reusedModels;

    @Override
    public int veil$reusedModels() {
        return veil$reusedModels;
    }

    @Override
    public void veil$setReusedModels(int models) {
        veil$reusedModels = models;
    }

    @Unique private dev.veil.revive.client.VeilOriginalQuadCapture.Snapshot veil$originalQuads;

    @Override
    public void veil$setOriginalQuads(
            dev.veil.revive.client.VeilOriginalQuadCapture.Snapshot snapshot) {
        if (veil$originalQuads != null) veil$originalQuads.close();
        veil$originalQuads = snapshot;
    }

    @Override
    public dev.veil.revive.client.VeilOriginalQuadCapture.Snapshot veil$originalQuads() {
        return veil$originalQuads;
    }

    @Override
    public dev.veil.revive.client.VeilOriginalQuadCapture.Snapshot veil$takeOriginalQuads() {
        var snapshot = veil$originalQuads;
        veil$originalQuads = null;
        return snapshot;
    }

    @org.spongepowered.asm.mixin.injection.Inject(
            method = "release",
            at = @org.spongepowered.asm.mixin.injection.At("HEAD"),
            require = 1)
    private void veil$releaseOriginalQuads(
            org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        veil$setOriginalQuads(null);
    }

    @Override
    public TextureAtlasSprite[] veil$animatedSprites() {
        return veil$animatedSprites;
    }

    @Override
    public void veil$setAnimatedSprites(TextureAtlasSprite[] sprites) {
        veil$animatedSprites = sprites == null ? new TextureAtlasSprite[0] : sprites;
    }

    @Override
    public VeilMaterialRange[] veil$materialRanges() {
        return veil$materialRanges;
    }

    @Override
    public void veil$setMaterialRanges(VeilMaterialRange[] ranges) {
        veil$materialRanges = ranges == null ? new VeilMaterialRange[0] : ranges;
    }

    @Override
    public VeilFluidGeometry[] veil$fluidGeometry() {
        return veil$fluidGeometry;
    }

    @Override
    public void veil$setFluidGeometry(VeilFluidGeometry[] geometry) {
        veil$fluidGeometry = geometry == null ? new VeilFluidGeometry[0] : geometry;
    }

    @Override
    public boolean veil$lightOnlyUpdate() {
        return veil$lightOnlyUpdate;
    }

    @Override
    public void veil$setLightOnlyUpdate(boolean lightOnly) {
        veil$lightOnlyUpdate = lightOnly;
    }
}
