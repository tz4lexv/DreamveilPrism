package dev.veil.revive.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.vertex.UberGpuBuffer;

import dev.veil.revive.client.VeilCanonicalGpuArena;
import dev.veil.revive.client.VeilCanonicalSparseUploads;

import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.nio.ByteBuffer;

@Mixin(SectionRenderDispatcher.RenderSection.class)
public abstract class RenderSectionCanonicalUploadMixin {
    @WrapOperation(
            method = "addSectionBuffersToUberBuffer",
            at =
                    @At(
                            value = "INVOKE",
                            target =
                                    "Lcom/mojang/blaze3d/vertex/UberGpuBuffer;addAllocation(Ljava/lang/Object;Lcom/mojang/blaze3d/vertex/UberGpuBuffer$UploadCallback;Ljava/nio/ByteBuffer;)Z"),
            require = 2)
    private boolean veil$sparse(
            UberGpuBuffer<?> arena,
            Object key,
            UberGpuBuffer.UploadCallback<?> callback,
            ByteBuffer input,
            Operation<Boolean> original,
            @Local(argsOnly = true) ChunkSectionLayer layer) {
        if (!VeilCanonicalSparseUploads.REQUESTED)
            return original.call(arena, key, callback, input);
        if (key instanceof SectionMesh mesh) {
            var section = (SectionRenderDispatcher.RenderSection) (Object) this;
            var result =
                    VeilCanonicalSparseUploads.stage(
                            arena, section.getSectionMesh(), mesh, layer, callback, input);
            if (result == VeilCanonicalGpuArena.Admission.ADDED) return true;
            if (result == VeilCanonicalGpuArena.Admission.STAGING) return false;
        }
        return original.call(arena, key, callback, input);
    }
}
