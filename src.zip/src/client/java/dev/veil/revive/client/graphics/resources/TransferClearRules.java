package dev.veil.revive.client.graphics.resources;

import dev.veil.api.VeilFormat;
import dev.veil.api.VeilTransfer;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Objects;

/** Host-independent rules for vkCmdClearColorImage's float32/int32/uint32 union. */
public final class TransferClearRules {
    private static final BigInteger UINT32_MAX = BigInteger.valueOf(0xffff_ffffL);

    private TransferClearRules() {}

    public static void validate(
            VeilFormat format, VeilTransfer.Aspect aspect, VeilTransfer.ClearValue clear) {
        Objects.requireNonNull(format, "format");
        Objects.requireNonNull(aspect, "aspect");
        Objects.requireNonNull(clear, "clear");
        if (aspect != VeilTransfer.Aspect.COLOR) {
            if (clear.colorType() != VeilTransfer.ClearColorType.FLOAT)
                throw new IllegalArgumentException(
                        "Depth/stencil clear cannot use integer color data");
            return;
        }
        VeilTransfer.ClearColorType expected =
                switch (format.numericType()) {
                    case SINT -> VeilTransfer.ClearColorType.SINT;
                    case UINT -> VeilTransfer.ClearColorType.UINT;
                    case DEPTH, STENCIL, DEPTH_STENCIL ->
                            throw new IllegalArgumentException(
                                    "Non-color format cannot have a color clear");
                    default -> VeilTransfer.ClearColorType.FLOAT;
                };
        if (clear.colorType() != expected) {
            throw new IllegalArgumentException(
                    "Image clear for "
                            + format
                            + " requires "
                            + expected
                            + " color components, got "
                            + clear.colorType());
        }
    }

    /** Parse a JSON integer without loss from floating-point conversion. */
    public static int channel(BigDecimal raw, VeilTransfer.ClearColorType type) {
        Objects.requireNonNull(raw, "raw");
        Objects.requireNonNull(type, "type");
        final BigInteger integer;
        try {
            integer = raw.toBigIntegerExact();
        } catch (ArithmeticException invalid) {
            throw new IllegalArgumentException(
                    "Integer image clear component is not an integer: " + raw, invalid);
        }
        if (type == VeilTransfer.ClearColorType.UINT) {
            if (integer.signum() < 0 || integer.compareTo(UINT32_MAX) > 0)
                throw new IllegalArgumentException(
                        "Unsigned image clear component exceeds uint32: " + raw);
            return integer.intValue();
        }
        if (type == VeilTransfer.ClearColorType.SINT) {
            try {
                return integer.intValueExact();
            } catch (ArithmeticException invalid) {
                throw new IllegalArgumentException(
                        "Signed image clear component exceeds int32: " + raw, invalid);
            }
        }
        throw new IllegalArgumentException("Floating-point color clears use decimal channels");
    }
}
