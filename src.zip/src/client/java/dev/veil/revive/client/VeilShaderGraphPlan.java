package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK13.*;

import java.util.List;
import java.util.Map;

public final class VeilShaderGraphPlan {
    public static final String SCENE_COLOR =
            VeilHostResourceRegistry.physical(VeilHostResourceRegistry.SCENE_COLOR);
    public static final String SCENE_DEPTH =
            VeilHostResourceRegistry.physical(VeilHostResourceRegistry.SCENE_DEPTH);
    public static final String SCENE_OPAQUE_COLOR =
            VeilHostResourceRegistry.physical(VeilHostResourceRegistry.SCENE_OPAQUE_COLOR);
    public static final String SCENE_OPAQUE_DEPTH =
            VeilHostResourceRegistry.physical(VeilHostResourceRegistry.SCENE_OPAQUE_DEPTH);
    public static final String SCENE_MATERIAL_ID =
            VeilHostResourceRegistry.physical(VeilHostResourceRegistry.SCENE_MATERIAL_ID);
    public static final String SCENE_MATERIAL_DEPTH =
            VeilHostResourceRegistry.physical(VeilHostResourceRegistry.SCENE_MATERIAL_DEPTH);

    public record Frame(
            List<List<VeilRenderGraph.Barrier>> passes,
            List<VeilRenderGraph.Barrier> present,
            Map<String, VeilRenderGraph.State> finalStates,
            List<VeilRenderGraph.Barrier> release,
            Map<String, List<VeilRenderGraph.ImageState>> imageStates) {
        public Frame {
            var snapshots = new java.util.LinkedHashMap<String, List<VeilRenderGraph.ImageState>>();
            imageStates.forEach((name, ranges) -> snapshots.put(name, List.copyOf(ranges)));
            imageStates = Map.copyOf(snapshots);
        }

        public Frame(
                List<List<VeilRenderGraph.Barrier>> passes,
                List<VeilRenderGraph.Barrier> present,
                Map<String, VeilRenderGraph.State> finalStates,
                List<VeilRenderGraph.Barrier> release) {
            this(passes, present, finalStates, release, Map.of());
        }
    }

    private final dev.veil.revive.client.graphics.rendergraph.FrameCyclePlan plan;

    public VeilShaderGraphPlan(VeilShaderPack.Prepared prepared) {
        plan = new dev.veil.revive.client.graphics.rendergraph.FrameCyclePlan(prepared);
    }

    public Frame frame(long ordinal) {
        return plan.frame(ordinal);
    }

    public Map<String, List<VeilRenderGraph.ImageState>> initialImageStates() {
        return plan.initialImageStates();
    }

    public String physical(String logical, long ordinal) {
        return plan.physical(logical, ordinal);
    }

    public static VeilRenderGraph.State sceneColorState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_2_TRANSFER_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    public static VeilRenderGraph.State sceneDepthState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT | VK_ACCESS_2_TRANSFER_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    public static VeilRenderGraph.State transferWriteState() {
        return VeilRenderGraph.State.of(VeilRenderGraph.Access.TRANSFER_WRITE);
    }

    public static VeilRenderGraph.State materialColorWriteState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_TRANSFER_BIT | VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT,
                VK_ACCESS_2_TRANSFER_WRITE_BIT | VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    public static VeilRenderGraph.State materialDepthWriteState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_TRANSFER_BIT
                        | VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT,
                VK_ACCESS_2_TRANSFER_WRITE_BIT | VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    public static VeilRenderGraph.State initialGeneralState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_TOP_OF_PIPE_BIT, 0, false, VeilRenderGraph.Layout.GENERAL);
    }

    public static VeilRenderGraph.State undefinedState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_TOP_OF_PIPE_BIT, 0, false, VeilRenderGraph.Layout.UNDEFINED);
    }

    public static VeilRenderGraph.State sampledState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_SAMPLED_READ_BIT,
                false,
                VeilRenderGraph.Layout.SHADER_READ_ONLY);
    }

    public static VeilRenderGraph.State storageState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT,
                VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }
}
