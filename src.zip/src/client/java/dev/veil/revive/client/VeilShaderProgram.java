package dev.veil.revive.client;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

public record VeilShaderProgram(
        VeilShaderId id,
        long generation,
        Map<VeilShaderStage, VeilSpirvBinary> stages,
        VeilShaderInterface shaderInterface,
        Map<VeilShaderId, String> dependencies) {
    public VeilShaderProgram {
        Objects.requireNonNull(id, "id");
        if (generation < 1) throw new IllegalArgumentException("generation < 1");
        stages = Map.copyOf(stages);
        dependencies = Map.copyOf(dependencies);
        Objects.requireNonNull(shaderInterface, "shaderInterface");
        boolean compute = stages.keySet().equals(Set.of(VeilShaderStage.COMPUTE));
        boolean graphics =
                stages.containsKey(VeilShaderStage.VERTEX)
                        && stages.containsKey(VeilShaderStage.FRAGMENT)
                        && stages.keySet().stream().allMatch(VeilShaderProgram::graphicsStage)
                        && stages.containsKey(VeilShaderStage.TESS_CONTROL)
                                == stages.containsKey(VeilShaderStage.TESS_EVALUATION);
        boolean rayTracing =
                stages.containsKey(VeilShaderStage.RAYGEN)
                        && stages.containsKey(VeilShaderStage.MISS)
                        && stages.keySet().stream().allMatch(VeilShaderProgram::rayStage);
        if (!compute && !graphics && !rayTracing) {
            throw new IllegalArgumentException(
                    "Program "
                            + id
                            + " requires compute, a complete graphics stage chain, or raygen + miss ray stages");
        }
        if (rayTracing
                && stages.containsKey(VeilShaderStage.INTERSECTION)
                && !stages.containsKey(VeilShaderStage.CLOSEST_HIT)
                && !stages.containsKey(VeilShaderStage.ANY_HIT)) {
            throw new IllegalArgumentException(
                    "Procedural ray program " + id + " requires closestHit or anyHit");
        }
        stages.forEach(
                (stage, binary) -> {
                    if (stage != binary.stage())
                        throw new IllegalArgumentException("Stage mismatch: " + id + " " + stage);
                });
        if (graphics) shaderInterface.validateGraphicsStages(stages.keySet());
    }

    public VeilSpirvBinary stage(VeilShaderStage stage) {
        VeilSpirvBinary binary = stages.get(stage);
        if (binary == null)
            throw new IllegalArgumentException("Program " + id + " has no " + stage + " stage");
        return binary;
    }

    public boolean rayTracing() {
        return stages.containsKey(VeilShaderStage.RAYGEN);
    }

    private static boolean rayStage(VeilShaderStage stage) {
        return switch (stage) {
            case RAYGEN, MISS, CLOSEST_HIT, ANY_HIT, INTERSECTION, CALLABLE -> true;
            default -> false;
        };
    }

    private static boolean graphicsStage(VeilShaderStage stage) {
        return switch (stage) {
            case VERTEX, TESS_CONTROL, TESS_EVALUATION, GEOMETRY, FRAGMENT -> true;
            default -> false;
        };
    }
}
