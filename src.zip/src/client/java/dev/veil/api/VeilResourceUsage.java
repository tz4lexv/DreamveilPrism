package dev.veil.api;

public enum VeilResourceUsage {
    SAMPLED,
    STORAGE,
    COLOR_ATTACHMENT,
    DEPTH_ATTACHMENT,
    TRANSFER_SOURCE,
    TRANSFER_DESTINATION,
    UNIFORM,
    VERTEX,
    INDEX,
    INDIRECT
}
