package dev.veil.revive.client;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;

import dev.veil.revive.ReviveMod;
import dev.veil.revive.platform.VeilPlatform;

import net.minecraft.client.Minecraft;

import java.nio.file.Files;
import java.util.Map;

final class VeilWorldVolumeProbe {
    private static final boolean CLOUDS = Boolean.getBoolean("veil.worldCloudProbe");
    private static final boolean DEBUG_VIEWS =
            CLOUDS && Boolean.getBoolean("veil.worldGraphicsDebugProbe");
    private static final boolean COVERAGE_TEST =
            CLOUDS && Boolean.getBoolean("veil.shadowCoverageProbe");
    private static final boolean NEAR_RELOAD = Boolean.getBoolean("veil.nearShadowReloadProbe");
    private static final boolean VIEWPORT_RESIZE =
            NEAR_RELOAD && Boolean.getBoolean("veil.modularViewportResizeProbe");
    private static final int DISABLED_GENERATION =
            NEAR_RELOAD ? 3 : DEBUG_VIEWS ? 9 : COVERAGE_TEST ? 2 : 1;
    private static double originalOutsideFraction, expandedOutsideFraction;
    private static final String KIND = CLOUDS ? "world cloud" : "world fog";
    private static final boolean ENABLED =
            (Boolean.getBoolean("veil.worldFogProbe") || CLOUDS)
                    && !VeilShadowMotionProbe.enabled()
                    && VeilPlatform.get().isDevelopmentEnvironment();
    private static boolean pending, complete;
    private static int frames, generation;
    private static VeilShaderPackRuntime previous;
    private static VeilShaderPackRuntime viewportRuntime;
    private static int viewportStage;
    private static final byte[][] pixels = new byte[4][];
    private static int returned;
    private static long started;
    private static long ready;
    private static long nextViewportWaitLog;
    private static final long WARMUP_NANOS =
            Math.clamp(Long.getLong("veil.worldFogProbeWarmupMillis", 0L), 0L, 120_000L)
                    * 1_000_000L;

    private VeilWorldVolumeProbe() {}

    static Map<String, String> overrides() {
        if (!ENABLED) return Map.of();
        var values = new java.util.LinkedHashMap<String, String>();
        values.put("enabled", "true");
        values.put("density", CLOUDS ? "0.05" : "0.015");
        values.put("steps", CLOUDS ? "48" : "24");
        values.put("shadowStrength", "0.65");
        if (NEAR_RELOAD) {
            if (CLOUDS || DEBUG_VIEWS || COVERAGE_TEST)
                throw new IllegalArgumentException(
                        "Near shadow reload requires the standalone fog probe");
            values.put("nearShadows", "false");
        }
        if (COVERAGE_TEST) {
            values.put("debugView", "7");
            values.put("shadowCoverage", "128.0");
            values.put("shadowRange", "256.0");
            values.put("shadowResolution", "1024");
        }
        return Map.copyOf(values);
    }

    static void checkTimeout(boolean failed) {
        if (!ENABLED || complete) return;
        if (started == 0) started = System.nanoTime();
        if (failed || System.nanoTime() - started > 300_000_000_000L) {
            complete = true;
            ReviveMod.LOGGER.error("Veil {} GPU probe: FAIL (execution failed or timed out)", KIND);
            Minecraft.getInstance().stop();
        }
    }

    static void tick(VeilShaderPackRuntime active) {
        try {
            capture(active);
        } catch (RuntimeException failure) {
            complete = true;
            ReviveMod.LOGGER.error("Veil " + KIND + " GPU probe: FAIL", failure);
            Minecraft.getInstance().stop();
        }
    }

    private static void capture(VeilShaderPackRuntime active) {
        if (!ENABLED
                || pending
                || complete
                || !VeilBenchmarkWorld.terrainReady()
                || active == previous) return;
        long now = System.nanoTime();
        if (ready == 0) ready = now;
        if (now - ready < WARMUP_NANOS || ++frames < 120) return;
        var view = active.output("diagnostics");
        int width = view.getWidth(0), height = view.getHeight(0);
        if (VIEWPORT_RESIZE) {
            int expectedWidth = viewportWidth();
            int expectedHeight = viewportHeight();
            var target = Minecraft.getInstance().gameRenderer.mainRenderTarget();
            if (width != expectedWidth
                    || height != expectedHeight
                    || target.width != expectedWidth
                    || target.height != expectedHeight) {
                if (now >= nextViewportWaitLog) {
                    nextViewportWaitLog = now + 10_000_000_000L;
                    ReviveMod.LOGGER.warn(
                            "Veil modular viewport waiting: stage={} expected={}x{} graph={}x{} native={}x{}",
                            viewportStage,
                            expectedWidth,
                            expectedHeight,
                            width,
                            height,
                            target.width,
                            target.height);
                }
                return;
            }
        }
        long size = (long) width * height * 4;
        if (size > 64 * 1024 * 1024)
            throw new IllegalStateException("Fog probe exceeds readback budget");
        pending = true;
        returned = 0;
        String[] names = {"diagnostics", "output", "original", "presented"};
        for (int index = 0; index < names.length; index++) {
            int slot = index;
            var buffer =
                    RenderSystem.getDevice()
                            .createBuffer(
                                    () -> "Veil world fog readback",
                                    GpuBuffer.USAGE_COPY_DST | GpuBuffer.USAGE_MAP_READ,
                                    size);
            try {
                Runnable callback =
                        () -> {
                            try (var mapped = buffer.map(true, false)) {
                                pixels[slot] = new byte[(int) size];
                                mapped.data().get(pixels[slot]);
                                if (++returned == 5) verify(active, width, height);
                            } catch (Exception failure) {
                                complete = true;
                                ReviveMod.LOGGER.error("Veil world fog GPU probe: FAIL", failure);
                            } finally {
                                buffer.close();
                                if (returned == 5) pending = false;
                                if (complete) Minecraft.getInstance().stop();
                            }
                        };
                if (slot == 3) active.readPresented(buffer, callback);
                else active.readOutput(names[index], buffer, callback);
            } catch (RuntimeException failure) {
                buffer.close();
                throw failure;
            }
        }
        net.minecraft.client.Screenshot.takeScreenshot(
                Minecraft.getInstance().gameRenderer.mainRenderTarget(),
                image -> {
                    try {
                        var directory =
                                VeilPlatform.get()
                                        .getGameDir()
                                        .resolve(CLOUDS ? "logs/world-cloud" : "logs/world-fog");
                        Files.createDirectories(directory);
                        image.writeToFile(directory.resolve(capturePrefix() + "-native.png"));
                        if (++returned == 5) verify(active, width, height);
                    } catch (Exception failure) {
                        complete = true;
                        ReviveMod.LOGGER.error("Veil " + KIND + " GPU probe: FAIL", failure);
                    } finally {
                        image.close();
                        if (returned == 5) pending = false;
                        if (complete) Minecraft.getInstance().stop();
                    }
                });
    }

    private static String capturePrefix() {
        return VIEWPORT_RESIZE && generation == 0 && viewportStage < 3
                ? "viewport-stage-" + viewportStage
                : "generation-" + generation;
    }

    private static int viewportWidth() {
        int stage = generation == 0 ? viewportStage : generation;
        return stage == 1 ? 800 : stage == 2 ? 480 : 640;
    }

    private static int viewportHeight() {
        int stage = generation == 0 ? viewportStage : generation;
        return stage == 1 ? 450 : stage == 2 ? 270 : 360;
    }

    private static void requestViewport() {
        Minecraft.getInstance().getWindow().setWindowed(viewportWidth(), viewportHeight());
        ReviveMod.LOGGER.info(
                "Veil modular viewport requested: {}x{}", viewportWidth(), viewportHeight());
    }

    private static void verify(VeilShaderPackRuntime active, int width, int height)
            throws java.io.IOException {
        int shadowWidth = active.output("shadowDepth").getWidth(0);
        int shadowHeight = active.output("shadowDepth").getHeight(0);
        if (NEAR_RELOAD) {
            boolean near = generation == 1;
            if (Boolean.parseBoolean(active.settings().get("nearShadows").value()) != near)
                throw new IllegalStateException(
                        "Near shadow reload did not publish requested setting");
            var passNames = active.recordedPassNames();
            if (passNames.size() != (near ? 4 : 3)
                    || passNames.contains("shadowNear") != near
                    || passNames.contains("shadowDetail") != near
                    || passNames.contains("farResolve") == near)
                throw new IllegalStateException(
                        "Near shadow reload retained the wrong recorded passes");
            for (String name : new String[] {"shadowDepthNear", "shadowColorNear"}) {
                if (near) {
                    var output = active.output(name);
                    int resolution =
                            Integer.parseInt(active.settings().get("nearShadowResolution").value());
                    if (output.getWidth(0) != resolution || output.getHeight(0) != resolution)
                        throw new IllegalStateException(
                                "Near shadow reload allocated wrong dimensions");
                } else if (active.outputNames().contains(name)) {
                    throw new IllegalStateException(
                            "Disabled near shadow target remains allocated: " + name);
                }
            }
        }
        if (COVERAGE_TEST) {
            int expected = generation == 0 ? 1024 : 2048;
            var shadowColor = active.output("shadowColor");
            if (shadowWidth != expected
                    || shadowHeight != expected
                    || shadowColor.getWidth(0) != expected
                    || shadowColor.getHeight(0) != expected)
                throw new IllegalStateException(
                        "Shadow attachment resize did not match creator settings");
        }
        int geometry = 0, fog = 0, shadow = 0, changed = 0, clouds = 0, selfShadow = 0, outside = 0;
        for (int offset = 0; offset < pixels[0].length; offset += 4) {
            int transmission = Byte.toUnsignedInt(pixels[0][offset]);
            int visibility = Byte.toUnsignedInt(pixels[0][offset + 1]);
            boolean surface = Byte.toUnsignedInt(pixels[0][offset + 2]) == 255;
            if (surface) geometry++;
            if (COVERAGE_TEST
                    && generation < DISABLED_GENERATION
                    && surface
                    && Byte.toUnsignedInt(pixels[1][offset]) > 253
                    && Byte.toUnsignedInt(pixels[1][offset + 1]) < 2
                    && Byte.toUnsignedInt(pixels[1][offset + 2]) > 253) outside++;
            if (surface && transmission < 250) fog++;
            if (surface && (CLOUDS ? visibility < 250 : visibility == 0)) shadow++;
            if (!surface && transmission < 250) {
                clouds++;
                if (visibility < 250) selfShadow++;
            }
            boolean differs = false;
            for (int channel = 0; channel < 4; channel++) {
                if (Math.abs(
                                Byte.toUnsignedInt(pixels[1][offset + channel])
                                        - Byte.toUnsignedInt(pixels[3][offset + channel]))
                        > 2)
                    throw new IllegalStateException(
                            "Presented scene differs from fog output at pixel=" + offset / 4);
                int difference =
                        Math.abs(
                                Byte.toUnsignedInt(pixels[1][offset + channel])
                                        - Byte.toUnsignedInt(pixels[2][offset + channel]));
                differs |= difference > 2;
                if (generation == DISABLED_GENERATION && difference > 1)
                    throw new IllegalStateException(
                            "Disabled fog changed original scene pixel=" + offset / 4);
            }
            if (differs) changed++;
            if (generation == DISABLED_GENERATION && (transmission != 255 || visibility != 255))
                throw new IllegalStateException("Disabled fog diagnostics are not neutral");
        }
        if (geometry < 100
                || generation < DISABLED_GENERATION
                        && ((CLOUDS ? clouds < 100 || selfShadow < 100 : fog < 100)
                                || shadow < 5
                                || changed < 100))
            throw new IllegalStateException(
                    "World fog coverage insufficient: geometry="
                            + geometry
                            + " fog="
                            + fog
                            + " shadow="
                            + shadow
                            + " changed="
                            + changed);
        if (COVERAGE_TEST && generation < DISABLED_GENERATION) {
            double fraction = (double) outside / geometry;
            if (generation == 0) {
                originalOutsideFraction = fraction;
                if (fraction < 0.1)
                    throw new IllegalStateException("Coverage fixture lacks outside receivers");
            } else {
                expandedOutsideFraction = fraction;
                if (fraction >= originalOutsideFraction * 0.75)
                    throw new IllegalStateException(
                            "Expanded shadow volume did not reduce outside receivers: " + fraction);
            }
        }
        var directory =
                VeilPlatform.get()
                        .getGameDir()
                        .resolve(CLOUDS ? "logs/world-cloud" : "logs/world-fog");
        Files.createDirectories(directory);
        for (int slot = 0; slot < 4; slot++) {
            var image =
                    new java.awt.image.BufferedImage(
                            width, height, java.awt.image.BufferedImage.TYPE_INT_ARGB);
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++) {
                    int offset = (y * width + x) * 4;
                    image.setRGB(
                            x,
                            height - 1 - y,
                            0xff000000
                                    | Byte.toUnsignedInt(pixels[slot][offset]) << 16
                                    | Byte.toUnsignedInt(pixels[slot][offset + 1]) << 8
                                    | Byte.toUnsignedInt(pixels[slot][offset + 2]));
                }
            if (!javax.imageio.ImageIO.write(
                    image,
                    "png",
                    directory.resolve(capturePrefix() + "-" + slot + ".png").toFile()))
                throw new java.io.IOException("PNG encoder unavailable");
        }
        Files.writeString(
                directory.resolve(capturePrefix() + ".json"),
                "{\"geometry_pixels\":"
                        + geometry
                        + ",\"shadow_width\":"
                        + shadowWidth
                        + ",\"shadow_height\":"
                        + shadowHeight
                        + ",\"outside_shadow_pixels\":"
                        + outside
                        + ",\"fog_pixels\":"
                        + fog
                        + ",\"shadow_pixels\":"
                        + shadow
                        + ",\"cloud_pixels\":"
                        + clouds
                        + ",\"cloud_self_shadow_pixels\":"
                        + selfShadow
                        + ",\"changed_pixels\":"
                        + changed
                        + ",\"width\":"
                        + width
                        + ",\"height\":"
                        + height
                        + (NEAR_RELOAD
                                ? ",\"near_shadow_reload\":true,\"near_shadows\":"
                                        + (generation == 1)
                                        + ",\"recorded_passes\":"
                                        + new com.google.gson.Gson()
                                                .toJson(active.recordedPassNames())
                                : "")
                        + "}");
        if (VIEWPORT_RESIZE && generation == 0) {
            if (viewportRuntime == null) viewportRuntime = active;
            else if (viewportRuntime != active)
                throw new IllegalStateException("In-place viewport probe replaced the runtime");
            ReviveMod.LOGGER.info(
                    "Veil modular in-place viewport verified: stage={} size={}x{} same_runtime=true",
                    viewportStage,
                    width,
                    height);
            if (viewportStage < 3) {
                viewportStage++;
                frames = 0;
                requestViewport();
                return;
            }
        }
        if (generation < DISABLED_GENERATION) {
            generation++;
            previous = active;
            frames = 0;
            if (VIEWPORT_RESIZE) {
                requestViewport();
            }
            if (NEAR_RELOAD && generation < DISABLED_GENERATION) {
                VeilShaderService.setting("nearShadows", generation == 1 ? "true" : "false");
            } else if (COVERAGE_TEST && generation == 1) {
                try {
                    VeilShaderService.settings(
                            Map.of("shadowCoverage", "512.0", "invalidProbeSetting", "1"));
                    throw new IllegalStateException("Invalid batch setting was accepted");
                } catch (IllegalArgumentException expected) {
                    if (!expected.getMessage().contains("Unknown shader setting")) throw expected;
                }
                VeilShaderService.settings(
                        Map.of(
                                "shadowCoverage",
                                "512.0",
                                "shadowRange",
                                "1024.0",
                                "shadowResolution",
                                "2048"));
            } else if (DEBUG_VIEWS && generation < DISABLED_GENERATION)
                VeilShaderService.setting("debugView", Integer.toString(generation));
            else VeilShaderService.setting("enabled", "false");
            ReviveMod.LOGGER.info(
                    "Veil "
                            + KIND
                            + " GPU probe: enabled scene verified; geometry={}, fog={}, shadow={}, changed={}; checking neutral generation",
                    geometry,
                    fog,
                    shadow,
                    changed);
        } else {
            complete = true;
            ReviveMod.LOGGER.info(
                    "Veil "
                            + KIND
                            + " GPU probe: PASS (real terrain depth, volume extinction, surface shadow visibility, presented scene pixel identity, disabled pixel identity, "
                            + (DISABLED_GENERATION + 1)
                            + " generations)");
            if (VIEWPORT_RESIZE)
                ReviveMod.LOGGER.info(
                        "Veil modular viewport resize: PASS (640x360, 800x450, 480x270, 640x360; native target and graph readbacks)");
            if (DEBUG_VIEWS)
                ReviveMod.LOGGER.info(
                        "Veil graphics debug views: PASS (9 modes presented, transactional mode changes, disabled identity, native screenshots)");
            if (NEAR_RELOAD)
                ReviveMod.LOGGER.info(
                        "Veil near shadow reload: PASS (off/on/off, recorded pass selection, current generation target allocation, disabled identity)");
            if (COVERAGE_TEST)
                ReviveMod.LOGGER.info(
                        "Veil shadow coverage: PASS (outside fraction {} -> {}, atomic volume/range/resolution reload, disabled identity)",
                        originalOutsideFraction,
                        expandedOutsideFraction);
        }
    }
}
