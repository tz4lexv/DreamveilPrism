package dev.veil.revive.mixin;

import dev.veil.revive.client.VeilRayCompileState;

import net.minecraft.client.renderer.chunk.SectionMesh;
import net.minecraft.client.renderer.chunk.SectionRenderDispatcher;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SectionRenderDispatcher.RenderSection.class)
public abstract class RenderSectionRayCompileMixin implements VeilRayCompileState {
    @Unique private volatile Object veil$rayCompileTask;

    @Inject(method = "createCompileTask", at = @At("RETURN"), require = 1)
    private void veil$trackRayCompile(CallbackInfoReturnable<Object> cir) {
        veil$rayCompileTask = cir.getReturnValue();
    }

    @Inject(method = "cancelTasks", at = @At("HEAD"), require = 1)
    private void veil$cancelRayCompile(CallbackInfo ci) {
        veil$rayCompileTask = null;
    }

    @Inject(method = "setSectionMesh", at = @At("RETURN"), require = 1)
    private void veil$finishRayCompile(SectionMesh mesh, CallbackInfoReturnable<SectionMesh> cir) {
        veil$rayCompileTask = null;
    }

    @Override
    public boolean veil$rayCompilePending() {
        Object task = veil$rayCompileTask;
        return task instanceof SectionTaskAccessor accessor && !accessor.veil$isCancelled().get();
    }
}
