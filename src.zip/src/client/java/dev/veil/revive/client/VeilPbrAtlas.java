package dev.veil.revive.client;

import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.revive.client.scene.materials.PbrAtlasInputs;

import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.Identifier;

public final class VeilPbrAtlas {
    private static final PbrAtlasInputs INPUTS =
            new PbrAtlasInputs(() -> VeilShaderLimits.current().packBytes());

    private VeilPbrAtlas() {}

    public static void invalidate(TextureAtlas atlas) {
        INPUTS.invalidate(atlas);
    }

    public static void animationFrame(Identifier name, Object animation, int frame, int subFrame) {
        INPUTS.animationFrame(name, animation, frame, subFrame);
    }

    static void prepare() {
        INPUTS.prepare();
    }

    static void prepare(int mask) {
        INPUTS.prepare((mask & 1) != 0, (mask & 2) != 0);
    }

    static boolean ready() {
        return INPUTS.ready();
    }

    static GpuTexture texture(boolean spec) {
        return INPUTS.texture(spec);
    }

    static GpuTextureView view(boolean spec) {
        return INPUTS.view(spec);
    }

    static String telemetry() {
        return INPUTS.telemetry();
    }

    static void close() {
        INPUTS.close();
    }
}
