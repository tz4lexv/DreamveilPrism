package dev.veil.revive.client;

import static org.lwjgl.vulkan.VK13.*;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;

import dev.veil.api.VeilResourceType;
import dev.veil.api.VeilResourceUsage;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureAtlas;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public final class VeilHostResourceRegistry {
    public static final String SCENE_COLOR = "minecraft:scene_color";
    public static final String SCENE_DEPTH = "minecraft:scene_depth";
    public static final String SCENE_OPAQUE_COLOR = "minecraft:scene_opaque_color";
    public static final String SCENE_OPAQUE_DEPTH = "minecraft:scene_opaque_depth";
    public static final String SCENE_MATERIAL_ID = "minecraft:scene_material_id";
    public static final String SCENE_MATERIAL_DEPTH = "minecraft:scene_material_depth";
    public static final String ENVIRONMENT = "minecraft:environment";
    public static final String BLOCK_NORMAL_ATLAS = "minecraft:block_normal_atlas";
    public static final String BLOCK_SPECULAR_ATLAS = "minecraft:block_specular_atlas";
    public static final String BLOCK_ATLAS = "minecraft:block_atlas";
    public static final String LIGHTMAP = "minecraft:lightmap";
    public static final String NATIVE_LIGHTING = VeilNativeLightingHost.HOST_ID;
    public static final String CREATOR_LIGHTS = VeilCreatorSceneHost.LIGHTS_ID;
    public static final String CREATOR_INSTANCES = VeilCreatorSceneHost.INSTANCES_ID;
    public static final String CREATOR_MATERIALS = VeilCreatorSceneHost.MATERIALS_ID;
    public static final String CREATOR_GEOMETRY = VeilCreatorSceneHost.GEOMETRY_ID;
    public static final String CREATOR_MESHES = VeilCreatorMeshHost.HOST_ID;
    public static final String SHADOW_LIGHTS = VeilShadowLightHost.HOST_ID;

    public record Definition(
            String id,
            VeilRenderGraph.Kind kind,
            long bytes,
            VeilResourceType type,
            Set<VeilResourceUsage> usages,
            VeilRenderGraph.State initialState,
            VeilRenderGraph.State releaseState,
            boolean nearestOnly,
            boolean compatibilityOnly) {}

    public record Resolved(GpuBuffer buffer, GpuTexture image, GpuTextureView view) {
        public static Resolved image(GpuTexture image, GpuTextureView view) {
            return new Resolved(null, image, view);
        }
    }

    @FunctionalInterface
    private interface Provider {
        Resolved resolve(RenderTarget scene);
    }

    private record Entry(Definition definition, Provider provider) {}

    private static final Map<String, Entry> ENTRIES;
    private static final Map<String, Definition> DEFINITIONS;

    static {
        var entries = new LinkedHashMap<String, Entry>();
        image(
                entries,
                SCENE_COLOR,
                sceneColorState(),
                new VeilRenderGraph.State(
                        VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                        VK_ACCESS_2_MEMORY_READ_BIT | VK_ACCESS_2_MEMORY_WRITE_BIT,
                        true,
                        VeilRenderGraph.Layout.GENERAL),
                false,
                false,
                scene -> Resolved.image(scene.getColorTexture(), scene.getColorTextureView()));
        image(
                entries,
                SCENE_DEPTH,
                sceneDepthState(),
                new VeilRenderGraph.State(
                        VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                        VK_ACCESS_2_MEMORY_READ_BIT | VK_ACCESS_2_MEMORY_WRITE_BIT,
                        true,
                        VeilRenderGraph.Layout.GENERAL),
                true,
                false,
                scene ->
                        scene.getDepthTexture() == null
                                ? null
                                : Resolved.image(
                                        scene.getDepthTexture(), scene.getDepthTextureView()));
        image(
                entries,
                SCENE_OPAQUE_COLOR,
                transferWriteState(),
                transferWriteState(),
                false,
                false,
                scene ->
                        VeilMaterialHost.readyOpaque()
                                ? Resolved.image(
                                        VeilMaterialHost.opaqueColorTexture(),
                                        VeilMaterialHost.opaqueColorView())
                                : null);
        image(
                entries,
                SCENE_OPAQUE_DEPTH,
                transferWriteState(),
                transferWriteState(),
                true,
                false,
                scene ->
                        VeilMaterialHost.readyOpaque()
                                ? Resolved.image(
                                        VeilMaterialHost.opaqueDepthTexture(),
                                        VeilMaterialHost.opaqueDepthView())
                                : null);
        image(
                entries,
                SCENE_MATERIAL_ID,
                materialColorWriteState(),
                materialColorWriteState(),
                true,
                false,
                scene ->
                        VeilMaterialHost.readyMaterials()
                                ? Resolved.image(
                                        VeilMaterialHost.materialIdTexture(),
                                        VeilMaterialHost.materialIdView())
                                : null);
        image(
                entries,
                SCENE_MATERIAL_DEPTH,
                materialDepthWriteState(),
                materialDepthWriteState(),
                true,
                false,
                scene ->
                        VeilMaterialHost.readyMaterials()
                                ? Resolved.image(
                                        VeilMaterialHost.materialDepthTexture(),
                                        VeilMaterialHost.materialDepthView())
                                : null);
        for (var channel : dev.veil.api.VeilSurfaceGuides.Channel.values())
            image(
                    entries,
                    channel.hostId(),
                    new VeilRenderGraph.State(
                            VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                            VK_ACCESS_2_MEMORY_READ_BIT | VK_ACCESS_2_MEMORY_WRITE_BIT,
                            true,
                            VeilRenderGraph.Layout.GENERAL),
                    new VeilRenderGraph.State(
                            VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                            VK_ACCESS_2_MEMORY_READ_BIT | VK_ACCESS_2_MEMORY_WRITE_BIT,
                            true,
                            VeilRenderGraph.Layout.GENERAL),
                    channel == dev.veil.api.VeilSurfaceGuides.Channel.IDENTITY
                            || channel == dev.veil.api.VeilSurfaceGuides.Channel.MOTION_DEPTH,
                    false,
                    scene -> null);
        image(
                entries,
                BLOCK_ATLAS,
                sampledHostState(),
                sampledHostState(),
                false,
                false,
                scene -> {
                    var atlas =
                            Minecraft.getInstance()
                                    .getTextureManager()
                                    .getTexture(TextureAtlas.LOCATION_BLOCKS);
                    return Resolved.image(atlas.getTexture(), atlas.getTextureView());
                });
        image(
                entries,
                LIGHTMAP,
                new VeilRenderGraph.State(
                        VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                        VK_ACCESS_2_MEMORY_READ_BIT | VK_ACCESS_2_MEMORY_WRITE_BIT,
                        true,
                        VeilRenderGraph.Layout.GENERAL),
                sampledHostState(),
                false,
                false,
                scene -> {
                    var renderer = Minecraft.getInstance().gameRenderer;
                    var view = renderer == null ? null : renderer.levelLightmap();
                    return view == null ? null : Resolved.image(view.texture(), view);
                });
        buffer(
                entries,
                VeilColorPipeline.HOST_ID,
                VeilColorPipeline.SIZE,
                new VeilRenderGraph.State(
                        VK_PIPELINE_STAGE_2_HOST_BIT,
                        VK_ACCESS_2_HOST_WRITE_BIT,
                        true,
                        VeilRenderGraph.Layout.GENERAL),
                new VeilRenderGraph.State(
                        VK_PIPELINE_STAGE_2_HOST_BIT,
                        VK_ACCESS_2_HOST_WRITE_BIT,
                        true,
                        VeilRenderGraph.Layout.GENERAL),
                scene -> null);
        buffer(
                entries,
                VeilSurfaceTransforms.HOST_ID,
                VeilSurfaceTransforms.SIZE,
                new VeilRenderGraph.State(
                        VK_PIPELINE_STAGE_2_HOST_BIT,
                        VK_ACCESS_2_HOST_WRITE_BIT,
                        true,
                        VeilRenderGraph.Layout.GENERAL),
                new VeilRenderGraph.State(
                        VK_PIPELINE_STAGE_2_HOST_BIT,
                        VK_ACCESS_2_HOST_WRITE_BIT,
                        true,
                        VeilRenderGraph.Layout.GENERAL),
                scene -> null);
        buffer(
                entries,
                VeilWorldRayScene.HOST_ID,
                VeilWorldRayScene.CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilWorldRayScene.buffer(), null, null));
        buffer(
                entries,
                CREATOR_LIGHTS,
                VeilCreatorSceneHost.LIGHTS_CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilCreatorSceneHost.lights(), null, null));
        buffer(
                entries,
                CREATOR_INSTANCES,
                VeilCreatorSceneHost.INSTANCES_CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilCreatorSceneHost.instances(), null, null));
        buffer(
                entries,
                CREATOR_MATERIALS,
                VeilCreatorSceneHost.MATERIALS_CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilCreatorSceneHost.materials(), null, null));
        buffer(
                entries,
                CREATOR_GEOMETRY,
                VeilCreatorSceneHost.GEOMETRY_CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilCreatorSceneHost.geometry(), null, null));
        buffer(
                entries,
                CREATOR_MESHES,
                VeilCreatorMeshHost.CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilCreatorMeshHost.buffer(), null, null));
        buffer(
                entries,
                SHADOW_LIGHTS,
                VeilShadowLightHost.CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilShadowLightHost.buffer(), null, null));
        image(
                entries,
                BLOCK_NORMAL_ATLAS,
                transferWriteState(),
                transferWriteState(),
                false,
                false,
                scene -> Resolved.image(VeilPbrAtlas.texture(false), VeilPbrAtlas.view(false)));
        image(
                entries,
                BLOCK_SPECULAR_ATLAS,
                transferWriteState(),
                transferWriteState(),
                false,
                false,
                scene -> Resolved.image(VeilPbrAtlas.texture(true), VeilPbrAtlas.view(true)));
        buffer(
                entries,
                ENVIRONMENT,
                VeilEnvironmentHost.CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilEnvironmentHost.buffer(), null, null));
        buffer(
                entries,
                NATIVE_LIGHTING,
                VeilNativeLightingHost.CAPACITY,
                transferWriteState(),
                transferWriteState(),
                scene -> new Resolved(VeilNativeLightingHost.buffer(), null, null));
        ENTRIES = Collections.unmodifiableMap(entries);
        var definitions = new LinkedHashMap<String, Definition>();
        entries.forEach((id, entry) -> definitions.put(id, entry.definition()));
        DEFINITIONS = Collections.unmodifiableMap(definitions);
    }

    private VeilHostResourceRegistry() {}

    private static VeilRenderGraph.State sceneColorState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_2_TRANSFER_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    private static VeilRenderGraph.State sceneDepthState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT | VK_ACCESS_2_TRANSFER_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    private static VeilRenderGraph.State transferWriteState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_TRANSFER_BIT,
                VK_ACCESS_2_TRANSFER_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    private static VeilRenderGraph.State materialColorWriteState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_TRANSFER_BIT | VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT,
                VK_ACCESS_2_TRANSFER_WRITE_BIT | VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    private static VeilRenderGraph.State materialDepthWriteState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_TRANSFER_BIT
                        | VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT
                        | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT,
                VK_ACCESS_2_TRANSFER_WRITE_BIT | VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
                true,
                VeilRenderGraph.Layout.GENERAL);
    }

    private static VeilRenderGraph.State sampledHostState() {
        return new VeilRenderGraph.State(
                VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT,
                VK_ACCESS_2_MEMORY_READ_BIT,
                false,
                VeilRenderGraph.Layout.GENERAL);
    }

    private static void image(
            Map<String, Entry> entries,
            String id,
            VeilRenderGraph.State initial,
            VeilRenderGraph.State release,
            boolean nearestOnly,
            boolean compatibility,
            Provider provider) {
        register(
                entries,
                new Definition(
                        id,
                        VeilRenderGraph.Kind.IMAGE,
                        0,
                        VeilResourceType.TEXTURE_2D,
                        Set.of(VeilResourceUsage.SAMPLED),
                        initial,
                        release,
                        nearestOnly,
                        compatibility),
                provider);
    }

    private static void buffer(
            Map<String, Entry> entries,
            String id,
            long bytes,
            VeilRenderGraph.State initial,
            VeilRenderGraph.State release,
            Provider provider) {
        register(
                entries,
                new Definition(
                        id,
                        VeilRenderGraph.Kind.BUFFER,
                        bytes,
                        VeilResourceType.BUFFER,
                        Set.of(VeilResourceUsage.STORAGE),
                        initial,
                        release,
                        false,
                        false),
                provider);
    }

    private static void register(
            Map<String, Entry> entries, Definition definition, Provider provider) {
        if (definition.id() == null
                || definition.id().isBlank()
                || !definition.id().contains(":")) {
            throw new IllegalArgumentException(
                    "Host resource ID must be namespaced: " + definition.id());
        }
        if (entries.putIfAbsent(definition.id(), new Entry(definition, provider)) != null) {
            throw new IllegalStateException(
                    "Duplicate host resource registration: " + definition.id());
        }
    }

    public static Definition definition(String id) {
        Definition definition = DEFINITIONS.get(id);
        if (definition == null)
            throw new IllegalArgumentException("Unknown Veil host resource: " + id);
        return definition;
    }

    public static boolean known(String id) {
        return DEFINITIONS.containsKey(id);
    }

    public static Map<String, Definition> definitions() {
        return DEFINITIONS;
    }

    public static String legacyId(VeilShaderPack.Source source) {
        return switch (source) {
            case OWNED, HOST -> null;
            case SCENE_COLOR -> SCENE_COLOR;
            case SCENE_DEPTH -> SCENE_DEPTH;
            case SCENE_OPAQUE_COLOR -> SCENE_OPAQUE_COLOR;
            case SCENE_OPAQUE_DEPTH -> SCENE_OPAQUE_DEPTH;
            case SCENE_MATERIAL_ID -> SCENE_MATERIAL_ID;
            case SCENE_MATERIAL_DEPTH -> SCENE_MATERIAL_DEPTH;
        };
    }

    public static String physical(String id) {
        return "@host:" + id;
    }

    public static Resolved resolve(String id, RenderTarget scene) {
        Entry entry = ENTRIES.get(id);
        if (entry == null) throw new IllegalArgumentException("Unknown Veil host resource: " + id);
        return entry.provider().resolve(scene);
    }
}
