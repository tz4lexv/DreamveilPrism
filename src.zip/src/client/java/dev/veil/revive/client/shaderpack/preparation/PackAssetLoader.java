package dev.veil.revive.client.shaderpack.preparation;

import dev.veil.revive.client.VeilRayScene;
import dev.veil.revive.client.VeilShaderAssets;
import dev.veil.revive.client.VeilShaderId;
import dev.veil.revive.client.VeilShaderPack.Resource;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BiFunction;

public final class PackAssetLoader {
    private PackAssetLoader() {}

    @FunctionalInterface
    public interface AssetReader {
        byte[] read(VeilShaderId id) throws IOException;
    }

    public record LoadedAsset(byte[] bytes, String hash) {}

    public record Assets(Map<String, LoadedAsset> images, Map<String, LoadedAsset> buffers) {}

    public static Assets load(
            Map<String, Resource> resources,
            AssetReader reader,
            BiFunction<Resource, byte[], byte[]> decodeKtx,
            long assetBudget,
            long packBudget)
            throws IOException {
        var imageAssets = new LinkedHashMap<String, LoadedAsset>();
        var bufferAssets = new LinkedHashMap<String, LoadedAsset>();
        long imageAssetBytes = 0;
        long bufferAssetBytes = 0;
        for (Resource resource : resources.values()) {
            if (resource.initializedAsset()) {
                long expected = resource.expectedAssetBytes();
                if (expected > assetBudget) {
                    throw new IllegalArgumentException(
                            "Image asset exceeds configured asset budget: " + resource.name());
                }
                imageAssetBytes = Math.addExact(imageAssetBytes, expected);
                if (imageAssetBytes > packBudget - bufferAssetBytes) {
                    throw new IllegalArgumentException(
                            "Combined image assets exceed configured pack budget");
                }
                byte[] sourceBytes = reader.read(resource.asset());
                if (sourceBytes.length > assetBudget) {
                    throw new IllegalArgumentException(
                            "Image source asset exceeds configured asset budget: "
                                    + resource.name());
                }
                byte[] bytes =
                        resource.ktx2Asset() ? decodeKtx.apply(resource, sourceBytes) : sourceBytes;
                if (bytes.length != expected) {
                    throw new IllegalArgumentException(
                            "Image "
                                    + resource.name()
                                    + (resource.ktx2Asset() ? " KTX2 decoded" : " raw")
                                    + " asset size mismatch; expected="
                                    + expected
                                    + " actual="
                                    + bytes.length);
                }
                imageAssets.put(
                        resource.name(),
                        new LoadedAsset(bytes, VeilShaderAssets.hash(sourceBytes)));
            } else if (resource.initializedBufferAsset()) {
                if (resource.raySceneAsset() && resource.history()) {
                    throw new IllegalArgumentException(
                            "Ray scene assets are immutable and cannot use history");
                }
                bufferAssetBytes = Math.addExact(bufferAssetBytes, resource.bytes());
                if (bufferAssetBytes > packBudget - imageAssetBytes) {
                    throw new IllegalArgumentException(
                            "Combined initialized assets exceed configured pack budget");
                }
                byte[] bytes = reader.read(resource.asset());
                if (resource.raySceneAsset()) {
                    bytes = VeilRayScene.compile(bytes, Math.toIntExact(resource.bytes()));
                }
                if (bytes.length != resource.bytes()) {
                    throw new IllegalArgumentException(
                            "Buffer "
                                    + resource.name()
                                    + " raw asset size mismatch; expected="
                                    + resource.bytes()
                                    + " actual="
                                    + bytes.length);
                }
                bufferAssets.put(
                        resource.name(), new LoadedAsset(bytes, VeilShaderAssets.hash(bytes)));
            }
        }
        return new Assets(imageAssets, bufferAssets);
    }
}
