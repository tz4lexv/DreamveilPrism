package dev.veil.revive.client.graphics.minecraft;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * One-shot admission to Minecraft's GPU retirement queue. This class does not signal GPU
 * completion: only the host queue may execute the destruction callback. An enqueue failure can be
 * retried as long as the callback never started.
 */
public final class DeferredGpuRetirement {
    private static final int OPEN = 0;
    private static final int SUBMITTING = 1;
    private static final int QUEUED = 2;
    private static final int DESTROYING = 3;
    private static final int FINISHED = 4;

    private final AtomicInteger state = new AtomicInteger(OPEN);

    public boolean closeRequested() {
        return state.get() != OPEN;
    }

    /** For resources destroyed synchronously during failed construction only. */
    public void markDestroyed() {
        state.set(FINISHED);
    }

    public void defer(Consumer<Runnable> hostQueue, Runnable destruction) {
        Objects.requireNonNull(hostQueue, "hostQueue");
        Objects.requireNonNull(destruction, "destruction");
        if (!state.compareAndSet(OPEN, SUBMITTING)) return;
        try {
            hostQueue.accept(
                    () -> {
                        if (!state.compareAndSet(QUEUED, DESTROYING)
                                && !state.compareAndSet(SUBMITTING, DESTROYING)) return;
                        try {
                            destruction.run();
                        } finally {
                            state.set(FINISHED);
                        }
                    });
            state.compareAndSet(SUBMITTING, QUEUED);
        } catch (RuntimeException | Error failure) {
            // Never re-open after execution began, even when a synchronous host
            // callback itself throws. That would risk native double destruction.
            state.compareAndSet(SUBMITTING, OPEN);
            throw failure;
        }
    }
}
