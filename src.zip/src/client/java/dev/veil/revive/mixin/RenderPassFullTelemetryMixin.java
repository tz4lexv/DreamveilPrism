package dev.veil.revive.mixin;

import com.mojang.blaze3d.IndexType;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;

import dev.veil.revive.client.VeilFullFrameTelemetry;

import org.lwjgl.PointerBuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.IntBuffer;
import java.util.Collection;

@Mixin(RenderPass.class)
public abstract class RenderPassFullTelemetryMixin {
    @Unique private int veil$token = -1;
    @Unique private boolean veil$started;

    @Inject(method = "setPipeline", at = @At("HEAD"), require = 0)
    private void veil$pipeline(RenderPipeline pipeline, CallbackInfo ci) {
        if (!VeilFullFrameTelemetry.active()) return;
        if (!this.veil$started) {
            this.veil$started = true;
            this.veil$token =
                    VeilFullFrameTelemetry.beginGpuRenderPass((RenderPass) (Object) this, pipeline);
        } else {
            VeilFullFrameTelemetry.pipelineBound(this.veil$token, pipeline);
        }
    }

    @Inject(method = "draw(IIII)V", at = @At("HEAD"), require = 0)
    private void veil$draw(
            int vertexCount,
            int instanceCount,
            int firstVertex,
            int firstInstance,
            CallbackInfo ci) {
        long instances = Math.max(0, instanceCount);
        VeilFullFrameTelemetry.draw(
                this.veil$token,
                Math.max(0L, (long) vertexCount) * instances,
                0L,
                instances,
                false);
    }

    @Inject(method = "drawIndexed(IIIII)V", at = @At("HEAD"), require = 0)
    private void veil$drawIndexed(
            int indexCount,
            int instanceCount,
            int firstIndex,
            int baseVertex,
            int firstInstance,
            CallbackInfo ci) {
        long instances = Math.max(0, instanceCount);
        VeilFullFrameTelemetry.draw(
                this.veil$token, 0L, Math.max(0L, (long) indexCount) * instances, instances, true);
    }

    @Inject(method = "drawIndirect", at = @At("HEAD"), require = 0)
    private void veil$drawIndirect(GpuBufferSlice commands, int drawCount, CallbackInfo ci) {
        VeilFullFrameTelemetry.indirectDraw(this.veil$token, drawCount, false);
    }

    @Inject(method = "drawIndexedIndirect", at = @At("HEAD"), require = 0)
    private void veil$drawIndexedIndirect(GpuBufferSlice commands, int drawCount, CallbackInfo ci) {
        VeilFullFrameTelemetry.indirectDraw(this.veil$token, drawCount, true);
    }

    @Inject(method = "multiDraw(Ljava/nio/IntBuffer;III)V", at = @At("HEAD"), require = 0)
    private void veil$multiDrawParams(
            IntBuffer drawParameters,
            int instanceCount,
            int firstInstance,
            int drawCount,
            CallbackInfo ci) {
        VeilFullFrameTelemetry.multiDraw(this.veil$token, drawCount, false);
    }

    @Inject(
            method = "multiDraw(Ljava/nio/IntBuffer;Ljava/nio/IntBuffer;I)V",
            at = @At("HEAD"),
            require = 0)
    private void veil$multiDrawBuffers(
            IntBuffer firstVertices, IntBuffer vertexCounts, int drawCount, CallbackInfo ci) {
        VeilFullFrameTelemetry.multiDraw(this.veil$token, drawCount, false);
    }

    @Inject(method = "multiDrawIndexed(Ljava/nio/IntBuffer;III)V", at = @At("HEAD"), require = 0)
    private void veil$multiDrawIndexedParams(
            IntBuffer drawParameters,
            int instanceCount,
            int firstInstance,
            int drawCount,
            CallbackInfo ci) {
        VeilFullFrameTelemetry.multiDraw(this.veil$token, drawCount, true);
    }

    @Inject(
            method =
                    "multiDrawIndexed(Lorg/lwjgl/PointerBuffer;Ljava/nio/IntBuffer;Ljava/nio/IntBuffer;I)V",
            at = @At("HEAD"),
            require = 0)
    private void veil$multiDrawIndexedBuffers(
            PointerBuffer firstIndexOffsets,
            IntBuffer indexCounts,
            IntBuffer vertexOffsets,
            int drawCount,
            CallbackInfo ci) {
        VeilFullFrameTelemetry.multiDraw(this.veil$token, drawCount, true);
    }

    @Inject(method = "drawMultipleIndexed", at = @At("HEAD"), require = 0)
    private <T> void veil$drawMultipleIndexed(
            Collection<RenderPass.Draw<T>> draws,
            GpuBuffer defaultIndexBuffer,
            IndexType defaultIndexType,
            Collection<String> dynamicUniforms,
            T uniformArgument,
            CallbackInfo ci) {
        VeilFullFrameTelemetry.drawMultipleIndexed(this.veil$token, draws);
    }

    @Inject(method = "close", at = @At("HEAD"), require = 0)
    private void veil$close(CallbackInfo ci) {
        if (!this.veil$started) return;
        VeilFullFrameTelemetry.endGpuRenderPass((RenderPass) (Object) this, this.veil$token);
        this.veil$started = false;
        this.veil$token = -1;
    }
}
